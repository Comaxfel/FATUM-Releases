'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function normalizedRelativePublicPath(urlPath) {
  let text = String(urlPath || '/').split('?')[0].split('#')[0].replace(/\\/g, '/');
  try { text = decodeURIComponent(text); } catch {}
  text = text.replace(/^\/+/, '');
  if (!text) return 'index.html';
  const parts = text.split('/');
  if (parts.some(part => !part || part === '.' || part === '..' || part.includes('\0'))) return null;
  return parts.join('/');
}

function safeJoin(root, relativePath) {
  const base = path.resolve(root);
  const target = path.resolve(base, relativePath);
  if (target !== base && !target.startsWith(`${base}${path.sep}`)) return null;
  return target;
}

function fileExists(filePath) {
  try { return fs.statSync(filePath).isFile(); } catch { return false; }
}

function isOverrideEligible(relativePath) {
  const normalized = String(relativePath || '').replace(/\\/g, '/').toLowerCase();
  return normalized.startsWith('assets/items/') ||
    normalized.startsWith('assets/audio/core/') ||
    normalized.startsWith('assets/cursors/');
}

// FATUM 1.7.19-1.7.22: hashes of historical *official* item art that may have
// been auto-captured into overrides by older updater versions.  When an
// override matches one of these hashes it is not a real user customization,
// so the refreshed built-in asset is allowed through.  Any different hash
// remains a genuine user override and keeps priority.
const LEGACY_OFFICIAL_ITEM_HASHES = new Map([
  ['assets/items/profiles-stable/consumables/batareya.webp', new Set(['6d0503c37f5af11964aca63d3710e45c9126f28313a93cfbb84d2f929a919221'])],
  ['assets/items/profiles-stable/consumables/bolty.webp', new Set(['75e2853622b7c5726d348977125ef6436c65994f53e2403714b2f28c5e60e905'])],
  ['assets/items/profiles-stable/consumables/dymovaya-shashka.webp', new Set(['04bd66dd2169387440ef064460f03cda6a03c7e4c691429606b0dddf0774d2fa'])],
  ['assets/items/profiles-stable/consumables/himicheskiy-neytralizator.webp', new Set(['00def9c2fe6bd7d553e2032c31fe9f76682f1f8840eef8fe00fee179cc8f7de7'])],
  ['assets/items/profiles-stable/consumables/mikrofonnyy-signalizator.webp', new Set(['68ec36e61f722e07850619a09354988703f09463a4301407d90213e0aeb04a3a', '934c3cb2a1d9521aae3500f914d6817096fc5fd7d1ff2457ec38ffaf7f9fdae6'])],
  ['assets/items/profiles-stable/consumables/podavitel-radiochastot.webp', new Set(['917aa940e3a43fed4c991894643e9ce2ef910f3bef585df283605705a5ad3f8d', 'fd268ab8b9436d5f00a833ca605be009618d767549f3984010fae1094ec16ee3'])],
  ['assets/items/profiles-stable/consumables/portativnyy-generator.webp', new Set(['d71f6bcb02347080330451166f1ce0e2c7cdae4a124d6f10661fbf0920a724fb', 'b0069eb02b44bca552dbb549b4eef494656d2ea9a4a0c27e4e2f772a852352bc'])],
  ['assets/items/profiles-stable/consumables/skript-detonator.webp', new Set(['9c927c597a54e34e2406063313aec0bb5d076fd5e589fe7d7129debd5fffa9df'])],
  ['assets/items/profiles-stable/consumables/strely.webp', new Set(['71765b454a6ae1a1b3dd54b0c29de8dd2a9dccb671db97cdad7d4ee751ae385d'])],
  ['assets/items/profiles/consumables/item-1233afc7.webp', new Set(['68ec36e61f722e07850619a09354988703f09463a4301407d90213e0aeb04a3a', '934c3cb2a1d9521aae3500f914d6817096fc5fd7d1ff2457ec38ffaf7f9fdae6'])],
  ['assets/items/profiles/consumables/item-61e61c6f.webp', new Set(['d71f6bcb02347080330451166f1ce0e2c7cdae4a124d6f10661fbf0920a724fb', 'b0069eb02b44bca552dbb549b4eef494656d2ea9a4a0c27e4e2f772a852352bc'])],
  ['assets/items/profiles/consumables/item-638ee485.webp', new Set(['917aa940e3a43fed4c991894643e9ce2ef910f3bef585df283605705a5ad3f8d', 'fd268ab8b9436d5f00a833ca605be009618d767549f3984010fae1094ec16ee3'])],
  ['assets/items/profiles/consumables/item-88460b76.webp', new Set(['9c927c597a54e34e2406063313aec0bb5d076fd5e589fe7d7129debd5fffa9df'])],
  ['assets/items/profiles/consumables/item-8ac4c194.webp', new Set(['04bd66dd2169387440ef064460f03cda6a03c7e4c691429606b0dddf0774d2fa'])],
  ['assets/items/profiles/consumables/item-96a4c39f.webp', new Set(['6d0503c37f5af11964aca63d3710e45c9126f28313a93cfbb84d2f929a919221'])],
  ['assets/items/profiles/consumables/item-97aea1d8.webp', new Set(['75e2853622b7c5726d348977125ef6436c65994f53e2403714b2f28c5e60e905'])],
  ['assets/items/profiles/consumables/item-e7a240e1.webp', new Set(['71765b454a6ae1a1b3dd54b0c29de8dd2a9dccb671db97cdad7d4ee751ae385d'])],
  ['assets/items/profiles/consumables/item-ecb618a7.webp', new Set(['00def9c2fe6bd7d553e2032c31fe9f76682f1f8840eef8fe00fee179cc8f7de7'])],
  ['assets/items/profiles-stable/consumables/signalnyy-mayachok.webp', new Set(['ddc0644ad398ff08cf3db2af1c2201b16df22068c0c9ab8b43e5d9e359bd5208'])],
  ['assets/items/profiles-stable/consumables/svetyaschiysya-marker.webp', new Set(['6c74f2e70da114c6378e6d6ecc8de0d1f7c8e01cb85ca914ad46e8a9d9189b62'])],
  ['assets/items/profiles/consumables/item-34d1fad5.webp', new Set(['ddc0644ad398ff08cf3db2af1c2201b16df22068c0c9ab8b43e5d9e359bd5208'])],
  ['assets/items/profiles/consumables/item-f12353ec.webp', new Set(['6c74f2e70da114c6378e6d6ecc8de0d1f7c8e01cb85ca914ad46e8a9d9189b62'])],
  ['assets/items/models/melee/item-013ad975.webp', new Set(['8c95819a9874eeb2153120edc9e5a888bd4dd72fc2f7e321fbc910a4a47bc568', '347f7862da666ffddd6887c2e6b1c7825e5b5e5e7912b63e2078ca114cf41f50'])],
  ['assets/items/models/melee/item-08e24b7f.webp', new Set(['7eb4fa249873635898f1ab31accec428fb1f4981a4c61ec4332c4ec5fd193f12', 'b4cc95c582ddd81c19a8a3433a141319f26ca613438afcabf4d466d55585dfaf'])],
  ['assets/items/models/melee/item-13110da4.webp', new Set(['79500d5eb6182bc74b8d1a1d21273a1c2aa605362a3898da0171f6f956481d53', '7348714812a2632ba8ccebccf7ec27ff0cf41084d0e242a5502ef11c1c64d309'])],
  ['assets/items/models/melee/item-14a96eaa.webp', new Set(['60742e4f9ac9f35421097266949735672c1ad6e2384b80a0c22ebc15a8059235', '47b65f50dd2c8d1b1cd0b27da10c5e6927823d41331402cf79520bc5291fc872'])],
  ['assets/items/models/melee/item-3701a903.webp', new Set(['f4afe8d639188465e938f7d0224154ba1e307d74c3797d4c63854fd06ee2c83d', '72b341e5ae4119275b1d71b712a577f640a0ab96a691875b7bdf9603e8f2f889'])],
  ['assets/items/models/melee/item-3b2a64c9.webp', new Set(['b314a9565db2175403e08e9cde5fdcc9ee991ddfb66ac219af15cda279796268', '0b97e4167aa38d1a5d181660c28689103b6647636a7d8e916e4e87ad5ad76eee'])],
  ['assets/items/models/melee/item-3eba6385.webp', new Set(['95d6c1128878fb9f368b71be622171ca03d9a022a7f215d185fd0bfacba433d3', '45a072a1d486822dfbb03df6393e160ee46d01954ff796e9306423a8987115b7'])],
  ['assets/items/models/melee/item-4ac3bc3a.webp', new Set(['f385ca0b816bb04e4486206df068961392400576978fabadcce0a4b2dd9596b7', 'dad8cf10104d62f595d8cd457e657adeb26d11edd349a27e43056375ac84fc83'])],
  ['assets/items/models/melee/item-4ff0eae9.webp', new Set(['742c1ea164dd05700922b3d742085d60a79aa29cd42f0eb3d23f1e9814fce2c2', 'aa0d14bd605705d0dd69be33270d64e1b1458cb96f0199bcf3daac91d8a78c93'])],
  ['assets/items/models/melee/item-50a5b19a.webp', new Set(['13ba6416983c598985d2cf5a7f01fd31da427826b726a15d70cd8a9f086e15a6', '42d2edafb4ece82d357e907edcfb48730dad21395e9906279883bab3bb756248'])],
  ['assets/items/models/melee/item-529f6003.webp', new Set(['5497449e1b9f7d40e81173f486fde1740275b252f14803a19fb2a825fdee3699', '9c0618856376c61d8b0b0f0beddf7a7b37960f731df5adc932fe2dcf3b001882'])],
  ['assets/items/models/melee/item-5ac69491.webp', new Set(['4396d3423e82f9189cfbec61888efd2bf008534eadc7c1feadb8d5fde2da1d17', '56d4cc40ebcdf90519d4860d23a501d1f1267ee849302e545756c99ef59297c4'])],
  ['assets/items/models/melee/item-66729750.webp', new Set(['edcf23c779758ff662b752f5e3feb978ecd958de0b08472aabb93bfc6b27eadc', 'ff7c804c67e3ca80aca93b04673a4af5f5aacf17eda23cb4b68568b545a2a104'])],
  ['assets/items/models/melee/item-6a878365.webp', new Set(['a0b4d91e4852be361e0a86f6246d084ebcee44459a78c05e3de345e800d73fea', 'f4427def453a798163d89930804880b4ada2c2a64f49b057c2a5c4c8a57e914a'])],
  ['assets/items/models/melee/item-745ba23e.webp', new Set(['71da1cc72f218920b90ea482cb25fead73e13a920113d4b772e878c6c116aaa2', '1f626b2190836cc7a4b5446e7245bb2669398b78f7d6d7a63ef9e1d413765f7c'])],
  ['assets/items/models/melee/item-75ec6fed.webp', new Set(['e9833468cc67a36ea2249a288dede2e3dbe3dadc4a511d7908155794caa6be90', 'c5a49b232917336691373e3d1447ac1f10dab361738d5e4d95492c89e8be303a'])],
  ['assets/items/models/melee/item-77aa0f0c.webp', new Set(['a5ae65cd1c1c4761aca12acc9c459331b0f57f111b44b3f49e651f2d001831e7', 'bc52eace5873857b583f5ec971d626020500de22c19ebc80f4ca47127c1ad968'])],
  ['assets/items/models/melee/item-7dcad2a0.webp', new Set(['1e307259ad4b8410aedf40f5a6da41f6adc415277e2f9bebf0b8c37d05c52557', '9a468580ade12f7f5deb31e6cebaf370ed007f7db3f92b240da20b7285637f6f'])],
  ['assets/items/models/melee/item-810e0ac4.webp', new Set(['c5cd8fbbc50b22e1ea91f12ddb41a49c8bc481baf70b9fdda9775526ae22360e', 'd2d765f1dfcc8a19a6c61c0ebb7b08cb40a24b219eaf6b375e25890aa11f3d63'])],
  ['assets/items/models/melee/item-8c292b76.webp', new Set(['476383c9674420cd5eefe86bcbf7881cd69406a95bf6311cdd3184602a873cbf', 'e8268dd9bf4b1c72e2aa3b8ad921c5d77e0c9cf0a152f7e76cc5a6c0fdf5e379'])],
  ['assets/items/models/melee/item-a7c45589.webp', new Set(['ca07bb79ca868680791de0e58e2e861de9cbd129d8839520ae4d7158afd20087', 'eafc60a370a24b67606f5be762f4e5a25ee0aa3e3dd2315fa50a30e87464ee2f'])],
  ['assets/items/models/melee/item-b1111c91.webp', new Set(['40f7b75965fca899610182e5f0ceeb62ea5b4d0569047091083503fd3778bb7a', '2182bc413d8e6a23dfd8af9d569353ce6a40e8628acb725274e0dbb73c1f9db8'])],
  ['assets/items/models/melee/item-bcbff290.webp', new Set(['581c02db305825a7a016b887fd8932449be2525dae919522ca690651f0f37733', '4cf4244f6fa2a8598c36c2a6fff61556ddb48326aad3e32249e5a3d8a54cb06b'])],
  ['assets/items/models/melee/item-bd93a4cc.webp', new Set(['ff8ee92a30143798868eba08a82dcc292d39516f6cfee6530bde143b2345bba9', 'bafbbe07dc4dab8afd0faf5e292b5f03634c6641c9d2ee2b0ee4ed9f1d0ed2ee'])],
  ['assets/items/models/melee/item-c1ba4fd3.webp', new Set(['1b31bd30f76ff5d52633b4c5b2eb08fd421ef0e369e2b818f07870fedce67d3a', 'f92e2dab3f91287592af6e4563b7b544d7c4e1859def87815dfb50a80c26d213'])],
  ['assets/items/models/melee/item-c26efa20.webp', new Set(['59b0e106a26fdb74723624221504c6c02297a9e52707317ed29de3a830831b83', 'bcaa8aa40a7c902e8750e42bd3a3c2e8670cd4b7d6788c98acbd23641cefdcf1'])],
  ['assets/items/models/melee/item-cffa389a.webp', new Set(['4d711699b9b9aed81469b1f10604916b20d4f88d2789abf4943fa8f54dede30c', '7143830b4f0033d0659ad6e814f76c23ecda5e895291899b5958fb35fed57269'])],
  ['assets/items/models/melee/item-d16dbb6c.webp', new Set(['1c840d000fd63f58aa0ba4264fdbeb3e9d6f61b34b4f5e105a718cbf73b048e4', 'd1cb112321c7da4dfcd7f403572ec1307673c9c543b34973dac049df485cef61'])],
  ['assets/items/models/melee/item-ec5a582c.webp', new Set(['9f23a7c7db1020e17da8fc25afa09b2a6486937a6e36e5d9c4d72509ac5c9736', '2d6e13a65f9723c4a8033bcfea97c6473e146d5acda01183dedac41f68074767'])],
  ['assets/items/models-stable/melee/alebarda.webp', new Set(['476383c9674420cd5eefe86bcbf7881cd69406a95bf6311cdd3184602a873cbf'])],
  ['assets/items/models-stable/melee/boevoy-topor.webp', new Set(['f4afe8d639188465e938f7d0224154ba1e307d74c3797d4c63854fd06ee2c83d'])],
  ['assets/items/models-stable/melee/boevoy-toporik.webp', new Set(['40f7b75965fca899610182e5f0ceeb62ea5b4d0569047091083503fd3778bb7a'])],
  ['assets/items/models-stable/melee/bulava.webp', new Set(['742c1ea164dd05700922b3d742085d60a79aa29cd42f0eb3d23f1e9814fce2c2'])],
  ['assets/items/models-stable/melee/dlinnyy-bagor.webp', new Set(['1c840d000fd63f58aa0ba4264fdbeb3e9d6f61b34b4f5e105a718cbf73b048e4'])],
  ['assets/items/models-stable/melee/dubinka.webp', new Set(['71da1cc72f218920b90ea482cb25fead73e13a920113d4b772e878c6c116aaa2'])],
  ['assets/items/models-stable/melee/dvuruchnyy-topor.webp', new Set(['1e307259ad4b8410aedf40f5a6da41f6adc415277e2f9bebf0b8c37d05c52557'])],
  ['assets/items/models-stable/melee/kastet.webp', new Set(['59b0e106a26fdb74723624221504c6c02297a9e52707317ed29de3a830831b83'])],
  ['assets/items/models-stable/melee/klinok-inspektora.webp', new Set(['edcf23c779758ff662b752f5e3feb978ecd958de0b08472aabb93bfc6b27eadc'])],
  ['assets/items/models-stable/melee/kope.webp', new Set(['4396d3423e82f9189cfbec61888efd2bf008534eadc7c1feadb8d5fde2da1d17'])],
  ['assets/items/models-stable/melee/korotkaya-sablya.webp', new Set(['8c95819a9874eeb2153120edc9e5a888bd4dd72fc2f7e321fbc910a4a47bc568'])],
  ['assets/items/models-stable/melee/korotkiy-stilet.webp', new Set(['9f23a7c7db1020e17da8fc25afa09b2a6486937a6e36e5d9c4d72509ac5c9736'])],
  ['assets/items/models-stable/melee/korotkoe-kope.webp', new Set(['b314a9565db2175403e08e9cde5fdcc9ee991ddfb66ac219af15cda279796268'])],
  ['assets/items/models-stable/melee/kukri.webp', new Set(['4d711699b9b9aed81469b1f10604916b20d4f88d2789abf4943fa8f54dede30c'])],
  ['assets/items/models-stable/melee/kuvalda.webp', new Set(['ca07bb79ca868680791de0e58e2e861de9cbd129d8839520ae4d7158afd20087'])],
  ['assets/items/models-stable/melee/machete.webp', new Set(['60742e4f9ac9f35421097266949735672c1ad6e2384b80a0c22ebc15a8059235'])],
  ['assets/items/models-stable/melee/molotok.webp', new Set(['13ba6416983c598985d2cf5a7f01fd31da427826b726a15d70cd8a9f086e15a6'])],
  ['assets/items/models-stable/melee/ofitserskaya-sablya.webp', new Set(['f385ca0b816bb04e4486206df068961392400576978fabadcce0a4b2dd9596b7'])],
  ['assets/items/models-stable/melee/okopnyy-shtyk.webp', new Set(['e9833468cc67a36ea2249a288dede2e3dbe3dadc4a511d7908155794caa6be90'])],
  ['assets/items/models-stable/melee/politseyskaya-palka.webp', new Set(['581c02db305825a7a016b887fd8932449be2525dae919522ca690651f0f37733'])],
  ['assets/items/models-stable/melee/promyshlennyy-lom.webp', new Set(['a5ae65cd1c1c4761aca12acc9c459331b0f57f111b44b3f49e651f2d001831e7'])],
  ['assets/items/models-stable/melee/razryadnyy-kastet.webp', new Set(['a0b4d91e4852be361e0a86f6246d084ebcee44459a78c05e3de345e800d73fea'])],
  ['assets/items/models-stable/melee/sapernaya-lopatka.webp', new Set(['7eb4fa249873635898f1ab31accec428fb1f4981a4c61ec4332c4ec5fd193f12'])],
  ['assets/items/models-stable/melee/sapozhnyy-nozh.webp', new Set(['c5cd8fbbc50b22e1ea91f12ddb41a49c8bc481baf70b9fdda9775526ae22360e'])],
  ['assets/items/models-stable/melee/shokovaya-dubinka.webp', new Set(['95d6c1128878fb9f368b71be622171ca03d9a022a7f215d185fd0bfacba433d3'])],
  ['assets/items/models-stable/melee/skladnoy-nozh.webp', new Set(['5497449e1b9f7d40e81173f486fde1740275b252f14803a19fb2a825fdee3699'])],
  ['assets/items/models-stable/melee/transheynyy-nozh.webp', new Set(['ff8ee92a30143798868eba08a82dcc292d39516f6cfee6530bde143b2345bba9'])],
  ['assets/items/models-stable/melee/tyazhelyy-mech.webp', new Set(['79500d5eb6182bc74b8d1a1d21273a1c2aa605362a3898da0171f6f956481d53'])],
  ['assets/items/models-stable/melee/tyazhelyy-tesak.webp', new Set(['1b31bd30f76ff5d52633b4c5b2eb08fd421ef0e369e2b818f07870fedce67d3a'])],
]);

function sha256File(filePath) { return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex'); }
function isHistoricalOfficialOverride(relativePath, filePath) {
  const hashes = LEGACY_OFFICIAL_ITEM_HASHES.get(String(relativePath || '').replace(/\\/g, '/').toLowerCase());
  if (!hashes || !hashes.size) return false;
  try { return hashes.has(sha256File(filePath)); } catch { return false; }
}

function resolvePublicAsset(publicDir, overridePublicDir, urlPath, fallback = 'index.html') {
  const relative = normalizedRelativePublicPath(urlPath === '/' ? fallback : urlPath);
  if (!relative) return null;

  if (overridePublicDir && isOverrideEligible(relative)) {
    const override = safeJoin(overridePublicDir, relative);
    if (override && fileExists(override) && !isHistoricalOfficialOverride(relative, override)) return { file: override, overridden: true, relative };
  }

  const normal = safeJoin(publicDir, relative);
  return normal ? { file: normal, overridden: false, relative } : null;
}

module.exports = {
  normalizedRelativePublicPath,
  safeJoin,
  isOverrideEligible,
  resolvePublicAsset
};
