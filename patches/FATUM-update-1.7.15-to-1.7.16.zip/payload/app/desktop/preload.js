'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('fatumDesktop', {
  isDesktop:true,
  getContext:() => ipcRenderer.invoke('desktop:get-context'),
  connectServer:value => ipcRenderer.invoke('desktop:connect-server', value),
  changeServer:() => ipcRenderer.send('desktop:change-server'),
  goCampaigns:() => ipcRenderer.invoke('desktop:go-campaigns'),
  requestExit:() => ipcRenderer.invoke('desktop:request-exit'),
  toggleFullscreen:() => ipcRenderer.invoke('desktop:toggle-fullscreen'),
  getServerUrl:() => ipcRenderer.invoke('desktop:get-server-url'),
  saveHtmlAsPng:payload => ipcRenderer.invoke('desktop:save-html-png', payload),
  alertSync:(message,title='FATUM') => ipcRenderer.sendSync('desktop:alert-sync',{message,title}),
  confirmSync:(message,title='FATUM') => ipcRenderer.sendSync('desktop:confirm-sync',{message,title}),
  onServerStopped:handler => ipcRenderer.on('fatum-server-stopped',(_event,payload)=>handler(payload))
});

window.addEventListener('DOMContentLoaded', () => {
  document.documentElement.classList.add('fatum-desktop');
  document.querySelectorAll('[data-fatum-desktop-only]').forEach(node => { node.hidden = false; });
});
