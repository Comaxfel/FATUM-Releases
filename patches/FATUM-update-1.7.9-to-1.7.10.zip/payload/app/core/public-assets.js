'use strict';

const fs = require('fs');
const path = require('path');

function normalizedRelativePublicPath(urlPath) {
  let text = String(urlPath || '/').split('?')[0].split('#')[0].replace(/\\/g, '/');
  try { text = decodeURIComponent(text); } catch {}
  text = text.replace(/^\/+/, '');
  if (!text) return 'index.html';
  const parts = text.split('/');
  if (parts.some(part => !part || part === '.' || part === '..' || part.includes('\0'))) return null;
  return parts.join('/');
}

function safeJoin(root, relativePath) {
  const base = path.resolve(root);
  const target = path.resolve(base, relativePath);
  if (target !== base && !target.startsWith(`${base}${path.sep}`)) return null;
  return target;
}

function fileExists(filePath) {
  try { return fs.statSync(filePath).isFile(); } catch { return false; }
}

function isOverrideEligible(relativePath) {
  const normalized = String(relativePath || '').replace(/\\/g, '/').toLowerCase();
  return normalized.startsWith('assets/items/') ||
    normalized.startsWith('assets/audio/core/') ||
    normalized.startsWith('assets/cursors/');
}

function resolvePublicAsset(publicDir, overridePublicDir, urlPath, fallback = 'index.html') {
  const relative = normalizedRelativePublicPath(urlPath === '/' ? fallback : urlPath);
  if (!relative) return null;

  if (overridePublicDir && isOverrideEligible(relative)) {
    const override = safeJoin(overridePublicDir, relative);
    if (override && fileExists(override)) return { file: override, overridden: true, relative };
  }

  const normal = safeJoin(publicDir, relative);
  return normal ? { file: normal, overridden: false, relative } : null;
}

module.exports = {
  normalizedRelativePublicPath,
  safeJoin,
  isOverrideEligible,
  resolvePublicAsset
};
