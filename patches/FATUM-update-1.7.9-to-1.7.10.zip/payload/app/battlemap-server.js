'use strict';

const fs = require('fs');
const path = require('path');
const { randomUUID } = require('crypto');
const { atomicWriteFile, atomicWriteJsonSync } = require('./core/io');
const { addCriticalRecoveryEffect } = require('./core/campaign-time');

function createBattlemapModule(options) {
  const {
    rootDir,
    dataDir,
    getCampaign,
    persistCampaign,
    persistHistory,
    recordHistory,
    publicHistoryEntry,
    broadcastHistory,
    broadcastCharacterUpdated,
    broadcastDice,
    broadcastCampaignReplaced,
    getSseClients,
    sseWrite,
    isMasterAuthorized,
    readJsonBody,
    sendJson,
    nowIso,
    clone,
    cleanId,
    cleanName,
    cleanText,
    safeNumber,
    clamp,
    makeId,
    normalizeDie,
    dieSides,
    rollOne,
    createSnapshot
  } = options;

  let currentDataDir = dataDir;
  let BATTLEMAP_FILE = null;
  let MAP_DIR = null;
  let TOKEN_DIR = null;
  let AUDIO_DIR = null;
  const CORE_AUDIO_DIR = path.join(rootDir, 'public', 'assets', 'audio', 'core');
  const CORE_AUDIO_MANIFEST = path.join(CORE_AUDIO_DIR, 'core-audio.json');
  const SHARED_AUDIO_DIR = path.join(rootDir, 'data', 'shared', 'audio');
  const SHARED_AUDIO_FILE = path.join(rootDir, 'data', 'shared', 'audio-library.json');
  let coreAudioLibrary = [];
  let sharedAudioLibrary = [];
  let coreDefaultEffectBindings = {};
  function configureStorage(nextDataDir) {
    currentDataDir = nextDataDir || dataDir;
    BATTLEMAP_FILE = path.join(currentDataDir, 'battlemap.json');
    MAP_DIR = path.join(currentDataDir, 'maps');
    TOKEN_DIR = path.join(currentDataDir, 'tokens');
    AUDIO_DIR = path.join(currentDataDir, 'audio');
  }
  configureStorage(dataDir);
  const MAX_SCENES = 100;
  const MAX_TOKENS = 1000;
  const MAX_WALLS = 6000;
  const MAX_LIGHTS = 1000;
  const MAX_DOORS = 2000;
  const MAX_COVERS = 2000;
  const MAX_EFFECT_ZONES = 1000;
  const MAX_AUDIO_SOURCES = 500;
  const MAX_WEATHER_LAYERS = 20;
  const MAX_PARALLAX_LAYERS = 64;
  const MAX_PARALLAX_OBJECTS = 300;
  const MAX_ELEVATION_ZONES = 300;
  const MAX_TRIGGER_ZONES = 500;
  const MAX_DRAWINGS = 2000;
  const MAX_DRAWING_POINTS = 2400;
  const MAX_MAP_WIDGETS = 300;

  const VEHICLE_PROFILES = {
    motorcycle:{name:'Мотоцикл',environment:'ground',speed:4,maneuver:2,mz:5,hull:3,armor:'none',bz:0,crew:1,passengers:1,cargo:0,slots:1},
    car:{name:'Легковой автомобиль',environment:'ground',speed:3,maneuver:1,mz:4,hull:5,armor:'none',bz:0,crew:1,passengers:3,cargo:1,slots:1},
    offroad:{name:'Внедорожник',environment:'ground',speed:3,maneuver:0,mz:4,hull:6,armor:'light',bz:2,crew:1,passengers:4,cargo:2,slots:2},
    truck:{name:'Грузовик',environment:'ground',speed:2,maneuver:-1,mz:3,hull:8,armor:'none',bz:0,crew:1,passengers:2,cargo:5,slots:2},
    armoredCar:{name:'Броневик',environment:'ground',speed:2,maneuver:-1,mz:3,hull:9,armor:'medium',bz:4,crew:2,passengers:4,cargo:2,slots:3},
    heavyCarrier:{name:'Тяжёлый бронетранспорт',environment:'ground',speed:2,maneuver:-2,mz:2,hull:12,armor:'heavy',bz:6,crew:2,passengers:8,cargo:3,slots:4},
    motorboat:{name:'Моторная лодка',environment:'water',speed:3,maneuver:1,mz:4,hull:4,armor:'none',bz:0,crew:1,passengers:3,cargo:1,slots:1},
    boat:{name:'Катер',environment:'water',speed:3,maneuver:0,mz:4,hull:6,armor:'light',bz:2,crew:1,passengers:5,cargo:2,slots:2},
    armoredBoat:{name:'Бронекатер',environment:'water',speed:2,maneuver:-1,mz:3,hull:9,armor:'medium',bz:4,crew:2,passengers:6,cargo:3,slots:3},
    barge:{name:'Грузовая баржа',environment:'water',speed:1,maneuver:-2,mz:2,hull:12,armor:'none',bz:0,crew:2,passengers:4,cargo:8,slots:2},
    autogyro:{name:'Автожир',environment:'air',speed:4,maneuver:2,mz:5,hull:3,armor:'none',bz:0,crew:1,passengers:1,cargo:0,slots:1},
    lightPlane:{name:'Лёгкий самолёт',environment:'air',speed:5,maneuver:2,mz:5,hull:4,armor:'none',bz:0,crew:1,passengers:1,cargo:0,slots:1},
    scoutPlane:{name:'Разведывательный самолёт',environment:'air',speed:5,maneuver:1,mz:5,hull:5,armor:'light',bz:1,crew:1,passengers:1,cargo:0,slots:1},
    attackPlane:{name:'Штурмовик',environment:'air',speed:4,maneuver:1,mz:4,hull:7,armor:'medium',bz:3,crew:1,passengers:0,cargo:1,slots:3},
    transportPlane:{name:'Транспортный самолёт',environment:'air',speed:4,maneuver:-1,mz:3,hull:10,armor:'light',bz:2,crew:2,passengers:10,cargo:6,slots:2},
    airship:{name:'Дирижабль',environment:'air',speed:2,maneuver:-2,mz:2,hull:14,armor:'none',bz:0,crew:4,passengers:20,cargo:10,slots:4},
    warAirship:{name:'Военный дирижабль',environment:'air',speed:2,maneuver:-2,mz:2,hull:16,armor:'medium',bz:5,crew:6,passengers:30,cargo:12,slots:6},
    horse:{name:'Верховая лошадь',environment:'ground',speed:3,maneuver:1,mz:4,hull:4,armor:'none',bz:0,crew:1,passengers:1,cargo:1,slots:0}
  };
  const MAX_FOG_OPS = 2500;
  const MAX_EXPLORED_CELLS = 60000;
  const requestCache = new Map();
  const pendingMeleeCounters = new Map();
  // v1.5.3: unresolved visible rolls stay open briefly so post-roll reactions can
  // change the result before damage / combat consequences are committed.
  const pendingRollResolutions = new Map();
  // v1.1.11: реакции на брошенные вручную гранаты живут отдельно от атак
  // гранатомётов. Правила дают эту реакцию именно на "брошенную гранату".
  const pendingGrenadeReactions = new Map();
  // v1.7.7: opportunity / Zone-of-Fire reactions are choices, not forced attacks.
  // The pending map keeps the mover's HTTP request open only while the attacker decides.
  const pendingCombatReactions = new Map();

  let rulesSourceCache = null;
  function rulesSource() {
    if (rulesSourceCache === null) rulesSourceCache = fs.readFileSync(path.join(rootDir, 'public', 'index.html'), 'utf8');
    return rulesSourceCache;
  }
  function readJsonConst(marker, fallback) {
    try {
      const source = rulesSource();
      const markerIndex = source.indexOf(`const ${marker} =`);
      if (markerIndex < 0) return fallback;
      const arrayStart = source.indexOf('[', markerIndex);
      const objectStart = source.indexOf('{', markerIndex);
      let start = -1;
      if (arrayStart >= 0 && objectStart >= 0) start = Math.min(arrayStart, objectStart);
      else start = Math.max(arrayStart, objectStart);
      if (start < 0) return fallback;
      const opener = source[start], closer = opener === '[' ? ']' : '}';
      let depth = 0, quote = null, escaped = false, end = -1;
      for (let index = start; index < source.length; index += 1) {
        const char = source[index];
        if (quote) {
          if (escaped) escaped = false;
          else if (char === '\\') escaped = true;
          else if (char === quote) quote = null;
          continue;
        }
        if (char === '"' || char === "'") { quote = char; continue; }
        if (char === opener) depth += 1;
        else if (char === closer) { depth -= 1; if (depth === 0) { end = index; break; } }
      }
      if (end < 0) return fallback;
      return JSON.parse(source.slice(start, end + 1));
    } catch (error) {
      console.warn(`Не удалось загрузить каталог ${marker}:`, error.message);
      return fallback;
    }
  }

  function catalogMap(marker) {
    const values = readJsonConst(marker, []);
    return new Map((Array.isArray(values) ? values : []).filter(item => item && item.id).map(item => [String(item.id), item]));
  }

  function readWeaponCatalog() {
    const values = readJsonConst('shopItems', []);
    return new Map((Array.isArray(values) ? values : []).filter(item => item && item.name).map(item => [String(item.name), item]));
  }

  const weaponCatalog = readWeaponCatalog();
  // Legacy campaigns can store the decorative model as item.name instead of
  // the canonical weapon profile. The character sheet knows these aliases,
  // but the battlemap used to see only the raw model and therefore could not
  // restore its profile (most visibly with Stahlhammer-11 shotguns).
  const LEGACY_WEAPON_PROFILE_ALIASES = new Map(Object.entries({
    'Poche-M2':'Карманный пистолет','Лань-M1':'Карманный пистолет',
    'Liberté-M1':'Средний пистолет','Kriegspistole':'Средний пистолет','Фэй Лун':'Средний пистолет','Тэппо':'Средний пистолет',
    'Kriegsfaust-11':'Тяжёлый пистолет','Буря-П':'Тяжёлый пистолет','Cavaliere-38':'Револьвер','Sûreté-R':'Револьвер','R-18 Revolver Vento':'Тяжёлый револьвер',
    'Traur-U':'Анаксионный пистолет','Тэндзо-Рэй':'Анаксионный пистолет',
    'Égalité':'Лёгкий карабин','Scauta-K2':'Лёгкий карабин','Банту Тип-31':'Армейский карабин','Ligne-M3':'Армейский карабин','Stahlkar-8':'Армейский карабин',
    'Банту Тип-32':'Штурмовой карабин','Кагэцу Тип-7':'Штурмовой карабин','Blitzsturm-kurz':'Автоматический карабин','Molot-B1':'Автоматический карабин',
    'Фэнчэн-L1':'Точный карабин','SR-42 Cacciatore':'Точный карабин','Fraternité':'Охотничья винтовка','Hirschlauf-3':'Охотничья винтовка',
    'Adlerauge-S':'Армейский карабин','Ordonnance-5':'Служебная винтовка','Adlerauge-X':'Снайперская винтовка','Шэньхуо':'Снайперская винтовка',
    'Palitsa-M2':'Анаксионная винтовка','Рюсан-C2':'Анаксионная винтовка','Рюсан-С2':'Анаксионная винтовка','Противобронная винтовка':'Анаксионная винтовка',
    'Bâtard-9':'Обрез','Лэймэнь-L2':'Стандартный дробовик','M. Dural':'Стандартный дробовик','Цзиньфэн':'Стандартный дробовик',
    'Stahlhammer-11':'Боевой дробовик','DS-15 Tempesta':'Боевой дробовик','Ками-Рэн':'Боевой дробовик',
    'Zarya-D1':'Боевой дробовик','Molot-R2':'Боевой дробовик','Пулевой дробовик':'Боевой дробовик','Stahlhammer-11F':'Огнемётный',
    'Éruption':'Лёгкий гранатомёт','Feuersturm':'Лёгкий гранатомёт','Festungsbrecher-T4':'Тяжёлый гранатомёт','Гром-О2':'Тяжёлый гранатомёт',
    'Stahlregen-11':'Тяжёлый пулемёт','Molot-MG2':'Тяжёлый пулемёт','Zvezda-T2':'Тяжёлый гранатомёт','Они-Баку':'Анаксионный излучатель',
    'Складной нож':'Малое оружие','Кастет Гроза':'Малое оружие','Кастет':'Малое оружие','Окопный штык':'Лёгкое оружие','Клинок Инспектора':'Лёгкое оружие',
    'Клинок инспектора':'Лёгкое оружие','Траншейный нож':'Лёгкое оружие','Тренч-клинок':'Лёгкое оружие','Короткая сабля':'Лёгкое оружие',
    'Сапёрная лопатка':'Среднее оружие','Мачете':'Среднее оружие','Короткое копьё':'Среднее оружие','Боевой топорик':'Среднее оружие',
    'Кукри':'Тяжёлое оружие','Офицерская сабля':'Тяжёлое оружие','Тяжёлый тесак':'Тяжёлое оружие','Боевой топор':'Тяжёлое оружие',
    'Простая дубинка':'Дробящее оружие','Дубинка':'Дробящее оружие','Молоток':'Дробящее оружие','Булава':'Дробящее оружие','Полицейская палка':'Дробящее оружие',
    'Копьё':'Древковое оружие','Алебарда':'Древковое оружие','Длинный багор':'Древковое оружие',
    'Кувалда':'Тяжёлое двуручное оружие','Двуручный топор':'Тяжёлое двуручное оружие','Тяжёлый меч':'Тяжёлое двуручное оружие','Промышленный лом':'Тяжёлое двуручное оружие',
    'Анаксионная дубинка Taser':'Анаксионное оружие ближнего боя','Шоковая дубинка':'Анаксионное оружие ближнего боя','Разрядный кастет':'Анаксионное оружие ближнего боя'
  }));
  function canonicalWeaponProfileAlias(...values) {
    for (const value of values) {
      const raw=String(value||'').trim();if(!raw)continue;
      if(weaponCatalog.has(raw))return raw;
      const direct=LEGACY_WEAPON_PROFILE_ALIASES.get(raw);if(direct)return direct;
      const lower=raw.toLocaleLowerCase('ru-RU');
      for(const [model,profile] of LEGACY_WEAPON_PROFILE_ALIASES)if(model.toLocaleLowerCase('ru-RU')===lower)return profile;
    }
    return '';
  }

  // Armor uses the same profile/model split as weapons. Profiles contain all
  // mechanics; model names are decorative/lore identifiers. Legacy campaigns
  // may still store the old concrete armor name, so normalize it server-side
  // before any combat, skill or movement calculation.
  const LEGACY_ARMOR_PROFILE_ALIASES = new Map(Object.entries({
    'Stahlmantel':'Скрытая броня','Veste Défenseur':'Скрытая броня','Цинцзя':'Скрытая броня',
    'Буря-М':'Полевой бронежилет','Gilet Guerrier':'Армейский бронежилет','Дуншань':'Армейский бронежилет',
    'Kriegskorps':'Противоосколочный бронекомплект','Титан-М':'Усиленный бронекомплект',
    'Berg M8':'Стабилизирующая тяжёлая броня','Armure Titanique':'Анаксионно-изолированная броня',
    'Экзоскелет Т-1':'Тяжёлый экзоскелет','Шаньхэй':'Адаптивный экзоскелет'
  }));
  const ARMOR_PROFILE_TYPES = new Set(['Лёгкая броня','Средняя броня','Тяжёлая броня']);
  function isArmorCatalogItem(item) { return Boolean(item && (item.armorClass || ARMOR_PROFILE_TYPES.has(String(item.type||'')))); }
  function canonicalArmorProfileAlias(...values) {
    for (const value of values) {
      const raw=String(value||'').trim(); if(!raw)continue;
      const directCatalog=weaponCatalog.get(raw); if(isArmorCatalogItem(directCatalog))return raw;
      const direct=LEGACY_ARMOR_PROFILE_ALIASES.get(raw); if(direct)return direct;
      const lower=raw.toLocaleLowerCase('ru-RU');
      for(const [model,profile] of LEGACY_ARMOR_PROFILE_ALIASES)if(model.toLocaleLowerCase('ru-RU')===lower)return profile;
      for(const [profile,item] of weaponCatalog)if(isArmorCatalogItem(item)&&profile.toLocaleLowerCase('ru-RU')===lower)return profile;
    }
    return '';
  }
  function armorCatalogDefinition(...values) {
    const profile=canonicalArmorProfileAlias(...values); return profile ? weaponCatalog.get(profile)||null : null;
  }
  function armorClassFromType(type) {
    const text=String(type||'');
    if(/Л[её]гкая броня/i.test(text))return 'light';
    if(/Средняя броня/i.test(text))return 'medium';
    if(/Тяж[её]лая броня/i.test(text))return 'heavy';
    return 'none';
  }
  function normalizedArmorItem(raw) {
    if(!raw || typeof raw!=='object')return null;
    const profile=canonicalArmorProfileAlias(raw.armorProfile,raw.profile,raw.name,raw.selectedModel,raw.customModel);
    const def=profile?weaponCatalog.get(profile)||null:null;
    const legacyModel=LEGACY_ARMOR_PROFILE_ALIASES.has(String(raw.name||''))?String(raw.name):'';
    const model=String(raw.customModel||raw.selectedModel||raw.model||legacyModel||'').trim();
    // A recognized profile is the single source of truth for mechanics.  Raw
    // class/BZ/feature fields are retained only for custom or legacy armor
    // which cannot be mapped to a canonical profile.
    const armorClass=String(def?.armorClass||raw.armorClass||raw.class||armorClassFromType(raw.type)||'none');
    const armorBz=Math.max(0,Math.round(safeNumber(def?.armorBz??raw.armorBz??raw.bzMax,0)));
    const armorFeature=String(def?.armorFeature||raw.armorFeature||'');
    const rawAnaxion=def ? def.anaxionSteps : raw.anaxionSteps;
    const anaxionSteps=rawAnaxion===undefined||rawAnaxion===null?null:Math.max(0,Math.round(safeNumber(rawAnaxion,0)));
    return {...raw,profile:profile||String(raw.profile||raw.armorProfile||''),armorProfile:profile||String(raw.armorProfile||raw.profile||''),model,armorClass,armorBz,armorFeature,anaxionSteps,definition:def};
  }
  function normalizedNpcArmor(npc) {
    const raw=npc?.armor||{}; const normalized=normalizedArmorItem(raw)||{};
    const profile=canonicalArmorProfileAlias(raw.profile,raw.armorProfile,raw.name,normalized.profile);
    const def=profile?weaponCatalog.get(profile)||null:null;
    const bzMax=Math.max(0,Math.round(safeNumber(def?.armorBz??raw.bzMax??normalized.armorBz,0)));
    const rawCurrent=Math.max(0,Math.round(safeNumber(raw.bzCurrent,bzMax)));
    const bzCurrent=def ? Math.min(bzMax,rawCurrent) : rawCurrent;
    return {...raw,...normalized,profile,armorProfile:profile,definition:def,
      armorClass:String(def?.armorClass||raw.class||raw.armorClass||normalized.armorClass||'none'),
      model:String(raw.name||raw.model||normalized.model||'').trim(),
      bzCurrent,bzMax};
  }
  function armorProfileForHost(host) {
    if(!host)return '';
    if(host.armor && typeof host.armor==='object')return normalizedNpcArmor({armor:host.armor}).profile||'';
    return normalizedArmorItem(equippedInventoryItem(host,'armor'))?.profile||'';
  }
  function armorSpeedPenaltyForProfile(profile) { return ['Усиленный бронекомплект','Тяжёлый экзоскелет'].includes(String(profile||'')) ? -5 : 0; }
  function armorSkillModifierForProfile(profile,skillName) { return profile==='Тяжёлый экзоскелет' && skillGroup(skillName)==='Ловкость' ? -2 : 0; }
  function armorContextualSkillOptions(profile,skillName) {
    if(profile==='Тяжёлый экзоскелет'&&skillName==='Физическая сила')return [{id:'equipment:heavy-exoskeleton-load',kind:'equipment',sourceId:'heavy-exoskeleton-load',name:'Силовой каркас',text:'+1 к проверке Физической силы, если она связана с переносом, подъёмом, удержанием или перемещением тяжёлого предмета. Не применяется к атакам.',frequency:'по ситуации',relevant:true,used:false,reactionOnly:false}];
    return [];
  }
  function armorSeriousPenaltyForProfile(profile) { return profile==='Стабилизирующая тяжёлая броня' ? -1 : -2; }
  function armorDisplayLabel(armor) {
    if(!armor)return 'Броня'; const model=String(armor.model||armor.name||'').trim(),profile=String(armor.profile||armor.armorProfile||'').trim();
    if(model&&profile&&model!==profile)return `${model} (${profile})`; return model||profile||'Броня';
  }
  const CANONICAL_MELEE_PROFILES = new Set([
    'Малое оружие','Лёгкое оружие','Среднее оружие','Тяжёлое оружие',
    'Дробящее оружие','Древковое оружие','Тяжёлое двуручное оружие','Анаксионное оружие ближнего боя','Безоружный бой'
  ]);

  const specializationCatalog = catalogMap('specializationCatalog');
  const doctrineCatalog = catalogMap('doctrineCatalog');
  const characterTraitCatalog = catalogMap('characterTraitsCatalog');
  const nationSkillOptions = readJsonConst('nationSkillOptions', {});

  let state = null;
  let writeChain = Promise.resolve();
  let pendingPersistSnapshot = null;
  let pendingPersistTimer = null;

  const AUDIO_EFFECT_KEYS = [
    'ui.click','ui.turn','ui.combatStart','ui.combatEnd','door.open','door.close',
    'weapon.pistol','weapon.revolver','weapon.carbine','weapon.rifle','weapon.shotgun',
    'weapon.machinegun','weapon.grenadeLauncher','weapon.anaxion','weapon.generic',
    'grenade.throw','grenade.explosion','grenade.smokeGas','zone.suppression','zone.barrage',
    'heavy.reload.machinegun','heavy.reload.grenadeLauncher',
    'natural.claws','natural.bite','melee.hit','unarmed.hit','item.use','token.damage'
  ];
  const AUDIO_FILE_RE = /^[A-Za-z0-9_.-]+\.(?:mp3|ogg|wav|webm|m4a|aac)$/i;
  const AUDIO_MIME_BY_EXT = { mp3:'audio/mpeg', ogg:'audio/ogg', wav:'audio/wav', webm:'audio/webm', m4a:'audio/mp4', aac:'audio/aac' };

  function makeEmptyAudioState() {
    return {
      library: [],
      channels: {
        music: { trackId: null, playing: false, position: 0, startedAt: null, volume: 0.7, loop: true, updatedAt: nowIso() },
        ambient: { trackId: null, playing: false, position: 0, startedAt: null, volume: 0.65, loop: true, updatedAt: nowIso() }
      },
      // null = use the installed core default, "off" = deliberately mute this action.
      effectBindings: Object.fromEntries(AUDIO_EFFECT_KEYS.map(key => [key, null]))
    };
  }

  function cleanAudioKind(value) { return ['music','ambient','effect'].includes(value) ? value : 'effect'; }
  function audioMimeForFile(fileName) { return AUDIO_MIME_BY_EXT[path.extname(String(fileName||'')).slice(1).toLowerCase()] || 'application/octet-stream'; }
  function audioScope(value) { return ['core','shared','campaign'].includes(value) ? value : 'campaign'; }
  function safeAudioFileName(value) { const name=path.basename(String(value||'')); return AUDIO_FILE_RE.test(name) ? name : null; }
  function audioSlug(value) { return String(value||'audio').replace(/\.[^.]+$/,'').replace(/[^A-Za-z0-9_.-]+/g,'_').replace(/^_+|_+$/g,'').slice(0,100)||'audio'; }
  function humanAudioName(fileName) {
    let base=path.basename(fileName,path.extname(fileName));
    base=base.replace(/^(?:music|ambient|effect)__+/i,'').replace(/__/g,' · ').replace(/[_.-]+/g,' ').trim();
    return base || 'Аудио';
  }
  function inferredAudioKind(fileName) {
    const base=path.basename(fileName,path.extname(fileName));
    if(/^music__+/i.test(base))return'music';
    if(/^ambient__+/i.test(base))return'ambient';
    return'effect';
  }
  function inferredDefaultBinding(fileName) {
    const base=path.basename(fileName,path.extname(fileName)).replace(/^effect__+/i,'').replace(/__/g,'.');
    return AUDIO_EFFECT_KEYS.includes(base) ? base : null;
  }
  function statAudioFile(folder,fileName) { try { return fs.statSync(path.join(folder,fileName)); } catch { return null; } }
  function normalizeExternalAudioItem(raw,index,scope,folder,urlPrefix) {
    const fileName=safeAudioFileName(raw?.fileName||raw?.file||raw?.name); if(!fileName)return null;
    const stat=statAudioFile(folder,fileName); if(!stat?.isFile())return null;
    const rawIdSource=raw?.id||path.basename(fileName,path.extname(fileName))||`audio${index+1}`;
    const idSource=String(rawIdSource).startsWith(`${scope}:`)?String(rawIdSource).slice(scope.length+1):rawIdSource;
    const localId=String(idSource).replace(/[^A-Za-z0-9_.-]+/g,'_').replace(/^_+|_+$/g,'').slice(0,100)||`audio${index+1}`;
    const id=`${scope}:${localId}`;
    return { id, name:cleanName(raw?.name,humanAudioName(fileName),180), kind:cleanAudioKind(raw?.kind||inferredAudioKind(fileName)), scope,
      fileName, url:`${urlPrefix}${encodeURIComponent(fileName)}`, mime:cleanText(raw?.mime||audioMimeForFile(fileName),100), size:stat.size,
      uploadedAt:raw?.uploadedAt||stat.mtime.toISOString(), readOnly:scope==='core', defaultBinding:AUDIO_EFFECT_KEYS.includes(raw?.defaultBinding)?raw.defaultBinding:inferredDefaultBinding(fileName) };
  }
  function scanCoreAudioLibrary() {
    fs.mkdirSync(CORE_AUDIO_DIR,{recursive:true});
    let manifest={items:[]}; try { if(fs.existsSync(CORE_AUDIO_MANIFEST))manifest=JSON.parse(fs.readFileSync(CORE_AUDIO_MANIFEST,'utf8')); } catch(error){ console.warn('Не удалось прочитать core-audio.json:',error.message); }
    const listed=new Set(),items=[];
    for(const [index,raw] of (Array.isArray(manifest?.items)?manifest.items:[]).entries()){
      const item=normalizeExternalAudioItem(raw,index,'core',CORE_AUDIO_DIR,'/assets/audio/core/'); if(!item)continue; listed.add(item.fileName); items.push(item);
    }
    for(const fileName of fs.readdirSync(CORE_AUDIO_DIR).filter(name=>AUDIO_FILE_RE.test(name)&&!listed.has(name)).sort()){
      const item=normalizeExternalAudioItem({fileName},items.length,'core',CORE_AUDIO_DIR,'/assets/audio/core/'); if(item)items.push(item);
    }
    const ids=new Set(); coreAudioLibrary=items.filter(item=>!ids.has(item.id)&&(ids.add(item.id),true)).slice(0,2000);
    coreDefaultEffectBindings={}; for(const item of coreAudioLibrary)if(item.defaultBinding&&!coreDefaultEffectBindings[item.defaultBinding])coreDefaultEffectBindings[item.defaultBinding]=item.id;
    return coreAudioLibrary;
  }
  function loadSharedAudioLibrary() {
    fs.mkdirSync(SHARED_AUDIO_DIR,{recursive:true});
    let raw=[]; try { if(fs.existsSync(SHARED_AUDIO_FILE)){const parsed=JSON.parse(fs.readFileSync(SHARED_AUDIO_FILE,'utf8'));raw=Array.isArray(parsed)?parsed:(Array.isArray(parsed?.library)?parsed.library:[]);} } catch(error){console.warn('Не удалось прочитать общую аудиобиблиотеку:',error.message);}
    const ids=new Set(); sharedAudioLibrary=raw.map((item,index)=>normalizeExternalAudioItem(item,index,'shared',SHARED_AUDIO_DIR,'/shared-audio/')).filter(item=>item&&!ids.has(item.id)&&(ids.add(item.id),true)).slice(0,2000);
    persistSharedAudioLibrarySync(); return sharedAudioLibrary;
  }
  function persistSharedAudioLibrarySync(){fs.mkdirSync(path.dirname(SHARED_AUDIO_FILE),{recursive:true});atomicWriteJsonSync(SHARED_AUDIO_FILE,{format:'fatum-shared-audio',version:1,library:sharedAudioLibrary.map(({readOnly,defaultBinding,...item})=>item)},2);}
  async function persistSharedAudioLibrary(){fs.mkdirSync(path.dirname(SHARED_AUDIO_FILE),{recursive:true});const temporary=`${SHARED_AUDIO_FILE}.tmp`;await fs.promises.writeFile(temporary,JSON.stringify({format:'fatum-shared-audio',version:1,library:sharedAudioLibrary.map(({readOnly,defaultBinding,...item})=>item)},null,2),'utf8');await fs.promises.rename(temporary,SHARED_AUDIO_FILE);}
  function refreshExternalAudioLibraries(){scanCoreAudioLibrary();loadSharedAudioLibrary();return combinedAudioLibrary();}
  function campaignAudioLibraryView(){
    return (state?.audio?.library||[]).map(item=>{
      const fileName=safeAudioFileName(item?.fileName||path.basename(String(item?.url||'')));
      const stat=fileName?statAudioFile(AUDIO_DIR,fileName):null;
      return {...item,available:Boolean(stat?.isFile()),size:stat?.isFile()?stat.size:Math.max(0,Number(item?.size||0)),mime:item?.mime||audioMimeForFile(fileName)};
    });
  }
  function combinedAudioLibrary(){return[...coreAudioLibrary,...sharedAudioLibrary,...campaignAudioLibraryView()];}
  function combinedAudioIds(){return new Set(combinedAudioLibrary().map(item=>item.id));}
  function audioItemById(id){return combinedAudioLibrary().find(item=>item.id===id)||null;}
  function audioStats(){const result={core:{count:0,size:0},shared:{count:0,size:0},campaign:{count:0,size:0}};for(const item of combinedAudioLibrary()){const scope=audioScope(item.scope);result[scope].count+=1;result[scope].size+=Math.max(0,Number(item.size||0));}return result;}
  function audioView(){const source=state?.audio||makeEmptyAudioState();return{...clone(source),library:clone(combinedAudioLibrary()),defaultEffectBindings:clone(coreDefaultEffectBindings),stats:audioStats()};}

  function normalizeAudioState(raw) {
    const base = makeEmptyAudioState();
    const library = (Array.isArray(raw?.library) ? raw.library : []).map((item, index) => ({
      id: cleanId(item?.id, makeId(`audio${index+1}`)),
      name: cleanName(item?.name, `Аудио ${index+1}`, 180),
      kind: cleanAudioKind(item?.kind), scope:'campaign',
      fileName: AUDIO_FILE_RE.test(String(item?.fileName||'')) ? String(item.fileName) : null,
      url: /^\/audio\/[A-Za-z0-9_.-]+\.(?:mp3|ogg|wav|webm|m4a|aac)$/i.test(String(item?.url||'')) ? String(item.url) : null,
      mime: cleanText(item?.mime || '', 100),
      size: Math.max(0, Math.round(safeNumber(item?.size, 0))),
      uploadedAt: item?.uploadedAt || nowIso(), readOnly:false
    })).filter(item => item.fileName && item.url).slice(0, 2000);
    const ids = new Set([...coreAudioLibrary,...sharedAudioLibrary,...library].map(item => item.id));
    const channels = {};
    for (const name of ['music','ambient']) {
      const source = raw?.channels?.[name] || {};
      channels[name] = {
        trackId: ids.has(cleanId(source.trackId, null)) ? cleanId(source.trackId, null) : null,
        playing: Boolean(source.playing), position: Math.max(0, safeNumber(source.position, 0)), startedAt: source.startedAt || null,
        volume: clamp(safeNumber(source.volume, base.channels[name].volume), 0, 1), loop: source.loop !== false, updatedAt: source.updatedAt || nowIso()
      };
      if (!channels[name].trackId) { channels[name].playing = false; channels[name].position = 0; channels[name].startedAt = null; }
    }
    const effectBindings = { ...base.effectBindings };
    for (const key of AUDIO_EFFECT_KEYS) {
      const rawValue=raw?.effectBindings?.[key];
      if(rawValue==='off')effectBindings[key]='off';
      else{const value=cleanId(rawValue,null);effectBindings[key]=ids.has(value)?value:null;}
    }
    return { library, channels, effectBindings };
  }

  function makeEmptyBattlemap() {
    return {
      format: 'fatum-battlemap',
      version: 10,
      tableLog: [],
      tokenGroups: [],
      activeSceneId: null,
      combat: { active: false, sceneId: null, participantTokenIds: [], startedAt: null, movement: {} },
      audio: makeEmptyAudioState(),
      // v1.5.1: время суток является параметром всего стола, а не отдельной сцены.
      daylight: { dayPhase: 1, daylightEnabled: true },
      masterPause: { active:false, reason:'', activatedAt:null },
      updatedAt: nowIso(),
      scenes: []
    };
  }

  function cleanColor(value, fallback = '#ffd88a') {
    const text = String(value || '').trim();
    return /^#[0-9a-f]{6}$/i.test(text) ? text : fallback;
  }

  function validAssetUrl(value, kind = null) {
    if (typeof value !== 'string') return null;
    const text = value.trim();
    const allowed = kind === 'map' ? '/maps/' : kind === 'token' ? '/tokens/' : kind === 'audio' ? '/audio/' : null;
    if (allowed && !text.startsWith(allowed)) return null;
    if (!/^\/(?:maps|tokens|portraits|audio)\/[A-Za-z0-9_.-]+$/.test(text)) return null;
    return text;
  }

  function normalizeGrid(raw) {
    return {
      enabled: raw?.enabled !== false,
      size: clamp(Math.round(safeNumber(raw?.size, 70)), 10, 500),
      feet: clamp(safeNumber(raw?.feet, 5), 0.25, 100),
      offsetX: clamp(safeNumber(raw?.offsetX, 0), -5000, 5000),
      offsetY: clamp(safeNumber(raw?.offsetY, 0), -5000, 5000),
      snap: raw?.snap !== false,
      color: cleanColor(raw?.color, '#8aa0b8'),
      opacity: clamp(safeNumber(raw?.opacity, 0.28), 0, 1)
    };
  }

  function normalizeSceneSettings(raw) {
    const fogMode = ['off', 'manual', 'vision', 'hybrid'].includes(raw?.fogMode) ? raw.fogMode : 'vision';
    return {
      fogMode,
      fogEnabled: raw?.fogEnabled !== false,
      visionEnabled: raw?.visionEnabled !== false,
      dynamicLightEnabled: raw?.dynamicLightEnabled !== false,
      globalIllumination: Boolean(raw?.globalIllumination),
      masterSeesLighting: raw?.masterSeesLighting !== false,
      ambientDarkness: clamp(safeNumber(raw?.ambientDarkness, 0.82), 0, 1),
      dayPhase: clamp(safeNumber(raw?.dayPhase, 1), 0, 1),
      daylightEnabled: raw?.daylightEnabled !== false,
      playerCanPing: raw?.playerCanPing !== false,
      playerCanDraw: raw?.playerCanDraw !== false,
      playerCanMeasure: raw?.playerCanMeasure !== false,
      playerCanMoveOwned: raw?.playerCanMoveOwned !== false,
      showGridToPlayers: raw?.showGridToPlayers !== false,
      enforceWalls: raw?.enforceWalls !== false,
      exploredMemory: raw?.exploredMemory !== false,
      elevationRulesEnabled: raw?.elevationRulesEnabled !== false,
      showZoneFireLinesMaster: Boolean(raw?.showZoneFireLinesMaster),
      showZoneFireLinesPlayers: Boolean(raw?.showZoneFireLinesPlayers),
      // Explicit mechanical switch. Weather layers remain visual unless the GM
      // enables this, so old scenes do not silently gain attack hindrance.
      badVisibility: Boolean(raw?.badVisibility)
    };
  }

  function normalizeGlobalDaylight(raw, fallbackSettings = null) {
    const fallback = fallbackSettings || {};
    return {
      dayPhase: clamp(safeNumber(raw?.dayPhase, fallback.dayPhase ?? 1), 0, 1),
      daylightEnabled: raw?.daylightEnabled !== undefined ? raw.daylightEnabled !== false : fallback.daylightEnabled !== false
    };
  }

  function applyGlobalDaylight(raw) {
    const fallback = state?.scenes?.find(scene => scene.id === state.activeSceneId)?.settings || state?.scenes?.[0]?.settings || null;
    state.daylight = normalizeGlobalDaylight({ ...(state?.daylight || {}), ...(raw || {}) }, fallback);
    const stamp = nowIso();
    for (const scene of state?.scenes || []) {
      scene.settings = normalizeSceneSettings({ ...scene.settings, ...state.daylight });
      scene.updatedAt = stamp;
    }
    return state.daylight;
  }

  function normalizeVision(raw) {
    return {
      enabled: raw?.enabled !== false,
      range: clamp(safeNumber(raw?.range, 60), 0, 2000),
      angle: clamp(safeNumber(raw?.angle, 360), 1, 360),
      darkvision: clamp(safeNumber(raw?.darkvision, 0), 0, 2000)
    };
  }

  const LIGHT_BLEND_MODES = new Set(['source-over','screen','overlay','soft-light','hard-light','lighter','color-dodge','multiply']);
  function normalizeLightBlendMode(value) { return LIGHT_BLEND_MODES.has(value) ? value : 'source-over'; }

  function normalizeLight(raw) {
    return {
      enabled: Boolean(raw?.enabled),
      bright: clamp(safeNumber(raw?.bright, 20), 0, 2000),
      dim: clamp(safeNumber(raw?.dim, 40), 0, 3000),
      angle: clamp(safeNumber(raw?.angle, 360), 1, 360),
      color: cleanColor(raw?.color, '#ffd88a'),
      intensity: clamp(safeNumber(raw?.intensity, 1), 0.05, 2),
      flicker: clamp(safeNumber(raw?.flicker, 0), 0, 1),
      flickerSpeed: clamp(safeNumber(raw?.flickerSpeed, 1.5), 0.1, 12),
      blendMode: normalizeLightBlendMode(raw?.blendMode)
    };
  }

  function normalizeVehicleWeapon(raw, index = 0) {
    const source = raw && typeof raw === 'object' ? raw : {};
    const hitDie = normalizeDie(source.hitDie || source.hitDieNormal, '1d6');
    const hitDieAimed = source.hitDieAimed ? normalizeDie(source.hitDieAimed, '') : '';
    return {
      id: cleanId(source.id, makeId(`vehicle-weapon${index + 1}`)),
      name: cleanName(source.name, `Установленное оружие ${index + 1}`),
      profile: cleanText(source.profile || source.name || 'Установленное оружие', 160),
      category: 'ranged',
      type: cleanText(source.type, 120) || 'Установленное оружие',
      melee: false,
      vehicleMounted: true,
      hitDie,
      hitDieNormal: hitDie,
      hitDieAimed,
      damage: clamp(Math.round(safeNumber(source.damage, 2)), 0, 30),
      damageTag: ['light','medium','heavy'].includes(source.damageTag) ? source.damageTag : 'medium',
      odCost: clamp(Math.round(safeNumber(source.odCost, 2)), 0, 10),
      aimedOdCost: hitDieAimed ? clamp(Math.round(safeNumber(source.aimedOdCost, safeNumber(source.odCost, 2) + 1)), 0, 10) : null,
      obCost: clamp(Math.round(safeNumber(source.obCost, 0)), 0, 20),
      threshold: clamp(Math.round(safeNumber(source.threshold, 0)), 0, 6),
      reloadCost: clamp(Math.round(safeNumber(source.reloadCost, 2)), 0, 10),
      minimumSafeRange: clamp(Math.round(safeNumber(source.minimumSafeRange, 20)), 0, 1000),
      range: clamp(Math.round(safeNumber(source.range, 150)), 1, 5000),
      radius: clamp(Math.round(safeNumber(source.radius, 0)), 0, 1000),
      ignoreMz: clamp(Math.round(safeNumber(source.ignoreMz, 0)), 0, 20),
      modificationsActive: source.modificationsActive !== false,
      bonusMode: 'manual',
      operatorTrainingMode: source.operatorTrainingMode === 'operator' ? 'operator' : 'manual',
      manualBonus: clamp(Math.round(safeNumber(source.manualBonus, source.hitBonus || 0)), -20, 30),
      hitBonus: clamp(Math.round(safeNumber(source.manualBonus, source.hitBonus || 0)), -20, 30),
      slotCost: clamp(Math.round(safeNumber(source.slotCost, 1)), 1, 20),
      projectileKind: ['bullet','shotgun','launcher','anaxion'].includes(source.projectileKind) ? source.projectileKind : 'bullet',
      soundId: source.soundId === 'off' ? 'off' : cleanId(source.soundId, null),
      properties: (Array.isArray(source.properties) ? source.properties : String(source.properties || '').split(',')).map(item => cleanText(item, 80).trim()).filter(Boolean).slice(0, 20),
      description: cleanText(source.description, 3000),
      enabled: source.enabled !== false
    };
  }

  function vehicleSeatRole(vehicle, tokenId) {
    const seat = vehicle?.vehicle?.seatAssignments?.[tokenId];
    if (seat && typeof seat === 'object') return seat.role || 'passenger';
    if (typeof seat === 'string') return seat;
    if (vehicle?.vehicle?.driverTokenId === tokenId) return 'driver';
    return vehicle?.vehicle?.occupants?.includes(tokenId) ? 'passenger' : null;
  }

  function normalizeVehicle(raw, fallbackName = 'Транспорт') {
    const profileId = Object.prototype.hasOwnProperty.call(VEHICLE_PROFILES, raw?.profileId) ? raw.profileId : null;
    const base = profileId ? VEHICLE_PROFILES[profileId] : {};
    const hullMax = clamp(Math.round(safeNumber(raw?.hullMax, base.hull || 5)), 1, 999);
    const armor = ['none','light','medium','heavy'].includes(raw?.armor) ? raw.armor : (base.armor || 'none');
    const occupants = [...new Set((Array.isArray(raw?.occupants) ? raw.occupants : []).map(value => cleanId(value, null)).filter(Boolean))].slice(0, 64);
    const bzMax = clamp(Math.round(safeNumber(raw?.bzMax, base.bz || 0)), 0, 999);
    const crew = clamp(Math.round(safeNumber(raw?.crew, base.crew || 1)), 0, 100);
    const passengerCapacity = clamp(Math.round(safeNumber(raw?.passengerCapacity, base.passengers || 0)), 0, 100);
    const gunnerCapacity = clamp(Math.round(safeNumber(raw?.gunnerCapacity, Math.max(0, crew - 1))), 0, 100);
    const slots = clamp(Math.round(safeNumber(raw?.slots, base.slots || 0)), 0, 100);
    const mountedWeapons = (Array.isArray(raw?.mountedWeapons) ? raw.mountedWeapons : []).slice(0, 30).map((weapon, index) => normalizeVehicleWeapon(weapon, index));
    const rawMountedWeaponStates = raw?.mountedWeaponStates && typeof raw.mountedWeaponStates === 'object' && !Array.isArray(raw.mountedWeaponStates) ? raw.mountedWeaponStates : {};
    const mountedWeaponStates = {};
    for (const weapon of mountedWeapons) {
      if (Math.max(0, Math.round(safeNumber(weapon.reloadCost, 0))) <= 0 && weapon.type !== 'Тяжёлое') continue;
      const previous = rawMountedWeaponStates[weapon.id];
      mountedWeaponStates[weapon.id] = { loaded: previous?.loaded !== false };
    }
    const rawAssignments = raw?.seatAssignments && typeof raw.seatAssignments === 'object' && !Array.isArray(raw.seatAssignments) ? raw.seatAssignments : {};
    const seatAssignments = {};
    let driverTokenId = occupants.includes(cleanId(raw?.driverTokenId, null)) ? cleanId(raw.driverTokenId, null) : null;
    for (const occupantId of occupants) {
      const value = rawAssignments[occupantId];
      let role = typeof value === 'string' ? value : value?.role;
      if (!['driver','gunner','passenger'].includes(role)) role = occupantId === driverTokenId ? 'driver' : 'passenger';
      if (role === 'driver') {
        if (driverTokenId && driverTokenId !== occupantId) role = 'passenger';
        else driverTokenId = occupantId;
      }
      seatAssignments[occupantId] = { role };
    }
    if (!driverTokenId && occupants.length && !Object.keys(rawAssignments).length) {
      driverTokenId = occupants[0];
      seatAssignments[driverTokenId] = { role:'driver' };
    }
    return {
      profileId,
      profileName: cleanName(raw?.profileName, base.name || fallbackName),
      environment: ['ground','water','air'].includes(raw?.environment) ? raw.environment : (base.environment || 'ground'),
      speed: clamp(Math.round(safeNumber(raw?.speed, base.speed || 1)), 0, 20),
      zoneFeet: clamp(safeNumber(raw?.zoneFeet, 60), 10, 2000),
      maneuver: clamp(Math.round(safeNumber(raw?.maneuver, base.maneuver || 0)), -20, 20),
      mz: clamp(Math.round(safeNumber(raw?.mz, base.mz || 4)), 0, 30),
      coverMz: clamp(Math.round(safeNumber(raw?.coverMz, 0)), 0, 30),
      hullMax,
      hullCurrent: clamp(Math.round(safeNumber(raw?.hullCurrent, hullMax)), 0, hullMax),
      armor,
      bzMax,
      bzCurrent: clamp(Math.round(safeNumber(raw?.bzCurrent, bzMax)), 0, bzMax),
      crew,
      gunnerCapacity,
      passengerCapacity,
      cargo: clamp(Math.round(safeNumber(raw?.cargo, base.cargo || 0)), 0, 1000),
      slots,
      mountedWeapons,
      mountedWeaponStates,
      occupants,
      seatAssignments,
      driverTokenId,
      movedRound: Math.max(0, Math.round(safeNumber(raw?.movedRound, 0))),
      stabilizedRound: Math.max(0, Math.round(safeNumber(raw?.stabilizedRound, 0))),
      stabilizedUntilDriverTurn: Boolean(raw?.stabilizedUntilDriverTurn),
      roughUntilDriverTurn: Boolean(raw?.roughUntilDriverTurn),
      evasiveUntilDriverTurn: Boolean(raw?.evasiveUntilDriverTurn),
      sharpManeuverRound: Math.max(0, Math.round(safeNumber(raw?.sharpManeuverRound, 0))),
      height: ['low','medium','high'].includes(raw?.height) ? raw.height : 'low',
      notes: cleanText(raw?.notes, 2000)
    };
  }

  function normalizeAudioSource(raw, index = 0) {
    return {
      id: cleanId(raw?.id, makeId(`audiosource${index + 1}`)),
      name: cleanName(raw?.name, `Аудио-объект ${index + 1}`),
      trackId: cleanId(raw?.trackId, null),
      x: clamp(safeNumber(raw?.x, 0), -100000, 100000),
      y: clamp(safeNumber(raw?.y, 0), -100000, 100000),
      radius: clamp(safeNumber(raw?.radius, 60), 1, 5000),
      volume: clamp(safeNumber(raw?.volume, .8), 0, 1),
      falloff: ['soft','linear','sharp'].includes(raw?.falloff) ? raw.falloff : 'soft',
      loop: raw?.loop !== false,
      enabled: raw?.enabled !== false,
      hidden: Boolean(raw?.hidden)
    };
  }

  function normalizeWeatherLayer(raw, index = 0) {
    const type = ['fog','dust','rain','snow'].includes(raw?.type) ? raw.type : 'fog';
    const fallbackColor = type === 'dust' ? '#b99162' : type === 'rain' ? '#96b8d4' : type === 'snow' ? '#e8f2fb' : '#b8c0c8';
    return {
      id: cleanId(raw?.id, makeId(`weather${index + 1}`)),
      name: cleanName(raw?.name, ({fog:'Туман',dust:'Пылевая буря',rain:'Дождь',snow:'Снег'})[type] || `Погода ${index + 1}`),
      type,
      enabled: raw?.enabled !== false,
      opacity: clamp(safeNumber(raw?.opacity, type === 'fog' ? .42 : .34), 0, .95),
      density: clamp(safeNumber(raw?.density, 1), .1, 2.5),
      speed: clamp(safeNumber(raw?.speed, type === 'fog' ? .35 : 1), 0, 4),
      direction: ((safeNumber(raw?.direction, type === 'rain' ? 105 : 15) % 360) + 360) % 360,
      scale: clamp(safeNumber(raw?.scale, 1), .2, 3),
      color: cleanColor(raw?.color, fallbackColor),
      soundTrackId: cleanId(raw?.soundTrackId, null),
      soundVolume: clamp(safeNumber(raw?.soundVolume, .55), 0, 1),
      soundEnabled: Boolean(raw?.soundEnabled)
    };
  }

  function normalizeParallaxLayer(raw, index = 0, scene = null) {
    const placement = raw?.placement === 'ground' ? 'ground' : 'overhead';
    const blendMode = ['source-over','multiply','screen','overlay','soft-light'].includes(raw?.blendMode) ? raw.blendMode : 'source-over';
    const fallbackWidth = Math.max(1, safeNumber(scene?.mapWidth, 1920));
    const fallbackHeight = Math.max(1, safeNumber(scene?.mapHeight, 1080));
    return {
      id: cleanId(raw?.id, makeId(`parallax${index + 1}`)),
      name: cleanName(raw?.name, `Слой ${index + 1}`, 120),
      imageUrl: validAssetUrl(raw?.imageUrl, 'map') || null,
      enabled: raw?.enabled !== false,
      showToPlayers: raw?.showToPlayers !== false,
      placement,
      depth: clamp(safeNumber(raw?.depth, placement === 'overhead' ? 1 : -0.35), -3, 3),
      opacity: clamp(safeNumber(raw?.opacity, 1), 0, 1),
      x: clamp(safeNumber(raw?.x, 0), -100000, 100000),
      y: clamp(safeNumber(raw?.y, 0), -100000, 100000),
      width: clamp(Math.abs(safeNumber(raw?.width, fallbackWidth)), 1, 100000),
      height: clamp(Math.abs(safeNumber(raw?.height, fallbackHeight)), 1, 100000),
      blendMode,
      shadow: Boolean(raw?.shadow),
      shadowOpacity: clamp(safeNumber(raw?.shadowOpacity, .32), 0, .9),
      shadowBlur: clamp(safeNumber(raw?.shadowBlur, 10), 0, 80),
      shadowOffsetY: clamp(safeNumber(raw?.shadowOffsetY, 8), -100, 100),
      fadeUnderToken: placement === 'overhead' && (raw?.fadeUnderToken !== undefined ? Boolean(raw.fadeUnderToken) : Boolean(raw?.roofOcclusion)),
      roofOcclusion: placement === 'overhead' && (raw?.roofOcclusion !== undefined ? Boolean(raw.roofOcclusion) : Boolean(raw?.fadeUnderToken)),
      fadeOpacity: clamp(safeNumber(raw?.fadeOpacity, .22), 0, 1),
      fadeRadius: clamp(safeNumber(raw?.fadeRadius, 1.15), .25, 6)
    };
  }

  function normalizeParallaxObject(raw, index = 0, scene = null) {
    const validTypes = ['roof','canopy','low','high','elevation','custom'];
    const type = validTypes.includes(raw?.type) ? raw.type : 'custom';
    const placement = raw?.placement === 'ground' ? 'ground' : 'overhead';
    const fallbackColor = type === 'roof' ? '#29251d' : type === 'canopy' ? '#243125' : '#252821';
    const points = (Array.isArray(raw?.points) ? raw.points : []).slice(0, 160).map(point => ({
      x: clamp(safeNumber(point?.x, 0), -100000, 100000),
      y: clamp(safeNumber(point?.y, 0), -100000, 100000)
    }));
    return {
      id: cleanId(raw?.id, makeId(`parallax-object${index + 1}`)),
      name: cleanName(raw?.name, `2.5D объект ${index + 1}`, 120),
      type,
      enabled: raw?.enabled !== false,
      showToPlayers: raw?.showToPlayers !== false,
      placement,
      points,
      height: clamp(safeNumber(raw?.height, type === 'low' ? 12 : type === 'canopy' ? 44 : type === 'high' ? 48 : type === 'roof' ? 36 : 28), 0, 160),
      parallax: clamp(safeNumber(raw?.parallax, 1), 0, 2.5),
      opacity: clamp(safeNumber(raw?.opacity, 1), 0, 1),
      shadow: raw?.shadow !== false,
      shadowOpacity: clamp(safeNumber(raw?.shadowOpacity, .34), 0, .9),
      sideOpacity: clamp(safeNumber(raw?.sideOpacity, .52), 0, .95),
      fadeWhenInside: placement === 'overhead' && (raw?.fadeWhenInside !== undefined ? Boolean(raw.fadeWhenInside) : (Boolean(raw?.roofOcclusion) || type === 'roof')),
      roofOcclusion: placement === 'overhead' && (raw?.roofOcclusion !== undefined ? Boolean(raw.roofOcclusion) : type === 'roof'),
      fadeOpacity: clamp(safeNumber(raw?.fadeOpacity, type === 'canopy' ? .28 : .18), 0, 1),
      underlayMode: ['darken','fill','none'].includes(raw?.underlayMode) ? raw.underlayMode : (type === 'roof' ? 'fill' : 'darken'),
      underlayColor: cleanColor(raw?.underlayColor, fallbackColor)
    };
  }

  function normalizeParallax(raw, scene = null) {
    const config = raw && typeof raw === 'object' ? raw : {};
    return {
      enabled: config.enabled === true,
      strength: clamp(safeNumber(config.strength, .35), 0, 1.5),
      maxShift: clamp(safeNumber(config.maxShift, 18), 0, 96),
      layers: (Array.isArray(config.layers) ? config.layers : [])
        .map((layer, index) => normalizeParallaxLayer(layer, index, scene))
        .filter(layer => layer.imageUrl)
        .slice(0, MAX_PARALLAX_LAYERS),
      objects: (Array.isArray(config.objects) ? config.objects : [])
        .map((object, index) => normalizeParallaxObject(object, index, scene))
        .filter(object => object.points.length >= 3)
        .slice(0, MAX_PARALLAX_OBJECTS)
    };
  }

  function normalizeElevationZone(raw, index = 0) {
    const level = raw?.level === 'very-high' ? 'very-high' : 'high';
    return {
      id: cleanId(raw?.id, makeId(`height${index + 1}`)),
      name: cleanName(raw?.name, level === 'very-high' ? `Очень высоко ${index + 1}` : `Высоко ${index + 1}`),
      level, x:clamp(safeNumber(raw?.x,0),-100000,100000), y:clamp(safeNumber(raw?.y,0),-100000,100000),
      width:clamp(safeNumber(raw?.width,100),-100000,100000), height:clamp(safeNumber(raw?.height,100),-100000,100000),
      color:cleanColor(raw?.color, level === 'very-high' ? '#b88cff' : '#62b8e8'),
      opacity:clamp(safeNumber(raw?.opacity,.18),.03,.65), showToPlayers:raw?.showToPlayers !== false
    };
  }
  const TRIGGER_EFFECTS = ['none','wound','morale-loss','morale-gain','heal','trauma','start-combat'];
  const TRAUMA_DEFINITIONS = Object.freeze({
    'Перелом черепа': { roll:1, desc:'−2 к инициативе, −4 к проверкам Концентрации, −5 к базовой морали. Лечение: хирургический набор; 3 привала с ним или 2 привала с квалифицированной помощью (Медик).' },
    'Повреждённое колено': { roll:2, desc:'Скорость −10 футов, невозможно совершать Прыжки и Рывки. Лечение: медицинский набор или аптечка; 1 привал.' },
    'Трещина в ребре': { roll:3, desc:'−1 ОД, −3 к проверкам Выносливости. Каждый Рывок или Прыжок наносит 1 Лёгкое ранение. Лечение: медицинский набор или аптечка; 2 привала.' },
    'Выбитое плечо': { roll:4, desc:'−2 к попаданию, −2 к проверкам Силы. Лечение: вправление (проверка Медицины), затем медицинский набор; 1 привал.' },
    'Сломанная рука': { roll:5, desc:'Невозможно использовать двуручное оружие; −2 к проверкам Силы и Ловкости, связанным с руками. Лечение: шина и бинты; 2 привала с медицинским набором.' },
    'Рваная рана': { roll:6, desc:'−2 ко всем проверкам из-за кровопотери. Лечение: перевязка (бинты или аптечка); полное восстановление через 2 привала.' },
    'Повреждённый глаз': { roll:7, desc:'−3 к проверкам Меткости и к попаданию; дальность стрельбы −30 футов. Лечение: медицинский набор; 2 привала.' },
    'Разрыв сухожилия': { roll:8, desc:'−3 к проверкам Ловкости; Скорость −5 футов. Лечение: медицинский набор; 2 привала.' },
    'Кровоизлияние в лёгкие': { roll:9, desc:'−3 к проверкам Выносливости, −2 к морали. Лечение: хирургический набор; 3 привала с ним.' },
    'Потеря конечности': { roll:10, desc:'Рука: −4 ко всем проверкам рук и невозможность использовать двуручное оружие. Нога: Скорость 15 футов, невозможны Прыжки, Рывки и стрельба стоя. Пальцы: −2 к проверкам рук и точным механизмам. Полное восстановление невозможно; протезирование снижает штрафы вдвое.' }
  });
  const LEGACY_TRAUMA_NAMES = Object.freeze({
    'Повреждённая нога':'Повреждённое колено','Сотрясение':'Перелом черепа','Повреждение глаза':'Повреждённый глаз','Глубокий шрам':'Рваная рана',
    'Потеря руки':'Потеря конечности','Потеря ноги':'Потеря конечности','Потеря пальцев':'Потеря конечности'
  });
  const LOST_LIMB_NAME_VARIANTS = Object.freeze({'Потеря руки':'arm','Потеря ноги':'leg','Потеря пальцев':'fingers'});
  function canonicalTraumaName(value) {
    const raw=cleanText(value,120), mapped=LEGACY_TRAUMA_NAMES[raw]||raw;
    return TRAUMA_DEFINITIONS[mapped] ? mapped : 'Перелом черепа';
  }
  function canonicalTraumaVariant(nameValue, variantValue=null) {
    const raw=cleanText(nameValue,120);
    if(LOST_LIMB_NAME_VARIANTS[raw])return LOST_LIMB_NAME_VARIANTS[raw];
    return ['arm','leg','fingers'].includes(variantValue)?variantValue:'arm';
  }
  function traumaItemVariant(item){
    if(!item)return null;const direct=LOST_LIMB_NAME_VARIANTS[cleanText(item.name,120)];
    if(direct)return direct;return canonicalTraumaName(item.name)==='Потеря конечности'?canonicalTraumaVariant(item.name,item.variant):null;
  }
  function traumaItemProsthesis(item){return Boolean(item?.prosthesis||item?.prosthetic||item?.prosthesisInstalled);}
  function traumaItemPenaltyScale(item){return traumaItemProsthesis(item)?.5:1;}
  function normalizeTriggerZone(raw, index = 0) {
    const effectType = TRIGGER_EFFECTS.includes(raw?.effectType) ? raw.effectType : 'none';
    const applyWhen = ['failure','success','always'].includes(raw?.applyWhen) ? raw.applyWhen : 'failure';
    const rawTraumaName=raw?.traumaName||raw?.traumaText||'Перелом черепа',traumaName=canonicalTraumaName(rawTraumaName);
    return {
      id:cleanId(raw?.id,makeId(`trigger${index+1}`)), name:cleanName(raw?.name,`Зона проверки ${index+1}`),
      x:clamp(safeNumber(raw?.x,0),-100000,100000), y:clamp(safeNumber(raw?.y,0),-100000,100000),
      width:clamp(safeNumber(raw?.width,100),-100000,100000), height:clamp(safeNumber(raw?.height,100),-100000,100000),
      skillName:cleanName(raw?.skillName,'Бдительность',80), difficultySides:[4,6,8,10,12].includes(Number(raw?.difficultySides))?Number(raw.difficultySides):8,
      difficultyModifier:clamp(Math.round(safeNumber(raw?.difficultyModifier,0)),-20,30), effectType, applyWhen,
      effectValue:clamp(Math.round(safeNumber(raw?.effectValue,1)),0,999), woundType:['light','medium','serious','critical'].includes(raw?.woundType)?raw.woundType:'light',
      traumaName, traumaVariant:traumaName==='Потеря конечности'?canonicalTraumaVariant(rawTraumaName,raw?.traumaVariant):'arm',
      traumaText:traumaName, pauseOnTrigger:Boolean(raw?.pauseOnTrigger), oneShot:Boolean(raw?.oneShot),
      combatTriggerMode:['automatic','check'].includes(raw?.combatTriggerMode)?raw.combatTriggerMode:'automatic',
      combatTokenIds:[...new Set((Array.isArray(raw?.combatTokenIds)?raw.combatTokenIds:[]).map(v=>cleanId(v,null)).filter(Boolean))].slice(0,MAX_TOKENS),
      showToPlayers:Boolean(raw?.showToPlayers), color:cleanColor(raw?.color,'#d99754'), opacity:clamp(safeNumber(raw?.opacity,.16),.03,.65),
      insideTokenIds:[...new Set((Array.isArray(raw?.insideTokenIds)?raw.insideTokenIds:[]).map(v=>cleanId(v,null)).filter(Boolean))].slice(0,MAX_TOKENS)
    };
  }

  function normalizeDrawing(raw, index = 0) {
    const points = (Array.isArray(raw?.points) ? raw.points : []).slice(0, MAX_DRAWING_POINTS)
      .filter(point => Number.isFinite(Number(point?.x)) && Number.isFinite(Number(point?.y)))
      .map(point => ({
        x: clamp(Number(point.x), -100000, 100000),
        y: clamp(Number(point.y), -100000, 100000)
      }));
    return {
      id: cleanId(raw?.id, makeId(`drawing${index + 1}`)),
      points,
      color: cleanColor(raw?.color, '#ffd36a'),
      width: clamp(safeNumber(raw?.width, 5), 1, 40),
      opacity: clamp(safeNumber(raw?.opacity, .9), .1, 1),
      authorId: cleanId(raw?.authorId, null),
      authorName: cleanName(raw?.authorName, 'Участник'),
      createdAt: raw?.createdAt || nowIso()
    };
  }


  function normalizeMapWidget(raw, index = 0) {
    const type = raw?.type === 'marker' ? 'marker' : 'counter';
    const icon = ['objective','danger','info','flag','medical','pin'].includes(raw?.icon) ? raw.icon : 'objective';
    return {
      id: cleanId(raw?.id, makeId(`widget${index + 1}`)),
      type,
      name: cleanName(raw?.name, type === 'marker' ? `Маркер ${index + 1}` : `Счётчик ${index + 1}`, 120),
      description: cleanText(raw?.description || '', 1200),
      x: clamp(safeNumber(raw?.x, 0), -100000, 100000),
      y: clamp(safeNumber(raw?.y, 0), -100000, 100000),
      size: clamp(safeNumber(raw?.size, 1), .25, 8),
      value: clamp(Math.round(safeNumber(raw?.value, 0)), -999999, 999999),
      step: clamp(Math.max(1, Math.round(Math.abs(safeNumber(raw?.step, 1)))), 1, 99999),
      color: cleanColor(raw?.color, type === 'marker' ? '#ffd36a' : '#62d8ff'),
      icon,
      imageUrl: validAssetUrl(raw?.imageUrl, 'token') || null,
      showToPlayers: raw?.showToPlayers !== false,
      createdAt: raw?.createdAt || nowIso()
    };
  }

  function normalizeNarrativeControl(raw) {
    const condition = value => ['normal','advantage','hindrance'].includes(value) ? value : 'normal';
    return {
      attackCondition: condition(raw?.attackCondition),
      attackBonus: clamp(Math.round(safeNumber(raw?.attackBonus, 0)), -20, 20),
      damageBonus: clamp(Math.round(safeNumber(raw?.damageBonus, 0)), -20, 20),
      defenseCondition: condition(raw?.defenseCondition),
      defenseBonus: clamp(Math.round(safeNumber(raw?.defenseBonus, 0)), -20, 20),
      checkCondition: condition(raw?.checkCondition),
      checkBonus: clamp(Math.round(safeNumber(raw?.checkBonus, 0)), -20, 20),
      note: cleanText(raw?.note || '', 300)
    };
  }

  function normalizeAiControl(raw) {
    const lastSeen = {};
    if (raw?.lastSeen && typeof raw.lastSeen === 'object' && !Array.isArray(raw.lastSeen)) {
      for (const [tokenId, memory] of Object.entries(raw.lastSeen)) {
        const id=cleanId(tokenId,null);if(!id||!memory)continue;
        lastSeen[id]={x:clamp(safeNumber(memory.x,0),-100000,100000),y:clamp(safeNumber(memory.y,0),-100000,100000),round:Math.max(0,Math.round(safeNumber(memory.round,0))),sceneId:cleanId(memory.sceneId,null)};
      }
    }
    const roles=['auto','rifleman','assault','sniper','gunner','grenadier','defender','medic','commander','scout','monster'];
    const rawPlan=raw?.plan&&typeof raw.plan==='object'&&!Array.isArray(raw.plan)?raw.plan:null;
    const plan=rawPlan&&Number.isFinite(Number(rawPlan.x))&&Number.isFinite(Number(rawPlan.y))?{
      type:['position','retreat','medic','search'].includes(rawPlan.type)?rawPlan.type:'position',
      x:clamp(safeNumber(rawPlan.x,0),-100000,100000),
      y:clamp(safeNumber(rawPlan.y,0),-100000,100000),
      targetId:cleanId(rawPlan.targetId,null),
      sceneId:cleanId(rawPlan.sceneId,null),
      createdRound:Math.max(0,Math.round(safeNumber(rawPlan.createdRound,0))),
      expiresRound:Math.max(0,Math.round(safeNumber(rawPlan.expiresRound,0)))
    }:null;
    return {
      enabled: Boolean(raw?.enabled),
      autoRun: raw?.autoRun !== false,
      profile: ['balanced','aggressive','defensive','support'].includes(raw?.profile) ? raw.profile : 'balanced',
      role: roles.includes(raw?.role) ? raw.role : 'auto',
      preferCover: raw?.preferCover !== false,
      useGrenades: raw?.useGrenades !== false,
      useSpecials: raw?.useSpecials !== false,
      lastSeen,
      plan,
      stationaryTurns: clamp(Math.round(safeNumber(raw?.stationaryTurns,0)),0,99),
      searchStep: clamp(Math.round(safeNumber(raw?.searchStep,0)),0,9999),
      lastPosition: raw?.lastPosition&&Number.isFinite(Number(raw.lastPosition.x))&&Number.isFinite(Number(raw.lastPosition.y))?{x:safeNumber(raw.lastPosition.x,0),y:safeNumber(raw.lastPosition.y,0)}:null
    };
  }
  function normalizeGroupRelations(raw) {
    const result = {};
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return result;
    for (const [key, value] of Object.entries(raw)) {
      const id = cleanId(key, null);
      if (id && ['ally','enemy','neutral'].includes(value)) result[id] = value;
    }
    return result;
  }

  function normalizeTokenGroup(raw, index = 0) {
    return {
      id: cleanId(raw?.id, makeId(`group${index + 1}`)),
      name: cleanName(raw?.name, `Группа ${index + 1}`),
      color: cleanColor(raw?.color, '#d64b4b'),
      moraleOnDeath: raw?.moraleOnDeath !== false,
      relations: normalizeGroupRelations(raw?.relations),
      updatedAt: raw?.updatedAt || nowIso()
    };
  }

  function normalizeInteractiveObject(raw, fallbackName = 'Интерактивный объект') {
    const objectType = ['explosive','hazard','cover','mixed'].includes(raw?.objectType) ? raw.objectType : 'explosive';
    const explosionEnabled = raw?.explosionEnabled !== undefined ? Boolean(raw.explosionEnabled) : ['explosive','mixed'].includes(objectType);
    const zoneEnabled = raw?.zoneEnabled !== undefined ? Boolean(raw.zoneEnabled) : ['hazard','mixed'].includes(objectType);
    const coverMzDefault = objectType === 'cover' ? 7 : 0;
    return {
      objectType,
      active: raw?.active !== false,
      triggered: Boolean(raw?.triggered),
      triggerOnShot: raw?.triggerOnShot !== false,
      removeAfterTrigger: Boolean(raw?.removeAfterTrigger),
      coverMz: clamp(Math.round(safeNumber(raw?.coverMz, coverMzDefault)), 0, 30),
      explosionEnabled,
      explosionRadius: clamp(safeNumber(raw?.explosionRadius, 10), 1, 5000),
      explosionDamage: clamp(Math.round(safeNumber(raw?.explosionDamage, 3)), 0, 30),
      explosionDamageTag: ['light','medium','heavy'].includes(raw?.explosionDamageTag) ? raw.explosionDamageTag : 'heavy',
      explosionSoundId: cleanId(raw?.explosionSoundId, null),
      zoneEnabled,
      zoneType: ['smoke','gas','toxin','panic','anaxion','fire'].includes(raw?.zoneType) ? raw.zoneType : 'gas',
      zoneRadius: clamp(safeNumber(raw?.zoneRadius, 15), 1, 5000),
      zoneDamage: clamp(Math.round(safeNumber(raw?.zoneDamage, 1)), 0, 30),
      zoneDamageTag: ['light','medium','heavy'].includes(raw?.zoneDamageTag) ? raw.zoneDamageTag : 'light',
      zoneRounds: clamp(Math.round(safeNumber(raw?.zoneRounds, 2)), 1, 100),
      zoneMzBonus: clamp(Math.round(safeNumber(raw?.zoneMzBonus, 0)), 0, 20),
      zoneVisionLimit: clamp(safeNumber(raw?.zoneVisionLimit, 20), 0, 3000),
      zoneSoundId: cleanId(raw?.zoneSoundId, null),
      notes: cleanText(raw?.notes || fallbackName, 1000)
    };
  }

  function normalizeToken(raw, scene, index = 0) {
    const kind = ['character', 'npc', 'generic', 'vehicle', 'interactive'].includes(raw?.kind) ? raw.kind : 'generic';
    const id = cleanId(raw?.id, makeId(`token${index + 1}`));
    const displayRaw = raw?.display || {};
    return {
      id,
      kind,
      refId: cleanId(raw?.refId, null),
      name: cleanName(raw?.name, kind === 'generic' ? `Токен ${index + 1}` : kind === 'interactive' ? `Интерактивный объект ${index + 1}` : 'Участник'),
      imageUrl: validAssetUrl(raw?.imageUrl) || null,
      formImages: {
        pallid: validAssetUrl(raw?.formImages?.pallid) || null,
        werewolf: validAssetUrl(raw?.formImages?.werewolf) || null
      },
      x: clamp(safeNumber(raw?.x, scene.mapWidth / 2), -100000, 100000),
      y: clamp(safeNumber(raw?.y, scene.mapHeight / 2), -100000, 100000),
      size: clamp(safeNumber(raw?.size, 1), 0.25, 12),
      rotation: ((safeNumber(raw?.rotation, 0) % 360) + 360) % 360,
      ownerId: cleanId(raw?.ownerId, null),
      groupId: cleanId(raw?.groupId, null),
      gmNarrative: normalizeNarrativeControl(raw?.gmNarrative),
      ai: normalizeAiControl(raw?.ai),
      hidden: Boolean(raw?.hidden),
      locked: Boolean(raw?.locked),
      defeated: Boolean(raw?.defeated),
      elevation: clamp(safeNumber(raw?.elevation, 0), -1000, 10000),
      vision: normalizeVision(raw?.vision),
      light: normalizeLight(raw?.light),
      display: {
        shape: ['circle','square','rounded','free'].includes(displayRaw.shape) ? displayRaw.shape : 'circle',
        fit: ['cover','contain'].includes(displayRaw.fit) ? displayRaw.fit : 'cover',
        imageScale: Math.max(0.25, safeNumber(displayRaw.imageScale, 1)),
        offsetX: clamp(safeNumber(displayRaw.offsetX, 0), -2, 2),
        offsetY: clamp(safeNumber(displayRaw.offsetY, 0), -2, 2),
        borderColor: cleanColor(displayRaw.borderColor, '#d7d7d7'),
        borderEnabled: displayRaw.borderEnabled !== false,
        backgroundEnabled: displayRaw.backgroundEnabled !== false,
        opacity: clamp(safeNumber(displayRaw.opacity, 1), 0.1, 1),
        showName: displayRaw.showName !== false,
        rotateImage: Boolean(displayRaw.autoRotateOnMove) || displayRaw.rotateImage !== false,
        autoRotateOnMove: Boolean(displayRaw.autoRotateOnMove),
        showGroupMarker: displayRaw.showGroupMarker !== false
      },
      mzOverride: raw?.mzOverride === null || raw?.mzOverride === undefined || raw?.mzOverride === '' ? null : clamp(Math.round(safeNumber(raw.mzOverride, 4)), 0, 99),
      coverBonus: clamp(Math.round(safeNumber(raw?.coverBonus, 0)), -20, 30),
      notes: cleanText(raw?.notes, 2000),
      boardedVehicleId: cleanId(raw?.boardedVehicleId, null),
      vehicle: kind === 'vehicle' ? normalizeVehicle(raw?.vehicle, raw?.name || 'Транспорт') : null,
      interactive: kind === 'interactive' ? normalizeInteractiveObject(raw?.interactive, raw?.name || 'Интерактивный объект') : null,
      updatedAt: raw?.updatedAt || nowIso()
    };
  }

  function normalizeWall(raw, index = 0) {
    const fallbackPoints = [
      { x: clamp(safeNumber(raw?.x1, 0), -100000, 100000), y: clamp(safeNumber(raw?.y1, 0), -100000, 100000) },
      { x: clamp(safeNumber(raw?.x2, 100), -100000, 100000), y: clamp(safeNumber(raw?.y2, 0), -100000, 100000) }
    ];
    const points = (Array.isArray(raw?.points) ? raw.points : fallbackPoints).slice(0, 512).map(point => ({
      x: clamp(safeNumber(point?.x, 0), -100000, 100000), y: clamp(safeNumber(point?.y, 0), -100000, 100000)
    }));
    if (points.length < 2) points.push({ ...fallbackPoints[1] });
    const shape = ['line','curve','pen','rect','square','circle','polygon'].includes(raw?.shape) ? raw.shape : (raw?.curved || points.length > 2 ? 'curve' : 'line');
    const closed = Boolean(raw?.closed || ['rect','square','circle','polygon'].includes(shape));
    return {
      id: cleanId(raw?.id, makeId(`wall${index + 1}`)),
      x1: points[0].x, y1: points[0].y, x2: points[points.length - 1].x, y2: points[points.length - 1].y,
      points, shape, closed,
      curved: Boolean(raw?.curved || points.length > 2 || shape === 'circle'),
      blocksVision: raw?.blocksVision !== false,
      blocksMovement: raw?.blocksMovement !== false,
      showGeometryToPlayers: Boolean(raw?.showGeometryToPlayers),
      coverMz: clamp(Math.round(safeNumber(raw?.coverMz, 0)), 0, 30),
      coverName: cleanText(raw?.coverName, 120),
      coverDurability: clamp(Math.round(safeNumber(raw?.coverDurability, 0)), 0, 999),
      coverDamage: clamp(Math.round(safeNumber(raw?.coverDamage, 0)), 0, 999),
      coverElevation: clamp(safeNumber(raw?.coverElevation, 0), -1000, 10000),
      coverHeightFt: clamp(safeNumber(raw?.coverHeightFt, 10), 0.5, 1000),
      destroyed: Boolean(raw?.destroyed) || (safeNumber(raw?.coverDurability,0)>0 && safeNumber(raw?.coverDamage,0)>=safeNumber(raw?.coverDurability,0))
    };
  }


  function normalizeDoor(raw, index = 0) {
    return {
      id: cleanId(raw?.id, makeId(`door${index + 1}`)),
      name: cleanName(raw?.name, `Дверь ${index + 1}`),
      wallId: cleanId(raw?.wallId, null),
      t: clamp(safeNumber(raw?.t, 0.5), 0, 1),
      width: clamp(safeNumber(raw?.width, 70), 10, 1000),
      x1: clamp(safeNumber(raw?.x1, 0), -100000, 100000),
      y1: clamp(safeNumber(raw?.y1, 0), -100000, 100000),
      x2: clamp(safeNumber(raw?.x2, 70), -100000, 100000),
      y2: clamp(safeNumber(raw?.y2, 0), -100000, 100000),
      open: Boolean(raw?.open),
      hinge: raw?.hinge === 'end' ? 'end' : 'start',
      openAngle: clamp(safeNumber(raw?.openAngle, 90), -170, 170),
      locked: Boolean(raw?.locked),
      allowPlayers: raw?.allowPlayers !== false,
      hidden: Boolean(raw?.hidden)
    };
  }

  function normalizeCover(raw, index = 0) {
    const shape = ['rect','circle','polygon','polyline'].includes(raw?.shape) ? raw.shape : 'rect';
    const points = (Array.isArray(raw?.points) ? raw.points : []).slice(0, 128).map(point => ({
      x: clamp(safeNumber(point?.x, 0), -100000, 100000),
      y: clamp(safeNumber(point?.y, 0), -100000, 100000)
    }));
    return {
      id: cleanId(raw?.id, makeId(`cover${index + 1}`)),
      name: cleanName(raw?.name, `Укрытие ${index + 1}`),
      shape,
      x: clamp(safeNumber(raw?.x, 0), -100000, 100000),
      y: clamp(safeNumber(raw?.y, 0), -100000, 100000),
      width: clamp(Math.abs(safeNumber(raw?.width, 140)), 5, 10000),
      height: clamp(Math.abs(safeNumber(raw?.height, 70)), 5, 10000),
      radius: clamp(Math.abs(safeNumber(raw?.radius, 70)), 5, 5000),
      points,
      mz: clamp(Math.round(safeNumber(raw?.mz, 2)), 0, 30),
      durability: clamp(Math.round(safeNumber(raw?.durability, 0)), 0, 9999),
      damage: clamp(Math.round(safeNumber(raw?.damage, 0)), 0, 9999),
      blocksMovement: Boolean(raw?.blocksMovement),
      thickness: clamp(safeNumber(raw?.thickness, 18), 2, 500),
      showGeometryToPlayers: Boolean(raw?.showGeometryToPlayers),
      hidden: Boolean(raw?.hidden),
      color: cleanColor(raw?.color, '#65a1c9'),
      preset: ['custom','flimsy','light','strong','fortified'].includes(raw?.preset) ? raw.preset : 'custom',
      coverage: ['quarter','half','full'].includes(raw?.coverage) ? raw.coverage : 'half',
      material: ['light','strong','special'].includes(raw?.material) ? raw.material : 'light',
      elevation: clamp(safeNumber(raw?.elevation, 0), -1000, 10000),
      verticalHeight: clamp(safeNumber(raw?.verticalHeight, raw?.coverage === 'quarter' ? 3 : raw?.coverage === 'full' ? 8 : 5), 0.5, 1000),
      destroyed: Boolean(raw?.destroyed) || (safeNumber(raw?.durability,0)>0 && safeNumber(raw?.damage,0)>=safeNumber(raw?.durability,0))
    };
  }

  function normalizeEffectZone(raw, index = 0) {
    const type = ['smoke','gas','toxin','panic','anaxion','fire','explosion','suppression','barrage'].includes(raw?.type) ? raw.type : 'smoke';
    const defaultColor = type === 'smoke' ? '#aab4bd' : type === 'gas' || type === 'toxin' ? '#75b86b' : type === 'panic' ? '#c2a45a' : type === 'suppression' ? '#d7b45a' : type === 'barrage' ? '#df6955' : type === 'fire' || type === 'explosion' ? '#ff9b43' : '#9b75d1';
    return {
      id: cleanId(raw?.id, makeId(`zone${index + 1}`)),
      name: cleanName(raw?.name, `Область ${index + 1}`),
      type,
      x: clamp(safeNumber(raw?.x, 0), -100000, 100000),
      y: clamp(safeNumber(raw?.y, 0), -100000, 100000),
      shape: raw?.shape === 'cone' ? 'cone' : 'circle',
      originX: clamp(safeNumber(raw?.originX, raw?.x || 0), -100000, 100000),
      originY: clamp(safeNumber(raw?.originY, raw?.y || 0), -100000, 100000),
      aimX: clamp(safeNumber(raw?.aimX, raw?.x || 0), -100000, 100000),
      aimY: clamp(safeNumber(raw?.aimY, raw?.y || 0), -100000, 100000),
      coneFeet: clamp(Math.abs(safeNumber(raw?.coneFeet, raw?.radius || 20)), 1, 5000),
      coneAngle: clamp(safeNumber(raw?.coneAngle, 60), 10, 160),
      radius: clamp(Math.abs(safeNumber(raw?.radius, 20)), 1, 5000),
      color: cleanColor(raw?.color, defaultColor),
      opacity: clamp(safeNumber(raw?.opacity, 0.28), 0.04, 0.85),
      mzBonus: clamp(Math.round(safeNumber(raw?.mzBonus, type === 'smoke' ? 2 : 0)), 0, 20),
      visionLimit: clamp(safeNumber(raw?.visionLimit, ['smoke','gas','toxin'].includes(type) ? 20 : 0), 0, 3000),
      gasHazard: Boolean(raw?.gasHazard) || type === 'gas' || type === 'toxin',
      damage: clamp(Math.round(safeNumber(raw?.damage, 0)), 0, 20),
      zoneDamage: clamp(Math.round(safeNumber(raw?.zoneDamage, raw?.damage || 0)), 0, 20),
      damageTag: ['light','medium','heavy'].includes(raw?.damageTag) ? raw.damageTag : (type === 'anaxion' ? 'heavy' : 'light'),
      remainingRounds: clamp(Math.round(safeNumber(raw?.remainingRounds, 1)), 0, 100),
      durationMode: raw?.durationMode === 'owner-turn' || (cleanId(raw?.ownerTokenId,null) && ['suppression','barrage','fire'].includes(type) && Math.round(safeNumber(raw?.remainingRounds,1))===1) ? 'owner-turn' : 'round',
      delayRounds: clamp(Math.round(safeNumber(raw?.delayRounds, 0)), 0, 100),
      createdRound: Math.max(0, Math.round(safeNumber(raw?.createdRound, 0))),
      ownerTokenId: cleanId(raw?.ownerTokenId, null),
      sourceName: cleanText(raw?.sourceName, 160),
      hostileOnly: Boolean(raw?.hostileOnly),
      attackHindrance: Boolean(raw?.attackHindrance),
      hitPenalty: clamp(Math.round(safeNumber(raw?.hitPenalty, 0)), -10, 10),
      visualOnly: Boolean(raw?.visualOnly),
      expiresAt: raw?.expiresAt ? String(raw.expiresAt) : null,
      pulse: raw?.pulse === true || Boolean(raw?.visualOnly),
      skipTurn: Boolean(raw?.skipTurn),
      triggered: Boolean(raw?.triggered),
      hidden: Boolean(raw?.hidden),
      notes: cleanText(raw?.notes, 1000),
      hitTokens: raw?.hitTokens && typeof raw.hitTokens === 'object' ? clone(raw.hitTokens) : {}
    };
  }

  function normalizeStaticLight(raw, index = 0) {
    return {
      id: cleanId(raw?.id, makeId(`light${index + 1}`)),
      name: cleanName(raw?.name, `Источник света ${index + 1}`),
      x: clamp(safeNumber(raw?.x, 0), -100000, 100000),
      y: clamp(safeNumber(raw?.y, 0), -100000, 100000),
      rotation: ((safeNumber(raw?.rotation, 0) % 360) + 360) % 360,
      enabled: raw?.enabled !== false,
      bright: clamp(safeNumber(raw?.bright, 20), 0, 2000),
      dim: clamp(safeNumber(raw?.dim, 40), 0, 3000),
      angle: clamp(safeNumber(raw?.angle, 360), 1, 360),
      color: cleanColor(raw?.color, '#ffd88a'),
      intensity: clamp(safeNumber(raw?.intensity, 1), 0.05, 2),
      flicker: clamp(safeNumber(raw?.flicker, 0), 0, 1),
      flickerSpeed: clamp(safeNumber(raw?.flickerSpeed, 1.5), 0.1, 12),
      blendMode: normalizeLightBlendMode(raw?.blendMode),
      hidden: Boolean(raw?.hidden)
    };
  }

  function normalizeFog(raw) {
    const ops = (Array.isArray(raw?.ops) ? raw.ops : []).map((op, index) => {
      const points = (Array.isArray(op?.points) ? op.points : []).slice(0, 2000).map(point => ({
        x: clamp(safeNumber(point?.x, 0), -100000, 100000),
        y: clamp(safeNumber(point?.y, 0), -100000, 100000)
      }));
      return {
        id: cleanId(op?.id, makeId(`fog${index + 1}`)),
        mode: op?.mode === 'hide' ? 'hide' : 'reveal',
        shape: ['brush', 'rect', 'circle'].includes(op?.shape) ? op.shape : 'brush',
        radius: clamp(safeNumber(op?.radius, 80), 2, 2000),
        x: clamp(safeNumber(op?.x, 0), -100000, 100000),
        y: clamp(safeNumber(op?.y, 0), -100000, 100000),
        width: clamp(safeNumber(op?.width, 0), -100000, 100000),
        height: clamp(safeNumber(op?.height, 0), -100000, 100000),
        points
      };
    }).slice(-MAX_FOG_OPS);
    const explored = {};
    if (raw?.explored && typeof raw.explored === 'object') {
      for (const [clientId, values] of Object.entries(raw.explored)) {
        const id = cleanId(clientId, null);
        if (!id || !Array.isArray(values)) continue;
        explored[id] = [...new Set(values.map(String).filter(value => /^-?\d+:-?\d+$/.test(value)))].slice(-MAX_EXPLORED_CELLS);
      }
    }
    return {
      baseHidden: raw?.baseHidden !== false,
      ops,
      explored,
      cellSize: clamp(Math.round(safeNumber(raw?.cellSize, 70)), 16, 500)
    };
  }

  function normalizeScene(raw, index = 0) {
    const mapWidth = clamp(Math.round(safeNumber(raw?.mapWidth, 1920)), 100, 30000);
    const mapHeight = clamp(Math.round(safeNumber(raw?.mapHeight, 1080)), 100, 30000);
    const provisional = { mapWidth, mapHeight };
    const rawWalls = Array.isArray(raw?.walls) ? raw.walls : [];
    const legacyDoorWalls = rawWalls.filter(wall => wall?.door);
    const walls = rawWalls.filter(wall => !wall?.door).map(normalizeWall).slice(0, MAX_WALLS);
    const rawDoors = Array.isArray(raw?.doors) ? raw.doors : [];
    const legacyDoors = legacyDoorWalls.map((wall, doorIndex) => normalizeDoor({
      id: wall.id || makeId(`legacydoor${doorIndex + 1}`), name: wall.coverName || `Дверь ${doorIndex + 1}`,
      wallId: null, x1: wall.x1, y1: wall.y1, x2: wall.x2, y2: wall.y2,
      width: Math.hypot(safeNumber(wall.x2, 0) - safeNumber(wall.x1, 0), safeNumber(wall.y2, 0) - safeNumber(wall.y1, 0)),
      open: wall.open, allowPlayers: true
    }, doorIndex));
    return {
      id: cleanId(raw?.id, makeId(`scene${index + 1}`)),
      name: cleanName(raw?.name, `Сцена ${index + 1}`),
      mapUrl: validAssetUrl(raw?.mapUrl, 'map') || null,
      mapPreviewUrl: validAssetUrl(raw?.mapPreviewUrl, 'map') || null,
      mapThumbnailUrl: validAssetUrl(raw?.mapThumbnailUrl, 'map') || null,
      mapOriginalUrl: validAssetUrl(raw?.mapOriginalUrl, 'map') || null,
      mapOptimization: raw?.mapOptimization && typeof raw.mapOptimization === 'object' ? {
        mode: ['optimal','high','original'].includes(raw.mapOptimization.mode) ? raw.mapOptimization.mode : 'original',
        sourceName: cleanName(raw.mapOptimization.sourceName, '', 180),
        sourceBytes: Math.max(0, Math.round(safeNumber(raw.mapOptimization.sourceBytes, 0))),
        fullBytes: Math.max(0, Math.round(safeNumber(raw.mapOptimization.fullBytes, 0))),
        previewBytes: Math.max(0, Math.round(safeNumber(raw.mapOptimization.previewBytes, 0))),
        thumbnailBytes: Math.max(0, Math.round(safeNumber(raw.mapOptimization.thumbnailBytes, 0))),
        sourceStored: Boolean(raw.mapOptimization.sourceStored),
        uploadedAt: raw.mapOptimization.uploadedAt || null
      } : null,
      mapWidth,
      mapHeight,
      background: cleanColor(raw?.background, '#20242b'),
      grid: normalizeGrid(raw?.grid),
      settings: normalizeSceneSettings(raw?.settings),
      tokenGroups: (Array.isArray(raw?.tokenGroups) ? raw.tokenGroups : []).map(normalizeTokenGroup).slice(0, 100),
      tokens: (Array.isArray(raw?.tokens) ? raw.tokens : []).map((token, tokenIndex) => normalizeToken(token, provisional, tokenIndex)).slice(0, MAX_TOKENS),
      walls,
      doors: [...rawDoors.map(normalizeDoor), ...legacyDoors].slice(0, MAX_DOORS),
      covers: (Array.isArray(raw?.covers) ? raw.covers : []).map(normalizeCover).slice(0, MAX_COVERS),
      effects: (Array.isArray(raw?.effects) ? raw.effects : []).map(normalizeEffectZone).slice(0, MAX_EFFECT_ZONES),
      audioSources: (Array.isArray(raw?.audioSources) ? raw.audioSources : []).map(normalizeAudioSource).slice(0, MAX_AUDIO_SOURCES),
      weatherLayers: (Array.isArray(raw?.weatherLayers) ? raw.weatherLayers : []).map(normalizeWeatherLayer).slice(0, MAX_WEATHER_LAYERS),
      parallax: normalizeParallax(raw?.parallax, provisional),
      elevationZones: (Array.isArray(raw?.elevationZones) ? raw.elevationZones : []).map(normalizeElevationZone).slice(0, MAX_ELEVATION_ZONES),
      triggerZones: (Array.isArray(raw?.triggerZones) ? raw.triggerZones : []).map(normalizeTriggerZone).slice(0, MAX_TRIGGER_ZONES),
      drawings: (Array.isArray(raw?.drawings) ? raw.drawings : []).map(normalizeDrawing).filter(item => item.points.length >= 2).slice(-MAX_DRAWINGS),
      mapWidgets: (Array.isArray(raw?.mapWidgets) ? raw.mapWidgets : []).map(normalizeMapWidget).slice(0, MAX_MAP_WIDGETS),
      lights: (Array.isArray(raw?.lights) ? raw.lights : []).map(normalizeStaticLight).slice(0, MAX_LIGHTS),
      fog: normalizeFog(raw?.fog),
      updatedAt: raw?.updatedAt || nowIso()
    };
  }


  function normalizeLogEntry(raw, index = 0) {
    return {
      id: cleanId(raw?.id, makeId(`log${index + 1}`)),
      at: raw?.at || nowIso(),
      type: ['chat','action','roll','system'].includes(raw?.type) ? raw.type : 'action',
      actorId: cleanId(raw?.actorId, null),
      actorName: cleanName(raw?.actorName, 'Система'),
      text: cleanText(raw?.text, 2000),
      visibility: raw?.visibility === 'master' ? 'master' : 'public',
      sceneId: cleanId(raw?.sceneId, null),
      tokenId: cleanId(raw?.tokenId, null),
      meta: raw?.meta && typeof raw.meta === 'object' ? clone(raw.meta) : {}
    };
  }
  function normalizeTableLog(raw) {
    return (Array.isArray(raw) ? raw : []).map(normalizeLogEntry).filter(item => item.text).slice(-500);
  }
  function appendTableLog(entry) {
    const normalized = normalizeLogEntry({ id: makeId('table'), at: nowIso(), ...entry });
    if (!normalized.text) return null;
    // v1.1.13: every journal entry that represents a roll should carry the
    // exact dice formula. When the caller only supplied a roll/attack id,
    // recover the formula from the campaign dice log automatically.
    if (!normalized.meta?.formula && !(Array.isArray(normalized.meta?.formulas) && normalized.meta.formulas.length)) {
      const refId=cleanId(normalized.meta?.rollId||normalized.meta?.attackId,null);
      if(refId){
        const stored=(getCampaign()?.diceLog||[]).find(item=>item?.id===refId);
        if(stored?.formula)normalized.meta.formula=String(stored.formula);
      }
    }
    state.tableLog ||= [];
    state.tableLog.push(normalized);
    if (state.tableLog.length > 500) state.tableLog.splice(0, state.tableLog.length - 500);
    return normalized;
  }
  function broadcastTableLog(entry) {
    if (!entry) return;
    for (const client of getSseClients().values()) {
      if (entry.visibility === 'master' && client.mode !== 'master') continue;
      try { sseWrite(client.response, 'battlemap-log-entry', { entry: publicTableLogEntry(entry, client.mode), at: nowIso() }); } catch {}
    }
  }

  function normalizeBattlemap(raw) {
    const base = makeEmptyBattlemap();
    const scenes = (Array.isArray(raw?.scenes) ? raw.scenes : []).map(normalizeScene).slice(0, MAX_SCENES);

    // v1.0.9: группы являются сущностями всей кампании. Старые сохранения
    // держали их внутри сцен, поэтому при загрузке объединяем оба формата.
    const groupCandidates = [
      ...(Array.isArray(raw?.tokenGroups) ? raw.tokenGroups : []),
      ...scenes.flatMap(scene => Array.isArray(scene.tokenGroups) ? scene.tokenGroups : [])
    ];
    const groupMap = new Map();
    for (let index = 0; index < groupCandidates.length; index += 1) {
      const normalized = normalizeTokenGroup(groupCandidates[index], index);
      const existing = groupMap.get(normalized.id);
      if (!existing) { groupMap.set(normalized.id, normalized); continue; }
      const existingTime = Date.parse(existing.updatedAt || '') || 0;
      const nextTime = Date.parse(normalized.updatedAt || '') || 0;
      const preferred = nextTime >= existingTime ? normalized : existing;
      groupMap.set(normalized.id, {
        ...existing,
        ...preferred,
        relations: { ...(existing.relations || {}), ...(normalized.relations || {}) }
      });
    }
    const tokenGroups = [...groupMap.values()].slice(0, 100);
    const globalGroupIds = new Set(tokenGroups.map(group => group.id));
    for (const group of tokenGroups) {
      group.relations = Object.fromEntries(Object.entries(group.relations || {})
        .filter(([otherId, relation]) => otherId !== group.id && globalGroupIds.has(otherId) && ['ally','enemy','neutral'].includes(relation)));
    }

    const used = new Set();
    for (const scene of scenes) {
      while (used.has(scene.id)) scene.id = makeId('scene');
      used.add(scene.id);
      const tokenIds = new Set();
      for (const token of scene.tokens) {
        while (tokenIds.has(token.id)) token.id = makeId('token');
        tokenIds.add(token.id);
        if (token.groupId && !globalGroupIds.has(token.groupId)) token.groupId = null;
      }
      // Совместимость со старыми клиентами и тестами: сцена содержит зеркало,
      // но канонический список хранится только на верхнем уровне battlemap.
      scene.tokenGroups = clone(tokenGroups);
    }
    const requestedActive = cleanId(raw?.activeSceneId, null);
    const activeForDaylight = scenes.find(scene => scene.id === requestedActive) || scenes[0] || null;
    const daylight = normalizeGlobalDaylight(raw?.daylight, activeForDaylight?.settings || null);
    for (const scene of scenes) scene.settings = normalizeSceneSettings({ ...scene.settings, ...daylight });
    const rawCombat = raw?.combat || {};
    const combatSceneId = scenes.some(scene => scene.id === cleanId(rawCombat.sceneId, null)) ? cleanId(rawCombat.sceneId, null) : null;
    const combatScene = scenes.find(scene => scene.id === combatSceneId);
    const validTokenIds = new Set(combatScene?.tokens.map(token => token.id) || []);
    return {
      ...base,
      version: 10,
      tableLog: normalizeTableLog(raw?.tableLog),
      tokenGroups,
      activeSceneId: scenes.some(scene => scene.id === requestedActive) ? requestedActive : (scenes[0]?.id || null),
      audio: normalizeAudioState(raw?.audio),
      daylight,
      masterPause: { active:Boolean(raw?.masterPause?.active), reason:cleanText(raw?.masterPause?.reason||'',300), activatedAt:raw?.masterPause?.activatedAt||null },
      combat: {
        active: Boolean(rawCombat.active && combatSceneId),
        sceneId: combatSceneId,
        participantTokenIds: (Array.isArray(rawCombat.participantTokenIds) ? rawCombat.participantTokenIds : []).map(value => cleanId(value, null)).filter(value => value && validTokenIds.has(value)),
        startedAt: rawCombat.startedAt || null,
        movement: Object.fromEntries(Object.entries(rawCombat.movement && typeof rawCombat.movement === 'object' ? rawCombat.movement : {})
          .filter(([tokenId]) => validTokenIds.has(tokenId))
          .map(([tokenId, value]) => [tokenId, {
            spent: Math.max(0, safeNumber(value?.spent, 0)),
            opportunityAttackers: [...new Set((Array.isArray(value?.opportunityAttackers) ? value.opportunityAttackers : []).map(item => cleanId(item, null)).filter(Boolean))],
            zoneFireShooters: [...new Set((Array.isArray(value?.zoneFireShooters) ? value.zoneFireShooters : []).map(item => cleanId(item, null)).filter(Boolean))]
          }]))
      },
      updatedAt: raw?.updatedAt || base.updatedAt,
      scenes
    };
  }

  function syncTokenGroupMirrors() {
    const groups = clone(state?.tokenGroups || []);
    for (const scene of state?.scenes || []) scene.tokenGroups = clone(groups);
  }

  function replaceGlobalTokenGroups(rawGroups) {
    const groups = [];
    const seen = new Set();
    for (const rawGroup of (Array.isArray(rawGroups) ? rawGroups : []).slice(0, 100)) {
      const group = normalizeTokenGroup(rawGroup, groups.length);
      if (seen.has(group.id)) continue;
      seen.add(group.id);
      groups.push(group);
    }
    const ids = new Set(groups.map(group => group.id));
    for (const group of groups) {
      group.relations = Object.fromEntries(Object.entries(group.relations || {})
        .filter(([otherId, relation]) => otherId !== group.id && ids.has(otherId) && ['ally','enemy','neutral'].includes(relation)));
    }
    state.tokenGroups = groups;
    for (const scene of state.scenes || []) {
      for (const token of scene.tokens || []) if (token.groupId && !ids.has(token.groupId)) token.groupId = null;
      scene.tokenGroups = clone(groups);
      scene.updatedAt = nowIso();
    }
    return state.tokenGroups;
  }

  function findGlobalTokenGroup(groupId) {
    return (state?.tokenGroups || []).find(group => group.id === groupId) || null;
  }

  function ensureDataFiles() {
    requestCache.clear();
    pendingMeleeCounters.clear();
    fs.mkdirSync(currentDataDir, { recursive: true });
    fs.mkdirSync(MAP_DIR, { recursive: true });
    fs.mkdirSync(TOKEN_DIR, { recursive: true });
    fs.mkdirSync(AUDIO_DIR, { recursive: true });
    fs.mkdirSync(CORE_AUDIO_DIR, { recursive: true });
    fs.mkdirSync(SHARED_AUDIO_DIR, { recursive: true });
    refreshExternalAudioLibraries();
    if (!fs.existsSync(BATTLEMAP_FILE)) atomicWriteJsonSync(BATTLEMAP_FILE, makeEmptyBattlemap(), 2);
    try {
      state = normalizeBattlemap(JSON.parse(fs.readFileSync(BATTLEMAP_FILE, 'utf8')));
    } catch (error) {
      const broken = path.join(dataDir, `battlemap-broken-${Date.now()}.json`);
      try { fs.copyFileSync(BATTLEMAP_FILE, broken); } catch {}
      state = makeEmptyBattlemap();
      console.error('battlemap.json повреждён:', error.message);
    }
    atomicWriteJsonSync(BATTLEMAP_FILE, state, 2);
  }

  function queuePersistSnapshot() {
    state.updatedAt = nowIso();
    pendingPersistSnapshot = JSON.stringify(state, null, 2);
  }

  function flushPendingPersist() {
    if (pendingPersistTimer) { clearTimeout(pendingPersistTimer); pendingPersistTimer = null; }
    if (!pendingPersistSnapshot) return writeChain;
    const snapshot = pendingPersistSnapshot;
    pendingPersistSnapshot = null;
    const battlemapFile = BATTLEMAP_FILE;
    writeChain = writeChain.then(() => atomicWriteFile(battlemapFile, snapshot, 'utf8'));
    return writeChain.then(() => pendingPersistSnapshot ? flushPendingPersist() : undefined);
  }

  function persist(options = {}) {
    queuePersistSnapshot();
    if (options.defer === true) {
      if (!pendingPersistTimer) {
        const delayMs = clamp(Math.round(safeNumber(options.delayMs, 120)), 25, 500);
        pendingPersistTimer = setTimeout(() => {
          pendingPersistTimer = null;
          flushPendingPersist().catch(error => console.error('Не удалось сохранить отложенное состояние battlemap:', error.message));
        }, delayMs);
        pendingPersistTimer.unref?.();
      }
      return Promise.resolve();
    }
    return flushPendingPersist();
  }

  function tokenUpdateIsMovementOnly(body) {
    const allowed = new Set(['clientId','playerName','x','y','rotation','movementDeltaFeet','forceMove','ignoreWalls','ignoreMovementLimit']);
    return Object.keys(body || {}).every(key => allowed.has(key)) && (body?.x !== undefined || body?.y !== undefined || body?.rotation !== undefined);
  }

  function assetFileFromUrl(urlPath) {
    if (typeof urlPath !== 'string') return null;
    const match = /^\/(maps|tokens|audio|shared-audio)\/([A-Za-z0-9_.-]+)$/.exec(urlPath);
    if (!match) return null;
    const folder=match[1] === 'maps' ? MAP_DIR : match[1] === 'tokens' ? TOKEN_DIR : match[1] === 'shared-audio' ? SHARED_AUDIO_DIR : AUDIO_DIR;
    return path.join(folder, match[2]);
  }

  function sceneMapAssetUrls(scene) {
    const parallaxUrls = (scene?.parallax?.layers || []).map(layer => layer?.imageUrl).filter(Boolean);
    return [...new Set([scene?.mapUrl, scene?.mapPreviewUrl, scene?.mapThumbnailUrl, scene?.mapOriginalUrl, ...parallaxUrls].filter(Boolean))];
  }

  function mapAssetIsUsed(mapUrl) {
    return Boolean(mapUrl && state?.scenes?.some(scene => sceneMapAssetUrls(scene).includes(mapUrl)));
  }

  async function deleteMapAssetIfUnused(mapUrl) {
    if (!mapUrl || mapAssetIsUsed(mapUrl)) return false;
    const file = assetFileFromUrl(mapUrl);
    if (!file || path.dirname(file) !== MAP_DIR) return false;
    try { await fs.promises.unlink(file); return true; }
    catch (error) { if (error?.code !== 'ENOENT') console.warn('Не удалось удалить файл карты:', error.message); return false; }
  }

  async function deleteMapAssetsIfUnused(mapUrls) {
    let removed = 0;
    for (const url of [...new Set((mapUrls || []).filter(Boolean))]) if (await deleteMapAssetIfUnused(url)) removed += 1;
    return removed;
  }

  function clearSceneObjects(scene) {
    const counts = {
      tokens: scene.tokens?.length || 0,
      tokenGroups: 0,
      walls: scene.walls?.length || 0,
      doors: scene.doors?.length || 0,
      covers: scene.covers?.length || 0,
      effects: scene.effects?.length || 0,
      audioSources: scene.audioSources?.length || 0,
      weatherLayers: scene.weatherLayers?.length || 0,
      elevationZones: scene.elevationZones?.length || 0,
      triggerZones: scene.triggerZones?.length || 0,
      drawings: scene.drawings?.length || 0,
      mapWidgets: scene.mapWidgets?.length || 0,
      lights: scene.lights?.length || 0,
      fogOps: scene.fog?.ops?.length || 0,
      exploredCells: Object.values(scene.fog?.explored || {}).reduce((sum, cells) => sum + (Array.isArray(cells) ? cells.length : 0), 0)
    };
    scene.tokens = [];
    scene.tokenGroups = clone(state.tokenGroups || []);
    scene.walls = [];
    scene.doors = [];
    scene.covers = [];
    scene.effects = [];
    scene.audioSources = [];
    scene.weatherLayers = [];
    scene.elevationZones = [];
    scene.triggerZones = [];
    scene.drawings = [];
    scene.mapWidgets = [];
    scene.lights = [];
    scene.fog = normalizeFog({ ...scene.fog, ops: [], explored: {} });
    scene.updatedAt = nowIso();
    return counts;
  }

  function clearCombatOnlyActions(scene) {
    if(!scene)return 0;let changed=0;
    for(const token of scene.tokens||[]){
      const actions=tokenActions(token);
      for(const [key,value] of Object.entries(actions||{})){if(value&&typeof value==='object'&&value.roundAction===true){delete actions[key];changed++;}}
      if(sniperRuntime(token,false)){clearCombatRuntimeForToken(token);changed++;}
      for(const key of ['weaponModMount','weaponModRest','weaponModOvercharge','weaponModStealthBonus','weaponMods'])if(actions[key]){delete actions[key];changed++;}
      if(token.kind==='vehicle'&&token.vehicle){for(const key of ['stabilizedUntilDriverTurn','roughUntilDriverTurn','evasiveUntilDriverTurn']){if(token.vehicle[key]){token.vehicle[key]=false;changed++;}}token.vehicle.stabilizedRound=0;token.vehicle.sharpManeuverRound=0;token.vehicle.movedRound=0;}
      resetTokenMovement(token);
    }
    return changed;
  }
  function endCombatStateForScene(scene) {
    if(scene)clearCombatOnlyActions(scene);
    state.combat={active:false,sceneId:null,participantTokenIds:[],startedAt:null,movement:{}};
    const campaign=getCampaign();campaign.initiative={round:1,currentIndex:0,entries:[]};
  }

  async function stopCombatForScene(sceneId) {
    if (state.combat?.sceneId !== sceneId) return false;
    const scene=findScene(sceneId);endCombatStateForScene(scene);
    const campaign = getCampaign();
    await persistCampaign();
    if (broadcastCampaignReplaced) broadcastCampaignReplaced(null, 'combat-reset-scene');
    return true;
  }

  function assetExtension(mime) {
    const map = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif' };
    return map[String(mime || '').toLowerCase()] || null;
  }

  function saveAssetBuffer(kind, buffer, originalName = '', mime = '') {
    const extension = assetExtension(mime);
    if (!extension) throw Object.assign(new Error('Поддерживаются PNG, JPEG, WEBP и GIF.'), { statusCode: 400 });
    const limit = kind === 'map' ? 36 * 1024 * 1024 : 10 * 1024 * 1024;
    if (!buffer?.length || buffer.length > limit) throw Object.assign(new Error(`Изображение слишком большое. Лимит: ${Math.round(limit / 1024 / 1024)} МБ.`), { statusCode: 413 });
    const base = path.basename(String(originalName || kind), path.extname(String(originalName || ''))).replace(/[^A-Za-z0-9_.-]+/g, '_').slice(0, 80) || kind;
    const fileName = `${base}-${Date.now()}-${Math.random().toString(16).slice(2, 8)}.${extension}`;
    const directory = kind === 'map' ? MAP_DIR : TOKEN_DIR;
    fs.writeFileSync(path.join(directory, fileName), buffer);
    return `/${kind === 'map' ? 'maps' : 'tokens'}/${fileName}`;
  }

  function saveAssetDataUrl(kind, dataUrl, originalName = '') {
    const match = /^data:(image\/(?:png|jpeg|webp|gif));base64,([A-Za-z0-9+/=\s]+)$/i.exec(String(dataUrl || ''));
    if (!match) throw Object.assign(new Error('Поддерживаются PNG, JPEG, WEBP и GIF.'), { statusCode: 400 });
    return saveAssetBuffer(kind, Buffer.from(match[2].replace(/\s+/g, ''), 'base64'), originalName, match[1]);
  }

  async function snapshotFolder(directory, maxSize = 40 * 1024 * 1024, pattern = /^[A-Za-z0-9А-Яа-яЁё_.-]+\.(?:png|jpe?g|webp|gif)$/i) {
    const result = {};
    for (const name of await fs.promises.readdir(directory)) {
      if (!pattern.test(name)) continue;
      const file = path.join(directory, name);
      const stat = await fs.promises.stat(file);
      if (!stat.isFile() || stat.size > maxSize) continue;
      result[name] = (await fs.promises.readFile(file)).toString('base64');
    }
    return result;
  }

  async function snapshotPayload(includeAssets = true) {
    const payload = { battlemap: clone(state) };
    if (!includeAssets) return payload;
    payload.mapAssets = await snapshotFolder(MAP_DIR);
    payload.tokenAssets = await snapshotFolder(TOKEN_DIR, 12 * 1024 * 1024);
    payload.audioAssets = await snapshotFolder(AUDIO_DIR, 90 * 1024 * 1024, /^[A-Za-z0-9_.-]+\.(?:mp3|ogg|wav|webm|m4a|aac)$/i);
    return payload;
  }

  async function restorePayload(payload) {
    // Старые снимки v0.4.x не содержат battlemap: не стираем текущие сцены при их восстановлении.
    if (payload?.battlemap) state = normalizeBattlemap(payload.battlemap);
    for (const [folder, assets, pattern, limit] of [[MAP_DIR, payload?.mapAssets, /^[A-Za-z0-9А-Яа-яЁё_.-]+\.(?:png|jpe?g|webp|gif)$/i, 40*1024*1024], [TOKEN_DIR, payload?.tokenAssets, /^[A-Za-z0-9А-Яа-яЁё_.-]+\.(?:png|jpe?g|webp|gif)$/i, 40*1024*1024], [AUDIO_DIR, payload?.audioAssets, /^[A-Za-z0-9_.-]+\.(?:mp3|ogg|wav|webm|m4a|aac)$/i, 90*1024*1024]]) {
      if (!assets || typeof assets !== 'object') continue;
      for (const [name, encoded] of Object.entries(assets)) {
        if (!pattern.test(name) || typeof encoded !== 'string') continue;
        const buffer = Buffer.from(encoded, 'base64');
        if (buffer.length && buffer.length <= limit) await fs.promises.writeFile(path.join(folder, name), buffer);
      }
    }
    await persist();
  }

  function findScene(sceneId) { return state.scenes.find(scene => scene.id === sceneId) || null; }
  function findToken(scene, tokenId) { return scene?.tokens.find(token => token.id === tokenId) || null; }
  function findDoor(scene, doorId) { return scene?.doors.find(door => door.id === doorId) || null; }
  function findCover(scene, coverId) { return scene?.covers.find(cover => cover.id === coverId) || null; }

  function linkedCharacter(token) {
    if (token?.kind !== 'character' || !token.refId) return null;
    return getCampaign().characters.find(character => character.id === token.refId) || null;
  }
  function linkedNpc(token) {
    if (token?.kind !== 'npc' || !token.refId) return null;
    return getCampaign().npcs.find(npc => npc.id === token.refId) || null;
  }

  function nextNpcCopyName(sourceName) {
    const campaign=getCampaign(),raw=String(sourceName||'NPC').trim()||'NPC',base=raw.replace(/\s+\(копия(?:\s+\d+)?\)$/i,'').trim()||'NPC';
    const names=new Set((campaign.npcs||[]).map(npc=>String(npc.name||'').trim().toLocaleLowerCase('ru-RU')));
    let index=1,candidate=`${base} (копия)`;
    while(names.has(candidate.toLocaleLowerCase('ru-RU'))){index+=1;candidate=`${base} (копия ${index})`;}
    return candidate;
  }

  function cloneNpcSheetForToken(token) {
    const campaign=getCampaign(),source=linkedNpc(token);if(!source)return null;
    const npc=clone(source);npc.id=makeId('npc');while(campaign.npcs.some(item=>item.id===npc.id))npc.id=makeId('npc');
    npc.name=nextNpcCopyName(source.name);npc.initiative=0;npc._battlemapActions={};npc._battlemapCounterDebt=0;npc._battlemapShockDebt=0;npc._battlemapMeleeDefensePenalty=0;npc.updatedAt=nowIso();
    campaign.npcs.push(npc);token.refId=npc.id;token.name=npc.name;token.updatedAt=nowIso();
    return npc;
  }

  function ensureSpeciesRuntime(st) {
    if (!st || typeof st !== 'object') return null;
    if (!['human','pallid','werewolf','rokurokubi'].includes(st.species)) st.species = 'human';
    st.pallid = st.pallid && typeof st.pallid === 'object' ? st.pallid : {};
    st.pallid.bloodDoses = Math.max(0, Math.round(safeNumber(st.pallid.bloodDoses, 0)));
    st.pallid.transformed = Boolean(st.pallid.transformed);
    st.pallid.memoryUsed = Boolean(st.pallid.memoryUsed);
    st.pallid.formArmorAdapted = Boolean(st.pallid.formArmorAdapted);
    st.werewolf = st.werewolf && typeof st.werewolf === 'object' ? st.werewolf : {};
    st.werewolf.transformed = Boolean(st.werewolf.transformed);
    st.werewolf.uncontrolled = Boolean(st.werewolf.uncontrolled);
    st.werewolf.beastState = ['calm','breakdown','full'].includes(st.werewolf.beastState) ? st.werewolf.beastState : 'calm';
    st.werewolf.beastFailures = Math.max(0, Math.round(safeNumber(st.werewolf.beastFailures, 0)));
    st.werewolf.odDebt = Math.max(0, Math.round(safeNumber(st.werewolf.odDebt, 0)));
    st.werewolf.hideUsed = Boolean(st.werewolf.hideUsed);
    st.werewolf.seriousTriggerUsed = Boolean(st.werewolf.seriousTriggerUsed);
    st.werewolf.aftereffects = Boolean(st.werewolf.aftereffects);
    st.werewolf.formArmorAdapted = Boolean(st.werewolf.formArmorAdapted);
    st.rokurokubi = st.rokurokubi && typeof st.rokurokubi === 'object' ? st.rokurokubi : {};
    st.rokurokubi.neckExtended = Boolean(st.rokurokubi.neckExtended);
    st.rokurokubi.ambushUsed = Boolean(st.rokurokubi.ambushUsed);
    st.rokurokubi.wrappedTarget = String(st.rokurokubi.wrappedTarget || '');
    st.rokurokubi.wrappedTargetTokenId = cleanId(st.rokurokubi.wrappedTargetTokenId, null);
    st.rokurokubi.headPoint = st.rokurokubi.headPoint && Number.isFinite(Number(st.rokurokubi.headPoint.x)) && Number.isFinite(Number(st.rokurokubi.headPoint.y))
      ? { x:safeNumber(st.rokurokubi.headPoint.x,0), y:safeNumber(st.rokurokubi.headPoint.y,0) } : null;
    st.rokurokubi.neckGearReady = Boolean(st.rokurokubi.neckGearReady);
    st._speciesConditions = st._speciesConditions && typeof st._speciesConditions === 'object' ? st._speciesConditions : {};
    st.activeEffects = Array.isArray(st.activeEffects) ? st.activeEffects : [];
    return st;
  }
  function speciesStateForToken(token) {
    if (token?.kind !== 'character') return null;
    const st = linkedCharacter(token)?.state || null;
    return ensureSpeciesRuntime(st);
  }
  function speciesConditionHost(token) {
    const host = actionHost(token);
    if (!host) return null;
    host._speciesConditions = host._speciesConditions && typeof host._speciesConditions === 'object' ? host._speciesConditions : {};
    return host._speciesConditions;
  }
  function speciesConditions(token) { return speciesConditionHost(token) || {}; }
  function removeSpeciesEffect(st, source) {
    if (!st) return;
    st.activeEffects = (st.activeEffects || []).filter(effect => effect?.source !== source);
  }
  function setSpeciesEffect(st, source, title, desc, extra = {}) {
    if (!st) return;
    removeSpeciesEffect(st, source);
    st.activeEffects.unshift({ id:makeId('effect'), title, desc, source, createdAt:nowIso(), ...extra });
  }
  function clearWrappedTarget(scene, wrapperToken) {
    const st = speciesStateForToken(wrapperToken);
    const targetId = st?.rokurokubi?.wrappedTargetTokenId;
    const target = targetId ? findToken(scene, targetId) : null;
    if (target) {
      const cond = speciesConditionHost(target);
      if (cond?.wrappedByTokenId === wrapperToken.id) delete cond.wrappedByTokenId;
    }
    if (st?.rokurokubi) {
      st.rokurokubi.wrappedTargetTokenId = null;
      st.rokurokubi.wrappedTarget = '';
      removeSpeciesEffect(st, 'rokurokubiWrap');
    }
  }
  function skillBonusForNaturalWeapon(character, names) {
    const values = names.map(name => ({ name, bonus:Math.round(safeNumber(characterSkillProfileDetailed(character,name,true)?.bonus,0)) }));
    return values.sort((a,b)=>b.bonus-a.bonus)[0] || { name:names[0] || 'Физическая сила', bonus:0 };
  }
  function speciesNaturalWeapons(token, { includeDormant = false } = {}) {
    const character = linkedCharacter(token), st = speciesStateForToken(token);
    if (!character || !st) return [];
    const make = (id,name,die,damage,cost,range,skills,damageTag,description,extra={}) => {
      const best=skillBonusForNaturalWeapon(character,skills);
      return { id,slot:id,name,profile:name,type:'Оружие ближнего боя',melee:true,hitDieNormal:die,hitDieAimed:'',hitBonus:best.bonus,skillName:best.name,ignoreMz:0,damage,damageTag,odCost:cost,aimedOdCost:null,obCost:0,range,radius:0,description,notes:[],naturalWeapon:true,...extra };
    };
    if (st.species === 'pallid' && st.pallid.transformed) return [
      make('pallid-claws','Когти Вечного','1d10',3,2,5,['Физическая сила','Акробатика'],'medium','Естественное оружие Формы Вечного. Обычная атака, Встречный удар и свободная атака; бонус — лучший из Физической силы и Акробатики.',{soundEffectKey:'natural.claws'}),
      make('pallid-rending','Разрывающий удар','1d8',4,3,5,['Физическая сила'],'heavy','Тяжёлый естественный удар. Нельзя использовать для Встречного удара или свободной атаки.',{counterAllowed:false,soundEffectKey:'natural.claws'})
    ];
    if (st.species === 'werewolf' && st.werewolf.transformed) return [
      make('werewolf-claws','Когти волколака','1d8',3,2,5,['Физическая сила','Акробатика'],'medium','Естественное оружие Звериной формы. Обычная атака, Встречный удар и свободная атака.',{soundEffectKey:'natural.claws'}),
      make('werewolf-bite','Укус','1d8',4,3,5,['Физическая сила'],'heavy','Естественное оружие. Нельзя использовать для Встречного удара или свободной атаки. Если нанесено хотя бы Среднее ранение, после сцены возможна передача ликантропии.',{counterAllowed:false,lycanthropyRisk:true,soundEffectKey:'natural.bite'}),
      make('werewolf-takedown','Сбивающий бросок','1d6',2,2,5,['Физическая сила','Акробатика'],'light','Естественное оружие. После нанесения ранения можно потратить ещё 1 ОД и сбить цель с ног. Нельзя использовать для Встречного удара.',{supportsTakedown:true,counterAllowed:false})
    ];
    if (st.species === 'rokurokubi' && (st.rokurokubi.neckExtended || includeDormant)) {
      const list=[];
      if (!st.rokurokubi.wrappedTargetTokenId) list.push(make('rokurokubi-lunge','Молниеносный выпад','1d8',3,2,10,['Физическая сила','Акробатика'],'medium','Естественное оружие с дистанцией 10 футов. Обычная атака, Встречный удар и свободная атака.'));
      if (!st.rokurokubi.wrappedTargetTokenId) list.push(make('rokurokubi-wrap','Обвивающий захват','1d6',1,2,10,['Физическая сила','Акробатика'],'light','При нанесении ранения цель можно Обвить. Используется только для обычной атаки.',{wrapOnHit:true,counterAllowed:false}));
      return list;
    }
    return [];
  }
  function naturalFormActive(token) {
    const st=speciesStateForToken(token);
    return Boolean(st && ((st.species==='pallid'&&st.pallid.transformed)||(st.species==='werewolf'&&st.werewolf.transformed)||(st.species==='rokurokubi'&&st.rokurokubi.neckExtended)));
  }
  function speciesCombatPoint(token) {
    const st=speciesStateForToken(token);
    if (st?.species==='rokurokubi' && st.rokurokubi.neckExtended && st.rokurokubi.headPoint) return { ...token, x:st.rokurokubi.headPoint.x, y:st.rokurokubi.headPoint.y };
    return token;
  }
  function runSkillAgainstTarget(token, skillName, targetNumber) {
    const character=linkedCharacter(token),npc=linkedNpc(token);
    let sides=6,bonus=0;
    if(character){const profile=characterSkillProfileDetailed(character,skillName,true)||{};sides=dieSides(profile.cube||profile.die||'1d6',6);bonus=Math.round(safeNumber(profile.bonus,0));}
    else if(npc){sides=dieSides(npc.successDie||'1d6',6);const map={'Стойкость':'endurance','Акробатика':'dexterity','Физическая сила':'strength','Воля':'will','Убеждение':'charisma','Интуиция':'charisma'};bonus=Math.round(safeNumber(npc.characteristics?.[map[skillName]||'endurance'],0));}
    else return null;
    const rolls=[rollOne(sides)],rt=actionHost(token)?._battlemapAberration||{};if(rt.forceNextReroll){rolls.push(rollOne(sides));delete rt.forceNextReroll;}const roll=rolls[rolls.length-1],target=Math.max(0,Math.round(safeNumber(targetNumber,0))),feature=consumeFeatureEffect(token,'nextCheck');
    bonus+=Math.round(safeNumber(feature?.flat,0));let featureRoll=0,baseTotal=roll+bonus;
    if(feature?.extraDie&&(!feature.afterFailure||baseTotal<target))featureRoll=rollOne(feature.extraDie);
    const total=baseTotal+featureRoll;
    const formulaParts=[rollSequenceFormula(`1d${sides}`,0,rolls.length>1)];if(featureRoll)formulaParts.push(`+1d${feature.extraDie}`);const formulaBonus=signedFormulaBonus(bonus);if(formulaBonus)formulaParts.push(formulaBonus);
    return{skillName,sides,rolls:[...rolls,...(featureRoll?[featureRoll]:[])],roll,bonus:bonus+featureRoll,baseBonus:bonus,baseTotal,total,target,success:total>=target,forcedReroll:rolls.length>1,featureEffect:feature,extraRolls:featureRoll?[{name:feature.sourceName||'Особенность',die:`1d${feature.extraDie}`,roll:featureRoll}]:[],formula:`${formulaParts.join(' ')} vs ${target}`};
  }


  function woundSeverityScore(wounds) {
    const weights={light:1,medium:3,serious:8,critical:20};
    return (wounds||[]).reduce((sum,wound)=>sum+(weights[wound]||0),0);
  }
  function markCharacterChanged(token, sourceClientId = null) {
    const character=linkedCharacter(token); if(!character)return;
    character.revision=Math.max(0,Number(character.revision||0))+1;character.updatedAt=nowIso();
    if (broadcastCharacterUpdated) broadcastCharacterUpdated(character,sourceClientId);
  }
  function beastStateLabel(value) { return value==='full'?'Полный срыв':value==='breakdown'?'Звериный срыв':'Контроль'; }
  function runSkillAgainstDifficulty(token, skillName, difficultySides, { hindrance=false, advantage=false, combatContext=true } = {}) {
    const character=linkedCharacter(token);if(!character)return null;
    const profile=characterSkillProfileDetailed(character,skillName,combatContext)||{};
    const successSides=dieSides(profile.cube||profile.die||'1d6',6),successRolls=[rollOne(successSides)];let successRoll=successRolls[0],bonus=Math.round(safeNumber(profile.bonus,0));
    const host=actionHost(token),forced=host?._battlemapForcedCondition;if(forced?.uses>0){if(forced.mode==='advantage')advantage=true;else if(forced.mode==='hindrance')hindrance=true;forced.uses-=1;if(forced.uses<=0)delete host._battlemapForcedCondition;}
    const abrt=host?._battlemapAberration;let superPlanRoll=0;if(abrt?.nextCheckPenalty){bonus+=Number(abrt.nextCheckPenalty);delete abrt.nextCheckPenalty;}if(abrt?.superPlanActive){superPlanRoll=rollOne(4);bonus+=superPlanRoll;}if(abrt?.nextCheckAdvantage){advantage=true;delete abrt.nextCheckAdvantage;}
    const feature=consumeFeatureEffect(token,'nextCheck');bonus+=Math.round(safeNumber(feature?.flat,0));if(feature?.condition==='advantage')advantage=true;else if(feature?.condition==='hindrance')hindrance=true;
    const advantages=[...(Array.isArray(profile.advantages)?profile.advantages:[])],hindrances=[...(Array.isArray(profile.hindrances)?profile.hindrances:[])];
    if(abrt?.cancelNextHindrance&&(hindrance||hindrances.length)){hindrance=false;hindrances.length=0;advantages.push('Предвидение: помеха отменена');delete abrt.cancelNextHindrance;}
    if(abrt?.forceNextReroll){successRolls.push(rollOne(successSides));successRoll=successRolls[successRolls.length-1];delete abrt.forceNextReroll;}
    if(advantage)advantages.push(feature?.condition==='advantage'?(feature.sourceName||'Особенность'):'Преимущество по условию вида');
    if(hindrance)hindrances.push(feature?.condition==='hindrance'?(feature.sourceName||'Особенность'):'Помеха по условию вида');
    const condition=combineCondition('normal',advantages,hindrances),orders=[4,6,8,10,12];
    let effectiveSides=orders.includes(Number(difficultySides))?Number(difficultySides):6,difficultyRolls=[];
    if(condition==='advantage'){
      if(effectiveSides===4){difficultyRolls=[rollOne(4),rollOne(4)];}
      else effectiveSides=orders[Math.max(0,orders.indexOf(effectiveSides)-1)];
    }else if(condition==='hindrance'){
      if(effectiveSides===12){difficultyRolls=[rollOne(12),rollOne(12)];}
      else effectiveSides=orders[Math.min(orders.length-1,orders.indexOf(effectiveSides)+1)];
    }
    if(!difficultyRolls.length)difficultyRolls=[rollOne(effectiveSides)];
    const difficultyRoll=condition==='advantage'&&effectiveSides===4?Math.min(...difficultyRolls):condition==='hindrance'&&effectiveSides===12?Math.max(...difficultyRolls):difficultyRolls[0];
    const baseSuccessTotal=successRoll+bonus;let featureRoll=0;if(feature?.extraDie&&(!feature.afterFailure||baseSuccessTotal<difficultyRoll))featureRoll=rollOne(feature.extraDie);const successTotal=baseSuccessTotal+featureRoll,success=successTotal>=difficultyRoll;
    let outcome=success?'success':'failure';
    if(successRoll===difficultyRoll&&successSides>effectiveSides)outcome='critical-success';
    else if(successRoll===difficultyRoll&&effectiveSides>successSides)outcome='critical-failure';
    const explicitExtraRolls=[...(superPlanRoll?[{name:'Сверхинтеллект II: план',die:'1d4',roll:superPlanRoll}]:[]),...(featureRoll?[{name:feature.sourceName||'Особенность',die:`1d${feature.extraDie}`,roll:featureRoll}]:[])];
    return {skillName,success,successDie:`1d${successSides}`,successRolls:[...successRolls,...explicitExtraRolls.map(item=>item.roll)],successRoll,bonus:bonus+featureRoll,baseBonus:bonus-superPlanRoll,baseSuccessTotal,successTotal,difficultyDie:difficultyRolls.length>1?`2d${effectiveSides}`:`1d${effectiveSides}`,difficultySides:effectiveSides,difficultyRolls,difficultyRoll,condition,outcome,advantages,hindrances,hindrance:condition==='hindrance',forcedReroll:successRolls.length>1,featureEffect:feature,extraRolls:explicitExtraRolls};
  }

  function applyWerewolfBeastCheckOutcome(token, check) {
    const st=speciesStateForToken(token);if(!st||st.species!=='werewolf'||!st.werewolf?.transformed||!check)return check;
    if(check.success){st.werewolf.beastState='calm';st.werewolf.beastFailures=0;removeSpeciesEffect(st,'werewolfBeast');}
    else {st.werewolf.beastFailures=Math.max(1,Math.round(safeNumber(st.werewolf.beastFailures,0))+1);st.werewolf.beastState=st.werewolf.beastFailures>=3?'full':'breakdown';setSpeciesEffect(st,'werewolfBeast',beastStateLabel(st.werewolf.beastState),'Не менее 2 ОД в ход нужно тратить на приближение к живой цели, атаку или пожирание добычи.',{roundAction:false});}
    check.state=st.werewolf.beastState;check.failures=st.werewolf.beastFailures;return check;
  }
  function runWerewolfBeastCheck(token, reason='триггер Зверя', { hindrance=false, applyOutcome=true } = {}) {
    const st=speciesStateForToken(token);
    if(st?.species!=='werewolf'||!st.werewolf.transformed)return null;
    const check=runSkillAgainstDifficulty(token,'Воля',8,{hindrance,combatContext:true});if(!check)return null;
    check.reason=reason;
    return applyOutcome?applyWerewolfBeastCheckOutcome(token,check):check;
  }
  async function resolveWerewolfBeastCheck(scene,token,reason,body={},options={}){
    const check=runWerewolfBeastCheck(token,reason,{hindrance:Boolean(options.hindrance),applyOutcome:false});if(!check)return{check:null,roll:null};
    let roll=storeSpeciesCheckRoll(scene,token,check,body,options.label||`${token.name}: Проверка Зверя`,{reactionSafe:true});
    if(roll){roll=await awaitCheckRollResolution(scene,roll);syncCheckFromReactionRoll(check,roll);}
    applyWerewolfBeastCheckOutcome(token,check);return{check,roll};
  }
  function makeSpeciesCheckRoll(scene, token, check, body, label, options = {}) {
    if(!check)return null;const outcome=check.outcome||(check.success?'success':'failure');
    const extraRolls=Array.isArray(check.extraRolls)?check.extraRolls:[],extraSum=extraRolls.reduce((sum,item)=>sum+Math.round(safeNumber(item?.roll,0)),0),baseBonus=Math.round(safeNumber(check.baseBonus,safeNumber(check.bonus,0)-extraSum));
    const successBase=check.forcedReroll?rollSequenceFormula(check.successDie||'1d6',0,true):String(check.successDie||'1d6');
    const successParts=[successBase,...extraRolls.map(item=>`+${String(item?.die||'1d4')}`)];const successBonus=signedFormulaBonus(baseBonus);if(successBonus)successParts.push(successBonus);
    const difficultyModifier=Math.round(safeNumber(check.difficultyModifier,0)),difficultyLabel=String(check.difficultyDie||'1d6')+(String(check.difficultyDie||'').startsWith('2d')?` (${check.condition==='advantage'?'лучший/меньший':'худший/больший'})`:'')+signedFormulaBonus(difficultyModifier);
    const formula=`${successParts.join(' ')} vs ${difficultyLabel}`;
    return {id:makeId('roll'),at:nowIso(),actorId:cleanId(body?.clientId,null),actorName:cleanName(body?.playerName,'Участник'),sceneId:scene?.id||null,tokenId:token?.id||null,characterId:linkedCharacter(token)?.id||null,characterName:token?.name||'',label:cleanText(label||`${token?.name||'Персонаж'}: ${check.skillName||'проверка'}`,200),visibility:'public',kind:'check',opposed:Boolean(check.opposed),skillName:check.skillName||'Воля',difficultySkillName:check.difficultySkillName||null,difficultyTokenId:check.difficultyTokenId||null,difficultyTokenName:check.difficultyTokenName||null,formula,rolls:check.successRolls||[check.successRoll],modifier:check.bonus,total:check.successTotal,successDie:check.successDie,successRoll:check.successRoll,successBonus:check.bonus,successTotal:check.successTotal,difficultyDie:check.difficultyDie,difficultyRolls:check.difficultyRolls||[check.difficultyRoll],difficultyRoll:check.difficultyRoll,difficultyModifier,difficultyTotal:safeNumber(check.difficultyTotal,check.difficultyRoll),condition:check.condition||'normal',outcome,margin:check.successTotal-safeNumber(check.difficultyTotal,check.difficultyRoll),breakdown:[],advantages:check.advantages||[],hindrances:check.hindrances||[],chosenOptions:[],extraRolls,reactionSafe:Boolean(options.reactionSafe),reactionExpiresAt:null,appliedReactionKeys:[]};
  }
  function storeSpeciesCheckRoll(scene, token, check, body, label, options = {}) {
    const roll=makeSpeciesCheckRoll(scene,token,check,body,label,options);if(!roll)return null;const campaign=getCampaign();campaign.diceLog.push(roll);if(campaign.diceLog.length>200)campaign.diceLog.splice(0,campaign.diceLog.length-200);if(broadcastDice)broadcastDice(roll);return roll;
  }
  function tokenOwnerId(token, scene = null) {
    // A character sheet assignment is authoritative. Tokens can outlive an
    // old assignment and therefore may still contain a stale ownerId.
    if (token?.kind === 'character') {
      const character = linkedCharacter(token);
      if (character) return character.ownerId || token.ownerId || null;
    }
    // The current driver controls the vehicle. This also lets the player see
    // and select it while their own character token is hidden inside it.
    if (token?.kind === 'vehicle' && token.vehicle?.driverTokenId) {
      const parentScene = scene || state?.scenes?.find(item => item.tokens?.some(candidate => candidate.id === token.id));
      const driver = findToken(parentScene, token.vehicle.driverTokenId);
      if (driver) return tokenOwnerId(driver, parentScene);
    }
    return token?.ownerId || null;
  }
  function canControlToken(token, req, requestUrl, body) {
    if (isMasterAuthorized(req, requestUrl, body)) return true;
    if (state?.masterPause?.active) return false;
    const clientId = cleanId(body?.clientId || requestUrl.searchParams.get('clientId'), null);
    return Boolean(clientId && tokenOwnerId(token) === clientId);
  }

  function fogOpContains(op, point) {
    if (!op || !point) return false;
    if (op.shape === 'rect') {
      const x1 = Math.min(op.x, op.x + op.width), x2 = Math.max(op.x, op.x + op.width);
      const y1 = Math.min(op.y, op.y + op.height), y2 = Math.max(op.y, op.y + op.height);
      return point.x >= x1 && point.x <= x2 && point.y >= y1 && point.y <= y2;
    }
    if (op.shape === 'circle') return Math.hypot(point.x - op.x, point.y - op.y) <= op.radius;
    return (op.points || []).some(sample => Math.hypot(point.x - sample.x, point.y - sample.y) <= op.radius);
  }

  function manualFogOverride(scene, point) {
    let result = null;
    for (const op of scene.fog?.ops || []) if (fogOpContains(op, point)) result = op.mode === 'reveal';
    return result;
  }

  function segmentCirclePassage(from,to,center,radiusPx){
    const dx=to.x-from.x,dy=to.y-from.y,length=Math.hypot(dx,dy);if(length<=.0001)return null;
    const ux=dx/length,uy=dy/length,cx=center.x-from.x,cy=center.y-from.y,projection=cx*ux+cy*uy,perp2=Math.max(0,cx*cx+cy*cy-projection*projection),r2=radiusPx*radiusPx;
    if(perp2>r2)return null;const half=Math.sqrt(Math.max(0,r2-perp2)),entry=Math.max(0,projection-half),exit=Math.min(length,projection+half);if(exit<=entry+.0001)return null;
    return{entry,exit,length:exit-entry,total:length,mid:{x:from.x+ux*((entry+exit)/2),y:from.y+uy*((entry+exit)/2)}};
  }
  function effectOriginPoint(effect){return effect?.shape==='cone'?{x:safeNumber(effect.originX,effect.x),y:safeNumber(effect.originY,effect.y)}:{x:safeNumber(effect?.x,0),y:safeNumber(effect?.y,0)};}
  function effectSpreadBlocked(scene,effect,point){return contactBlockedByWall(scene,effectOriginPoint(effect),point);}
  function effectOccupiesPoint(scene,effect,point){
    if(!effect||effect.remainingRounds<=0)return false;
    if(effect.shape==='cone')return pointInsideConePixels({x:effect.originX,y:effect.originY},{x:effect.aimX,y:effect.aimY},point,feetToScenePixels(scene,effect.coneFeet),effect.coneAngle,0)&&!effectSpreadBlocked(scene,effect,point);
    if(distanceFeet(scene,point,{x:effect.x,y:effect.y})>effect.radius+.01)return false;
    return !effectSpreadBlocked(scene,effect,point);
  }
  function viewerCanSeePoint(scene, viewer, point) {
    if (!viewer?.vision?.enabled || viewer.defeated) return false;
    viewer = speciesCombatPoint(viewer);
    if(viewer.boardedVehicleId){const vehicle=findToken(scene,viewer.boardedVehicleId);if(vehicle)viewer={...viewer,x:vehicle.x,y:vehicle.y};}
    const px = Math.hypot(point.x - viewer.x, point.y - viewer.y);
    const feet = px / Math.max(1, scene.grid.size) * scene.grid.feet;
    let visionRange = Math.max(0, safeNumber(viewer.vision.range, 60));
    for (const effect of scene.effects || []) {
      if (effect.visualOnly || effect.remainingRounds <= 0 || !effect.visionLimit) continue;
      const limit=Math.max(0,safeNumber(effect.visionLimit,0));if(!limit)continue;
      if(effectOccupiesPoint(scene,effect,viewer)){visionRange=Math.min(visionRange,limit);continue;}
      if(effect.shape!=='circle')continue;
      const passage=segmentCirclePassage(viewer,point,{x:effect.x,y:effect.y},feetToScenePixels(scene,effect.radius));if(!passage)continue;
      if(effectSpreadBlocked(scene,effect,passage.mid))continue;
      const cloudFeet=passage.length/Math.max(1,scene.grid.size)*scene.grid.feet;
      if(cloudFeet+0.01>=limit)return false;
    }
    if (feet > visionRange) return false;
    const angle = clamp(safeNumber(viewer.vision.angle, 360), 1, 360);
    if (angle < 359.9) {
      const targetAngle = Math.atan2(point.y - viewer.y, point.x - viewer.x) * 180 / Math.PI + 90;
      const delta = Math.abs((((targetAngle - viewer.rotation) % 360) + 540) % 360 - 180);
      if (delta > angle / 2) return false;
    }
    return !lineBlocked(scene, viewer, point);
  }


  const ABERRATION_GIFT_NAMES=['Сверхинтеллект','Телекинез','Краткосрочная невидимость','Предвидение','Манипуляция сознанием','Гипноз','Невероятная сила','Невероятная ловкость','Парение'];
  function ensureAberrationRuntime(st){if(!st||typeof st!=='object')return null;st.aberrations=Array.isArray(st.aberrations)?st.aberrations:[];st.aberrationRanks=st.aberrationRanks&&typeof st.aberrationRanks==='object'?st.aberrationRanks:{};st.aberrationTension=Math.max(0,Math.round(safeNumber(st.aberrationTension,0)));st._battlemapAberration=st._battlemapAberration&&typeof st._battlemapAberration==='object'?st._battlemapAberration:{};return st._battlemapAberration;}
  function aberrationStateForToken(token){if(token?.kind!=='character')return null;const st=linkedCharacter(token)?.state;if(!st)return null;const rt=ensureAberrationRuntime(st);return{gifts:st.aberrations.filter(name=>ABERRATION_GIFT_NAMES.includes(name)),ranks:clone(st.aberrationRanks),tension:st.aberrationTension,runtime:clone(rt)};}
  function giftRankForToken(token,gift){const st=linkedCharacter(token)?.state||{};if(!Array.isArray(st.aberrations)||!st.aberrations.includes(gift))return 0;return clamp(Math.round(safeNumber(st.aberrationRanks?.[gift],1)),1,3);}
  function applyAberrationTension(scene,token,rank,body){
    const character=linkedCharacter(token),st=character?.state;if(!st)return null;ensureAberrationRuntime(st);st.aberrationTension=Math.max(0,Math.round(safeNumber(st.aberrationTension,0))+rank);
    const willCheck=st.aberrationTension>=3?runSkillAgainstDifficulty(token,'Воля',8,{combatContext:true}):null;
    return{tension:st.aberrationTension,willCheck,breakdown:null};
  }
  async function applyAberrationBreakdown(scene,token,tensionResult,body={}){
    const character=linkedCharacter(token),st=character?.state,check=tensionResult?.willCheck;if(!st||!check||check.success)return null;const rt=ensureAberrationRuntime(st),breakdownRoll=await resolveScalarRoll(scene,token,{body,label:`${token.name}: Срыв Дара — таблица эффекта`,sides:6,kind:'aberration-breakdown',purpose:'aberration-breakdown'}),d6=breakdownRoll.value,breakdown={roll:d6,rollRecord:breakdownRoll.roll};
    if(d6===1)rt.nextCheckPenalty=-2;
    else if(d6===2){st.morale=st.morale||{current:0,max:0};const moraleRoll=await resolveScalarRoll(scene,token,{body,label:`${token.name}: Срыв Дара — потеря морали`,sides:8,kind:'aberration-breakdown-morale',purpose:'morale-loss'}),loss=moraleRoll.total;st.morale.current=Math.max(0,safeNumber(st.morale.current,0)-loss);breakdown.moraleLoss=loss;breakdown.moraleRoll=moraleRoll.roll;}
    else if(d6===4){directWound(token,'light');rt.odPenaltyUntilRest=1;const info=tokenOd(token);if(info)info.host[info.currentKey]=Math.max(0,info.current-1);}
    else if(d6===5)rt.lockedUntilDay=true;
    else if(d6===3)breakdown.gmComplication=true;
    else if(d6===6)breakdown.lossOfControl=true;
    st.aberrationTension=Math.max(2,st.aberrationTension-1);tensionResult.tension=st.aberrationTension;tensionResult.breakdown=breakdown;return breakdown;
  }
  async function resolveAberrationTension(scene,token,rank,body={}){
    const result=applyAberrationTension(scene,token,rank,body);if(!result)return null;
    if(result.willCheck){
      let roll=storeSpeciesCheckRoll(scene,token,result.willCheck,body,`${token.name}: Воля против Срыва Дара`,{reactionSafe:true});
      if(roll){roll=await awaitCheckRollResolution(scene,roll);syncCheckFromReactionRoll(result.willCheck,roll);}result.willRoll=roll;
      if(!result.willCheck.success)await applyAberrationBreakdown(scene,token,result,body);
    }
    return result;
  }
  function makeOpposedCheckFromProfiles(source,target,sourceProfile,targetProfile,skillName,difficultySkillName='Воля'){
    if(!sourceProfile||!targetProfile)return null;
    const successRoll=rollOne(sourceProfile.sides),difficultyRoll=rollOne(targetProfile.sides),successTotal=successRoll+Math.round(safeNumber(sourceProfile.bonus,0)),difficultyTotal=difficultyRoll+Math.round(safeNumber(targetProfile.bonus,0)),success=successTotal>=difficultyTotal;let outcome=success?'success':'failure';
    if(successRoll===difficultyRoll&&sourceProfile.sides>targetProfile.sides)outcome='critical-success';else if(successRoll===difficultyRoll&&targetProfile.sides>sourceProfile.sides)outcome='critical-failure';
    return{opposed:true,skillName,difficultySkillName,difficultyTokenId:target?.id||null,difficultyTokenName:target?.name||'',success,successDie:`1d${sourceProfile.sides}`,successRolls:[successRoll],successRoll,bonus:Math.round(safeNumber(sourceProfile.bonus,0)),baseBonus:Math.round(safeNumber(sourceProfile.bonus,0)),baseSuccessTotal:successTotal,successTotal,difficultyDie:`1d${targetProfile.sides}`,difficultySides:targetProfile.sides,difficultyRolls:[difficultyRoll],difficultyRoll,difficultyModifier:Math.round(safeNumber(targetProfile.bonus,0)),difficultyTotal,condition:'normal',outcome,advantages:sourceProfile.advantages||[],hindrances:sourceProfile.hindrances||[],defenseAdvantages:targetProfile.advantages||[],defenseHindrances:targetProfile.hindrances||[],extraRolls:[]};
  }
  function runOpposedSkillCheck(source,target,skillName,difficultySkillName='Воля'){
    return makeOpposedCheckFromProfiles(source,target,opposedSkillProfile(source,skillName,true),opposedSkillProfile(target,difficultySkillName,true),skillName,difficultySkillName);
  }
  async function resolveOpposedSkillCheck(scene,source,target,skillName,difficultySkillName,body={},label=null,profiles=null){
    const check=profiles?makeOpposedCheckFromProfiles(source,target,profiles.source,profiles.target,skillName,difficultySkillName):runOpposedSkillCheck(source,target,skillName,difficultySkillName);if(!check)return{check:null,roll:null,success:false,source:null,target:null};
    let roll=storeSpeciesCheckRoll(scene,source,check,body,label||`${source.name}: ${skillName} против ${difficultySkillName} — ${target.name}`,{reactionSafe:true});if(roll){roll=await awaitCheckRollResolution(scene,roll);syncCheckFromReactionRoll(check,roll);}
    return{check,roll,success:check.success,source:{sides:dieSides(check.successDie,6),roll:check.successRoll,baseBonus:check.bonus,total:check.successTotal},target:{sides:dieSides(check.difficultyDie,6),roll:check.difficultyRoll,baseBonus:check.difficultyModifier,total:check.difficultyTotal}};
  }
  function fixedDifficultySkillCheck(token,skillName,targetNumber){
    const raw=runSkillAgainstTarget(token,skillName,targetNumber);if(!raw)return null;const target=Math.max(0,Math.round(safeNumber(targetNumber,0))),success=raw.total>=target;
    return{skillName,success,successDie:`1d${raw.sides||dieSides(raw.formula,6)}`,successRolls:Array.isArray(raw.rolls)?[...raw.rolls]:[raw.roll],successRoll:raw.roll,bonus:Math.round(safeNumber(raw.bonus,0)),baseBonus:Math.round(safeNumber(raw.baseBonus,raw.bonus)),baseSuccessTotal:Math.round(safeNumber(raw.baseTotal,raw.total)),successTotal:Math.round(safeNumber(raw.total,0)),difficultyDie:`Порог ${target}`,difficultySides:0,difficultyRolls:[],difficultyRoll:target,difficultyModifier:0,difficultyTotal:target,condition:'normal',outcome:success?'success':'failure',advantages:[],hindrances:[],extraRolls:Array.isArray(raw.extraRolls)?raw.extraRolls:[]};
  }
  function makeAberrationAttack(scene,attacker,target,{body={},label='Аберрантная атака',kind='aberration-attack',sides=6,damage=0,damageTag='medium'}={}){
    const hitSides=Math.max(2,Math.round(safeNumber(sides,6))),attackRoll=rollOne(hitSides),targetMz=tokenBaseMz(target),total=attackRoll,hit=total>=targetMz,at=nowIso(),id=makeId('attack'),weapon={id:`aberration-${cleanText(label,80).toLowerCase().replace(/[^a-zа-я0-9]+/gi,'-')}`,name:label,profile:label,type:'Аберрантность',hitDieNormal:`1d${hitSides}`,hitBonus:0,damage,damageTag,range:999,odCost:0,obCost:0,description:'Атака Даром Аберранта.'};
    return{id,at,sceneId:scene?.id||null,kind,actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,attacker?.name||'Участник'),visibility:'public',label:`${attacker?.name||'Персонаж'}: ${label} → ${target?.name||'цель'}`,attackerTokenId:attacker?.id||null,attackerName:attacker?.name||'',targetTokenId:target?.id||null,targetName:target?.name||'',weapon,hitDie:`1d${hitSides}`,reactionRollMode:0,attackRolls:[attackRoll],rolls:[attackRoll],roll:attackRoll,baseHitBonus:0,hitBonus:0,modifier:0,total,targetMz,margin:total-targetMz,hit,damage,damageTag,damageTargetTokenId:hit?target?.id:null,damageTargetName:hit?target?.name:null,conditionalReasons:[],flags:{aberration:true}};
  }
  async function resolveAberrationAttack(scene,attacker,target,options={}){
    let attack=makeAberrationAttack(scene,attacker,target,options),roll=combatRollRecord(scene,attacker,attack,options.label||'Аберрантная атака');roll=await awaitAttackRollResolution(scene,roll);attack=roll.battlemapAttack;return{attack,roll};
  }
  function pushTokenAway(source,target,feet,scene){const from={x:target.x,y:target.y},dx=target.x-source.x,dy=target.y-source.y,length=Math.max(.001,Math.hypot(dx,dy)),px=feetToScenePixels(scene,feet),desired={x:target.x+dx/length*px,y:target.y+dy/length*px},next=farthestFreeTokenPoint(scene,target,from,desired);target.x=next.x;target.y=next.y;}

  function tokenVisibleForClient(scene, token, clientId) {
    if (tokenOwnerId(token, scene) === clientId) return true;
    if (mainTraitViewerHasMark(scene, clientId, token)) return true;
    const mode = scene.settings.fogEnabled === false ? 'off' : scene.settings.fogMode;
    if (mode === 'off') return true;
    const override = manualFogOverride(scene, token);
    const manualVisible = override === null ? scene.fog?.baseHidden === false : override;
    if (mode === 'manual') return manualVisible;
    const viewers = scene.tokens.filter(candidate => tokenOwnerId(candidate, scene) === clientId && candidate.vision?.enabled !== false && !candidate.defeated);
    const inVision = scene.settings.visionEnabled !== false && viewers.some(viewer => viewerCanSeePoint(scene, viewer, token));
    if (mode === 'vision') return inVision;
    if (override === false) return false;
    if (override === true) return true;
    return inVision;
  }

  function hiddenTokenName(token) {
    if (token?.kind === 'character') return 'Неизвестный персонаж';
    if (token?.kind === 'npc') return 'Неизвестный NPC';
    if (token?.kind === 'vehicle') return 'Неизвестный транспорт';
    if (token?.kind === 'interactive') return 'Неизвестный объект';
    return 'Неизвестный токен';
  }
  function tokenNameForMode(token, mode = 'player') {
    return mode !== 'master' && token?.display?.showName === false ? hiddenTokenName(token) : token?.name;
  }
  function publicTableLogEntry(entry, mode = 'player') {
    const result = clone(entry);
    if (mode === 'master') return result;
    const hidden = (state.scenes || []).flatMap(scene => scene.tokens || []).filter(token => token?.display?.showName === false && token?.name);
    hidden.sort((a,b) => String(b.name).length - String(a.name).length);
    for (const token of hidden) {
      const actual=String(token.name),alias=hiddenTokenName(token);
      if(actual.length<2)continue;
      result.actorName=String(result.actorName||'').split(actual).join(alias);
      result.text=String(result.text||'').split(actual).join(alias);
    }
    return result;
  }

  function publicToken(token, mode, clientId, scene = null) {
    const parentScene=scene || state?.scenes?.find(candidate => candidate.tokens?.some(item => item.id === token.id)) || null;
    const owner = tokenOwnerId(token, parentScene);
    const stealth=stealthRuntime(token,false);
    if (mode !== 'master' && token.hidden && owner !== clientId) return null;
    const visibleByMark=mode!=='master'&&owner!==clientId&&mainTraitViewerHasMark(parentScene,clientId,token);
    if (mode !== 'master' && owner !== clientId && stealth?.hideFromPlayers && isStealthed(token) && !visibleByMark) return null;
    const result = clone(token);
    result.ownerId = owner;
    if (mode !== 'master' && token.display?.showName === false) { result.name = hiddenTokenName(token); result.nameHidden = true; }
    const visibleWeapons = weaponsForToken(token);
    const zoneFireWeapons = visibleWeapons.filter(weapon => weaponIsRanged(weapon) && (!weaponIsHeavy(weapon) || heavyWeaponState(token, weapon, true)?.loaded !== false) && weapon.loaded!==false && (weapon.specialRangedKind!=='bow'||weapon.drawn===true));
    result.zoneFireRange = zoneFireWeapons.reduce((maximum, weapon) => Math.max(maximum, safeNumber(weapon.range, 0)), 0);
    if (mode === 'master' || owner === clientId) {
      result.weapons = visibleWeapons; result.movement = movementSummary(token);
      const sniper=publicSniperRuntime(parentScene,token);if(sniper)result.sniperRuntime=sniper;
      if(stealth)result.stealthRuntime={active:isStealthed(token),inCombat:isCombatStealthed(token,parentScene),difficultySides:Math.max(4,Math.round(safeNumber(stealth.difficultySides,6))),difficultyModifier:Math.round(safeNumber(stealth.difficultyModifier,0)),hideFromPlayers:Boolean(stealth.hideFromPlayers),grantedWithoutCheck:Boolean(stealth.grantedWithoutCheck),lastCheckAt:stealth.lastCheckAt||null,lastOutcome:stealth.lastOutcome||null};
    }
    const st=speciesStateForToken(token);if(st)result.speciesRuntime={species:st.species,pallid:clone(st.pallid),werewolf:clone(st.werewolf),rokurokubi:clone(st.rokurokubi),conditions:clone(speciesConditions(token)),naturalWeapons:clone(speciesNaturalWeapons(token))};
    const ab=aberrationStateForToken(token);if(ab)result.aberrationRuntime=clone(ab);
    result.criticalRuntime=clone(criticalState(token));delete result.criticalRuntime.host;delete result.criticalRuntime.medical;delete result.criticalRuntime.wounds;
    if(['character','npc'].includes(token.kind)){
      result.baseMz=tokenBaseMz(token);
      result.grenadeThrowRange=grenadeThrowRange(token);
    }
    if(mode!=='master'&&token.kind==='interactive'){
      // Игроку нужен только физический результат объекта, но не мастерские
      // параметры ловушки (урон, радиусы, тип/длительность зоны и звуковые ID).
      result.interactive={active:token.interactive?.active!==false,triggered:Boolean(token.interactive?.triggered),coverMz:Math.max(0,Math.round(safeNumber(token.interactive?.coverMz,0)))};
    }
    if (mode !== 'master') { result.notes = ''; delete result.gmNarrative; delete result.ai; }
    return result;
  }

  function publicSceneTokens(scene, mode, clientId) {
    const combatHere=Boolean(state.combat?.active&&state.combat.sceneId===scene.id);
    const campaign=getCampaign(),activeEntry=combatHere?campaign.initiative?.entries?.[campaign.initiative.currentIndex||0]:null;
    const activeToken=combatHere?initiativeToken(scene,activeEntry):null;
    return scene.tokens.filter(token => mode === 'master' || tokenVisibleForClient(scene, token, clientId)).map(token => {
      const publicResult=publicToken(token, mode, clientId, scene);
      if(publicResult&&combatHere&&['character','npc'].includes(token.kind))publicResult.combatMz=combatMzBreakdown(scene,token,activeToken);
      return publicResult;
    }).filter(Boolean);
  }

  function publicParallax(scene, mode = 'player') {
    const config = clone(scene?.parallax || { enabled:false, strength:.35, maxShift:18, layers:[], objects:[] });
    if (mode !== 'master') {
      config.layers = (scene?.parallax?.layers || []).filter(layer => layer.showToPlayers !== false).map(layer => clone(layer));
      config.objects = (scene?.parallax?.objects || []).filter(object => object.showToPlayers !== false).map(object => clone(object));
    }
    return config;
  }

  function publicScene(scene, mode, clientId) {
    const result = clone(scene);
    result.tokens = publicSceneTokens(scene, mode, clientId);
    if (mode !== 'master') {
      result.tokenGroups = (result.tokenGroups || []).map(group => ({ id:group.id, name:group.name, color:group.color, moraleOnDeath:group.moraleOnDeath }));
      result.walls = scene.walls.map(wall => ({ id: wall.id, x1: wall.x1, y1: wall.y1, x2: wall.x2, y2: wall.y2, points: clone(wall.points || []), shape: wall.shape || 'line', closed: Boolean(wall.closed), curved: wall.curved, blocksVision: wall.blocksVision, blocksMovement: wall.blocksMovement, coverMz: wall.coverMz, coverName: wall.coverName, coverDurability: wall.coverDurability, coverDamage: wall.coverDamage, destroyed: wall.destroyed, showGeometryToPlayers: wall.showGeometryToPlayers }));
      result.doors = scene.doors.filter(door => !door.hidden).map(door => ({ ...door, name: door.name || 'Дверь' }));
      result.covers = scene.covers.filter(cover => !cover.hidden).map(cover => ({ ...cover, damage: cover.damage, durability: cover.durability }));
      if (result.parallax) result.parallax = publicParallax(scene, mode);
      result.elevationZones = (scene.elevationZones||[]).filter(zone=>zone.showToPlayers).map(zone=>clone(zone));
      result.triggerZones = (scene.triggerZones||[]).filter(zone=>zone.showToPlayers).map(zone=>({...clone(zone),insideTokenIds:[],combatTokenIds:[]}));
      result.effects = (scene.effects || []).filter(effect => !effect.hidden && (!effect.expiresAt || Date.parse(effect.expiresAt) > Date.now())).map(effect => ({ ...effect }));
      result.lights = scene.lights.filter(light => !light.hidden).map(light => ({ ...light, name: light.name || 'Источник света' }));
      // Hidden audio objects still need to reach players so their sound can be heard;
      // the client only hides the marker, not the source itself.
      result.audioSources = (scene.audioSources || []).map(source => ({ ...source }));
      result.mapWidgets = (scene.mapWidgets || []).filter(widget => widget.showToPlayers !== false).map(widget => clone(widget));
      result.fog.explored = { [clientId]: clone(scene.fog.explored?.[clientId] || []) };
    }
    return result;
  }

  function viewFor(mode, clientId) {
    const scenes = mode === 'master'
      ? state.scenes.map(scene => publicScene(scene, mode, clientId))
      : state.scenes.filter(scene => scene.id === state.activeSceneId).map(scene => publicScene(scene, mode, clientId));
    return {
      format: state.format,
      version: state.version,
      activeSceneId: state.activeSceneId,
      updatedAt: state.updatedAt,
      combat: mode === 'master' || !state.combat?.active || state.combat?.sceneId === state.activeSceneId
        ? clone(state.combat)
        : { active:false, sceneId:null, participantTokenIds:[], startedAt:null, movement:{} },
      masterPause: clone(state.masterPause || { active:false, reason:'', activatedAt:null }),
      daylight: clone(state.daylight || { dayPhase:1, daylightEnabled:true }),
      audio: audioView(),
      tableLog: (state.tableLog || []).filter(entry => mode === 'master' || entry.visibility !== 'master').slice(-300).map(entry => publicTableLogEntry(entry, mode)),
      tokenGroups: mode === 'master'
        ? clone(state.tokenGroups || [])
        : (state.tokenGroups || []).map(group => ({ id:group.id, name:group.name, color:group.color, moraleOnDeath:group.moraleOnDeath })),
      scenes
    };
  }

  function broadcast(eventName = 'battlemap-replaced', sourceClientId = null, payload = {}) {
    const deltaScene = eventName === 'battlemap-token-updated' && payload?.sceneId ? findScene(cleanId(payload.sceneId, null)) : null;
    const parallaxScene = eventName === 'battlemap-parallax-updated' && payload?.sceneId ? findScene(cleanId(payload.sceneId, null)) : null;
    for (const client of getSseClients().values()) {
      try {
        if (deltaScene) {
          if (client.mode !== 'master' && deltaScene.id !== state.activeSceneId) continue;
          sseWrite(client.response, eventName, {
            sceneId: deltaScene.id,
            sceneUpdatedAt: deltaScene.updatedAt,
            tokens: publicSceneTokens(deltaScene, client.mode, client.clientId),
            sourceClientId,
            at: nowIso(),
            ...payload
          });
          continue;
        }
        if (parallaxScene) {
          if (client.mode !== 'master' && parallaxScene.id !== state.activeSceneId) continue;
          sseWrite(client.response, eventName, {
            sceneId: parallaxScene.id,
            sceneUpdatedAt: parallaxScene.updatedAt,
            parallax: publicParallax(parallaxScene, client.mode),
            sourceClientId,
            at: nowIso()
          });
          continue;
        }
        sseWrite(client.response, eventName, {
          battlemap: viewFor(client.mode, client.clientId),
          sourceClientId,
          at: nowIso(),
          ...payload
        });
      } catch {}
    }
  }


  function broadcastTransientEffect(sceneId, effect, ttlMs = 8000, sourceClientId = null) {
    const safeTtl = clamp(Math.round(safeNumber(ttlMs, 8000)), 500, 30000);
    for (const client of getSseClients().values()) {
      try {
        sseWrite(client.response, 'battlemap-transient-effect', {
          sceneId,
          effect: clone(effect),
          ttlMs: safeTtl,
          sourceClientId,
          at: nowIso()
        });
      } catch {}
    }
  }

  function broadcastAudioEffect(sceneId, soundKey, source = {}, sourceClientId = null) {
    if (!soundKey) return;
    const payload = { sceneId, soundKey, source: clone(source), sourceClientId, at: nowIso() };
    for (const client of getSseClients().values()) {
      try { sseWrite(client.response, 'battlemap-audio-effect', payload); } catch {}
    }
  }
  function broadcastOneShotAudio(trackId,volume=1,sourceClientId=null){
    const item=audioItemById(trackId);if(!item||item.kind!=='effect')return false;
    const payload={trackId:item.id,name:item.name,volume:clamp(safeNumber(volume,1),0,1),sourceClientId,at:nowIso()};
    for(const client of getSseClients().values())try{sseWrite(client.response,'battlemap-one-shot-audio',payload);}catch{}
    return true;
  }

  function broadcastVehicleEffect(sceneId, payload = {}, sourceClientId = null) {
    if (!sceneId || !payload?.vehicleTokenId) return;
    const event = {
      id: cleanId(payload.id, makeId('vehicle-effect')),
      sceneId,
      vehicleTokenId: cleanId(payload.vehicleTokenId, null),
      action: ['drive','sharp','stabilize','gas','ram','emergency'].includes(payload.action) ? payload.action : 'drive',
      durationMs: clamp(Math.round(safeNumber(payload.durationMs, 850)), 250, 2400),
      sourceClientId,
      at: nowIso()
    };
    for (const client of getSseClients().values()) {
      try { sseWrite(client.response, 'battlemap-vehicle-effect', event); } catch {}
    }
  }

  function broadcastProjectileEffect(sceneId, payload = {}, sourceClientId = null) {
    if (!sceneId || !payload?.from || !payload?.to) return;
    const event = {
      id: cleanId(payload.id, makeId('projectile')),
      sceneId,
      kind: ['bullet','shotgun','anaxion','grenade','launcher','explosion'].includes(payload.kind) ? payload.kind : 'bullet',
      from: { x:safeNumber(payload.from.x,0), y:safeNumber(payload.from.y,0), elevation:safeNumber(payload.from.elevation,0) },
      to: { x:safeNumber(payload.to.x,0), y:safeNumber(payload.to.y,0), elevation:safeNumber(payload.to.elevation,0) },
      durationMs: clamp(Math.round(safeNumber(payload.durationMs, 420)), 120, 2200),
      hit: Boolean(payload.hit),
      explosive: payload.explosive !== false,
      effectType: ['explosive','smoke','gas','tear-gas','flash'].includes(payload.effectType) ? payload.effectType : null,
      radius: Math.max(0, safeNumber(payload.radius, 0)),
      color: cleanColor(payload.color, payload.kind === 'anaxion' ? '#b980ff' : '#ffd36a'),
      label: cleanText(payload.label, 160),
      deferExplosion:Boolean(payload.deferExplosion),
      explodeOnly:Boolean(payload.explodeOnly),
      sourceClientId,
      at: nowIso()
    };
    for (const client of getSseClients().values()) {
      try { sseWrite(client.response, 'battlemap-projectile', event); } catch {}
    }
  }

  function projectileKindForWeapon(weapon) {
    if(['bullet','shotgun','launcher','anaxion'].includes(weapon?.projectileKind))return weapon.projectileKind;
    const text = `${weapon?.type||''} ${weapon?.profile||''} ${weapon?.name||''} ${weapon?.description||''}`;
    if (/анаксион/i.test(text)) return 'anaxion';
    if (/гранатом[её]т/i.test(text)) return 'launcher';
    if (/дробовик/i.test(text)) return 'shotgun';
    return 'bullet';
  }

  function weaponSoundKey(weapon, context = {}) {
    const selectedSound=String(weapon?.soundId||'').trim();
    if(selectedSound==='off')return null;
    if(selectedSound)return `track:${selectedSound}`;
    if(weapon?.soundEffectKey)return String(weapon.soundEffectKey);
    const text = `${weapon?.type||''} ${weapon?.profile||''} ${weapon?.name||''} ${weapon?.description||''}`;
    if (/укус|\bbite\b/i.test(text)) return 'natural.bite';
    if (/когт|\bclaw/i.test(text)) return 'natural.claws';

    // For melee endpoints the action type is authoritative.  Do not try to
    // infer the sound only from the item name: canonical profiles such as
    // «Среднее оружие» or old saved items may not contain melee=true.
    const isUnarmed=Boolean(context.unarmed||weapon?.id==='unarmed'||/безоруж|кулак|пинок/i.test(text));
    const isMelee=Boolean(context.melee||context.attackKind==='melee'||context.attackKind==='melee-counter'||weaponIsMelee(weapon));
    if(isMelee)return isUnarmed?'unarmed.hit':'melee.hit';

    if (/анаксион/i.test(text)) return 'weapon.anaxion';
    if (/гранатом[её]т/i.test(text)) return 'weapon.grenadeLauncher';
    if (/тяж[её]лый пулем[её]т|пулем[её]т/i.test(text)) return 'weapon.machinegun';
    if (/дробовик/i.test(text)) return 'weapon.shotgun';
    if (/снайпер|винтовк/i.test(text)) return 'weapon.rifle';
    if (/карабин/i.test(text)) return 'weapon.carbine';
    if (/револьвер/i.test(text)) return 'weapon.revolver';
    if (/пистолет/i.test(text)) return 'weapon.pistol';
    return 'weapon.generic';
  }

  function interactiveDistanceDifficulty(distance) {
    const d=Math.max(0,safeNumber(distance,0));
    if(d<=30)return 0;
    if(d<=60)return 4;
    if(d<=120)return 6;
    if(d<=180)return 8;
    if(d<=240)return 10;
    return 12;
  }

  function interactiveAccuracyCheck(attacker, difficultySides) {
    if(!difficultySides)return {automatic:true,skillName:'Меткость',success:true,successTotal:null,difficultyTotal:null,difficultySides:0,difficultyDie:null};
    if(attacker?.kind==='character'){
      const check=runSkillAgainstDifficulty(attacker,'Меткость',difficultySides,{combatContext:true});
      if(check){check.difficultyTotal=check.difficultyRoll;return check;}
    }
    const profile=opposedSkillProfile(attacker,'Меткость',true);
    if(!profile)return null;
    const successRoll=rollOne(profile.sides),difficultyRoll=rollOne(difficultySides),successTotal=successRoll+profile.bonus;
    return {skillName:'Меткость',success:successTotal>=difficultyRoll,successDie:`1d${profile.sides}`,successRolls:[successRoll],successRoll,bonus:profile.bonus,baseBonus:profile.bonus,baseSuccessTotal:successTotal,successTotal,difficultyDie:`1d${difficultySides}`,difficultySides,difficultyRolls:[difficultyRoll],difficultyRoll,difficultyTotal:difficultyRoll,condition:'normal',outcome:successTotal>=difficultyRoll?'success':'failure',advantages:profile.advantages||[],hindrances:profile.hindrances||[],extraRolls:[]};
  }

  function interactiveObjectWeapon(scene, attacker, body) {
    assertTokenCanAct(attacker,{attack:true});
    const weapons=weaponsForToken(attacker),weapon=weapons.find(item=>item.id===body.weaponId||item.slot===body.weaponId||item.name===body.weaponId)||weapons.find(weaponIsRanged);
    if(!weapon||!weaponIsRanged(weapon))throw Object.assign(new Error('Для выстрела по интерактивному объекту нужно дальнобойное оружие.'),{statusCode:400});
    if(weapon.unavailable)throw Object.assign(new Error(weapon.unavailableReason||'Оружие недоступно.'),{statusCode:409});
    assertHeavyWeaponReady(attacker,weapon);
    const engaged=hostileMeleeOpponents(scene,attacker,speciesCombatPoint(attacker));
    if(engaged.length&&!weaponIsShotgun(weapon))throw Object.assign(new Error('В ближнем бою из огнестрельного оружия разрешены только дробовики.'),{statusCode:409});
    return weapon;
  }

  function interactiveChainCandidates(scene, sourceObject) {
    const cfg=sourceObject?.interactive;if(!scene||!cfg?.explosionEnabled||cfg.explosionDamage<=0)return [];
    const point={x:sourceObject.x,y:sourceObject.y};
    return (scene.tokens||[]).filter(token=>{
      if(!token||token.id===sourceObject.id||token.kind!=='interactive')return false;
      const target=token.interactive;if(!target?.active||target.triggered||!target.explosionEnabled||target.explosionDamage<=0)return false;
      if(distanceFeet(scene,token,point)>cfg.explosionRadius+.01)return false;
      return !explosionBlockedByWall(scene,point,token);
    });
  }

  async function triggerInteractiveObject(scene, objectToken, body = {}, { sourceToken=null, persistNow=true, chainVisited=null, chainRootId=null } = {}) {
    const cfg=objectToken?.interactive;
    if(!objectToken||objectToken.kind!=='interactive'||!cfg)throw Object.assign(new Error('Интерактивный объект не найден.'),{statusCode:404});
    if(!cfg.active||cfg.triggered)throw Object.assign(new Error(`Объект «${objectToken.name}» уже сработал или отключён.`),{statusCode:409});
    const visited=chainVisited instanceof Set?chainVisited:new Set();if(visited.has(objectToken.id))return{ok:true,objectTokenId:objectToken.id,objectName:objectToken.name,affected:[],zones:[],removed:false,chain:[],skipped:true};visited.add(objectToken.id);
    // Помечаем объект сработавшим до обхода соседей, чтобы A↔B не вызвали рекурсию.
    cfg.triggered=true;cfg.active=false;objectToken.updatedAt=nowIso();scene.updatedAt=nowIso();
    const point={x:objectToken.x,y:objectToken.y},affected=[],createdZones=[],chain=[];
    if(cfg.explosionEnabled&&cfg.explosionDamage>0){
      for(const target of [...(scene.tokens||[])]){
        if(!['character','npc','vehicle'].includes(target.kind))continue;
        const feet=distanceFeet(scene,target,point);if(feet>cfg.explosionRadius+.01)continue;
        const base=feet<=cfg.explosionRadius/2?cfg.explosionDamage:Math.floor(cfg.explosionDamage/2),wallBlocked=explosionBlockedByWall(scene,point,target),coverReduction=wallBlocked?0:explosionCoverReduction(scene,point,target),dealt=wallBlocked?0:Math.max(0,base-coverReduction);
        let result=null;if(dealt>0)result=target.kind==='vehicle'?await applyDamageToVehicle(scene,target,{...body,damage:dealt,damageTag:cfg.explosionDamageTag},{persistNow:false}):await applyDamageToTarget(scene,target,{...body,damage:dealt,damageTag:cfg.explosionDamageTag,explosive:true,sourceText:objectToken.name,bleeding:false},{persist:false,recordHistory:false,role:'system'}).catch(()=>null);
        affected.push({tokenId:target.id,name:target.name,distance:Math.round(feet*10)/10,damage:dealt,coverReduction,wallBlocked,result});
      }
      blastDamageCovers(scene,point,cfg.explosionRadius,cfg.explosionDamage,{heavy:cfg.explosionDamageTag==='heavy'});
      const visual=normalizeEffectZone({id:makeId('interactive-blast'),name:`${objectToken.name}: взрыв`,type:'explosion',x:point.x,y:point.y,radius:cfg.explosionRadius,color:'#ff9b43',opacity:.24,remainingRounds:1,visualOnly:true,pulse:true,sourceName:objectToken.name},scene.effects.length);
      broadcastTransientEffect(scene.id,visual,9000,body.clientId||null);
      if(cfg.explosionSoundId!=='off')broadcastAudioEffect(scene.id,cfg.explosionSoundId?`track:${cfg.explosionSoundId}`:'grenade.explosion',{x:point.x,y:point.y,tokenId:objectToken.id},body.clientId||null);
      // Цепная реакция: любой активный взрывоопасный объект в радиусе текущего
      // взрыва детонирует следом. Полная стена/закрытая дверь разрывает цепь.
      for(const next of interactiveChainCandidates(scene,objectToken)){
        if(visited.has(next.id))continue;
        const child=await triggerInteractiveObject(scene,next,body,{sourceToken:sourceToken||objectToken,persistNow:false,chainVisited:visited,chainRootId:chainRootId||objectToken.id});
        chain.push(child,...(child.chain||[]));
      }
    }
    if(cfg.zoneEnabled){
      const zone=normalizeEffectZone({id:makeId('interactive-zone'),name:`${objectToken.name}: опасная зона`,type:cfg.zoneType,x:point.x,y:point.y,radius:cfg.zoneRadius,color:cfg.zoneType==='smoke'?'#aab4bd':cfg.zoneType==='panic'?'#c2a45a':cfg.zoneType==='anaxion'?'#9b75d1':cfg.zoneType==='fire'?'#ff9b43':'#75b86b',mzBonus:cfg.zoneMzBonus,visionLimit:cfg.zoneVisionLimit,damage:cfg.zoneDamage,zoneDamage:cfg.zoneDamage,damageTag:cfg.zoneDamageTag,remainingRounds:cfg.zoneRounds,createdRound:getCampaign().initiative?.round||0,ownerTokenId:sourceToken?.id||null,sourceName:objectToken.name},scene.effects.length);
      scene.effects.push(zone);createdZones.push(zone);
      const visual=normalizeEffectZone({...zone,id:makeId('interactive-zone-visual'),opacity:.14,visualOnly:true,remainingRounds:1,pulse:true},scene.effects.length);
      broadcastTransientEffect(scene.id,visual,3200,body.clientId||null);
      if(cfg.zoneSoundId!=='off')broadcastAudioEffect(scene.id,cfg.zoneSoundId?`track:${cfg.zoneSoundId}`:(['smoke','gas','toxin'].includes(cfg.zoneType)?'grenade.smokeGas':'grenade.explosion'),{x:point.x,y:point.y,tokenId:objectToken.id},body.clientId||null);
    }
    const removed=Boolean(cfg.removeAfterTrigger);if(removed)scene.tokens=scene.tokens.filter(item=>item.id!==objectToken.id);
    const chainNames=chain.filter(item=>!item.skipped).map(item=>item.objectName);const entry=appendTableLog({type:'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,sourceToken?.name||'Система'),text:`Интерактивный объект «${objectToken.name}» сработал${cfg.explosionEnabled?`; взрыв ${cfg.explosionDamage} урона / ${cfg.explosionRadius} фт`:''}${cfg.zoneEnabled?`; зона ${cfg.zoneType} ${cfg.zoneRadius} фт на ${cfg.zoneRounds} раунд(а)`:''}${chainNames.length?`; цепная реакция: ${chainNames.join(', ')}`:''}.`,sceneId:scene.id,tokenId:sourceToken?.id||objectToken.id});
    if(persistNow){await persistCampaign();await persist();broadcastTableLog(entry);for(const item of chain)if(item?.entry)broadcastTableLog(item.entry);broadcast('battlemap-replaced',body.clientId||null,{reason:'interactive-triggered',sceneId:scene.id,tokenId:objectToken.id});}
    return {ok:true,objectTokenId:objectToken.id,objectName:objectToken.name,affected,zones:createdZones,removed,entry,chain};
  }

  async function resolveInteractiveShot(scene, attacker, objectToken, body, masterAuthorized=false) {
    const cfg=objectToken?.interactive;if(!cfg?.triggerOnShot)throw Object.assign(new Error('Этот интерактивный объект не настроен на срабатывание от выстрела.'),{statusCode:409});
    if(!cfg.active||cfg.triggered)throw Object.assign(new Error('Этот объект уже сработал или отключён.'),{statusCode:409});
    const weapon=interactiveObjectWeapon(scene,attacker,body),origin=speciesCombatPoint(attacker),target={x:objectToken.x,y:objectToken.y},distance=distanceFeet(scene,origin,target);
    if(contactBlockedByWall(scene,origin,target))throw Object.assign(new Error('Линия огня к объекту перекрыта стеной или закрытой дверью.'),{statusCode:409});
    if(distance>safeNumber(weapon.range,5)+.001)throw Object.assign(new Error(`Объект вне дальности оружия: ${distance.toFixed(1)} фт при максимуме ${weapon.range} фт.`),{statusCode:409});
    const difficultySides=interactiveDistanceDifficulty(distance),check=interactiveAccuracyCheck(attacker,difficultySides);
    let roll=null;
    if(check&&!check.automatic){
      roll=storeSpeciesCheckRoll(scene,attacker,check,body,`${attacker.name}: ${weapon.name} → ${objectToken.name}: Меткость`,{reactionSafe:true});
      if(roll){roll=await awaitCheckRollResolution(scene,roll);syncCheckFromReactionRoll(check,roll);}
    }
    const hit=Boolean(check?.success);
    const attack={id:makeId('interactive-shot'),at:nowIso(),actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),kind:'interactive-shot',visibility:body.visibility==='master'?'master':'public',sceneId:scene.id,attackerTokenId:attacker.id,attackerName:attacker.name,targetTokenId:objectToken.id,targetName:objectToken.name,weapon,distance:Math.round(distance*10)/10,objectTarget:true,objectCheck:check,hit,hitDie:check?.automatic?'—':check?.successDie||'1d6',roll:check?.automatic?'—':check?.successRoll||0,hitBonus:check?.automatic?0:check?.bonus||0,total:check?.automatic?'авто':check?.successTotal||0,targetMz:check?.automatic?'без проверки':check?.difficultyTotal??check?.difficultyRoll??0,baseMz:0,coverMz:0,coverSource:null,damage:0,damageTag:weapon.damageTag||'medium',flags:{interactiveObject:true},odCost:Math.max(0,safeNumber(weapon.odCost,1)),requiredOdCost:Math.max(0,safeNumber(weapon.odCost,1)),obCost:0,label:`${attacker.name}: ${weapon.name} → ${objectToken.name}`,formula:check?.automatic?'Автоматическое попадание до 30 фт':(roll?.formula||`${check.successDie}${check.bonus>=0?'+':''}${check.bonus} vs ${check.difficultyDie}`),rolls:check?.automatic?[]:(roll?.rolls||[...(check.successRolls||[check.successRoll]),...(check.difficultyRolls||[check.difficultyRoll])]),modifier:check?.automatic?0:check?.bonus||0,conditionalReasons:[check?.automatic?'До 30 фт: проверка Меткости не требуется.':`Дистанционная проверка Меткости против ${check.difficultyDie}.`]};
    // Цена атаки платится после фиксации броска, но независимо от того, попала
    // ли она. Так реакция может изменить попадание, не откатывая уже нанесённый урон.
    await spendAttackResources(attacker,attack,{...body,spendResources:body.spendResources!==false},masterAuthorized);markHeavyWeaponFired(attacker,weapon);
    broadcastProjectileEffect(scene.id,{id:attack.id,kind:projectileKindForWeapon(weapon),from:origin,to:target,durationMs:projectileDurationMs(scene,origin,target,weapon),hit,label:weapon.name},body.clientId);
    broadcastAudioEffect(scene.id,weaponSoundKey(weapon),{tokenId:attacker.id,x:attacker.x,y:attacker.y,targetTokenId:objectToken.id},body.clientId);
    let triggerResult=null;if(hit)triggerResult=await triggerInteractiveObject(scene,objectToken,body,{sourceToken:attacker,persistNow:false});
    const entry=appendTableLog({type:'roll',actorId:attack.actorId,actorName:attack.actorName,text:`${attack.label}: ${check?.automatic?'автоматическое попадание':`${check.successTotal} против ${check.difficultyTotal??check.difficultyRoll} (${check.difficultyDie})`} — ${hit?'объект сработал':'промах'}.`,visibility:attack.visibility,sceneId:scene.id,tokenId:attacker.id,meta:{attackId:attack.id,interactiveObjectId:objectToken.id,formula:attack.formula}});
    await persistCampaign();await persist();broadcastTableLog(entry);if(triggerResult?.entry)broadcastTableLog(triggerResult.entry);broadcast('battlemap-replaced',body.clientId,{reason:'interactive-shot',sceneId:scene.id,tokenId:objectToken.id});
    return {ok:true,attack,roll,entry,triggerResult};
  }

  async function recordMapHistory(body, action, entityType, entityId, summary) {
    if (!recordHistory || !persistHistory) return;
    const entry = recordHistory({
      actor: { id: cleanId(body?.clientId, null), name: cleanName(body?.playerName, 'Мастер'), role: 'master' },
      action,
      entityType,
      entityId,
      summary,
      undoData: null
    });
    await persistHistory();
    if (broadcastHistory) broadcastHistory(entry);
  }

  function segmentIntersection(a, b, c, d) {
    const orient = (p, q, r) => (q.x - p.x) * (r.y - p.y) - (q.y - p.y) * (r.x - p.x);
    const o1 = orient(a, b, c), o2 = orient(a, b, d), o3 = orient(c, d, a), o4 = orient(c, d, b);
    const epsilon = 1e-7;
    if (Math.abs(o1) < epsilon && Math.abs(o2) < epsilon && Math.abs(o3) < epsilon && Math.abs(o4) < epsilon) {
      const overlap = (a1, a2, b1, b2) => Math.max(Math.min(a1, a2), Math.min(b1, b2)) <= Math.min(Math.max(a1, a2), Math.max(b1, b2)) + epsilon;
      return overlap(a.x, b.x, c.x, d.x) && overlap(a.y, b.y, c.y, d.y);
    }
    return ((o1 > epsilon && o2 < -epsilon) || (o1 < -epsilon && o2 > epsilon)) && ((o3 > epsilon && o4 < -epsilon) || (o3 < -epsilon && o4 > epsilon));
  }

  function pointSegmentDistance(point, a, b) {
    const dx = b.x - a.x, dy = b.y - a.y;
    const length2 = dx * dx + dy * dy;
    if (length2 < 1e-12) return Math.hypot(point.x - a.x, point.y - a.y);
    const t = clamp(((point.x - a.x) * dx + (point.y - a.y) * dy) / length2, 0, 1);
    return Math.hypot(point.x - (a.x + dx * t), point.y - (a.y + dy * t));
  }

  function segmentSegmentDistance(a, b, c, d) {
    if (segmentIntersection(a, b, c, d)) return 0;
    return Math.min(pointSegmentDistance(a, c, d), pointSegmentDistance(b, c, d), pointSegmentDistance(c, a, b), pointSegmentDistance(d, a, b));
  }

  function tokenVisualFootprintScale(token) {
    // Kept as a compatibility helper: imageScale is visual-only.
    return 1;
  }
  function tokenFootprintSize(token) {
    // The explicit token Size is the single source of truth for physical space.
    return Math.max(.25, safeNumber(token?.size, 1));
  }
  function movementCollisionRadius(scene, token) {
    const cell = Math.max(8, safeNumber(scene?.grid?.size, 70));
    const baseSize = Math.max(.25, safeNumber(token?.size, 1));
    return Math.max(5, cell * baseSize * .30);
  }

  // Hitboxes, occupied grid footprint, melee contact and vehicle boarding all
  // depend on Size only. display.imageScale never changes game geometry.
  function tokenFootprintHalfSize(scene, token) {
    const cell = Math.max(8, safeNumber(scene?.grid?.size, 70));
    return cell * tokenFootprintSize(token) / 2;
  }
  function tokensMaySharePosition(a, b) {
    if (!a || !b) return true;
    if (a.boardedVehicleId || b.boardedVehicleId) return true;
    if (a.kind === 'vehicle' && b.boardedVehicleId === a.id) return true;
    if (b.kind === 'vehicle' && a.boardedVehicleId === b.id) return true;
    return false;
  }
  function tokenPositionBlocker(scene, token, point, ignoreIds = null) {
    if (!scene || !token || !point || token.boardedVehicleId) return null;
    const ignored = ignoreIds instanceof Set ? ignoreIds : new Set(Array.isArray(ignoreIds) ? ignoreIds : []);
    const halfA = tokenFootprintHalfSize(scene, token);
    for (const other of scene.tokens || []) {
      if (!other || other.id === token.id || ignored.has(other.id) || tokensMaySharePosition(token, other)) continue;
      const halfB = tokenFootprintHalfSize(scene, other), limit = halfA + halfB;
      if (Math.abs(safeNumber(point.x, token.x) - safeNumber(other.x, 0)) < limit - .5 &&
          Math.abs(safeNumber(point.y, token.y) - safeNumber(other.y, 0)) < limit - .5) return other;
    }
    return null;
  }

  function nearestFreeTokenPoint(scene, token, preferredPoint=null, ignoreIds=null) {
    if(!scene||!token)return null;
    const cell=Math.max(8,safeNumber(scene.grid?.size,70)),half=tokenFootprintHalfSize(scene,token),base={
      x:clamp(safeNumber(preferredPoint?.x,scene.mapWidth/2),half,Math.max(half,scene.mapWidth-half)),
      y:clamp(safeNumber(preferredPoint?.y,scene.mapHeight/2),half,Math.max(half,scene.mapHeight-half))
    };
    const snap=value=>scene.grid?.enabled&&scene.grid?.snap!==false?Math.round(value/cell)*cell:value;
    const candidate=(x,y)=>({x:clamp(snap(x),half,Math.max(half,scene.mapWidth-half)),y:clamp(snap(y),half,Math.max(half,scene.mapHeight-half))});
    const checked=new Set();
    for(let ring=0;ring<=40;ring++){
      const offsets=[];
      if(ring===0)offsets.push([0,0]);
      else for(let x=-ring;x<=ring;x++){offsets.push([x,-ring],[x,ring]);} 
      if(ring>0)for(let y=-ring+1;y<=ring-1;y++){offsets.push([-ring,y],[ring,y]);}
      for(const [ox,oy] of offsets){const point=candidate(base.x+ox*cell,base.y+oy*cell),key=`${Math.round(point.x*10)}:${Math.round(point.y*10)}`;if(checked.has(key))continue;checked.add(key);if(!tokenPositionBlocker(scene,token,point,ignoreIds))return point;}
    }
    return null;
  }

  function farthestFreeTokenPoint(scene, token, from, to, ignoreIds = null) {
    if (!tokenPositionBlocker(scene, token, to, ignoreIds)) return { x:to.x, y:to.y };
    let low = 0, high = 1;
    for (let i = 0; i < 14; i += 1) {
      const mid = (low + high) / 2, point = { x:from.x + (to.x - from.x) * mid, y:from.y + (to.y - from.y) * mid };
      if (tokenPositionBlocker(scene, token, point, ignoreIds)) high = mid; else low = mid;
    }
    return { x:from.x + (to.x - from.x) * low, y:from.y + (to.y - from.y) * low };
  }

  function sweptTokenHitsSegment(scene, token, from, to, segment) {
    const a = { x: segment.x1, y: segment.y1 }, b = { x: segment.x2, y: segment.y2 };
    const radius = movementCollisionRadius(scene, token);
    const startDistance = pointSegmentDistance(from, a, b);
    const endDistance = pointSegmentDistance(to, a, b);
    const sweptDistance = segmentSegmentDistance(from, to, a, b);
    if (startDistance < radius) {
      // Разрешаем токену выбраться из уже пересекающейся стены, но не углубляться и не пересекать её насквозь.
      const side = (p) => (b.x - a.x) * (p.y - a.y) - (b.y - a.y) * (p.x - a.x);
      const crossed = side(from) * side(to) < -1e-6;
      return crossed || endDistance <= startDistance + .25;
    }
    return sweptDistance < radius - .25 || endDistance < radius - .25;
  }

  function wallPoints(wall) { const source = Array.isArray(wall?.points) && wall.points.length >= 2 ? wall.points : [{x:wall.x1,y:wall.y1},{x:wall.x2,y:wall.y2}]; const points=source.map(point=>({x:safeNumber(point?.x,0),y:safeNumber(point?.y,0)})); if(wall?.closed&&points.length>=3){const first=points[0],last=points[points.length-1];if(Math.hypot(first.x-last.x,first.y-last.y)>.001)points.push({...first});} return points; }
  function wallLength(wall) { const points=wallPoints(wall); let total=0; for(let i=1;i<points.length;i++) total+=Math.hypot(points[i].x-points[i-1].x,points[i].y-points[i-1].y); return Math.max(1,total); }
  function pointOnWall(wall, t) {
    const points=wallPoints(wall), target=clamp(t,0,1)*wallLength(wall); let passed=0;
    for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],len=Math.hypot(b.x-a.x,b.y-a.y);if(passed+len>=target||i===points.length-1){const u=len?clamp((target-passed)/len,0,1):0;return{x:a.x+(b.x-a.x)*u,y:a.y+(b.y-a.y)*u};}passed+=len;}
    return {...points[points.length-1]};
  }

  function doorGeometry(scene, door) {
    const wall = door.wallId ? scene.walls.find(item => item.id === door.wallId) : null;
    if (!wall) {
      const x1 = safeNumber(door.x1, 0), y1 = safeNumber(door.y1, 0), x2 = safeNumber(door.x2, x1 + door.width), y2 = safeNumber(door.y2, y1);
      return { x1, y1, x2, y2, center: { x: (x1 + x2) / 2, y: (y1 + y2) / 2 }, wall: null, t1: 0, t2: 1 };
    }
    const length = wallLength(wall);
    const halfT = Math.min(0.49, door.width / length / 2);
    const t1 = clamp(door.t - halfT, 0, 1), t2 = clamp(door.t + halfT, 0, 1);
    const a = pointOnWall(wall, t1), b = pointOnWall(wall, t2);
    return { x1: a.x, y1: a.y, x2: b.x, y2: b.y, center: pointOnWall(wall, door.t), wall, t1, t2 };
  }

  function wallIntervalSegments(wall, t1 = 0, t2 = 1) {
    const points=wallPoints(wall), result=[], total=wallLength(wall), start=clamp(t1,0,1)*total, end=clamp(t2,0,1)*total;
    if(end<=start)return result;
    let passed=0;
    for(let i=1;i<points.length;i++){
      const a=points[i-1],b=points[i],length=Math.hypot(b.x-a.x,b.y-a.y),segStart=passed,segEnd=passed+length,from=Math.max(start,segStart),to=Math.min(end,segEnd);
      if(to>from+1e-7){const u1=length?(from-segStart)/length:0,u2=length?(to-segStart)/length:1;result.push({x1:a.x+(b.x-a.x)*u1,y1:a.y+(b.y-a.y)*u1,x2:a.x+(b.x-a.x)*u2,y2:a.y+(b.y-a.y)*u2,source:wall});}
      passed=segEnd;
    }
    return result;
  }

  function effectiveWallSegments(scene, property) {
    const segments = [];
    for (const wall of scene.walls) {
      if (!wall[property]) continue;
      const attached = scene.doors.filter(door => door.wallId === wall.id).map(door => doorGeometry(scene, door)).sort((a, b) => a.t1 - b.t1);
      let cursor = 0;
      for (const gap of attached) {
        if (gap.t1 > cursor) segments.push(...wallIntervalSegments(wall,cursor,gap.t1));
        cursor = Math.max(cursor, gap.t2);
      }
      if (cursor < 1) segments.push(...wallIntervalSegments(wall,cursor,1));
    }
    for (const door of scene.doors) {
      if (door.open) continue;
      const g = doorGeometry(scene, door);
      segments.push({ x1:g.x1,y1:g.y1,x2:g.x2,y2:g.y2,source:door,door:true });
    }
    return segments;
  }

  function pointInPolygon(point, points) {
    let inside = false;
    for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
      const a = points[i], b = points[j];
      if (((a.y > point.y) !== (b.y > point.y)) && point.x < (b.x - a.x) * (point.y - a.y) / ((b.y - a.y) || 1e-12) + a.x) inside = !inside;
    }
    return inside;
  }

  function pointInCover(point, cover) {
    if (cover.shape === 'circle') return Math.hypot(point.x - cover.x, point.y - cover.y) <= cover.radius;
    if (cover.shape === 'polygon') return cover.points.length >= 3 && pointInPolygon(point, cover.points);
    if (cover.shape === 'polyline') { const points=cover.points||[]; for(let i=1;i<points.length;i++) if(pointSegmentDistance(point,points[i-1],points[i])<=Math.max(1,safeNumber(cover.thickness,18))/2)return true; return false; }
    return point.x >= cover.x && point.x <= cover.x + cover.width && point.y >= cover.y && point.y <= cover.y + cover.height;
  }

  function lineIntersectsCover(from, to, cover) {
    if (pointInCover(from, cover) && pointInCover(to, cover)) return false;
    if (cover.shape === 'polyline') {
      const points=cover.points||[], threshold=Math.max(1,safeNumber(cover.thickness,18))/2;
      for(let i=1;i<points.length;i++) if(segmentSegmentDistance(from,to,points[i-1],points[i])<=threshold)return true;
      return pointInCover(to,cover);
    }
    if (cover.shape === 'circle') {
      const dx = to.x - from.x, dy = to.y - from.y, fx = from.x - cover.x, fy = from.y - cover.y;
      const a = dx*dx + dy*dy, b = 2*(fx*dx + fy*dy), c = fx*fx + fy*fy - cover.radius*cover.radius;
      const disc = b*b - 4*a*c; if (disc < 0 || a < 1e-12) return false;
      const root = Math.sqrt(disc), t1 = (-b-root)/(2*a), t2 = (-b+root)/(2*a); return (t1>=0&&t1<=1)||(t2>=0&&t2<=1);
    }
    const points = cover.shape === 'polygon' ? cover.points : [
      {x:cover.x,y:cover.y},{x:cover.x+cover.width,y:cover.y},{x:cover.x+cover.width,y:cover.y+cover.height},{x:cover.x,y:cover.y+cover.height}
    ];
    for (let i=0;i<points.length;i++) if (segmentIntersection(from,to,points[i],points[(i+1)%points.length])) return true;
    return pointInCover(to, cover);
  }

  function movementBlocked(scene, token, from, to) {
    if (effectiveWallSegments(scene, 'blocksMovement').some(segment => sweptTokenHitsSegment(scene, token, from, to, segment))) return true;
    return scene.covers.some(cover => cover.blocksMovement && (lineIntersectsCover(from, to, cover) || pointInCover(to, cover)));
  }

  function lineBlocked(scene, from, to) {
    return effectiveWallSegments(scene, 'blocksVision').some(segment => segmentIntersection(from, to, {x:segment.x1,y:segment.y1}, {x:segment.x2,y:segment.y2}));
  }

  function contactBlockedByWall(scene,from,to){
    const seen=new Set(),segments=[];
    for(const property of ['blocksMovement','blocksVision'])for(const segment of effectiveWallSegments(scene,property)){
      const key=[segment.x1,segment.y1,segment.x2,segment.y2].map(v=>Math.round(v*1000)).join(':');if(seen.has(key))continue;seen.add(key);segments.push(segment);
    }
    return segments.some(segment=>segmentIntersection(from,to,{x:segment.x1,y:segment.y1},{x:segment.x2,y:segment.y2}));
  }
  function projectileWallImpact(scene,from,to){
    let best=null;const seen=new Set(),segments=[];
    for(const property of ['blocksMovement','blocksVision'])for(const segment of effectiveWallSegments(scene,property)){const key=[segment.x1,segment.y1,segment.x2,segment.y2].map(value=>Math.round(value*1000)).join(':');if(seen.has(key))continue;seen.add(key);segments.push(segment);}
    for(const segment of segments){
      const t=segmentIntersectionT(from,to,{x:segment.x1,y:segment.y1},{x:segment.x2,y:segment.y2});
      if(t!==null&&t>.0001&&(best===null||t<best))best=t;
    }
    if(best===null)return null;
    const safeT=Math.max(0,best-.002);
    return{x:from.x+(to.x-from.x)*safeT,y:from.y+(to.y-from.y)*safeT,t:best};
  }

  function gridCellForPoint(scene, point) {
    const size=Math.max(1,safeNumber(scene?.grid?.size,70)),offsetX=safeNumber(scene?.grid?.offsetX,0),offsetY=safeNumber(scene?.grid?.offsetY,0);
    return{x:Math.round((safeNumber(point?.x,0)-offsetX-size/2)/size),y:Math.round((safeNumber(point?.y,0)-offsetY-size/2)/size)};
  }
  function gridPointForCell(scene, cell) {
    const size=Math.max(1,safeNumber(scene?.grid?.size,70)),offsetX=safeNumber(scene?.grid?.offsetX,0),offsetY=safeNumber(scene?.grid?.offsetY,0);
    return{x:offsetX+cell.x*size+size/2,y:offsetY+cell.y*size+size/2};
  }
  function pushDirection(scene,pusher,target){
    const a=gridCellForPoint(scene,pusher),b=gridCellForPoint(scene,target);let dx=Math.sign(b.x-a.x),dy=Math.sign(b.y-a.y);
    if(!dx&&!dy){const vx=safeNumber(target?.x,0)-safeNumber(pusher?.x,0),vy=safeNumber(target?.y,0)-safeNumber(pusher?.y,0);if(Math.abs(vx)>=Math.abs(vy))dx=Math.sign(vx)||1;else dy=Math.sign(vy)||1;}
    return{dx,dy};
  }
  function pushDestination(scene,token,direction){const size=Math.max(1,safeNumber(scene?.grid?.size,70));return{x:safeNumber(token?.x,0)+direction.dx*size,y:safeNumber(token?.y,0)+direction.dy*size};}
  function opposedSkillProfile(token,skillName,combatContext=true){
    if(token?.kind==='character'){const profile=characterSkillProfileDetailed(linkedCharacter(token),skillName,combatContext)||{};return{skillName,cube:profile.cube||profile.die||'1d6',sides:dieSides(profile.cube||profile.die||'1d6',6),bonus:Math.round(safeNumber(profile.bonus,0)),advantages:profile.advantages||[],hindrances:profile.hindrances||[]};}
    if(token?.kind==='npc'){const npc=linkedNpc(token);if(!npc)return null;const map={'Физическая сила':'strength','Акробатика':'dexterity','Скрытность':'dexterity','Взлом':'dexterity','Выдержка':'endurance','Стойкость':'endurance','Иммунитет':'endurance','Бдительность':'concentration','Воля':'concentration','Меткость':'concentration','Выживание':'concentration','Анализ':'intelligence','Эрудиция':'intelligence','Память':'intelligence','Медицина':'intelligence','Механика':'intelligence','Убеждение':'charisma','Обман':'charisma','Интуиция':'charisma','Запугивание':'charisma','Очарование':'charisma'};const sides=dieSides(npc.successDie||'1d6',6),armorProfile=normalizedNpcArmor(npc).profile,serious=safeNumber(npc?.wounds?.serious,0)>0?armorSeriousPenaltyForProfile(armorProfile):0,armorMod=armorSkillModifierForProfile(armorProfile,skillName),bonus=Math.round(safeNumber(npc.characteristics?.[map[skillName]||'concentration'],0)+injurySkillPenalty(npc,skillName).value+serious+armorMod);return{skillName,cube:`1d${sides}`,sides,bonus,advantages:[],hindrances:[]};}
    return null;
  }
  function runOpposedPushCheck(pusher,target){
    const attack=opposedSkillProfile(pusher,'Физическая сила',true),defense=opposedSkillProfile(target,'Стойкость',true);if(!attack||!defense)return null;
    const successRoll=rollOne(attack.sides),difficultyRoll=rollOne(defense.sides),successTotal=successRoll+attack.bonus,difficultyTotal=difficultyRoll+defense.bonus,success=successTotal>=difficultyTotal;let outcome=success?'success':'failure';
    if(successRoll===difficultyRoll&&attack.sides>defense.sides)outcome='critical-success';else if(successRoll===difficultyRoll&&defense.sides>attack.sides)outcome='critical-failure';
    return{skillName:'Физическая сила',difficultySkillName:'Стойкость',targetTokenId:target.id,targetName:target.name,success,successDie:`1d${attack.sides}`,successRolls:[successRoll],successRoll,bonus:attack.bonus,baseBonus:attack.bonus,baseSuccessTotal:successTotal,successTotal,difficultyDie:`1d${defense.sides}`,difficultySides:defense.sides,difficultyRolls:[difficultyRoll],difficultyRoll,difficultyModifier:defense.bonus,difficultyTotal,condition:'normal',outcome,advantages:attack.advantages||[],hindrances:attack.hindrances||[],defenseAdvantages:defense.advantages||[],defenseHindrances:defense.hindrances||[],extraRolls:[]};
  }
  function tokenInsideMap(scene,token,point){const half=tokenFootprintHalfSize(scene,token);return point.x-half>=0&&point.y-half>=0&&point.x+half<=scene.mapWidth&&point.y+half<=scene.mapHeight;}
  function pushBarrierInfo(scene,token,from,to){
    const doors=[],solid=[];
    for(const segment of effectiveWallSegments(scene,'blocksMovement')){
      if(!sweptTokenHitsSegment(scene,token,from,to,segment))continue;
      if(segment.door&&segment.source)doors.push(segment.source);else solid.push(segment);
    }
    const cover=(scene.covers||[]).find(item=>item.blocksMovement&&(lineIntersectsCover(from,to,item)||pointInCover(to,item)))||null;
    return{doors,solid,cover};
  }
  function resolvePushChain(scene,pusher,target,body={}){
    const direction=pushDirection(scene,pusher,target),planned=[],checks=[],openedDoors=new Map(),visiting=new Set();let blockedReason=null,blockedBy=null;
    const moveOne=(token,depth=0)=>{
      if(!token||visiting.has(token.id)||depth>30){blockedReason='Цепочка отталкивания зациклена.';return false;}visiting.add(token.id);
      if(!['character','npc'].includes(token.kind)){blockedReason=`Токен «${token.name}» нельзя оттолкнуть.`;blockedBy=token.id;visiting.delete(token.id);return false;}
      const check=runOpposedPushCheck(pusher,token);checks.push({tokenId:token.id,tokenName:token.name,pusherTokenId:pusher.id,pusherName:pusher.name,check});
      if(!check||!check.success){blockedReason=check?`${token.name} выдерживает Отталкивание: ${pusher.name} не превзошёл Стойкость цели.`:`Не удалось выполнить встречную проверку Отталкивания.`;blockedBy=token.id;visiting.delete(token.id);return false;}
      const from={x:token.x,y:token.y},to=pushDestination(scene,token,direction);
      if(!tokenInsideMap(scene,token,to)){blockedReason='Край карты не позволяет продолжить отталкивание.';blockedBy=token.id;visiting.delete(token.id);return false;}
      const barrier=pushBarrierInfo(scene,token,from,to);for(const door of barrier.doors)openedDoors.set(door.id,door);
      if(barrier.solid.length||barrier.cover){blockedReason=barrier.cover?'Позади находится непроходимое укрытие.':'Позади находится стена.';blockedBy=token.id;visiting.delete(token.id);return false;}
      const ignored=new Set(planned.map(item=>item.token.id));const blocker=tokenPositionBlocker(scene,token,to,ignored);
      if(blocker&&!moveOne(blocker,depth+1)){visiting.delete(token.id);return false;}
      planned.push({token,from,to,depth});visiting.delete(token.id);return true;
    };
    const moved=moveOne(target,0);
    for(const door of openedDoors.values()){door.open=true;door.locked=false;}
    if(moved){for(const item of planned){item.token.x=item.to.x;item.token.y=item.to.y;item.token.updatedAt=nowIso();}}
    return{moved,direction,planned:planned.map(item=>({tokenId:item.token.id,tokenName:item.token.name,from:item.from,to:item.to,depth:item.depth})),checks,openedDoors:[...openedDoors.values()].map(door=>({id:door.id,name:door.name})),blockedReason,blockedBy};
  }

  async function resolvePushChainWithReactions(scene,pusher,target,body={}){
    const direction=pushDirection(scene,pusher,target),planned=[],checks=[],openedDoors=new Map(),visiting=new Set();let blockedReason=null,blockedBy=null;
    const moveOne=async(token,depth=0)=>{
      if(!token||visiting.has(token.id)||depth>30){blockedReason='Цепочка отталкивания зациклена.';return false;}visiting.add(token.id);
      if(!['character','npc'].includes(token.kind)){blockedReason=`Токен «${token.name}» нельзя оттолкнуть.`;blockedBy=token.id;visiting.delete(token.id);return false;}
      const check=runOpposedPushCheck(pusher,token);let roll=null;
      if(check){roll=storeSpeciesCheckRoll(scene,pusher,check,body,`${pusher.name}: Физическая сила против Стойкости — ${token.name}`,{reactionSafe:true});if(roll){roll=await awaitCheckRollResolution(scene,roll);syncCheckFromReactionRoll(check,roll);}}
      checks.push({tokenId:token.id,tokenName:token.name,pusherTokenId:pusher.id,pusherName:pusher.name,check,roll});
      if(!check||!check.success){blockedReason=check?`${token.name} выдерживает Отталкивание: ${pusher.name} не превзошёл Стойкость цели.`:`Не удалось выполнить встречную проверку Отталкивания.`;blockedBy=token.id;visiting.delete(token.id);return false;}
      const from={x:token.x,y:token.y},to=pushDestination(scene,token,direction);
      if(!tokenInsideMap(scene,token,to)){blockedReason='Край карты не позволяет продолжить отталкивание.';blockedBy=token.id;visiting.delete(token.id);return false;}
      const barrier=pushBarrierInfo(scene,token,from,to);for(const door of barrier.doors)openedDoors.set(door.id,door);
      if(barrier.solid.length||barrier.cover){blockedReason=barrier.cover?'Позади находится непроходимое укрытие.':'Позади находится стена.';blockedBy=token.id;visiting.delete(token.id);return false;}
      const ignored=new Set(planned.map(item=>item.token.id));const blocker=tokenPositionBlocker(scene,token,to,ignored);
      if(blocker&&!await moveOne(blocker,depth+1)){visiting.delete(token.id);return false;}
      planned.push({token,from,to,depth});visiting.delete(token.id);return true;
    };
    const moved=await moveOne(target,0);
    for(const door of openedDoors.values()){door.open=true;door.locked=false;}
    if(moved){for(const item of planned){item.token.x=item.to.x;item.token.y=item.to.y;item.token.updatedAt=nowIso();}}
    return{moved,direction,planned:planned.map(item=>({tokenId:item.token.id,tokenName:item.token.name,from:item.from,to:item.to,depth:item.depth})),checks,openedDoors:[...openedDoors.values()].map(door=>({id:door.id,name:door.name})),blockedReason,blockedBy};
  }

  function aiGridBounds(scene){const size=Math.max(1,safeNumber(scene?.grid?.size,70)),offsetX=safeNumber(scene?.grid?.offsetX,0),offsetY=safeNumber(scene?.grid?.offsetY,0);return{minX:Math.ceil((0-offsetX-size/2)/size),maxX:Math.floor((scene.mapWidth-offsetX-size/2)/size),minY:Math.ceil((0-offsetY-size/2)/size),maxY:Math.floor((scene.mapHeight-offsetY-size/2)/size)};}
  function aiCellKey(cell){return`${cell.x}:${cell.y}`;}
  function aiSolidMovementBlocked(scene,token,from,to){
    for(const segment of effectiveWallSegments(scene,'blocksMovement')){
      if(!sweptTokenHitsSegment(scene,token,from,to,segment))continue;
      if(segment.door&&segment.source&&!segment.source.locked)continue;
      return true;
    }
    return(scene.covers||[]).some(cover=>cover.blocksMovement&&(lineIntersectsCover(from,to,cover)||pointInCover(to,cover)));
  }
  function aiCanStandCell(scene,token,cell,startCell){const b=aiGridBounds(scene);if(cell.x<b.minX||cell.x>b.maxX||cell.y<b.minY||cell.y>b.maxY)return false;if(startCell&&cell.x===startCell.x&&cell.y===startCell.y)return true;const point=gridPointForCell(scene,cell);if(!tokenInsideMap(scene,token,point))return false;return!tokenPositionBlocker(scene,token,point);}
  function aiEdgeOpen(scene,token,fromCell,toCell,startCell){if(!aiCanStandCell(scene,token,toCell,startCell))return false;const from=fromCell.x===startCell.x&&fromCell.y===startCell.y?speciesCombatPoint(token):gridPointForCell(scene,fromCell),to=gridPointForCell(scene,toCell);if(aiSolidMovementBlocked(scene,token,from,to))return false;const dx=toCell.x-fromCell.x,dy=toCell.y-fromCell.y;if(dx&&dy){const sideA={x:fromCell.x+dx,y:fromCell.y},sideB={x:fromCell.x,y:fromCell.y+dy};if(!aiCanStandCell(scene,token,sideA,startCell)||!aiCanStandCell(scene,token,sideB,startCell))return false;if(aiSolidMovementBlocked(scene,token,from,gridPointForCell(scene,sideA))||aiSolidMovementBlocked(scene,token,from,gridPointForCell(scene,sideB)))return false;}return true;}
  function aiAStar(scene,token,goalCell){const start=gridCellForPoint(scene,token),startKey=aiCellKey(start),goalKey=aiCellKey(goalCell),directions=[[-1,0,1],[1,0,1],[0,-1,1],[0,1,1],[-1,-1,Math.SQRT2],[1,-1,Math.SQRT2],[-1,1,Math.SQRT2],[1,1,Math.SQRT2]];if(!aiCanStandCell(scene,token,goalCell,start))return null;const heuristic=cell=>{const dx=Math.abs(goalCell.x-cell.x),dy=Math.abs(goalCell.y-cell.y);return Math.max(dx,dy)+(Math.SQRT2-1)*Math.min(dx,dy)};const open=[{...start,g:0,f:heuristic(start)}],best=new Map([[startKey,0]]),came=new Map();let iterations=0;while(open.length&&iterations++<12000){open.sort((a,b)=>b.f-a.f);const current=open.pop(),key=aiCellKey(current);if(current.g>Number(best.get(key))+.0001)continue;if(key===goalKey){const path=[{x:current.x,y:current.y}];let cursor=key;while(cursor!==startKey){const prev=came.get(cursor);if(!prev)return null;path.push(prev.cell);cursor=prev.key;}path.reverse();return path;}for(const[dx,dy,cost]of directions){const next={x:current.x+dx,y:current.y+dy};if(!aiEdgeOpen(scene,token,current,next,start))continue;const nextKey=aiCellKey(next),g=current.g+cost;if(best.has(nextKey)&&best.get(nextKey)<=g+.0001)continue;best.set(nextKey,g);came.set(nextKey,{key,cell:{x:current.x,y:current.y}});open.push({...next,g,f:g+heuristic(next)});}}return null;}
  function aiDestinationCandidates(scene,point){const center=gridCellForPoint(scene,point),items=[];for(let radius=0;radius<=6;radius++)for(let dx=-radius;dx<=radius;dx++)for(let dy=-radius;dy<=radius;dy++){if(Math.max(Math.abs(dx),Math.abs(dy))!==radius)continue;items.push({x:center.x+dx,y:center.y+dy,distance:dx*dx+dy*dy});}return items.sort((a,b)=>a.distance-b.distance);}
  function aiFindRoute(scene,token,point){if(!scene?.grid?.enabled){const target={x:clamp(point.x,0,scene.mapWidth),y:clamp(point.y,0,scene.mapHeight)};return aiSolidMovementBlocked(scene,token,token,target)||tokenPositionBlocker(scene,token,target)?null:[speciesCombatPoint(token),target];}for(const candidate of aiDestinationCandidates(scene,point).slice(0,64)){const cells=aiAStar(scene,token,candidate);if(cells?.length)return[speciesCombatPoint(token),...cells.slice(1).map(cell=>gridPointForCell(scene,cell))];}return null;}
  function aiDoorsAlongPath(scene,token,from,to){const result=[];for(const segment of effectiveWallSegments(scene,'blocksMovement'))if(segment.door&&segment.source&&!segment.source.locked&&sweptTokenHitsSegment(scene,token,from,to,segment))result.push(segment.source);return[...new Map(result.map(door=>[door.id,door])).values()];}

  function coverBetweenPoints(from, to, cover) {
    // Укрытие — физический объект между стрелком и целью, а не аура вокруг токена.
    if (!cover || pointInCover(from, cover) || pointInCover(to, cover)) return false;
    return lineIntersectsCover(from, to, cover);
  }

  function coverDistanceFromPoint(point, cover) {
    if (!cover) return Infinity;
    if (pointInCover(point, cover)) return 0;
    if (cover.shape === 'circle') return Math.max(0, Math.hypot(point.x-cover.x, point.y-cover.y)-cover.radius);
    if (cover.shape === 'polyline') {
      let best=Infinity; const points=cover.points||[], half=Math.max(1,safeNumber(cover.thickness,18))/2;
      for(let i=1;i<points.length;i++)best=Math.min(best,Math.max(0,pointSegmentDistance(point,points[i-1],points[i])-half));
      return best;
    }
    const points=cover.shape==='polygon'?(cover.points||[]):[
      {x:cover.x,y:cover.y},{x:cover.x+cover.width,y:cover.y},{x:cover.x+cover.width,y:cover.y+cover.height},{x:cover.x,y:cover.y+cover.height}
    ];
    let best=Infinity;for(let i=0;i<points.length;i++)best=Math.min(best,pointSegmentDistance(point,points[i],points[(i+1)%points.length]));return best;
  }
  function wallDistanceFromPoint(point, wall) { const points=wallPoints(wall);let best=Infinity;for(let i=1;i<points.length;i++)best=Math.min(best,pointSegmentDistance(point,points[i-1],points[i]));return best; }
  function tokenCoverClearance(scene, token) {
    const gridSize=Math.max(1,safeNumber(scene?.grid?.size,70)),tokenRadius=gridSize*Math.max(.25,safeNumber(token?.size,1))/2;
    // «Выглянуть» доступно не только при наложении токена на геометрию укрытия,
    // но и из соседней клетки: от края токена допускается ещё половина клетки.
    return Math.max(8,tokenRadius+gridSize/2+2);
  }
  function tokenAdjacentToCover(scene, token) {
    if(!scene||!token)return false;const point=speciesCombatPoint(token),clearance=tokenCoverClearance(scene,token);
    return (scene.covers||[]).some(cover=>cover.mz>0&&coverDistanceFromPoint(point,cover)<=clearance) || (scene.walls||[]).some(wall=>wall.coverMz>0&&wallDistanceFromPoint(point,wall)<=clearance);
  }
  function segmentIntersectionT(a,b,c,d) {
    const r={x:b.x-a.x,y:b.y-a.y},s={x:d.x-c.x,y:d.y-c.y},den=r.x*s.y-r.y*s.x;
    if(Math.abs(den)<1e-9)return null;
    const q={x:c.x-a.x,y:c.y-a.y},t=(q.x*s.y-q.y*s.x)/den,u=(q.x*r.y-q.y*r.x)/den;
    return t>=0&&t<=1&&u>=0&&u<=1?t:null;
  }
  function coverIntersectionT(from,to,cover) {
    if(!cover)return null;
    if(cover.shape==='circle'){
      const dx=to.x-from.x,dy=to.y-from.y,fx=from.x-cover.x,fy=from.y-cover.y,a=dx*dx+dy*dy,b=2*(fx*dx+fy*dy),c=fx*fx+fy*fy-cover.radius*cover.radius,disc=b*b-4*a*c;
      if(a<=1e-9||disc<0)return null;const root=Math.sqrt(disc),values=[(-b-root)/(2*a),(-b+root)/(2*a)].filter(t=>t>=0&&t<=1);return values.length?Math.min(...values):null;
    }
    const points=cover.shape==='polygon'||cover.shape==='polyline'?(cover.points||[]): [{x:cover.x,y:cover.y},{x:cover.x+cover.width,y:cover.y},{x:cover.x+cover.width,y:cover.y+cover.height},{x:cover.x,y:cover.y+cover.height}];
    let best=null,limit=cover.shape==='polyline'?points.length-1:points.length;
    for(let i=0;i<limit;i++){const j=cover.shape==='polyline'?i+1:(i+1)%points.length,t=segmentIntersectionT(from,to,points[i],points[j]);if(t!==null&&(best===null||t<best))best=t;}
    return best;
  }
  function rectContainsPoint(zone, point) {
    if(!zone||!point)return false;const x1=Math.min(zone.x,zone.x+zone.width),x2=Math.max(zone.x,zone.x+zone.width),y1=Math.min(zone.y,zone.y+zone.height),y2=Math.max(zone.y,zone.y+zone.height);return point.x>=x1&&point.x<=x2&&point.y>=y1&&point.y<=y2;
  }
  function elevationLevelAt(scene, point) {
    let level=0;for(const zone of scene?.elevationZones||[]){if(!rectContainsPoint(zone,point))continue;level=Math.max(level,zone.level==='very-high'?2:1);}return level;
  }
  function coverReferencePoint(cover) {
    if(cover?.shape==='circle')return{x:cover.x,y:cover.y};if(Array.isArray(cover?.points)&&cover.points.length)return{x:cover.points.reduce((s,p)=>s+p.x,0)/cover.points.length,y:cover.points.reduce((s,p)=>s+p.y,0)/cover.points.length};return{x:safeNumber(cover?.x,0)+safeNumber(cover?.width,0)/2,y:safeNumber(cover?.y,0)+safeNumber(cover?.height,0)/2};
  }
  function trajectoryClearsCover(scene, from, to, cover, intersectionT, { wall=false } = {}) {
    if(scene?.settings?.elevationRulesEnabled===false||intersectionT===null)return false;
    const shooterLevel=elevationLevelAt(scene,from);if(shooterLevel<2)return false;
    return elevationLevelAt(scene,coverReferencePoint(cover))<2;
  }

  function automaticCoverInfo(scene, from, to, options = {}) {
    let best = 0, source = null, ignored = [];
    const ignoreNearOrigin=Boolean(options.ignoreNearOrigin),clearance=ignoreNearOrigin?Math.max(0,safeNumber(options.originClearance,tokenCoverClearance(scene,options.originToken))):0;
    for (const wall of scene.walls) {
      if (!wall.coverMz) continue;
      const nearOrigin=ignoreNearOrigin&&wallDistanceFromPoint(from,wall)<=clearance;
      const points=wallPoints(wall);let intersectionT=null;for(let i=1;i<points.length;i++){const t=segmentIntersectionT(from,to,points[i-1],points[i]);if(t!==null&&(intersectionT===null||t<intersectionT))intersectionT=t;}
      if(intersectionT===null)continue;
      if(nearOrigin){ignored.push({id:wall.id,name:wall.coverName||'Линия укрытия',type:'wall',reason:'near-origin'});continue;}
      if(trajectoryClearsCover(scene,from,to,wall,intersectionT,{wall:true})){ignored.push({id:wall.id,name:wall.coverName||'Линия укрытия',type:'wall',reason:'elevation'});continue;}
      if (wall.coverMz > best) { best = wall.coverMz; source = { id: wall.id, name: wall.coverName || 'Линия укрытия', type: 'wall' }; }
    }
    for (const cover of scene.covers) {
      const intersects=options.includeTargetInsideCover?(lineIntersectsCover(from,to,cover)||pointInCover(to,cover)):coverBetweenPoints(from,to,cover);
      if (!cover.mz || !intersects) continue;
      if(ignoreNearOrigin&&coverDistanceFromPoint(from,cover)<=clearance){ignored.push({id:cover.id,name:cover.name||'Укрытие',type:'cover',reason:'near-origin'});continue;}
      const intersectionT=coverIntersectionT(from,to,cover);
      if(trajectoryClearsCover(scene,from,to,cover,intersectionT)){ignored.push({id:cover.id,name:cover.name||'Укрытие',type:'cover',reason:'elevation'});continue;}
      if(cover.mz<=best)continue;
      best = cover.mz; source = { id: cover.id, name: cover.name || 'Укрытие', type: 'cover' };
    }
    // v1.1.10: транспорт и передвижные интерактивные объекты могут быть
    // настоящими подвижными укрытиями. Их изображение/токен определяет место,
    // а величину МЗ задаёт мастер в инспекторе.
    for (const token of scene.tokens || []) {
      const mz = token.kind === 'vehicle' ? Math.max(0, Math.round(safeNumber(token.vehicle?.coverMz, 0)))
        : token.kind === 'interactive' ? Math.max(0, Math.round(safeNumber(token.interactive?.coverMz, 0))) : 0;
      if (!mz || token.defeated || token.boardedVehicleId) continue;
      const radius=Math.max(4,tokenFootprintHalfSize(scene,token)*.92), mobileCover={shape:'circle',x:token.x,y:token.y,radius};
      const intersects=options.includeTargetInsideCover?(lineIntersectsCover(from,to,mobileCover)||pointInCover(to,mobileCover)):coverBetweenPoints(from,to,mobileCover);
      if(!intersects)continue;
      if(ignoreNearOrigin&&coverDistanceFromPoint(from,mobileCover)<=clearance){ignored.push({id:token.id,name:token.name||'Передвижное укрытие',type:token.kind,reason:'near-origin'});continue;}
      if(mz<=best)continue;
      best=mz;source={id:token.id,name:token.name||'Передвижное укрытие',type:token.kind};
    }
    return { mz: best, source, ignored };
  }

  function automaticCoverMz(scene, from, to) { return automaticCoverInfo(scene, from, to).mz; }

  function automaticZoneMz(scene, from, to) {
    let best = 0;
    for (const effect of scene.effects || []) {
      if (effect.visualOnly || effect.remainingRounds <= 0 || !effect.mzBonus) continue;
      const radiusPx = effect.radius / Math.max(0.01, scene.grid.feet) * Math.max(1, scene.grid.size);
      const asCover = { shape:'circle', x:effect.x, y:effect.y, radius:radiusPx };
      if (!(lineIntersectsCover(from, to, asCover) || pointInCover(to, asCover))) continue;
      const passage=segmentCirclePassage(from,to,{x:effect.x,y:effect.y},radiusPx),sample=passage?.mid||(pointInCover(to,asCover)?to:null);
      if(sample&&effectSpreadBlocked(scene,effect,sample))continue;
      best = Math.max(best, effect.mzBonus);
    }
    return best;
  }

  function explosionBlockedByWall(scene,center,target){return contactBlockedByWall(scene,center,speciesCombatPoint(target));}
  function explosionCoverReduction(scene, center, target) {
    if (explosionBlockedByWall(scene,center,target)) return 0;
    const mz = automaticCoverMz(scene, center, target);
    if (mz >= 5) return 3;
    if (mz >= 3) return 2;
    if (mz > 0) return 1;
    return 0;
  }


  // --- v1.1.11: реакция на БРОШЕННУЮ гранату по актуальным правилам FATUM ---
  // Падение/нырок дают -1 урон от взрыва и создают долг 1 ОД на ближайший ход.
  // При наличии укрытия в 5 футах нырок требует Акробатику против 1к6.
  // Гранатомётные снаряды намеренно не используют эти функции: в правилах
  // реакция сформулирована только для брошенной гранаты.
  function grenadeReactionDisabled(token) {
    if (!token || !['character','npc'].includes(token.kind)) return true;
    const critical=criticalState(token);
    if (critical.dead || critical.critical || token.defeated) return true;
    if (speciesConditions(token)?.wrappedByTokenId) return true;
    return false;
  }
  function tokenSeesThrownGrenade(scene, token, throwOrigin, impactPoint) {
    if (grenadeReactionDisabled(token)) return false;
    const eye=speciesCombatPoint(token);
    // При включённой системе зрения учитываем её (дальность, дым, свет, стены).
    // На старых сценах без персонального зрения сохраняем геометрическую LOS.
    if (token?.vision?.enabled) {
      if (viewerCanSeePoint(scene,token,impactPoint)) return true;
      if (throwOrigin && viewerCanSeePoint(scene,token,throwOrigin)) return true;
      return false;
    }
    return !lineBlocked(scene,eye,impactPoint) || Boolean(throwOrigin && !lineBlocked(scene,eye,throwOrigin));
  }
  function grenadeDiveCandidate(scene, token, impactPoint) {
    if (!scene || !token || !impactPoint || grenadeReactionDisabled(token)) return null;
    const from=speciesCombatPoint(token), candidates=[];
    if (scene.grid?.enabled !== false) {
      const cell=gridCellForPoint(scene,from);
      for (const [dx,dy] of [[-1,0],[1,0],[0,-1],[0,1],[-1,-1],[1,-1],[-1,1],[1,1]]) {
        // Одна соседняя клетка в FATUM считается ближайшим укрытием (5 футов).
        candidates.push(gridPointForCell(scene,{x:cell.x+dx,y:cell.y+dy}));
      }
    } else {
      const px=feetToScenePixels(scene,5);
      for(let i=0;i<16;i++){const a=Math.PI*2*i/16;candidates.push({x:from.x+Math.cos(a)*px,y:from.y+Math.sin(a)*px});}
    }
    let best=null;
    for (const point of candidates) {
      if (!tokenInsideMap(scene,token,point)) continue;
      if (tokenPositionBlocker(scene,token,point)) continue;
      if (movementBlocked(scene,token,from,point)) continue;
      const shadow={...token,x:point.x,y:point.y};
      const wallBlocked=explosionBlockedByWall(scene,impactPoint,shadow);
      const reduction=wallBlocked?99:explosionCoverReduction(scene,impactPoint,shadow);
      if (reduction<=0) continue;
      const info=wallBlocked?{mz:99,source:{name:'стена или закрытая дверь',type:'wall'}}:automaticCoverInfo(scene,impactPoint,speciesCombatPoint(shadow));
      const score=(wallBlocked?100:reduction*10)-Math.hypot(point.x-from.x,point.y-from.y)/Math.max(1,scene.grid?.size||70);
      if(!best||score>best.score)best={x:point.x,y:point.y,coverReduction:wallBlocked?3:reduction,wallBlocked,coverName:info?.source?.name||'укрытие',score};
    }
    return best;
  }
  function addGrenadeReactionDebt(token, amount=1) {
    const host=actionHost(token);if(!host)return 0;
    amount=Math.max(0,Math.round(safeNumber(amount,1)));
    host._battlemapGrenadeReactionDebt=Math.max(0,Math.round(safeNumber(host._battlemapGrenadeReactionDebt,0)))+amount;
    return host._battlemapGrenadeReactionDebt;
  }
  function grenadeReactionRecipient(token) {
    const ownerId=tokenOwnerId(token);
    const clients=[...getSseClients().values()];
    if(ownerId){const playerClients=clients.filter(client=>client.mode!=='master'&&client.clientId===ownerId);if(playerClients.length)return{kind:'player',ownerId,clients:playerClients};}
    const masters=clients.filter(client=>client.mode==='master');
    if(masters.length)return{kind:'master',ownerId:null,clients:masters};
    return null;
  }
  function askGrenadeReaction(scene,thrower,target,impactPoint,profile,baseDamage,diveCandidate) {
    const recipient=grenadeReactionRecipient(target);if(!recipient)return Promise.resolve('none');
    const reactionId=makeId('grenade-reaction'),expiresAt=Date.now()+25000;
    return new Promise(resolve=>{
      const timer=setTimeout(()=>{const pending=pendingGrenadeReactions.get(reactionId);if(!pending)return;pendingGrenadeReactions.delete(reactionId);resolve('none');},25000);
      pendingGrenadeReactions.set(reactionId,{id:reactionId,sceneId:scene.id,targetTokenId:target.id,recipientKind:recipient.kind,ownerId:recipient.ownerId,expiresAt,timer,resolve});
      const payload={reactionId,sceneId:scene.id,targetTokenId:target.id,targetName:target.name,throwerTokenId:thrower?.id||null,throwerName:thrower?.name||'',grenadeName:profile?.name||'Граната',baseDamage:Math.max(0,Math.round(baseDamage)),distance:Math.round(distanceFeet(scene,target,impactPoint)*10)/10,canDive:Boolean(diveCandidate),coverName:diveCandidate?.coverName||'',expiresAt,rule:'thrown-grenade'};
      for(const client of recipient.clients)try{sseWrite(client.response,'battlemap-grenade-reaction',payload);}catch{}
    });
  }
  function combatReactionRecipient(attacker){return grenadeReactionRecipient(attacker);}
  function askCombatReaction(scene,attacker,target,type,weapon=null){
    const recipient=combatReactionRecipient(attacker);if(!recipient)return Promise.resolve('skip');
    const reactionId=makeId(type==='zone-fire'?'zone-fire-reaction':'opportunity-reaction'),expiresAt=Date.now()+20000;
    return new Promise(resolve=>{
      const timer=setTimeout(()=>{const pending=pendingCombatReactions.get(reactionId);if(!pending)return;pendingCombatReactions.delete(reactionId);resolve('skip');},20000);
      pendingCombatReactions.set(reactionId,{id:reactionId,sceneId:scene.id,attackerTokenId:attacker.id,targetTokenId:target.id,type,recipientKind:recipient.kind,ownerId:recipient.ownerId,expiresAt,timer,resolve});
      const payload={reactionId,sceneId:scene.id,type,attackerTokenId:attacker.id,attackerName:attacker.name,targetTokenId:target.id,targetName:target.name,weaponName:weapon?.name||weapon?.profile||null,expiresAt,rule:type==='zone-fire'?'zone-fire':'opportunity-attack'};
      for(const client of recipient.clients)try{sseWrite(client.response,'battlemap-combat-reaction',payload);}catch{}
    });
  }
  function applyGrenadeReactionChoice(scene,target,impactPoint,choice,body={}) {
    choice=['fall','dive'].includes(choice)?choice:'none';
    if(choice==='none'||grenadeReactionDisabled(target))return{choice:'none',damageReduction:0,odDebt:0,moved:false};
    const result={choice,damageReduction:1,odDebt:addGrenadeReactionDebt(target,1),moved:false,check:null,coverName:null};
    if(choice==='dive'){
      const candidate=grenadeDiveCandidate(scene,target,impactPoint);
      if(!candidate){result.choice='fall';result.reason='Укрытие больше недоступно.';return result;}
      const check=runAnyTokenSkillCheck(target,'Акробатика',6,0);result.check=check;
      if(check?.success){target.x=candidate.x;target.y=candidate.y;target.updatedAt=nowIso();result.moved=true;result.coverName=candidate.coverName;result.wallBlocked=candidate.wallBlocked;result.coverReduction=candidate.coverReduction;}
      else result.reason='Проверка Акробатики провалена.';
    }
    if(target.kind==='character')markCharacterChanged(target,body.clientId||null);else{const npc=linkedNpc(target);if(npc)npc.updatedAt=nowIso();}
    return result;
  }
  async function resolveGrenadeReactionChoice(scene,target,impactPoint,choice,body={}) {
    choice=['fall','dive'].includes(choice)?choice:'none';
    if(choice==='none'||grenadeReactionDisabled(target))return{choice:'none',damageReduction:0,odDebt:0,moved:false};
    const result={choice,damageReduction:1,odDebt:addGrenadeReactionDebt(target,1),moved:false,check:null,roll:null,coverName:null};
    if(choice==='dive'){
      const candidate=grenadeDiveCandidate(scene,target,impactPoint);
      if(!candidate){result.choice='fall';result.reason='Укрытие больше недоступно.';}
      else{
        const check=runAnyTokenSkillCheck(target,'Акробатика',6,0);result.check=check;
        if(check){
          let roll=storeSpeciesCheckRoll(scene,target,check,body,`${target.name}: реакция на гранату — Акробатика`,{reactionSafe:true});
          if(roll){roll=await awaitCheckRollResolution(scene,roll);syncCheckFromReactionRoll(check,roll);result.roll=roll;}
        }
        if(check?.success){target.x=candidate.x;target.y=candidate.y;target.updatedAt=nowIso();result.moved=true;result.coverName=candidate.coverName;result.wallBlocked=candidate.wallBlocked;result.coverReduction=candidate.coverReduction;}
        else result.reason='Проверка Акробатики провалена.';
      }
    }
    if(target.kind==='character')markCharacterChanged(target,body.clientId||null);else{const npc=linkedNpc(target);if(npc)npc.updatedAt=nowIso();}
    return result;
  }

  async function resolveThrownGrenadeReactions(scene,thrower,impactPoint,profile,body={}) {
    const reactions=new Map();
    if(!state.combat?.active||state.combat.sceneId!==scene?.id||safeNumber(profile?.damage,0)<=0)return reactions;
    const playerWait=[];
    for(const target of scene.tokens||[]){
      if(!['character','npc'].includes(target.kind))continue;
      if(profile.hostileOnly&&!tokensHostile(thrower,target))continue;
      const feet=distanceFeet(scene,target,impactPoint);if(feet>profile.radius+.01)continue;
      if(explosionBlockedByWall(scene,impactPoint,target))continue;
      const baseDamage=feet<=profile.radius/2?profile.damage:Math.floor(profile.damage/2);if(baseDamage<=0)continue;
      if(!tokenSeesThrownGrenade(scene,target,speciesCombatPoint(thrower),impactPoint))continue;
      const dive=grenadeDiveCandidate(scene,target,impactPoint);
      if(target.kind==='npc'){
        // NPC действует рационально: пытается нырнуть за доступное укрытие,
        // иначе падает. Это не требует ручного подтверждения мастера.
        const result=await resolveGrenadeReactionChoice(scene,target,impactPoint,dive?'dive':'fall',{...body,clientId:null,playerName:`NPC: ${target.name}`});reactions.set(target.id,result);
      }else{
        playerWait.push((async()=>{const choice=await askGrenadeReaction(scene,thrower,target,impactPoint,profile,baseDamage,dive);const result=await resolveGrenadeReactionChoice(scene,target,impactPoint,choice,body);reactions.set(target.id,result);})());
      }
    }
    if(playerWait.length)await Promise.all(playerWait);
    for(const [tokenId,reaction] of reactions){const target=findToken(scene,tokenId);if(!target||reaction.choice==='none')continue;const detail=reaction.choice==='dive'?(reaction.moved?`ныряет за «${reaction.coverName||'укрытие'}» (Акробатика ${reaction.check?.successTotal??'?'} против ${reaction.check?.difficultyTotal??reaction.check?.difficultyRoll??'?'} — успех)`:`пытается нырнуть, но не успевает${reaction.check?` (Акробатика ${reaction.check.successTotal} против ${reaction.check.difficultyTotal})`:''}`):'падает на землю';const entry=appendTableLog({type:'action',actorId:null,actorName:target.name,text:`${target.name}: реакция на брошенную гранату — ${detail}; −1 урон от взрыва, −1 ОД в ближайший ход.`,sceneId:scene.id,tokenId:target.id});broadcastTableLog(entry);}
    return reactions;
  }

  function parseRange(desc) {
    const text = String(desc || '');
    const radiusMatch = text.match(/(\d+)\s*(?:фт|фут(?:ов|а)?)\s*радиус\s*\/\s*(\d+)\s*(?:фт|фут(?:ов|а)?)/i);
    if (radiusMatch) return { range: Number(radiusMatch[2]), radius: Number(radiusMatch[1]) };
    const matches = [...text.matchAll(/(\d+)\s*(?:фт|фут(?:ов|а)?)/gi)].map(match => Number(match[1]));
    return { range: matches.length ? Math.max(...matches) : 5, radius: 0 };
  }

  function parseWeaponDesc(item) { return String(item?.desc || item?.description || ''); }
  function parseDamage(desc) { const match = String(desc).match(/урон\s*(\d+)/i); return match ? Number(match[1]) : 1; }
  function parseThreshold(desc) { const match = String(desc).match(/порог\s*(\d+)/i); return match ? Number(match[1]) : 0; }
  function parseOdCost(desc) { const match = String(desc).match(/(?:атака|выстрел)?[^.;]*?(\d+)\s*ОД/i); return match ? Number(match[1]) : 2; }
  function parseAimedOdCost(desc, type, normalCost, hasAimedMode) {
    if (!hasAimedMode) return null;
    const explicit = String(desc || '').match(/прицельн\w*\s+(?:выстрел|атака)[^.;]*?(\d+)\s*ОД/i);
    if (explicit) return Math.max(0, Number(explicit[1]));
    if (type === 'Пистолет') return 2;
    return Math.max(0, Number(normalCost || 0) + 1);
  }
  function parseDamageTag(item, desc) {
    if (['light', 'medium', 'heavy'].includes(item?.damageTag)) return item.damageTag;
    const match = String(desc).match(/тег:\s*(л[её]гк\w*|средн\w*|тяж[её]л\w*)/i);
    if (!match) return 'medium';
    if (/л[её]гк/i.test(match[1])) return 'light';
    if (/тяж/i.test(match[1])) return 'heavy';
    return 'medium';
  }
  function parseHitDice(desc, type, profile) {
    const text = String(desc || '').replace(/к/g, 'd');
    const pair = text.match(/Попадание:\s*(1d(?:4|6|8|10|12))\s*обыч[^/]*\/\s*(1d(?:4|6|8|10|12))/i);
    if (pair) return { normal: pair[1].toLowerCase(), aimed: pair[2].toLowerCase() };
    const single = text.match(/(?:Попадание[:\s]*)?(1d(?:4|6|8|10|12))/i);
    const normal = single ? single[1].toLowerCase() : '1d6';
    if (type === 'Пистолет') return { normal, aimed: normal === '1d4' ? '1d6' : normal === '1d6' ? '1d8' : normal };
    return { normal, aimed: '' };
  }
  function profCategory(type) {
    if (type === 'Пистолет') return 'Пистолеты';
    if (type === 'Карабин') return 'Карабины';
    if (type === 'Снайперская винтовка') return 'Винтовки';
    if (type === 'Дробовик') return 'Дробовики';
    if (type === 'Тяжёлое') return 'Тяжёлое';
    return null;
  }

  function weaponSpecialRangedKind(type, profile = '', name = '') {
    const blob = `${type || ''} ${profile || ''} ${name || ''}`;
    if (type === 'Луки' || /(?:^|\s)лук(?:$|\s)|короткий лук|длинный лук|охотничий лук/i.test(blob)) return 'bow';
    if (type === 'Арбалеты' || /арбалет/i.test(blob)) return 'crossbow';
    return null;
  }
  function specialRangedHitBonus(character, type, profile = '', name = '') {
    const kind = weaponSpecialRangedKind(type, profile, name);
    if (!kind) return null;
    const accuracy = Math.round(safeNumber(character?.state?._lanRollProfile?.skills?.['Меткость']?.bonus, character?.state?.skills?.['Меткость']?.bonus || 0));
    if (kind === 'crossbow') return accuracy;
    const strength = Math.round(safeNumber(character?.state?._lanRollProfile?.skills?.['Физическая сила']?.bonus, character?.state?.skills?.['Физическая сила']?.bonus || 0));
    return strength + Math.floor(accuracy / 2);
  }
  function canonicalBaseObCost(profile, type = '', desc = '', fallback = 0) {
    const canonical = canonicalWeaponProfileAlias(profile) || String(profile || '');
    if (canonical === 'Тяжёлый пулемёт') return 0;
    if (['Лёгкий гранатомёт','Тяжёлый гранатомёт','Анаксионный излучатель'].includes(canonical)) return 1;
    if (type === 'Тяжёлое' && !/пулем[её]т/i.test(`${canonical} ${desc}`)) return 1;
    if (/каждая атака требует\s*1\s*ОБ/i.test(desc)) return 1;
    return Math.max(0, safeNumber(fallback, 0));
  }

  function fallbackWeaponsForCharacter(character) {
    const st = character?.state || {};
    const storedProfile = st._lanBattleProfile;
    const storedWeapons = Array.isArray(storedProfile?.weapons) ? storedProfile.weapons : [];
    const inventory = Array.isArray(st.inventory) ? st.inventory : [];
    const equipment = st.equipment || {};
    const accuracy = Math.round(safeNumber(st?._lanRollProfile?.skills?.['Меткость']?.bonus, st?.skills?.['Меткость']?.bonus || 0));
    const weapons = [];
    const normalized = value => String(value ?? '').trim().toLocaleLowerCase('ru-RU');
    const findInventoryItem = (slot, equippedKey, stored) => {
      if (equippedKey && typeof equippedKey === 'object') return equippedKey;
      const exact = inventory.find(candidate => String(candidate?.uid || candidate?.id || '') === String(equippedKey || ''));
      if (exact) return exact;
      const keys = [equippedKey, stored?.inventoryUid, stored?.itemUid, stored?.uid, stored?.name, stored?.profile]
        .map(normalized).filter(Boolean);
      if (!keys.length) return null;
      return inventory.find(candidate => {
        const values = [candidate?.uid, candidate?.id, candidate?.name, candidate?.selectedModel, candidate?.customModel, candidate?.profile, candidate?.legacyProfile]
          .map(normalized).filter(Boolean);
        return values.some(value => keys.includes(value));
      }) || null;
    };
    const findCatalogItem = (...names) => {
      for (const name of names) {
        if (!name) continue;
        const direct = weaponCatalog.get(String(name));
        if (direct) return direct;
        const canonical=canonicalWeaponProfileAlias(name);
        if(canonical&&weaponCatalog.has(canonical))return weaponCatalog.get(canonical);
      }
      return {};
    };
    for (const slot of ['weapon1', 'weapon2']) {
      const hasExplicitSlot = Object.prototype.hasOwnProperty.call(equipment, slot);
      const equippedKey = equipment[slot];
      const stored = storedWeapons.find(candidate => candidate?.slot === slot || candidate?.id === slot) || null;
      // Явно очищенный слот важнее старого сохранённого профиля. В старых листах,
      // где equipment ещё не существовал, допускаем восстановление из _lanBattleProfile.
      if (hasExplicitSlot && !equippedKey) continue;
      if (!equippedKey && !stored) continue;
      const inventoryItem = findInventoryItem(slot, equippedKey, stored);
      const catalogItem = findCatalogItem(
        inventoryItem?.name,
        inventoryItem?.profile,
        inventoryItem?.legacyProfile,
        stored?.profile,
        stored?.name
      );
      const item = { ...catalogItem, ...(inventoryItem || {}) };
      // v1.7.6 combatfix4: the actually equipped inventory item is the source of
      // truth for weapon identity.  _lanBattleProfile and token.weapons are
      // caches and can legitimately lag one save behind after swapping weapons
      // or changing a model.  A stale cached carbine must never turn a currently
      // equipped machine gun into a carbine.
      const inferredProfile=canonicalWeaponProfileAlias(
        inventoryItem?.profile, inventoryItem?.legacyProfile, inventoryItem?.name,
        inventoryItem?.selectedModel, inventoryItem?.customModel,
        catalogItem?.name, equippedKey
      );
      const canonicalCatalog=inferredProfile&&weaponCatalog.has(inferredProfile)?weaponCatalog.get(inferredProfile):catalogItem;
      const currentProfile = inventoryItem ? (
        inferredProfile || inventoryItem?.profile || inventoryItem?.legacyProfile ||
        canonicalCatalog?.name || catalogItem?.legacyProfile || catalogItem?.name || inventoryItem?.name
      ) : '';
      const profileName = currentProfile || stored?.profile || canonicalWeaponProfileAlias(stored?.profile, stored?.name) || item.profile || item.legacyProfile || item.name || String(equippedKey || slot);
      const currentCanonical = canonicalWeaponProfileAlias(profileName, inventoryItem?.selectedModel, inventoryItem?.customModel, inventoryItem?.name) || String(profileName || '');
      const storedCanonical = stored ? (canonicalWeaponProfileAlias(stored?.profile, stored?.name) || String(stored?.profile || stored?.name || '')) : '';
      // A cached slot may belong to the weapon that occupied it before the
      // current inventory item. Reuse cached runtime/detail fields only when
      // both identities resolve to the same canonical profile. This extends
      // combatfix4/5 from the core die/damage fields to every weapon flag.
      const storedMatch = stored && (!inventoryItem || (currentCanonical && storedCanonical === currentCanonical)) ? stored : null;
      const desc = String(
        inventoryItem?.desc || inventoryItem?.description ||
        canonicalCatalog?.desc || canonicalCatalog?.description || catalogItem?.desc || catalogItem?.description ||
        storedMatch?.description || ''
      );
      const type = inventoryItem?.type || canonicalCatalog?.type || catalogItem?.type || stored?.type || item.type || '';
      const rawModelName=String(inventoryItem?.name||'');
      const rawNameIsLegacyModel=Boolean(LEGACY_WEAPON_PROFILE_ALIASES.has(rawModelName));
      const displayName = inventoryItem
        ? (inventoryItem.customModel || inventoryItem.selectedModel || (rawNameIsLegacyModel?rawModelName:'') || profileName || rawModelName)
        : (stored?.name || item.customModel || item.selectedModel || item.name || profileName);
      const melee = Boolean(
        storedMatch?.melee || type === 'Оружие ближнего боя' ||
        CANONICAL_MELEE_PROFILES.has(profileName) || CANONICAL_MELEE_PROFILES.has(inferredProfile) ||
        CANONICAL_MELEE_PROFILES.has(canonicalWeaponProfileAlias(displayName, profileName))
      );
      const category = profCategory(type);
      const proficiency = category ? Math.round(safeNumber(st.weaponProficiencies?.[category], 0)) : 0;
      const specialRangedKind = weaponSpecialRangedKind(type, profileName, displayName);
      const modIds = Array.isArray(inventoryItem?.mods) ? inventoryItem.mods.map(String) : [];
      const baseThreshold = melee || specialRangedKind ? 0 : parseThreshold(desc);
      const threshold = melee || specialRangedKind ? 0 : baseThreshold + weaponModThresholdBonus(modIds);
      let bonus = melee ? 0 : (specialRangedHitBonus(character, type, profileName, displayName) ?? (proficiency + Math.floor(accuracy / 2) - threshold));
      if (melee) {
        const tempWeapon = { profile: profileName, name: displayName, description: desc };
        const candidates = meleeSkillNames(tempWeapon).map(name => Math.round(safeNumber(characterSkillProfileDetailed(character, name, true)?.bonus, 0)));
        bonus = candidates.length ? Math.max(...candidates) : 0;
      }
      const dice = parseHitDice(desc || storedMatch?.description || '', type, profileName);
      const rangeInfo = parseRange(desc || storedMatch?.description || '');
      const storedNotes = Array.isArray(storedMatch?.notes) ? storedMatch.notes.map(String) : [];
      weapons.push({
        ...(storedMatch || {}),
        id: slot, slot, inventoryUid: inventoryItem?.uid || inventoryItem?.id || null,
        name: displayName, profile: profileName, type, melee,
        hitDieNormal: dice.normal || storedMatch?.hitDieNormal || '1d6', hitDieAimed: dice.aimed || '', hitBonus: bonus,
        ignoreMz: inventoryItem ? (/игнорирует\s+1\s+МЗ\s+цели/i.test(desc) ? 1 : 0) : Math.max(/игнорирует\s+1\s+МЗ\s+цели/i.test(desc) ? 1 : 0, Math.max(0, Math.round(safeNumber(storedMatch?.ignoreMz, 0)))),
        lightCoverIgnoreMz: Math.max((profileName==='Тяжёлый арбалет'||/игнорирует\s+1(?:\s+ед\.?)?\s+МЗ[^.;]*л[её]гк[^.;]*укрыт|пробивает\s+л[её]гк[^.;]*укрыт[^.;]*игнорирует\s+1(?:\s+ед\.?)?\s+МЗ/i.test(desc)) ? 1 : 0, Math.max(0, Math.round(safeNumber(storedMatch?.lightCoverIgnoreMz, 0)))),
        damage: desc ? parseDamage(desc) : Math.max(0, safeNumber(storedMatch?.damage, 1)),
        damageTag: parseDamageTag(item, desc) || storedMatch?.damageTag || 'medium',
        odCost: specialRangedKind === 'bow' ? 2 : (desc ? parseOdCost(desc) : Math.max(0, safeNumber(storedMatch?.odCost, 2))),
        aimedOdCost: parseAimedOdCost(desc, type, desc ? parseOdCost(desc) : storedMatch?.odCost, Boolean(dice.aimed)),
        obCost: canonicalBaseObCost(profileName, type, desc, storedMatch?.obCost),
        range: (rangeInfo.range > 5 || !storedMatch?.range ? rangeInfo.range : safeNumber(storedMatch.range, 5)) + ((proficiency >= threshold && (modIds.includes('pistol_long_barrel') || modIds.includes('carbine_heavy_barrel'))) ? 50 : 0),
        radius: rangeInfo.radius || Math.max(0, safeNumber(storedMatch?.radius, 0)),
        description: desc || storedMatch?.description || '',
        proficiency, baseThreshold, threshold, modificationsActive: Boolean(melee || specialRangedKind || proficiency >= threshold),
        mods: modIds,
        notes: [...new Set([...storedNotes, ...modIds])]
      });
    }
    return weapons;
  }

  function npcWeaponProficiencyCategory(weapon) {
    const direct=profCategory(String(weapon?.type||''));if(direct)return direct;
    const text=`${weapon?.profile||''} ${weapon?.name||''} ${weapon?.description||''}`;
    if(/пистолет|револьвер/i.test(text))return 'Пистолеты';
    if(/карабин|автомат/i.test(text))return 'Карабины';
    if(/снайпер|винтовк/i.test(text))return 'Винтовки';
    if(/дробовик/i.test(text))return 'Дробовики';
    if(/тяж[её]л|гранатом[её]т|пулем[её]т|излучатель|пушк|оруди/i.test(text))return 'Тяжёлое';
    return null;
  }
  function npcCombatBonus(npc, threshold = 0, weaponLike = null) {
    const legacy=npc?.weapon||{}, rawMode=String(npc?.weaponTrainingMode||legacy.bonusMode||'rank');
    const mode=rawMode==='formula'?'detailed':rawMode;
    if(mode==='detailed'){
      const category=npcWeaponProficiencyCategory(weaponLike||legacy), prof=Math.max(0,Math.round(safeNumber(category?npc?.weaponProficiencies?.[category]:legacy.proficiency,legacy.proficiency||0))), accuracy=Math.round(safeNumber(npc?.weaponAccuracy,legacy.accuracy||0));
      return Math.round(prof + Math.floor(accuracy / 2) - safeNumber(threshold, legacy.threshold || 0));
    }
    if(mode==='manual')return Math.round(safeNumber(npc?.manualCombatBonus,legacy.manualBonus||0));
    return ({ mob:0, regular:1, veteran:2, elite:3, boss:4 }[npc?.rank] ?? 1);
  }
  function mountedWeaponForGunner(gunner, weapon) {
    if (!weapon) return null;
    const result = { ...weapon };
    const threshold = Math.max(0, Math.round(safeNumber(weapon.threshold, 0)));
    const mountBonus = Math.round(safeNumber(weapon.manualBonus, weapon.hitBonus || 0));
    if (weapon.operatorTrainingMode !== 'operator' || !gunner) {
      result.hitBonus = mountBonus;
      result.modificationsActive = weapon.modificationsActive !== false;
      result.operatorTraining = { mode:'manual', mountBonus, threshold, trained:true };
      return result;
    }
    const category = npcWeaponProficiencyCategory(weapon);
    let proficiency = 0, accuracy = 0, baseBonus = 0, trained = true, mode = 'operator';
    if (gunner.kind === 'character') {
      const character = linkedCharacter(gunner), st = character?.state || {};
      proficiency = category ? Math.max(0, Math.round(safeNumber(st.weaponProficiencies?.[category], 0))) : 0;
      accuracy = Math.round(safeNumber(st?._lanRollProfile?.skills?.['Меткость']?.bonus, st?.skills?.['Меткость']?.bonus || 0));
      baseBonus = category ? proficiency + Math.floor(accuracy / 2) - threshold : 0;
      trained = !category || proficiency >= threshold;
      mode = 'character';
    } else if (gunner.kind === 'npc') {
      const npc = linkedNpc(gunner) || {}, trainingMode = String(npc.weaponTrainingMode || npc.weapon?.bonusMode || 'rank');
      baseBonus = npcCombatBonus(npc, threshold, weapon);
      if (trainingMode === 'detailed') {
        proficiency = category ? Math.max(0, Math.round(safeNumber(npc.weaponProficiencies?.[category], npc.weapon?.proficiency || 0))) : 0;
        accuracy = Math.round(safeNumber(npc.weaponAccuracy, npc.weapon?.accuracy || 0));
        trained = !category || proficiency >= threshold;
      }
      mode = `npc-${trainingMode}`;
    }
    result.hitBonus = Math.round(baseBonus + mountBonus);
    result.proficiency = proficiency;
    result.threshold = threshold;
    result.proficiencyCategory = category;
    result.modificationsActive = weapon.modificationsActive !== false && trained;
    result.operatorTraining = { mode, category, proficiency, accuracy, baseBonus, mountBonus, threshold, trained };
    return result;
  }
  function mountedWeaponNeedsReload(weapon) {
    return Boolean(weapon && (weapon.type === 'Тяжёлое' || Math.max(0, Math.round(safeNumber(weapon.reloadCost, 0))) > 0));
  }
  function mountedWeaponState(vehicle, weapon, create = true) {
    if (!vehicle?.vehicle || !weapon || !mountedWeaponNeedsReload(weapon)) return null;
    let states = vehicle.vehicle.mountedWeaponStates;
    if (!states || typeof states !== 'object' || Array.isArray(states)) {
      if (!create) return null;
      states = vehicle.vehicle.mountedWeaponStates = {};
    }
    const key = cleanId(weapon.id || weapon.name, null);
    if (!key) return null;
    if (!states[key] && create) states[key] = { loaded:true };
    return states[key] || null;
  }
  function assertMountedWeaponReady(vehicle, weapon) {
    const stateInfo = mountedWeaponState(vehicle, weapon, true);
    if (stateInfo?.loaded === false) throw Object.assign(new Error(`«${weapon.name}» разряжено. Сначала перезарядите орудие.`), { statusCode:409 });
  }
  function markMountedWeaponFired(vehicle, weapon) {
    const stateInfo = mountedWeaponState(vehicle, weapon, true);
    if (stateInfo) stateInfo.loaded = false;
  }
  function reloadMountedWeapon(vehicle, gunner, weapon) {
    if (!mountedWeaponNeedsReload(weapon)) throw Object.assign(new Error('Этот профиль не требует отдельной перезарядки.'), { statusCode:409 });
    const stateInfo = mountedWeaponState(vehicle, weapon, true);
    if (stateInfo.loaded !== false) throw Object.assign(new Error(`«${weapon.name}» уже заряжено.`), { statusCode:409 });
    const cost = Math.max(1, Math.round(safeNumber(weapon.reloadCost, 2)));
    spendTokenOd(gunner, cost);
    stateInfo.loaded = true;
    return { loaded:true, cost };
  }

  function npcCatalogWeapon(npc, raw, slot) {
    const directCatalog = weaponCatalog.get(String(raw?.name || '')) || {};
    const aliasProfile = canonicalWeaponProfileAlias(raw?.profile, raw?.name, directCatalog?.name);
    const profileCatalog = aliasProfile ? (weaponCatalog.get(aliasProfile) || {}) : {};
    // NPC inventories from older campaigns may store only a decorative model
    // name. Resolve the profile first, then inherit that profile's mechanics;
    // keep raw fields last so explicit GM overrides still win.
    const item = { ...profileCatalog, ...directCatalog, ...raw, desc: raw?.desc || raw?.description || directCatalog.desc || profileCatalog.desc || '' };
    const desc = parseWeaponDesc(item), type = String(item.type || ''), canonicalProfile=canonicalWeaponProfileAlias(item.profile,raw?.name,item.name,aliasProfile), melee = type === 'Оружие ближнего боя' || CANONICAL_MELEE_PROFILES.has(String(item.profile||'')) || CANONICAL_MELEE_PROFILES.has(canonicalProfile) || /ближн|рукопаш|нож|клинок|меч|мачете|кукри|сабл|тесак|топор|дубин|булав|молот|лопат|копь|алебард|багор|кастет|шты|безоруж/i.test(`${type} ${item.profile||''} ${item.name||''} ${desc}`);
    const dice = parseHitDice(desc, type, item.profile || item.name), rangeInfo = parseRange(desc), modIds=Array.isArray(raw?.mods)?raw.mods.map(String):[], baseThreshold = melee ? 0 : parseThreshold(desc), threshold=melee?0:baseThreshold+weaponModThresholdBonus(modIds);
    const trainingProbe={name:item.name,profile:item.profile||item.name,type,description:desc},trainingCategory=npcWeaponProficiencyCategory(trainingProbe),proficiency=melee?0:Math.max(0,Math.round(safeNumber(npc?.weaponProficiencies?.[trainingCategory],npc?.weapon?.proficiency||0))),trainingMode=String(npc?.weaponTrainingMode||npc?.weapon?.bonusMode||'rank'),detailedTraining=['detailed','formula'].includes(trainingMode),modificationsActive=Boolean(melee||!detailedTraining||proficiency>=threshold);
    return {
      id: String(raw?.uid || raw?.id || slot || item.name), slot, name: item.name || 'Оружие', profile: canonicalProfile || item.profile || item.name || 'Оружие', type, melee,
      hitDieNormal: dice.normal, hitDieAimed: dice.aimed, hitBonus: specialRangedHitBonus({state:{_lanRollProfile:{skills:{'Меткость':{bonus:safeNumber(npc?.weaponAccuracy,npc?.characteristics?.accuracy||0)},'Физическая сила':{bonus:safeNumber(npc?.characteristics?.strength,0)}}}}},type,canonicalProfile,item.name) ?? npcCombatBonus(npc, threshold, trainingProbe),
      ignoreMz: canonicalProfile==='Охотничий лук'||/игнорирует\s+1(?:\s+ед\.?)?\s+МЗ\s+цели/i.test(desc) ? 1 : 0,
      lightCoverIgnoreMz: canonicalProfile==='Тяжёлый арбалет'||/игнорирует\s+1(?:\s+ед\.?)?\s+МЗ[^.;]*л[её]гк[^.;]*укрыт|пробивает\s+л[её]гк[^.;]*укрыт[^.;]*игнорирует\s+1(?:\s+ед\.?)?\s+МЗ/i.test(desc) ? 1 : 0,
      damage: Math.max(0, parseDamage(desc)), damageTag: parseDamageTag(item, desc), odCost: weaponSpecialRangedKind(type,canonicalProfile,item.name)==='bow'?2:Math.max(0, parseOdCost(desc)), aimedOdCost: parseAimedOdCost(desc, type, parseOdCost(desc), Boolean(dice.aimed)), obCost: canonicalBaseObCost(canonicalProfile || item.profile || item.name, type, desc, 0),
      range: Math.max(5, rangeInfo.range)+(modificationsActive&&(modIds.includes('pistol_long_barrel')||modIds.includes('carbine_heavy_barrel'))?50:0), radius: Math.max(0, rangeInfo.radius), description: desc,
      proficiency, baseThreshold, threshold, proficiencyCategory:trainingCategory,
      modificationsActive,
      mods: modIds, notes: [...modIds]
    };
  }
  function customAttackWeapon(token, profile, index = 0) {
    const source = profile && typeof profile === 'object' ? profile : {};
    const category = ['natural','melee','ranged'].includes(source.category) ? source.category : (source.naturalWeapon ? 'natural' : source.melee ? 'melee' : 'ranged');
    const melee = category !== 'ranged';
    let hitBonus = Math.round(safeNumber(source.manualBonus, 0));
    if (source.bonusMode === 'formula') hitBonus = Math.round(safeNumber(source.proficiency,0) + Math.floor(safeNumber(source.accuracy,0)/2) - safeNumber(source.threshold,0));
    else if (source.bonusMode === 'rank' && token?.kind === 'npc') hitBonus = npcCombatBonus(linkedNpc(token), source.threshold, source);
    const properties = Array.isArray(source.properties) ? source.properties.map(String) : [];
    const propertyText = properties.join(', ');
    const description = [source.description, propertyText].filter(Boolean).join(propertyText && source.description ? ' · ' : '');
    return {
      id:String(source.id||`custom-attack-${index}`), slot:String(source.id||`custom-attack-${index}`),
      name:source.name||'Пользовательская атака', profile:source.profile||source.name||'Пользовательская атака',
      type:source.type||(melee?'Оружие ближнего боя':'Особое оружие'), melee, naturalWeapon:category==='natural'||Boolean(source.naturalWeapon), customProfile:true,
      hitDieNormal:normalizeDie(source.hitDie||source.hitDieNormal,'1d6'), hitDieAimed:source.hitDieAimed?normalizeDie(source.hitDieAimed,'1d6'):'', hitBonus,
      ignoreMz:Math.max(0,Math.round(safeNumber(source.ignoreMz,0))), damage:Math.max(0,Math.round(safeNumber(source.damage,2))),
      damageTag:['light','medium','heavy'].includes(source.damageTag)?source.damageTag:'medium', odCost:Math.max(0,Math.round(safeNumber(source.odCost,2))),
      aimedOdCost:source.hitDieAimed?Math.max(0,Math.round(safeNumber(source.aimedOdCost,safeNumber(source.odCost,2)+1))):null,
      obCost:Math.max(0,Math.round(safeNumber(source.obCost,0))), range:Math.max(melee?5:1,safeNumber(source.range,melee?5:100)),
      radius:Math.max(0,safeNumber(source.radius,0)), description, properties,
      proficiency:Math.max(0,Math.round(safeNumber(source.proficiency,0))), threshold:Math.max(0,Math.round(safeNumber(source.threshold,0))), modificationsActive:source.modificationsActive!==false,
      mods:Array.isArray(source.mods)?source.mods.map(String):[], notes:Array.isArray(source.notes)?source.notes.map(String):[], counterAllowed:source.counterAllowed!==false,
      freeAttackAllowed:source.freeAttackAllowed!==false, enabled:source.enabled!==false,
      soundId:source.soundId==='off'?'off':cleanId(source.soundId,null)
    };
  }
  function npcWeapons(npc, token = null) {
    if (!npc) return [];
    const inventory = Array.isArray(npc.inventory) ? npc.inventory : [], equipment = npc.equipment || {};
    const equipped = ['weapon1','weapon2'].map(slot => { const value=equipment[slot]; return inventory.find(item => String(item.uid||item.id||item.name||'')===String(value||'')) || (value&&typeof value==='object'?value:null); }).filter(Boolean);
    const listed = equipped.map((item,index) => npcCatalogWeapon(npc,item,index ? 'weapon2' : 'weapon1'));
    const custom = (Array.isArray(npc.attacks)?npc.attacks:[]).filter(item=>item?.enabled!==false).map((item,index)=>customAttackWeapon(token||{kind:'npc'},item,index));
    if (listed.length || custom.length) return [...listed, ...custom];
    const weapon = npc.weapon || {};
    const description=String(weapon.description||weapon.desc||''),modIds=Array.isArray(weapon.mods)?weapon.mods.map(String):[],baseThreshold=Math.max(0,Math.round(safeNumber(weapon.baseThreshold,safeNumber(weapon.threshold,parseThreshold(description))))),threshold=baseThreshold+weaponModThresholdBonus(modIds),trainingMode=String(npc?.weaponTrainingMode||weapon.bonusMode||'rank'),trainingProbe={name:weapon.name,profile:weapon.profile||weapon.name,type:weapon.type||'',description},trainingCategory=npcWeaponProficiencyCategory(trainingProbe),proficiency=Math.max(0,Math.round(safeNumber(trainingCategory?npc?.weaponProficiencies?.[trainingCategory]:weapon.proficiency,weapon.proficiency||baseThreshold))),modificationsActive=weapon.modificationsActive!==false&&(!['detailed','formula'].includes(trainingMode)||proficiency>=threshold);
    return [{
      id: 'npc-weapon', slot: 'npc-weapon', name: weapon.name || 'Оружие', profile: weapon.profile || weapon.name || 'Оружие', type: weapon.type || (weapon.melee ? 'Оружие ближнего боя' : 'NPC'), melee: Boolean(weapon.melee),
      hitDieNormal: normalizeDie(weapon.hitDie, '1d6'), hitDieAimed: weapon.hitDieAimed?normalizeDie(weapon.hitDieAimed,'1d6'):'', hitBonus: npcCombatBonus(npc, threshold), ignoreMz: Math.round(safeNumber(weapon.ignoreMz, 0)),
      damage: Math.max(0, Math.round(safeNumber(weapon.damage, 2))), damageTag: ['light','medium','heavy'].includes(weapon.damageTag) ? weapon.damageTag : 'medium',
      odCost: Math.max(0, Math.round(safeNumber(weapon.odCost, 2))), aimedOdCost: weapon.hitDieAimed ? Math.max(0, Math.round(safeNumber(weapon.aimedOdCost, safeNumber(weapon.odCost, 2) + 1))) : null, obCost: Math.max(0, Math.round(safeNumber(weapon.obCost, 0))), range: Math.max(5, safeNumber(weapon.range, 100))+(modificationsActive&&(modIds.includes('pistol_long_barrel')||modIds.includes('carbine_heavy_barrel'))?50:0), radius: Math.max(0, safeNumber(weapon.radius, 0)),
      description, proficiency, baseThreshold, threshold, modificationsActive,
      mods:modIds, notes:[...(Array.isArray(weapon.notes)?weapon.notes.map(String):[]),...modIds]
    }];
  }
  function characterCustomWeapons(token) {
    const character=linkedCharacter(token),profiles=Array.isArray(character?.state?._lanCustomWeapons)?character.state._lanCustomWeapons:[];
    return profiles.filter(item=>item?.enabled!==false).map((item,index)=>customAttackWeapon(token,item,index));
  }

  function unarmedWeaponForToken(token) {
    let bonus = 0;
    if (token?.kind === 'character') {
      const st = linkedCharacter(token)?.state || {};
      bonus = Math.round(safeNumber(st?._lanRollProfile?.skills?.['Физическая сила']?.bonus, st?.skills?.['Физическая сила']?.bonus || 0));
    } else if (token?.kind === 'npc') {
      bonus = Math.round(safeNumber(linkedNpc(token)?.characteristics?.strength, 0));
    }
    return {
      id: 'unarmed', slot: 'unarmed', name: 'Безоружный бой', profile: 'Безоружный бой', type: 'Оружие ближнего боя', melee: true,
      hitDieNormal: '1d4', hitDieAimed: '', hitBonus: bonus, ignoreMz: 0, damage: token?.kind === 'character' && safeNumber(linkedCharacter(token)?.state?.traits?.main?.['Сильный'],0) >= 6 ? 2 : 1, damageTag: 'light', odCost: 2, obCost: 0,
      range: 5, radius: 0, description: 'Безоружная атака. Встречный бросок; бонус Физической силы.', notes: []
    };
  }

  function weaponText(weapon){return `${weapon?.name||''} ${weapon?.profile||''} ${weapon?.type||''} ${weapon?.description||''}`;}
  // v1.7.8 weapon-mod combat integration: mods[] is the sole source of truth.
  // Conditional effects are calculated at attack time; they are never baked into
  // the cached _lanBattleProfile, preventing stale hit/damage/MZ bonuses.
  const WEAPON_MOD_THRESHOLD_BONUS=new Set(['pistol_weighted_frame','carbine_heavy_barrel','rifle_ap_barrel','heavy_fast_breech']);
  function weaponModIds(weapon){return [...new Set((Array.isArray(weapon?.mods)?weapon.mods:[]).map(String).filter(Boolean))];}
  function weaponHasMod(weapon,id){return weapon?.modificationsActive!==false&&weaponModIds(weapon).includes(id);}
  function weaponModThresholdBonus(ids){return (ids||[]).reduce((sum,id)=>sum+(WEAPON_MOD_THRESHOLD_BONUS.has(String(id))?1:0),0);}
  function weaponModRuntime(token,weapon,create=true){
    const actions=tokenActions(token);if(!actions)return null;
    if(!actions.weaponMods||typeof actions.weaponMods!=='object'||Array.isArray(actions.weaponMods)){if(!create)return null;actions.weaponMods={roundAction:false,states:{}};}
    actions.weaponMods.roundAction=false;actions.weaponMods.states=actions.weaponMods.states&&typeof actions.weaponMods.states==='object'?actions.weaponMods.states:{};
    const key=heavyWeaponKey(weapon);if(!actions.weaponMods.states[key]&&create)actions.weaponMods.states[key]={matchShots:0,matchNeedsCooling:false,matchFiredThisTurn:false,coolingShroudUsed:false};
    return actions.weaponMods.states[key]||null;
  }
  function weaponModPrepared(token,weapon,kind){
    const actions=tokenActions(token),key=heavyWeaponKey(weapon),state=kind==='rest'?actions.weaponModRest:actions.weaponModMount;
    return Boolean(state&&state.weaponKey===key);
  }
  function weaponModStateSummary(token,weapon){
    const actions=tokenActions(token),key=heavyWeaponKey(weapon),rt=weaponModRuntime(token,weapon,false)||{};
    return {
      restPrepared:Boolean(actions.weaponModRest?.weaponKey===key),
      mountPrepared:Boolean(actions.weaponModMount?.weaponKey===key),
      overchargeMode:actions.weaponModOvercharge?.weaponKey===key?String(actions.weaponModOvercharge.mode||''):null,
      matchShots:Math.max(0,Math.round(safeNumber(rt.matchShots,0))),
      matchNeedsCooling:Boolean(rt.matchNeedsCooling),
      coolingRequired:Boolean(rt.coolingRequired||weapon?.coolingRequired||weapon?.needsCooling),
      coolingShroudUsed:Boolean(rt.coolingShroudUsed)
    };
  }
  function weaponModCoolingBypass(token,weapon){
    if(!weaponHasMod(weapon,'heavy_cooling_shroud'))throw Object.assign(new Error('На оружии нет «Охлаждающего кожуха».'),{statusCode:409});
    const rt=weaponModRuntime(token,weapon,true);
    if(rt.coolingShroudUsed)throw Object.assign(new Error('Охлаждающий кожух уже использован в этом бою.'),{statusCode:409});
    if(!(rt.coolingRequired||weapon?.coolingRequired||weapon?.needsCooling))throw Object.assign(new Error('Сейчас оружие не требует охлаждения.'),{statusCode:409});
    rt.coolingRequired=false;rt.coolingShroudUsed=true;return rt;
  }
  function weaponModInstabilityPenalty(weapon){
    return Math.min(0,Math.round(safeNumber(weapon?.instabilityPenalty,0)+safeNumber(weapon?.overheatPenalty,0)+safeNumber(weapon?.recoilPenalty,0)));
  }
  function weaponModAttackEffects(weapon,{distance=0,shotMode='normal',moved=false,badVisibility=false,smoke=false,attacker=null,specialMode=null}={}){
    const out={hitBonus:0,damageBonus:0,ignoreMz:0,positiveHit:0,negativeHit:0,reasons:[],stealthBonus:0,stabilityReduction:0};
    if(!weapon||weapon.modificationsActive===false)return out;
    const ids=new Set(weaponModIds(weapon)),band=distanceBand(distance),close=band==='close',medium=band==='medium',long=band==='long',addHit=(n,why)=>{if(n>0)out.positiveHit+=n;else out.negativeHit+=n;out.reasons.push(`${n>=0?'+':''}${n}: ${why}`);};
    if(ids.has('pistol_micro_reflex')&&shotMode==='aimed')addHit(1,'Микроколлиматор: прицельный выстрел');
    if(ids.has('pistol_suppressor')){out.damageBonus-=1;out.stealthBonus=Math.max(out.stealthBonus,2);out.reasons.push('Глушитель: урон −1; +2 к повторной Скрытности после скрытой атаки');}
    if(ids.has('pistol_weighted_frame')&&!moved)addHit(1,'Утяжелённая рамка: стрелок не двигался');
    if(ids.has('pistol_light_bolt')){if(close&&shotMode==='normal')addHit(1,'Облегчённый затвор на ближней дистанции');else if(long)addHit(-1,'Облегчённый затвор на дальней дистанции');}
    if(ids.has('pistol_long_barrel')&&close)addHit(-1,'Длинный ствол пистолета на ближней дистанции');
    if(ids.has('carbine_reflex')&&(close||medium)&&!badVisibility&&!smoke)addHit(1,'Коллиматорный прицел');
    if(ids.has('carbine_lpvo')){if(medium)addHit(1,'Оптический прицел малой кратности');else if(close)addHit(-1,'Оптический прицел малой кратности вблизи');}
    if(ids.has('carbine_heavy_barrel')){if(close)addHit(-1,'Тяжёлый ствол карабина вблизи');if(long){out.damageBonus+=1;out.reasons.push('+1 урон: Тяжёлый ствол на дальней дистанции');}}
    if(ids.has('carbine_rest_rail')&&attacker&&weaponModPrepared(attacker,weapon,'rest')&&!moved){out.ignoreMz+=1;out.reasons.push('Упорная планка: игнор 1 МЗ при подготовленном упоре');}
    if(ids.has('rifle_scope')){if(long)addHit(1,'Снайперская оптика на дальней дистанции');else if(close)addHit(-1,'Снайперская оптика вблизи');}
    if(ids.has('rifle_match_barrel')){if(long){out.damageBonus+=1;out.reasons.push('+1 урон: Матчевый ствол на дальней дистанции');}const rt=attacker?weaponModRuntime(attacker,weapon,false):null;if(rt?.matchNeedsCooling)addHit(-2,'Матчевый ствол требует охлаждения');}
    if(ids.has('rifle_suppressor')){out.damageBonus-=1;out.stealthBonus=Math.max(out.stealthBonus,2);out.reasons.push('Глушитель: урон −1; +2 к повторной Скрытности после скрытой атаки');}
    if(ids.has('rifle_ap_barrel')){out.ignoreMz+=1;out.reasons.push('Бронебойный ствол: игнор 1 МЗ укрытия');}
    if(ids.has('shotgun_choke')&&medium)addHit(1,'Сужение ствола на средней дистанции');
    if(ids.has('shotgun_short_barrel'))addHit(close?1:-1,close?'Укороченный ствол вблизи':'Укороченный ствол на средней/дальней дистанции');
    if(ids.has('shotgun_long_barrel')&&close)addHit(-1,'Длинный ствол на ближней дистанции');
    if(ids.has('heavy_optic')&&!moved)addHit(1,'Тяжёлая оптика: стрелок не двигался');
    if(ids.has('heavy_mount')&&attacker&&weaponModPrepared(attacker,weapon,'mount')&&!moved){out.ignoreMz+=2;out.reasons.push('Станок: игнор 2 МЗ с установленной позиции');}
    const overcharge=attacker?tokenActions(attacker)?.weaponModOvercharge:null;
    if(ids.has('heavy_overcharge')&&overcharge?.weaponKey===heavyWeaponKey(weapon)){
      if(overcharge.mode==='damage'){out.damageBonus+=1;out.reasons.push('+1 урон: Усиленный заряд');}
      else if(overcharge.mode==='radius')out.reasons.push('Усиленный заряд: радиус +5 фт');
    }
    const instability=weaponModInstabilityPenalty(weapon),stabilizers=['pistol_heat_shroud','carbine_foregrip','rifle_muzzle_brake','heavy_damper'].filter(id=>ids.has(id));
    if(instability<0&&stabilizers.length){out.stabilityReduction=Math.min(-instability,1);out.positiveHit+=out.stabilityReduction;out.reasons.push(`+${out.stabilityReduction}: модификация снижает штраф перегрева/нестабильности`);}
    const capped=Math.min(2,out.positiveHit);if(out.positiveHit>2)out.reasons.push('Положительный бонус модификаций к попаданию ограничен +2');out.hitBonus=capped+out.negativeHit;
    return out;
  }
  function finalizeWeaponModAttack(token,weapon,attack){
    if(!token||!weapon||weapon.modificationsActive===false)return null;const ids=new Set(weaponModIds(weapon)),actions=tokenActions(token),rt=weaponModRuntime(token,weapon,true);
    if(ids.has('rifle_match_barrel')){rt.matchShots=Math.max(0,Math.round(safeNumber(rt.matchShots,0)))+1;rt.matchFiredThisTurn=true;if(rt.matchShots>=2)rt.matchNeedsCooling=true;}
    if(actions.weaponModOvercharge?.weaponKey===heavyWeaponKey(weapon))delete actions.weaponModOvercharge;
    if(attack?.stealthAtAttack&&attack.weaponModEffects?.stealthBonus>0)actions.weaponModStealthBonus={roundAction:false,bonus:attack.weaponModEffects.stealthBonus,weaponKey:heavyWeaponKey(weapon)};
    return rt;
  }
  function advanceWeaponModTurnState(token){
    if(!token)return;const actions=tokenActions(token),states=actions.weaponMods?.states||{};
    for(const rt of Object.values(states)){if(rt?.matchNeedsCooling){if(rt.matchFiredThisTurn)rt.matchFiredThisTurn=false;else{rt.matchNeedsCooling=false;rt.matchShots=0;}}else if(rt){if(rt.matchFiredThisTurn)rt.matchFiredThisTurn=false;else rt.matchShots=0;}}
  }
  const RIFLE_PROFILES = new Set(['Охотничья винтовка','Служебная винтовка','Снайперская винтовка','Анаксионная винтовка']);
  function rifleProfileForWeapon(weapon) {
    if (!weapon) return null;
    const canonical = canonicalWeaponProfileAlias(weapon.profile, weapon.name) || String(weapon.profile || weapon.name || '');
    const text = `${weaponText(weapon)} ${(weapon.notes||[]).join(' ')} ${(weapon.mods||[]).join(' ')}`;
    const eligible = RIFLE_PROFILES.has(canonical) || weapon.type === 'Снайперская винтовка' || /(?:охотничья|служебная|снайперская|анаксионная)\s+винтовка/i.test(text);
    if (!eligible) return null;
    const modificationsActive = weapon.modificationsActive !== false;
    const scope = modificationsActive && /rifle_scope|снайперская оптика/i.test(text);
    const bipod = modificationsActive && /rifle_bipod|сошки/i.test(text);
    const apBarrel = modificationsActive && /rifle_ap_barrel|бронебойный ствол/i.test(text);
    const parsedThreshold=parseThreshold(weapon.description||'');
    const baseThreshold = Math.max(0, Math.round(safeNumber(weapon.baseThreshold, parsedThreshold||weapon.threshold||0)));
    const effectiveThreshold = Math.max(0, baseThreshold + weaponModThresholdBonus(weaponModIds(weapon)));
    return {
      profile: canonical,
      eligible: true,
      scope, bipod, apBarrel,
      baseThreshold,
      effectiveThreshold,
      proficiency: Math.max(0, Math.round(safeNumber(weapon.proficiency, baseThreshold))),
      measuredFlatBonus: RIFLE_PROFILES.has(canonical) ? 1 : (/выверенн[^.;]*дополнительно[^.;]*\+1\s*к\s*попад/i.test(text) ? 1 : 0)
    };
  }
  function weaponIsRifle(weapon){return Boolean(rifleProfileForWeapon(weapon));}
  function weaponIsHeavy(weapon){return Boolean(weapon&&(weapon.type==='Тяжёлое'||/тяж[её]л(?:ый|ое)\s+(?:пулем[её]т|гранатом[её]т)|л[её]гкий гранатом[её]т|анаксионный излучатель/i.test(weaponText(weapon))));}
  function weaponIsExplosiveHeavy(weapon){return weaponIsHeavy(weapon)&&(/гранатом[её]т/i.test(weaponText(weapon))||safeNumber(weapon?.radius,0)>0&&!/излучатель/i.test(weaponText(weapon)));}
  // Runtime readiness keys include the current inventory/profile identity. This
  // prevents a weapon swapped into the same visual slot from inheriting the
  // loaded/unloaded state of the previous weapon.
  function heavyWeaponKey(weapon){
    const identity=weapon?.inventoryUid||canonicalWeaponProfileAlias(weapon?.profile,weapon?.name)||weapon?.profile||weapon?.name||'heavy';
    return cleanId(`${weapon?.slot||weapon?.id||'weapon'}:${identity}`,'heavy');
  }
  function specialRangedWeaponKey(weapon){
    const identity=weapon?.inventoryUid||canonicalWeaponProfileAlias(weapon?.profile,weapon?.name)||weapon?.profile||weapon?.name||'special-ranged';
    return cleanId(`${weapon?.slot||weapon?.id||'weapon'}:${identity}`,'special-ranged');
  }
  function specialRangedState(token,weapon,create=true){
    const kind=weaponSpecialRangedKind(weapon?.type,weapon?.profile,weapon?.name);if(!kind)return null;
    const actions=tokenActions(token);if(!actions.specialRangedWeapons||typeof actions.specialRangedWeapons!=='object'){if(!create)return null;actions.specialRangedWeapons={roundAction:false,states:{}};}
    actions.specialRangedWeapons.roundAction=false;actions.specialRangedWeapons.states=actions.specialRangedWeapons.states&&typeof actions.specialRangedWeapons.states==='object'?actions.specialRangedWeapons.states:{};
    const key=specialRangedWeaponKey(weapon);if(!actions.specialRangedWeapons.states[key]&&create)actions.specialRangedWeapons.states[key]=kind==='crossbow'?{loaded:true}:{drawn:false};
    return actions.specialRangedWeapons.states[key]||null;
  }
  function specialRangedReloadCost(weapon){return /тяж[её]л\w*\s+арбалет/i.test(`${weapon?.profile||''} ${weapon?.name||''} ${weapon?.description||''}`)?2:1;}
  function specialRangedAttackOdCost(token,weapon){
    const kind=weaponSpecialRangedKind(weapon?.type,weapon?.profile,weapon?.name);if(kind==='bow')return specialRangedState(token,weapon,true)?.drawn?1:2;
    return Math.max(0,safeNumber(weapon?.odCost,2));
  }
  function assertSpecialRangedReady(token,weapon){
    const kind=weaponSpecialRangedKind(weapon?.type,weapon?.profile,weapon?.name);if(!kind)return;
    assertSpecialRangedAmmo(token,weapon);
    if(kind==='crossbow'&&specialRangedState(token,weapon,true)?.loaded===false)throw Object.assign(new Error(`«${weapon.name}» разряжен. Сначала выполните перезарядку.`),{statusCode:409});
  }
  function markSpecialRangedFired(token,weapon){
    const kind=weaponSpecialRangedKind(weapon?.type,weapon?.profile,weapon?.name),st=specialRangedState(token,weapon,false);if(!kind||!st)return null;
    const ammo=consumeSpecialRangedAmmo(token,weapon);
    if(kind==='bow')st.drawn=false;else if(kind==='crossbow')st.loaded=false;
    return ammo;
  }
  function drawSpecialRangedWeapon(token,weapon){
    if(weaponSpecialRangedKind(weapon?.type,weapon?.profile,weapon?.name)!=='bow')throw Object.assign(new Error('Выбрано не оружие типа «Лук».'),{statusCode:400});
    assertSpecialRangedAmmo(token,weapon);const st=specialRangedState(token,weapon,true);if(st.drawn)throw Object.assign(new Error('Лук уже натянут.'),{statusCode:409});
    const cost=state.combat?.active?1:0;if(cost)spendTokenOd(token,cost);st.drawn=true;return{cost,drawn:true,ammoName:'Стрелы',ammoCount:specialRangedAmmoCount(token,weapon)};
  }
  function reloadSpecialRangedWeapon(token,weapon){
    if(weaponSpecialRangedKind(weapon?.type,weapon?.profile,weapon?.name)!=='crossbow')throw Object.assign(new Error('Выбрано не оружие типа «Арбалет».'),{statusCode:400});
    assertSpecialRangedAmmo(token,weapon);const st=specialRangedState(token,weapon,true);if(st.loaded!==false)throw Object.assign(new Error('Арбалет уже заряжен.'),{statusCode:409});
    const heavy=/тяж[её]л\w*\s+арбалет/i.test(`${weapon?.profile||''} ${weapon?.name||''} ${weapon?.description||''}`),cost=state.combat?.active?specialRangedReloadCost(weapon):0;
    if(heavy&&state.combat?.active&&safeNumber(movementRecord(token)?.spent,0)>.001)throw Object.assign(new Error('Тяжёлый арбалет нельзя перезаряжать после перемещения в этом ходу.'),{statusCode:409});
    if(cost)spendTokenOd(token,cost);st.loaded=true;if(heavy&&state.combat?.active)tokenActions(token).heavyCrossbowReload={roundAction:true,movementLocked:true,reason:'Перезарядка тяжёлого арбалета'};
    return{cost,loaded:true,heavy,ammoName:'Болты',ammoCount:specialRangedAmmoCount(token,weapon)};
  }
  function heavyWeaponState(token,weapon,create=true){
    if(!weaponIsHeavy(weapon))return null;const actions=tokenActions(token);if(!actions.heavyWeapons||typeof actions.heavyWeapons!=='object'){if(!create)return null;actions.heavyWeapons={roundAction:false,states:{}};}
    actions.heavyWeapons.roundAction=false;actions.heavyWeapons.states=actions.heavyWeapons.states&&typeof actions.heavyWeapons.states==='object'?actions.heavyWeapons.states:{};const key=heavyWeaponKey(weapon);
    if(!actions.heavyWeapons.states[key]&&create)actions.heavyWeapons.states[key]={loaded:true};return actions.heavyWeapons.states[key]||null;
  }
  function heavyReloadCost(weapon){const text=weaponText(weapon);return weaponHasMod(weapon,'heavy_fast_breech')||/ускоренн(?:ый|ого) затвор|перезарядк[^.;]*1\s*ОД/i.test(text)?1:Math.max(1,Math.round(safeNumber(weapon?.reloadCost,2)));}
  function shotgunProfileForWeapon(weapon) {
    if(!weapon)return null;
    const text=`${weaponText(weapon)} ${(weapon.notes||[]).join(' ')} ${(weapon.mods||[]).join(' ')}`;
    if(!/дробовик|огнем[её]тн/i.test(text))return null;
    const anaxion=/анаксионный дробовик/i.test(text);
    const flame=/огнем[её]тн/i.test(text);
    const modificationsActive=weapon.modificationsActive!==false;
    const slug=modificationsActive&&/пулевой ствол|shotgun_slug_barrel/i.test(text)&&!anaxion;
    let coneWidthFeet=/боевой дробовик/i.test(text)?15:10;
    const choke=modificationsActive&&/сужение ствола|shotgun_choke/i.test(text);
    const spreader=modificationsActive&&/расширенный раструб|shotgun_spreader/i.test(text);
    if(choke)coneWidthFeet=Math.max(5,coneWidthFeet-5);
    if(spreader)coneWidthFeet+=5;
    const hasCone=!anaxion&&!flame;
    const maxConeDepth=Math.min(30,Math.max(0,safeNumber(weapon.range,30)));
    return {
      // v1.4.0: «Конус» — ширина осыпи у дальней границы, а глубина
      // конусной атаки ограничена 30 футами независимо от полной дальности профиля.
      coneFeet:hasCone?maxConeDepth:0,
      coneDepthFeet:hasCone?maxConeDepth:0,
      coneWidthFeet:hasCone?Math.max(5,coneWidthFeet):0,
      conePatternFeet:hasCone?Math.max(5,coneWidthFeet):0,
      // Оставляем приблизительный угол только для обратной совместимости старых эффектов;
      // новая геометрия дробовика строится по ширине, а не по фиксированному углу.
      coneAngle:60,
      singleTargetOnly:Boolean(anaxion||flame),
      flame,
      slug,
      slugModeAvailable:slug,
      closeDie:/боевой дробовик/i.test(text)?'1d8':null,
      normalDie:/боевой дробовик/i.test(text)?'1d6':weapon.hitDieNormal,
      longBarrel:modificationsActive&&/длинный ствол|shotgun_long_barrel/i.test(text),
      shortBarrel:modificationsActive&&/укороченный ствол|shotgun_short_barrel/i.test(text),
      choke,
      spreader,
      modificationsActive
    };
  }
  function weaponIsShotgun(weapon) {
    return Boolean(weapon && /дробовик/i.test(weaponText(weapon)));
  }
  function decorateShotgunWeapon(weapon) {
    const profile=shotgunProfileForWeapon(weapon);if(!profile)return weapon;
    const result={...weapon,shotgun:true,coneFeet:profile.coneDepthFeet,coneDepthFeet:profile.coneDepthFeet,coneWidthFeet:profile.coneWidthFeet,coneAngle:profile.coneAngle,coneAttack:profile.coneDepthFeet>0,singleTargetOnly:profile.singleTargetOnly,flameCone:false,slugModeAvailable:profile.slugModeAvailable};
    // У Боевого дробовика 1к8/1к6 — дистанционный профиль, а не прицельный режим.
    if(/боевой дробовик/i.test(weaponText(result))){result.hitDieAimed='';result.aimedOdCost=null;}
    // Пулевой ствол и расширенный раструб больше не меняют базовый профиль постоянно:
    // их урон/стоимость применяются только к соответствующему режиму выстрела.
    return result;
  }
  function decorateWeaponForToken(token,weapon){
    const st=actionHost(token)||{};
    if(traumaBlocksWeapon(st,weapon))return{...weapon,unavailable:true,unavailableReason:'Травма не позволяет использовать двуручное оружие.'};
    let result=decorateShotgunWeapon({...weapon,_ownerState:st});
    delete result._ownerState;
    // Эти модификаторы применяются поверх сохранённого профиля, поэтому зоны ранений
    // начинают влиять на атаки сразу, не дожидаясь открытия листа или начала боя.
    const zeroMoralePenalty=safeNumber(st?.morale?.current,1)<=0&&!st?._battlemapActions?.ignoreZeroMoralePenalty?-3:0;
    const armorProfile=token?.kind==='npc'?normalizedNpcArmor(linkedNpc(token)||{}).profile:(equippedArmorForCharacter(st)?.profile||'');
    const seriousPenalty=safeNumber(st?.wounds?.serious,0)>0?(token?.kind==='character'&&bonusTraitLevel(token,'Крепкий')>=3?-1:armorSeriousPenaltyForProfile(armorProfile)):0;
    const hitPenalty=injuryHitPenalty(st,result)+seriousPenalty+zeroMoralePenalty,rangePenalty=injuryRangePenalty(st);
    result={...result,hitBonus:Math.round(safeNumber(result.hitBonus,0)+hitPenalty),range:Math.max(result.melee?0:5,safeNumber(result.range,0)-rangePenalty)};
    if(weaponHasMod(result,'heavy_cooling_shroud'))result.weaponModSpeedPenalty=-5;
    if(result.modificationsActive!==false&&weaponModIds(result).length){
      result.weaponModRuntime=clone(weaponModRuntime(token,result,true)||{});
      result.weaponModState=weaponModStateSummary(token,result);
    }
    const specialKind=weaponSpecialRangedKind(result.type,result.profile,result.name);
    if(specialKind){const specialState=specialRangedState(token,result,true),ammoName=specialRangedAmmoName(specialKind),ammoCount=specialRangedAmmoCount(token,result);result={...result,specialRangedKind:specialKind,effectiveOdCost:specialRangedAttackOdCost(token,result),ammoName,ammoCount};if(specialKind==='bow')result.drawn=Boolean(specialState?.drawn);else{result.loaded=specialState?.loaded!==false;result.reloadCost=specialRangedReloadCost(result);}}
    if(!weaponIsHeavy(result))return result;
    const stateInfo=heavyWeaponState(token,result,true);return{...result,heavy:true,loaded:stateInfo?.loaded!==false,reloadCost:heavyReloadCost(result)};
  }
  function assertHeavyWeaponReady(token,weapon){if(weaponIsHeavy(weapon)&&heavyWeaponState(token,weapon,true)?.loaded===false)throw Object.assign(new Error(`«${weapon.name}» разряжено. Сначала выполните перезарядку.`),{statusCode:409});}
  function markHeavyWeaponFired(token,weapon){if(!weaponIsHeavy(weapon))return;heavyWeaponState(token,weapon,true).loaded=false;}
  function reloadHeavyWeapon(token,weapon){if(!weaponIsHeavy(weapon))throw Object.assign(new Error('Выбрано не тяжёлое оружие.'),{statusCode:400});const stateInfo=heavyWeaponState(token,weapon,true);if(stateInfo.loaded!==false)throw Object.assign(new Error('Оружие уже заряжено.'),{statusCode:409});const cost=state.combat?.active?heavyReloadCost(weapon):0;if(cost)spendTokenOd(token,cost);stateInfo.loaded=true;return{cost,loaded:true};}

  function weaponsForToken(token) {
    const st = speciesStateForToken(token), natural = speciesNaturalWeapons(token);
    // Паллид сохраняет возможность пользоваться обычным оружием в Форме Вечного.
    // Волколак и рокурокуби с расправленной шеей ограничены естественным оружием.
    if (st?.species === 'werewolf' && st.werewolf?.transformed) return natural.map(item=>decorateWeaponForToken(token,item));
    if (st?.species === 'rokurokubi' && st.rokurokubi?.neckExtended) return natural.map(item=>decorateWeaponForToken(token,item));
    let list = [];
    if (token?.kind === 'character') list = [...fallbackWeaponsForCharacter(linkedCharacter(token)), ...characterCustomWeapons(token)];
    else if (token?.kind === 'npc') list = npcWeapons(linkedNpc(token), token);
    if (st?.species === 'pallid' && st.pallid?.transformed) return [...natural, ...list].map(item=>decorateWeaponForToken(token,item));
    if (token && ['character','npc'].includes(token.kind) && !list.some(item => item.id === 'unarmed' || item.name === 'Безоружный бой')) list.push(unarmedWeaponForToken(token));
    return list.map(item=>decorateWeaponForToken(token,item));
  }

  function actionHost(token) {
    if (token?.kind === 'character') return linkedCharacter(token)?.state || null;
    if (token?.kind === 'npc') return linkedNpc(token) || null;
    return null;
  }

  // --- v1.5.9 sniper/stealth tactical patch ---
  // Runtime data lives on the linked character/NPC, not on the visual token, so
  // it follows the combatant if the client refreshes its token representation.
  function sniperRuntime(token, create = true) {
    const host=actionHost(token);if(!host)return null;
    if(!host._battlemapSniper||typeof host._battlemapSniper!=='object'||Array.isArray(host._battlemapSniper)){
      if(!create)return null;
      host._battlemapSniper={positions:[]};
    }
    const rt=host._battlemapSniper;
    if(!Array.isArray(rt.positions))rt.positions=[];
    // Keep the save bounded. Old firing points stay zeroed during the battle,
    // but there is no value in retaining an unbounded history.
    if(rt.positions.length>24)rt.positions=rt.positions.slice(-24);
    return rt;
  }
  function stealthRuntime(token, create = true) {
    const host=actionHost(token);if(!host)return null;
    if(!host._battlemapCombatStealth||typeof host._battlemapCombatStealth!=='object'||Array.isArray(host._battlemapCombatStealth)){
      if(!create)return null;
      host._battlemapCombatStealth={active:false,difficultySides:6,difficultyModifier:0,hideFromPlayers:false};
    }
    return host._battlemapCombatStealth;
  }
  function isStealthed(token) {
    return Boolean(stealthRuntime(token,false)?.active);
  }
  function isCombatStealthed(token, scene = null) {
    if(!isStealthed(token)||!state.combat?.active)return false;
    if(scene&&state.combat.sceneId!==scene.id)return false;
    return Boolean(state.combat.participantTokenIds?.includes(token?.id));
  }
  function clearCombatRuntimeForToken(token) {
    const host=actionHost(token);if(!host)return;
    // Скрытность с v1.6.0 является общим состоянием сцены и переживает
    // начало/конец боя. Боевой runtime очищает только снайперские данные.
    delete host._battlemapSniper;
    delete host._battlemapSniperDebt;
    delete host._battlemapMainTraits;
    const actions=host._battlemapActions;
    if(actions&&typeof actions==='object')delete actions.counterSniperObservation;
  }
  function sniperPositionAtToken(scene, token) {
    const rt=sniperRuntime(token,false);if(!scene||!token||!rt?.positions?.length)return null;
    const point=speciesCombatPoint(token);
    let best=null;
    for(const position of rt.positions){
      const distance=distanceFeet(scene,point,position);
      // 10 feet is the minimum distance required to establish a new firing point.
      if(distance>=9.999)continue;
      if(!best||safeNumber(position.level,0)>safeNumber(best.level,0)||distance<best.distance)best={...position,distance};
    }
    return best;
  }
  function recordMeasuredShotPosition(scene, token) {
    const rt=sniperRuntime(token,true);if(!scene||!token||!rt)return null;
    const point=speciesCombatPoint(token);
    let position=null,bestDistance=Infinity;
    for(const candidate of rt.positions){
      const distance=distanceFeet(scene,point,candidate);
      if(distance<9.999&&distance<bestDistance){position=candidate;bestDistance=distance;}
    }
    if(!position){
      position={id:makeId('sniper-position'),x:point.x,y:point.y,level:1,createdAt:nowIso(),lastShotAt:nowIso()};
      rt.positions.push(position);
    }else{
      position.level=Math.min(3,Math.max(1,Math.round(safeNumber(position.level,1))+1));
      // Anchor remains the first established firing point. Small shifts under
      // 10 ft are still the same point for zeroing purposes.
      position.lastShotAt=nowIso();
    }
    rt.lastMeasuredAt=nowIso();
    rt.lastMeasuredPositionId=position.id;
    return {...position};
  }
  function counterSniperObservation(token, scene = null) {
    const observation=tokenActions(token)?.counterSniperObservation;
    if(!observation||observation.used)return null;
    const point=speciesCombatPoint(token);
    // Any voluntary or forced displacement cancels observation. Checking the
    // anchor here catches every movement path, including push/AI/special moves.
    if(Math.hypot(safeNumber(point.x,0)-safeNumber(observation.anchorX,0),safeNumber(point.y,0)-safeNumber(observation.anchorY,0))>.05)return null;
    if(scene&&state.combat?.sceneId!==scene.id)return null;
    return observation;
  }
  function counterSniperSmokeBlock(scene, from, to) {
    for(const effect of scene?.effects||[]){
      if(effect.type!=='smoke'||safeNumber(effect.remainingRounds,0)<=0)continue;
      const radiusPx=feetToScenePixels(scene,effect.radius||0),circle={shape:'circle',x:effect.x,y:effect.y,radius:radiusPx};
      if(!(pointInCover(from,circle)||pointInCover(to,circle)||lineIntersectsCover(from,to,circle)))continue;
      const passage=segmentCirclePassage(from,to,{x:effect.x,y:effect.y},radiusPx),sample=passage?.mid||(pointInCover(to,circle)?to:from);
      if(!effectSpreadBlocked(scene,effect,sample))return effect;
    }
    return null;
  }
  function publicSniperRuntime(scene,token){
    const rt=sniperRuntime(token,false),position=sniperPositionAtToken(scene,token),observation=counterSniperObservation(token,scene);
    if(!rt&&!observation)return null;
    return {
      zeroingLevel:Math.max(0,Math.round(safeNumber(position?.level,0))),
      positionId:position?.id||null,
      observation:observation?{active:true,weaponId:observation.weaponId,activatedAt:observation.activatedAt||null}:null
    };
  }

  // v1.6.1: Bonus Traits are first-class rule objects.  Their active uses,
  // scene resources and long-rest resources are kept separately from the older
  // specialization/doctrine feature state so old campaigns can be migrated safely.
  function bonusTraitLevel(tokenOrCharacter,name){
    let character=null;
    if(tokenOrCharacter?.kind==='character')character=linkedCharacter(tokenOrCharacter);
    else if(tokenOrCharacter?.state)character=tokenOrCharacter;
    const st=character?.state||{};
    return Math.max(0,Math.round(safeNumber(st?.traits?.bonus?.[name],0)));
  }
  function bonusTraitRuntime(host,create=true){
    if(!host)return null;
    if(!host._battlemapBonusTraits||typeof host._battlemapBonusTraits!=='object'||Array.isArray(host._battlemapBonusTraits)){
      if(!create)return null;
      host._battlemapBonusTraits={};
    }
    return host._battlemapBonusTraits;
  }
  function bonusSceneSerial(scene){return Math.max(0,Math.round(safeNumber(scene?._bonusTraitSceneSerial,0)));}
  function bonusSceneScope(scene){return `scene:${scene?.id||'unknown'}:${bonusSceneSerial(scene)}`;}
  function bonusBattleScope(scene){return `battle:${state.combat?.active&&state.combat?.sceneId===scene?.id?(state.combat.startedAt||'active'):'inactive'}`;}


  // v1.6.2: active rank-6 Main Trait abilities. Runtime is battle-scoped and
  // stored on the linked character so refreshes/token re-renders do not lose it.
  function mainTraitLevel(tokenOrCharacter,name){
    let entity=null;
    if(tokenOrCharacter?.kind==='character')entity=linkedCharacter(tokenOrCharacter);
    else if(tokenOrCharacter?.kind==='npc')entity=linkedNpc(tokenOrCharacter);
    else entity=tokenOrCharacter||null;
    if(entity?.state)return Math.max(0,Math.round(safeNumber(entity.state?.traits?.main?.[name],0)));
    const ids=new Set(Array.isArray(entity?.abilityIds)?entity.abilityIds:[]);
    if(name==='Бдительный')return ids.has('main-mark')?6:ids.has('main-pristrelka')?3:0;
    if(name==='Умный')return ids.has('main-experienced-look')?6:0;
    return 0;
  }
  function mainTraitRuntime(host,create=true){
    if(!host)return null;
    if(!host._battlemapMainTraits||typeof host._battlemapMainTraits!=='object'||Array.isArray(host._battlemapMainTraits)){
      if(!create)return null;
      host._battlemapMainTraits={};
    }
    return host._battlemapMainTraits;
  }
  function mainTraitCharacter(tokenOrCharacter){
    if(tokenOrCharacter?.kind==='character')return linkedCharacter(tokenOrCharacter);
    if(tokenOrCharacter?.kind==='npc')return linkedNpc(tokenOrCharacter);
    return tokenOrCharacter&&(tokenOrCharacter.state||tokenOrCharacter.rank)?tokenOrCharacter:null;
  }
  function mainTraitRuntimeHost(entity){return entity?.state||entity||null;}
  function activeMainTraitMark(tokenOrCharacter,scene,target=null){
    const character=mainTraitCharacter(tokenOrCharacter),rt=mainTraitRuntime(mainTraitRuntimeHost(character),false),mark=rt?.mark;
    if(!mark||mark.scope!==bonusBattleScope(scene))return null;
    if(target&&String(mark.targetTokenId||'')!==String(target.id||target))return null;
    return mark;
  }
  function setMainTraitMark(character,scene,target){
    const rt=mainTraitRuntime(mainTraitRuntimeHost(character),true);
    rt.mark={scope:bonusBattleScope(scene),targetTokenId:target.id,targetName:target.name,createdAt:nowIso(),firstAttackTurnKey:null};
    return rt.mark;
  }
  function experiencedLookState(tokenOrCharacter,scene,create=false){
    const character=mainTraitCharacter(tokenOrCharacter),rt=mainTraitRuntime(mainTraitRuntimeHost(character),create),scope=bonusBattleScope(scene);
    if(!rt)return null;
    if(!rt.experiencedLook||rt.experiencedLook.scope!==scope||typeof rt.experiencedLook.targets!=='object'||Array.isArray(rt.experiencedLook.targets)){
      if(!create)return null;
      rt.experiencedLook={scope,targets:{}};
    }
    return rt.experiencedLook;
  }
  function setExperiencedLookTarget(character,scene,target){
    const gaze=experiencedLookState(character,scene,true);
    gaze.targets[target.id]={targetTokenId:target.id,targetName:target.name,hitBonus:3,createdAt:nowIso()};
    return gaze.targets[target.id];
  }
  function activeExperiencedLook(tokenOrCharacter,scene,target){
    const gaze=experiencedLookState(tokenOrCharacter,scene,false);
    return gaze?.targets?.[target?.id]||null;
  }
  function pristrelkaState(tokenOrCharacter,scene,create=false){
    const character=mainTraitCharacter(tokenOrCharacter),rt=mainTraitRuntime(mainTraitRuntimeHost(character),create),scope=bonusBattleScope(scene);
    if(!rt)return null;
    if(!rt.pristrelka||rt.pristrelka.scope!==scope||typeof rt.pristrelka.targets!=='object'||Array.isArray(rt.pristrelka.targets)){
      if(!create)return null;
      rt.pristrelka={scope,targets:{}};
    }
    return rt.pristrelka;
  }
  function activePristrelka(tokenOrCharacter,scene,target){
    if(!state.combat?.active||state.combat.sceneId!==scene?.id||mainTraitLevel(tokenOrCharacter,'Бдительный')<3)return null;
    const rt=pristrelkaState(tokenOrCharacter,scene,false),entry=rt?.targets?.[target?.id];
    return entry&&Math.max(0,Math.round(safeNumber(entry.ownTurnsRemaining,0)))>0?entry:null;
  }
  function finalizePristrelkaAttack(scene,attacker,target,attack){
    if(!scene||!attacker||!target||!attack||!state.combat?.active||state.combat.sceneId!==scene.id||mainTraitLevel(attacker,'Бдительный')<3)return null;
    const character=mainTraitCharacter(attacker);if(!character)return null;
    const rt=pristrelkaState(character,scene,true),used=Boolean(attack.mainTraitEffects?.pristrelka?.applied&&String(attack.mainTraitEffects.pristrelka.targetTokenId||'')===String(target.id));
    if(used)delete rt.targets[target.id];
    let armed=null;
    if(!attack.hit){
      const ownTurnsRemaining=isCurrentCombatToken(scene,attacker)?2:1;
      armed=rt.targets[target.id]={targetTokenId:target.id,targetName:target.name,hitBonus:2,ownTurnsRemaining,createdAt:nowIso()};
    }
    attack.mainTraitEffects=attack.mainTraitEffects||{};
    attack.mainTraitEffects.pristrelkaResolution={used,armed:armed?{targetTokenId:target.id,hitBonus:2,ownTurnsRemaining:armed.ownTurnsRemaining}:null};
    if(used||armed){if(attacker.kind==='character')markCharacterChanged(attacker,null);else if(attacker.kind==='npc'){const npc=linkedNpc(attacker);if(npc)npc.updatedAt=nowIso();}}
    return attack.mainTraitEffects.pristrelkaResolution;
  }
  function expirePristrelkaAtOwnerTurnEnd(token,scene){
    if(!token||!['character','npc'].includes(token.kind))return false;
    const character=mainTraitCharacter(token),rt=pristrelkaState(character,scene,false);if(!rt)return false;let changed=false;
    for(const [targetId,entry] of Object.entries(rt.targets||{})){
      entry.ownTurnsRemaining=Math.max(0,Math.round(safeNumber(entry.ownTurnsRemaining,0))-1);changed=true;
      if(entry.ownTurnsRemaining<=0)delete rt.targets[targetId];
    }
    return changed;
  }
  function mainTraitAttackTurnKey(scene,attacker){
    if(!state.combat?.active||state.combat.sceneId!==scene?.id||!isCurrentCombatToken(scene,attacker))return null;
    const initiative=getCampaign().initiative||{};
    return `${bonusBattleScope(scene)}:${Math.max(1,Math.round(safeNumber(initiative.round,1)))}:${Math.max(0,Math.round(safeNumber(initiative.currentIndex,0)))}:${attacker.id}`;
  }
  function consumeMarkedFirstAttackAdvantage(scene,attacker,target){
    const mark=activeMainTraitMark(attacker,scene,target),turnKey=mark?mainTraitAttackTurnKey(scene,attacker):null;
    if(!mark||!turnKey||mark.firstAttackTurnKey===turnKey)return false;
    mark.firstAttackTurnKey=turnKey;
    return true;
  }
  function mainTraitTargetVisibleToToken(scene,viewer,target){
    if(!scene||!viewer||!target)return false;
    const targetOwner=tokenOwnerId(target,scene),viewerOwner=tokenOwnerId(viewer,scene);
    if(target.hidden&&targetOwner!==viewerOwner)return false;
    const stealth=stealthRuntime(target,false);
    if(stealth?.hideFromPlayers&&isStealthed(target)&&targetOwner!==viewerOwner&&!activeMainTraitMark(viewer,scene,target))return false;
    return reactionSourceCanSee(scene,viewer,target);
  }
  function mainTraitViewerHasMark(scene,clientId,target){
    if(!scene||!clientId||!target)return false;
    for(const viewer of scene.tokens||[]){
      if(viewer.kind!=='character'||tokenOwnerId(viewer,scene)!==clientId)continue;
      if(activeMainTraitMark(viewer,scene,target)&&reactionSourceCanSee(scene,viewer,target))return true;
    }
    return false;
  }
  function mainTraitFeatureEntries(character){
    const result=[];
    if(mainTraitLevel(character,'Бдительный')>=3)result.push({
      key:'mainTrait:Бдительный:3',kind:'mainTrait',sourceId:'Бдительный:3',name:'Бдительный 3 — Пристрелка',ability:'Пристрелка',frequency:'пассивно',
      text:'Если ваша дальнобойная атака по цели промахнулась, следующая дальнобойная атака по этой же цели до конца вашего следующего хода получает +2 к попаданию. Эффект применяется только к одной следующей атаке и не складывается сам с собой.',
      explicitActions:[]
    });
    if(mainTraitLevel(character,'Бдительный')>=6)result.push({
      key:'mainTrait:Бдительный:6',kind:'mainTrait',sourceId:'Бдительный:6',name:'Бдительный 6 — Метка',ability:'Метка',frequency:'1 раз за бой',
      text:'1 раз за бой, 3 ОД: выберите видимую цель. До конца боя она получает −2 МЗ против ваших атак и не может стать Скрытой от вас. Первая атака по ней в каждом вашем ходу совершается с преимуществом. Метка не увеличивает урон и не позволяет видеть или атаковать сквозь непрозрачные препятствия.',
      explicitActions:[{id:'main-mark',label:'Метка (3 ОД)',slot:'main-mark',target:'target',odCost:3}]
    });
    if(mainTraitLevel(character,'Умный')>=6)result.push({
      key:'mainTrait:Умный:6',kind:'mainTrait',sourceId:'Умный:6',name:'Умный 6 — Опытный взгляд',ability:'Опытный взгляд',frequency:'по ситуации',
      text:'1 ОД: пройдите проверку Анализа против 1к10. При успехе узнайте здоровье, мораль и уязвимость цели; до конца боя получаете +3 к попаданию по этой цели. Бонус к урону не предоставляется.',
      explicitActions:[{id:'main-experienced-look',label:'Опытный взгляд (1 ОД)',slot:'main-experienced-look',target:'target',odCost:1}]
    });
    return result;
  }
  function bonusLongRestUsage(host){const rt=bonusTraitRuntime(host,true);rt.longRestUsed=rt.longRestUsed&&typeof rt.longRestUsed==='object'&&!Array.isArray(rt.longRestUsed)?rt.longRestUsed:{};return rt.longRestUsed;}
  function bonusAbilityUsage(host){const rt=bonusTraitRuntime(host,true);rt.uses=rt.uses&&typeof rt.uses==='object'&&!Array.isArray(rt.uses)?rt.uses:{};return rt.uses;}
  function bonusAbilityScope(scene,scope){return scope==='scene'?bonusSceneScope(scene):scope==='long-rest'?'long-rest':bonusBattleScope(scene);}
  function bonusAbilityUsed(host,scene,key,scope='battle'){
    if(scope==='long-rest')return Boolean(bonusLongRestUsage(host)[key]);
    return Boolean(bonusAbilityUsage(host)[`${bonusAbilityScope(scene,scope)}:${key}`]);
  }
  function markBonusAbilityUsed(host,scene,key,scope='battle'){
    if(scope==='long-rest'){bonusLongRestUsage(host)[key]=nowIso();return;}
    bonusAbilityUsage(host)[`${bonusAbilityScope(scene,scope)}:${key}`]=nowIso();
  }
  function fortuneState(character,scene){
    const st=character?.state||{},level=bonusTraitLevel(character,'Удачливый'),max=level>=4?2:level>=1?1:0,scope=bonusSceneScope(scene),rt=bonusTraitRuntime(st,true);
    if(!rt.fortune||rt.fortune.scope!==scope)rt.fortune={scope,current:max,max};
    rt.fortune.max=max;rt.fortune.current=clamp(Math.round(safeNumber(rt.fortune.current,max)),0,max);
    return rt.fortune;
  }
  function luckyFortuneAvailable(character,scene,minLevel=1){return bonusTraitLevel(character,'Удачливый')>=minLevel&&fortuneState(character,scene).current>0;}
  function spendFortune(character,scene){
    const fortune=fortuneState(character,scene);
    if(fortune.current<=0)throw Object.assign(new Error('Фортуна на эту сцену уже израсходована.'),{statusCode:409});
    fortune.current-=1;return fortune;
  }
  function studiedTargetState(character,scene){
    const st=character?.state||{},rt=bonusTraitRuntime(st,true),scope=bonusSceneScope(scene);
    if(!rt.studiedTarget||rt.studiedTarget.scope!==scope)rt.studiedTarget={scope,targetTokenId:null,studiedAt:null,lastFact:null};
    return rt.studiedTarget;
  }
  function studiedTargetToken(character,scene){
    const studied=studiedTargetState(character,scene);
    return studied.targetTokenId?findToken(scene,studied.targetTokenId):null;
  }
  function reactionSourceCanHear(scene,source,target,maxFeet=30){
    if(!scene||!source||!target||criticalState(source).dead)return false;
    return distanceFeet(scene,speciesCombatPoint(source),speciesCombatPoint(target))<=Math.max(0,safeNumber(maxFeet,30))+.01;
  }
  function eligibleConfidentLeaders(scene,target,minLevel=3){
    return (scene?.tokens||[]).filter(source=>source?.kind==='character'&&bonusTraitLevel(source,'Уверенный')>=minLevel&&!criticalState(source).dead&&reactionSourceCanHear(scene,source,target,minLevel>=3?30:30)&&(!tokensHostile(source,target)));
  }
  function confidentPresenceReduction(scene,target){
    if(!scene||!target)return 0;
    return (scene.tokens||[]).some(source=>source?.kind==='character'&&bonusTraitLevel(source,'Уверенный')>=3&&!tokenUnableToReact(source)&&!tokensHostile(source,target)&&distanceFeet(scene,speciesCombatPoint(source),speciesCombatPoint(target))<=10.01)?2:0;
  }
  const BONUS_TRAIT_DEFS={
    'Крепкий':[
      ['Закалка','Преимущество на Выдержку, Стойкость и Иммунитет при боли, яде, болезни, истощении, холоде, жаре и иных тяжёлых физических условиях.','по ситуации'],
      ['Болевой порог','Среднее ранение даёт −1 к боевым проверкам вместо помехи.','пассивно'],
      ['На ногах','Серьёзное ранение даёт −10 футов Скорости и −1 к проверкам вместо половины Скорости и −2.','пассивно'],
      ['Второе дыхание','1 раз за бой после попадания можно уменьшить одно некритическое ранение на одну ступень.','1 раз за бой'],
      ['Тяжело убить','Критический отсчёт длится 4 раунда; проверки Медицины для вашей стабилизации получают преимущество.','пассивно'],
      ['Отказ умирать','1 раз до большого привала Критическое ранение превращается в Серьёзное, которое может выйти сверх лимита.','1 раз до большого привала']
    ],
    'Уверенный':[
      ['Самообладание','1 раз за сцену перед проверкой Харизмы или Воли получите преимущество.','1 раз за сцену'],
      ['Поддержать','1 раз за бой за 1 ОД: союзник в 30 фт, который вас слышит, восстанавливает 1к6 морали.','1 раз за бой'],
      ['Присутствие','Вы и союзники в 10 фт уменьшаете каждую потерю морали на 2, минимум до 0.','пассивно'],
      ['Не падать духом','1 раз за бой уменьшите потерю морали себе или слышащему вас союзнику в 30 фт на 1к8.','1 раз за бой'],
      ['Не сломаться','1 раз за бой, когда мораль слышащего вас союзника в 30 фт должна упасть до 0, она остаётся на 1.','1 раз за бой'],
      ['За мной!','1 раз за бой за 2 ОД: союзники в 30 фт выбирают 1к8 морали или 10 фт к укрытию без Зоны обстрела.','1 раз за бой']
    ],
    'Удачливый':[
      ['Второй шанс','Фортуна: после проваленной собственной проверки или атаки перебросьте её; второй результат обязателен.','ресурс Фортуны'],
      ['Счастливый промах','Фортуна: когда атака попала по вам, заставьте атакующего перебросить попадание; второй результат обязателен.','ресурс Фортуны'],
      ['Удачный поворот','Собственный переброс через «Второй шанс» получает +1к4 к повторному результату.','пассивно'],
      ['Любимец судьбы','В начале сцены вы получаете 2 Фортуны вместо 1.','пассивно'],
      ['На волосок','Фортуна: провал проверки на 1–3 можно превратить в «Успех на грани» с последствием на одну ступень легче.','ресурс Фортуны'],
      ['Не сегодня','1 раз до большого привала, когда вы должны погибнуть, вы выживаете.','1 раз до большого привала']
    ],
    'Вдумчивый':[
      ['Наблюдение','В бою за 1 ОД изучите видимую цель; вне боя достаточно короткого наблюдения. Узнайте один доступный наблюдению факт о цели.','по ситуации'],
      ['Читать движения','+1 МЗ против первой атаки Изученной цели по вам в каждом раунде.','пассивно'],
      ['Просчитанный момент','1 раз за бой после действия Изученной цели: следующая атака или встречная проверка против неё получает преимущество.','1 раз за бой'],
      ['Ожидать худшего','1 раз за сцену первая Бдительность против внезапности/засады получает преимущество, если угрозу физически можно заметить.','1 раз за сцену'],
      ['Указать слабость','1 раз за бой за 1 ОД: союзник в 30 фт получает преимущество на следующую атаку/направленную проверку против вашей Изученной цели.','1 раз за бой'],
      ['Я это предусмотрел','1 раз за сцену при видимой непосредственной угрозе выполните подходящее неатакующее действие стоимостью 1 ОД как реакцию; ОД вычитается из ближайшего хода.','1 раз за сцену']
    ]
  };
  function bonusTraitFeatureEntries(character){
    const result=[];
    for(const [trait,defs] of Object.entries(BONUS_TRAIT_DEFS)){
      const level=bonusTraitLevel(character,trait);
      for(let idx=0;idx<Math.min(level,defs.length);idx++){
        const rank=idx+1,[ability,text,frequency]=defs[idx],entry={key:`bonusTrait:${trait}:${rank}`,kind:'bonusTrait',sourceId:`${trait}:${rank}`,trait,rank,name:`${trait} ${rank} — ${ability}`,ability,text,frequency,explicitActions:[]};
        if(trait==='Крепкий'&&rank===1)entry.rollSkills=['Выдержка','Стойкость','Иммунитет'];
        if(trait==='Уверенный'&&rank===1)entry.rollSkills=['Убеждение','Обман','Интуиция','Запугивание','Очарование','Воля'];
        if(trait==='Вдумчивый'&&rank===4)entry.rollSkills=['Бдительность'];
        if(trait==='Уверенный'&&rank===2)entry.explicitActions=[{id:'bonus-support',label:'Поддержать союзника (1 ОД)',slot:'bonus-support',target:'target',odCost:1}];
        if(trait==='Уверенный'&&rank===4)entry.explicitActions=[{id:'bonus-morale-brace',label:'Подготовить реакцию на фиксированную потерю морали',slot:'bonus-morale-brace',target:'target',odCost:0}];
        if(trait==='Уверенный'&&rank===6)entry.explicitActions=[{id:'bonus-follow-me',label:'За мной! (2 ОД)',slot:'bonus-follow-me',target:'self',odCost:2}];
        if(trait==='Вдумчивый'&&rank===1)entry.explicitActions=[{id:'bonus-study',label:'Изучить цель',slot:'bonus-study',target:'target',odCost:1}];
        if(trait==='Вдумчивый'&&rank===3)entry.explicitActions=[{id:'bonus-calculated',label:'Просчитанный момент',slot:'bonus-calculated',target:'self',odCost:0}];
        if(trait==='Вдумчивый'&&rank===5)entry.explicitActions=[{id:'bonus-point-weakness',label:'Указать слабость (1 ОД)',slot:'bonus-point-weakness',target:'target',odCost:1}];
        if(trait==='Вдумчивый'&&rank===6)entry.explicitActions=[{id:'bonus-foresaw',label:'Я это предусмотрел (реакция 1 ОД)',slot:'bonus-foresaw',target:'self',odCost:0}];
        result.push(entry);
      }
    }
    return result;
  }
  function bonusTraitStatus(scene,token,character){
    const st=character?.state||{},fortune=fortuneState(character,scene),studied=studiedTargetState(character,scene),studiedToken=studied.targetTokenId?findToken(scene,studied.targetTokenId):null;
    const mark=activeMainTraitMark(character,scene),markToken=mark?.targetTokenId?findToken(scene,mark.targetTokenId):null,gaze=experiencedLookState(character,scene,false),pristrelka=pristrelkaState(character,scene,false);
    const experiencedLookTargets=Object.values(gaze?.targets||{}).map(item=>findToken(scene,item.targetTokenId)).filter(Boolean).map(item=>({id:item.id,name:item.name}));
    const pristrelkaTargets=Object.values(pristrelka?.targets||{}).filter(item=>Math.max(0,Math.round(safeNumber(item.ownTurnsRemaining,0)))>0).map(item=>{const target=findToken(scene,item.targetTokenId);return target?{id:target.id,name:target.name,hitBonus:2,ownTurnsRemaining:item.ownTurnsRemaining}:null;}).filter(Boolean);
    return{
      fortune:{current:fortune.current,max:fortune.max},
      studiedTarget:studiedToken?{id:studiedToken.id,name:studiedToken.name}:null,
      markedTarget:markToken?{id:markToken.id,name:markToken.name}:null,
      pristrelkaTargets,
      experiencedLookTargets,
      thoughtfulDebt:Math.max(0,Math.round(safeNumber(st._battlemapThoughtfulDebt,0))),
      refusalToDieUsed:Boolean(bonusLongRestUsage(st)['Крепкий:6']),
      notTodayUsed:Boolean(bonusLongRestUsage(st)['Удачливый:6'])
    };
  }
  function consumeFeatureEffectForTarget(token,slot,targetTokenId){
    const effects=featureEffects(token),value=effects?.[slot]||null;
    if(!value)return null;
    if(value.targetTokenId&&String(value.targetTokenId)!==String(targetTokenId||''))return null;
    delete effects[slot];return value;
  }

  // v1.0.19: manual, context-approved mechanics for Specializations,
  // Doctrines and Character traits. The VTT deliberately does not decide
  // whether the narrative condition is satisfied. «1 раз за сцену» refers to
  // a narrative scene rather than a VTT map, so that limit is deliberately
  // left to the GM. Only the unambiguous «1 раз за бой» limit is enforced.
  function characterFeatureEntries(character) {
    const st=ensureSpeciesRuntime(character?.state||{})||{}, result=[];
    const add=(kind,id)=>{
      const data=catalogOptionFor(st,kind,id);if(!data)return;
      const text=String(kind==='characterTrait'?(data.support||data.effect||''):(data.effect||data.support||''));
      const frequency=String(data.frequency||(/1\s+раз\s+за\s+бой/i.test(text)?'1 раз за бой':'1 раз за сцену'));
      result.push({key:`${kind}:${id}`,kind,sourceId:String(id),name:data.name||String(id),text,frequency,core:kind==='doctrine'&&st.coreDoctrine===id});
    };
    for(const id of (Array.isArray(st.specializations)?st.specializations:[]))add('specialization',id);
    for(const id of (Array.isArray(st.doctrines)?st.doctrines:[]))add('doctrine',id);
    for(const id of (Array.isArray(st.characterTraits)?st.characterTraits:[]))add('characterTrait',id);
    result.push(...mainTraitFeatureEntries(character));
    result.push(...bonusTraitFeatureEntries(character));
    return result;
  }
  function featureKindLabel(kind){return kind==='specialization'?'Специализация':kind==='doctrine'?'Доктрина':kind==='bonusTrait'?'Бонусная черта':kind==='mainTrait'?'Основная черта':'Черта характера';}
  function additiveDiceFromText(text) {
    const source=String(text||''), result=[];
    const pattern=/\+\s*1[кd](4|6|8|10|12)(?:\s+к\s+([^.!;\n]+))?/ig;
    let match;
    while((match=pattern.exec(source))){
      const sides=Number(match[1]),context=String(match[2]||'').trim(),before=source.slice(Math.max(0,match.index-140),match.index),targetPhrase=context.split(/[,;:]/,1)[0].trim();
      const kind=/попадан/i.test(targetPhrase)?'attack':/^(?:морал|урон|потер)/i.test(targetPhrase)?'other':'check';
      result.push({sides,context,kind,afterFailure:/после\s+(?:провал|неудач)/i.test(before)});
    }
    return result;
  }
  function featureMechanics(entry) {
    if(entry?.kind==='bonusTrait'||entry?.kind==='mainTrait')return Array.isArray(entry.explicitActions)?entry.explicitActions.map(action=>({...action})):[];
    const text=String(entry?.text||''),actions=[],seen=new Set(),sourceOdCost=Math.max(0,Math.round(safeNumber(/потратьте\s+(\d+)\s+ОД/i.exec(text)?.[1],0))),afterRollText=/после\s+броска|можно\s+применить\s+после\s+броска/i.test(text);
    const add=(id,label,slot,target='self',extra={})=>{if(seen.has(id))return;seen.add(id);actions.push({id,label,slot,target,odCost:sourceOdCost,...extra});};
    for(const bonusDie of additiveDiceFromText(text)){
      if(bonusDie.kind==='attack')add(`attack-die-${bonusDie.sides}`,`Добавить 1к${bonusDie.sides} к следующему попаданию`,'nextAttack','self',{extraDie:bonusDie.sides});
      else if(bonusDie.kind==='check')add(`check-die-${bonusDie.sides}${bonusDie.afterFailure?'-after-failure':afterRollText?'-after-roll':''}`,`${bonusDie.afterFailure?'После неудачи добавить':afterRollText?'После броска добавить':'Добавить'} 1к${bonusDie.sides} к следующей проверке`,'nextCheck','target',{extraDie:bonusDie.sides,afterFailure:bonusDie.afterFailure,afterRoll:afterRollText});
    }
    const hitFlat=/\+\s*(\d+)\s+к\s+попадан/i.exec(text);
    if(hitFlat)add(`attack-flat-${hitFlat[1]}`,`+${hitFlat[1]} к следующему попаданию`,'nextAttack','self',{flat:Number(hitFlat[1])});
    const defense=/\+\s*(\d+)\s+к\s+(?:сложности\s+попадания|МЗ)/i.exec(text);
    if(defense)add(`defense-flat-${defense[1]}`,`+${defense[1]} МЗ против следующей атаки`,'nextDefense','target',{flat:Number(defense[1])});
    const restore=/(?:восстанов(?:ите|ить|ит)|восстанавлива(?:ет|ют)|восстановите\s+(?:себе|союзнику))[^.!]{0,90}?1[кd](4|6|8|10|12)\s+морал/i.exec(text);
    if(restore)add(`morale-restore-${restore[1]}`,`Восстановить 1к${restore[1]} морали`,'moraleRestore','target',{die:Number(restore[1])});
    const reduce=/уменьш(?:ите|ает|ить)[^.!]{0,100}?потер[^.!]{0,50}?морал[^.!]{0,50}?1[кd](4|6|8|10|12)/i.exec(text)
      ||/уменьш(?:ите|ает|ить)[^.!]{0,100}?1[кd](4|6|8|10|12)[^.!]{0,50}?морал/i.exec(text)
      ||/морал[^.!]{0,140}?уменьш(?:ите|ает|ить)[^.!]{0,80}?потер[^.!]{0,50}?1[кd](4|6|8|10|12)/i.exec(text);
    if(reduce)add(`morale-reduce-${reduce[1]}`,`Уменьшить следующую потерю морали на 1к${reduce[1]}`,'moraleReduction','target',{die:Number(reduce[1])});
    if(/преимуществ[^.!]{0,100}?проверк/i.test(text))add('check-advantage','Преимущество на следующую проверку','nextCheck','target',{condition:'advantage'});
    if(/после\s+провал[^.!]{0,120}?переброс|перебросьте\s+(?:её|проверку)/i.test(text))add('check-reroll','Перебросить следующую неудачную проверку','nextCheck','target',{reroll:true,rerollPenalty:/второй\s+результат\s+получает\s*[−-]1/i.test(text)?-1:0});
    const nextCheck=/\+\s*(\d+)\s+к\s+(?:ближайшей|следующей)\s+провер/i.exec(text);
    if(nextCheck)add(`check-flat-${nextCheck[1]}`,`+${nextCheck[1]} к следующей проверке`,'nextCheck','target',{flat:Number(nextCheck[1])});
    if(/следующ(?:ая|ей)\s+атак(?:а|е)\s+или\s+проверк|ближайшей\s+проверке\s+или/i.test(text)){
      add('check-flat-1','+1 к следующей проверке','nextCheck','target',{flat:1});
      add('attack-flat-1','+1 к следующему попаданию','nextAttack','target',{flat:1});
    }
    const targetAttackPenalty=/(?:цель|выбранная\s+цель)[^.!]{0,120}?получает\s*[−-](\d+)\s+к\s+(?:своей\s+следующей\s+атаке|попадан)/i.exec(text);
    if(targetAttackPenalty){
      const penalty=-Number(targetAttackPenalty[1]),successRider=/если\s+атак[а-яё]*\s+успеш/i.test(text);
      if(!successRider)add(`target-attack-penalty-${targetAttackPenalty[1]}`,`Цель получает −${targetAttackPenalty[1]} к следующему попаданию`,'nextAttack','target',{flat:penalty});
      // Some features (notably «Боец ближнего боя») include a rider that is
      // granted by the same successful attack. Preserve that rider on the
      // self attack effect so it is applied automatically instead of requiring
      // a second activation that the 1/battle limit would reject.
      for(const prepared of actions)if(prepared.slot==='nextAttack'&&prepared.target==='self')prepared.onHitTargetAttackPenalty=penalty;
    }
    const safeMove=/переместитесь\s+на\s+(\d+)\s+(?:фт|фут)[^.!]{0,100}?без\s+провоцирования\s+реакц/i.exec(text);
    if(safeMove)add(`safe-move-${safeMove[1]}`,`Переместиться на ${safeMove[1]} фт без провоцирования реакций`,'safeMove','self',{feet:Number(safeMove[1])});
    const coverDamage=/нанесите\s+\+(\d+)\s+урон\s+укрыт/i.exec(text);
    if(coverDamage)add(`cover-damage-${coverDamage[1]}`,`+${coverDamage[1]} урона следующему атакованному укрытию`,'nextCoverDamage','self',{flat:Number(coverDamage[1])});
    if(/игнорирует\s+штраф\s+от\s+нулевой\s+морали/i.test(text))add('ignore-zero-morale','Игнорировать штраф от нулевой морали до конца следующего хода','ignoreZeroMorale','target');
    const areaShift=/сместить\s+точку\s+попадания\s+на\s+(\d+)\s+(?:фт|фут)/i.exec(text);
    if(areaShift)add(`area-shift-${areaShift[1]}`,`Разрешить смещение точки следующей зональной атаки на ${areaShift[1]} фт`,'areaShift','self',{feet:Number(areaShift[1])});
    if(entry?.core)add('core-doctrine-morale','Стержневая Доктрина: восстановить 1к8 морали','moraleRestore','self',{die:8,coreDoctrine:true,odCost:0});
    // Narrative or complex riders are still selectable: the use is logged and
    // its frequency is consumed, while the GM resolves the non-numerical part.
    add('declare','Заявить использование','declare','self');
    for(const action of actions)action.reactionOnly=Boolean(action.slot==='nextCheck'&&(action.reroll||action.afterFailure||action.afterRoll||action.extraDie));
    return actions;
  }
  function featureScopeKey(scene,entry) {
    const frequency=String(entry?.frequency||'');
    if(/бой/i.test(frequency))return bonusBattleScope(scene);
    if(entry?.kind==='bonusTrait'&&/сцен/i.test(frequency))return bonusSceneScope(scene);
    return null;
  }
  function featureUsage(host){if(!host)return{};if(!host._battlemapFeatureUsage||typeof host._battlemapFeatureUsage!=='object'||Array.isArray(host._battlemapFeatureUsage))host._battlemapFeatureUsage={};return host._battlemapFeatureUsage;}
  function featureUsedForHost(host,scene,entry){const scope=featureScopeKey(scene,entry);return scope?Boolean(featureUsage(host)[`${scope}:${entry.key}`]):false;}
  function markFeatureUsedForHost(host,scene,entry){const scope=featureScopeKey(scene,entry);if(scope)featureUsage(host)[`${scope}:${entry.key}`]=nowIso();}
  function featureEffects(token){const host=actionHost(token);if(!host)return{};if(!host._battlemapFeatureEffects||typeof host._battlemapFeatureEffects!=='object'||Array.isArray(host._battlemapFeatureEffects))host._battlemapFeatureEffects={};return host._battlemapFeatureEffects;}
  function peekFeatureEffect(token,slot){return featureEffects(token)?.[slot]||null;}
  function consumeFeatureEffect(token,slot){const effects=featureEffects(token),value=effects?.[slot]||null;if(value)delete effects[slot];return value;}
  function armFeatureEffect(token,slot,effect){const effects=featureEffects(token);effects[slot]={...effect,armedAt:nowIso()};return effects[slot];}
  function expireFeatureEffectsAtOwnerTurnEnd(token){
    const effects=featureEffects(token);let changed=false;
    for(const [slot,effect] of Object.entries(effects||{})){
      if(!effect?.expiresAfterOwnerTurn)continue;
      if(effect.skipCurrentOwnerTurnEnd){effect.skipCurrentOwnerTurnEnd=false;changed=true;continue;}
      delete effects[slot];changed=true;
    }
    return changed;
  }
  function featureEffectRoll(effect){return effect?.extraDie?rollOne(effect.extraDie):0;}
  function rollModeFormula(die,mode=0){
    const sides=dieSides(die,6),prefix=mode===0?`1d${sides}`:`2d${sides} (${mode>0?'лучший':'худший'})`;
    return prefix;
  }
  function rollSequenceFormula(die,mode=0,forcedReroll=false){
    const base=rollModeFormula(die,mode),sides=dieSides(die,6);
    return forcedReroll?`${base} → 1d${sides} (обязательный переброс, используется последний)` : base;
  }
  function signedFormulaBonus(value){const n=Math.round(safeNumber(value,0));return n?`${n>0?'+':''}${n}`:'';}
  function attackFormulaText(die,mode,extraDie,baseBonus,targetText,forcedReroll=false,additionalDice=[]){
    const parts=[rollSequenceFormula(die,mode,forcedReroll)];
    if(extraDie)parts.push(`+1d${Math.max(2,Math.round(safeNumber(extraDie,0)))}`);
    for(const extra of additionalDice||[])parts.push(`+1d${Math.max(2,Math.round(safeNumber(extra,0)))}`);
    const bonus=signedFormulaBonus(baseBonus);if(bonus)parts.push(bonus);return `${parts.join(' ')} vs ${targetText}`;
  }
  function journalRollFormulas(primary,...results){
    const formulas=[];if(primary)formulas.push(String(primary));
    for(const result of results){
      if(!result)continue;
      if(result.formula)formulas.push(String(result.formula));
      const moraleRolls=Array.isArray(result.moraleRolls)?result.moraleRolls:[];if(moraleRolls.length)formulas.push(`Мораль: ${moraleRolls.length}d10`);
      const reduction=result.moraleReduction;if(reduction?.effect?.die)formulas.push(`Снижение потери морали (${reduction.effect.sourceName||'особенность'}): 1d${reduction.effect.die}`);
      if(result.beastCheck?.formula)formulas.push(`Зверь: ${result.beastCheck.formula}`);
      if(result.beastRoll?.formula)formulas.push(`Зверь: ${result.beastRoll.formula}`);
      for(const nearby of Array.isArray(result.nearbyBeastChecks)?result.nearbyBeastChecks:[]){if(nearby?.roll?.formula)formulas.push(`Зверь — ${nearby.tokenName||'рядом'}: ${nearby.roll.formula}`);}
    }
    return [...new Set(formulas.filter(Boolean))];
  }
  function attackTotalBreakdown(attack, melee=false){
    const extra=Math.round(safeNumber(attack?.featureEffects?.attackRoll,0));
    const total=Math.round(safeNumber(melee?attack?.attackerTotal:attack?.total,0));
    if(!extra)return String(total);
    const baseRoll=Math.round(safeNumber(melee?attack?.attackerRoll:attack?.roll,0));
    const baseBonus=Math.round(safeNumber(melee?attack?.attackerBaseBonus:attack?.baseHitBonus,0));
    const sides=Math.max(0,Math.round(safeNumber(attack?.featureEffects?.attack?.extraDie,0)));
    const source=cleanName(attack?.featureEffects?.attack?.sourceName,'Особенность');
    const parts=[String(baseRoll),`${sides?`1к${sides}`:'добавочный куб'}=${extra} («${source}»)`];
    if(baseBonus)parts.push(`${baseBonus>0?'+':''}${baseBonus}`);
    return `${parts.join(' + ').replace(/\+ \+/g,'+ ')} = ${total}`;
  }
  function checkTotalBreakdown(roll){
    const extra=Array.isArray(roll?.extraRolls)?roll.extraRolls:[];
    if(!extra.length)return String(Math.round(safeNumber(roll?.successTotal,roll?.total)));
    const baseRoll=Math.round(safeNumber(roll?.successRoll,0)),extraSum=extra.reduce((sum,item)=>sum+Math.round(safeNumber(item?.roll,0)),0);
    const baseBonus=Math.round(safeNumber(roll?.successBonus,roll?.modifier)-extraSum),parts=[String(baseRoll)];
    for(const item of extra)parts.push(`${String(item?.die||'добавочный куб').replace(/^1d/i,'1к')}=${Math.round(safeNumber(item?.roll,0))} («${cleanName(item?.name,'Особенность')}»)`);
    if(baseBonus)parts.push(`${baseBonus>0?'+':''}${baseBonus}`);
    return `${parts.join(' + ').replace(/\+ \+/g,'+ ')} = ${Math.round(safeNumber(roll?.successTotal,roll?.total))}`;
  }
  function applyPendingMoraleReduction(token,total){
    const effect=consumeFeatureEffect(token,'moraleReduction'),before=Math.max(0,Math.round(safeNumber(total,0)));
    if(!effect)return{before,total:before,reduction:0,roll:0,effect:null};
    const roll=rollOne(Math.max(2,Math.round(safeNumber(effect.die,6)))),reduction=Math.min(before,roll);
    return{before,total:Math.max(0,before-reduction),reduction,roll,effect};
  }

  async function applyPendingMoraleReductionResolved(scene,token,total,body={}){
    const effect=consumeFeatureEffect(token,'moraleReduction'),before=Math.max(0,Math.round(safeNumber(total,0)));
    if(!effect)return{before,total:before,reduction:0,roll:0,effect:null,rollRecord:null};
    const resolved=await resolveScalarRoll(scene,token,{body,label:`${token.name}: уменьшение потери морали — ${effect.sourceName||'особенность'}`,sides:Math.max(2,Math.round(safeNumber(effect.die,6))),kind:'morale-reduction',purpose:'morale-reduction'}),roll=resolved.value,reduction=Math.min(before,roll);
    return{before,total:Math.max(0,before-reduction),reduction,roll,effect,rollRecord:resolved.roll};
  }
  function fixedMoraleLossWithBonusTraits(scene,target,rawLoss){
    const host=actionHost(target),before=Math.max(0,Math.round(safeNumber(rawLoss,0))),presence=confidentPresenceReduction(scene,target),afterPresence=Math.max(0,before-presence);
    const prepared=applyPendingMoraleReduction(target,afterPresence);
    let total=prepared.total,steadiedBy=null;
    if(host?.morale&&safeNumber(host.morale.current,0)>0&&safeNumber(host.morale.current,0)-total<=0){
      const leader=(scene?.tokens||[]).find(source=>source?.kind==='character'&&source.id!==target.id&&bonusTraitLevel(source,'Уверенный')>=5&&!tokenUnableToReact(source)&&!tokensHostile(source,target)&&reactionSourceCanHear(scene,source,target,30)&&!bonusAbilityUsed(linkedCharacter(source)?.state,scene,'Уверенный:5','battle'));
      if(leader){
        const leaderState=linkedCharacter(leader)?.state||{};
        total=Math.max(0,Math.round(safeNumber(host.morale.current,0))-1);
        markBonusAbilityUsed(leaderState,scene,'Уверенный:5','battle');steadiedBy=leader.name;
      }
    }
    return{before,total,presenceReduction:presence,preparedReduction:prepared,steadiedBy};
  }

  function criticalState(token) {
    if (!token || !['character','npc'].includes(token.kind)) return { critical:false, dead:false, stabilized:false, elapsed:0, limit:3, remaining:0, canAttack:false };
    const host = actionHost(token) || {};
    if(token.kind==='character')ensureCharacterMedicalState(host);
    else {host.wounds ||= {light:0,lightMax:1,medium:0,mediumMax:0,serious:0,seriousMax:0,critical:false};host.criticalRounds=Math.max(0,Math.round(safeNumber(host.criticalRounds,0)));host.stabilized=Boolean(host.stabilized);host.dead=Boolean(host.dead);host.bleeding=Boolean(host.bleeding);host.failedStabilizers=Array.isArray(host.failedStabilizers)?host.failedStabilizers:[];host.failedStabilizerIds=Array.isArray(host.failedStabilizerIds)?host.failedStabilizerIds:[];}
    const wounds = host.wounds || {};
    const medical = token.kind === 'character' ? host.medical : host;
    const critical = Boolean(wounds.critical);
    const dead = Boolean(medical.dead || token.defeated && !critical);
    const stabilized = token.kind === 'character' ? Boolean(medical.stabilized) : Boolean(host.stabilized);
    const tough = token.kind === 'character' ? Math.max(0, safeNumber(host.traits?.bonus?.['Крепкий'], host.traits?.bonus?.Крепкий || 0)) : 0;
    const limit = tough >= 5 ? 4 : 3;
    const elapsed = Math.max(0, Math.round(safeNumber(medical.criticalRounds, 0)));
    return { critical, dead, stabilized, elapsed, limit, remaining:Math.max(0, limit - elapsed), canAttack:false, attackPenalty:0, host, medical, wounds };
  }

  function initializeCriticalCountdown(scene, token) {
    const info = criticalState(token);
    if (!info.critical || info.dead) return info;
    info.medical.criticalRounds = Math.max(0, Math.round(safeNumber(info.medical.criticalRounds, 0)));
    info.medical.stabilized = false;
    info.medical.failedStabilizers = [];
    info.medical.failedStabilizerIds = [];
    if (state.combat?.active && state.combat.sceneId === scene?.id) info.medical._criticalSkipCurrentTurn = isCurrentCombatToken(scene, token);
    return criticalState(token);
  }

  function assertTokenCanAct(token, { attack=false, movement=false } = {}) {
    const info = criticalState(token);
    if (info.dead) throw Object.assign(new Error('Персонаж мёртв и не может действовать.'), { statusCode:409 });
    if (!info.critical) return info;
    if (movement) throw Object.assign(new Error('Критическое ранение обездвиживает персонажа.'), { statusCode:409 });
    throw Object.assign(new Error('Критическое ранение не позволяет совершать действия.'), { statusCode:409 });
  }

  function narrativeControl(token) {
    token.gmNarrative = normalizeNarrativeControl(token.gmNarrative);
    return token.gmNarrative;
  }
  function consumeNarrative(token, kind) {
    const n = narrativeControl(token), result = { condition:'normal', bonus:0, damageBonus:0, note:n.note || '' };
    if (kind === 'attack') { result.condition=n.attackCondition; result.bonus=n.attackBonus; result.damageBonus=n.damageBonus; n.attackCondition='normal'; n.attackBonus=0; n.damageBonus=0; }
    else if (kind === 'defense') { result.condition=n.defenseCondition; result.bonus=n.defenseBonus; n.defenseCondition='normal'; n.defenseBonus=0; }
    else { result.condition=n.checkCondition; result.bonus=n.checkBonus; n.checkCondition='normal'; n.checkBonus=0; }
    if(n.attackCondition==='normal'&&!n.attackBonus&&!n.damageBonus&&n.defenseCondition==='normal'&&!n.defenseBonus&&n.checkCondition==='normal'&&!n.checkBonus)n.note='';
    token.updatedAt = nowIso();
    return result;
  }
  function mergeRollCondition(baseAdvantage, baseHindrance, narrativeCondition) {
    const score=(baseAdvantage?1:0)-(baseHindrance?1:0)+(narrativeCondition==='advantage'?1:narrativeCondition==='hindrance'?-1:0);
    return score>0?1:score<0?-1:0;
  }

  function tokenActions(token) {
    const host = actionHost(token); if (!host) return {};
    if (!host._battlemapActions || typeof host._battlemapActions !== 'object' || Array.isArray(host._battlemapActions)) host._battlemapActions = {};
    return host._battlemapActions;
  }
  function clearRoundActions(token) {
    const actions = tokenActions(token);
    for (const [key, value] of Object.entries(actions)) if (value?.roundAction !== false) delete actions[key];
  }
  function consumeBlock(token) {
    const actions = tokenActions(token);
    if (!actions.block) return false;
    delete actions.block;
    return true;
  }
  function tokenMovementLockReason(token){
    const actions=tokenActions(token);if(actions?.block)return 'Блок активен: персонаж не может двигаться, пока Блок не снят или не израсходован.';
    const locked=Object.values(actions||{}).find(value=>value&&typeof value==='object'&&value.movementLocked===true);return locked?.reason?`${locked.reason}: движение до конца хода недоступно.`:(locked?'Движение до конца хода недоступно из-за совершённого действия.':'');
  }
  function tokenMovementLocked(token) { return Boolean(tokenMovementLockReason(token)); }
  function assertTokenMovementUnlocked(token) {
    if(token?.boardedVehicleId)throw Object.assign(new Error('Персонаж находится в транспорте. Сначала используйте действие «Выйти».'),{statusCode:409});
    const reason=tokenMovementLockReason(token);if(reason)throw Object.assign(new Error(reason),{statusCode:409});
  }
  function tokenOd(token) {
    if (token?.kind === 'character') {
      const st = ensureSpeciesRuntime(linkedCharacter(token)?.state || {}) || {};
      const baseMax=safeNumber(st.od, st.odMax || st.odCurrent || 0), formBonus=st.species==='pallid'&&st.pallid?.transformed?1:0;
      return { current: safeNumber(st.odCurrent, baseMax + formBonus), max: baseMax + formBonus, host: st, currentKey: 'odCurrent' };
    }
    if (token?.kind === 'npc') {
      const npc = linkedNpc(token); npc.od ||= {};
      return { current: safeNumber(npc.od.current, npc.od.max || 0), max: safeNumber(npc.od.max, npc.od.current || 0), host: npc.od, currentKey: 'current' };
    }
    return null;
  }
  function spendTokenOd(token, amount) {
    const info = tokenOd(token); amount = Math.max(0, Math.round(safeNumber(amount, 0)));
    if (!info) throw Object.assign(new Error('У токена нет Очков Действий.'), { statusCode: 400 });
    if (info.current < amount) throw Object.assign(new Error(`Недостаточно ОД: требуется ${amount}.`), { statusCode: 409 });
    info.host[info.currentKey] = info.current - amount;
  }
  function refundTokenOd(token, amount) {
    const info = tokenOd(token); amount = Math.max(0, Math.round(safeNumber(amount, 0)));
    if (!info) return;
    info.host[info.currentKey] = Math.min(info.max, info.current + amount);
  }

  function tokenDefensiveMzBonus(token) {
    let bonus = Math.round(safeNumber(tokenActions(token)?.crossing?.mzBonus, 0) + safeNumber(tokenActions(token)?.aberrantMzBonus, 0));
    if (token?.kind === 'vehicle' && (token.vehicle?.evasiveUntilDriverTurn || token.vehicle?.sharpManeuverRound === (getCampaign().initiative?.round || 0))) bonus += 1;
    return bonus;
  }

  function tokenNaturalMz(token) {
    if (token?.kind === 'vehicle') return Math.max(0, Math.round(safeNumber(token.vehicle?.mz, 4)));
    if (token?.mzOverride !== null && token?.mzOverride !== undefined) return Math.max(0, Math.round(safeNumber(token.mzOverride, 4)));
    const character = linkedCharacter(token);
    if (character) {
      const st = ensureSpeciesRuntime(character.state || {}) || {};
      const acrobatics = Math.round(safeNumber(st?._lanRollProfile?.skills?.['Акробатика']?.bonus, st?.skills?.['Акробатика']?.bonus || 0));
      // Базовое МЗ по текущим правилам: 4 + Акробатика. Старое state.mz=4
      // оставалось техническим полем листа и не должно подменять расчёт навыка.
      return Math.max(0, 4 + acrobatics + (st.species==='werewolf' && st.werewolf?.transformed ? 2 : 0));
    }
    const npc = linkedNpc(token);
    if (npc) {
      const manualBaseMz = npc.baseMz;
      if (manualBaseMz !== null && manualBaseMz !== undefined && manualBaseMz !== '' && Number.isFinite(Number(manualBaseMz))) return Math.max(0, Math.round(Number(manualBaseMz)));
      return Math.max(0, 4 + Math.round(safeNumber(npc.characteristics?.dexterity, 0)));
    }
    return 4;
  }

  function shortRangeNaturalMz(naturalMz, distance) {
    const value = Math.max(0, Math.round(safeNumber(naturalMz, 4)));
    return distance <= 15.001 ? Math.ceil(value / 2) : value;
  }

  function tokenBaseMz(token) {
    return tokenNaturalMz(token) + tokenDefensiveMzBonus(token);
  }

  function combatMzBreakdown(scene, target, activeToken = null) {
    const base=Math.max(0,Math.round(tokenBaseMz(target))),manualMz=Math.round(safeNumber(target?.coverBonus,0));
    let coverInfo={mz:0,source:null,ignored:[]},zoneMz=0,peeking=false;
    if(scene&&activeToken&&activeToken.id!==target.id){
      const origin=speciesCombatPoint(activeToken),destination=speciesCombatPoint(target);
      peeking=Boolean(tokenActions(activeToken)?.peek)&&tokenAdjacentToCover(scene,activeToken);
      coverInfo=automaticCoverInfo(scene,origin,destination,{ignoreNearOrigin:peeking,originToken:activeToken});
      zoneMz=automaticZoneMz(scene,origin,destination);
    }
    const coverMz=Math.max(0,Math.round(safeNumber(coverInfo.mz,0)));
    return {base,coverMz,zoneMz,bonusMz:manualMz,effective:Math.max(base,coverMz)+zoneMz+manualMz,coverSource:coverInfo.source||null,relativeToTokenId:activeToken?.id||null,peeking};
  }

  function feetToScenePixels(scene, feet) { return Number(feet||0) / Math.max(.001, scene.grid.feet) * Math.max(1, scene.grid.size); }

  function distanceFeet(scene, a, b) {
    const px = Math.hypot(a.x - b.x, a.y - b.y);
    return px / Math.max(1, scene.grid.size) * scene.grid.feet;
  }

  // Contact range follows occupied grid cells rather than centre-to-centre
  // Euclidean distance. One neighbouring cell is always one FATUM step (5 ft),
  // including a diagonal neighbour. This keeps melee and adjacent abilities
  // usable after token overlap was forbidden, even on legacy scenes whose
  // grid distance value was accidentally saved as 10 ft.
  function contactDistanceFeet(scene, a, b) {
    const cell = Math.max(1, safeNumber(scene?.grid?.size, 70));
    const dx = Math.abs(safeNumber(a?.x, 0) - safeNumber(b?.x, 0));
    const dy = Math.abs(safeNumber(a?.y, 0) - safeNumber(b?.y, 0));
    // Contact actions use the FATUM combat cell (5 ft), not the scene's generic
    // ruler scale. Measure the empty grid layers between token footprints. Any
    // two tokens in touching/neighboring cells — including diagonals and small
    // visual tokens — are therefore one contact step (5 ft) apart.
    const halfA = tokenFootprintHalfSize(scene, a);
    const halfB = tokenFootprintHalfSize(scene, b);
    const edgeGap = Math.max(0, Math.max(dx, dy) - halfA - halfB);
    const extraGridLayers = Math.max(0, Math.floor((edgeGap + cell * 1e-6) / cell));
    return (extraGridLayers + 1) * 5;
  }

  function distanceBand(distance) { return distance <= 10 ? 'close' : distance <= 30 ? 'medium' : 'long'; }

  function conditionalWeaponModifier(weapon, distance, body) {
    const text = String(weapon.description || '');
    const band = distanceBand(distance);
    let value = 0;
    const reasons = [];
    const add = (amount, reason) => { value += amount; reasons.push(`${amount >= 0 ? '+' : ''}${amount}: ${reason}`); };
    const profileAbilitiesActive = weapon?.modificationsActive !== false;
    if (/на дальней дистанции\s*-1\s*к\s*попад/i.test(text) && band === 'long') add(-1, 'штраф оружия на дальней дистанции');
    if (profileAbilitiesActive && /на ближней дистанции\s*\+1\s*к\s*попад/i.test(text) && band === 'close') add(1, 'бонус оружия на ближней дистанции');
    if (profileAbilitiesActive && /на дальней дистанции\s*\+1\s*к\s*попад/i.test(text) && band === 'long' && body.moved !== true) add(1, 'бонус оружия на дальней дистанции без движения');
    const previousTurnHitBonus = /(?:если стрелок не двигался[^.]*в прошлом ходу[^.]*\+1\s*к\s*попад|\+1\s*к\s*попад[^.]*если стрелок не двигался[^.]*в прошлом ходу)/i.test(text);
    if (profileAbilitiesActive && previousTurnHitBonus && body.hasPreviousTurn===true && body.previousTurnMoved!==true) add(1, 'стрелок не двигался в прошлом ходу');
    else if (profileAbilitiesActive && /если стрелок не двигался[^.]*\+1\s*к\s*попад/i.test(text) && !/в прошлом ходу/i.test(text) && body.moved !== true) add(1, 'стрелок не двигался');
    if (profileAbilitiesActive && /цели без укрытия\s*\+1\s*к\s*попад/i.test(text) && !body.hasCover) add(1, 'цель без укрытия');
    return { value, reasons };
  }

  function canonicalCombatWeaponProfile(weapon) {
    if (!weapon) return '';
    const canonical = canonicalWeaponProfileAlias(weapon.profile, weapon.legacyProfile, weapon.name, weapon.selectedModel, weapon.customModel);
    if (canonical) return canonical;
    const blob = weaponText(weapon);
    if (/тяж[её]л\w*\s+пулем[её]т/i.test(blob)) return 'Тяжёлый пулемёт';
    if (/автоматическ\w*\s+карабин/i.test(blob)) return 'Автоматический карабин';
    if (/штурмов\w*\s+карабин/i.test(blob)) return 'Штурмовой карабин';
    if (/армейск\w*\s+карабин/i.test(blob)) return 'Армейский карабин';
    return String(weapon.profile || weapon.name || '');
  }
  function weaponSupportsSuppression(weapon) { return weapon?.modificationsActive!==false&&['Армейский карабин','Штурмовой карабин','Автоматический карабин','Тяжёлый пулемёт'].includes(canonicalCombatWeaponProfile(weapon)); }
  function weaponSupportsBarrage(weapon) { return weapon?.modificationsActive!==false&&['Штурмовой карабин','Автоматический карабин','Тяжёлый пулемёт'].includes(canonicalCombatWeaponProfile(weapon)); }
  function weaponSupportsAnaxion(weapon) { return weapon?.modificationsActive!==false&&['Анаксионный пистолет','Анаксионная винтовка','Анаксионный дробовик','Анаксионный излучатель'].includes(canonicalCombatWeaponProfile(weapon)); }
  function weaponSupportsDual(weapon) { return weapon?.modificationsActive!==false && ['Карманный пистолет','Средний пистолет','Тяжёлый пистолет','Револьвер','Тяжёлый револьвер','Анаксионный пистолет'].includes(canonicalCombatWeaponProfile(weapon)); }

  async function applyDirectWeaponOnHitEffects(scene, attacker, target, weapon, body = {}) {
    if (!scene || !target || !weapon || !['character','npc'].includes(target.kind)) return null;
    const profile = canonicalCombatWeaponProfile(weapon);
    if (profile === 'Анаксионный пистолет') {
      const moraleRoll = await resolveScalarRoll(scene,target,{body,label:`${target.name}: потеря морали от анаксионного пистолета`,sides:4,kind:'anaxion-pistol-morale',purpose:'morale-loss'});
      const moraleLoss = -(await adjustTokenMoraleResolved(scene,target,-moraleRoll.total,body));
      return { profile, moraleLoss, moraleRoll, formula:'1d4' };
    }
    if (profile === 'Огнемётный') {
      // The rulebook specifies the delayed burning-zone damage but not its size.
      // VTT operational convention: the impact cell itself is the zone (5-ft
      // diameter => 2.5-ft radius), lasting until the shooter's next turn.
      const point=speciesCombatPoint(target),effect=normalizeEffectZone({id:makeId('flame-zone'),name:`${weapon.name}: зона горения`,type:'fire',x:point.x,y:point.y,radius:2.5,color:'#ff9b43',zoneDamage:1,damageTag:'heavy',remainingRounds:1,durationMode:'owner-turn',createdRound:getCampaign().initiative?.round||0,ownerTokenId:attacker?.id||null,sourceName:weapon.name,notes:'Зона попадания огнемётного профиля: 1 урон в начале хода тем, кто остался в клетке.'},scene.effects.length);
      scene.effects.push(effect);return{profile,burningZone:effect};
    }
    return null;
  }

  function attackFlagsFromWeapon(weapon) {
    const text = `${weapon?.name || ''} ${weapon?.profile || ''} ${weapon?.description || ''}`;
    const fire=/огнем[её]т|flamethrower/i.test(text);
    return {
      explosive: /взрыв|гранатом[её]т|радиус\s*\//i.test(text),
      armorPiercing: /бронебойн/i.test(text),
      anaxion: /анаксион/i.test(text),
      anaxionArmorAllowed: /тяж[её]лая броня снижает|броня защищает от анаксион/i.test(text),
      fire,
      ignoreArmor:fire,
      environmentalHazard:fire?'fire':''
    };
  }

  function woundTypesFromDamage(damage) {
    if (damage <= 0) return [];
    if (damage === 1) return ['light'];
    if (damage === 2) return ['medium'];
    if (damage === 3) return ['medium', 'light'];
    if (damage === 4) return ['serious'];
    return ['critical'];
  }

  function reduceWound(type, steps) {
    const order = ['light', 'medium', 'serious', 'critical'];
    const index = order.indexOf(type) - Math.max(0, Math.round(steps || 0));
    return index < 0 ? null : order[index];
  }

  function equippedArmorForCharacter(st) {
    const key = st?.equipment?.armor;
    if (!key) return null;
    const inventory = Array.isArray(st.inventory) ? st.inventory : [];
    const raw=inventory.find(item => item?.uid === key || item?.id === key || item?.name === key) || { name: String(key), type: '', desc: '' };
    return normalizedArmorItem(raw);
  }

  function armorResolutionForCharacter(st, damage, damageTag, flags) {
    st=ensureSpeciesRuntime(st)||st||{};
    const beforeBz=Math.max(0,Math.round(safeNumber(st?.bz,0))),baseWounds=woundTypesFromDamage(damage),sourceText=String(flags?.sourceText||'');
    const pallidActive=st.species==='pallid'&&st.pallid?.transformed,werewolfActive=st.species==='werewolf'&&st.werewolf?.transformed;
    const armorAllowed=!(pallidActive&&!st.pallid?.formArmorAdapted)&&!(werewolfActive&&!st.werewolf?.formArmorAdapted);
    let armorResult={damage,wounds:baseWounds,used:false,beforeBz,afterBz:beforeBz,steps:0,wear:0,damageReduction:0,reason:armorAllowed?'броня не применена':'обычная броня не приспособлена к активной форме'};
    const armor=(!flags?.ignoreArmor&&armorAllowed)?equippedArmorForCharacter(st):null;
    if(flags?.ignoreArmor)armorResult.reason=flags.environmentalHazard==='gas'?'газ игнорирует обычную броню':flags.environmentalHazard==='fire'?'огонь игнорирует обычную броню':'эффект игнорирует обычную броню';
    if(armor&&beforeBz>0){
      const armorClass=armor.armorClass||'none',profile=armor.profile||'',effectiveTag=flags.explosive?'heavy':damageTag,intrinsicAnaxion=armor.anaxionSteps;
      const anaxionAllowed=Boolean(flags.anaxionArmorAllowed)||intrinsicAnaxion!==null;
      if(flags.anaxion&&!anaxionAllowed){armorResult.reason='анаксионная атака обходит эту броню';}
      else {
        let steps=0;
        if(armorClass==='light')steps=effectiveTag==='light'?1:0;
        else if(armorClass==='medium')steps=['light','medium'].includes(effectiveTag)?1:0;
        else if(armorClass==='heavy')steps=['light','medium'].includes(effectiveTag)?2:effectiveTag==='heavy'?1:0;
        if(flags.anaxion){
          if(intrinsicAnaxion!==null)steps=intrinsicAnaxion;
          else steps=(flags.anaxionArmorAllowed&&armorClass==='heavy')?1:0;
        }
        if(flags.armorPiercing)steps=Math.max(0,steps-1);
        const numericalReduction=flags.explosive&&['Противоосколочный бронекомплект','Анаксионно-изолированная броня'].includes(profile)?1:0;
        const resolvedDamage=Math.max(0,damage-numericalReduction),armorBase=woundTypesFromDamage(resolvedDamage);
        const wounds=armorBase.map(typeName=>reduceWound(typeName,steps)).filter(Boolean),changed=numericalReduction>0||JSON.stringify(armorBase)!==JSON.stringify(wounds);
        const wear=changed?((effectiveTag==='heavy'||flags.explosive||flags.armorPiercing||flags.anaxion)?2:1):0;
        const effects=[];if(numericalReduction)effects.push(`урон -${numericalReduction}`);if(steps)effects.push(`тяжесть каждого ранения -${steps} ступ.`);
        armorResult={damage:resolvedDamage,wounds,used:changed,beforeBz,afterBz:Math.max(0,beforeBz-wear),steps,wear,damageReduction:numericalReduction,profile,armorClass,reason:changed?`${armorDisplayLabel(armor)}: ${effects.join(', ')}, БЗ ${beforeBz}→${Math.max(0,beforeBz-wear)}`:'тип атаки обходит защиту этой брони'};
      }
    }
    const candidates=[armorResult];
    const pallidExcluded=Boolean(flags?.environmentalHazard)||damageTag==='heavy'||flags.explosive||flags.armorPiercing||flags.anaxion||/огонь|пламя|газ|яд|токсин|удуш|паден|истощ/i.test(sourceText);
    if(pallidActive&&!pallidExcluded&&['light','medium'].includes(damageTag)){
      const wounds=baseWounds.map(typeName=>reduceWound(typeName,1)).filter(Boolean);
      candidates.push({damage,wounds,used:JSON.stringify(wounds)!==JSON.stringify(baseWounds),beforeBz,afterBz:beforeBz,steps:1,wear:0,speciesDefense:'pallidFlesh',reason:'Плоть Вечного снизила каждое ранение на одну ступень'});
    }
    if(!flags?.environmentalHazard&&werewolfActive&&!st.werewolf.hideUsed&&(damageTag==='light'||flags.unarmed)){
      const wounds=baseWounds.map((typeName,index)=>index===0?reduceWound(typeName,1):typeName).filter(Boolean);
      candidates.push({damage,wounds,used:JSON.stringify(wounds)!==JSON.stringify(baseWounds),beforeBz,afterBz:beforeBz,steps:1,wear:0,speciesDefense:'werewolfHide',reason:'Звериная шкура снизила одно ранение на одну ступень'});
    }
    candidates.sort((a,b)=>woundSeverityScore(a.wounds)-woundSeverityScore(b.wounds)||(b.used?1:0)-(a.used?1:0));
    const best=candidates[0];if(best.speciesDefense==='werewolfHide'&&best.used)st.werewolf.hideUsed=true;return best;
  }

  function armorResolutionForNpc(npc, damage, damageTag, flags) {
    const armor=normalizedNpcArmor(npc),beforeBz=armor.bzCurrent,armorClass=armor.armorClass||'none',profile=armor.profile||'';
    if(flags?.ignoreArmor)return{damage,wounds:woundTypesFromDamage(damage),used:false,beforeBz,afterBz:beforeBz,steps:0,wear:0,damageReduction:0,reason:flags.environmentalHazard==='gas'?'газ игнорирует обычную броню':flags.environmentalHazard==='fire'?'огонь игнорирует обычную броню':'эффект игнорирует обычную броню'};
    if(beforeBz<=0||armorClass==='none')return{damage,wounds:woundTypesFromDamage(damage),used:false,beforeBz,afterBz:beforeBz,steps:0,wear:0,damageReduction:0,reason:'броня не применена'};
    const effectiveTag=flags.explosive?'heavy':damageTag,intrinsicAnaxion=armor.anaxionSteps,anaxionAllowed=Boolean(flags.anaxionArmorAllowed)||intrinsicAnaxion!==null;
    if(flags.anaxion&&!anaxionAllowed)return{damage,wounds:woundTypesFromDamage(damage),used:false,beforeBz,afterBz:beforeBz,steps:0,wear:0,damageReduction:0,reason:'анаксионная атака обходит эту броню'};
    let steps=armorClass==='light'?(effectiveTag==='light'?1:0):armorClass==='medium'?(['light','medium'].includes(effectiveTag)?1:0):armorClass==='heavy'?(['light','medium'].includes(effectiveTag)?2:effectiveTag==='heavy'?1:0):0;
    if(flags.anaxion){if(intrinsicAnaxion!==null)steps=intrinsicAnaxion;else steps=(flags.anaxionArmorAllowed&&armorClass==='heavy')?1:0;}
    if(flags.armorPiercing)steps=Math.max(0,steps-1);
    const numericalReduction=flags.explosive&&['Противоосколочный бронекомплект','Анаксионно-изолированная броня'].includes(profile)?1:0;
    const resolvedDamage=Math.max(0,damage-numericalReduction),baseWounds=woundTypesFromDamage(resolvedDamage),wounds=baseWounds.map(typeName=>reduceWound(typeName,steps)).filter(Boolean);
    const changed=numericalReduction>0||JSON.stringify(baseWounds)!==JSON.stringify(wounds),wear=changed?((effectiveTag==='heavy'||flags.explosive||flags.armorPiercing||flags.anaxion)?2:1):0,effects=[];
    if(numericalReduction)effects.push(`урон -${numericalReduction}`);if(steps)effects.push(`тяжесть каждого ранения -${steps} ступ.`);
    return{damage:resolvedDamage,wounds,used:changed,beforeBz,afterBz:Math.max(0,beforeBz-wear),steps,wear,damageReduction:numericalReduction,profile,armorClass,reason:changed?`${armorDisplayLabel(armor)}: ${effects.join(', ')}, БЗ ${beforeBz}→${Math.max(0,beforeBz-wear)}`:'тип атаки обходит защиту этой брони'};
  }

  function addWoundWithOverflow(wounds, type, medical = null) {
    if (wounds.critical) { if (medical) medical.dead = true; return 'death'; }
    if (type === 'critical') { wounds.critical = true; return 'critical'; }
    const next = type === 'light' ? 'medium' : type === 'medium' ? 'serious' : 'critical';
    const max = Math.max(0, Math.round(safeNumber(wounds[`${type}Max`], 0)));
    const current = Math.max(0, Math.round(safeNumber(wounds[type], 0)));
    if (current < max) { wounds[type] = current + 1; return type; }
    return addWoundWithOverflow(wounds, next, medical);
  }

  function reduceIncomingWoundOneStep(types){
    const list=[...(types||[])],priority=['serious','medium'];
    for(const type of priority){const index=list.indexOf(type);if(index<0)continue;list[index]=type==='serious'?'medium':'light';return{wounds:list,reducedFrom:type,reducedTo:list[index]};}
    return{wounds:list,reducedFrom:null,reducedTo:null};
  }
  function addCharacterWoundWithBonus(scene,target,wounds,type,medical,body={}){
    if(!target||target.kind!=='character')return addWoundWithOverflow(wounds,type,medical);
    const character=linkedCharacter(target),st=character?.state||{};
    if(wounds.critical)return addWoundWithOverflow(wounds,type,medical);
    if(bonusTraitLevel(character,'Крепкий')>=6&&!bonusAbilityUsed(st,scene,'Крепкий:6','long-rest')){
      const probe=clone(wounds),probeMedical={dead:Boolean(medical?.dead)},result=addWoundWithOverflow(probe,type,probeMedical);
      if(result==='critical'){
        wounds.serious=Math.max(0,Math.round(safeNumber(wounds.serious,0)))+1;
        if(medical){medical.dead=false;medical.stabilized=false;}
        markBonusAbilityUsed(st,scene,'Крепкий:6','long-rest');
        return 'serious';
      }
    }
    return addWoundWithOverflow(wounds,type,medical);
  }
  function preparedSecondWind(character){
    const rt=bonusTraitRuntime(character?.state||{},true);
    return rt.secondWindPrepared||null;
  }
  function consumePreparedSecondWind(character){
    const rt=bonusTraitRuntime(character?.state||{},true),value=rt.secondWindPrepared||null;
    delete rt.secondWindPrepared;return value;
  }

  function meleeSkillNames(weapon) {
    const text = `${weapon?.profile || ''} ${weapon?.name || ''} ${weapon?.description || ''}`;
    if (/Л[её]гкое оружие/i.test(text)) return ['Акробатика'];
    if (/Тяж[её]лое двуручное|Тяж[её]лое оружие|Дробящее оружие/i.test(text)) return ['Физическая сила'];
    if (/Безоружн/i.test(text)) return ['Физическая сила'];
    return ['Акробатика', 'Физическая сила'];
  }

  function meleeBonusForToken(token, weapon) {
    if (token?.kind === 'npc') {
      const npc = linkedNpc(token);
      if (!npc) return { bonus: Math.round(safeNumber(weapon?.hitBonus, 0)), skill: 'Боевой бонус' };
      const names = meleeSkillNames(weapon),armorProfile=normalizedNpcArmor(npc).profile;
      const values = names.map(name => {
        const raw = name === 'Акробатика' ? Math.round(safeNumber(npc.characteristics?.dexterity, 0)) : Math.round(safeNumber(npc.characteristics?.strength, 0));
        const serious=safeNumber(npc?.wounds?.serious,0)>0?armorSeriousPenaltyForProfile(armorProfile):0;
        let value = raw + injurySkillPenalty(npc,name).value + serious + armorSkillModifierForProfile(armorProfile,name);
        // Выбитое плечо даёт −2 к попаданию даже тогда, когда лёгкое оружие использует Акробатику.
        if(name==='Акробатика'&&hasTrauma(npc,'Выбитое плечо'))value-=2;
        return { name, value };
      });
      const best = values.sort((a,b)=>b.value-a.value)[0] || { name:'Боевой бонус', value:Math.round(safeNumber(weapon?.hitBonus,0)) };
      // Готовый боевой бонус NPC остаётся допустимой упрощённой заменой характеристик,
      // но травмы не должны исчезать из-за выбора более высокого из двух способов расчёта.
      let ready = Math.round(safeNumber(weapon?.hitBonus, best.value));
      if(weapon?.melee&&hasTrauma(npc,'Рваная рана'))ready-=2;
      return ready > best.value ? { bonus: ready, skill: 'Боевой бонус NPC' } : { bonus: best.value, skill: best.name };
    }
    const character = linkedCharacter(token);
    if (!character) return { bonus: Math.round(safeNumber(weapon?.hitBonus, 0)), skill: 'Бонус профиля' };
    const choices = meleeSkillNames(weapon).map(name => {
      const profile = characterSkillProfileDetailed(character, name, true);
      let value=Math.round(safeNumber(profile?.bonus, 0));
      if(name==='Акробатика'&&hasTrauma(character.state||{},'Выбитое плечо'))value-=2;
      return { name, value };
    });
    const best = choices.sort((a,b)=>b.value-a.value)[0];
    return best ? { bonus:best.value, skill:best.name } : { bonus:0, skill:'Физическая сила' };
  }

  function moraleLossFromDamage(damage) {
    const count = Math.max(0, Math.round(safeNumber(damage, 0)));
    const rolls = Array.from({ length: count }, () => rollOne(10));
    return { rolls, total: rolls.reduce((sum, value) => sum + value, 0) };
  }

  async function moraleLossFromDamageResolved(scene,token,damage,body={}) {
    const count=Math.max(0,Math.round(safeNumber(damage,0)));if(!count)return{rolls:[],total:0,rollRecord:null};
    const presence=confidentPresenceReduction(scene,token);
    const resolved=await resolveScalarRoll(scene,token,{body,label:`${token.name}: потеря морали от урона`,sides:10,count,kind:'damage-morale',purpose:'morale-loss'});
    return{rolls:resolved.values,total:Math.max(0,resolved.total),rollRecord:resolved.roll,presenceReduction:presence};
  }

  function ensureCharacterMedicalState(st) {
    st.wounds ||= { light:0,lightMax:2,medium:0,mediumMax:1,serious:0,seriousMax:1,critical:false };
    st.medical ||= {};
    st.medical.criticalRounds = Math.max(0, Math.round(safeNumber(st.medical.criticalRounds, 0)));
    st.medical.stabilized = Boolean(st.medical.stabilized);
    st.medical.dead = Boolean(st.medical.dead);
    st.medical.bleeding = Boolean(st.medical.bleeding);
    st.medical.failedStabilizers = Array.isArray(st.medical.failedStabilizers) ? st.medical.failedStabilizers : [];
    st.medical.failedStabilizerIds = Array.isArray(st.medical.failedStabilizerIds) ? st.medical.failedStabilizerIds : [];
    st.morale ||= { current:0, max:0 };
    st.activeEffects ||= [];
  }

  function damageCanCauseBleeding(flags, body) {
    if (body.bleeding === true) return true;
    if (body.bleeding === false) return false;
    const text = String(body.sourceText || '');
    if (flags.anaxion || flags.unarmed || /дробящ|безоруж|оглуш|газ|дым|огн|плам|яд|токс|удуш|паден|истощ|анаксион/i.test(text)) return false;
    return Boolean(body.melee || text.trim());
  }

  async function applyDamageToTarget(scene, target, body, options = {}) {
    const damage = Math.max(0, Math.round(safeNumber(body.damage, 0)));
    const damageTag = ['light','medium','heavy'].includes(body.damageTag) ? body.damageTag : 'medium';
    const flags = { explosive:Boolean(body.explosive), armorPiercing:Boolean(body.armorPiercing), anaxion:Boolean(body.anaxion), anaxionArmorAllowed:Boolean(body.anaxionArmorAllowed), unarmed:Boolean(body.unarmed), fire:Boolean(body.fire), ignoreArmor:Boolean(body.ignoreArmor||body.fire), environmentalHazard:String(body.environmentalHazard||(body.fire?'fire':'')), sourceText:String(body.sourceText||'') };
    const actorName = cleanName(body.playerName, options.actorName || 'Система');
    const actorId = cleanId(body.clientId, null);
    const persistNow = options.persist !== false;
    const recordUndo = options.recordHistory !== false;
    if (!target || !['character','npc'].includes(target.kind)) throw Object.assign(new Error('К этой цели нельзя применить ранения.'), { statusCode:400 });

    if (target.kind === 'character') {
      const character = linkedCharacter(target);
      if (!character) throw Object.assign(new Error('Лист цели не найден.'), { statusCode:404 });
      const before = clone(character), st = character.state || (character.state = {});
      ensureCharacterMedicalState(st);
      if (body.melee && consumeBlock(target)) {
        character.revision=Math.max(0,Number(character.revision||0))+1;character.updatedAt=nowIso();
        if (persistNow) await persistCampaign();
        if (broadcastCharacterUpdated) broadcastCharacterUpdated(character, body.clientId);
        return { ok:true, blocked:true, wounds:[], applied:[], moraleLoss:0, moraleRolls:[], armor:{used:false,beforeBz:safeNumber(st.bz,0),afterBz:safeNumber(st.bz,0),reason:'Блок полностью отменил атаку ближнего боя'}, character };
      }
      const wasCritical=Boolean(st.wounds.critical), wasDead=Boolean(st.medical.dead);
      const armor = armorResolutionForCharacter(st, damage, damageTag, flags);
      if (armor.used) st.bz = armor.afterBz;
      const secondWind=consumePreparedSecondWind(character);
      if(secondWind){const reduced=reduceIncomingWoundOneStep(armor.wounds);armor.wounds=reduced.wounds;armor.secondWind={...secondWind,reducedFrom:reduced.reducedFrom,reducedTo:reduced.reducedTo};}
      const applied = armor.wounds.map(typeName => addCharacterWoundWithBonus(scene,target,st.wounds,typeName,st.medical,body));
      if(!wasCritical&&st.wounds.critical)initializeCriticalCountdown(scene,target);
      let deathResult=null;
      if(!wasDead&&st.medical.dead)deathResult=markTokenDead(scene,target,body,'Новое ранение при Критическом ранении');
      if (body.stun) st._battlemapMeleeDefensePenalty = Math.max(1, Math.round(safeNumber(st._battlemapMeleeDefensePenalty, 0)));
      const shouldBleed = damageCanCauseBleeding(flags, body) && applied.includes('serious') && !st.wounds.critical && !st.medical.dead;
      if (shouldBleed) {
        if (st.medical.bleeding) {
          const repeatedBleedWound=addCharacterWoundWithBonus(scene,target,st.wounds,'light',st.medical,body);
          if(repeatedBleedWound==='critical')initializeCriticalCountdown(scene,target);
          else if(repeatedBleedWound==='death')deathResult=markTokenDead(scene,target,body,'Новое ранение при Критическом ранении');
        }
        st.medical.bleeding = true;
      }
      const morale = await moraleLossFromDamageResolved(scene,target,armor.damage,body),moraleReduction=await applyPendingMoraleReductionResolved(scene,target,morale.total,body);
      morale.total=moraleReduction.total;
      const moraleBefore = Math.max(0, Math.round(safeNumber(st.morale.current, 0)));
      st.morale.current = Math.max(0, moraleBefore - morale.total);
      let beastCheck=null,beastRoll=null;
      if(st.species==='werewolf'&&st.werewolf?.transformed){
        const seriousTrigger=(applied.includes('serious')||applied.includes('critical'))&&!st.werewolf.seriousTriggerUsed;
        const moraleTrigger=moraleBefore>0&&st.morale.current<=0;
        if(seriousTrigger){st.werewolf.seriousTriggerUsed=true;const resolved=await resolveWerewolfBeastCheck(scene,target,'первое тяжёлое или критическое ранение в сцене',body);beastCheck=resolved.check;beastRoll=resolved.roll;}
        else if(moraleTrigger){const resolved=await resolveWerewolfBeastCheck(scene,target,'мораль упала до 0',body);beastCheck=resolved.check;beastRoll=resolved.roll;}
      }
      const nearbyBeastChecks=deathResult?.nearbyBeastChecks||[];
      const groupMoraleLoss=deathResult?.affected||[];
      character.revision=Math.max(0,Number(character.revision||0))+1;character.updatedAt=nowIso();character.updatedBy=actorId;
      if (persistNow) await persistCampaign();
      if (recordUndo && recordHistory && persistHistory) {
        const summary=`${character.name}: урон ${damage}; ${applied.length?applied.join(', '):'ранения отменены'}; мораль -${morale.total}${armor.used?`; БЗ ${armor.beforeBz}→${armor.afterBz}`:''}`;
        const entry=recordHistory({actor:{id:actorId,name:actorName,role:options.role||'player'},action:'battlemap-damage',entityType:'character',entityId:character.id,summary,undoData:{kind:'restore-character',character:before}});
        await persistHistory(); if (broadcastHistory) broadcastHistory(entry);
      }
      if (broadcastCharacterUpdated) broadcastCharacterUpdated(character, body.clientId);
      if (armor.damage > 0) { broadcastHitEffect(scene.id, target.id, armor.damage, body.clientId); broadcastAudioEffect(scene.id,'token.damage',{tokenId:target.id,x:target.x,y:target.y,damage:armor.damage},body.clientId); }
      return { ok:true, wounds:armor.wounds, applied, armor, moraleLoss:morale.total, moraleRolls:morale.rolls, moraleReduction, moraleBefore, moraleAfter:st.morale.current, bleeding:Boolean(st.medical.bleeding), beastCheck, beastRoll, nearbyBeastChecks, groupMoraleLoss, critical:criticalState(target), character };
    }

    const npc = linkedNpc(target);
    if (!npc) throw Object.assign(new Error('NPC цели не найден.'), { statusCode:404 });
    npc.wounds ||= { light:0,lightMax:1,medium:0,mediumMax:0,serious:0,seriousMax:0,critical:false };
    npc.morale ||= { current:0, max:0 };
    if (body.melee && consumeBlock(target)) {
      if (persistNow) await persistCampaign();
      broadcast('battlemap-replaced',body.clientId,{reason:'npc-blocked',sceneId:scene.id,tokenId:target.id});
      return {ok:true,blocked:true,wounds:[],applied:[],moraleLoss:0,moraleRolls:[],armor:{used:false,beforeBz:safeNumber(npc.armor?.bzCurrent,0),afterBz:safeNumber(npc.armor?.bzCurrent,0),reason:'Блок полностью отменил атаку ближнего боя'},npc};
    }
    const wasCritical=Boolean(npc.wounds.critical),wasDead=Boolean(npc.dead);
    const armor=armorResolutionForNpc(npc,damage,damageTag,flags);if(armor.used)npc.armor.bzCurrent=armor.afterBz;
    const applied=armor.wounds.map(typeName=>addWoundWithOverflow(npc.wounds,typeName,npc));
    if(!wasCritical&&npc.wounds.critical)initializeCriticalCountdown(scene,target);
    let deathResult=null;if(!wasDead&&npc.dead)deathResult=markTokenDead(scene,target,body,'Новое ранение при Критическом ранении');
    if(body.stun)npc._battlemapMeleeDefensePenalty=Math.max(1,Math.round(safeNumber(npc._battlemapMeleeDefensePenalty,0)));
    const shouldBleed=damageCanCauseBleeding(flags,body)&&applied.includes('serious')&&!npc.wounds.critical&&!npc.dead;
    if(shouldBleed){if(npc.bleeding){const repeatedBleedWound=addWoundWithOverflow(npc.wounds,'light',npc);if(repeatedBleedWound==='critical')initializeCriticalCountdown(scene,target);else if(repeatedBleedWound==='death')markTokenDead(scene,target,body,'Новое ранение при Критическом ранении');}npc.bleeding=true;}
    const morale=await moraleLossFromDamageResolved(scene,target,armor.damage,body),moraleReduction=await applyPendingMoraleReductionResolved(scene,target,morale.total,body);morale.total=moraleReduction.total;const moraleBefore=Math.max(0,Math.round(safeNumber(npc.morale.current,0)));npc.morale.current=Math.max(0,moraleBefore-morale.total);
    npc.updatedAt=nowIso();
    const nearbyBeastChecks=deathResult?.nearbyBeastChecks||[],groupMoraleLoss=deathResult?.affected||[];
    if(persistNow)await persistCampaign();broadcast('battlemap-replaced',body.clientId,{reason:'npc-damaged',sceneId:scene.id,tokenId:target.id});if(armor.damage>0){broadcastHitEffect(scene.id,target.id,armor.damage,body.clientId);broadcastAudioEffect(scene.id,'token.damage',{tokenId:target.id,x:target.x,y:target.y,damage:armor.damage},body.clientId);}
    return {ok:true,wounds:armor.wounds,applied,armor,moraleLoss:morale.total,moraleRolls:morale.rolls,moraleReduction,moraleBefore,moraleAfter:npc.morale.current,bleeding:Boolean(npc.bleeding),nearbyBeastChecks,groupMoraleLoss,critical:criticalState(target),npc};
  }

  function triggerNearbyWerewolfDeath(scene, deceasedToken, body = {}) {
    if(!scene||!deceasedToken)return [];
    const results=[];
    for(const token of scene.tokens||[]){
      if(!token||token.id===deceasedToken.id||token.kind!=='character'||distanceFeet(scene,token,deceasedToken)>10.01)continue;
      const st=speciesStateForToken(token);if(st?.species!=='werewolf'||!st.werewolf?.transformed)continue;
      const reason=`в пределах 10 футов погибло живое существо (${deceasedToken.name})`,check=runWerewolfBeastCheck(token,reason,{applyOutcome:false});if(!check)continue;
      const roll=storeSpeciesCheckRoll(scene,token,check,body,`${token.name}: смерть рядом — Проверка Зверя`,{reactionSafe:true});
      // Смерть уже является свершившимся событием, но состояние Зверя не
      // фиксируем до закрытия реакций на саму проверку. Запускаем ожидание
      // независимо от синхронной цепочки смерти, чтобы не откатывать её.
      void (async()=>{try{let finalRoll=roll;if(finalRoll){finalRoll=await awaitCheckRollResolution(scene,finalRoll);syncCheckFromReactionRoll(check,finalRoll);}applyWerewolfBeastCheckOutcome(token,check);markCharacterChanged(token,body.clientId);scene.updatedAt=nowIso();await persistCampaign();await persist();broadcast('battlemap-replaced',body.clientId,{reason:'werewolf-nearby-death-check-finalized',sceneId:scene.id,tokenId:token.id});}catch(error){console.error('Nearby werewolf Beast check resolution failed:',error);}})();
      results.push({tokenId:token.id,tokenName:token.name,check,roll,pending:true});
    }
    return results;
  }

  function broadcastHitEffect(sceneId, tokenId, damage = 1, sourceClientId = null) {
    for (const client of getSseClients().values()) {
      try { sseWrite(client.response, 'battlemap-hit', { sceneId, tokenId, damage:Math.max(1,Math.round(safeNumber(damage,1))), sourceClientId, at:nowIso() }); } catch {}
    }
  }

  function vehicleArmorReduction(vehicle, damageTag) {
    const armor=vehicle?.armor||'none';
    if(armor==='light')return damageTag==='light'?1:0;
    if(armor==='medium')return damageTag==='light'||damageTag==='medium'?1:0;
    if(armor==='heavy')return damageTag==='heavy'?1:(damageTag==='light'||damageTag==='medium'?2:0);
    return 0;
  }
  function vehicleStatus(vehicle){const current=Math.max(0,safeNumber(vehicle?.hullCurrent,0)),max=Math.max(1,safeNumber(vehicle?.hullMax,1));if(current<=0)return'Выведен из строя';if(current===1)return'Критическое состояние';if(current<=max/2)return'Повреждён';return'Целый';}
  function effectiveVehicleManeuver(vehicle){const base=safeNumber(vehicle?.maneuver,0),current=Math.max(0,safeNumber(vehicle?.hullCurrent,0)),max=Math.max(1,safeNumber(vehicle?.hullMax,1));return base-(current>0&&current<=max/2?1:0);}
  async function applyDamageToVehicle(scene,target,body,{persistNow=true}={}){
    if(!target||target.kind!=='vehicle'||!target.vehicle)throw Object.assign(new Error('Транспорт не найден.'),{statusCode:404});
    const vehicle=target.vehicle,raw=Math.max(0,Math.round(safeNumber(body.damage,0))),damageTag=['light','medium','heavy'].includes(body.damageTag)?body.damageTag:'medium';
    const possible=vehicleArmorReduction(vehicle,damageTag),reduction=vehicle.bzCurrent>0?Math.min(raw,possible):0,beforeBz=vehicle.bzCurrent;
    if(reduction>0)vehicle.bzCurrent=Math.max(0,vehicle.bzCurrent-1);
    const finalDamage=Math.max(0,raw-reduction),beforeHull=vehicle.hullCurrent;vehicle.hullCurrent=Math.max(0,vehicle.hullCurrent-finalDamage);
    target.defeated=vehicle.hullCurrent<=0;target.updatedAt=nowIso();scene.updatedAt=nowIso();
    if(persistNow)await persist();if(finalDamage>0)broadcastHitEffect(scene.id,target.id,finalDamage,body.clientId);
    return{ok:true,vehicle:clone(vehicle),damage:finalDamage,rawDamage:raw,reduction,beforeBz,afterBz:vehicle.bzCurrent,beforeHull,afterHull:vehicle.hullCurrent,status:vehicleStatus(vehicle),effectiveManeuver:effectiveVehicleManeuver(vehicle)};
  }

  function inventoryForToken(token) {
    const character=linkedCharacter(token), npc=linkedNpc(token), st=character?.state||null;
    if (character) return { character, npc:null, state:st, items:Array.isArray(st.inventory)?st.inventory:[], owner:character, ownerType:'character' };
    if (npc) { npc.inventory ||= []; return { character:null, npc, state:npc, items:npc.inventory, owner:npc, ownerType:'npc' }; }
    return { character:null, npc:null, state:null, items:[], owner:null, ownerType:null };
  }
  function inventoryItemById(token, itemId) {
    const holder=inventoryForToken(token),key=String(itemId||'');
    const item=holder.items.find(candidate=>[candidate?.uid,candidate?.id,candidate?.name].filter(Boolean).map(String).includes(key));
    if(!item)return { ...holder, item:null, index:-1 };
    const catalog=weaponCatalog.get(String(item.name||''))||{};
    return { ...holder, item:{...catalog,...item,desc:item.desc||item.description||catalog.desc||''}, raw:item, index:holder.items.indexOf(item) };
  }
  function itemQuantity(item){return Math.max(0,Math.round(safeNumber(item?.qty,item?.quantity??1)));}
  function consumeInventoryItem(holder, uses=1, usesMax=null) {
    const raw=holder.raw;if(!raw)return;
    const maximum=Math.max(0,Math.round(safeNumber(usesMax,raw.usesMax||0)));
    if(Number.isFinite(Number(raw.usesRemaining))){
      raw.usesRemaining=Math.max(0,Math.round(Number(raw.usesRemaining))-uses);if(raw.usesRemaining>0)return;
      const qty=itemQuantity(raw);raw.qty=Math.max(0,qty-1);if(raw.qty<=0){holder.items.splice(holder.index,1);return;}if(maximum>0)raw.usesRemaining=maximum;return;
    }
    const qty=itemQuantity(raw);raw.qty=Math.max(0,qty-1);if(raw.qty<=0)holder.items.splice(holder.index,1);
  }
  function specialRangedAmmoName(kind){return kind==='bow'?'Стрелы':kind==='crossbow'?'Болты':null;}
  function specialRangedAmmoHolders(token,weapon){
    const kind=weaponSpecialRangedKind(weapon?.type,weapon?.profile,weapon?.name),ammoName=specialRangedAmmoName(kind);if(!ammoName)return[];
    const base=inventoryForToken(token);return base.items.map((raw,index)=>({ ...base,raw,index,item:raw })).filter(holder=>String(holder.raw?.name||'').trim().toLocaleLowerCase('ru-RU')===ammoName.toLocaleLowerCase('ru-RU'));
  }
  function specialRangedAmmoCount(token,weapon){return specialRangedAmmoHolders(token,weapon).reduce((sum,holder)=>sum+itemQuantity(holder.raw),0);}
  function assertSpecialRangedAmmo(token,weapon){
    const kind=weaponSpecialRangedKind(weapon?.type,weapon?.profile,weapon?.name),ammoName=specialRangedAmmoName(kind);if(!ammoName)return;
    if(specialRangedAmmoCount(token,weapon)<=0)throw Object.assign(new Error(`Для выстрела из «${weapon.name}» нужны «${ammoName}». Боеприпасов в инвентаре нет.`),{statusCode:409});
  }
  function consumeSpecialRangedAmmo(token,weapon){
    const kind=weaponSpecialRangedKind(weapon?.type,weapon?.profile,weapon?.name),ammoName=specialRangedAmmoName(kind);if(!ammoName)return null;
    const holder=specialRangedAmmoHolders(token,weapon).find(item=>itemQuantity(item.raw)>0);if(!holder)throw Object.assign(new Error(`Для выстрела из «${weapon.name}» нужны «${ammoName}».`),{statusCode:409});
    consumeInventoryItem(holder,1);return{ammoName,remaining:specialRangedAmmoCount(token,weapon)};
  }
  function removeToxicEffectsFromState(st){const before=Array.isArray(st.activeEffects)?st.activeEffects.length:0;st.activeEffects=(st.activeEffects||[]).filter(effect=>!/яд|токсин|токсич|газ/i.test(`${effect?.title||effect?.name||''} ${effect?.desc||effect?.description||''}`));return before-st.activeEffects.length;}
  function healWound(st,type,count=1){ensureCharacterMedicalState(st);let healed=0;while(count-->0&&safeNumber(st.wounds[type],0)>0){st.wounds[type]-=1;healed+=1;}return healed;}
  function addTemporaryEffect(st,title,desc,duration){st.activeEffects ||= [];st.activeEffects.unshift({id:makeId('effect'),title,desc,duration,source:'battlemap-item',createdAt:nowIso()});}
  function tokenMedicalHost(token) {
    const character=linkedCharacter(token), npc=linkedNpc(token);
    if(character){const st=character.state||(character.state={});ensureCharacterMedicalState(st);return {type:'character',entity:character,state:st,wounds:st.wounds,get bleeding(){return Boolean(st.medical?.bleeding)},set bleeding(v){st.medical ||= {};st.medical.bleeding=Boolean(v)},effects:st.activeEffects||(st.activeEffects=[]),injuries:st.injuries||(st.injuries=[])};}
    if(npc){npc.wounds ||= {light:0,medium:0,serious:0,critical:false};npc.effects ||= [];npc.injuries ||= [];return {type:'npc',entity:npc,state:npc,wounds:npc.wounds,get bleeding(){return Boolean(npc.bleeding)},set bleeding(v){npc.bleeding=Boolean(v)},effects:npc.effects,injuries:npc.injuries};}
    return null;
  }
  function removeToxicEffectsFromHost(host){if(!host)return 0;const before=host.effects.length;host.effects=host.effects.filter(effect=>!/яд|токсин|токсич|газ/i.test(`${effect?.title||effect?.name||''} ${effect?.desc||effect?.description||''}`));if(host.type==='character')host.state.activeEffects=host.effects;else host.entity.effects=host.effects;return before-host.effects.length;}
  function addTemporaryEffectToHost(host,title,desc,duration){if(!host)return;const effect=host.type==='character'?{id:makeId('effect'),title,desc,duration,source:'battlemap-item',createdAt:nowIso()}:{id:makeId('npceffect'),name:title,description:desc,duration};host.effects.unshift(effect);}
  function restoreEntity(target,snapshot){for(const key of Object.keys(target))delete target[key];Object.assign(target,clone(snapshot));}

  const GRENADE_PROFILES = {
    'Sturmblitz':{type:'explosive',damage:4,radius:20,damageTag:'heavy',bleeding:true,name:'Sturmblitz'},
    'Panzersturm':{type:'explosive',damage:4,radius:15,damageTag:'heavy',armorPiercing:true,bleeding:true,name:'Panzersturm'},
    'Vaporize':{type:'smoke',damage:0,radius:20,rounds:3,mzBonus:2,visionLimit:20,name:'Vaporize'},
    'Fogmire-5':{type:'gas',damage:0,zoneDamage:1,radius:15,rounds:2,visionLimit:20,damageTag:'light',gasHazard:true,name:'Fogmire-5'},
    'Vektron-12':{type:'toxin',damage:0,zoneDamage:3,radius:15,rounds:2,delayRounds:1,visionLimit:20,damageTag:'light',gasHazard:true,name:'Vektron-12'},
    'ГПД':{type:'panic',damage:2,radius:10,rounds:1,visionLimit:20,gasHazard:true,attackHindrance:true,skipTurn:true,hostileOnly:true,name:'ГПД'},
    'Экспансор-6':{type:'anaxion',damage:4,radius:30,damageTag:'heavy',anaxion:true,name:'Экспансор-6'},
    'Энтропия-7':{type:'anaxion',damage:4,radius:20,damageTag:'heavy',anaxion:true,rounds:1,notes:'Спонтанную атаку ближайшей цели разрешает мастер.',name:'Энтропия-7'},
    'Дымовая шашка':{type:'smoke',damage:0,radius:10,rounds:1,mzBonus:1,visionLimit:20,name:'Дымовая шашка'}
  };
  function grenadeProfile(item){const exact=GRENADE_PROFILES[item?.name];if(exact)return {...exact};const text=`${item?.name||''} ${item?.desc||''}`;const damage=Math.round(safeNumber(text.match(/урон\s*(\d+)/i)?.[1],0)),radius=Math.round(safeNumber(text.match(/радиус(?:ом)?\s*(\d+)/i)?.[1],10));if(/дым/i.test(text))return{type:'smoke',damage:0,radius,rounds:1,mzBonus:/\+2\s*МЗ/i.test(text)?2:1,visionLimit:20,name:item.name};if(/газ|токс/i.test(text))return{type:'gas',damage:0,zoneDamage:damage||1,radius,rounds:2,visionLimit:20,gasHazard:true,name:item.name};return{type:'explosive',damage:damage||4,radius,damageTag:'heavy',name:item.name};}
  function grenadeThrowRange(token){
    const rawBonus=token?.kind==='npc'?safeNumber(linkedNpc(token)?.characteristics?.strength,0):safeNumber(characterSkillProfileDetailed(linkedCharacter(token),'Физическая сила',false)?.bonus,0);
    return 30+Math.max(0,Math.round(rawBonus))*10;
  }

  function bestGrenadeThrowSkill(token){
    const options=['Меткость','Физическая сила'].map(name=>({name,profile:opposedSkillProfile(token,name,true)})).filter(item=>item.profile);
    options.sort((a,b)=>(safeNumber(b.profile.sides,6)+2*safeNumber(b.profile.bonus,0))-(safeNumber(a.profile.sides,6)+2*safeNumber(a.profile.bonus,0)));
    return options[0]?.name||'Меткость';
  }
  function grenadeThrowDifficulty(scene,token,point,maxRange=grenadeThrowRange(token),forced=false){
    const origin=speciesCombatPoint(token),distance=distanceFeet(scene,token,point),reasons=[];
    if(distance>maxRange/2+.01)reasons.push('дальше половины максимальной дальности');
    const cover=automaticCoverInfo(scene,origin,point,{includeTargetInsideCover:true});if(cover.mz>0)reasons.push(`точка за укрытием${cover.source?.name?` «${cover.source.name}»`:''}`);
    if(automaticZoneMz(scene,origin,point)>0)reasons.push('дым или иная мешающая зона');
    if(token?.vision?.enabled&&!viewerCanSeePoint(scene,token,point))reasons.push('точка плохо видна (темнота/ограничение зрения)');
    if(forced)reasons.push('сложные условия');
    return{difficult:reasons.length>0,reasons,distance,maxRange};
  }

  function meleeWeaponForToken(token, weaponId = null, {forCounter=false, forFreeAttack=false, includeDormant=false} = {}) {
    let available = weaponsForToken(token);
    if (includeDormant) {
      const known = new Set(available.map(item => item.id));
      available = [...available, ...speciesNaturalWeapons(token, { includeDormant:true }).filter(item => !known.has(item.id))];
    }
    let melee = available.filter(item => item.melee || item.type === 'Оружие ближнего боя' || item.id === 'unarmed');
    if (!melee.length) return unarmedWeaponForToken(token);
    if (forCounter) melee=melee.filter(item=>item.counterAllowed!==false);
    if (forFreeAttack) melee=melee.filter(item=>item.freeAttackAllowed!==false);
    if (!melee.length) return unarmedWeaponForToken(token);
    if (weaponId) return melee.find(item => item.id === weaponId || item.slot === weaponId || item.name === weaponId) || melee[0];
    return melee.sort((a,b) => (dieSides(b.hitDieNormal,4) + safeNumber(b.hitBonus,0)) - (dieSides(a.hitDieNormal,4) + safeNumber(a.hitBonus,0)))[0];
  }
  function meleeReachFeet(_scene, _a, _b) {
    // Body-to-body contact is one neighbouring FATUM cell. Larger footprints
    // are already accounted for by contactDistanceFeet().
    return 5;
  }
  function meleeDefenseBonus(weapon, attacker) {
    let bonus = Math.round(safeNumber(weapon.hitBonus, 0));
    const text = `${weapon.profile || ''} ${weapon.description || ''}`;
    if (/Л[её]гкое оружие|Быстрое/i.test(text)) bonus += 1;
    if (/Древковое оружие|Удержание дистанции/i.test(text) && tokenActions(attacker)?.charge) bonus += 1;
    return bonus;
  }
  function makeMeleeRoll(body, scene, attacker, target, options = {}) {
    const critical=assertTokenCanAct(attacker,{attack:true});
    const weapon = meleeWeaponForToken(attacker, body.weaponId, { includeDormant:body.specialMode === 'ambush', forFreeAttack:Boolean(options.freeAttack) }), defenderWeapon = meleeWeaponForToken(target, body.defenderWeaponId, {forCounter:true});
    const attackerPoint=options.attackerPoint||speciesCombatPoint(attacker),targetPoint=options.targetPoint||(body.targetPart==='head'?speciesCombatPoint(target):target);
    const bodyCentres=Math.hypot(attackerPoint.x-attacker.x,attackerPoint.y-attacker.y)<.01&&Math.hypot(targetPoint.x-target.x,targetPoint.y-target.y)<.01;
    const distance=bodyCentres?contactDistanceFeet(scene,attacker,target):distanceFeet(scene,attackerPoint,targetPoint),reach=Math.max(meleeReachFeet(scene,attacker,target),safeNumber(weapon.range,5),options.freeAttack?10:0);
    if (distance > reach + 0.01) throw Object.assign(new Error(`Цель слишком далеко для ближнего боя: ${distance.toFixed(1)} фт при дистанции ${reach} фт.`), { statusCode: 409 });
    if(contactBlockedByWall(scene,attackerPoint,targetPoint))throw Object.assign(new Error('Ближний бой невозможен: между персонажами находится стена или закрытая дверь.'),{statusCode:409});
    const weaponText = `${weapon.profile || ''} ${weapon.description || ''}`;
    const specialMode = body.specialMode === 'power' && /Мощный удар/i.test(weaponText) ? 'power' : body.specialMode === 'stun' && /Оглуш/i.test(weaponText) ? 'stun' : body.specialMode === 'shock' && /Шок/i.test(weaponText) ? 'shock' : ['ambush','takedown'].includes(body.specialMode) ? body.specialMode : null;
    const attackerSt=speciesStateForToken(attacker);
    if(specialMode==='ambush'&&!(attackerSt?.species==='rokurokubi'&&!attackerSt.rokurokubi.neckExtended&&!attackerSt.rokurokubi.ambushUsed&&['rokurokubi-lunge','rokurokubi-wrap'].includes(weapon.id)))throw Object.assign(new Error('Молниеносная засада сейчас недоступна.'),{statusCode:409});
    if(weapon.id==='rokurokubi-lunge'&&attackerSt?.rokurokubi?.wrappedTargetTokenId)throw Object.assign(new Error('Нельзя использовать Молниеносный выпад, пока цель Обвита.'),{statusCode:409});
    const narrativeAttack=options.narrativeAttack||consumeNarrative(attacker,'attack'),narrativeDefense=options.narrativeDefense||consumeNarrative(target,'defense');
    const featureAttack=consumeFeatureEffectForTarget(attacker,'nextAttack',target.id),featureDefense=consumeFeatureEffect(target,'nextDefense');
    const featureAttackRoll=featureEffectRoll(featureAttack),experiencedLook=activeExperiencedLook(attacker,scene,target),experiencedLookHitBonus=experiencedLook?3:0,mainTraitMark=activeMainTraitMark(attacker,scene,target),markedFirstAttackAdvantage=consumeMarkedFirstAttackAdvantage(scene,attacker,target);
    const attackerHost=actionHost(attacker)||{},defenderMedical=actionHost(target)||{},attackerTough=attacker.kind==='character'?bonusTraitLevel(attacker,'Крепкий'):0,defenderTough=target.kind==='character'?bonusTraitLevel(target,'Крепкий'):0;
    const attackerSides = dieSides(weapon.hitDieNormal, 4),attackerRt=attackerHost?._battlemapAberration||{},defenderRt=defenderMedical?._battlemapAberration||{};let hindrance=Boolean(tokenActions(attacker)?.gasAttackHindrance||(safeNumber(attackerHost?.wounds?.medium,0)>0&&attackerTough<2)),advantage=specialMode==='ambush'||markedFirstAttackAdvantage;if(attackerRt.cancelNextHindrance&&hindrance){hindrance=false;delete attackerRt.cancelNextHindrance;}
    const attackerRollMode=mergeRollCondition(advantage||featureAttack?.condition==='advantage',hindrance||featureAttack?.condition==='hindrance',narrativeAttack.condition);
    const attackerRollValues = attackerRollMode===0 ? [rollOne(attackerSides)] : [rollOne(attackerSides), rollOne(attackerSides)];let attackerForcedReroll=false;
    let attackerRoll = attackerRollMode<0 ? Math.min(...attackerRollValues) : attackerRollMode>0 ? Math.max(...attackerRollValues) : attackerRollValues[0];if(attackerRt.forceNextReroll){attackerRollValues.push(rollOne(attackerSides));attackerRoll=attackerRollValues[attackerRollValues.length-1];attackerForcedReroll=true;delete attackerRt.forceNextReroll;}
    const defenderSides=dieSides(defenderWeapon.hitDieNormal,4),baseDefenderHindrance=safeNumber(defenderMedical?.wounds?.medium,0)>0&&defenderTough<2,defenderRollMode=mergeRollCondition(false,baseDefenderHindrance,narrativeDefense.condition),defenderHindrance=defenderRollMode<0,defenderRollValues=defenderRollMode===0?[rollOne(defenderSides)]:[rollOne(defenderSides),rollOne(defenderSides)];let defenderForcedReroll=false;if(defenderRt.forceNextReroll){defenderRollValues.push(rollOne(defenderSides));defenderForcedReroll=true;delete defenderRt.forceNextReroll;}const defenderRoll=defenderForcedReroll?defenderRollValues[defenderRollValues.length-1]:(defenderRollMode<0?Math.min(...defenderRollValues):defenderRollMode>0?Math.max(...defenderRollValues):defenderRollValues[0]);
    const attackerProfile = meleeBonusForToken(attacker, weapon);
    const defenderProfile = meleeBonusForToken(target, defenderWeapon);
    const attackerMediumPenalty=safeNumber(attackerHost?.wounds?.medium,0)>0&&attackerTough>=2?-1:0;
    const attackerBaseBonus = attackerProfile.bonus + narrativeAttack.bonus + critical.attackPenalty + Math.round(safeNumber(featureAttack?.flat,0)) + attackerMediumPenalty + experiencedLookHitBonus;
    const attackerBonus = attackerBaseBonus + featureAttackRoll;
    const defenderHost = actionHost(target);
    const pendingDefensePenalty = Math.max(0, Math.round(safeNumber(defenderHost?._battlemapMeleeDefensePenalty, 0)));
    const defenderMediumPenalty=safeNumber(defenderMedical?.wounds?.medium,0)>0&&defenderTough>=2?-1:0;
    let defenderBonus = defenderProfile.bonus + narrativeDefense.bonus + Math.round(safeNumber(featureDefense?.flat,0)) - pendingDefensePenalty - (speciesConditions(target)?.wrappedByTokenId ? 1 : 0) - (speciesConditions(target)?.prone ? 1 : 0) + defenderMediumPenalty;
    const defenderText = `${defenderWeapon.profile || ''} ${defenderWeapon.description || ''}`;
    if (/Л[её]гкое оружие|Быстрое/i.test(defenderText)) defenderBonus += 1;
    if (/Древковое оружие|Удержание дистанции/i.test(defenderText) && tokenActions(attacker)?.charge) defenderBonus += 1;
    if (pendingDefensePenalty && defenderHost) defenderHost._battlemapMeleeDefensePenalty = Math.max(0, pendingDefensePenalty - 1);
    const defenderCritical=criticalState(target),defenderDisabled=defenderCritical.dead||(defenderCritical.critical&&!defenderCritical.canAttack);
    const resolvedDefenderRoll=defenderDisabled?0:defenderRoll,resolvedDefenderBonus=defenderDisabled?0:defenderBonus;
    const attackerTotal = attackerRoll + attackerBonus, defenderTotal = resolvedDefenderRoll + resolvedDefenderBonus;
    const hit = attackerTotal > defenderTotal, tie = attackerTotal === defenderTotal, counterAvailable = !defenderDisabled&&!options.suppressCounter && defenderTotal > attackerTotal;
    const attack = {
      id: makeId('melee'), at: nowIso(), actorId: cleanId(body.clientId,null), actorName: cleanName(body.playerName,'Участник'), kind:options.kind||'melee',
      visibility: body.visibility === 'master' ? 'master' : 'public', sceneId: scene.id,
      attackerTokenId: attacker.id, attackerName: attacker.name, targetTokenId: target.id, targetName: target.name,
      weapon, defenderWeapon, attackerSkill:attackerProfile.skill, defenderSkill:defenderProfile.skill, distance: Math.round(distance*10)/10, attackerRoll, defenderRoll:resolvedDefenderRoll, attackerRollValues:[...attackerRollValues], defenderRollValues:[...defenderRollValues], attackerRollMode, defenderRollMode, attackerSides, defenderSides, defenderDisabled, suppressCounter:Boolean(options.suppressCounter), specialMode, attackerBaseBonus, attackerBonus, defenderBonus:resolvedDefenderBonus, attackerTotal, defenderTotal,
      hit, tie, counterAvailable, narrative:{attack:narrativeAttack,defense:narrativeDefense}, featureEffects:{attack:featureAttack,defense:featureDefense,attackRoll:featureAttackRoll}, mainTraitEffects:{mark:mainTraitMark?{targetTokenId:target.id,firstAttackAdvantage:markedFirstAttackAdvantage}:null,experiencedLook:experiencedLook?{targetTokenId:target.id,hitBonus:3}:null}, counterCost: counterAvailable ? (/Тяж[её]лое двуручное|Громоздк/i.test(`${defenderWeapon.profile||''} ${defenderWeapon.description||''}`) ? 2 : 1) : 0, counterExpiresAt: counterAvailable ? Date.now()+120000 : null, damage: specialMode === 'shock' ? 0 : Math.max(0, safeNumber(weapon.damage,0) + (specialMode === 'power' ? 1 : 0) + (tokenActions(attacker)?.aberrantStrength?.mode==='damage'?safeNumber(tokenActions(attacker).aberrantStrength.bonus,0):0) + narrativeAttack.damageBonus), damageTag: weapon.damageTag, flags: { ...attackFlagsFromWeapon(weapon), melee:true, unarmed:weapon.id==='unarmed', powerStrike:specialMode==='power', stun:specialMode==='stun'&&hit, shock:specialMode==='shock'&&hit, speciesAmbush:specialMode==='ambush', knockdown:specialMode==='takedown'&&hit, wrapTarget:weapon.id==='rokurokubi-wrap'&&hit, lycanthropyRisk:weapon.id==='werewolf-bite'&&hit, aberrantStrength:tokenActions(attacker)?.aberrantStrength?clone(tokenActions(attacker).aberrantStrength):null },
      odCost: Math.max(0, safeNumber(weapon.odCost,2) + (specialMode === 'power' || (specialMode === 'stun' && hit) ? 1 : 0)), requiredOdCost: Math.max(0, safeNumber(weapon.odCost,2) + (specialMode==='takedown' ? 1 : (specialMode === 'power' || (specialMode === 'stun' && hit) ? 1 : 0))), postHitOdCost: specialMode==='takedown' ? 1 : 0, obCost: 0, label: options.label||`${attacker.name}: ${weapon.name}${specialMode==='power'?' (Мощный удар)':specialMode==='stun'?' (Оглушение)':specialMode==='ambush'?' (Молниеносная засада)':specialMode==='takedown'?' (сбивание)':specialMode==='shock'?' (Шок)':''} → ${target.name}`,
      formula: `${attackFormulaText(weapon.hitDieNormal,attackerRollMode,featureAttack?.extraDie,attackerBaseBonus,'',attackerForcedReroll)}`.replace(/\s+vs\s*$/,'')+` vs ${rollSequenceFormula(defenderWeapon.hitDieNormal,defenderRollMode,defenderForcedReroll)}${signedFormulaBonus(resolvedDefenderBonus)?` ${signedFormulaBonus(resolvedDefenderBonus)}`:''}`,
      rolls:[...attackerRollValues,...(featureAttackRoll?[featureAttackRoll]:[]),...defenderRollValues], modifier:attackerBonus, forcedReroll:attackerRollValues.length>(hindrance||advantage?2:1)||defenderForcedReroll, attackerHindrance:hindrance, defenderHindrance
    };
    return attack;
  }
  function makeMeleeCounter(body, scene, pending, defender, attacker) {
    const weapon = meleeWeaponForToken(defender, body.weaponId, {forCounter:true});
    return {
      id:makeId('counter'),at:nowIso(),actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),kind:'melee-counter',visibility:'public',sceneId:scene.id,
      attackerTokenId:defender.id,attackerName:defender.name,targetTokenId:attacker.id,targetName:attacker.name,weapon,defenderWeapon:null,distance:Math.round(distanceFeet(scene,defender,attacker)*10)/10,
      attackerRoll:0,defenderRoll:0,attackerBonus:0,defenderBonus:0,attackerTotal:0,defenderTotal:0,hit:true,tie:false,counterAvailable:false,
      damage:weapon.damage,damageTag:weapon.damageTag,flags:{...attackFlagsFromWeapon(weapon),melee:true,unarmed:weapon.id==='unarmed'},odCost:0,obCost:0,
      label:`${defender.name}: Встречный удар → ${attacker.name}`,formula:'Встречный удар без дополнительного броска',rolls:[],modifier:0,parentAttackId:pending.attack.id
    };
  }

  function makeAttackRoll(body, scene, attacker, target, options = {}) {
    const critical=assertTokenCanAct(attacker,{attack:true});
    const riddenForSeat=attacker.boardedVehicleId?findToken(scene,attacker.boardedVehicleId):null;
    const seatRole=riddenForSeat?.kind==='vehicle'?vehicleSeatRole(riddenForSeat,attacker.id):null;
    if(!options.vehicleMounted&&seatRole==='driver')throw Object.assign(new Error('Водитель занят управлением транспортом и не может стрелять.'),{statusCode:409});
    if(!options.vehicleMounted&&seatRole==='gunner')throw Object.assign(new Error('Стрелок использует установленное оружие транспорта. Личное оружие с этого места недоступно.'),{statusCode:409});
    const weapons = options.weaponOverride ? [options.weaponOverride] : weaponsForToken(attacker);
    const requested = options.weaponOverride || weapons.find(item => item.id === body.weaponId || item.slot === body.weaponId || item.name === body.weaponId);
    const weapon = requested || weapons.find(weaponIsRanged);
    if (!weapon) throw Object.assign(new Error('У атакующего нет доступного дальнобойного оружия. Откройте и сохраните лист, чтобы обновить боевой профиль.'), { statusCode: 400 });
    if (!weaponIsRanged(weapon)) throw Object.assign(new Error('Для этого профиля используйте действие ближнего боя.'), { statusCode:409 });
    if (weapon.unavailable) throw Object.assign(new Error(weapon.unavailableReason||'Оружие недоступно из-за травмы.'), { statusCode:409 });
    if(hasLostLimb(actionHost(attacker)||{},'leg')&&!speciesConditions(attacker)?.prone)throw Object.assign(new Error('При потере ноги стрелять можно только из положения лёжа.'),{statusCode:409});
    assertHeavyWeaponReady(attacker,weapon);assertSpecialRangedReady(attacker,weapon);
    const attackOrigin=options.attackOrigin||speciesCombatPoint(attacker),targetPoint=options.targetPoint||(body.targetPart==='head'?speciesCombatPoint(target):target);
    const engagedAttackers=hostileMeleeOpponents(scene,attacker,attackOrigin);
    const shotgunInMelee=!options.skipEngagedAttackerCheck&&engagedAttackers.length>0&&weaponIsShotgun(weapon);
    if(!options.skipEngagedAttackerCheck&&engagedAttackers.length&&!shotgunInMelee){
      throw Object.assign(new Error(`Стрельба недоступна: ${attacker.name} связан ближним боем с ${engagedAttackers.map(item=>item.name).join(', ')}. В ближнем бою из огнестрельного оружия разрешены только дробовики.`),{statusCode:409});
    }
    const targetAb=actionHost(target)?._battlemapAberration||{};if(targetAb.invisibleUntargetable&&!body.ignoreInvisibility)throw Object.assign(new Error('Цель скрыта краткосрочной невидимостью и не может быть выбрана для дальнобойной атаки.'),{statusCode:409});
    if(attacker.kind==='npc'&&isStealthed(target)&&!options.allowStealthTarget)throw Object.assign(new Error('Цель находится в Скрытности. NPC не может выбрать её целью дальнобойной атаки; исключение — Контрснайперский выстрел.'),{statusCode:409});
    const distance = distanceFeet(scene, attackOrigin, targetPoint);
    const blocked = contactBlockedByWall(scene, attackOrigin, targetPoint);
    if (blocked && !body.ignoreLineOfSight) throw Object.assign(new Error('Линия огня перекрыта стеной или закрытой дверью.'), { statusCode: 409 });
    const outOfRange = distance > safeNumber(weapon.range, 5) + 0.001;
    if (outOfRange && !body.ignoreRange) throw Object.assign(new Error(`Цель вне дальности оружия: ${distance.toFixed(1)} фт при максимуме ${weapon.range} фт.`), { statusCode: 409 });
    const peeking=Boolean(tokenActions(attacker)?.peek)&&tokenAdjacentToCover(scene,attacker);
    const ignoreNearOrigin=peeking||Boolean(options.ignoreNearOriginCover);
    const coverInfo = automaticCoverInfo(scene, attackOrigin, targetPoint, { ignoreNearOrigin, originToken: attacker });
    const coverMz = coverInfo.mz;
    const zoneMz = automaticZoneMz(scene, attackOrigin, targetPoint);
    const naturalMz = tokenNaturalMz(target);
    const defensiveMzBonus = tokenDefensiveMzBonus(target);
    const baseMz = naturalMz + defensiveMzBonus;
    const movedThisTurn = body.moved === true || Boolean(state.combat?.active && state.combat.sceneId === scene.id && safeNumber(state.combat?.movement?.[attacker.id]?.spent, 0) > 0.001);
    const meleeParticipants=options.ignoreTargetMelee?[]:hostileMeleeOpponents(scene,target,targetPoint).filter(item=>item.id!==attacker.id);
    const targetInMelee=meleeParticipants.length>0;
    const explicitMz = body.targetMz === null || body.targetMz === undefined || body.targetMz === '' ? null : Math.round(safeNumber(body.targetMz, baseMz));
    const meleeTargetMz=8+Math.floor(Math.max(0,tokenAcrobaticsBonus(target))/2);
    let specialMode = ['dual','anaxion','slug'].includes(body.specialMode) ? body.specialMode : null;
    if (specialMode === 'anaxion' && !weaponSupportsAnaxion(weapon)) throw Object.assign(new Error('Этот профиль не может использовать Анаксионный режим.'), { statusCode:409 });
    const shotgunProfile=shotgunProfileForWeapon(weapon);
    if (specialMode === 'slug' && !(shotgunProfile?.slugModeAvailable)) throw Object.assign(new Error('Для этого оружия не установлен «Пулевой ствол».'), { statusCode:409 });
    if (specialMode === 'dual') {
      const eligible = weapons.filter(item => weaponSupportsDual(item));
      const traitLevel = safeNumber(linkedCharacter(attacker)?.state?.traits?.main?.['Ловкий'], 0);
      if (eligible.length < 2 || (attacker.kind === 'character' && traitLevel < 3)) throw Object.assign(new Error('Для Стрельбы с двух рук нужны два подходящих одноручных оружия и способность Ловкого 3.'), { statusCode:409 });
    }
    const rifleProfile=rifleProfileForWeapon(weapon);
    const measuredShot=body.shotMode==='measured';
    if(measuredShot){
      if(!rifleProfile)throw Object.assign(new Error('«Выверенный выстрел» доступен только винтовкам.'),{statusCode:409});
      if(movedThisTurn)throw Object.assign(new Error('«Выверенный выстрел» недоступен после перемещения в этом ходу.'),{statusCode:409});
      if(distance<=30.001)throw Object.assign(new Error('Для «Выверенного выстрела» цель должна находиться дальше 30 футов.'),{statusCode:409});
      if(rifleProfile.proficiency<rifleProfile.effectiveThreshold)throw Object.assign(new Error(`Для «Выверенного выстрела» владение винтовками должно быть не ниже порога ${rifleProfile.effectiveThreshold}.`),{statusCode:409});
    }
    const effectiveShotMode=measuredShot?'measured':(body.shotMode==='aimed'&&weapon.hitDieAimed&&specialMode!=='dual'?'aimed':'normal');
    const smokeOnLine=Boolean(counterSniperSmokeBlock(scene,attackOrigin,targetPoint));
    const badVisibility=Boolean(scene.settings?.badVisibility||body.badVisibility===true),weaponModEffects=weaponModAttackEffects(weapon,{distance,shotMode:effectiveShotMode,moved:movedThisTurn,badVisibility,smoke:smokeOnLine,attacker,specialMode});
    const narrativeAttack=options.narrativeAttack||consumeNarrative(attacker,'attack'),narrativeDefense=options.narrativeDefense||consumeNarrative(target,'defense');
    const featureAttack=Object.prototype.hasOwnProperty.call(options,'featureAttack')?options.featureAttack:consumeFeatureEffectForTarget(attacker,'nextAttack',target.id),featureDefense=Object.prototype.hasOwnProperty.call(options,'featureDefense')?options.featureDefense:consumeFeatureEffect(target,'nextDefense'),featureAttackRoll=Object.prototype.hasOwnProperty.call(options,'featureAttackRoll')?Math.round(safeNumber(options.featureAttackRoll,0)):featureEffectRoll(featureAttack);
    // Дробовик против противника, непосредственно связанного со стрелком, не
    // получает ни бесплатного преимущества, ни специального МЗ чужой рукопашной.
    const shotgunDirectMelee=Boolean(shotgunInMelee&&engagedAttackers.some(item=>item.id===target.id));
    const rangedTargetInMelee=targetInMelee&&!shotgunDirectMelee;
    const rangeAdjustedNaturalMz = rangedTargetInMelee ? naturalMz : shortRangeNaturalMz(naturalMz, distance);
    const shortRangeApplied = !rangedTargetInMelee && distance<=15.001;
    const coverSourceIsLight = coverInfo?.source?.material === 'light';
    const lightCoverIgnore = coverSourceIsLight ? Math.max(0, Math.round(safeNumber(weapon.lightCoverIgnoreMz, 0))) : 0;
    const baseWeaponIgnore=Math.max(0,Math.round(safeNumber(weapon.ignoreMz,0)+safeNumber(weaponModEffects.ignoreMz,0)),lightCoverIgnore);
    const measuredCoverIgnore=measuredShot?(1+(rifleProfile?.bipod?1:0)):0;
    const weaponCoverIgnore=measuredShot?Math.min(3,baseWeaponIgnore+measuredCoverIgnore):baseWeaponIgnore;
    const targetSniperPosition=sniperPositionAtToken(scene,target);
    const targetSniperPositionLevel=Math.max(0,Math.round(safeNumber(targetSniperPosition?.level,0)));
    const positionCoverIgnore=targetSniperPositionLevel>=3?coverMz:(targetSniperPositionLevel===2?Math.min(2,coverMz):0);
    const coverIgnore=Math.min(coverMz,Math.max(0,weaponCoverIgnore+positionCoverIgnore));
    const coverAfterIgnore = Math.max(0, coverMz - coverIgnore);
    const explicitDefenseBonus = defensiveMzBonus + zoneMz + Math.round(safeNumber(target.coverBonus, 0));
    const ordinaryTargetMz = explicitMz ?? (Math.max(rangeAdjustedNaturalMz, coverAfterIgnore) + explicitDefenseBonus);
    const directShotgunMz = rangeAdjustedNaturalMz + explicitDefenseBonus;
    let targetMz = (shotgunDirectMelee ? directShotgunMz : (rangedTargetInMelee ? meleeTargetMz : ordinaryTargetMz)) + narrativeDefense.bonus + Math.round(safeNumber(featureDefense?.flat,0));
    const mainTraitMark=activeMainTraitMark(attacker,scene,target),experiencedLook=activeExperiencedLook(attacker,scene,target),experiencedLookHitBonus=experiencedLook?3:0,pristrelka=activePristrelka(attacker,scene,target),pristrelkaHitBonus=pristrelka?2:0;
    if(mainTraitMark)targetMz=Math.max(0,targetMz-2);
    let thoughtfulReadMovesMz=0;
    if(target.kind==='character'&&bonusTraitLevel(target,'Вдумчивый')>=2){
      const targetCharacter=linkedCharacter(target),studied=studiedTargetToken(targetCharacter,scene),round=Math.max(0,Math.round(safeNumber(getCampaign().initiative?.round,0))),rt=bonusTraitRuntime(targetCharacter?.state||{},true),key=`${bonusBattleScope(scene)}:${round}:${attacker.id}`;
      rt.readMovesUsed=rt.readMovesUsed&&typeof rt.readMovesUsed==='object'&&!Array.isArray(rt.readMovesUsed)?rt.readMovesUsed:{};
      if(studied?.id===attacker.id&&!rt.readMovesUsed[key]){thoughtfulReadMovesMz=1;targetMz+=1;rt.readMovesUsed[key]=nowIso();}
    }
    const shotMode = effectiveShotMode;
    if(shotgunProfile?.coneDepthFeet>0&&!shotgunProfile.singleTargetOnly&&!options.allowShotgunSingle&&specialMode!=='slug'&&distance<=30.001)throw Object.assign(new Error('На дистанции до 30 футов обычный дробовик использует конусную атаку. Для одноцелевого выстрела нужен «Пулевой ствол».'),{statusCode:409});
    let hitDie = shotMode === 'aimed' ? weapon.hitDieAimed : weapon.hitDieNormal;
    if(shotgunProfile&&/боевой дробовик/i.test(weaponText(weapon)))hitDie=distance<=10?'1d8':'1d6';
    if(shotgunProfile?.longBarrel&&distance>10&&distance<=30)hitDie='1d8';
    const sides = dieSides(hitDie, 6);
    const activeSuppressionEffects = (scene.effects||[]).filter(effect => effect.type === 'suppression' && effect.remainingRounds > 0 && Math.hypot(attacker.x-effect.x,attacker.y-effect.y) <= feetToScenePixels(scene,effect.radius||7.5));
    const suppressed = activeSuppressionEffects.length > 0;
    const suppressionHitPenalty = activeSuppressionEffects.reduce((worst,effect)=>Math.min(worst,Math.round(safeNumber(effect.hitPenalty,0))),0);
    const currentRound=getCampaign().initiative?.round||0;
    const riddenVehicle=attacker.boardedVehicleId?findToken(scene,attacker.boardedVehicleId):null;
    const vehicleMoved=Boolean(riddenVehicle?.kind==='vehicle'&&riddenVehicle.vehicle?.movedRound===currentRound);
    const vehicleStabilized=Boolean(riddenVehicle?.kind==='vehicle'&&(riddenVehicle.vehicle?.stabilizedUntilDriverTurn||riddenVehicle.vehicle?.stabilizedRound===currentRound));
    const vehicleRough=Boolean(riddenVehicle?.kind==='vehicle'&&riddenVehicle.vehicle?.roughUntilDriverTurn);
    const riddenSeatRole=riddenVehicle?.kind==='vehicle'?vehicleSeatRole(riddenVehicle,attacker.id):null;
    const passengerVehicleHindrance=Boolean(!options.vehicleMounted&&riddenSeatRole==='passenger'&&!vehicleStabilized);
    const attackerMedical=actionHost(attacker)||{},attackerTough=attacker.kind==='character'?bonusTraitLevel(attacker,'Крепкий'):0;
    const badVisibilityHindrance=Boolean(badVisibility&&!weaponHasMod(weapon,'shotgun_sealed_action'));
    let attackHindrance = Boolean(tokenActions(attacker)?.gasAttackHindrance || (safeNumber(attackerMedical?.wounds?.medium,0)>0&&attackerTough<2) || suppressed || vehicleRough || passengerVehicleHindrance || rangedTargetInMelee || targetAb.invisibleHindrance || badVisibilityHindrance || (movedThisTurn&&weaponIsHeavy(weapon)));
    const elevationDelta=0;
    const elevationLevel=scene.settings?.elevationRulesEnabled!==false?Math.max(elevationLevelAt(scene,attackOrigin),safeNumber(tokenActions(attacker)?.aberrantHoverLevel,0)):0;
    const elevationAdvantage=elevationLevel>=1;
    const attackerAb=actionHost(attacker)?._battlemapAberration||{};if(attackerAb.cancelNextHindrance&&attackHindrance){attackHindrance=false;delete attackerAb.cancelNextHindrance;}const markedFirstAttackAdvantage=consumeMarkedFirstAttackAdvantage(scene,attacker,target),attackAdvantage=Boolean(specialMode==='dual'||elevationAdvantage||attackerAb.invisibleFirstAttackAdvantage||markedFirstAttackAdvantage);if(attackerAb.invisibleFirstAttackAdvantage){delete attackerAb.invisibleFirstAttackAdvantage;delete attackerAb.invisibleUntargetable;delete attackerAb.invisibleHindrance;}
    const rollMode=mergeRollCondition(attackAdvantage||narrativeDefense.condition==='hindrance'||featureAttack?.condition==='advantage',attackHindrance||narrativeDefense.condition==='advantage'||featureAttack?.condition==='hindrance',narrativeAttack.condition);
    let attackRolls = rollMode===0 ? [rollOne(sides)] : [rollOne(sides), rollOne(sides)],forcedAttackReroll=false;
    let roll = rollMode>0 ? Math.max(...attackRolls) : rollMode<0 ? Math.min(...attackRolls) : attackRolls[0];if(attackerAb.forceNextReroll){attackRolls.push(rollOne(sides));roll=attackRolls[attackRolls.length-1];forcedAttackReroll=true;delete attackerAb.forceNextReroll;}
    const situational = Math.round(safeNumber(body.situationalModifier, 0));
    const conditional = conditionalWeaponModifier(weapon, distance, { moved: movedThisTurn, hasCover: coverMz > 0, hasPreviousTurn:Boolean(tokenActions(attacker)?.previousTurnMovement), previousTurnMoved:Boolean(tokenActions(attacker)?.previousTurnMovement?.moved) });
    const stabilityPenalty=weaponModInstabilityPenalty(weapon);
    if(stabilityPenalty){conditional.value+=stabilityPenalty;conditional.reasons.push(`${stabilityPenalty}: перегрев / нестабильность / отдача профиля`);}
    conditional.value+=weaponModEffects.hitBonus;conditional.reasons.push(...weaponModEffects.reasons);
    if(badVisibility){conditional.reasons.push(weaponHasMod(weapon,'shotgun_sealed_action')?'Герметичный механизм: помеха плохой погоды/слабой видимости игнорируется':'Плохая погода / слабая видимость: помеха');}
    if(smokeOnLine&&weaponHasMod(weapon,'carbine_reflex'))conditional.reasons.push('Коллиматорный прицел не работает через дым');
    if(safeNumber(attackerMedical?.wounds?.medium,0)>0&&attackerTough>=2){conditional.value-=1;conditional.reasons.push('Крепкий 2: Среднее ранение даёт −1 к боевой проверке вместо помехи');}
    if(thoughtfulReadMovesMz)conditional.reasons.push('Вдумчивый 2 — Читать движения: +1 МЗ против первой атаки Изученной цели в раунде');
    if(mainTraitMark)conditional.reasons.push('Метка: −2 МЗ цели против ваших атак');
    if(markedFirstAttackAdvantage)conditional.reasons.push('Метка: первая атака по цели в этом ходу получает преимущество');
    if(experiencedLookHitBonus)conditional.reasons.push('Опытный взгляд: +3 к попаданию по проанализированной цели');
    if(pristrelkaHitBonus)conditional.reasons.push('Пристрелка: +2 к попаданию по цели после предыдущего промаха');
    let measuredRoll=0;
    if(measuredShot){
      measuredRoll=rollOne(4);
      conditional.value+=Math.max(0,Math.round(safeNumber(rifleProfile?.measuredFlatBonus,0)));
      conditional.reasons.push(`Выверенный выстрел: +1к4=${measuredRoll}; игнорирует 1 МЗ укрытия`);
      if(rifleProfile?.measuredFlatBonus)conditional.reasons.push(`+${rifleProfile.measuredFlatBonus}: особенность профиля винтовки при Выверенном выстреле`);
      if(rifleProfile?.bipod)conditional.reasons.push('Сошки: Выверенный выстрел дополнительно игнорирует 1 МЗ укрытия');
      if(weaponCoverIgnore)conditional.reasons.push(`Оружие игнорирует ${weaponCoverIgnore} МЗ укрытия (до сравнения с базовым МЗ цели)`);
    }
    if(positionCoverIgnore){
      conditional.reasons.push(targetSniperPositionLevel>=3?'Пристрелянная огневая позиция: МЗ укрытия цели полностью игнорируется':`Раскрытая огневая позиция: дополнительно игнорируются 2 МЗ укрытия цели`);
      conditional.reasons.push(`Итого игнорируется ${coverIgnore} МЗ укрытия`);
    }
    if(shotgunProfile?.longBarrel&&distance>10&&distance<=30)conditional.reasons.push('Длинный ствол: куб попадания 1к8 на средней дистанции');
    if(attackRolls.length>(rollMode===0?1:2))conditional.reasons.push('Предвидение II: обязательный переброс, используется второй результат');
    if(elevationAdvantage)conditional.reasons.push(`Высота: зона «${elevationLevel>=2?'Очень высоко':'Высоко'}» даёт преимущество на стрельбу${attackHindrance?' — отменено помехой':''}`);
    const elevationIgnored=(coverInfo.ignored||[]).filter(item=>item.reason==='elevation');
    if(elevationIgnored.length)conditional.reasons.push(`Высота: траектория проходит над укрытием (${elevationIgnored.map(item=>item.name).join(', ')})`);
    if(peeking&&(coverInfo.ignored||[]).length)conditional.reasons.push(`Выглянуть: укрытие у стрелка не защищает цель (${coverInfo.ignored.map(item=>item.name).join(', ')})`);
    if(options.ignoreNearOriginCover&&!peeking&&(coverInfo.ignored||[]).length)conditional.reasons.push('Зона обстрела: укрытие у стрелка не учитывается');
    if(shortRangeApplied)conditional.reasons.push(`Короткая дистанция (≤15 фт): базовое/природное МЗ ${naturalMz} → ${rangeAdjustedNaturalMz} (пополам, округление вверх)`);
    if(shotgunDirectMelee)conditional.reasons.push(`Дробовик в собственном ближнем бою: без преимущества и без МЗ укрытия; используется базовое МЗ ${rangeAdjustedNaturalMz} с обычными защитными модификаторами`);
    if(rangedTargetInMelee)conditional.reasons.push(`Стрельба по цели в ближнем бою: помеха; МЗ ${meleeTargetMz} (8 + половина Акробатики)`);
    const vehiclePenalty=0;
    if(safeNumber(attackerMedical?.wounds?.medium,0)>0&&attackerTough<2)conditional.reasons.push('Среднее ранение: помеха на боевую проверку');
    if(passengerVehicleHindrance)conditional.reasons.push('Пассажирское место: стрельба личным оружием с помехой; «Стабилизировать ход» водителя снимает её на этот раунд');
    if(vehicleStabilized&&riddenSeatRole==='passenger')conditional.reasons.push('Стабилизированный ход: помеха пассажира снята');
    if(vehicleRough)conditional.reasons.push('Резкий манёвр транспорта: помеха');
    if(suppressionHitPenalty){conditional.value+=suppressionHitPenalty;conditional.reasons.push(`${suppressionHitPenalty}: Автоматический карабин усиливает Подавление`);}
    if(movedThisTurn&&weaponIsHeavy(weapon))conditional.reasons.push('Тяжёлое оружие после движения: помеха');
    if(narrativeAttack.condition!=='normal')conditional.reasons.push(`Мастер: ${narrativeAttack.condition==='advantage'?'преимущество':'помеха'}${narrativeAttack.note?` — ${narrativeAttack.note}`:''}`);
    if(narrativeAttack.bonus)conditional.reasons.push(`Мастер: ${narrativeAttack.bonus>0?'+':''}${narrativeAttack.bonus} к попаданию`);
    if(narrativeDefense.condition!=='normal')conditional.reasons.push(`Мастер: защита цели с ${narrativeDefense.condition==='advantage'?'преимуществом':'помехой'}${narrativeDefense.note?` — ${narrativeDefense.note}`:''}`);
    if(narrativeDefense.bonus)conditional.reasons.push(`Мастер: ${narrativeDefense.bonus>0?'+':''}${narrativeDefense.bonus} к МЗ цели`);
    if(featureAttack){const parts=[];if(featureAttack.flat)parts.push(`${featureAttack.flat>0?'+':''}${featureAttack.flat}`);if(featureAttackRoll)parts.push(`1к${featureAttack.extraDie}=${featureAttackRoll}`);if(featureAttack.condition)parts.push(featureAttack.condition==='advantage'?'преимущество':'помеха');conditional.reasons.push(`${featureAttack.sourceName||'Особенность'}: ${parts.join(', ')||'эффект атаки'}`);}
    if(featureDefense?.flat)conditional.reasons.push(`${featureDefense.sourceName||'Особенность цели'}: +${featureDefense.flat} МЗ`);
    const baseHitBonus = Math.round(safeNumber(weapon.hitBonus, 0)) + situational + conditional.value + vehiclePenalty + narrativeAttack.bonus + critical.attackPenalty + Math.round(safeNumber(featureAttack?.flat,0)) + experiencedLookHitBonus + pristrelkaHitBonus;
    const hitBonus = baseHitBonus + featureAttackRoll + measuredRoll;
    const total = roll + hitBonus;
    let hit = total >= targetMz,forcedMissReason=null;if(hit&&targetAb.cancelNextHit){hit=false;forcedMissReason='Следующее попадание отменено защитным эффектом';delete targetAb.cancelNextHit;}if(hit&&targetAb.dodgeNextAttack){hit=false;forcedMissReason='Невероятная ловкость: следующая атака уклонена';delete targetAb.dodgeNextAttack;}
    const redirectTarget=!hit&&rangedTargetInMelee?chooseMeleeMissRecipient(attackOrigin,targetPoint,meleeParticipants):null;
    return {
      id: makeId('attack'), at: nowIso(), actorId: cleanId(body.clientId, null), actorName: cleanName(body.playerName, 'Участник'),
      kind: 'attack', reactionType: options.reactionType||null, visibility: body.visibility === 'master' ? 'master' : 'public', sceneId: scene.id,
      attackerTokenId: attacker.id, attackerName: attacker.name, targetTokenId: target.id, targetName: target.name,
      damageTargetTokenId: hit ? target.id : (redirectTarget?.id||null), damageTargetName: hit ? target.name : (redirectTarget?.name||null),
      targetInMelee:rangedTargetInMelee, shotgunInMelee, shotgunDirectMelee, engagedAttackerTokenIds:engagedAttackers.map(item=>item.id), meleeParticipantTokenIds:rangedTargetInMelee?meleeParticipants.map(item=>item.id):[], missRedirectTargetTokenId:redirectTarget?.id||null, missRedirectTargetName:redirectTarget?.name||null,
      mainTraitEffects:{mark:mainTraitMark?{targetTokenId:target.id,mzPenalty:2,firstAttackAdvantage:markedFirstAttackAdvantage}:null,experiencedLook:experiencedLook?{targetTokenId:target.id,hitBonus:3}:null,pristrelka:pristrelka?{targetTokenId:target.id,hitBonus:2,applied:true}:null},
      weapon, shotMode, distance: Math.round(distance * 10) / 10, distanceBand: distanceBand(distance), lineOfSightBlocked: blocked,
      coverMz:shotgunDirectMelee||rangedTargetInMelee?0:coverMz, coverSource:shotgunDirectMelee||rangedTargetInMelee?null:coverInfo.source, coverIgnore, weaponCoverIgnore, positionCoverIgnore, targetSniperPositionLevel, coverAfterIgnore, peeking, ignoredFiringCover: coverInfo.ignored || [], elevationDelta:Math.round(elevationDelta*10)/10, elevationAdvantage,
      zoneMz:rangedTargetInMelee?0:zoneMz, naturalMz, rangeAdjustedNaturalMz, shortRangeApplied, defensiveMzBonus, baseMz, targetMz, narrative:{attack:narrativeAttack,defense:narrativeDefense}, featureEffects:{attack:featureAttack,defense:featureDefense,attackRoll:featureAttackRoll}, hitDie, roll, attackRolls:[...attackRolls], reactionRollMode:rollMode, reactionSides:sides, forcedMissReason, baseHitBonus, hitBonus, situationalModifier: situational, conditionalReasons: conditional.reasons,
      total, hit, margin: total - targetMz, damage: Math.max(weaponModEffects.damageBonus<0?1:0, weapon.damage + safeNumber(weaponModEffects.damageBonus,0) + (specialMode === 'anaxion' ? 1 : 0) + (specialMode === 'slug' ? 1 : 0) + narrativeAttack.damageBonus), damageTag: weapon.damageTag,
      weaponModEffects:{...weaponModEffects,overchargeRadiusBonus:tokenActions(attacker)?.weaponModOvercharge?.weaponKey===heavyWeaponKey(weapon)&&tokenActions(attacker)?.weaponModOvercharge?.mode==='radius'?5:0}, stealthAtAttack:isStealthed(attacker),
      flags: { ...attackFlagsFromWeapon(weapon), anaxion: specialMode === 'anaxion' || attackFlagsFromWeapon(weapon).anaxion }, specialMode,
      odCost: specialMode==='slug' ? 3 : (shotMode === 'measured' ? Math.max(0, safeNumber(weapon.odCost,0)+1) : (shotMode === 'aimed' ? Math.max(0, safeNumber(weapon.aimedOdCost, safeNumber(weapon.odCost, 0) + 1)) : specialRangedAttackOdCost(attacker,weapon))),
      obCost: Math.max(0,safeNumber(weapon.obCost,0)) + (['dual','anaxion'].includes(specialMode) ? 1 : 0),
      measuredShot: measuredShot ? { active:true, roll:measuredRoll, flatBonus:Math.max(0,Math.round(safeNumber(rifleProfile?.measuredFlatBonus,0))), coverIgnore, weaponCoverIgnore, positionCoverIgnore, bipod:Boolean(rifleProfile?.bipod), proficiency:rifleProfile?.proficiency, threshold:rifleProfile?.effectiveThreshold } : null,
      movedThisTurn,
      label: options.label||`${attacker.name}: ${weapon.name}${measuredShot?' (Выверенный выстрел)':''} → ${target.name}`,
      formula: attackFormulaText(hitDie,rollMode,featureAttack?.extraDie,baseHitBonus,`МЗ ${targetMz}`,forcedAttackReroll,measuredShot?[4]:[]), rolls: [...attackRolls,...(measuredShot?[measuredRoll]:[]),...(featureAttackRoll?[featureAttackRoll]:[])], modifier: hitBonus
    };
  }

  async function spendAttackResources(attacker, attack, body, masterAuthorized = false) {
    if (!body.spendResources || !state.combat?.active || state.combat.sceneId !== attack.sceneId) return;
    if (attacker.kind === 'character') {
      const character = linkedCharacter(attacker);
      if (!character) return;
      const before = clone(character);
      const st = character.state || (character.state = {});
      const odCurrent = safeNumber(st.odCurrent, st.od || 0);
      const obCurrent = safeNumber(st.obCurrent, st.ob || 0);
      const requiredOdCost = Math.max(attack.odCost, safeNumber(attack.requiredOdCost, attack.odCost));
      if (odCurrent < requiredOdCost) throw Object.assign(new Error(`Недостаточно ОД: требуется ${requiredOdCost}.`), { statusCode: 409 });
      if (obCurrent < attack.obCost) throw Object.assign(new Error(`Недостаточно ОБ: требуется ${attack.obCost}.`), { statusCode: 409 });
      st.odCurrent = odCurrent - attack.odCost;
      st.obCurrent = obCurrent - attack.obCost;
      character.revision = Math.max(0, Number(character.revision || 0)) + 1;
      character.updatedAt = nowIso();
      character.updatedBy = cleanId(body.clientId, null);
      await persistCampaign();
      if (recordHistory && persistHistory) {
        const entry = recordHistory({
          actor: { id: cleanId(body.clientId, null), name: cleanName(body.playerName, 'Участник'), role: masterAuthorized ? 'master' : 'player' },
          action: 'battlemap-attack-cost', entityType: 'character', entityId: character.id,
          summary: `${character.name}: атака «${attack.weapon.name}», ОД -${attack.odCost}${attack.obCost ? `, ОБ -${attack.obCost}` : ''}`,
          undoData: { kind: 'restore-character', character: before }
        });
        await persistHistory();
        if (broadcastHistory) broadcastHistory(entry);
      }
      if (broadcastCharacterUpdated) broadcastCharacterUpdated(character, body.clientId);
    } else if (attacker.kind === 'npc') {
      const npc = linkedNpc(attacker);
      if (!npc) return;
      const requiredOdCost = Math.max(attack.odCost, safeNumber(attack.requiredOdCost, attack.odCost));
      const obCurrent = Math.max(0, Math.round(safeNumber(npc.ob?.current, npc.obCurrent ?? 4)));
      if (safeNumber(npc.od?.current, 0) < requiredOdCost) throw Object.assign(new Error(`У NPC недостаточно ОД: требуется ${requiredOdCost}.`), { statusCode: 409 });
      if (obCurrent < Math.max(0, safeNumber(attack.obCost, 0))) throw Object.assign(new Error(`У NPC недостаточно ОБ: требуется ${attack.obCost}.`), { statusCode: 409 });
      npc.od.current -= attack.odCost;
      npc.ob = npc.ob && typeof npc.ob === 'object' ? npc.ob : { current: obCurrent, max: Math.max(4, obCurrent) };
      npc.ob.current = obCurrent - Math.max(0, safeNumber(attack.obCost, 0));
      await persistCampaign();
    }
  }


  function tokenSpeedFeet(token) {
    if (!token) return 0;
    if (token.kind === 'npc') {
      const npc = linkedNpc(token);
      if (!npc || npc.dead || npc.outOfCombat || npc.wounds?.critical) return 0;
      const armorProfile=normalizedNpcArmor(npc).profile;
      let speed=Math.max(0,safeNumber(npc.speed,30)+armorSpeedPenaltyForProfile(armorProfile));
      if (safeNumber(npc.wounds?.serious, 0) > 0) speed = Math.floor(speed / 2);
      return speed;
    }
    if (token.kind === 'vehicle') {
      const v=token.vehicle||{};
      if (safeNumber(v.hullCurrent,0)<=0) return 0;
      const zones=safeNumber(v.hullCurrent,0)<=1?Math.min(1,safeNumber(v.speed,0)):safeNumber(v.speed,0);
      return Math.max(0,zones*safeNumber(v.zoneFeet,60));
    }
    if (token.kind === 'character') {
      const st = ensureSpeciesRuntime(linkedCharacter(token)?.state || {}) || {};
      if (st.medical?.dead || st.wounds?.critical || speciesConditions(token)?.prone || speciesConditions(token)?.wrappedByTokenId) return 0;
      let speed = Math.max(0, safeNumber(st.speed, 30));
      if (st.species==='pallid'&&st.pallid?.transformed) speed += 30;
      if (st.species==='werewolf'&&st.werewolf?.transformed) speed += 40;
      if (st.species==='rokurokubi'&&st.rokurokubi?.neckExtended) speed += 10;
      if (st.species==='rokurokubi'&&st.rokurokubi?.wrappedTargetTokenId) speed = Math.floor(speed/2);
      if (safeNumber(st.wounds?.serious, 0) > 0) speed = bonusTraitLevel(linkedCharacter(token),'Крепкий')>=3?Math.max(0,speed-10):Math.floor(speed / 2);
      // «Охлаждающий кожух»: штраф существует, пока мод установлен на одном
      // из реально экипированных и активных тяжёлых профилей.
      const coolingPenalty=fallbackWeaponsForCharacter(linkedCharacter(token)).some(weapon=>weaponHasMod(weapon,'heavy_cooling_shroud'))?5:0;
      speed=Math.max(0,speed-coolingPenalty);
      return speed;
    }
    return 0;
  }

  function tokenMovementLimit(token) {
    let limit = tokenSpeedFeet(token);
    const actions = tokenActions(token);
    if (actions?.sprint) limit *= Math.max(1, safeNumber(actions.sprint.movementMultiplier, 2));
    if (actions?.charge) { const st=speciesStateForToken(token); limit += st?.species==='werewolf'&&st.werewolf?.transformed?30:st?.species==='pallid'&&st.pallid?.transformed?20:10; }
    return Math.max(0, Math.round(limit * 10) / 10);
  }

  function movementRecord(token) {
    state.combat.movement ||= {};
    state.combat.movement[token.id] ||= { spent: 0, opportunityAttackers: [], zoneFireShooters: [] };
    const record=state.combat.movement[token.id];
    record.opportunityAttackers ||= [];
    record.zoneFireShooters ||= [];
    return record;
  }

  function movementSummary(token) {
    if (!state.combat?.active || !token || (token.kind !== 'vehicle' && !state.combat.participantTokenIds?.includes(token.id))) return null;
    const record = movementRecord(token), limit = tokenMovementLimit(token);
    const spent = Math.max(0, Math.round(safeNumber(record.spent, 0) * 10) / 10);
    const locked=tokenMovementLocked(token);
    return { spent, limit, remaining: locked?0:Math.max(0, Math.round((limit - spent) * 10) / 10), locked, lockReason:locked?'Блок':null };
  }

  function resetTokenMovement(token) {
    if (!state.combat?.active || !token) return;
    state.combat.movement ||= {};
    state.combat.movement[token.id] = { spent: 0, opportunityAttackers: [], zoneFireShooters: [] };
  }

  function groupForToken(_scene, token) { return token?.groupId ? findGlobalTokenGroup(token.groupId) : null; }
  function moraleHost(token) {
    if (token?.kind === 'character') return linkedCharacter(token)?.state?.morale || null;
    if (token?.kind === 'npc') return linkedNpc(token)?.morale || null;
    return null;
  }
  function tokenIsDead(token) { return criticalState(token).dead || Boolean(token?.defeated && !criticalState(token).critical); }
  function applyGroupDeathMorale(scene, deceasedToken, body = {}) {
    const group=groupForToken(scene,deceasedToken), deceasedHost=actionHost(deceasedToken);
    if(!group||group.moraleOnDeath===false||!deceasedHost||deceasedHost._battlemapGroupDeathMoraleApplied)return [];
    deceasedHost._battlemapGroupDeathMoraleApplied=true;
    const affected=[];
    for(const token of scene.tokens||[]){
      if(token.id===deceasedToken.id||token.groupId!==group.id||!['character','npc'].includes(token.kind)||tokenIsDead(token))continue;
      const morale=moraleHost(token);if(!morale)continue;
      const before=Math.max(0,Math.round(safeNumber(morale.current,0))),resolved=fixedMoraleLossWithBonusTraits(scene,token,10);morale.current=Math.max(0,before-resolved.total);
      affected.push({tokenId:token.id,tokenName:token.name,before,after:morale.current,loss:resolved.total,rawLoss:10,presenceReduction:resolved.presenceReduction,steadiedBy:resolved.steadiedBy});
      if(token.kind==='character'){markCharacterChanged(token,body.clientId);if(broadcastCharacterUpdated)broadcastCharacterUpdated(linkedCharacter(token),body.clientId);}else{const npc=linkedNpc(token);if(npc)npc.updatedAt=nowIso();}
    }
    return affected;
  }
  function markTokenDead(scene, token, body = {}, reason='Критическое ранение') {
    const info=criticalState(token),host=actionHost(token)||{};
    if(token?.kind==='character'&&reason!=='Мгновенное действие Мастера'&&bonusTraitLevel(token,'Удачливый')>=6&&!bonusAbilityUsed(host,scene,'Удачливый:6','long-rest')){
      markBonusAbilityUsed(host,scene,'Удачливый:6','long-rest');
      info.medical.dead=false;info.medical.stabilized=false;info.medical.criticalRounds=0;info.medical.failedStabilizers=[];info.medical.failedStabilizerIds=[];
      if(info.wounds?.critical){info.wounds.critical=false;info.medical.bleeding=false;addCriticalRecoveryEffect(host);}
      delete info.medical._criticalSkipCurrentTurn;delete host._battlemapDeathHandled;token.defeated=false;
      return {died:false,prevented:true,ability:'Удачливый 6 — Не сегодня',affected:[],reason};
    }
    if(host._battlemapDeathHandled)return {died:false,affected:[]};
    host._battlemapDeathHandled=true;info.medical.dead=true;info.medical.stabilized=false;token.defeated=true;
    if(token.kind==='npc'){const npc=linkedNpc(token);if(npc)npc.outOfCombat=true;}
    const affected=applyGroupDeathMorale(scene,token,body);
    const nearbyBeastChecks=triggerNearbyWerewolfDeath(scene,token,body);
    return {died:true,affected,nearbyBeastChecks,reason};
  }
  function processCriticalCountdownAtTurnEnd(scene, token, body = {}) {
    const info=criticalState(token);
    if(!info.critical||info.dead||info.stabilized)return {advanced:false,died:false,info};
    if(info.medical._criticalSkipCurrentTurn){delete info.medical._criticalSkipCurrentTurn;return {advanced:false,died:false,skipped:true,info:criticalState(token)};}
    info.medical.criticalRounds=Math.max(0,info.elapsed)+1;
    const next=criticalState(token);
    if(next.elapsed>=next.limit){const death=markTokenDead(scene,token,body,'Истёк отсчёт Критического ранения');return {advanced:true,died:true,death,info:criticalState(token)};}
    return {advanced:true,died:false,info:next};
  }

  function processBleedingAtTurnEnd(scene, token, body = {}) {
    if(!token||!['character','npc'].includes(token.kind))return {advanced:false,reason:'unsupported'};
    const host=tokenMedicalHost(token),critical=criticalState(token);
    if(!host||!host.bleeding)return {advanced:false,reason:'not-bleeding',critical};
    if(critical.dead)return {advanced:false,reason:'dead',critical};
    // Кровотечение приостанавливается в Критическом ранении. Оно либо будет
    // снято успешной стабилизацией, либо снова продолжится только после
    // отдельного восстановления персонажа мастером.
    if(critical.critical)return {advanced:false,paused:true,reason:'critical',critical};
    const wound=token.kind==='character'?addCharacterWoundWithBonus(scene,token,host.wounds,'light',critical.medical,body):addWoundWithOverflow(host.wounds,'light',critical.medical);
    let death=null;
    if(wound==='critical')initializeCriticalCountdown(scene,token);
    else if(wound==='death')death=markTokenDead(scene,token,body,'Кровотечение нанесло новое ранение при Критическом ранении');
    if(token.kind==='character')markCharacterChanged(token,body.clientId);
    else {const npc=linkedNpc(token);if(npc)npc.updatedAt=nowIso();}
    return {advanced:true,wound,died:Boolean(death?.died),death,critical:criticalState(token),bleeding:Boolean(host.bleeding)};
  }

  function stabilizerIdentity(token) {
    return `${token?.kind||'token'}:${token?.refId||token?.id||'unknown'}`;
  }

  function failedStabilizerIdsFor(target) {
    const info=criticalState(target);
    info.medical.failedStabilizerIds=Array.isArray(info.medical.failedStabilizerIds)?info.medical.failedStabilizerIds:[];
    info.medical.failedStabilizers=Array.isArray(info.medical.failedStabilizers)?info.medical.failedStabilizers:[];
    return info.medical.failedStabilizerIds;
  }

  async function performStabilization(scene, source, target, body = {}) {
    const targetInfo=criticalState(target),sourceKey=stabilizerIdentity(source);
    if(!targetInfo.critical||targetInfo.dead)throw Object.assign(new Error('Цель не находится в состоянии, которое можно стабилизировать.'),{statusCode:409});
    if(failedStabilizerIdsFor(target).includes(sourceKey))throw Object.assign(new Error('Этот персонаж уже провалил попытку стабилизации данного Критического ранения.'),{statusCode:409});
    const check=runAnyTokenSkillCheck(source,'Медицина',6,0,{advantage:target.kind==='character'&&bonusTraitLevel(target,'Крепкий')>=5});
    if(!check)throw Object.assign(new Error('Не удалось выполнить проверку Медицины.'),{statusCode:400});
    let roll=storeSpeciesCheckRoll(scene,source,check,body,`${source.name}: Стабилизация ${target.name}`,{reactionSafe:true});roll=await awaitCheckRollResolution(scene,roll);syncCheckFromReactionRoll(check,roll);
    let outcome='failure',resultText='Стабилизация не удалась.';
    if(check.outcome==='critical-failure'){
      outcome='critical-failure';
      markTokenDead(scene,target,body,'Критический провал Стабилизации');
      resultText='Критический провал: цель погибает.';
    }else if(check.success){
      outcome=check.outcome==='critical-success'?'critical-success':'success';
      targetInfo.wounds.critical=false;
      targetInfo.medical.criticalRounds=0;
      targetInfo.medical.stabilized=false;
      targetInfo.medical.dead=false;
      targetInfo.medical.bleeding=false;
      targetInfo.medical.failedStabilizers=[];
      targetInfo.medical.failedStabilizerIds=[];
      if (target.kind === 'character') addCriticalRecoveryEffect(targetInfo.host);
      delete targetInfo.medical._criticalSkipCurrentTurn;
      delete targetInfo.medical._battlemapDeathHandled;delete targetInfo.host._battlemapDeathHandled;
      target.defeated=false;
      if(target.kind==='npc'){
        const npc=linkedNpc(target);if(npc){npc.outOfCombat=false;npc.updatedAt=nowIso();}
      }
      resultText='Критическое ранение снято, Кровотечение остановлено. Цель снова может двигаться и действовать.';
    }else{
      targetInfo.medical.failedStabilizerIds.push(sourceKey);
      if(!targetInfo.medical.failedStabilizers.includes(source.name))targetInfo.medical.failedStabilizers.push(source.name);
    }
    if(source.kind==='character')markCharacterChanged(source,body.clientId);else{const npc=linkedNpc(source);if(npc)npc.updatedAt=nowIso();}
    if(target.kind==='character')markCharacterChanged(target,body.clientId);else{const npc=linkedNpc(target);if(npc)npc.updatedAt=nowIso();}
    return {outcome,success:outcome==='success'||outcome==='critical-success',check,roll,resultText,critical:criticalState(target)};
  }

  function initiativeProfileForToken(token) {
    if (token.kind === 'npc') {
      const npc = linkedNpc(token),penalty=hasTrauma(npc,'Перелом черепа')?-2:0;
      return npc ? { cube: normalizeDie(npc.successDie, '1d6'), bonus: Math.round(safeNumber(npc.characteristics?.concentration, 0)+injurySkillPenalty(npc,'Бдительность').value+penalty) } : { cube: '1d6', bonus: 0 };
    }
    const character = linkedCharacter(token),st=character?.state||{},profile=characterSkillProfileDetailed(character,'Бдительность',true),penalty=hasTrauma(st,'Перелом черепа')?-2:0;
    return { cube: normalizeDie(profile?.cube || '1d6', '1d6'), bonus: Math.round(safeNumber(profile?.bonus, 0)+penalty) };
  }
  function rollCombatInitiative(items) {
    const rolled = items.map(item => {
      const profile = initiativeProfileForToken(item.token), sides = dieSides(profile.cube, 6), value = rollOne(sides);
      return { id: makeId('init'), tokenId:item.token.id, type: item.token.kind === 'npc' ? 'npc' : 'character', refId: item.token.refId, cube: `1d${sides}`, roll: value, bonus: profile.bonus, score: value + profile.bonus, tieBreaks: [], delayed: false };
    });
    for (let pass = 0; pass < 4; pass += 1) {
      const groups = new Map(); for (const entry of rolled) { const list = groups.get(entry.score) || []; list.push(entry); groups.set(entry.score, list); }
      const tied = [...groups.values()].filter(group => group.length > 1); if (!tied.length) break;
      for (const group of tied) for (const entry of group) { const reroll = rollOne(dieSides(entry.cube, 6)) + entry.bonus; entry.tieBreaks.push(reroll); entry.score = reroll; }
    }
    return rolled.sort((a,b)=>b.score-a.score || a.refId.localeCompare(b.refId));
  }
  async function rollCombatInitiativeWithReactions(scene,items,body={}){
    const rolled=await Promise.all(items.map(async item=>{const profile=initiativeProfileForToken(item.token),sides=dieSides(profile.cube,6),resolved=await resolveScalarRoll(scene,item.token,{body:{...body,playerName:body.playerName||item.token.name},label:`${item.token.name}: Инициатива`,sides,modifier:profile.bonus,kind:'initiative',purpose:'initiative'}),entry={id:makeId('init'),tokenId:item.token.id,type:item.token.kind==='npc'?'npc':'character',refId:item.token.refId,cube:`1d${sides}`,roll:resolved.value,bonus:profile.bonus,score:resolved.total,tieBreaks:[],tieRollIds:[],rollId:resolved.roll?.id||null,delayed:false};return entry;}));
    for(let pass=0;pass<4;pass+=1){const groups=new Map();for(const entry of rolled){const list=groups.get(entry.score)||[];list.push(entry);groups.set(entry.score,list);}const tied=[...groups.values()].filter(group=>group.length>1);if(!tied.length)break;await Promise.all(tied.flatMap(group=>group.map(async entry=>{const token=initiativeToken(scene,entry);if(!token)return;const resolved=await resolveScalarRoll(scene,token,{body:{...body,playerName:body.playerName||token.name},label:`${token.name}: Инициатива — разрешение ничьей`,sides:dieSides(entry.cube,6),modifier:entry.bonus,kind:'initiative',purpose:'initiative-tiebreak'});entry.tieBreaks.push(resolved.total);entry.tieRollIds.push(resolved.roll?.id||null);entry.score=resolved.total;})));}
    return rolled.sort((a,b)=>b.score-a.score||String(a.refId).localeCompare(String(b.refId)));
  }
  function initiativeFormulaLines(scene,entries){
    return (entries||[]).map(entry=>{const token=initiativeToken(scene,entry),bonus=signedFormulaBonus(entry.bonus),tieCount=Array.isArray(entry.tieBreaks)?entry.tieBreaks.length:0,tie=tieCount?` (при ничьей: ${tieCount}× повтор ${entry.cube}${bonus})`:'';return `Инициатива — ${token?.name||entry.refId||'участник'}: ${entry.cube}${bonus}${tie}`;});
  }
  function initiativeToken(scene, entry) {
    if(entry?.tokenId){const exact=scene?.tokens.find(token=>token.id===entry.tokenId);if(exact)return exact;}
    return scene?.tokens.find(token => token.refId === entry?.refId && ((entry.type === 'npc' && token.kind === 'npc') || (entry.type === 'character' && token.kind === 'character'))) || null;
  }
  function resetTurnResources(token) {
    if (!token) return;
    const preActions=tokenActions(token),previousMoved=Boolean(preActions?.previousTurnMovement?.moved);
    clearRoundActions(token);
    if(previousMoved)delete tokenActions(token).weaponModMount;
    resetTokenMovement(token);
    if (token.kind === 'character') {
      const character = linkedCharacter(token); if (!character) return;
      const st = ensureSpeciesRuntime(character.state || (character.state = {})), counterDebt = Math.max(0, Math.round(safeNumber(st._battlemapCounterDebt,0))), sniperDebt=Math.max(0,Math.round(safeNumber(st._battlemapSniperDebt,0))), shockDebt=Math.max(0,Math.round(safeNumber(st._battlemapShockDebt,0))), grenadeDebt=Math.max(0,Math.round(safeNumber(st._battlemapGrenadeReactionDebt,0))), thoughtfulDebt=Math.max(0,Math.round(safeNumber(st._battlemapThoughtfulDebt,0))), beastDebt=Math.max(0,Math.round(safeNumber(st.werewolf?.odDebt,0))),formBonus=st.species==='pallid'&&st.pallid?.transformed?1:0;
      st.odCurrent = Math.max(0, safeNumber(st.od, st.odMax || st.odCurrent || 0) + formBonus - counterDebt - sniperDebt - shockDebt - grenadeDebt - thoughtfulDebt - beastDebt); st._battlemapCounterDebt = 0; st._battlemapSniperDebt=0; st._battlemapShockDebt = 0; st._battlemapGrenadeReactionDebt=0; st._battlemapThoughtfulDebt=0; if(st.werewolf){st.werewolf.odDebt=0;st.werewolf.hideUsed=false;}
      character.revision = Math.max(0, Number(character.revision || 0)) + 1; character.updatedAt = nowIso();
    } else if (token.kind === 'npc') {
      const npc = linkedNpc(token); if (!npc) return; npc.od ||= {}; const debt=Math.max(0,Math.round(safeNumber(npc._battlemapCounterDebt,0))),sniperDebt=Math.max(0,Math.round(safeNumber(npc._battlemapSniperDebt,0))),shockDebt=Math.max(0,Math.round(safeNumber(npc._battlemapShockDebt,0))),grenadeDebt=Math.max(0,Math.round(safeNumber(npc._battlemapGrenadeReactionDebt,0)));
      npc.od.current = Math.max(0, safeNumber(npc.od.max, npc.od.current || 0) - debt - sniperDebt - shockDebt - grenadeDebt); npc._battlemapCounterDebt=0; npc._battlemapSniperDebt=0; npc._battlemapShockDebt=0; npc._battlemapGrenadeReactionDebt=0; npc.updatedAt = nowIso();
    }
  }
  function spendCounterCost(scene, token, cost) {
    cost = Math.max(1, Math.round(safeNumber(cost,1)));
    if (isCurrentCombatToken(scene, token)) { spendTokenOd(token, cost); return; }
    if (token.kind === 'character') {
      const st=linkedCharacter(token)?.state||{},max=safeNumber(st.od,st.odMax||0),debt=safeNumber(st._battlemapCounterDebt,0);
      if(max-debt<cost)throw Object.assign(new Error('В ближайшем ходу не хватит ОД для Встречного удара.'),{statusCode:409});
      st._battlemapCounterDebt=debt+cost;
    } else if(token.kind==='npc') {
      const npc=linkedNpc(token),max=safeNumber(npc?.od?.max,0),debt=safeNumber(npc?._battlemapCounterDebt,0);
      if(max-debt<cost)throw Object.assign(new Error('У NPC в ближайшем ходу не хватит ОД для Встречного удара.'),{statusCode:409});
      npc._battlemapCounterDebt=debt+cost;
    }
  }
  function tokenFutureOdDebt(token){
    const host=actionHost(token)||{};
    let debt=Math.max(0,Math.round(safeNumber(host._battlemapCounterDebt,0)))+Math.max(0,Math.round(safeNumber(host._battlemapSniperDebt,0)))+Math.max(0,Math.round(safeNumber(host._battlemapShockDebt,0)))+Math.max(0,Math.round(safeNumber(host._battlemapGrenadeReactionDebt,0)))+Math.max(0,Math.round(safeNumber(host._battlemapThoughtfulDebt,0)));
    const st=speciesStateForToken(token);if(st?.species==='werewolf')debt+=Math.max(0,Math.round(safeNumber(st.werewolf?.odDebt,0)));
    return debt;
  }
  function spendThoughtfulReactionCost(scene,token,cost=1){
    cost=Math.max(1,Math.round(safeNumber(cost,1)));
    if(isCurrentCombatToken(scene,token)){spendTokenOd(token,cost);return{immediate:true,cost};}
    const info=tokenOd(token),host=actionHost(token);if(!info||!host)throw Object.assign(new Error('Нет доступных ОД для реакции «Я это предусмотрел».'),{statusCode:409});
    if(info.max-tokenFutureOdDebt(token)<cost)throw Object.assign(new Error(`В ближайшем ходу не хватит ${cost} ОД для реакции «Я это предусмотрел».`),{statusCode:409});
    host._battlemapThoughtfulDebt=Math.max(0,Math.round(safeNumber(host._battlemapThoughtfulDebt,0)))+cost;return{immediate:false,cost};
  }
  function studiedObservableFact(scene,viewer,target,category){
    const host=actionHost(target)||{},wounds=host.wounds||{},weapon=weaponsForToken(target).find(item=>!item.unavailable)||null;
    if(category==='wounds'){
      const parts=[];if(wounds.critical)parts.push('Критическое');if(safeNumber(wounds.serious,0)>0)parts.push(`Серьёзных: ${Math.round(safeNumber(wounds.serious,0))}`);if(safeNumber(wounds.medium,0)>0)parts.push(`Средних: ${Math.round(safeNumber(wounds.medium,0))}`);if(safeNumber(wounds.light,0)>0)parts.push(`Лёгких: ${Math.round(safeNumber(wounds.light,0))}`);return parts.length?`Ранения: ${parts.join(', ')}.`:'Очевидных ранений не видно.';
    }
    if(category==='armor'){
      if(target.kind==='character'){
        const st=linkedCharacter(target)?.state||{},armor=equippedArmorForCharacter(st);if(!armor)return 'Очевидной брони нет.';
        const current=safeNumber(st.bz,0),maximum=Math.max(1,safeNumber(st.armorBzMax,armor.armorBz||current)),condition=current<=0?'повреждённое':current<=maximum*0.4?'сильно изношенное':'боеспособное';
        if(armor.profile==='Скрытая броня')return `Внешний вид не позволяет автоматически подтвердить или опровергнуть скрытую броню; точное наличие, профиль и модель определяет Мастер. Если броня обнаружена, её состояние: ${condition}.`;
        const classLabel={light:'лёгкая',medium:'средняя',heavy:'тяжёлая'}[armor.armorClass]||armor.armorClass||'неизвестная';
        const model=armor.model?`; модель «${armor.model}»`:'';return `Броня: класс ${classLabel}; профиль «${armor.profile||'неизвестен'}»${model}; состояние ${condition}.`;
      }
      const npc=linkedNpc(target)||{},armor=normalizedNpcArmor(npc);if(safeNumber(armor.bzMax,0)<=0)return 'Очевидной брони нет.';
      const condition=armor.bzCurrent<=0?'повреждённое':armor.bzCurrent<=Math.max(1,armor.bzMax)*0.4?'сильно изношенное':'боеспособное',classLabel={light:'лёгкая',medium:'средняя',heavy:'тяжёлая',special:'особая'}[armor.armorClass]||armor.armorClass||'неизвестная';
      if(armor.profile==='Скрытая броня')return `Внешний вид не позволяет автоматически подтвердить или опровергнуть скрытую броню; точное наличие, профиль и модель определяет Мастер. Если броня обнаружена, её состояние: ${condition}.`;
      return `Броня: класс ${classLabel}${armor.profile?`; профиль «${armor.profile}»`:''}${armor.model?`; модель «${armor.model}»`:''}; состояние ${condition}.`;
    }
    if(category==='weapon')return weapon?`Оружие: ${weapon.name||weapon.profile||'неизвестное'}, профиль ${weapon.profile||weapon.category||'не определён'}.`:'Очевидного оружия нет.';
    if(category==='effects'){
      const states=[];if(isStealthed(target))states.push('Скрытность');if(host.bleeding||host.medical?.bleeding)states.push('Кровотечение');if(host.wounds?.critical)states.push('Критическое ранение');if(speciesConditions(target)?.prone)states.push('Лежит');return states.length?`Заметные состояния: ${states.join(', ')}.`:'Заметных активных состояний не обнаружено.';
    }
    if(category==='mz'){
      const natural=tokenNaturalMz(target),defense=tokenDefensiveMzBonus(target);return `Наблюдаемая защита: базовое/природное МЗ около ${natural}${defense?`, активный защитный бонус +${defense}`:''}. Укрытие зависит от линии огня.`;
    }
    if(category==='speed')return `Примерная эффективная Скорость: ${Math.round(tokenSpeedFeet(target))} фт за раунд; характер движения определяется текущим состоянием.`;
    return 'Наблюдение не дало нового очевидного факта.';
  }
  function bonusCoverStepPoint(scene,token,feet=10){
    if(!scene||!token)return null;const from=speciesCombatPoint(token),candidates=[];
    for(const cover of scene.covers||[])if(safeNumber(cover.mz,0)>0)candidates.push({point:coverReferencePoint(cover),distance:coverDistanceFromPoint(from,cover),name:cover.name||'Укрытие'});
    for(const wall of scene.walls||[])if(safeNumber(wall.coverMz,0)>0){const points=wallPoints(wall);if(points.length){let best=null,bestD=Infinity;for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],dx=b.x-a.x,dy=b.y-a.y,t=clamp(((from.x-a.x)*dx+(from.y-a.y)*dy)/(dx*dx+dy*dy||1),0,1),p={x:a.x+dx*t,y:a.y+dy*t},d=Math.hypot(from.x-p.x,from.y-p.y);if(d<bestD){best=p;bestD=d;}}if(best)candidates.push({point:best,distance:bestD,name:wall.coverName||'Укрытие'});}}
    candidates.sort((a,b)=>a.distance-b.distance);
    for(const candidate of candidates.slice(0,12)){
      const route=aiFindRoute(scene,token,candidate.point);if(!route||route.length<2)continue;
      let remaining=Math.max(0,safeNumber(feet,10)),current={x:from.x,y:from.y};
      for(let i=1;i<route.length&&remaining>0.01;i++){const next=route[i],segment=distanceFeet(scene,current,next);if(segment<=remaining+.001){current={x:next.x,y:next.y};remaining-=segment;}else{const ratio=remaining/Math.max(.001,segment);current={x:current.x+(next.x-current.x)*ratio,y:current.y+(next.y-current.y)*ratio};remaining=0;}}
      return{x:current.x,y:current.y,coverName:candidate.name};
    }
    return null;
  }

  function spendSniperReactionCost(scene,token,cost){
    cost=Math.max(1,Math.round(safeNumber(cost,1)));
    if(isCurrentCombatToken(scene,token)){spendTokenOd(token,cost);return {immediate:true,cost};}
    const info=tokenOd(token),host=actionHost(token);
    if(!info||!host)throw Object.assign(new Error('У снайпера нет доступных ОД для реакции.'),{statusCode:409});
    if(info.max-tokenFutureOdDebt(token)<cost)throw Object.assign(new Error(`В ближайшем ходу не хватит ${cost} ОД для Контрснайперского выстрела.`),{statusCode:409});
    host._battlemapSniperDebt=Math.max(0,Math.round(safeNumber(host._battlemapSniperDebt,0)))+cost;
    return {immediate:false,cost};
  }

  function isCurrentCombatToken(scene, token) {
    if (!state.combat?.active || state.combat.sceneId !== scene?.id) return true;
    const campaign = getCampaign(), current = campaign.initiative?.entries?.[campaign.initiative.currentIndex || 0];
    const active = initiativeToken(scene, current); return Boolean(active && active.id === token.id);
  }

  async function applySpeciesPostAttack(scene, attacker, target, attack, damageResult, body) {
    const st=speciesStateForToken(attacker), targetCond=speciesConditionHost(target);
    if(!st||!attack?.hit)return [];
    const notes=[];
    if(attack.flags?.speciesAmbush&&st.species==='rokurokubi'){
      st.rokurokubi.neckExtended=true;st.rokurokubi.ambushUsed=true;st.rokurokubi.headPoint={x:target.x,y:target.y};
      setSpeciesEffect(st,'rokurokubiNeck','Расправленная шея','+10 футов Скорости; естественные атаки на дистанции 10 футов; руки заняты.');
      notes.push('Молниеносная засада использована; шея осталась расправленной.');
    }
    const woundApplied=Array.isArray(damageResult?.applied)&&damageResult.applied.some(value=>!['death'].includes(value));
    if(attack.flags?.wrapTarget&&woundApplied&&st.species==='rokurokubi'&&!st.rokurokubi.wrappedTargetTokenId){
      st.rokurokubi.wrappedTargetTokenId=target.id;st.rokurokubi.wrappedTarget=target.name;targetCond.wrappedByTokenId=attacker.id;
      setSpeciesEffect(st,'rokurokubiWrap',`Обвита цель: ${target.name}`,'Скорость цели 0; Рывок и Натиск недоступны; −1 к встречным броскам ближнего боя.');notes.push(`${target.name} Обвит.`);
    }
    if(attack.flags?.knockdown&&woundApplied){
      const postCost=Math.max(0,Math.round(safeNumber(attack.postHitOdCost,1)));
      if(postCost){
        if(attacker.kind==='character'){
          const attackerCharacter=linkedCharacter(attacker),attackerState=attackerCharacter?.state||{};
          attackerState.odCurrent=Math.max(0,safeNumber(attackerState.odCurrent,0)-postCost);
        }else if(attacker.kind==='npc'){
          const attackerNpc=linkedNpc(attacker);if(attackerNpc?.od)attackerNpc.od.current=Math.max(0,safeNumber(attackerNpc.od.current,0)-postCost);
        }
      }
      targetCond.prone=true;notes.push(`${target.name} сбит с ног${postCost?`; дополнительно потрачено ${postCost} ОД`:''}.`);
    }
    if(attack.flags?.lycanthropyRisk&&damageResult?.applied?.some(wound=>['medium','serious','critical'].includes(wound))){targetCond.lycanthropyExposure={sourceTokenId:attacker.id,sourceName:attacker.name,at:nowIso()};notes.push(`${target.name}: после сцены требуется проверка Иммунитета 1к8 против ликантропии.`);}
    if(attack.weapon?.id==='werewolf-bite'&&woundApplied&&st.species==='werewolf'&&st.werewolf.transformed){const resolved=await resolveWerewolfBeastCheck(scene,attacker,'укус нанёс ранение',body,{label:`${attacker.name}: Укус — Проверка Зверя`}),check=resolved.check;if(check)notes.push(`Проверка Зверя: ${check.success?'успех':'провал'} (${check.successTotal} против ${check.difficultyTotal??check.difficultyRoll}).`);}
    markCharacterChanged(attacker,body.clientId);
    if(target.kind==='character')markCharacterChanged(target,body.clientId);
    return notes;
  }

  function requestKey(body, scope) {
    const id = cleanId(body?.requestId, null);
    return id ? `${scope}:${id}` : null;
  }
  function cachedRequest(key) {
    if (!key) return null;
    const item = requestCache.get(key);
    if (!item || Date.now() - item.at > 2 * 60 * 1000) { requestCache.delete(key); return null; }
    return clone(item.payload);
  }
  function storeRequest(key, payload) {
    if (!key) return;
    requestCache.set(key, { at: Date.now(), payload: clone(payload) });
    if (requestCache.size > 500) {
      const entries = [...requestCache.entries()].sort((a, b) => a[1].at - b[1].at);
      for (const [oldKey] of entries.slice(0, requestCache.size - 400)) requestCache.delete(oldKey);
    }
  }


  const SKILL_GROUPS = {
    'Сила':['Физическая сила'], 'Ловкость':['Взлом','Акробатика','Скрытность'],
    'Выносливость':['Выдержка','Стойкость','Иммунитет'], 'Концентрация':['Бдительность','Воля','Меткость','Выживание'],
    'Интеллект':['Анализ','Эрудиция','Память','Медицина','Механика'], 'Харизма':['Убеждение','Обман','Интуиция','Запугивание','Очарование']
  };
  const GROUP_TRAIT = {'Сила':'Сильный','Ловкость':'Ловкий','Выносливость':'Выносливый','Концентрация':'Бдительный','Интеллект':'Умный','Харизма':'Обаятельный'};
  const ALL_SKILLS = Object.values(SKILL_GROUPS).flat();
  function skillGroup(skillName) { return Object.entries(SKILL_GROUPS).find(([,list]) => list.includes(skillName))?.[0] || null; }
  function equippedInventoryItem(st, slot) {
    const value = st?.equipment?.[slot]; if (!value) return null;
    const inventory = Array.isArray(st?.inventory) ? st.inventory : [];
    return inventory.find(item => [item?.uid,item?.id,item?.name].filter(Boolean).map(String).includes(String(value))) || null;
  }
  function gasProtectionForToken(token) {
    const host=actionHost(token);if(!host)return{protected:false,source:null};
    const armorProfile=canonicalArmorProfileAlias(armorProfileForHost(host)||'');
    if(armorProfile==='Тяжёлый экзоскелет')return{protected:true,source:'Тяжёлый экзоскелет'};
    const mask=equippedInventoryItem(host,'gasMask');
    if(mask&&/противогаз/i.test(String(mask.name||'')))return{protected:true,source:'Противогаз'};
    return{protected:false,source:null};
  }
  function effectIsGasHazard(effect){return Boolean(effect?.gasHazard)||['gas','toxin'].includes(effect?.type);}
  function traumaItemKey(item) { const name=canonicalTraumaName(item?.name);const variant=traumaItemVariant(item);return variant?`${name}:${variant}`:name; }
  function injurySuppressed(st, name) { const canonical=canonicalTraumaName(name);return Array.isArray(st?.activeEffects) && st.activeEffects.some(effect => effect?.suppressedInjury === name || effect?.suppressedInjury === canonical); }
  function injuryItemSuppressed(st,item){if(!Array.isArray(st?.activeEffects))return false;const key=traumaItemKey(item),canonical=canonicalTraumaName(item?.name);return st.activeEffects.some(effect=>effect?.suppressedInjuryKey===key||(!effect?.suppressedInjuryKey&&(effect?.suppressedInjury===item?.name||effect?.suppressedInjury===canonical)));}
  function activeTraumas(st) {
    return (Array.isArray(st?.injuries)?st.injuries:[]).filter(item=>item?.name&&!injuryItemSuppressed(st,item));
  }
  function hasTrauma(st,name,variant=null) {
    const canonical=canonicalTraumaName(name);
    return activeTraumas(st).some(item=>canonicalTraumaName(item.name)===canonical&&(!variant||traumaItemVariant(item)===variant));
  }
  function injurySkillPenalty(st, skillName) {
    const group = skillGroup(skillName), traumas=activeTraumas(st), names = new Set(traumas.map(item => canonicalTraumaName(item.name)));
    let value = 0; const parts = [];
    const add = (amount, label) => { value += amount; parts.push({label,value:amount}); };
    if (names.has('Перелом черепа') && group === 'Концентрация') add(-4,'Перелом черепа');
    if (names.has('Трещина в ребре') && group === 'Выносливость') add(-3,'Трещина в ребре');
    if (names.has('Выбитое плечо') && group === 'Сила') add(-2,'Выбитое плечо');
    if (names.has('Сломанная рука') && ['Сила','Ловкость'].includes(group)) add(-2,'Сломанная рука');
    if (names.has('Рваная рана')) add(-2,'Рваная рана');
    if (names.has('Повреждённый глаз') && skillName === 'Меткость') add(-3,'Повреждённый глаз');
    if (names.has('Разрыв сухожилия') && group === 'Ловкость') add(-3,'Разрыв сухожилия');
    if (names.has('Кровоизлияние в лёгкие') && group === 'Выносливость') add(-3,'Кровоизлияние в лёгкие');
    for(const item of traumas){const variant=traumaItemVariant(item),scale=traumaItemPenaltyScale(item);if(variant==='arm'&&['Физическая сила','Взлом','Механика','Медицина'].includes(skillName))add(-4*scale,`Потеря руки${traumaItemProsthesis(item)?' (протез)':''}`);if(variant==='fingers'&&['Физическая сила','Взлом','Механика','Медицина'].includes(skillName))add(-2*scale,`Потеря пальцев${traumaItemProsthesis(item)?' (протез)':''}`);}
    return { value, parts };
  }
  function injuryHitPenalty(st, weapon = null) {
    let value=0;
    if(hasTrauma(st,'Выбитое плечо'))value-=2;
    // Повреждённый глаз мешает именно стрельбе, но не встречному броску ближнего боя.
    if(!weapon?.melee&&hasTrauma(st,'Повреждённый глаз'))value-=3;
    // Рваная рана уже входит в проверку навыка ближнего боя; для готового стрелкового
    // бонуса и упрощённого боевого бонуса NPC её нужно учитывать отдельно.
    if(!weapon?.melee&&hasTrauma(st,'Рваная рана'))value-=2;
    return value;
  }
  function injuryRangePenalty(st) { return hasTrauma(st,'Повреждённый глаз') ? 30 : 0; }
  function weaponIsTwoHanded(weapon) { return /двуруч|тяж[её]лое оружие|древков|винтовк|карабин|дробовик|пулем[её]т|гранатом[её]т|лук|арбалет/i.test(weaponText(weapon)); }
  function lostLimbTrauma(st,variant){return activeTraumas(st).find(item=>traumaItemVariant(item)===variant)||null;}
  function hasLostLimb(st,variant){return Boolean(lostLimbTrauma(st,variant));}
  function traumaBlocksWeapon(st,weapon) { return weaponIsTwoHanded(weapon)&&(hasTrauma(st,'Сломанная рука')||hasLostLimb(st,'arm')); }
  function activeSkillBonus(st, skillName) {
    let value=0; const parts=[];
    for (const effect of (Array.isArray(st?.activeEffects)?st.activeEffects:[])) {
      const amount = Math.round(safeNumber(effect?.skillBonuses?.[skillName],0));
      if (amount) { value += amount; parts.push({label:effect.title||effect.name||'Активный эффект',value:amount}); }
    }
    return {value,parts};
  }
  function equipmentSkillBonus(st, skillName) {
    let value=0; const parts=[];
    const armor=equippedArmorForCharacter(st),profile=armor?.profile||'';
    const armorMod=armorSkillModifierForProfile(profile,skillName);
    if(armorMod){value+=armorMod;parts.push({label:profile,value:armorMod});}
    // The Heavy Exoskeleton's +1 Strength is contextual (lifting/carrying/holding
    // heavy objects), so it is intentionally not applied to every Strength roll.
    return {value,parts};
  }
  function baseSkillComponents(st, skillName) {
    const group=skillGroup(skillName), traitName=GROUP_TRAIT[group], level=Math.max(0,Math.round(safeNumber(st?.traits?.main?.[traitName],0)));
    const traitBonus=[2,4,5].filter(x=>level>=x).length + (traitName==='Бдительный'&&level>=5&&['Бдительность','Выживание'].includes(skillName)?1:0);
    const manual=Math.round(safeNumber(st?.skills?.[skillName]?.bonus,0));
    const option = nationSkillOptions?.[st?.nation]?.[st?.nationSkillChoice];
    const nation=Array.isArray(option)&&option.includes(skillName)?1:0;
    return {group,traitName,level,traitBonus,manual,nation};
  }
  function skillCubeForState(st, skillName, level) {
    const orders=[4,6,8,10,12]; let index=level===0?0:level<=2?1:level<=4?2:3;
    if (st?.skills?.[skillName]?.prof) index=Math.min(index+1,orders.length-1);
    return normalizeDie(st?.skills?.[skillName]?.customCube,`1d${orders[index]}`);
  }
  function characterSkillProfileDetailed(character, skillName, combatContext=false) {
    const st=character?.state||{}, base=baseSkillComponents(st,skillName), equipment=equipmentSkillBonus(st,skillName), injury=injurySkillPenalty(st,skillName), active=activeSkillBonus(st,skillName);
    let passive=0; const passiveParts=[];
    const rawBase = base.traitBonus+base.manual+base.nation+equipment.value+injury.value+active.value;
    const strong=Math.round(safeNumber(st?.traits?.main?.['Сильный'],0)), enduring=Math.round(safeNumber(st?.traits?.main?.['Выносливый'],0)), charming=Math.round(safeNumber(st?.traits?.main?.['Обаятельный'],0));
    if (strong>=3 && ['Убеждение','Очарование','Запугивание'].includes(skillName)) { const p=baseSkillComponents(st,'Физическая сила'),eq=equipmentSkillBonus(st,'Физическая сила'),inj=injurySkillPenalty(st,'Физическая сила'),act=activeSkillBonus(st,'Физическая сила'); const amount=Math.ceil((p.traitBonus+p.manual+p.nation+eq.value+inj.value+act.value)/2); passive+=amount;passiveParts.push({label:'Право сильного',value:amount}); }
    if (charming>=3 && ['Очарование','Убеждение'].includes(skillName)) { passive+=charming;passiveParts.push({label:'Оратор',value:charming}); }
    if (enduring>=6 && ['Физическая сила','Акробатика'].includes(skillName)) { const p=baseSkillComponents(st,'Выдержка'),eq=equipmentSkillBonus(st,'Выдержка'),inj=injurySkillPenalty(st,'Выдержка'),act=activeSkillBonus(st,'Выдержка'); const amount=Math.floor((p.traitBonus+p.manual+p.nation+eq.value+inj.value+act.value)/2); passive+=amount;passiveParts.push({label:'Атлет',value:amount}); }
    let situational=0; const situationalParts=[];
    const wounds=st.wounds||{},tough=Math.max(0,Math.round(safeNumber(st?.traits?.bonus?.['Крепкий'],0)));
    if (Number(wounds.serious||0)>0) { const armorProfile=equippedArmorForCharacter(st)?.profile||'',penalty=tough>=3?-1:armorSeriousPenaltyForProfile(armorProfile);situational+=penalty;situationalParts.push({label:tough>=3?'Крепкий 3 — Серьёзное ранение':armorProfile==='Стабилизирующая тяжёлая броня'?'Серьёзное ранение — стабилизирующая броня':'Серьёзное ранение',value:penalty}); }
    if (combatContext&&Number(wounds.medium||0)>0&&tough>=2){situational-=1;situationalParts.push({label:'Крепкий 2 — Среднее ранение',value:-1});}
    if (safeNumber(st?.morale?.current,1)<=0&&!st?._battlemapActions?.ignoreZeroMoralePenalty) { situational-=3;situationalParts.push({label:'Мораль 0',value:-3}); }
    if (st?.werewolf?.aftereffects && ['Физическая сила','Акробатика','Выдержка'].includes(skillName)) {situational-=1;situationalParts.push({label:'Последствия звериной формы',value:-1});}
    const advantages=[], hindrances=[];
    if (base.traitName==='Ловкий'&&base.level>=5&&['Скрытность','Взлом'].includes(skillName))advantages.push('Ловкий 5');
    if (base.traitName==='Умный'&&base.level>=5&&skillName==='Анализ')advantages.push('Умный 5');
    if (combatContext&&Number(wounds.medium||0)>0&&tough<2)hindrances.push('Среднее ранение: боевая проверка');
    const total=rawBase+passive+situational;
    return {name:skillName,cube:skillCubeForState(st,skillName,base.level),bonus:total,group:base.group,advantages,hindrances,criticalBlocked:Boolean(wounds.critical&&!st?.medical?.dead),breakdown:[
      {label:`Основная черта «${base.traitName||'—'}»`,value:base.traitBonus},{label:'Бонус навыка',value:base.manual},{label:'Путь происхождения',value:base.nation},...equipment.parts,...injury.parts,...active.parts,...passiveParts,...situationalParts
    ].filter(item=>item.value)};
  }
  const SKILL_TEXT_FORMS={
    'Физическая сила':['физическая сила','физической силы','физической силе','физическую силу'],
    'Взлом':['взлом','взлома','взлому'],
    'Акробатика':['акробатика','акробатики','акробатике','акробатику'],
    'Скрытность':['скрытность','скрытности'],
    'Выдержка':['выдержка','выдержки','выдержке','выдержку'],
    'Стойкость':['стойкость','стойкости'],
    'Иммунитет':['иммунитет','иммунитета','иммунитету'],
    'Бдительность':['бдительность','бдительности'],
    'Воля':['воля','воли','воле','волю'],
    'Меткость':['меткость','меткости'],
    'Выживание':['выживание','выживания','выживанию'],
    'Анализ':['анализ','анализа','анализу'],
    'Эрудиция':['эрудиция','эрудиции','эрудицию'],
    'Память':['память','памяти'],
    'Медицина':['медицина','медицины','медицине','медицину'],
    'Механика':['механика','механики','механике','механику'],
    'Убеждение':['убеждение','убеждения','убеждению'],
    'Обман':['обман','обмана','обману'],
    'Интуиция':['интуиция','интуиции','интуицию'],
    'Запугивание':['запугивание','запугивания','запугиванию'],
    'Очарование':['очарование','очарования','очарованию']
  };
  function textMentionsSkill(text,skillName){
    const source=String(text||'').toLocaleLowerCase('ru-RU').replace(/ё/g,'е'),forms=SKILL_TEXT_FORMS[skillName]||[String(skillName||'').toLocaleLowerCase('ru-RU')];
    return forms.some(form=>source.includes(String(form).replace(/ё/g,'е')));
  }
  function catalogOptionFor(st, kind, id) {
    if (kind==='specialization') return specializationCatalog.get(id) || (Array.isArray(st?.customSpecializations)?st.customSpecializations.find(x=>x?.id===id):null);
    if (kind==='doctrine') return doctrineCatalog.get(id) || (Array.isArray(st?.customDoctrines)?st.customDoctrines.find(x=>x?.id===id):null);
    return characterTraitCatalog.get(id) || (Array.isArray(st?.customCharacterTraits)?st.customCharacterTraits.find(x=>x?.id===id):null);
  }
  function rollOptionsForCharacter(character, skillName, scene=findScene(state?.activeSceneId)) {
    const st=ensureSpeciesRuntime(character?.state||{})||{}, result=[];
    const add=(kind,id)=>{const data=catalogOptionFor(st,kind,id);if(!data)return;const text=String(kind==='characterTrait'?(data.support||data.effect||''):(data.effect||data.support||''));const name=data.name||id,frequency=String(data.frequency||(/1\s+раз\s+за\s+бой/i.test(text)?'1 раз за бой':'1 раз за сцену')),listedSkills=Array.isArray(data.skills)?data.skills:[],relevant=listedSkills.length?listedSkills.includes(skillName):(textMentionsSkill(text,skillName)||/любой проверк|первой проверк|подходящ(?:ей|ую) проверк/i.test(text));const entry={key:`${kind}:${id}`,kind,sourceId:id,name,text,frequency},mechanic=optionMechanic(entry),reactionOnly=Boolean(mechanic.reroll||mechanic.afterFailure||mechanic.afterRoll||mechanic.extraDie);result.push({id:entry.key,...entry,core:kind==='doctrine'&&st.coreDoctrine===id,relevant,used:featureUsedForHost(st,scene,entry),reactionOnly});};
    const speciesOption=(id,name,text,skills,frequency='по ситуации')=>result.push({id:`species:${id}`,kind:'species',sourceId:id,name,text,frequency,relevant:skills.includes(skillName)});
    for(const id of (Array.isArray(st.specializations)?st.specializations:[]))add('specialization',id);
    for(const id of (Array.isArray(st.doctrines)?st.doctrines:[]))add('doctrine',id);
    for(const id of (Array.isArray(st.characterTraits)?st.characterTraits:[]))add('characterTrait',id);
    for(const entry of bonusTraitFeatureEntries(character)){
      if(!Array.isArray(entry.rollSkills)||!entry.rollSkills.includes(skillName))continue;
      result.push({id:entry.key,...entry,kindLabel:featureKindLabel(entry.kind),relevant:true,used:featureUsedForHost(st,scene,entry),reactionOnly:false});
    }
    if(st.species==='pallid'){
      speciesOption('pallid-immunity','Паллидская природа','Преимущество на Иммунитет против естественных болезней, ядов, токсинов и испорченных припасов.',['Иммунитет']);
      if(st.pallid.memoryUsed && (st.activeEffects||[]).some(effect=>effect?.source==='pallidMemory')) speciesOption('pallid-memory','Память прожитых жизней','Преимущество на одну проверку Памяти или Эрудиции, связанную с прошлым паллида.',['Память','Эрудиция'],'1 раз за сцену');
      if(st.pallid.transformed){
        speciesOption('pallid-power','Сверхъестественная мощь','Преимущество на Физическую силу, Акробатику или Выдержку при беге, прыжке, удержании тяжести и продолжительной нагрузке.',['Физическая сила','Акробатика','Выдержка']);
        speciesOption('pallid-terror','Чудовищный облик','Преимущество на Запугивание, когда вид Формы Вечного способен повлиять на цель.',['Запугивание']);
        speciesOption('pallid-charm-hindrance','Чудовищный облик: помеха','Помеха на Очарование, направленное на доверие, симпатию или ощущение безопасности.',['Очарование']);
      }
    }
    if(st.species==='werewolf'){
      speciesOption('werewolf-senses','Звериные чувства','Преимущество на Бдительность по слуху или запаху, Выживание при выслеживании живой цели или Интуицию для распознавания страха, ярости и паники.',['Бдительность','Выживание','Интуиция']);
      speciesOption('werewolf-immunity','Заражённый организм','Преимущество на Иммунитет против естественных инфекций, заражения ран, испорченной пищи и обычных паразитов.',['Иммунитет']);
      if(st.werewolf.transformed) speciesOption('werewolf-power','Звериная мощь','Преимущество на Физическую силу, Акробатику, Выдержку при преследовании или Выживание при выслеживании живой цели.',['Физическая сила','Акробатика','Выдержка','Выживание']);
    }
    if(st.species==='rokurokubi' && st.rokurokubi.neckExtended && (st.activeEffects||[]).some(effect=>effect?.source==='rokurokubiPerception')) speciesOption('rokurokubi-perception','Дистанционное восприятие','Преимущество на Бдительность, когда вынесенная вперёд голова действительно помогает наблюдению.',['Бдительность']);
    result.push(...armorContextualSkillOptions(equippedArmorForCharacter(st)?.profile||'',skillName));
    return result;
  }
  function optionMechanic(option) {
    const text=String(option?.text||''),dice=additiveDiceFromText(text).filter(item=>item.kind==='check'),die=dice[0]||null,flat=/\+\s*(\d+)\s+к\s+(?:ближайшей\s+)?провер/i.exec(text);
    const reroll=/(?:после\s+(?:провал|неудач)[^.!]{0,140}?переброс|перебросьте\s+(?:её|проверку)|перебросить\s+неудач)/i.test(text);
    const afterRoll=/после\s+броска|можно\s+применить\s+после\s+броска/i.test(text);
    return {extraDie:die?.sides||0,afterFailure:Boolean(die?.afterFailure),afterRoll,flat:flat?Number(flat[1]):0,advantage:/преимуществ/i.test(text),hindrance:/помех/i.test(text),reroll,rerollPenalty:/второй результат получает\s*[−-]1/i.test(text)?-1:0};
  }
  function combineCondition(manual, advantages, hindrances) {
    let score=(manual==='advantage'?1:manual==='hindrance'?-1:0)+(advantages.length?1:0)-(hindrances.length?1:0);
    return score>0?'advantage':score<0?'hindrance':'normal';
  }
  function rollManualExtraDice(value) {
    const raw=Array.isArray(value)?value:[],result=[];
    for(const item of raw){const sides=Number(typeof item==='object'&&item?item.sides:item);if(![4,6,8,10,12].includes(sides))continue;const count=typeof item==='object'&&item?clamp(Math.round(safeNumber(item.count,1)),1,10):1;for(let i=0;i<count&&result.length<20;i++)result.push({name:'Произвольный куб',die:`1d${sides}`,roll:rollOne(sides),manual:true});if(result.length>=20)break;}
    return result;
  }
  function makeMapSkillRoll(body, token, character, profile, options) {
    assertTokenCanAct(token);
    const chosenIds=new Set(Array.isArray(body.optionIds)?body.optionIds.map(String):[]), chosenAll=options.filter(opt=>chosenIds.has(opt.id)),scene=findScene(cleanId(body.sceneId,state?.activeSceneId));
    if(chosenAll.some(opt=>opt.reactionOnly))throw Object.assign(new Error('Эта особенность применяется после броска через кнопку рядом со счётчиком результата.'),{statusCode:409});
    const chosen=chosenAll.filter(opt=>!opt.reactionOnly),chosenFeatures=chosen.filter(opt=>!['species','equipment'].includes(opt.kind));
    if(chosenFeatures.length>1)throw Object.assign(new Error('К одной проверке можно применить прямой эффект только одной Специализации, Доктрины, Черты характера или Бонусной черты.'),{statusCode:409});
    if(chosenFeatures.some(opt=>opt.used))throw Object.assign(new Error('Выбранная особенность уже использована в текущем бою.'),{statusCode:409});
    const pendingCheck=peekFeatureEffect(token,'nextCheck'),pendingIsReaction=Boolean(pendingCheck&&(pendingCheck.reroll||pendingCheck.afterFailure||pendingCheck.afterRoll));
    if(pendingCheck&&!pendingIsReaction&&chosenFeatures.length)throw Object.assign(new Error('К проверке уже подготовлен эффект другой особенности. Используйте только один прямой источник бонуса.'),{statusCode:409});
    const consumedPendingCheck=pendingCheck&&!pendingIsReaction?consumeFeatureEffect(token,'nextCheck'):null;
    const narrative=consumeNarrative(token,'check');
    const optionMechanics=chosen.map(option=>({option,mechanic:optionMechanic(option)}));
    const manualExtraRolls=rollManualExtraDice(body.extraDice),advantages=[...profile.advantages],hindrances=[...profile.hindrances];let flat=manualExtraRolls.reduce((sum,item)=>sum+item.roll,0);const extraRolls=[...manualExtraRolls],deferredExtra=[];
    const addExtraDie=(name,sides,afterFailure=false)=>{
      if(!sides)return;
      if(afterFailure){deferredExtra.push({name,sides});return;}
      const value=rollOne(sides);extraRolls.push({name,die:`1d${sides}`,roll:value});flat+=value;
    };
    if(consumedPendingCheck){
      if(consumedPendingCheck.condition==='advantage')advantages.push(consumedPendingCheck.sourceName||'Особенность');
      if(consumedPendingCheck.condition==='hindrance')hindrances.push(consumedPendingCheck.sourceName||'Особенность');
      flat+=Math.round(safeNumber(consumedPendingCheck.flat,0));
      addExtraDie(consumedPendingCheck.sourceName||'Особенность',consumedPendingCheck.extraDie,Boolean(consumedPendingCheck.afterFailure));
    }
    for(const item of optionMechanics){
      if(item.mechanic.advantage)advantages.push(item.option.name);
      if(item.mechanic.hindrance)hindrances.push(item.option.name);
      flat+=item.mechanic.flat;
      addExtraDie(item.option.name,item.mechanic.extraDie,item.mechanic.afterFailure);
    }
    if(narrative.condition==='advantage')advantages.push(`Мастер${narrative.note?`: ${narrative.note}`:''}`);if(narrative.condition==='hindrance')hindrances.push(`Мастер${narrative.note?`: ${narrative.note}`:''}`);
    flat+=narrative.bonus;
    const condition=combineCondition(body.condition,advantages,hindrances),successSides=dieSides(profile.cube,6);let successRoll=rollOne(successSides),successBonus=profile.bonus+flat,successTotal=successRoll+successBonus;
    const difficultyBase=normalizeDie(body.difficultyDie,'1d6'),diff=(()=>{const orders=[4,6,8,10,12];let sides=dieSides(difficultyBase,6),idx=orders.indexOf(sides);if(condition==='advantage'){if(sides===4){const rolls=[rollOne(4),rollOne(4)];return{die:'2d4',rolls,chosen:Math.min(...rolls)}}sides=orders[Math.max(0,idx-1)];}else if(condition==='hindrance'){if(sides===12){const rolls=[rollOne(12),rollOne(12)];return{die:'2d12',rolls,chosen:Math.max(...rolls)}}sides=orders[Math.min(orders.length-1,idx+1)];}const value=rollOne(sides);return{die:`1d${sides}`,rolls:[value],chosen:value};})();
    const difficultyModifier=Math.round(safeNumber(body.difficultyModifier,0)),difficultyTotal=diff.chosen+difficultyModifier;
    const baseSuccessTotal=successTotal;let margin=successTotal-difficultyTotal;
    if(margin<0&&deferredExtra.length){for(const item of deferredExtra){const value=rollOne(item.sides);extraRolls.push({name:item.name,die:`1d${item.sides}`,roll:value,afterFailure:true});flat+=value;}successBonus=profile.bonus+flat;successTotal=successRoll+successBonus;margin=successTotal-difficultyTotal;}
    let outcome=margin>=0?'success':margin>=-3?'edge':'failure',rerolled=null;
    const difficultySides=dieSides(diff.die,dieSides(difficultyBase,6));if(successRoll===diff.chosen&&successSides>difficultySides)outcome='critical-success';else if(successRoll===diff.chosen&&difficultySides>successSides)outcome='critical-failure';
    for(const option of chosenFeatures){const entry=characterFeatureEntries(character).find(item=>item.key===option.id);if(entry)markFeatureUsedForHost(character.state,scene,entry);}
    const extraFormula=extraRolls.map(item=>` + ${item.die}`).join(''),baseFormulaBonus=successBonus-extraRolls.reduce((sum,item)=>sum+item.roll,0),difficultyChoice=diff.die==='2d4'?' (лучший/меньший)':diff.die==='2d12'?' (худший/больший)':'',successFormula=rerolled?`${profile.cube} → ${profile.cube} (переброс, используется второй)`:`${profile.cube}`;
    return {id:makeId('roll'),at:nowIso(),actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),sceneId:body.sceneId||null,tokenId:token.id,characterId:character?.id||null,characterName:token.name,label:cleanText(body.label||`${token.name}: ${profile.name}`,200),visibility:body.visibility==='master'?'master':'public',kind:'check',skillName:profile.name,formula:`${successFormula}${extraFormula}${baseFormulaBonus?signedFormulaBonus(baseFormulaBonus):''} vs ${diff.die}${difficultyChoice}${difficultyModifier?signedFormulaBonus(difficultyModifier):''}`,rolls:[...(rerolled?[rerolled.first,rerolled.second]:[successRoll]),...extraRolls.map(item=>item.roll)],modifier:successBonus,total:successTotal,successDie:profile.cube,successRoll,successBonus,successTotal,baseSuccessTotal,difficultyDie:diff.die,difficultyRolls:diff.rolls,difficultyRoll:diff.chosen,difficultyModifier,difficultyTotal,condition,outcome,margin,breakdown:profile.breakdown,advantages,hindrances,chosenOptions:chosen.map(x=>({id:x.id,name:x.name,text:x.text})),pendingFeature:consumedPendingCheck,extraRolls,rerolled,reactionSafe:true,reactionExpiresAt:null,appliedReactionKeys:[]};
  }

  function failedCheckOutcome(roll){return ['failure','critical-failure'].includes(String(roll?.outcome||''));}
  function improvableCheckOutcome(roll){return failedCheckOutcome(roll)||String(roll?.outcome||'')==='edge';}
  function traitUsageState(st){if(!st)return{};if(!st._battlemapTraitUsage||typeof st._battlemapTraitUsage!=='object'||Array.isArray(st._battlemapTraitUsage))st._battlemapTraitUsage={};return st._battlemapTraitUsage;}
  function luckyRerollAvailable(character,scene=findScene(state.activeSceneId),minLevel=1){return luckyFortuneAvailable(character,scene,minLevel);}
  function checkReactionAlreadyApplied(roll,key){return new Set(Array.isArray(roll?.appliedReactionKeys)?roll.appliedReactionKeys:[]).has(key);}
  function checkHasDirectFeature(roll){return Boolean((roll?.chosenOptions||[]).some(option=>!/^(?:species|equipment):/i.test(String(option?.id||'')))||roll?.pendingFeature?.sourceKey||(roll?.appliedReactionKeys||[]).some(key=>String(key).startsWith('feature:')));}
  function reactionSourceCanSee(scene,source,target){if(!scene||!source||!target)return false;if(source.id===target.id)return true;const from=speciesCombatPoint(source),to=speciesCombatPoint(target);if(!source.vision||source.vision.enabled===false||scene.settings?.visionEnabled===false)return !lineBlocked(scene,from,to);return viewerCanSeePoint(scene,source,to);}
  function attackRollFromRecord(roll){return roll?.battlemapAttack&&typeof roll.battlemapAttack==='object'?roll.battlemapAttack:null;}
  function areaShiftFeatureForCharacter(character,scene){
    if(!character)return null;
    for(const entry of characterFeatureEntries(character)){
      if(featureUsedForHost(character.state,scene,entry))continue;
      const action=featureMechanics(entry).find(item=>item.slot==='areaShift'&&safeNumber(item.feet,0)>0);
      if(action)return{entry,action};
    }
    return null;
  }
  function reactionRollerTokenIds(roll){
    const attack=attackRollFromRecord(roll);if(!attack)return roll?.tokenId?[roll.tokenId]:[];
    if(String(attack.kind||'').startsWith('melee'))return [attack.attackerTokenId,attack.targetTokenId].filter(Boolean);
    return [attack.attackerTokenId].filter(Boolean);
  }
  function rollReactionFinalized(roll){return Boolean(roll?.resolutionFinal)||Boolean(roll?.resolutionExpired);}
  function addForesightReactionOptions(result,add,scene,roll,targetToken,part,req,requestUrl,body){
    if(!targetToken)return;
    for(const source of scene.tokens||[]){
      if(source.kind!=='character'||criticalState(source).dead||!canControlToken(source,req,requestUrl,body))continue;
      if(giftRankForToken(source,'Предвидение')<2)continue;
      const sourceState=linkedCharacter(source)?.state||{},runtime=ensureAberrationRuntime(sourceState);if(runtime?.lockedUntilDay||!reactionSourceCanSee(scene,source,targetToken))continue;
      const key=`aberration:foresight2:${source.id}:${part||'roll'}`;
      add({id:key,applyKey:key,kind:'reroll',rollPart:part||'check',rollTokenId:targetToken.id,label:`✧ Предвидение II${source.id===targetToken.id?'':` · ${source.name}`}${part==='defender'?' · защита':part==='attacker'?' · атака':part==='difficulty'?' · сложность':part==='check'?' · успех':''}`,shortEffect:'обязательный переброс',penalty:0,sourceTokenId:source.id,sourceName:source.name,gift:'Предвидение',rank:2,description:'После любого видимого броска заставить перебросить его; второй результат обязателен.'});
    }
  }
  function addMoraleBonusTraitReactionOptions(result,add,scene,roll,target,req,requestUrl,body){
    if(!target||String(roll?.scalarPurpose||'')!=='morale-loss'||safeNumber(roll.total,0)<=0)return;
    for(const source of scene.tokens||[]){
      if(source?.kind!=='character'||tokenUnableToReact(source)||tokensHostile(source,target)||!reactionSourceCanHear(scene,source,target,30)||!canControlToken(source,req,requestUrl,body))continue;
      const sourceCharacter=linkedCharacter(source),sourceState=sourceCharacter?.state||{},level=bonusTraitLevel(source,'Уверенный');
      if(level>=4&&!bonusAbilityUsed(sourceState,scene,'Уверенный:4','battle')){
        const key=`bonus:confident4:${source.id}`;
        add({id:key,applyKey:key,kind:'morale-reduce',sides:8,rollPart:'scalar',rollTokenId:target.id,label:`◆ Не падать духом${source.id===target.id?'':` · ${source.name}`}`,shortEffect:'уменьшить потерю морали на 1к8',sourceTokenId:source.id,sourceName:source.name,trait:'Уверенный',rank:4});
      }
      const morale=moraleHost(target),wouldZero=morale&&safeNumber(morale.current,0)>0&&safeNumber(morale.current,0)-Math.max(0,safeNumber(roll.total,0))<=0;
      if(level>=5&&source.id!==target.id&&wouldZero&&!bonusAbilityUsed(sourceState,scene,'Уверенный:5','battle')){
        const key=`bonus:confident5:${source.id}`;
        add({id:key,applyKey:key,kind:'morale-floor-one',rollPart:'scalar',rollTokenId:target.id,label:`◆ Не сломаться · ${source.name}`,shortEffect:'оставить мораль цели на 1',sourceTokenId:source.id,sourceName:source.name,trait:'Уверенный',rank:5});
      }
    }
  }
  function addSecondWindReactionOption(result,add,scene,roll,attack,req,requestUrl,body){
    if(!attack?.hit||safeNumber(attack.damage,0)<=0)return;
    const target=findToken(scene,cleanId(attack.damageTargetTokenId||attack.targetTokenId,null));
    if(!target||target.kind!=='character'||bonusTraitLevel(target,'Крепкий')<4||!canControlToken(target,req,requestUrl,body))return;
    const character=linkedCharacter(target),st=character?.state||{};
    if(bonusAbilityUsed(st,scene,'Крепкий:4','battle'))return;
    const key=`bonus:tough4:${target.id}`;
    add({id:key,applyKey:key,kind:'second-wind',rollPart:'defense',rollTokenId:target.id,label:'◆ Второе дыхание',shortEffect:'снизить одно некритическое ранение на ступень',sourceTokenId:target.id,sourceName:target.name,trait:'Крепкий',rank:4});
  }

  function checkRollReactionOptions(scene,roll,req,requestUrl,body={}){
    if(!scene||!roll||roll.reactionSafe!==true||roll.supersededBy||rollReactionFinalized(roll))return[];
    const result=[],applied=new Set(Array.isArray(roll.appliedReactionKeys)?roll.appliedReactionKeys:[]);const add=option=>{if(!option?.id||applied.has(option.applyKey||option.id)||result.some(item=>item.id===option.id))return;result.push(option);};
    const attack=attackRollFromRecord(roll);
    if(!attack){
      const roller=findToken(scene,cleanId(roll.tokenId,null));if(!roller)return[];
      if(roll.kind!=='check'){
        addMoraleBonusTraitReactionOptions(result,add,scene,roll,roller,req,requestUrl,body);
        // Универсальный одиночный куб не имеет понятия «провал» сам по себе.
        // Предвидение II по-прежнему может заставить перебросить видимый куб.
        addForesightReactionOptions(result,add,scene,roll,roller,'scalar',req,requestUrl,body);return result;
      }
      const rollerControlled=canControlToken(roller,req,requestUrl,body);
      if(rollerControlled&&roller.kind==='character'){
        const character=linkedCharacter(roller),failure=failedCheckOutcome(roll),improvable=improvableCheckOutcome(roll),featureBlocked=checkHasDirectFeature(roll);
        if(!featureBlocked&&(failure||improvable)){
          for(const option of rollOptionsForCharacter(character,roll.skillName,scene)){
            if(!option.relevant||option.used)continue;const mechanic=optionMechanic(option),base={sourceTokenId:roller.id,sourceName:roller.name,rollTokenId:roller.id,rollPart:'check',featureKey:option.id,featureName:option.name,frequency:option.frequency,description:option.text};
            if(failure&&mechanic.reroll)add({id:`feature:${option.id}:reroll`,applyKey:`feature:${option.id}`,kind:'reroll',label:`↻ ${option.name}`,shortEffect:mechanic.rerollPenalty?`переброс ${mechanic.rerollPenalty}`:'переброс',penalty:mechanic.rerollPenalty,...base});
            else if(mechanic.extraDie&&improvable)add({id:`feature:${option.id}:extra-${mechanic.extraDie}`,applyKey:`feature:${option.id}`,kind:'extra-die',label:`+1к${mechanic.extraDie} · ${option.name}`,shortEffect:`добавить 1к${mechanic.extraDie} к результату`,sides:mechanic.extraDie,...base});
          }
        }
        const pending=peekFeatureEffect(roller,'nextCheck');if(failure&&pending&&(pending.reroll||pending.afterFailure))add({id:`prepared:${pending.sourceKey||pending.sourceName||'reaction'}`,applyKey:`prepared:${pending.sourceKey||pending.sourceName||'reaction'}`,kind:pending.reroll?'reroll':'extra-die',rollPart:'check',rollTokenId:roller.id,label:pending.reroll?`↻ ${pending.sourceName||'Подготовленная особенность'}`:`+1к${pending.extraDie||4} · ${pending.sourceName||'Подготовленная особенность'}`,shortEffect:pending.reroll?'переброс':`добавить 1к${pending.extraDie||4}`,penalty:safeNumber(pending.rerollPenalty,0),sides:safeNumber(pending.extraDie,0),prepared:true,sourceTokenId:roller.id,sourceName:roller.name,featureKey:pending.sourceKey||null,featureName:pending.sourceName||'Подготовленная особенность'});
        if(failure&&luckyRerollAvailable(character,scene,1))add({id:`trait:lucky:${roller.id}:check`,applyKey:`trait:lucky:${roller.id}:fortune`,kind:'reroll',rollPart:'check',rollTokenId:roller.id,label:'☘ Второй шанс',shortEffect:'потратить Фортуну и перебросить',penalty:0,sourceTokenId:roller.id,sourceName:roller.name,trait:'Удачливый',luckyMode:'own',description:'Потратить 1 Фортуну и перебросить провал; второй результат обязателен.'});
        if(String(roll.outcome||'')==='edge'&&Math.abs(Math.round(safeNumber(roll.margin,0)))>=1&&Math.abs(Math.round(safeNumber(roll.margin,0)))<=3&&luckyFortuneAvailable(character,scene,5))add({id:`trait:lucky-edge:${roller.id}:check`,applyKey:`trait:lucky-edge:${roller.id}:fortune`,kind:'lucky-edge',rollPart:'check',rollTokenId:roller.id,label:'☘ На волосок',shortEffect:'смягчить Успех на грани на одну ступень',sourceTokenId:roller.id,sourceName:roller.name,trait:'Удачливый',rank:5});
      }
      addForesightReactionOptions(result,add,scene,roll,roller,'check',req,requestUrl,body);
      // В обычной проверке второй бросок принадлежит сложности; во встречной
      // проверке это реальный бросок защищающегося токена. Предвидение II
      // привязывается именно к тому, чей куб был брошен. Фиксированный порог
      // (например, Стойкость против уже определённого результата атаки) не
      // является броском и поэтому не получает кнопку переброса сложности.
      const difficultyRoller=findToken(scene,cleanId(roll.difficultyTokenId,null))||roller,difficultyIsRoll=/^\s*\d+d\d+/i.test(String(roll.difficultyDie||''));
      if(difficultyIsRoll){
        if(roll.opposed&&['success','critical-success'].includes(String(roll.outcome||''))&&difficultyRoller?.kind==='character'&&canControlToken(difficultyRoller,req,requestUrl,body)){
          const defenderCharacter=linkedCharacter(difficultyRoller);
          if(luckyRerollAvailable(defenderCharacter,scene,1))add({id:`trait:lucky:${difficultyRoller.id}:difficulty`,applyKey:`trait:lucky:${difficultyRoller.id}:fortune`,kind:'reroll',rollPart:'difficulty',rollTokenId:difficultyRoller.id,label:'☘ Второй шанс · встречная проверка',shortEffect:'потратить Фортуну и перебросить свой бросок',penalty:0,sourceTokenId:difficultyRoller.id,sourceName:difficultyRoller.name,trait:'Удачливый',luckyMode:'own',description:'Потратить 1 Фортуну и перебросить проигранную встречную проверку; второй результат обязателен.'});
        }
        addForesightReactionOptions(result,add,scene,roll,difficultyRoller,'difficulty',req,requestUrl,body);
      }
      return result;
    }
    const melee=String(attack.kind||'').startsWith('melee')&&attack.kind!=='melee-counter';
    const attacker=findToken(scene,cleanId(attack.attackerTokenId,null));if(!attacker)return[];
    if(melee){
      const defender=findToken(scene,cleanId(attack.targetTokenId,null));
      if(attacker.kind==='character'&&canControlToken(attacker,req,requestUrl,body)&&!attack.hit){const character=linkedCharacter(attacker);if(luckyRerollAvailable(character,scene,1))add({id:`trait:lucky:${attacker.id}:attacker`,applyKey:`trait:lucky:${attacker.id}:fortune`,kind:'reroll',rollPart:'attacker',rollTokenId:attacker.id,label:'☘ Второй шанс · атака',shortEffect:'потратить Фортуну и перебросить атаку',penalty:0,sourceTokenId:attacker.id,sourceName:attacker.name,trait:'Удачливый',luckyMode:'own'});}
      if(defender?.kind==='character'&&canControlToken(defender,req,requestUrl,body)&&attack.hit){const character=linkedCharacter(defender);if(luckyFortuneAvailable(character,scene,2))add({id:`trait:lucky:${defender.id}:defense`,applyKey:`trait:lucky:${defender.id}:fortune`,kind:'reroll',rollPart:'attacker',rollTokenId:attacker.id,label:'☘ Счастливый промах',shortEffect:'заставить атакующего перебросить атаку',penalty:0,sourceTokenId:defender.id,sourceName:defender.name,trait:'Удачливый',rank:2,luckyMode:'defense'});}
      addSecondWindReactionOption(result,add,scene,roll,attack,req,requestUrl,body);
      addForesightReactionOptions(result,add,scene,roll,attacker,'attacker',req,requestUrl,body);if(defender&&!attack.defenderDisabled)addForesightReactionOptions(result,add,scene,roll,defender,'defender',req,requestUrl,body);
      return result;
    }
    if(attacker.kind==='character'&&canControlToken(attacker,req,requestUrl,body)&&!attack.hit){const character=linkedCharacter(attacker);if(luckyRerollAvailable(character,scene,1))add({id:`trait:lucky:${attacker.id}:attack`,applyKey:`trait:lucky:${attacker.id}:fortune`,kind:'reroll',rollPart:'attack',rollTokenId:attacker.id,label:'☘ Второй шанс',shortEffect:'потратить Фортуну и перебросить атаку',penalty:0,sourceTokenId:attacker.id,sourceName:attacker.name,trait:'Удачливый',luckyMode:'own'});
      if(attack.kind==='area-attack'){
        const prepared=peekFeatureEffect(attacker,'areaShift'),feature=areaShiftFeatureForCharacter(character,scene);
        if(prepared?.feet)add({id:`prepared:area-shift:${prepared.sourceKey||prepared.sourceName||attacker.id}`,applyKey:`prepared:area-shift:${prepared.sourceKey||prepared.sourceName||attacker.id}`,kind:'area-shift',rollPart:'attack',rollTokenId:attacker.id,label:`◉ ${prepared.sourceName||'Коррекция точки'}`,shortEffect:`сместить точку до ${Math.round(safeNumber(prepared.feet,5))} фт`,feet:Math.max(0,safeNumber(prepared.feet,5)),sourceTokenId:attacker.id,sourceName:attacker.name,featureKey:prepared.sourceKey||null,featureName:prepared.sourceName||'Коррекция точки',prepared:true});
        else if(feature)add({id:`feature:${feature.entry.key}:area-shift`,applyKey:`feature:${feature.entry.key}`,kind:'area-shift',rollPart:'attack',rollTokenId:attacker.id,label:`◉ ${feature.entry.name}`,shortEffect:`сместить точку до ${Math.round(safeNumber(feature.action.feet,5))} фт`,feet:Math.max(0,safeNumber(feature.action.feet,5)),sourceTokenId:attacker.id,sourceName:attacker.name,featureKey:feature.entry.key,featureName:feature.entry.name,frequency:feature.entry.frequency,description:feature.entry.text});
      }
    }
    const rangedDefender=findToken(scene,cleanId(attack.damageTargetTokenId||attack.targetTokenId,null));
    if(attack.hit&&rangedDefender?.kind==='character'&&canControlToken(rangedDefender,req,requestUrl,body)){const character=linkedCharacter(rangedDefender);if(luckyFortuneAvailable(character,scene,2))add({id:`trait:lucky:${rangedDefender.id}:defense`,applyKey:`trait:lucky:${rangedDefender.id}:fortune`,kind:'reroll',rollPart:'attack',rollTokenId:attacker.id,label:'☘ Счастливый промах',shortEffect:'заставить атакующего перебросить атаку',penalty:0,sourceTokenId:rangedDefender.id,sourceName:rangedDefender.name,trait:'Удачливый',rank:2,luckyMode:'defense'});}
    addSecondWindReactionOption(result,add,scene,roll,attack,req,requestUrl,body);
    addForesightReactionOptions(result,add,scene,roll,attacker,'attack',req,requestUrl,body);
    return result;
  }
  function recalculateReactionCheck(roll){
    roll.successTotal=Math.round(safeNumber(roll.successRoll,0)+safeNumber(roll.successBonus,0));roll.total=roll.successTotal;roll.modifier=roll.successBonus;roll.margin=roll.successTotal-safeNumber(roll.difficultyTotal,0);roll.outcome=roll.margin>=0?'success':roll.opposed?'failure':roll.margin>=-3?'edge':'failure';const successSides=dieSides(roll.successDie,6),difficultySides=dieSides(roll.difficultyDie,6);if(roll.successRoll===roll.difficultyRoll&&successSides>difficultySides)roll.outcome='critical-success';else if(roll.successRoll===roll.difficultyRoll&&difficultySides>successSides)roll.outcome='critical-failure';return roll;
  }
  function rebuildReactionFormula(roll,reaction){
    const extras=Array.isArray(roll.extraRolls)?roll.extraRolls:[],extraSum=extras.reduce((sum,item)=>sum+Math.round(safeNumber(item?.roll,0)),0),baseBonus=Math.round(safeNumber(roll.successBonus,0)-extraSum),rerollDifficulty=reaction?.kind==='reroll'&&reaction?.rollPart==='difficulty',successBase=reaction?.kind==='reroll'&&!rerollDifficulty?`${roll.successDie} → ${roll.successDie} (переброс, используется второй)`:String(roll.successDie||'1d6'),extraFormula=extras.map(item=>` + ${item.die}`).join(''),difficultyChoice=String(roll.difficultyDie||'').startsWith('2d')?` (${roll.condition==='advantage'?'лучший/меньший':'худший/больший'})`:'',difficultyBase=rerollDifficulty?`${roll.difficultyDie} → ${roll.difficultyDie} (переброс, используется второй)`:String(roll.difficultyDie||'1d6');return `${successBase}${extraFormula}${baseBonus?signedFormulaBonus(baseBonus):''} vs ${difficultyBase}${difficultyChoice}${safeNumber(roll.difficultyModifier,0)?signedFormulaBonus(roll.difficultyModifier):''}`;
  }
  function outcomeTextForCheck(outcome){return({'success':'успех','failure':'провал','edge':'успех на грани','critical-success':'критический успех','critical-failure':'критический провал'})[outcome]||outcome;}
  function storeScalarRoll(scene,token,{body={},label='Бросок',sides=6,count=1,modifier=0,kind='scalar',visibility='public',purpose=null}={}){
    if(!scene||!token)return null;const die=Math.max(2,Math.round(safeNumber(sides,6))),diceCount=clamp(Math.round(safeNumber(count,1)),1,20),values=Array.from({length:diceCount},()=>rollOne(die)),base=values.reduce((sum,value)=>sum+value,0),mod=Math.round(safeNumber(modifier,0)),roll={id:makeId('roll'),at:nowIso(),actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,token.name||'Участник'),sceneId:scene.id,tokenId:token.id,characterId:linkedCharacter(token)?.id||null,characterName:token.name||'',label:cleanText(label,200),visibility:visibility==='master'?'master':'public',kind,formula:`${diceCount}d${die}${mod?signedFormulaBonus(mod):''}`,rolls:values,modifier:mod,total:base+mod,scalarSides:die,scalarCount:diceCount,scalarRoll:base,scalarModifier:mod,scalarPurpose:purpose||kind,reactionSafe:true,reactionExpiresAt:null,appliedReactionKeys:[]};const campaign=getCampaign();campaign.diceLog.push(roll);if(campaign.diceLog.length>200)campaign.diceLog.splice(0,campaign.diceLog.length-200);if(broadcastDice)broadcastDice(roll);return roll;
  }
  async function resolveScalarRoll(scene,token,options={}){
    const prepared={...options};
    if(String(prepared.purpose||prepared.kind||'')==='morale-loss'&&!prepared.presenceApplied){
      prepared.modifier=Math.round(safeNumber(prepared.modifier,0))-confidentPresenceReduction(scene,token);
      prepared.presenceApplied=true;
    }
    let roll=storeScalarRoll(scene,token,prepared);if(roll)roll=await awaitCheckRollResolution(scene,roll);
    const total=Math.round(safeNumber(roll?.total,0));
    return{roll,value:Math.round(safeNumber(roll?.scalarRoll,roll?.total)),values:Array.isArray(roll?.rolls)?[...roll.rolls]:[],total:String(prepared.purpose||prepared.kind||'')==='morale-loss'?Math.max(0,total):total};
  }

  function syncCheckFromReactionRoll(check,roll){
    if(!check||!roll)return check;
    check.successDie=roll.successDie||check.successDie;check.successRolls=Array.isArray(roll.rolls)?[...roll.rolls]:check.successRolls;check.successRoll=Math.round(safeNumber(roll.successRoll,check.successRoll));check.bonus=Math.round(safeNumber(roll.successBonus,check.bonus));check.successTotal=Math.round(safeNumber(roll.successTotal,check.successTotal));check.difficultyDie=roll.difficultyDie||check.difficultyDie;check.difficultyRolls=Array.isArray(roll.difficultyRolls)?[...roll.difficultyRolls]:check.difficultyRolls;check.difficultyRoll=Math.round(safeNumber(roll.difficultyRoll,check.difficultyRoll));check.difficultyModifier=Math.round(safeNumber(roll.difficultyModifier,check.difficultyModifier));check.difficultyTotal=Math.round(safeNumber(roll.difficultyTotal,check.difficultyTotal??check.difficultyRoll));check.condition=roll.condition||check.condition;check.outcome=roll.outcome||check.outcome;check.success=['success','critical-success'].includes(String(check.outcome||''));check.reactionRollId=roll.id;return check;
  }
  function checkRollPotentialReaction(scene,roll){
    if(!scene||!roll||attackRollFromRecord(roll)||roll.reactionSafe!==true||rollReactionFinalized(roll)||roll.supersededBy)return false;
    const fakeUrl=new URL('http://localhost/?master=1');try{return checkRollReactionOptions(scene,roll,{headers:{}},fakeUrl,{master:true,clientId:'__resolution__'}).length>0;}catch{return false;}
  }
  function finalizePendingRollResolution(scene,root,{broadcastNow=true}={}){
    const current=latestReactionRoll(root),rootId=current?.reactionRootId||root?.reactionRootId||root?.id||current?.id;
    if(!current)return root;
    current.resolutionPending=false;current.resolutionFinal=true;
    if(rootId)pendingRollResolutions.delete(rootId);
    if(broadcastNow&&broadcast)broadcast('battlemap-roll-finalized',null,{sceneId:scene?.id||current.sceneId||null,rollId:current.id,rootRollId:rootId||current.id});
    return current;
  }
  async function awaitCheckRollResolution(scene,roll){
    if(!checkRollPotentialReaction(scene,roll)){roll.resolutionFinal=true;roll.resolutionPending=false;return roll;}
    const rootId=roll.reactionRootId||roll.id,pending={rootId,currentRollId:roll.id,finalizeRequested:false};pendingRollResolutions.set(rootId,pending);roll.resolutionPending=true;roll.resolutionFinal=false;
    while(pendingRollResolutions.get(rootId)===pending&&!pending.finalizeRequested)await wait(80);
    if(pendingRollResolutions.get(rootId)!==pending)return latestReactionRoll(roll);
    return finalizePendingRollResolution(scene,roll);
  }

  function reactionPool(sides,mode){const values=mode===0?[rollOne(sides)]:[rollOne(sides),rollOne(sides)];const chosen=mode>0?Math.max(...values):mode<0?Math.min(...values):values[0];return{values,chosen};}
  function recalculateRangedReactionAttack(scene,attack){
    attack.total=Math.round(safeNumber(attack.roll,0)+safeNumber(attack.hitBonus,0));attack.margin=attack.total-safeNumber(attack.targetMz,0);attack.hit=attack.total>=safeNumber(attack.targetMz,0)&&!attack.forcedMissReason;
    const attacker=findToken(scene,attack.attackerTokenId),target=findToken(scene,attack.targetTokenId);let redirect=null;
    if(!attack.hit&&attack.targetInMelee&&attacker&&target){const participants=(attack.meleeParticipantTokenIds||[]).map(id=>findToken(scene,id)).filter(Boolean);redirect=chooseMeleeMissRecipient(speciesCombatPoint(attacker),speciesCombatPoint(target),participants);}
    attack.missRedirectTargetTokenId=redirect?.id||null;attack.missRedirectTargetName=redirect?.name||null;attack.damageTargetTokenId=attack.hit?attack.targetTokenId:(redirect?.id||null);attack.damageTargetName=attack.hit?attack.targetName:(redirect?.name||null);
    const mode=Math.round(safeNumber(attack.reactionRollMode,0)),featureDie=attack.featureEffects?.attack?.extraDie,measured=attack.measuredShot?[4]:[];attack.formula=attackFormulaText(attack.hitDie||attack.weapon?.hitDieNormal||'1d6',mode,featureDie,attack.baseHitBonus,`МЗ ${attack.targetMz}`,true,measured);attack.modifier=attack.hitBonus;return attack;
  }
  function recalculateMeleeReactionAttack(attack){
    attack.attackerTotal=Math.round(safeNumber(attack.attackerRoll,0)+safeNumber(attack.attackerBonus,0));attack.defenderTotal=Math.round(safeNumber(attack.defenderRoll,0)+safeNumber(attack.defenderBonus,0));attack.hit=attack.attackerTotal>attack.defenderTotal;attack.tie=attack.attackerTotal===attack.defenderTotal;attack.counterAvailable=!attack.defenderDisabled&&!attack.suppressCounter&&attack.defenderTotal>attack.attackerTotal;
    attack.counterCost=attack.counterAvailable?(/Тяж[её]лое двуручное|Громоздк/i.test(`${attack.defenderWeapon?.profile||''} ${attack.defenderWeapon?.description||''}`)?2:1):0;attack.counterExpiresAt=attack.counterAvailable?Date.now()+120000:null;
    if(attack.flags){attack.flags.stun=attack.specialMode==='stun'&&attack.hit;attack.flags.shock=attack.specialMode==='shock'&&attack.hit;attack.flags.knockdown=attack.specialMode==='takedown'&&attack.hit;attack.flags.wrapTarget=attack.weapon?.id==='rokurokubi-wrap'&&attack.hit;attack.flags.lycanthropyRisk=attack.weapon?.id==='werewolf-bite'&&attack.hit;}
    const baseOd=Math.max(0,safeNumber(attack.weapon?.odCost,2));attack.odCost=Math.max(0,baseOd+(attack.specialMode==='power'||(attack.specialMode==='stun'&&attack.hit)?1:0));attack.requiredOdCost=Math.max(0,baseOd+(attack.specialMode==='takedown'?1:(attack.specialMode==='power'||(attack.specialMode==='stun'&&attack.hit)?1:0)));
    const am=Math.round(safeNumber(attack.attackerRollMode,0)),dm=Math.round(safeNumber(attack.defenderRollMode,0));attack.formula=`${attackFormulaText(attack.weapon?.hitDieNormal||`1d${attack.attackerSides||4}`,am,attack.featureEffects?.attack?.extraDie,attack.attackerBaseBonus,'',true)}`.replace(/\s+vs\s*$/,'')+` vs ${rollSequenceFormula(attack.defenderWeapon?.hitDieNormal||`1d${attack.defenderSides||4}`,dm,true)}${signedFormulaBonus(attack.defenderBonus)?` ${signedFormulaBonus(attack.defenderBonus)}`:''}`;attack.modifier=attack.attackerBonus;return attack;
  }
  function applyAttackRerollReaction(scene,next,reaction){
    const attack=clone(next.battlemapAttack),part=reaction.rollPart||'attack';attack.id=next.id;attack.at=next.at;
    if(String(attack.kind||'').startsWith('melee')&&attack.kind!=='melee-counter'){
      if(part==='defender'){const pool=reactionPool(Math.max(2,Math.round(safeNumber(attack.defenderSides,dieSides(attack.defenderWeapon?.hitDieNormal,4)))),Math.round(safeNumber(attack.defenderRollMode,0)));attack.defenderRollValues=pool.values;attack.defenderRoll=pool.chosen;attack.reactionReroll={part,values:pool.values,chosen:pool.chosen};}
      else {const pool=reactionPool(Math.max(2,Math.round(safeNumber(attack.attackerSides,dieSides(attack.weapon?.hitDieNormal,4)))),Math.round(safeNumber(attack.attackerRollMode,0)));attack.attackerRollValues=pool.values;attack.attackerRoll=pool.chosen;attack.reactionReroll={part:'attacker',values:pool.values,chosen:pool.chosen};}
      recalculateMeleeReactionAttack(attack);next.total=attack.attackerTotal;next.modifier=attack.attackerBonus;next.rolls=[...(attack.attackerRollValues||[attack.attackerRoll]),...(attack.featureEffects?.attackRoll?[attack.featureEffects.attackRoll]:[]),...(attack.defenderRollValues||[attack.defenderRoll])];attack.rolls=[...next.rolls];
    }else{
      const pool=reactionPool(dieSides(attack.hitDie||attack.weapon?.hitDieNormal,6),Math.round(safeNumber(attack.reactionRollMode,0)));attack.attackRolls=pool.values;attack.roll=pool.chosen;attack.reactionReroll={part:'attack',values:pool.values,chosen:pool.chosen};recalculateRangedReactionAttack(scene,attack);next.total=attack.total;next.modifier=attack.hitBonus;next.rolls=[...pool.values,...(attack.measuredShot?[attack.measuredShot.roll]:[]),...(attack.featureEffects?.attackRoll?[attack.featureEffects.attackRoll]:[])];attack.rolls=[...next.rolls];
    }
    next.formula=attack.formula;next.battlemapAttack=attack;next.tokenId=attack.attackerTokenId;next.characterId=linkedCharacter(findToken(scene,attack.attackerTokenId))?.id||null;next.characterName=attack.attackerName;return next;
  }
  function applyLuckyOwnRerollBonus(scene,next,reaction){
    if(reaction?.trait!=='Удачливый'||reaction?.luckyMode!=='own')return 0;
    const source=findToken(scene,cleanId(reaction.sourceTokenId,null));if(source?.kind!=='character'||bonusTraitLevel(source,'Удачливый')<3)return 0;
    const value=rollOne(4),attack=attackRollFromRecord(next);
    if(attack){
      if(String(attack.kind||'').startsWith('melee')&&attack.kind!=='melee-counter'){
        attack.attackerBonus=Math.round(safeNumber(attack.attackerBonus,0)+value);attack.luckyRerollBonus=value;recalculateMeleeReactionAttack(attack);next.total=attack.attackerTotal;next.modifier=attack.attackerBonus;
      }else{
        attack.hitBonus=Math.round(safeNumber(attack.hitBonus,0)+value);attack.luckyRerollBonus=value;recalculateRangedReactionAttack(scene,attack);next.total=attack.total;next.modifier=attack.hitBonus;
      }
      attack.formula=`${attack.formula} + 1d4(${value}) [Удачный поворот]`;attack.rolls=[...(attack.rolls||[]),value];next.formula=attack.formula;next.rolls=[...(next.rolls||[]),value];next.battlemapAttack=attack;
    }else if(next.kind==='check'){
      next.extraRolls=Array.isArray(next.extraRolls)?next.extraRolls:[];next.extraRolls.push({name:'Удачный поворот',die:'1d4',roll:value,reaction:true,part:reaction.rollPart==='difficulty'?'difficulty':'success'});
      if(reaction.rollPart==='difficulty'){
        next.difficultyModifier=Math.round(safeNumber(next.difficultyModifier,0)+value);next.difficultyTotal=Math.round(safeNumber(next.difficultyRoll,0)+safeNumber(next.difficultyModifier,0));
      }else{
        next.successBonus=Math.round(safeNumber(next.successBonus,0)+value);
      }
      next.rolls=[Math.round(safeNumber(next.successRoll,0)),...next.extraRolls.map(item=>item.roll)];recalculateReactionCheck(next);next.formula=rebuildReactionFormula(next,reaction);
    }
    next.luckyRerollBonus=value;return value;
  }

  function attackRollPotentialReaction(scene,roll){
    if(!scene||!attackRollFromRecord(roll)||rollReactionFinalized(roll)||roll.supersededBy)return false;
    const fakeUrl=new URL('http://localhost/?master=1');
    try{return checkRollReactionOptions(scene,roll,{headers:{}},fakeUrl,{master:true,clientId:'__resolution__'}).length>0;}catch{return false;}
  }
  function latestReactionRoll(root){const campaign=getCampaign();let current=root,guard=0;while(current?.supersededBy&&guard++<20){const next=(campaign.diceLog||[]).find(item=>item?.id===current.supersededBy);if(!next)break;current=next;}return current||root;}
  function notePendingRollReaction(scene,next){
    const rootId=next.reactionRootId||next.reactionOf||next.id,pending=pendingRollResolutions.get(rootId),potential=attackRollFromRecord(next)?attackRollPotentialReaction(scene,next):checkRollPotentialReaction(scene,next);
    next.resolutionPending=Boolean(potential);next.resolutionFinal=!potential;
    if(!pending)return;
    pending.currentRollId=next.id;
    if(!potential)pending.finalizeRequested=true;
  }
  async function awaitAttackRollResolution(scene,roll){
    if(!attackRollPotentialReaction(scene,roll)){roll.resolutionFinal=true;roll.resolutionPending=false;return roll;}
    const rootId=roll.reactionRootId||roll.id,pending={rootId,currentRollId:roll.id,finalizeRequested:false};pendingRollResolutions.set(rootId,pending);roll.resolutionPending=true;roll.resolutionFinal=false;
    while(pendingRollResolutions.get(rootId)===pending&&!pending.finalizeRequested)await wait(80);
    if(pendingRollResolutions.get(rootId)!==pending)return latestReactionRoll(roll);
    return finalizePendingRollResolution(scene,roll);
  }

  function tokenFaction(token) {
    if (!token) return 'neutral';
    if (token.kind === 'character') return 'party';
    if (token.kind === 'npc') {
      const kind = linkedNpc(token)?.kind;
      if (kind === 'enemy') return 'enemy';
      if (kind === 'ally') return 'party';
    }
    return 'neutral';
  }
  function sceneContainingTokens(a,b) {
    return (state?.scenes||[]).find(scene => (scene.tokens||[]).some(token=>token.id===a?.id) && (scene.tokens||[]).some(token=>token.id===b?.id)) || null;
  }
  function tokenGroupRelation(a,b) {
    if(!a||!b)return null;
    const scene=sceneContainingTokens(a,b);if(!scene||!a.groupId||!b.groupId)return null;
    if(a.groupId===b.groupId)return 'ally';
    const ga=findGlobalTokenGroup(a.groupId),gb=findGlobalTokenGroup(b.groupId);
    const ab=ga?.relations?.[b.groupId],ba=gb?.relations?.[a.groupId];
    if(ab==='enemy'||ba==='enemy')return'enemy';
    if(ab==='ally'||ba==='ally')return'ally';
    if(ab==='neutral'||ba==='neutral')return'neutral';
    // Если оба токена уже распределены по группам, отсутствие явной связи
    // трактуется как нейтралитет. Старые фракции используются только для
    // токенов без групп — так интерфейс отношений и поведение ИИ не расходятся.
    return 'neutral';
  }
  function tokensHostile(a, b) {
    const relation=tokenGroupRelation(a,b);if(relation)return relation==='enemy';
    const fa=tokenFaction(a),fb=tokenFaction(b);
    return (fa==='party'&&fb==='enemy')||(fa==='enemy'&&fb==='party');
  }

  function weaponIsMelee(weapon) {
    if(!weapon)return false;
    const canonicalProfile=canonicalWeaponProfileAlias(weapon.profile,weapon.name);
    const text=weaponText(weapon);
    return Boolean(
      weapon.melee || weapon.category==='melee' || weapon.category==='natural' || weapon.naturalWeapon ||
      weapon.type==='Оружие ближнего боя' || weapon.id==='unarmed' ||
      CANONICAL_MELEE_PROFILES.has(String(weapon.profile||'')) || CANONICAL_MELEE_PROFILES.has(canonicalProfile) ||
      /оружие ближнего боя|ближн|рукопаш|безоруж|меч|нож|кинжал|мачете|кукри|сабл|тесак|клинок|дубин|булав|топор|молот|лопат|копь|алебард|багор|кастет|штык|приклад/i.test(text)
    );
  }
  function weaponIsRanged(weapon) { return Boolean(weapon&&!weaponIsMelee(weapon)&&safeNumber(weapon.range,0)>0&&safeNumber(weapon.radius,0)<=0); }
  function tokenUnableToReact(token) {
    if(!token)return true;
    const critical=criticalState(token);
    if(critical.dead||token.defeated&&!critical.critical)return true;
    if(critical.critical)return !critical.canAttack;
    if(token.kind==='npc'){const npc=linkedNpc(token)||{};return Boolean(npc.outOfCombat||npc.dead);}
    return !['character','npc'].includes(token.kind);
  }
  function tokenAcrobaticsBonus(token) {
    if(token?.kind==='character')return Math.round(safeNumber(characterSkillProfileDetailed(linkedCharacter(token),'Акробатика',true)?.bonus,0));
    if(token?.kind==='npc')return Math.round(safeNumber(linkedNpc(token)?.characteristics?.dexterity,0));
    return 0;
  }
  function hostileMeleeOpponents(scene, token, pointOverride=null) {
    if(!scene||!token||!['character','npc'].includes(token.kind))return [];
    const point=pointOverride||speciesCombatPoint(token),bodyPoint=Math.hypot(point.x-token.x,point.y-token.y)<.01;
    return (scene.tokens||[]).filter(other=>{
      if(!other||other.id===token.id||!['character','npc'].includes(other.kind)||tokenUnableToReact(other)||!tokensHostile(token,other))return false;
      const otherPoint=speciesCombatPoint(other),otherBody=Math.hypot(otherPoint.x-other.x,otherPoint.y-other.y)<.01;
      const distance=bodyPoint&&otherBody?contactDistanceFeet(scene,token,other):distanceFeet(scene,point,otherPoint);
      return distance<=Math.max(5,meleeReachFeet(scene,token,other))+.01&&!contactBlockedByWall(scene,point,otherPoint);
    });
  }
  function tokenEngagedInMelee(scene, token, pointOverride=null) { return hostileMeleeOpponents(scene,token,pointOverride).length>0; }
  function chooseMeleeMissRecipient(from,targetPoint,participants) {
    return [...(participants||[])].sort((a,b)=>{
      const ap=speciesCombatPoint(a),bp=speciesCombatPoint(b);
      const aline=pointSegmentDistance(ap,from,targetPoint),bline=pointSegmentDistance(bp,from,targetPoint);
      if(Math.abs(aline-bline)>.001)return aline-bline;
      return Math.hypot(ap.x-targetPoint.x,ap.y-targetPoint.y)-Math.hypot(bp.x-targetPoint.x,bp.y-targetPoint.y);
    })[0]||null;
  }
  function bestRangedReactionWeapon(scene, shooter, targetPoint) {
    // Zone-fire is a free reaction. It may use a loaded crossbow, but a bow must
    // already have been drawn with its 1-OD preparation action; the reaction
    // cannot silently perform a paid preparation for free.
    return weaponsForToken(shooter).filter(weaponIsRanged).filter(weapon=>weapon.loaded!==false).filter(weapon=>!weapon.specialRangedKind||specialRangedAmmoCount(shooter,weapon)>0).filter(weapon=>weapon.specialRangedKind!=='bow'||weapon.drawn===true).filter(weapon=>distanceFeet(scene,speciesCombatPoint(shooter),targetPoint)<=safeNumber(weapon.range,0)+.01).sort((a,b)=>(dieSides(b.hitDieNormal,4)+safeNumber(b.hitBonus,0)+safeNumber(b.damage,0))-(dieSides(a.hitDieNormal,4)+safeNumber(a.hitBonus,0)+safeNumber(a.damage,0)))[0]||null;
  }
  function combatRollRecord(scene, attacker, attack, skillName) {
    const campaign=getCampaign(),roll={id:attack.id,at:attack.at,actorId:attack.actorId,actorName:attack.actorName,sceneId:scene?.id||attack.sceneId||null,tokenId:attacker?.id||attack.attackerTokenId||null,characterId:linkedCharacter(attacker)?.id||null,characterName:attacker.name,formula:attack.formula,label:attack.label,rolls:attack.rolls||[],modifier:attack.modifier||0,total:attack.kind?.startsWith('melee')?attack.attackerTotal:attack.total,visibility:attack.visibility||'public',kind:'attack',skillName,battlemapAttack:attack,reactionSafe:attack.kind!=='melee-counter',reactionExpiresAt:null,appliedReactionKeys:[]};
    campaign.diceLog.push(roll);if(campaign.diceLog.length>200)campaign.diceLog.splice(0,campaign.diceLog.length-200);if(broadcastDice)broadcastDice(roll);return roll;
  }
  function reactionDamageText(result){if(!result)return'';if(result.blocked)return' Урон заблокирован.';return` Ранения: ${(result.applied||[]).join(', ')||'нет'}${result.moraleLoss?`; мораль −${result.moraleLoss}`:''}.`;}
  function targetPointForProjectile(scene, attack, fallbackTarget) {
    const redirected=attack?.damageTargetTokenId?findToken(scene,attack.damageTargetTokenId):null;
    const target=redirected||fallbackTarget;if(!target)return{x:0,y:0,elevation:0};
    const point=speciesCombatPoint(target);if(redirected||attack?.hit)return point;
    const seed=String(attack?.id||'miss').split('').reduce((sum,ch)=>(sum*33+ch.charCodeAt(0))>>>0,5381),angle=(seed%360)*Math.PI/180,distance=Math.max(12,safeNumber(scene?.grid?.size,70)*(.42+((seed>>>8)%30)/100));
    return {...point,x:point.x+Math.cos(angle)*distance,y:point.y+Math.sin(angle)*distance};
  }
  function projectileDurationMs(scene, from, to, weapon) {
    const feet=distanceFeet(scene,from,to),kind=projectileKindForWeapon(weapon);if(kind==='launcher')return clamp(520+feet*2.2,600,1500);return clamp(180+feet*.7,180,650);
  }

  async function executeOpportunityAttack(scene, striker, mover, moverPoint, body={}) {
    let attack=makeMeleeRoll({...body,clientId:null,playerName:striker.name,visibility:'public',specialMode:null},scene,striker,mover,{attackerPoint:speciesCombatPoint(striker),targetPoint:moverPoint,suppressCounter:true,freeAttack:true,kind:'melee-free',label:`${striker.name}: свободная атака → ${mover.name}`});
    attack.odCost=0;attack.requiredOdCost=0;attack.obCost=0;attack.reactionType='opportunity';let roll=combatRollRecord(scene,striker,attack,'Свободная атака');roll=await awaitAttackRollResolution(scene,roll);attack=roll.battlemapAttack;
    let damageResult=null;if(attack.hit)damageResult=await applyDamageToTarget(scene,mover,{clientId:null,playerName:striker.name,damage:attack.damage,damageTag:attack.damageTag,...attack.flags,melee:true,sourceText:`${attack.weapon?.profile||''} ${attack.weapon?.description||''}`},{persist:false,recordHistory:false,role:'system'});
    const entry=appendTableLog({type:'roll',actorId:null,actorName:striker.name,text:`${attack.label}: ${attackTotalBreakdown(attack,true)} против ${attack.defenderTotal} — ${attack.hit?'попадание':attack.tie?'ничья':'промах'}.${reactionDamageText(damageResult)}`,visibility:'public',sceneId:scene.id,tokenId:striker.id,meta:{attackId:attack.id,reaction:'opportunity',formulas:journalRollFormulas(attack.formula,damageResult)}});broadcastTableLog(entry);broadcastAudioEffect(scene.id,weaponSoundKey(attack.weapon,{melee:true,unarmed:Boolean(attack.flags?.unarmed)}),{tokenId:striker.id,x:striker.x,y:striker.y,targetTokenId:mover.id},body.clientId);
    return{type:'opportunity',attackerTokenId:striker.id,attackerName:striker.name,targetTokenId:mover.id,targetName:mover.name,attack,roll,entry,damageResult};
  }
  async function executeZoneFireAttack(scene, shooter, mover, targetPoint, weapon, body={}) {
    let attack=makeAttackRoll({...body,clientId:null,playerName:shooter.name,visibility:'public',weaponId:weapon.id||weapon.slot||weapon.name,shotMode:'normal',specialMode:null,targetMz:null,situationalModifier:0,moved:false},scene,shooter,mover,{attackOrigin:speciesCombatPoint(shooter),targetPoint,skipEngagedAttackerCheck:true,ignoreNearOriginCover:true,reactionType:'zone-fire',label:`${shooter.name}: Зона обстрела → ${mover.name}`});
    attack.odCost=0;attack.obCost=0;let roll=combatRollRecord(scene,shooter,attack,'Зона обстрела');roll=await awaitAttackRollResolution(scene,roll);attack=roll.battlemapAttack;finalizePristrelkaAttack(scene,shooter,mover,attack);markHeavyWeaponFired(shooter,attack.weapon);markSpecialRangedFired(shooter,attack.weapon);
    broadcastProjectileEffect(scene.id,{id:attack.id,kind:projectileKindForWeapon(attack.weapon),from:speciesCombatPoint(shooter),to:targetPointForProjectile(scene,attack,mover),durationMs:projectileDurationMs(scene,speciesCombatPoint(shooter),targetPointForProjectile(scene,attack,mover),attack.weapon),hit:Boolean(attack.damageTargetTokenId),label:attack.weapon?.name},body.clientId);
    const damageTarget=attack.damageTargetTokenId?findToken(scene,attack.damageTargetTokenId):null;let damageResult=null;
    if(damageTarget)damageResult=await applyDamageToTarget(scene,damageTarget,{clientId:null,playerName:shooter.name,damage:attack.damage,damageTag:attack.damageTag,...attack.flags,sourceText:`${attack.weapon?.profile||''} ${attack.weapon?.description||''}`},{persist:false,recordHistory:false,role:'system'});
    const onHitEffect=damageTarget?await applyDirectWeaponOnHitEffects(scene,shooter,damageTarget,attack.weapon,{...body,clientId:null,playerName:shooter.name}):null;
    const redirect=attack.missRedirectTargetName?` Промах по ${mover.name}; попадание в ${attack.missRedirectTargetName}.`:'';const onHitText=onHitEffect?.moraleLoss?` Анаксионный импульс: мораль −${onHitEffect.moraleLoss}.`:onHitEffect?.burningZone?' Создана зона горения.':'';
    const reactionFormulas=[...journalRollFormulas(attack.formula,damageResult),...(onHitEffect?.moraleRoll?[`Анаксионный пистолет: 1d4 морали = ${onHitEffect.moraleRoll.total}`]:[])];
    const entry=appendTableLog({type:'roll',actorId:null,actorName:shooter.name,text:`${attack.label}: ${attack.total} против МЗ ${attack.targetMz} — ${attack.hit?'попадание':'промах'}.${redirect}${reactionDamageText(damageResult)}${onHitText}`,visibility:'public',sceneId:scene.id,tokenId:shooter.id,meta:{attackId:attack.id,reaction:'zone-fire',formulas:reactionFormulas}});broadcastTableLog(entry);broadcastAudioEffect(scene.id,weaponSoundKey(attack.weapon),{tokenId:shooter.id,x:shooter.x,y:shooter.y,targetTokenId:mover.id},body.clientId);
    return{type:'zone-fire',attackerTokenId:shooter.id,attackerName:shooter.name,targetTokenId:mover.id,targetName:mover.name,attack,roll,entry,damageResult,onHitEffect};
  }

  function stealthHidesTokenLocation(token,scene){
    const rt=stealthRuntime(token,false);return Boolean(rt?.active&&rt.hideFromPlayers&&isStealthed(token));
  }
  function counterSniperReactionAffordable(scene,token,cost){
    cost=Math.max(1,Math.round(safeNumber(cost,1)));const info=tokenOd(token);if(!info)return false;
    return isCurrentCombatToken(scene,token)?info.current>=cost:info.max-tokenFutureOdDebt(token)>=cost;
  }
  async function executeCounterSniperAttack(scene,observer,triggerShooter,observation,triggerAttack,body={}){
    const weapon=weaponsForToken(observer).find(item=>String(item.id||item.slot||item.name)===String(observation.weaponId||''));
    const rifle=rifleProfileForWeapon(weapon);if(!weapon||!rifle||rifle.proficiency<rifle.effectiveThreshold)return null;
    const from=speciesCombatPoint(observer),to=speciesCombatPoint(triggerShooter),distance=distanceFeet(scene,from,to),cost=Math.max(1,Math.round(safeNumber(weapon.odCost,2)));
    if(distance<=30.001||distance>safeNumber(weapon.range,0)+.001||contactBlockedByWall(scene,from,to)||counterSniperSmokeBlock(scene,from,to)||!counterSniperReactionAffordable(scene,observer,cost))return null;
    let attack=makeAttackRoll({clientId:null,playerName:observer.name,weaponId:weapon.id||weapon.slot||weapon.name,shotMode:'measured',specialMode:null,targetMz:null,situationalModifier:0,moved:false,visibility:(stealthHidesTokenLocation(observer,scene)||stealthHidesTokenLocation(triggerShooter,scene))?'master':'public'},scene,observer,triggerShooter,{reactionType:'counter-sniper',allowStealthTarget:true,label:`${observer.name}: Контрснайперский выстрел → ${triggerShooter.name}`});
    const payment=spendSniperReactionCost(scene,observer,cost);
    observation.used=true;delete tokenActions(observer).counterSniperObservation;
    // The reaction uses every Measured Shot bonus but pays only the rifle's
    // ordinary attack cost from the nearest turn, as specified by the rule.
    attack.kind='counter-sniper';attack.counterSniper=true;attack.triggerAttackId=triggerAttack?.id||null;attack.counterSniperDebtCost=cost;attack.counterSniperPayment=payment;attack.standardMeasuredOdCost=attack.odCost;attack.odCost=0;attack.obCost=0;
    let roll=combatRollRecord(scene,observer,attack,'Контрснайперский выстрел');roll=await awaitAttackRollResolution(scene,roll);attack=roll.battlemapAttack;finalizePristrelkaAttack(scene,observer,triggerShooter,attack);
    const position=recordMeasuredShotPosition(scene,observer);attack.sniperPosition=position;
    const hiddenLocation=stealthHidesTokenLocation(observer,scene)||stealthHidesTokenLocation(triggerShooter,scene);
    if(!hiddenLocation)broadcastProjectileEffect(scene.id,{id:attack.id,kind:projectileKindForWeapon(weapon),from,to:targetPointForProjectile(scene,attack,triggerShooter),durationMs:projectileDurationMs(scene,from,to,weapon),hit:Boolean(attack.damageTargetTokenId),label:weapon.name},body.clientId);
    const damageTarget=attack.damageTargetTokenId?findToken(scene,attack.damageTargetTokenId):null;let damageResult=null;
    if(damageTarget)damageResult=damageTarget.kind==='vehicle'?await applyDamageToVehicle(scene,damageTarget,{damage:attack.damage,damageTag:attack.damageTag},{persistNow:false}):await applyDamageToTarget(scene,damageTarget,{clientId:null,playerName:observer.name,damage:attack.damage,damageTag:attack.damageTag,...attack.flags,sourceText:weaponText(weapon)},{persist:false,recordHistory:false,role:'system'});
    const entry=appendTableLog({type:'roll',actorId:null,actorName:hiddenLocation?'Контрснайпер':observer.name,text:hiddenLocation?`Контрснайперская реакция по скрытой огневой точке: ${attackTotalBreakdown(attack,false)} против МЗ ${attack.targetMz} — ${attack.hit?'попадание':'промах'}.`:`${attack.label}: ${attackTotalBreakdown(attack,false)} против МЗ ${attack.targetMz} — ${attack.hit?'попадание':'промах'}.${reactionDamageText(damageResult)}`,visibility:hiddenLocation?'master':'public',sceneId:scene.id,tokenId:hiddenLocation?null:observer.id,meta:{attackId:attack.id,reaction:'counter-sniper',triggerAttackId:triggerAttack?.id||null,formulas:journalRollFormulas(attack.formula,damageResult)}});broadcastTableLog(entry);
    broadcastAudioEffect(scene.id,weaponSoundKey(weapon),hiddenLocation?{}:{tokenId:observer.id,x:observer.x,y:observer.y,targetTokenId:triggerShooter.id},body.clientId);
    return{type:'counter-sniper',attackerTokenId:observer.id,attackerName:observer.name,targetTokenId:triggerShooter.id,targetName:triggerShooter.name,attack,roll,entry,damageResult,position};
  }
  async function resolveCounterSniperReactions(scene,triggerShooter,triggerAttack,body={}){
    if(!scene||!triggerShooter||triggerAttack?.shotMode!=='measured'||triggerAttack?.reactionType==='counter-sniper')return[];
    const reactions=[];
    for(const observer of scene.tokens||[]){
      if(!observer||observer.id===triggerShooter.id||!['character','npc'].includes(observer.kind)||!state.combat?.participantTokenIds?.includes(observer.id)||!tokensHostile(observer,triggerShooter)||tokenUnableToReact(observer))continue;
      const observation=counterSniperObservation(observer,scene);if(!observation)continue;
      try{const reaction=await executeCounterSniperAttack(scene,observer,triggerShooter,observation,triggerAttack,body);if(reaction)reactions.push(reaction);}
      catch(error){console.warn(`Counter-sniper reaction skipped for ${observer.name}:`,error?.message||error);}
    }
    return reactions;
  }

  function pointInsideTriggerZone(zone,point){return rectContainsPoint(zone,point);}
  function directWound(token,type='light'){
    const host=actionHost(token);if(!host)return false;host.wounds=host.wounds&&typeof host.wounds==='object'?host.wounds:{};
    if(token?.kind==='character'){ensureCharacterMedicalState(host);const scene=findScene(state.activeSceneId);return addCharacterWoundWithBonus(scene,token,host.wounds,type,host.medical,{})!==null;}
    return addWoundWithOverflow(host.wounds,type,host)!==null;
  }
  function healOneWound(token){const host=actionHost(token);if(!host?.wounds)return false;for(const key of ['critical','serious','medium','light']){if(safeNumber(host.wounds[key],0)>0){host.wounds[key]=Math.max(0,Math.round(host.wounds[key])-1);return true;}}return false;}
  function traumaVariantLabel(variant){return({arm:'рука',leg:'нога',fingers:'пальцы'})[variant]||'рука';}
  function activeStatBonusFromEffects(st,key){return (Array.isArray(st?.activeEffects)?st.activeEffects:[]).reduce((sum,effect)=>sum+safeNumber(effect?.statBonuses?.[key]??effect?.[key],0),0);}
  function recalculateCharacterAfterTrauma(character) {
    const st=character?.state;if(!st)return;
    ensureCharacterMedicalState(st);st.traits ||= {start:{},main:{},bonus:{}};st.traits.start ||= {};st.traits.main ||= {};st.traits.bonus ||= {};
    const injuryMods={odPenalty:hasTrauma(st,'Трещина в ребре')?1:0,speedMod:(hasTrauma(st,'Повреждённое колено')?-10:0)+(hasTrauma(st,'Разрыв сухожилия')?-5:0)};
    const level=Math.max(1,Math.round(safeNumber(st.level,1))),oldOdCurrent=safeNumber(st.odCurrent,st.od||0);
    st.od=Math.max(0,(level<=4?3:level<=9?4:5)-injuryMods.odPenalty);st.odCurrent=clamp(oldOdCurrent,0,st.od);
    const armorProfile=equippedArmorForCharacter(st)?.profile||'',speed=30+(safeNumber(st.traits.main['Ловкий'],0)>=5?5:0)+armorSpeedPenaltyForProfile(armorProfile)+safeNumber(st.speedBonus,0)+activeStatBonusFromEffects(st,'speedBonus')+injuryMods.speedMod;
    st.speed=Math.max(0,speed);{const lostLeg=lostLimbTrauma(st,'leg');if(lostLeg){const cap=traumaItemProsthesis(lostLeg)?15+Math.max(0,st.speed-15)/2:15;st.speed=Math.min(st.speed,cap);}}
    // Базовая мораль использует обычный модификатор Воли. Штраф Перелома черепа к
    // проверкам Концентрации не вычитается второй раз: для морали у травмы есть отдельные −5.
    const willBase=baseSkillComponents(st,'Воля'),willEquipment=equipmentSkillBonus(st,'Воля'),willActive=activeSkillBonus(st,'Воля');
    const will=Math.round(willBase.traitBonus+willBase.manual+willBase.nation+willEquipment.value+willActive.value),brave=safeNumber(st.traits.start['Храбрый'],0);
    const braveBonus=(brave>=1?10:0)+(brave>=2?15:0)+(brave>=3?20:0),moralePenalty=(hasTrauma(st,'Перелом черепа')?5:0)+(hasTrauma(st,'Кровоизлияние в лёгкие')?2:0);
    st.morale.base=Math.max(0,10+braveBonus+will-moralePenalty);st.morale.max=st.morale.base;st.morale.current=clamp(safeNumber(st.morale.current,0),0,st.morale.max);
  }
  function applyNpcTraumaStatChanges(npc,name,variant) {
    if(name==='Трещина в ребре'){npc.od=npc.od&&typeof npc.od==='object'?npc.od:{current:3,max:3};npc.od.max=Math.max(0,safeNumber(npc.od.max,3)-1);npc.od.current=Math.min(safeNumber(npc.od.current,npc.od.max),npc.od.max);}
    if(name==='Повреждённое колено')npc.speed=Math.max(0,safeNumber(npc.speed,30)-10);
    if(name==='Разрыв сухожилия')npc.speed=Math.max(0,safeNumber(npc.speed,30)-5);
    if(name==='Потеря конечности'&&variant==='leg')npc.speed=Math.min(safeNumber(npc.speed,30),15);
    if(name==='Перелом черепа'||name==='Кровоизлияние в лёгкие'){const loss=name==='Перелом черепа'?5:2;npc.morale=npc.morale&&typeof npc.morale==='object'?npc.morale:{current:0,max:0};npc.morale.max=Math.max(0,safeNumber(npc.morale.max,0)-loss);npc.morale.current=Math.min(safeNumber(npc.morale.current,0),npc.morale.max);}
  }
  function addCanonicalTrauma(token,zone) {
    const host=actionHost(token),rawName=zone.traumaName||zone.traumaText,name=canonicalTraumaName(rawName),def=TRAUMA_DEFINITIONS[name],variant=name==='Потеря конечности'?canonicalTraumaVariant(rawName,zone.traumaVariant):null;
    if(!host||!def)return{applied:0,name:null,variant:null};
    host.injuries=Array.isArray(host.injuries)?host.injuries:[];
    const duplicate=host.injuries.some(item=>item?.name===name&&(name!=='Потеря конечности'||(item.variant||'arm')===variant));
    if(duplicate)return{applied:0,name,variant,duplicate:true};
    const variantSuffix=variant?` Выбран вариант: ${traumaVariantLabel(variant)}.`:'';
    host.injuries.unshift({name,roll:def.roll,variant,desc:`${def.desc}${variantSuffix}`,source:`trigger:${zone.id}`,createdAt:nowIso()});
    if(token.kind==='character'){const character=linkedCharacter(token);recalculateCharacterAfterTrauma(character);character.revision=Math.max(0,Number(character.revision||0))+1;character.updatedAt=nowIso();}
    else if(token.kind==='npc')applyNpcTraumaStatChanges(linkedNpc(token),name,variant);
    return{applied:1,name,variant,desc:def.desc};
  }

  async function beginTriggeredCombat(scene, enteringToken, zone, body={}) {
    if(state.combat?.active)return{started:false,reason:'combat-active',participantCount:state.combat.participantTokenIds?.length||0};
    const ids=[...new Set([enteringToken?.id,...(zone.combatTokenIds||[])].map(value=>cleanId(value,null)).filter(Boolean))];
    const seenNpcRefs=new Set(),clonedNpcIds=[];
    for(const tokenId of ids){const candidate=findToken(scene,tokenId);if(!candidate||candidate.kind!=='npc'||!candidate.refId)continue;if(seenNpcRefs.has(candidate.refId)){const npc=cloneNpcSheetForToken(candidate);if(npc)clonedNpcIds.push(npc.id);}seenNpcRefs.add(candidate.refId);}
    const linked=new Set(),items=ids.map(tokenId=>({token:findToken(scene,tokenId)})).filter(item=>{
      if(!item.token||!['character','npc'].includes(item.token.kind)||item.token.defeated||tokenIsDead(item.token)||!item.token.refId)return false;
      const key=`${item.token.kind}:${item.token.refId}`;if(linked.has(key))return false;linked.add(key);return true;
    });
    if(!items.length)return{started:false,reason:'no-participants',participantCount:0};
    const campaign=getCampaign();campaign.initiative={round:1,currentIndex:0,entries:await rollCombatInitiativeWithReactions(scene,items,body)};
    for(const item of items){clearCombatRuntimeForToken(item.token);resetTurnResources(item.token);}
    // Автоматический запуск боя на триггере не должен переключать публичную сцену.
    // Если триггер сработал у игроков, activeSceneId уже указывает на их сцену; если мастер
    // готовит скрытую сцену, она остаётся скрытой до явного «Показать игрокам».
    state.combat={active:true,sceneId:scene.id,participantTokenIds:items.map(item=>item.token.id),startedAt:nowIso(),movement:Object.fromEntries(items.map(item=>[item.token.id,{spent:0,opportunityAttackers:[],zoneFireShooters:[]}]))};
    if(broadcastCampaignReplaced)broadcastCampaignReplaced(body.clientId,'trigger-zone-combat-start');
    broadcast('battlemap-replaced',body.clientId,{reason:'trigger-zone-combat-started',sceneId:scene.id,zoneId:zone.id});
    broadcastAudioEffect(scene.id,'ui.combatStart',{},body.clientId);
    return{started:true,participantCount:items.length,clonedNpcCount:clonedNpcIds.length,initiativeFormulas:initiativeFormulaLines(scene,campaign.initiative.entries)};
  }
  async function applyTriggerZoneEffect(scene,token,zone,check,body={}){
    const combatMode=zone.effectType==='start-combat'?(zone.combatTriggerMode==='check'?'check':'automatic'):null;
    const should=zone.effectType==='start-combat'?(token?.kind==='character'&&(combatMode==='automatic'||(combatMode==='check'&&check&&!check.success))):zone.applyWhen==='always'||(zone.applyWhen==='success'&&check?.success)||(zone.applyWhen==='failure'&&!check?.success);if(!should||zone.effectType==='none')return null;
    const host=actionHost(token),value=Math.max(0,Math.round(safeNumber(zone.effectValue,1)));if(!host)return null;let applied=0,trauma=null,combat=null;
    if(zone.effectType==='wound'){for(let i=0;i<Math.max(1,value);i++)if(directWound(token,zone.woundType))applied++;}
    else if(zone.effectType==='heal'){for(let i=0;i<Math.max(1,value);i++)if(healOneWound(token))applied++;}
    else if(zone.effectType==='morale-loss'||zone.effectType==='morale-gain'){host.morale=host.morale&&typeof host.morale==='object'?host.morale:{current:0,max:0};const before=Math.round(safeNumber(host.morale.current,0)),delta=zone.effectType==='morale-loss'?-value:value,maximum=Math.max(0,safeNumber(host.morale.max,999));host.morale.current=clamp(before+delta,0,maximum||999);applied=Math.abs(host.morale.current-before);}
    else if(zone.effectType==='trauma'){trauma=addCanonicalTrauma(token,zone);applied=trauma.applied;}
    else if(zone.effectType==='start-combat'){combat=await beginTriggeredCombat(scene,token,zone,body);applied=combat.started?combat.participantCount:0;}
    return{type:zone.effectType,value,woundType:zone.woundType,traumaName:zone.traumaName,traumaVariant:zone.traumaVariant,trauma,combat,applied};
  }
  function runAnyTokenSkillCheck(token,skillName,difficultySides,difficultyModifier=0,options={}){
    if(token.kind==='character'){const check=runSkillAgainstDifficulty(token,skillName,difficultySides,{combatContext:true,advantage:Boolean(options.advantage),hindrance:Boolean(options.hindrance)});if(!check)return null;check.difficultyModifier=Math.round(safeNumber(difficultyModifier,0));check.difficultyTotal=check.difficultyRoll+check.difficultyModifier;check.success=check.successTotal>=check.difficultyTotal;check.outcome=check.success?'success':'failure';if(check.successRoll===check.difficultyRoll&&dieSides(check.successDie,6)>check.difficultySides)check.outcome='critical-success';else if(check.successRoll===check.difficultyRoll&&check.difficultySides>dieSides(check.successDie,6))check.outcome='critical-failure';return check;}
    const npc=linkedNpc(token);if(!npc)return null;const map={'Физическая сила':'strength','Акробатика':'dexterity','Скрытность':'dexterity','Взлом':'dexterity','Выдержка':'endurance','Стойкость':'endurance','Иммунитет':'endurance','Бдительность':'concentration','Воля':'concentration','Меткость':'concentration','Выживание':'concentration','Анализ':'intelligence','Эрудиция':'intelligence','Память':'intelligence','Медицина':'intelligence','Механика':'intelligence','Убеждение':'charisma','Обман':'charisma','Интуиция':'charisma','Запугивание':'charisma','Очарование':'charisma'};const sides=dieSides(npc.successDie||'1d6',6),armorProfile=normalizedNpcArmor(npc).profile,serious=safeNumber(npc?.wounds?.serious,0)>0?armorSeriousPenaltyForProfile(armorProfile):0,armorMod=armorSkillModifierForProfile(armorProfile,skillName),bonus=Math.round(safeNumber(npc.characteristics?.[map[skillName]||'concentration'],0)+injurySkillPenalty(npc,skillName).value+serious+armorMod),roll=rollOne(sides),difficultyRoll=rollOne(difficultySides),difficultyTotal=difficultyRoll+Math.round(safeNumber(difficultyModifier,0)),total=roll+bonus,success=total>=difficultyTotal;let outcome=success?'success':'failure';if(roll===difficultyRoll&&sides>difficultySides)outcome='critical-success';else if(roll===difficultyRoll&&difficultySides>sides)outcome='critical-failure';return{skillName,success,successDie:`1d${sides}`,successRolls:[roll],successRoll:roll,bonus,successTotal:total,difficultyDie:`1d${difficultySides}`,difficultySides,difficultyRolls:[difficultyRoll],difficultyRoll,difficultyModifier,difficultyTotal,condition:'normal',outcome,advantages:[],hindrances:[]};
  }
  async function resolveCombatStealthCheck(scene,token,body={},options={}){
    const rt=stealthRuntime(token,true),difficultySides=[4,6,8,10,12].includes(Number(options.difficultySides))?Number(options.difficultySides):Math.max(4,Math.round(safeNumber(rt.difficultySides,6))),difficultyModifier=Math.round(safeNumber(options.difficultyModifier,rt.difficultyModifier||0));
    rt.difficultySides=difficultySides;rt.difficultyModifier=difficultyModifier;
    if(Object.prototype.hasOwnProperty.call(options,'hideFromPlayers'))rt.hideFromPlayers=Boolean(options.hideFromPlayers);
    const check=runAnyTokenSkillCheck(token,'Скрытность',difficultySides,difficultyModifier);
    if(!check)throw Object.assign(new Error('Не удалось провести проверку Скрытности.'),{statusCode:409});
    const suppressorBoost=tokenActions(token)?.weaponModStealthBonus,modStealthBonus=Math.max(0,Math.round(safeNumber(suppressorBoost?.bonus,0)));
    if(modStealthBonus){
      check.bonus=Math.round(safeNumber(check.bonus,0)+modStealthBonus);check.successTotal=Math.round(safeNumber(check.successTotal,0)+modStealthBonus);check.success=check.successTotal>=check.difficultyTotal;
      check.outcome=check.success?'success':'failure';if(check.successRoll===check.difficultyRoll&&dieSides(check.successDie,6)>check.difficultySides)check.outcome='critical-success';else if(check.successRoll===check.difficultyRoll&&check.difficultySides>dieSides(check.successDie,6))check.outcome='critical-failure';
      check.weaponModStealthBonus=modStealthBonus;delete tokenActions(token).weaponModStealthBonus;
    }
    let roll=storeSpeciesCheckRoll(scene,token,check,body,options.label||`${token.name}: Скрытность`,{reactionSafe:true});
    if(roll){roll=await awaitCheckRollResolution(scene,roll);syncCheckFromReactionRoll(check,roll);}
    rt.active=Boolean(check.success);rt.grantedWithoutCheck=false;rt.lastCheckAt=nowIso();rt.lastOutcome=check.outcome|| (check.success?'success':'failure');rt.lastSuccessTotal=check.successTotal;rt.lastDifficultyTotal=check.difficultyTotal;
    if(!rt.active)rt.revealedAt=nowIso();else delete rt.revealedAt;
    const entry=appendTableLog({type:'roll',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,token.name),text:`${token.name}: Скрытность против 1к${difficultySides}${difficultyModifier?`${difficultyModifier>0?'+':''}${difficultyModifier}`:''}${modStealthBonus?` · Глушитель +${modStealthBonus}`:''} — ${check.success?'успех, персонаж остаётся скрытым':'провал, Скрытность снята'}.`,sceneId:scene.id,tokenId:token.id,meta:{formulas:journalRollFormulas(roll?.formula)}});
    broadcastTableLog(entry);
    return {check,roll,entry,stealth:{active:rt.active,difficultySides,difficultyModifier,hideFromPlayers:Boolean(rt.hideFromPlayers)}};
  }
  async function resolveStealthAtTurnEnd(scene,token,body={}){
    const rt=stealthRuntime(token,false);if(!rt?.active)return null;
    const critical=criticalState(token);if(critical.dead||token.defeated){rt.active=false;rt.lastOutcome='ended';return {ended:true,reason:'unable'};}
    // Скрытность, назначенная мастером без проверки, является ручным состоянием:
    // она не создаёт автоматических бросков в конце хода и снимается мастером.
    if(rt.grantedWithoutCheck)return {held:true,grantedWithoutCheck:true};
    return resolveCombatStealthCheck(scene,token,{...body,playerName:token.name},{difficultySides:rt.difficultySides,difficultyModifier:rt.difficultyModifier,hideFromPlayers:rt.hideFromPlayers,label:`${token.name}: удержание Скрытности`});
  }

  async function resolveForcedCheckZones(scene,token,oldPoint,nextPoint,body={}){
    const results=[],removeIds=new Set();
    for(const zone of scene?.triggerZones||[]){
      zone.insideTokenIds=Array.isArray(zone.insideTokenIds)?zone.insideTokenIds:[];const inside=pointInsideTriggerZone(zone,nextPoint),tracked=zone.insideTokenIds.includes(token.id);
      if(!inside){zone.insideTokenIds=zone.insideTokenIds.filter(id=>id!==token.id);continue;}if(tracked)continue;
      const combatZone=zone.effectType==='start-combat',combatMode=zone.combatTriggerMode==='check'?'check':'automatic';
      // Зоны старта боя реагируют только на персонажей игроков. NPC могут свободно
      // находиться внутри такой зоны и не запускают ни бой, ни лишние броски.
      if(combatZone&&token.kind!=='character')continue;
      zone.insideTokenIds.push(token.id);
      let check=null,roll=null,effect=null;
      if(combatZone&&combatMode==='automatic'){
        effect=await applyTriggerZoneEffect(scene,token,zone,null,body);
      }else{
        check=runAnyTokenSkillCheck(token,zone.skillName,zone.difficultySides,zone.difficultyModifier);if(!check)continue;
        // Любая отображаемая проверка сначала публикует исходный результат и
        // ждёт пост-бросковые реакции. Эффект триггер-зоны применяется только
        // после фиксации окончательного результата.
        roll=storeSpeciesCheckRoll(scene,token,check,body,`${token.name}: ${zone.name} — ${zone.skillName}`,{reactionSafe:true});
        if(roll){roll=await awaitCheckRollResolution(scene,roll);syncCheckFromReactionRoll(check,roll);}
        effect=await applyTriggerZoneEffect(scene,token,zone,check,body);
      }
      const effectText=effect?`; эффект применён после итогового результата: ${effect.type}${effect.applied!==undefined?` (${effect.applied})`:''}`:'';
      const text=combatZone&&combatMode==='automatic'?`${token.name} входит в «${zone.name}»: бой начинается автоматически, без проверки${effectText}.`:`${token.name} входит в «${zone.name}»: ${zone.skillName} — ${check?.success?'успех':'провал'}${effectText}.`;
      const triggerFormulas=[];if(roll?.formula)triggerFormulas.push(roll.formula);if(effect?.combat?.initiativeFormulas)triggerFormulas.push(...effect.combat.initiativeFormulas);const entry=appendTableLog({type:check?'roll':'action',actorId:cleanId(body.clientId,null),actorName:token.name,text,sceneId:scene.id,tokenId:token.id,meta:{formulas:triggerFormulas}});broadcastTableLog(entry);
      if(zone.pauseOnTrigger)state.masterPause={active:true,reason:`Сработала зона «${zone.name}»`,activatedAt:nowIso()};if(zone.oneShot)removeIds.add(zone.id);
      results.push({zoneId:zone.id,zoneName:zone.name,combatTriggerMode:combatZone?combatMode:null,check,roll,effect,pause:Boolean(zone.pauseOnTrigger),oneShot:Boolean(zone.oneShot)});
    }
    if(removeIds.size)scene.triggerZones=(scene.triggerZones||[]).filter(zone=>!removeIds.has(zone.id));return results;
  }

  async function resolveMovementReactions(scene, mover, oldPoint, nextPoint, body={}) {
    if(!state.combat?.active||state.combat.sceneId!==scene?.id||!state.combat.participantTokenIds?.includes(mover.id)||!['character','npc'].includes(mover.kind))return[];
    if(body.ignoreReactions===true)return[];
    const actions=tokenActions(mover),record=movementRecord(mover),reactions=[];
    const safeMove=Math.max(0,safeNumber(actions.aberrantSafeMoveFeet,0));if(safeMove>0){const moved=distanceFeet(scene,oldPoint,nextPoint);actions.aberrantSafeMoveFeet=Math.max(0,safeMove-moved);if(actions.aberrantSafeMoveFeet<=.01)delete actions.aberrantSafeMoveFeet;}
    const oldOpponents=hostileMeleeOpponents(scene,mover,oldPoint),newIds=new Set(hostileMeleeOpponents(scene,mover,nextPoint).map(item=>item.id));
    const leaving=oldOpponents.filter(item=>!newIds.has(item.id));
    // Отход защищает от ВСЕХ свободных атак, пока действие активно. Ранее он
    // удалялся после первого покинутого противника, из-за чего второй/третий
    // противник мог провести атаку по возможности в рамках того же перемещения.
    if(leaving.length&&actions.retreat){/* действие остаётся активно до конца хода/ручного снятия */}
    else if(leaving.length&&safeMove<=0){
      const striker=leaving.filter(item=>!item.hidden&&!record.opportunityAttackers.includes(item.id)).sort((a,b)=>distanceFeet(scene,a,oldPoint)-distanceFeet(scene,b,oldPoint))[0];
      if(striker){record.opportunityAttackers.push(striker.id);const choice=await askCombatReaction(scene,striker,mover,'opportunity');if(choice==='attack')reactions.push(await executeOpportunityAttack(scene,striker,mover,oldPoint,body));}
    }
    if(!actions.crossing&&!actions.charge&&!body.ignoreZoneFire){
      for(const shooter of (scene.tokens||[])){
        if(!shooter||shooter.hidden||shooter.id===mover.id||!state.combat.participantTokenIds.includes(shooter.id)||!tokensHostile(shooter,mover)||tokenUnableToReact(shooter)||record.zoneFireShooters.includes(shooter.id)||tokenEngagedInMelee(scene,shooter))continue;
        if(shooter.kind==='npc'&&isStealthed(mover))continue;
        const weapon=bestRangedReactionWeapon(scene,shooter,nextPoint);if(!weapon)continue;
        const origin=speciesCombatPoint(shooter),oldBlocked=lineBlocked(scene,origin,oldPoint),newBlocked=lineBlocked(scene,origin,nextPoint);if(newBlocked)continue;
        const oldCover=automaticCoverInfo(scene,origin,oldPoint,{ignoreNearOrigin:true,originToken:shooter}),newCover=automaticCoverInfo(scene,origin,nextPoint,{ignoreNearOrigin:true,originToken:shooter});
        const leftProtection=oldBlocked||oldCover.mz>0,nowOpen=!newBlocked&&newCover.mz<=0;if(!leftProtection||!nowOpen)continue;
        record.zoneFireShooters.push(shooter.id);const choice=await askCombatReaction(scene,shooter,mover,'zone-fire',weapon);if(choice==='attack')reactions.push(await executeZoneFireAttack(scene,shooter,mover,nextPoint,weapon,body));
      }
    }
    return reactions;
  }

  // Проверяем пересечение всего круга токена с сектором, а не только попадание
  // его центральной точки. Ранее крупный токен или цель у края нарисованного
  // конуса визуально находились под дробью, но сервер возвращал ноль целей.
  function pointInsideConePixels(origin,aim,point,depthPx,angleDeg=60,extraRadius=0) {
    const dx=aim.x-origin.x,dy=aim.y-origin.y,len=Math.hypot(dx,dy);if(len<.001)return false;
    const ux=dx/len,uy=dy/len,px=point.x-origin.x,py=point.y-origin.y,radius=Math.max(0,safeNumber(extraRadius,0));
    const distance=Math.hypot(px,py);if(distance>depthPx+radius)return false;
    const forward=px*ux+py*uy;if(forward < -radius || forward > depthPx+radius)return false;
    const lateral=Math.abs(px*uy-py*ux),half=Math.max(0.01,Math.min(89,angleDeg/2))*Math.PI/180;
    const width=Math.tan(half)*Math.max(0,Math.min(depthPx,forward));
    return lateral<=width+radius;
  }
  // Дробовой конус FATUM v1.4.0: глубина и ширина задаются независимо.
  // widthPx — полная ширина дальней границы; у стрелка ширина сходится к нулю.
  function pointInsideShotgunConePixels(origin,aim,point,depthPx,widthPx,extraRadius=0,lateralBonus=0) {
    const dx=aim.x-origin.x,dy=aim.y-origin.y,len=Math.hypot(dx,dy);if(len<.001||depthPx<=0)return false;
    const ux=dx/len,uy=dy/len,px=point.x-origin.x,py=point.y-origin.y,radius=Math.max(0,safeNumber(extraRadius,0)),sideBonus=Math.max(0,safeNumber(lateralBonus,0));
    // v1.4.1: для связанной цели разрешаем дополнительный боковой допуск у
    // самой вершины конуса, но не расширяем его назад за спину стрелка.
    const forward=px*ux+py*uy;if(forward < -radius || forward > depthPx+radius)return false;
    const lateral=Math.abs(px*uy-py*ux),clampedForward=clamp(forward,0,depthPx),halfWidth=Math.max(0,widthPx/2)*(clampedForward/depthPx);
    return lateral<=halfWidth+radius+sideBonus;
  }

  function effectContainsToken(scene,effect,token) {
    if(effect.shape==='cone')return pointInsideConePixels({x:effect.originX,y:effect.originY},{x:effect.aimX,y:effect.aimY},speciesCombatPoint(token),feetToScenePixels(scene,effect.coneFeet),effect.coneAngle,movementCollisionRadius(scene,token));
    return distanceFeet(scene,token,{x:effect.x,y:effect.y})<=effect.radius+0.01;
  }
  function effectCanReachToken(scene,effect,token){
    if(!effectContainsToken(scene,effect,token))return false;
    if(!['smoke','gas','toxin','panic','fire'].includes(effect.type)&&!effect.gasHazard)return true;
    return !effectSpreadBlocked(scene,effect,speciesCombatPoint(token));
  }

  async function processEffectZonesAtTurnStart(scene, token, roundChanged, body) {
    if (!scene || !token) return [];
    const results=[];
    // Эффекты «на один ход» живут до следующего субъективного хода создателя,
    // а не до глобального перехода раунда. Поэтому созданный последним в
    // инициативе Шквальный огонь успевает подействовать на весь следующий круг.
    for(const effect of scene.effects||[]){
      if(effect.durationMode==='owner-turn'&&effect.ownerTokenId===token.id&&effect.remainingRounds>0)effect.remainingRounds=Math.max(0,effect.remainingRounds-1);
    }
    scene.effects=(scene.effects||[]).filter(effect=>effect.remainingRounds>0);
    for (const effect of scene.effects || []) {
      if(effect.remainingRounds<=0)continue;
      const inside=effectCanReachToken(scene,effect,token);if(!inside)continue;
      const owner=findToken(scene,effect.ownerTokenId);if(effect.hostileOnly&&owner&&!tokensHostile(owner,token))continue;
      const gasProtection=effectIsGasHazard(effect)?gasProtectionForToken(token):{protected:false,source:null};
      if(effect.attackHindrance&&!gasProtection.protected)tokenActions(token).gasAttackHindrance={roundAction:true,source:effect.name};
      if(effect.skipTurn&&!gasProtection.protected){const info=tokenOd(token);if(info)info.host[info.currentKey]=0;}
      if((effectIsGasHazard(effect)||effect.type==='barrage'||effect.type==='fire')&&effect.zoneDamage>0&&!gasProtection.protected){const environmentalHazard=effectIsGasHazard(effect)?'gas':effect.type==='fire'?'fire':'';results.push(await applyDamageToTarget(scene,token,{...body,damage:effect.zoneDamage,damageTag:effect.damageTag,sourceText:effect.name,bleeding:false,ignoreArmor:Boolean(environmentalHazard),environmentalHazard},{persist:false,recordHistory:false,role:'system'}));}
    }
    if(roundChanged){
      const currentRound=getCampaign().initiative?.round||0;
      for(const effect of scene.effects||[]){
        if(effect.type==='toxin'&&!effect.triggered&&currentRound-effect.createdRound>=effect.delayRounds){
          for(const target of scene.tokens){if(!['character','npc'].includes(target.kind)||!effectCanReachToken(scene,effect,target))continue;const gasProtection=gasProtectionForToken(target);if(gasProtection.protected)continue;results.push(await applyDamageToTarget(scene,target,{...body,damage:effect.zoneDamage||effect.damage,damageTag:effect.damageTag,sourceText:effect.name,bleeding:false,ignoreArmor:true,environmentalHazard:'gas'},{persist:false,recordHistory:false,role:'system'}));}
          effect.triggered=true;
        }
        if(effect.durationMode!=='owner-turn')effect.remainingRounds=Math.max(0,effect.remainingRounds-1);
      }
      scene.effects=scene.effects.filter(effect=>effect.remainingRounds>0);
    }
    return results;
  }

  function coverAimPoint(kind,obj){
    if(kind==='wall')return pointOnWall(obj,.5);
    if(obj.shape==='circle')return{x:obj.x,y:obj.y};if(['polygon','polyline'].includes(obj.shape)&&obj.points?.length)return{x:obj.points.reduce((n,p)=>n+p.x,0)/obj.points.length,y:obj.points.reduce((n,p)=>n+p.y,0)/obj.points.length};return{x:obj.x+obj.width/2,y:obj.y+obj.height/2};
  }
  function damageCoverObject(kind,obj,rawDamage,{heavy=false}={}){
    const durability=Math.max(0,Math.round(safeNumber(kind==='wall'?obj.coverDurability:obj.durability,0)));if(!durability)return null;const damage=Math.max(0,Math.round(safeNumber(rawDamage,0)))*(heavy?2:1),key=kind==='wall'?'coverDamage':'damage',mzKey=kind==='wall'?'coverMz':'mz';obj[key]=Math.max(0,Math.round(safeNumber(obj[key],0))+damage);const destroyed=obj[key]>=durability;if(destroyed){obj.destroyed=true;obj[mzKey]=0;obj.blocksMovement=false;if(kind==='wall'){obj.blocksVision=false;obj.blocksMovement=false;}}return{kind,id:obj.id,name:kind==='wall'?(obj.coverName||'Укрытие-стена'):(obj.name||'Укрытие'),damage,totalDamage:obj[key],durability,destroyed};
  }
  function blastDamageCovers(scene,point,radius,rawDamage,{heavy=false}={}){const radiusPx=feetToScenePixels(scene,radius),results=[];for(const cover of scene.covers||[]){if(cover.destroyed||coverDistanceFromPoint(point,cover)>radiusPx)continue;const result=damageCoverObject('cover',cover,rawDamage,{heavy});if(result)results.push(result);}for(const wall of scene.walls||[]){if(wall.destroyed||wallDistanceFromPoint(point,wall)>radiusPx)continue;const result=damageCoverObject('wall',wall,rawDamage,{heavy});if(result)results.push(result);}return results;}
  function adjustTokenMorale(token,delta){const host=actionHost(token);if(!host)return 0;host.morale=host.morale&&typeof host.morale==='object'?host.morale:{current:0,max:0};const before=Math.round(safeNumber(host.morale.current,0)),max=Math.max(before,safeNumber(host.morale.max,999));let applied=Math.round(safeNumber(delta,0));if(applied<0)applied=-applyPendingMoraleReduction(token,-applied).total;host.morale.current=clamp(before+applied,0,max||999);return host.morale.current-before;}
  async function adjustTokenMoraleResolved(scene,token,delta,body={}){const host=actionHost(token);if(!host)return 0;host.morale=host.morale&&typeof host.morale==='object'?host.morale:{current:0,max:0};const before=Math.round(safeNumber(host.morale.current,0)),max=Math.max(before,safeNumber(host.morale.max,999));let applied=Math.round(safeNumber(delta,0));if(applied<0)applied=-(await applyPendingMoraleReductionResolved(scene,token,-applied,body)).total;host.morale.current=clamp(before+applied,0,max||999);return host.morale.current-before;}

  function audioExtension(mime, originalName = '') {
    const ext = path.extname(String(originalName||'')).toLowerCase().replace('.', '');
    if (['mp3','ogg','wav','webm','m4a','aac'].includes(ext)) return ext;
    const map = { 'audio/mpeg':'mp3','audio/mp3':'mp3','audio/ogg':'ogg','audio/wav':'wav','audio/x-wav':'wav','audio/webm':'webm','audio/mp4':'m4a','audio/x-m4a':'m4a','audio/aac':'aac' };
    return map[String(mime||'').toLowerCase()] || null;
  }
  function readBinaryBody(req, limit = 90 * 1024 * 1024, tooLargeMessage = 'Файл слишком большой.') {
    return new Promise((resolve, reject) => {
      const chunks=[]; let size=0, tooLarge=false;
      req.on('data', chunk => {
        size += chunk.length;
        if (size > limit) { tooLarge=true; chunks.length=0; return; }
        if (!tooLarge) chunks.push(chunk);
      });
      req.on('end', () => tooLarge ? reject(Object.assign(new Error(tooLargeMessage), { statusCode:413 })) : resolve(Buffer.concat(chunks)));
      req.on('error', reject);
    });
  }
  function currentChannelPosition(channel) {
    let position = Math.max(0, safeNumber(channel?.position, 0));
    if (channel?.playing && channel?.startedAt) position += Math.max(0, (Date.now() - Date.parse(channel.startedAt)) / 1000);
    return position;
  }

  const aiTurnLocks = new Set();
  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  function aiAliveCombatToken(token){return Boolean(token&&['character','npc'].includes(token.kind)&&!tokenIsDead(token)&&!token.defeated&&!linkedNpc(token)?.outOfCombat);}
  function aiEnemies(scene,token){return (scene?.tokens||[]).filter(other=>other.id!==token.id&&!other.hidden&&!isStealthed(other)&&state.combat?.participantTokenIds?.includes(other.id)&&aiAliveCombatToken(other)&&tokensHostile(token,other));}
  function aiAllies(scene,token){return (scene?.tokens||[]).filter(other=>other.id!==token.id&&state.combat?.participantTokenIds?.includes(other.id)&&aiAliveCombatToken(other)&&!tokensHostile(token,other));}
  function aiOd(token){return Math.max(0,Math.round(safeNumber(tokenOd(token)?.current,0)));}
  function aiOb(token){const info=token?.kind==='character'?{current:safeNumber(linkedCharacter(token)?.state?.obCurrent,linkedCharacter(token)?.state?.ob||0)}:token?.kind==='npc'?{current:safeNumber(linkedNpc(token)?.ob?.current,linkedNpc(token)?.obCurrent??4)}:null;return Math.max(0,Math.round(safeNumber(info?.current,0)));}
  function aiWeaponScore(weapon,distance=0){let score=dieSides(weapon.hitDieNormal,4)+safeNumber(weapon.hitBonus,0)*1.5+safeNumber(weapon.damage,0)*2;if(distance>safeNumber(weapon.range,0))score-=100;if(weapon.loaded===false)score-=30;if(weapon.unavailable)score-=100;return score;}
  function aiNearestEnemy(scene,token,enemies=aiEnemies(scene,token)){return [...enemies].sort((a,b)=>distanceFeet(scene,token,a)-distanceFeet(scene,token,b))[0]||null;}
  function aiPointCluster(scene,origin,tokens,radiusFeet,maxRangeFeet){let best=null;for(const candidate of tokens){const point=speciesCombatPoint(candidate);if(distanceFeet(scene,origin,point)>maxRangeFeet+.01)continue;const inside=tokens.filter(t=>distanceFeet(scene,t,point)<=radiusFeet+.01);const score=inside.length*10-distanceFeet(scene,origin,point)*.02;if(!best||score>best.score)best={point,inside,score};}return best;}
  function aiCoverPoint(scene,token,enemy){if(!enemy)return null;const remaining=movementSummary(token)?.remaining??tokenMovementLimit(token),maxPx=feetToScenePixels(scene,remaining),from=speciesCombatPoint(token),enemyPoint=speciesCombatPoint(enemy);let best=null;for(const cover of scene.covers||[]){if(cover.destroyed||safeNumber(cover.mz,0)<=0)continue;const center=coverReferencePoint(cover),dx=center.x-enemyPoint.x,dy=center.y-enemyPoint.y,len=Math.max(1,Math.hypot(dx,dy)),offset=movementCollisionRadius(scene,token)+Math.max(10,safeNumber(cover.thickness,18));const point={x:clamp(center.x+dx/len*offset,0,scene.mapWidth),y:clamp(center.y+dy/len*offset,0,scene.mapHeight)},travel=Math.hypot(point.x-from.x,point.y-from.y);if(travel>maxPx+.01||movementBlocked(scene,token,from,point))continue;const protection=automaticCoverInfo(scene,enemyPoint,point,{originToken:enemy}).mz;const score=protection*20-safeNumber(travel,0)*.02;if(protection>0&&(!best||score>best.score))best={point,score,cover};}return best;}
  function aiUseTacticalAction(token,actionId,steps){
    const actions=tokenActions(token);if(actions[actionId])return false;
    const speciesSt=speciesStateForToken(token),sprintCost=speciesSt?.species==='werewolf'&&speciesSt.werewolf?.transformed?1:2;
    const defs={retreat:{cost:2,roundAction:true},sprint:{cost:sprintCost,movementMultiplier:2,roundAction:true},crossing:{cost:1,mzBonus:2,roundAction:true},charge:{cost:1,roundAction:true},block:{cost:1,blockMeleeDamage:true,roundAction:true},peek:{cost:0,roundAction:true}};
    const def=defs[actionId];if(!def||aiOd(token)<def.cost)return false;spendTokenOd(token,def.cost);actions[actionId]={...def,at:nowIso(),ai:true};steps.push({type:'tactical',actionId,cost:def.cost});return true;
  }
  async function aiMove(scene,token,point,body,steps){
    const oldPoint={x:token.x,y:token.y};point=farthestFreeTokenPoint(scene,token,oldPoint,point);const movedFeet=distanceFeet(scene,oldPoint,point);if(movedFeet<=.05)return false;const movement=movementSummary(token);if(movement&&movedFeet>movement.remaining+.01)return false;
    const doors=aiDoorsAlongPath(scene,token,oldPoint,point);for(const door of doors){door.open=true;door.updatedAt=nowIso();steps.push({type:'door-open',doorId:door.id,doorName:door.name});broadcastAudioEffect(scene.id,'door.open',{x:doorGeometry(scene,door).center.x,y:doorGeometry(scene,door).center.y},null);}
    if(movementBlocked(scene,token,oldPoint,point))return false;
    const reactions=await resolveMovementReactions(scene,token,oldPoint,point,{...body,clientId:null,playerName:`ИИ: ${token.name}`});
    for(const effect of scene.effects||[]){if(effect.type!=='barrage'||effect.remainingRounds<=0||!effect.zoneDamage)continue;const circle={shape:'circle',x:effect.x,y:effect.y,radius:feetToScenePixels(scene,effect.radius)};if(lineIntersectsCover(oldPoint,point,circle)||pointInCover(point,circle)){effect.hitTokens||={};const round=getCampaign().initiative?.round||0;if(effect.hitTokens[token.id]!==round){const damageResult=await applyDamageToTarget(scene,token,{...body,damage:effect.zoneDamage,damageTag:effect.damageTag,sourceText:effect.name,role:'system'},{persist:false,recordHistory:false,role:'system'});const formulas=journalRollFormulas(null,damageResult);if(formulas.length){const damageEntry=appendTableLog({type:'roll',actorId:null,actorName:`ИИ: ${token.name}`,text:`${token.name}: урон при пересечении зоны «${effect.name}».`,sceneId:scene.id,tokenId:token.id,meta:{formulas}});broadcastTableLog(damageEntry);}effect.hitTokens[token.id]=round;}}}
    const forcedChecks=await resolveForcedCheckZones(scene,token,oldPoint,point,body);if(movement)movementRecord(token).spent=Math.round((movement.spent+movedFeet)*10)/10;token.x=point.x;token.y=point.y;if(token.display?.autoRotateOnMove)token.rotation=((Math.atan2(point.y-oldPoint.y,point.x-oldPoint.x)*180/Math.PI+90)%360+360)%360;token.updatedAt=nowIso();steps.push({type:'move',from:oldPoint,to:point,feet:Math.round(movedFeet*10)/10,reactions,forcedChecks});broadcast('battlemap-token-updated',null,{reason:'ai-move',sceneId:scene.id,tokenId:token.id});await wait(180);return true;
  }
  async function aiMoveToward(scene,token,point,body,steps){
    const route=aiFindRoute(scene,token,point);if(!route||route.length<2)return false;let moved=false,guard=0;
    for(const next of route.slice(1)){if(guard++>=14)break;const movement=movementSummary(token);if(!movement||movement.remaining<=.1)break;const feet=distanceFeet(scene,token,next);if(feet>movement.remaining+.01){const from=speciesCombatPoint(token),ratio=movement.remaining/Math.max(.01,feet),partial={x:from.x+(next.x-from.x)*ratio,y:from.y+(next.y-from.y)*ratio};if(await aiMove(scene,token,partial,body,steps))moved=true;break;}if(await aiMove(scene,token,next,body,steps))moved=true;else break;}
    return moved;
  }
  async function aiRangedAttack(scene,attacker,target,weapon,body,steps){
    const targetDistance=distanceFeet(scene,speciesCombatPoint(attacker),speciesCombatPoint(target)),rifle=rifleProfileForWeapon(weapon),moved=Boolean(state.combat?.active&&state.combat.sceneId===scene.id&&safeNumber(state.combat?.movement?.[attacker.id]?.spent,0)>0.001),useMeasured=Boolean(rifle&&!moved&&targetDistance>30.001&&rifle.proficiency>=rifle.effectiveThreshold&&aiOd(attacker)>=safeNumber(weapon.odCost,2)+1);
    const hiddenOrigin=stealthHidesTokenLocation(attacker,scene);
    let attack=makeAttackRoll({...body,clientId:null,playerName:`ИИ: ${attacker.name}`,sceneId:scene.id,attackerTokenId:attacker.id,targetTokenId:target.id,weaponId:weapon.id||weapon.slot||weapon.name,shotMode:useMeasured?'measured':'normal',moved,spendResources:true,autoApplyDamage:true,visibility:hiddenOrigin?'master':'public'},scene,attacker,target);
    let roll=combatRollRecord(scene,attacker,attack,'Атака ИИ');roll=await awaitAttackRollResolution(scene,roll);attack=roll.battlemapAttack;
    await spendAttackResources(attacker,attack,{spendResources:true},true);finalizePristrelkaAttack(scene,attacker,target,attack);markHeavyWeaponFired(attacker,weapon);markSpecialRangedFired(attacker,weapon);
    const sniperPosition=attack.shotMode==='measured'?recordMeasuredShotPosition(scene,attacker):null;if(sniperPosition)attack.sniperPosition=sniperPosition;
    const damageTarget=attack.damageTargetTokenId?findToken(scene,attack.damageTargetTokenId):null;let damageResult=null;
    if(damageTarget)damageResult=damageTarget.kind==='vehicle'?await applyDamageToVehicle(scene,damageTarget,{damage:attack.damage,damageTag:attack.damageTag},{persistNow:false}):await applyDamageToTarget(scene,damageTarget,{damage:attack.damage,damageTag:attack.damageTag,...attack.flags,sourceText:weaponText(weapon),role:'system'},{persist:false,recordHistory:false,role:'system'});
    const onHitEffect=damageTarget?await applyDirectWeaponOnHitEffects(scene,attacker,damageTarget,weapon,{...body,clientId:null,playerName:`ИИ: ${attacker.name}`}):null;
    const entry=appendTableLog({type:'roll',actorId:null,actorName:hiddenOrigin?'Скрытый стрелок':`ИИ: ${attacker.name}`,text:hiddenOrigin?`Скрытый стрелок совершает дальнобойную атаку: ${attackTotalBreakdown(attack,false)} против МЗ ${attack.targetMz} — ${attack.hit?'попадание':'промах'}.`:`${attack.label}: ${attackTotalBreakdown(attack,false)} против МЗ ${attack.targetMz} — ${attack.hit?'попадание':'промах'}.${reactionDamageText(damageResult)}${onHitEffect?.moraleLoss?` Мораль −${onHitEffect.moraleLoss}.`:onHitEffect?.burningZone?' Создана зона горения.':''}`,visibility:hiddenOrigin?'master':'public',sceneId:scene.id,tokenId:hiddenOrigin?null:attacker.id,meta:{formulas:[...journalRollFormulas(attack.formula,damageResult),...(onHitEffect?.moraleRoll?[`Анаксионный пистолет: 1d4 морали = ${onHitEffect.moraleRoll.total}`]:[])]}});broadcastTableLog(entry);
    if(!hiddenOrigin)broadcastProjectileEffect(scene.id,{id:`ai-shot-${attack.id}`,kind:projectileKindForWeapon(weapon),from:speciesCombatPoint(attacker),to:targetPointForProjectile(scene,attack,target),durationMs:projectileDurationMs(scene,speciesCombatPoint(attacker),targetPointForProjectile(scene,attack,target),weapon),hit:attack.hit,label:weapon.name},null);
    broadcastAudioEffect(scene.id,weaponSoundKey(weapon),hiddenOrigin?{}:{tokenId:attacker.id,x:attacker.x,y:attacker.y,targetTokenId:target.id},null);
    const counterSniperReactions=attack.shotMode==='measured'?await resolveCounterSniperReactions(scene,attacker,attack,body):[];
    steps.push({type:'attack',weapon:weapon.name,target:target.name,attack,damageResult,onHitEffect,roll,counterSniperReactions});await wait(300);return true;
  }
  async function aiWeaponZone(scene,attacker,weapon,enemies,modeName,body,steps){
    if(!scene||!attacker||!weapon||!['suppression','barrage'].includes(modeName))return false;
    const odCost=Math.max(0,Math.round(safeNumber(weapon.odCost,2)));
    if(weapon.unavailable||weapon.loaded===false||aiOd(attacker)<odCost||aiOb(attacker)<1)return false;
    if(modeName==='suppression'&&!weaponSupportsSuppression(weapon))return false;
    if(modeName==='barrage'&&!weaponSupportsBarrage(weapon))return false;
    if(tokenEngagedInMelee(scene,attacker))return false;

    const origin=speciesCombatPoint(attacker);
    const zoneProfile=canonicalCombatWeaponProfile(weapon),radius=modeName==='barrage'?(zoneProfile==='Тяжёлый пулемёт'?10.6:7.1):7.5;
    const visible=(Array.isArray(enemies)?enemies:[]).filter(enemy=>enemy&&aiAliveCombatToken(enemy)&&!enemy.hidden&&distanceFeet(scene,attacker,enemy)<=safeNumber(weapon.range,0)+.01&&!contactBlockedByWall(scene,origin,speciesCombatPoint(enemy)));
    if(!visible.length)return false;

    // ИИ не должен класть Подавление/Шквальный огонь поверх союзников или себя.
    // Для Шквального огня это предотвращает дружественный урон, для Подавления —
    // случайную помеху своим стрелкам. Также не дублируем собственную активную
    // зону того же типа в той же точке.
    const friendlies=[attacker,...aiAllies(scene,attacker)];
    const ownZones=(scene.effects||[]).filter(effect=>effect.type===modeName&&effect.remainingRounds>0&&effect.ownerTokenId===attacker.id);
    let best=null;
    for(const primary of visible){
      const point=speciesCombatPoint(primary);
      if(ownZones.some(effect=>distanceFeet(scene,point,{x:effect.x,y:effect.y})<=Math.max(radius,safeNumber(effect.radius,0))*.65))continue;
      const inside=visible.filter(target=>distanceFeet(scene,target,point)<=radius+.01);
      const friendlyHits=friendlies.filter(target=>distanceFeet(scene,target,point)<=radius+.01);
      if(friendlyHits.length)continue;

      let coverInfo={mz:0,source:null,ignored:[]},peeking=false;
      if(modeName==='barrage'){
        peeking=Boolean(tokenActions(attacker)?.peek)&&tokenAdjacentToCover(scene,attacker);
        coverInfo=automaticCoverInfo(scene,origin,point,{ignoreNearOrigin:peeking,originToken:attacker,includeTargetInsideCover:true});
        if(coverInfo.mz>0)continue;
      }
      const score=inside.length*(modeName==='barrage'?14:10)-distanceFeet(scene,attacker,point)*.02;
      if(!best||score>best.score)best={primary,point,inside,score,peeking,coverInfo};
    }
    if(!best)return false;

    await spendAttackResources(attacker,{id:makeId(`ai-${modeName}-cost`),sceneId:scene.id,odCost,obCost:1,weapon},{...body,clientId:null,playerName:`ИИ: ${attacker.name}`,spendResources:true},true);
    markHeavyWeaponFired(attacker,weapon);
    const effect=normalizeEffectZone({
      id:makeId(modeName),
      name:modeName==='barrage'?'Шквальный огонь':'Подавление',
      type:modeName,
      x:best.point.x,y:best.point.y,radius,
      color:modeName==='barrage'?'#df6955':'#d7b45a',
      zoneDamage:modeName==='barrage'?(zoneProfile==='Тяжёлый пулемёт'?2:1):0,
      hitPenalty:modeName==='suppression'?((zoneProfile==='Автоматический карабин'?-1:0)+(weaponHasMod(weapon,'carbine_suppression_kit')?-1:0)):0,
      damageTag:weapon.damageTag||'medium',remainingRounds:1,durationMode:'owner-turn',
      createdRound:getCampaign().initiative?.round||0,ownerTokenId:attacker.id,sourceName:weapon.name,
      notes:modeName==='barrage'?'Урон при входе, пересечении или начале хода.':'Помеха на дальнобойные атаки из этой позиции.'
    },scene.effects.length);
    scene.effects.push(effect);
    const entry=appendTableLog({type:'action',actorId:null,actorName:`ИИ: ${attacker.name}`,text:`${attacker.name}: ${effect.name} (${weapon.name}) по позиции ${best.primary.name}.`,sceneId:scene.id,tokenId:attacker.id});
    broadcastTableLog(entry);
    broadcastAudioEffect(scene.id,modeName==='barrage'?'zone.barrage':'zone.suppression',{tokenId:attacker.id,x:attacker.x,y:attacker.y,targetX:best.point.x,targetY:best.point.y},null);
    if(Array.isArray(steps))steps.push({type:'weapon-zone',mode:modeName,weapon:weapon.name,target:best.primary.name,targetIds:best.inside.map(target=>target.id),effect});
    await wait(260);
    return true;
  }

  async function aiMeleeAttack(scene,attacker,target,weapon,body,steps){let attack=makeMeleeRoll({...body,clientId:null,playerName:`ИИ: ${attacker.name}`,weaponId:weapon.id||weapon.slot||weapon.name,visibility:'public'},scene,attacker,target,{suppressCounter:false});let roll=combatRollRecord(scene,attacker,attack,'Ближний бой ИИ');roll=await awaitAttackRollResolution(scene,roll);attack=roll.battlemapAttack;await spendAttackResources(attacker,attack,{spendResources:true},true);let damageResult=null;if(attack.hit)damageResult=await applyDamageToTarget(scene,target,{damage:attack.damage,damageTag:attack.damageTag,...attack.flags,melee:true,sourceText:weaponText(weapon),role:'system'},{persist:false,recordHistory:false,role:'system'});if(attack.counterAvailable)pendingMeleeCounters.set(attack.id,{attack:clone(attack),defenderTokenId:target.id,attackerTokenId:attacker.id,createdAt:Date.now(),expiresAt:Date.now()+120000});const entry=appendTableLog({type:'roll',actorId:null,actorName:`ИИ: ${attacker.name}`,text:`${attack.label}: ${attackTotalBreakdown(attack,true)} против ${attack.defenderTotal} — ${attack.hit?'попадание':attack.tie?'ничья':'промах'}.${reactionDamageText(damageResult)}`,sceneId:scene.id,tokenId:attacker.id,meta:{formulas:journalRollFormulas(attack.formula,damageResult)}});broadcastTableLog(entry);broadcastAudioEffect(scene.id,weaponSoundKey(attack.weapon,{melee:true,unarmed:Boolean(attack.flags?.unarmed)}),{tokenId:attacker.id,x:attacker.x,y:attacker.y,targetTokenId:target.id},null);steps.push({type:'melee',weapon:weapon.name,target:target.name,attack,damageResult,roll});await wait(420);return true;}
  async function aiShotgunCone(scene,attacker,weapon,enemies,body,steps){
    const profile=shotgunProfileForWeapon(weapon);if(!profile?.coneDepthFeet)return false;
    const origin=speciesCombatPoint(attacker),depthFeet=Math.min(30,profile.coneDepthFeet),depthPx=feetToScenePixels(scene,depthFeet),widthFeet=profile.coneWidthFeet,widthPx=feetToScenePixels(scene,widthFeet);
    let best=null;
    for(const primary of enemies){if(distanceFeet(scene,origin,speciesCombatPoint(primary))>depthFeet+.01)continue;const aim=speciesCombatPoint(primary),targets=enemies.filter(t=>pointInsideShotgunConePixels(origin,aim,speciesCombatPoint(t),depthPx,widthPx,movementCollisionRadius(scene,t))&&!contactBlockedByWall(scene,origin,speciesCombatPoint(t))),allies=aiAllies(scene,attacker).filter(t=>pointInsideShotgunConePixels(origin,aim,speciesCombatPoint(t),depthPx,widthPx,movementCollisionRadius(scene,t))),score=targets.length*12-allies.length*30;if(!best||score>best.score)best={aim,primary,targets,allies,score};}
    if(!best||!best.targets.length||best.allies.length)return false;
    const attacks=[];
    for(const target of best.targets){const attack=makeAttackRoll({...body,weaponId:weapon.id||weapon.slot||weapon.name,targetTokenId:target.id,shotMode:'normal'},scene,attacker,target,{allowShotgunSingle:true,shotgunCone:true,ignoreTargetMelee:!hostileMeleeOpponents(scene,attacker,origin).some(item=>item.id===target.id),label:`${attacker.name}: ${weapon.name} (конус) → ${target.name}`});const distance=distanceFeet(scene,origin,speciesCombatPoint(target)),primary=target.id===best.primary.id;attack.kind='shotgun-cone';attack.primaryTarget=primary;attack.coneDepthFeet=depthFeet;attack.coneWidthFeet=widthFeet;let reduction=0;if(!primary&&distance>10)reduction++;if(profile.spreader)reduction++;if(reduction)attack.damage=Math.max(1,attack.damage-reduction);attacks.push({attack,target,primary,distance});}
    await spendAttackResources(attacker,{id:makeId('ai-cone'),sceneId:scene.id,weapon,odCost:weapon.odCost,obCost:0},{spendResources:true},true);
    for(const item of attacks){let attack=item.attack;const target=item.target;let roll=combatRollRecord(scene,attacker,attack,'Конус дробовика ИИ');roll=await awaitAttackRollResolution(scene,roll);attack=roll.battlemapAttack;finalizePristrelkaAttack(scene,attacker,target,attack);item.attack=attack;let damageResult=null;if(attack.hit)damageResult=target.kind==='vehicle'?await applyDamageToVehicle(scene,target,{damage:attack.damage,damageTag:attack.damageTag},{persistNow:false}):await applyDamageToTarget(scene,target,{damage:attack.damage,damageTag:attack.damageTag,...attack.flags,sourceText:weaponText(weapon),role:'system'},{persist:false,recordHistory:false,role:'system'});item.damageResult=damageResult;steps.push({type:'shotgun-cone-hit',target:target.name,attack,damageResult,roll});}
    const len=Math.max(1,Math.hypot(best.aim.x-origin.x,best.aim.y-origin.y)),endpoint={x:origin.x+(best.aim.x-origin.x)/len*depthPx,y:origin.y+(best.aim.y-origin.y)/len*depthPx};broadcastProjectileEffect(scene.id,{id:makeId('ai-shotgun'),kind:'shotgun',from:origin,to:endpoint,durationMs:520,hit:attacks.some(x=>x.attack.hit),label:weapon.name},null);broadcastAudioEffect(scene.id,weaponSoundKey(weapon),{tokenId:attacker.id,x:attacker.x,y:attacker.y},null);
    const formulas=attacks.flatMap(({attack,target,damageResult})=>journalRollFormulas(`${target.name}: ${attack.formula}`,damageResult)),entry=appendTableLog({type:'roll',actorId:null,actorName:`ИИ: ${attacker.name}`,text:`${attacker.name}: ${weapon.name}, конус ${depthFeet}×${widthFeet} фт — целей ${attacks.length}, попаданий ${attacks.filter(x=>x.attack.hit).length}; основная цель: ${best.primary.name}.`,sceneId:scene.id,tokenId:attacker.id,meta:{formulas}});broadcastTableLog(entry);steps.push({type:'shotgun-cone',weapon:weapon.name,primary:best.primary.name,targets:best.targets.map(t=>t.name)});await wait(480);return true;
  }

  async function aiAreaWeaponAttack(scene,attacker,weapon,enemies,body,steps){
    if(!weapon||safeNumber(weapon.radius,0)<=0||weapon.loaded===false||aiOd(attacker)<safeNumber(weapon.odCost,2))return false;
    const cluster=aiPointCluster(scene,attacker,enemies.filter(enemy=>!contactBlockedByWall(scene,speciesCombatPoint(attacker),speciesCombatPoint(enemy))),weapon.radius,weapon.range);if(!cluster||contactBlockedByWall(scene,speciesCombatPoint(attacker),cluster.point))return false;
    const allies=aiAllies(scene,attacker).filter(t=>distanceFeet(scene,t,cluster.point)<=weapon.radius+.01),score=cluster.inside.length*15-allies.length*40;
    if(score<=0||allies.length)return false;
    const targetNumber=3,hitDie=weapon.hitDieNormal||'1d6',hitSides=dieSides(hitDie,6),initialRoll=rollOne(hitSides),bonus=safeNumber(weapon.hitBonus,0);
    let attack={id:makeId('ai-area'),at:nowIso(),actorId:null,actorName:`ИИ: ${attacker.name}`,kind:'area-attack',visibility:'public',sceneId:scene.id,attackerTokenId:attacker.id,attackerName:attacker.name,targetTokenId:null,targetName:'точка области',weapon,hitDie,attackRolls:[initialRoll],reactionRollMode:0,rolls:[initialRoll],roll:initialRoll,baseHitBonus:bonus,hitBonus:bonus,total:initialRoll+bonus,targetMz:targetNumber,hit:initialRoll+bonus>=targetNumber,damage:Math.max(0,safeNumber(weapon.damage,0)),damageTag:weapon.damageTag||'heavy',specialMode:null,flags:attackFlagsFromWeapon(weapon),featureEffects:{},formula:`1d${hitSides}${signedFormulaBonus(bonus)} vs 3`,label:`${attacker.name}: ${weapon.name} по области`};
    let areaRoll=combatRollRecord(scene,attacker,attack,'Атака по области ИИ');areaRoll=await awaitAttackRollResolution(scene,areaRoll);attack=areaRoll.battlemapAttack;
    const hit=Boolean(attack.hit);let point={...cluster.point},scatter=0;
    if(!hit){const scatterResolved=await resolveScalarRoll(scene,attacker,{body:{...body,clientId:null,playerName:`ИИ: ${attacker.name}`},label:`${attacker.name}: отклонение выстрела по области`,sides:6,kind:'scatter',purpose:'scatter'});scatter=scatterResolved.value*5;const angle=Math.random()*Math.PI*2,px=feetToScenePixels(scene,scatter),scattered={x:clamp(point.x+Math.cos(angle)*px,0,scene.mapWidth),y:clamp(point.y+Math.sin(angle)*px,0,scene.mapHeight)},impact=projectileWallImpact(scene,speciesCombatPoint(attacker),scattered);point=impact?{x:impact.x,y:impact.y}:scattered;}
    const obCost=weaponIsExplosiveHeavy(weapon)?1:Math.max(0,safeNumber(weapon.obCost,0));
    await spendAttackResources(attacker,{...attack,id:makeId('ai-area-cost'),odCost:weapon.odCost,obCost},{spendResources:true},true);markHeavyWeaponFired(attacker,weapon);
    const affected=[];
    for(const target of scene.tokens||[]){
      if(!['character','npc','vehicle'].includes(target.kind))continue;const feet=distanceFeet(scene,target,point);if(feet>weapon.radius+.01)continue;
      const base=feet<=weapon.radius/2?attack.damage:Math.floor(attack.damage/2),wallBlocked=explosionBlockedByWall(scene,point,target),reduction=wallBlocked?0:explosionCoverReduction(scene,point,target),dealt=(wallBlocked?0:Math.max(0,base-reduction))*(target.kind==='vehicle'&&weaponIsHeavy(weapon)?2:1);let result=null;
      if(dealt>0)result=target.kind==='vehicle'?await applyDamageToVehicle(scene,target,{damage:dealt,damageTag:weapon.damageTag||'heavy'},{persistNow:false}):await applyDamageToTarget(scene,target,{damage:dealt,damageTag:weapon.damageTag||'heavy',...attack.flags,explosive:true,sourceText:weapon.name,role:'system'},{persist:false,recordHistory:false,role:'system'});
      let extraMorale=0;if(/анаксионный излучатель/i.test(weaponText(weapon))&&!wallBlocked){const moraleRoll=await resolveScalarRoll(scene,target,{body:{...body,clientId:null,playerName:`ИИ: ${attacker.name}`},label:`${target.name}: дополнительная потеря морали от анаксионного излучателя`,sides:6,kind:'anaxion-morale',purpose:'morale-loss'});extraMorale=-(await adjustTokenMoraleResolved(scene,target,-moraleRoll.total,{...body,clientId:null,playerName:`ИИ: ${attacker.name}`}));}affected.push({target:target.name,damage:dealt,coverReduction:reduction,wallBlocked,result,extraMorale});
    }
    const damagedCovers=blastDamageCovers(scene,point,weapon.radius,attack.damage,{heavy:weaponIsHeavy(weapon)});
    broadcastProjectileEffect(scene.id,{id:makeId('ai-area'),kind:'launcher',from:speciesCombatPoint(attacker),to:point,durationMs:900,hit:true,radius:weapon.radius,label:weapon.name},null);
    broadcastAudioEffect(scene.id,weaponSoundKey(weapon),{tokenId:attacker.id,x:attacker.x,y:attacker.y},null);broadcastAudioEffect(scene.id,'grenade.explosion',{x:point.x,y:point.y},null);
    const areaFormula=attack.formula,areaFormulas=[areaFormula,...(!hit?['Отклонение: 1d6 × 5 фт']:[]),...affected.flatMap(item=>journalRollFormulas(null,item.result)),...(/анаксионный излучатель/i.test(weaponText(weapon))&&affected.length?[`Доп. потеря морали: ${affected.length}×1d6 (по одному на цель)`]:[])];
    const entry=appendTableLog({type:'roll',actorId:null,actorName:`ИИ: ${attacker.name}`,text:`${attacker.name}: ${weapon.name} по области — ${hit?'точно':`отклонение ${scatter} фт`}; затронуто целей ${affected.length}.`,sceneId:scene.id,tokenId:attacker.id,meta:{rollId:areaRoll.id,formulas:areaFormulas}});broadcastTableLog(entry);
    steps.push({type:'area-attack',weapon:weapon.name,point,hit,scatter,affected,damagedCovers,roll:areaRoll});await wait(560);return true;
  }
  async function aiThrowGrenade(scene,attacker,enemies,body,steps){
    const origin=speciesCombatPoint(attacker),visible=enemies.filter(enemy=>!contactBlockedByWall(scene,origin,speciesCombatPoint(enemy))),inventory=inventoryForToken(attacker),candidates=[];
    for(let i=0;i<inventory.items.length;i++){const raw=inventory.items[i],catalog=weaponCatalog.get(String(raw?.name||''))||{},item={...catalog,...raw,desc:raw?.desc||raw?.description||catalog.desc||''},type=String(item.type||'');if(type==='Граната'||GRENADE_PROFILES[item.name]||/Дымовая шашка/i.test(item.name))candidates.push({...inventory,item,raw,index:i,profile:grenadeProfile(item)});}
    const offensive=candidates.filter(x=>['explosive','gas','toxin','panic','anaxion'].includes(x.profile.type));if(!offensive.length||!visible.length||aiOd(attacker)<1)return false;const range=grenadeThrowRange(attacker);let choice=null;
    for(const holder of offensive){const cluster=aiPointCluster(scene,attacker,visible,holder.profile.radius,range);if(!cluster||contactBlockedByWall(scene,origin,cluster.point))continue;const allyHits=aiAllies(scene,attacker).filter(t=>distanceFeet(scene,t,cluster.point)<=holder.profile.radius+.01&&!explosionBlockedByWall(scene,cluster.point,t)).length,score=cluster.inside.length*12-allyHits*35;if((cluster.inside.length>=2||holder.profile.type==='panic')&&(!choice||score>choice.score))choice={holder,cluster,score};}
    if(!choice||choice.score<=0)return false;spendTokenOd(attacker,1);consumeInventoryItem(choice.holder,1);const profile=choice.holder.profile;let point={...choice.cluster.point},throwCheck=null,scatter=0;
    const throwDistance=distanceFeet(scene,attacker,point);
    const aiThrowDifficulty=grenadeThrowDifficulty(scene,attacker,point,range,false);if(aiThrowDifficulty.difficult){const accuracy=opposedSkillProfile(attacker,'Меткость',true),strength=opposedSkillProfile(attacker,'Физическая сила',true),skill=(safeNumber(strength?.bonus,0)>safeNumber(accuracy?.bonus,0))?'Физическая сила':'Меткость';throwCheck=runAnyTokenSkillCheck(attacker,skill,6,0);if(throwCheck)throwCheck.difficultyReasons=aiThrowDifficulty.reasons;if(throwCheck){let throwRoll=storeSpeciesCheckRoll(scene,attacker,throwCheck,{clientId:null,playerName:`ИИ: ${attacker.name}`},`${attacker.name}: бросок гранаты — ${skill}`,{reactionSafe:true});if(throwRoll){throwRoll=await awaitCheckRollResolution(scene,throwRoll);syncCheckFromReactionRoll(throwCheck,throwRoll);}}if(throwCheck&&!throwCheck.success){const scatterResolved=await resolveScalarRoll(scene,attacker,{body:{...body,clientId:null,playerName:`ИИ: ${attacker.name}`},label:`${attacker.name}: отклонение гранаты`,sides:6,kind:'scatter',purpose:'scatter'});scatter=scatterResolved.value*5;const angle=Math.random()*Math.PI*2,px=feetToScenePixels(scene,scatter),scattered={x:clamp(point.x+Math.cos(angle)*px,0,scene.mapWidth),y:clamp(point.y+Math.sin(angle)*px,0,scene.mapHeight)},impact=projectileWallImpact(scene,origin,scattered);point=impact?{x:impact.x,y:impact.y}:scattered;}}
    broadcastProjectileEffect(scene.id,{id:makeId('ai-grenade'),kind:'grenade',from:origin,to:point,durationMs:900,hit:true,radius:profile.radius,label:profile.name,explosive:profile.type==='explosive',deferExplosion:true},null);broadcastAudioEffect(scene.id,'grenade.throw',{tokenId:attacker.id,x:attacker.x,y:attacker.y},null);
    const grenadeReactions=await resolveThrownGrenadeReactions(scene,attacker,point,profile,body),affected=[];
    if(profile.damage>0){for(const target of scene.tokens||[]){if(!['character','npc','vehicle'].includes(target.kind))continue;if(profile.hostileOnly&&!tokensHostile(attacker,target))continue;if(profile.gasHazard&&target.kind==='vehicle')continue;const feet=distanceFeet(scene,target,point);if(feet>profile.radius+.01)continue;const wallBlocked=explosionBlockedByWall(scene,point,target),coverReduction=profile.gasHazard||wallBlocked?0:explosionCoverReduction(scene,point,target),reaction=grenadeReactions.get(target.id)||null,reactionReduction=profile.gasHazard?0:(reaction?.choice&&reaction.choice!=='none'?1:0),gasProtection=profile.gasHazard?gasProtectionForToken(target):{protected:false,source:null},dealt=wallBlocked||gasProtection.protected?0:Math.max(0,(feet<=profile.radius/2?profile.damage:Math.floor(profile.damage/2))-coverReduction-reactionReduction);if(dealt<=0){affected.push({target:target.name,damage:0,wallBlocked,coverReduction,reactionReduction,reaction,gasProtection});continue;}const result=target.kind==='vehicle'?await applyDamageToVehicle(scene,target,{damage:dealt,damageTag:profile.damageTag||'heavy'},{persistNow:false}):await applyDamageToTarget(scene,target,{damage:dealt,damageTag:profile.damageTag||'heavy',explosive:!profile.gasHazard,ignoreArmor:Boolean(profile.gasHazard),environmentalHazard:profile.gasHazard?'gas':'',sourceText:profile.name,role:'system'},{persist:false,recordHistory:false,role:'system'});affected.push({target:target.name,damage:dealt,wallBlocked:false,coverReduction,reactionReduction,reaction,gasProtection,result});}}
    let zone=null;if(['smoke','gas','toxin','panic','anaxion'].includes(profile.type)&&profile.rounds){zone=normalizeEffectZone({id:makeId('zone'),name:profile.name,type:profile.type,x:point.x,y:point.y,radius:profile.radius,color:profile.type==='smoke'?'#aab4bd':profile.type==='panic'?'#c2a45a':profile.type==='anaxion'?'#9b75d1':'#75b86b',mzBonus:profile.mzBonus||0,visionLimit:profile.visionLimit||0,gasHazard:Boolean(profile.gasHazard),zoneDamage:profile.zoneDamage||0,damageTag:profile.damageTag||'light',remainingRounds:profile.rounds,delayRounds:profile.delayRounds||0,createdRound:getCampaign().initiative?.round||0,ownerTokenId:attacker.id,sourceName:profile.name,attackHindrance:Boolean(profile.attackHindrance),skipTurn:Boolean(profile.skipTurn),hostileOnly:Boolean(profile.hostileOnly),notes:profile.notes||''},scene.effects.length);scene.effects.push(zone);}
    broadcastProjectileEffect(scene.id,{id:makeId('ai-grenade-impact'),kind:'grenade',from:point,to:point,durationMs:120,hit:true,radius:profile.radius,label:profile.name,effectType:profile.type,explosive:profile.type==='explosive',explodeOnly:true},null);if(profile.type==='explosive')broadcastAudioEffect(scene.id,'grenade.explosion',{x:point.x,y:point.y},null);else broadcastAudioEffect(scene.id,'grenade.smokeGas',{x:point.x,y:point.y},null);const aiGrenadeFormulas=[];if(throwCheck){aiGrenadeFormulas.push(`${throwCheck.successDie}${signedFormulaBonus(throwCheck.bonus)} vs ${throwCheck.difficultyDie}${signedFormulaBonus(throwCheck.difficultyModifier)}`);if(!throwCheck.success)aiGrenadeFormulas.push('Отклонение: 1d6 × 5 фт');}for(const item of affected)aiGrenadeFormulas.push(...journalRollFormulas(null,item.result));const entry=appendTableLog({type:aiGrenadeFormulas.length?'roll':'action',actorId:null,actorName:`ИИ: ${attacker.name}`,text:`${attacker.name} бросает «${profile.name}»${throwCheck?throwCheck.success?' — проверка броска успешна':` — промах, отклонение ${scatter} фт`:''}: затронуто целей ${affected.filter(item=>item.damage>0).length}${zone?'; создана зона':''}.`,sceneId:scene.id,tokenId:attacker.id,meta:{formulas:aiGrenadeFormulas}});broadcastTableLog(entry);steps.push({type:'grenade',name:profile.name,point,throwCheck,scatter,affected,reactions:Object.fromEntries(grenadeReactions),zone});await wait(420);return true;
  }
  function aiInteractiveBlastCluster(scene,startObject){
    const queue=[startObject],seen=new Set(),objects=[];
    while(queue.length){const object=queue.shift();if(!object||seen.has(object.id))continue;seen.add(object.id);const cfg=object.interactive;if(!cfg?.active||cfg.triggered||!cfg.explosionEnabled||cfg.explosionDamage<=0)continue;objects.push(object);for(const next of interactiveChainCandidates(scene,object))if(!seen.has(next.id))queue.push(next);}
    return objects;
  }
  function aiInteractiveDamageAt(scene,objects,target){
    let total=0;for(const object of objects){const cfg=object.interactive,point={x:object.x,y:object.y},feet=distanceFeet(scene,target,point);if(feet>cfg.explosionRadius+.01||explosionBlockedByWall(scene,point,target))continue;const base=feet<=cfg.explosionRadius/2?cfg.explosionDamage:Math.floor(cfg.explosionDamage/2),reduction=explosionCoverReduction(scene,point,target);total+=Math.max(0,base-reduction);}return total;
  }
  function aiInteractiveOpportunity(scene,attacker,enemies){
    const allies=[attacker,...aiAllies(scene,attacker)],origin=speciesCombatPoint(attacker),weapons=weaponsForToken(attacker).filter(weaponIsRanged).filter(w=>w.loaded!==false&&!w.unavailable&&aiOd(attacker)>=safeNumber(w.odCost,1));let best=null;
    for(const object of scene.tokens||[]){const cfg=object?.interactive;if(object?.kind!=='interactive'||object.hidden||!cfg?.active||cfg.triggered||!cfg.triggerOnShot||!cfg.explosionEnabled||cfg.explosionDamage<=0)continue;if(contactBlockedByWall(scene,origin,{x:object.x,y:object.y}))continue;
      const weapon=[...weapons].filter(w=>distanceFeet(scene,origin,{x:object.x,y:object.y})<=safeNumber(w.range,0)+.01).sort((a,b)=>aiWeaponScore(b)-aiWeaponScore(a))[0];if(!weapon)continue;
      const cluster=aiInteractiveBlastCluster(scene,object),enemyDamage=enemies.reduce((sum,target)=>sum+aiInteractiveDamageAt(scene,cluster,target),0),allyDamage=allies.reduce((sum,target)=>sum+aiInteractiveDamageAt(scene,cluster,target),0);if(enemyDamage<=0||allyDamage>0)continue;
      const enemyHits=enemies.filter(target=>aiInteractiveDamageAt(scene,cluster,target)>0).length,score=enemyDamage*12+enemyHits*8-distanceFeet(scene,attacker,object)*.02;if(!best||score>best.score)best={object,weapon,cluster,enemyDamage,enemyHits,score};
    }
    return best;
  }
  async function aiShootInteractiveObject(scene,attacker,opportunity,body,steps){
    if(!opportunity)return false;const result=await resolveInteractiveShot(scene,attacker,opportunity.object,{...body,clientId:null,playerName:`ИИ: ${attacker.name}`,sceneId:scene.id,weaponId:opportunity.weapon.id||opportunity.weapon.slot||opportunity.weapon.name,spendResources:true,visibility:'public'},true);steps.push({type:'interactive-shot',weapon:opportunity.weapon.name,target:opportunity.object.name,enemyDamagePotential:opportunity.enemyDamage,enemyHits:opportunity.enemyHits,attack:result.attack,triggerResult:result.triggerResult});await wait(340);return true;
  }
  const aiSquadBoards = new Map();
  const AI_ROLE_LABELS = Object.freeze({auto:'Авто',rifleman:'Стрелок',assault:'Штурмовик',sniper:'Снайпер',gunner:'Пулемётчик',grenadier:'Гренадер',defender:'Защитник',medic:'Медик',commander:'Командир',scout:'Разведчик',monster:'Чудовище'});
  function aiInferRole(token){
    const weapons=weaponsForToken(token).filter(w=>!w.unavailable),ranged=weapons.filter(weaponIsRanged),melee=weapons.filter(w=>w.melee||weaponIsMelee(w)),text=weapons.map(weaponText).join(' ').toLowerCase();
    if(/пулем[её]т|machine.?gun/.test(text))return'gunner';
    if(/гранатом[её]т|launcher/.test(text)||weapons.some(w=>safeNumber(w.radius,0)>=15))return'grenadier';
    if(/снайпер|sniper|дальнобойн/.test(text))return'sniper';
    if(weapons.some(weaponIsShotgun))return'assault';
    if(!ranged.length&&melee.length)return'monster';
    return'rifleman';
  }
  function aiResolvedRole(token,config=normalizeAiControl(token?.ai)){return config.role&&config.role!=='auto'?config.role:aiInferRole(token);}
  function aiMoralePosture(token){
    const host=actionHost(token),morale=host?.morale;if(!morale||typeof morale!=='object')return{state:'steady',ratio:1,current:null,max:null};
    const max=Math.max(0,safeNumber(morale.max,0)),current=clamp(safeNumber(morale.current,max),0,Math.max(max,safeNumber(morale.current,max)));if(max<=0)return{state:'steady',ratio:1,current,max};
    const ratio=current/max;if(current<=0)return{state:'broken',ratio:0,current,max};if(ratio<=.25)return{state:'shaken',ratio,current,max};if(ratio<=.5)return{state:'cautious',ratio,current,max};return{state:'steady',ratio,current,max};
  }
  function aiSquadKey(scene,token){return token?.groupId?`${scene?.id||'scene'}:group:${token.groupId}`:`${scene?.id||'scene'}:solo:${token?.id||'npc'}`;}
  function aiSquadBoard(scene,token){
    const key=aiSquadKey(scene,token),round=getCampaign().initiative?.round||0;let board=aiSquadBoards.get(key);
    if(!board){board={key,sceneId:scene.id,groupId:token.groupId||null,round,priorityTargetId:null,lastSeen:{},claims:{},suppressedTargetId:null};aiSquadBoards.set(key,board);}
    if(board.round!==round){if(round<board.round){board.priorityTargetId=null;board.lastSeen={};}board.round=round;board.claims={};board.suppressedTargetId=null;}
    for(const[id,memory]of Object.entries(board.lastSeen||{}))if(memory.sceneId!==scene.id||round<safeNumber(memory.round,0)||round-safeNumber(memory.round,0)>6)delete board.lastSeen[id];
    return board;
  }
  function aiRememberSquadVisible(scene,token,visible,config,board){
    const round=getCampaign().initiative?.round||0;for(const enemy of visible){const memory={x:enemy.x,y:enemy.y,round,sceneId:scene.id};config.lastSeen[enemy.id]=memory;board.lastSeen[enemy.id]=memory;}
    for(const id of Object.keys(config.lastSeen)){const memory=config.lastSeen[id];if(memory.sceneId!==scene.id||round<memory.round||round-memory.round>6||!aiEnemies(scene,token).some(enemy=>enemy.id===id))delete config.lastSeen[id];}
    if(board.priorityTargetId&&!aiEnemies(scene,token).some(enemy=>enemy.id===board.priorityTargetId))board.priorityTargetId=null;
  }
  function aiObservableWoundScore(enemy){const info=criticalState(enemy);if(info.dead)return-100;if(info.critical)return14;const wounds=info.wounds||{};return safeNumber(wounds.serious,0)*8+safeNumber(wounds.medium,0)*3+safeNumber(wounds.light,0);}
  function aiEnemyWeaponThreat(enemy){const weapons=weaponsForToken(enemy).filter(w=>!w.unavailable);if(!weapons.length)return 0;return Math.max(...weapons.map(w=>Math.max(0,safeNumber(w.damage,0))*2+dieSides(w.hitDieNormal||w.hitDie||'1d4',4)*.6+(weaponIsHeavy(w)?4:0)+(safeNumber(w.radius,0)>0?3:0)));
  }
  function aiProtectedAlly(scene,token){
    const allies=aiAllies(scene,token);if(!allies.length)return null;return [...allies].sort((a,b)=>{const ar=aiResolvedRole(a,normalizeAiControl(a.ai)),br=aiResolvedRole(b,normalizeAiControl(b.ai));const av=(ar==='commander'?20:0)+(ar==='medic'?15:0)+aiObservableWoundScore(a),bv=(br==='commander'?20:0)+(br==='medic'?15:0)+aiObservableWoundScore(b);return bv-av;})[0]||null;
  }
  function aiTargetThreatScore(scene,attacker,enemy,role,board){
    const distance=distanceFeet(scene,attacker,enemy),cover=automaticCoverInfo(scene,speciesCombatPoint(attacker),speciesCombatPoint(enemy),{originToken:attacker}).mz,claims=safeNumber(board?.claims?.[enemy.id],0);let score=25+aiEnemyWeaponThreat(enemy)+aiObservableWoundScore(enemy)-distance*.045-cover*2.5-claims*4;
    if(board?.priorityTargetId===enemy.id)score+=14;if(board?.suppressedTargetId===enemy.id&&['assault','scout','monster'].includes(role))score+=8;
    if(role==='assault'||role==='monster')score-=distance*.07;
    if(role==='sniper')score+=Math.min(distance,160)*.025-cover*2;
    if(role==='grenadier'){const cluster=aiPointCluster(scene,attacker,aiEnemies(scene,attacker),15,9999);if(cluster?.inside?.some(item=>item.id===enemy.id))score+=cluster.inside.length*2;}
    if(role==='defender'){const ally=aiProtectedAlly(scene,attacker);if(ally)score+=Math.max(0,25-distanceFeet(scene,ally,enemy))*.35;}
    return score;
  }
  function aiSelectTarget(scene,attacker,visible,role,board){
    if(!visible.length)return null;let ranked=[...visible].map(enemy=>({enemy,score:aiTargetThreatScore(scene,attacker,enemy,role,board)})).sort((a,b)=>b.score-a.score);
    if(role==='commander'||!board.priorityTargetId){board.priorityTargetId=ranked[0]?.enemy.id||board.priorityTargetId;}
    if(board.priorityTargetId){ranked=ranked.map(item=>({enemy:item.enemy,score:item.score+(item.enemy.id===board.priorityTargetId?10:0)})).sort((a,b)=>b.score-a.score);}
    const target=ranked[0]?.enemy||null;if(target)board.claims[target.id]=safeNumber(board.claims[target.id],0)+1;return target;
  }
  function aiLatestRemembered(config,board,enemies){
    const allowed=new Set(enemies.map(enemy=>enemy.id)),items=[];for(const[id,memory]of Object.entries(config.lastSeen||{}))if(allowed.has(id))items.push({id,...memory,source:'self'});for(const[id,memory]of Object.entries(board?.lastSeen||{}))if(allowed.has(id))items.push({id,...memory,source:'squad'});items.sort((a,b)=>safeNumber(b.round,0)-safeNumber(a.round,0));return items[0]||null;
  }
  function aiPreferredDistance(role,weapon){
    const range=Math.max(5,safeNumber(weapon?.range,60));if(role==='monster')return5;if(role==='assault')return Math.min(25,Math.max(10,range*.25));if(role==='sniper')return Math.min(180,Math.max(60,range*.65));if(role==='gunner')return Math.min(110,Math.max(45,range*.45));if(role==='grenadier')return Math.min(75,Math.max(35,range*.4));if(role==='scout')return Math.min(60,Math.max(25,range*.35));if(role==='medic'||role==='commander'||role==='defender')return Math.min(80,Math.max(35,range*.4));return Math.min(70,Math.max(30,range*.4));
  }
  function aiPointDanger(scene,token,point,enemies){
    let danger=0;for(const effect of scene.effects||[]){if(effect.remainingRounds<=0)continue;const radius=feetToScenePixels(scene,safeNumber(effect.radius,0));if(radius>0&&Math.hypot(point.x-safeNumber(effect.x,0),point.y-safeNumber(effect.y,0))<=radius+.01){if(effect.zoneDamage)danger+=safeNumber(effect.zoneDamage,0)*8;if(['suppression','barrage','fire'].includes(effect.type))danger+=7;}}
    for(const enemy of enemies||[]){if(lineBlocked(scene,speciesCombatPoint(enemy),point))continue;const cover=automaticCoverInfo(scene,speciesCombatPoint(enemy),point,{originToken:enemy}).mz;danger+=Math.max(0,5-cover*.7);}return danger;
  }
  function aiPositionScore(scene,token,point,target,role,{enemies=aiEnemies(scene,token),allies=aiAllies(scene,token),weapon=null,anchor=null}={}){
    if(!target)return-9999;const targetPoint=speciesCombatPoint(target),distance=distanceFeet(scene,point,targetPoint),preferred=aiPreferredDistance(role,weapon),blocked=lineBlocked(scene,point,targetPoint),cover=automaticCoverInfo(scene,targetPoint,point,{originToken:target}).mz;let score=cover*8-Math.abs(distance-preferred)*.16-aiPointDanger(scene,token,point,enemies);
    if(blocked)score-=role==='scout'?12:45;else score+=8;
    for(const ally of allies){const spacing=distanceFeet(scene,point,speciesCombatPoint(ally));if(spacing<7.5)score-=8;else if(spacing<15)score-=2;}
    if(role==='sniper'){if(distance<35)score-=28;if(distance>=preferred*.75)score+=8;}
    if(role==='assault'&&distance<=25)score+=10;
    if(role==='monster'&&distance<=10)score+=24;
    if(role==='gunner'&&cover>0)score+=8;
    if(role==='scout'){const ally=[...allies].sort((a,b)=>distanceFeet(scene,a,target)-distanceFeet(scene,b,target))[0];if(ally){const va={x:speciesCombatPoint(ally).x-targetPoint.x,y:speciesCombatPoint(ally).y-targetPoint.y},vp={x:point.x-targetPoint.x,y:point.y-targetPoint.y},den=Math.max(1,Math.hypot(va.x,va.y)*Math.hypot(vp.x,vp.y)),dot=(va.x*vp.x+va.y*vp.y)/den;if(dot<.25)score+=12;}}
    if(anchor){const anchorDistance=distanceFeet(scene,point,speciesCombatPoint(anchor));if(role==='defender')score-=Math.abs(anchorDistance-10)*.22;if(role==='medic')score-=Math.max(0,anchorDistance-20)*.25;}
    return score;
  }
  function aiTacticalPositionCandidates(scene,token,target,role,weapon){
    const items=[],seen=new Set(),push=point=>{if(!point)return;const x=clamp(point.x,0,scene.mapWidth),y=clamp(point.y,0,scene.mapHeight),key=`${Math.round(x/8)}:${Math.round(y/8)}`;if(seen.has(key))return;seen.add(key);items.push({x,y});};push(speciesCombatPoint(token));const targetPoint=speciesCombatPoint(target),preferred=aiPreferredDistance(role,weapon),radii=[preferred,Math.max(10,preferred*.7)];
    for(const radiusFeet of radii){const radius=feetToScenePixels(scene,radiusFeet);for(let i=0;i<12;i++){const angle=Math.PI*2*i/12;push({x:targetPoint.x+Math.cos(angle)*radius,y:targetPoint.y+Math.sin(angle)*radius});}}
    const from=speciesCombatPoint(token),base=Math.atan2(from.y-targetPoint.y,from.x-targetPoint.x),flankRadius=feetToScenePixels(scene,Math.max(15,preferred*.75));for(const delta of [-Math.PI/2,Math.PI/2])push({x:targetPoint.x+Math.cos(base+delta)*flankRadius,y:targetPoint.y+Math.sin(base+delta)*flankRadius});
    for(const cover of (scene.covers||[]).slice(0,24)){if(cover.destroyed||safeNumber(cover.mz,0)<=0)continue;const center=coverReferencePoint(cover),dx=center.x-targetPoint.x,dy=center.y-targetPoint.y,len=Math.max(1,Math.hypot(dx,dy)),offset=movementCollisionRadius(scene,token)+Math.max(10,safeNumber(cover.thickness,18));push({x:center.x+dx/len*offset,y:center.y+dy/len*offset});}
    return items;
  }
  function aiBestTacticalPosition(scene,token,target,role,weapon){
    if(!target)return null;const enemies=aiEnemies(scene,token),allies=aiAllies(scene,token),anchor=role==='defender'||role==='medic'?aiProtectedAlly(scene,token):null,current=speciesCombatPoint(token),currentScore=aiPositionScore(scene,token,current,target,role,{enemies,allies,weapon,anchor});const ranked=aiTacticalPositionCandidates(scene,token,target,role,weapon).map(point=>({point,score:aiPositionScore(scene,token,point,target,role,{enemies,allies,weapon,anchor})})).sort((a,b)=>b.score-a.score).slice(0,10);
    for(const candidate of ranked){if(candidate.score<currentScore+4)break;if(distanceFeet(scene,current,candidate.point)<3)continue;const route=aiFindRoute(scene,token,candidate.point);if(route?.length>1)return{...candidate,route,currentScore};}return null;
  }
  function aiSetPlan(config,type,point,targetId,scene,round){config.plan={type,x:point.x,y:point.y,targetId:targetId||null,sceneId:scene.id,createdRound:round,expiresRound:round+2};return config.plan;}
  function aiPlanPoint(config,scene,round,targetId=null){const plan=config.plan;if(!plan||plan.sceneId!==scene.id||plan.expiresRound<round||(targetId&&plan.targetId&&plan.targetId!==targetId)){config.plan=null;return null;}return{x:plan.x,y:plan.y};}
  function aiRetreatPoint(scene,token,enemies){const from=speciesCombatPoint(token),visible=(enemies||[]).filter(enemy=>!lineBlocked(scene,from,speciesCombatPoint(enemy))),sources=visible.length?visible:enemies;if(!sources?.length)return{x:clamp(from.x,0,scene.mapWidth),y:clamp(from.y,0,scene.mapHeight)};const center=sources.reduce((acc,item)=>{const p=speciesCombatPoint(item);acc.x+=p.x;acc.y+=p.y;return acc;},{x:0,y:0});center.x/=sources.length;center.y/=sources.length;let dx=from.x-center.x,dy=from.y-center.y,len=Math.hypot(dx,dy);if(len<1){dx=from.x-scene.mapWidth/2;dy=from.y-scene.mapHeight/2;len=Math.max(1,Math.hypot(dx,dy));}const distance=feetToScenePixels(scene,Math.max(30,movementSummary(token)?.remaining||30));return{x:clamp(from.x+dx/len*distance,0,scene.mapWidth),y:clamp(from.y+dy/len*distance,0,scene.mapHeight)};}
  function aiShouldRepositionBeforeAttack(scene,token,target,role,weapon,currentCover,morale){const distance=distanceFeet(scene,token,target),preferred=aiPreferredDistance(role,weapon);if(morale.state==='shaken'||morale.state==='cautious')return currentCover<=0;if(role==='sniper')return distance<preferred*.55||currentCover<=0;if(role==='gunner'||role==='defender')return currentCover<=0;if(role==='scout')return currentCover<=0&&distance>15;return false;}
  async function aiTryMedic(scene,token,allies,body,steps,config,round){
    const candidates=(allies||[]).filter(ally=>{const info=criticalState(ally);return info.critical&&!info.dead;}).sort((a,b)=>contactDistanceFeet(scene,token,a)-contactDistanceFeet(scene,token,b));if(!candidates.length)return false;const target=candidates[0],contact=contactDistanceFeet(scene,token,target),reach=Math.max(5,meleeReachFeet(scene,token,target));
    if(contact<=reach+.01&&!contactBlockedByWall(scene,speciesCombatPoint(token),speciesCombatPoint(target))&&aiOd(token)>=2&&!failedStabilizerIdsFor(target).includes(stabilizerIdentity(token))){spendTokenOd(token,2);const result=await performStabilization(scene,token,target,{...body,clientId:null,playerName:`ИИ: ${token.name}`});const check=result.check,entry=appendTableLog({type:'roll',actorId:null,actorName:`ИИ: ${token.name}`,text:`${token.name} стабилизирует ${target.name}: ${check.successTotal} против ${check.difficultyTotal??check.difficultyRoll} — ${result.success?'успех':result.outcome==='critical-failure'?'критический провал':'провал'}. ${result.resultText}`,sceneId:scene.id,tokenId:token.id,meta:{formulas:[`${check.successDie}${signedFormulaBonus(check.bonus)} vs ${check.difficultyDie}${signedFormulaBonus(check.difficultyModifier||0)}`]}});broadcastTableLog(entry);steps.push({type:'medical-stabilize',target:target.name,result});config.plan=null;await wait(420);return true;}
    const movement=movementSummary(token);if(movement?.remaining>.1){aiSetPlan(config,'medic',speciesCombatPoint(target),target.id,scene,round);if(await aiMoveToward(scene,token,speciesCombatPoint(target),body,steps))return true;}return false;
  }
  async function runNpcAiTurn(scene,token,body={}){
    const steps=[],config=normalizeAiControl(token.ai);token.ai=config;if(token.kind!=='npc'||!config.enabled)throw Object.assign(new Error('Для этого NPC ИИ не включён.'),{statusCode:409});assertTokenCanAct(token,{});
    const start={x:token.x,y:token.y},round=getCampaign().initiative?.round||0,role=aiResolvedRole(token,config),board=aiSquadBoard(scene,token);let enemies=aiEnemies(scene,token);if(!enemies.length){steps.push({type:'wait',reason:'Нет враждебных целей.'});return{steps,role,morale:aiMoralePosture(token),squadTargetId:board.priorityTargetId};}
    let guard=0;
    while(aiOd(token)>0&&guard++<10&&aiAliveCombatToken(token)){
      enemies=aiEnemies(scene,token);if(!enemies.length)break;const origin=speciesCombatPoint(token),visibleRaw=enemies.filter(enemy=>!lineBlocked(scene,origin,speciesCombatPoint(enemy))),morale=aiMoralePosture(token);aiRememberSquadVisible(scene,token,visibleRaw,config,board);const shootTarget=aiSelectTarget(scene,token,visibleRaw,role,board),visible=shootTarget?[shootTarget,...visibleRaw.filter(item=>item.id!==shootTarget.id)]:visibleRaw,remembered=aiLatestRemembered(config,board,enemies),engaged=hostileMeleeOpponents(scene,token).filter(enemy=>!enemy.hidden&&enemies.some(item=>item.id===enemy.id));

      if(morale.state==='broken'){
        if(engaged.length&&aiOd(token)>=2&&!tokenActions(token).retreat)aiUseTacticalAction(token,'retreat',steps);const away=aiRetreatPoint(scene,token,enemies);aiSetPlan(config,'retreat',away,null,scene,round);const movement=movementSummary(token);if(movement?.remaining>.1){if(!tokenActions(token).sprint)aiUseTacticalAction(token,'sprint',steps);if(await aiMoveToward(scene,token,away,body,steps))continue;}if(aiOd(token)>=1&&!tokenActions(token).block)aiUseTacticalAction(token,'block',steps);steps.push({type:'wait',reason:'Мораль сломлена: NPC пытается выйти из боя.'});break;
      }

      const allies=aiAllies(scene,token);if(role==='medic'&&await aiTryMedic(scene,token,allies,body,steps,config,round))continue;

      if(engaged.length){
        const target=aiSelectTarget(scene,token,engaged,role,board)||engaged[0],allWeapons=weaponsForToken(token).filter(w=>!w.unavailable),shotguns=allWeapons.filter(w=>weaponIsShotgun(w)&&w.loaded!==false),ranged=allWeapons.filter(weaponIsRanged),shouldWithdraw=(config.profile==='defensive'||config.profile==='support'||['sniper','gunner','medic','commander','scout'].includes(role)||morale.state==='shaken'||morale.state==='cautious');
        if(shouldWithdraw&&ranged.length&&!shotguns.length&&aiOd(token)>=2&&aiUseTacticalAction(token,'retreat',steps)){const away=aiRetreatPoint(scene,token,[target]);if(await aiMoveToward(scene,token,away,body,steps))continue;}
        const cone=shotguns.filter(w=>w.coneAttack&&safeNumber(w.coneFeet,0)>0).sort((a,b)=>aiWeaponScore(b)-aiWeaponScore(a))[0];if(cone&&aiOd(token)>=safeNumber(cone.odCost,2)&&await aiShotgunCone(scene,token,cone,engaged,body,steps))continue;
        const single=shotguns.filter(w=>!w.coneAttack||w.singleTargetOnly).sort((a,b)=>aiWeaponScore(b,distanceFeet(scene,token,target))-aiWeaponScore(a,distanceFeet(scene,token,target)))[0];if(single&&aiOd(token)>=safeNumber(single.odCost,2)){await aiRangedAttack(scene,token,target,single,body,steps);continue;}
        const weapon=meleeWeaponForToken(token,null);if(aiOd(token)<safeNumber(weapon.odCost,2))break;await aiMeleeAttack(scene,token,target,weapon,body,steps);continue;
      }

      const weapons=weaponsForToken(token).filter(w=>!w.unavailable),ranged=weapons.filter(weaponIsRanged).filter(w=>w.loaded!==false),bestRanged=shootTarget?[...ranged].sort((a,b)=>aiWeaponScore(b,distanceFeet(scene,token,shootTarget))-aiWeaponScore(a,distanceFeet(scene,token,shootTarget)))[0]:null,interactiveOpportunity=aiInteractiveOpportunity(scene,token,visible),heavyUnloaded=weapons.find(w=>weaponIsHeavy(w)&&w.loaded===false),crossbowUnloaded=weapons.find(w=>w.specialRangedKind==='crossbow'&&w.loaded===false);
      if(interactiveOpportunity&&role!=='medic'&&await aiShootInteractiveObject(scene,token,interactiveOpportunity,body,steps))continue;
      if(heavyUnloaded&&aiOd(token)>=heavyReloadCost(heavyUnloaded)){const result=reloadHeavyWeapon(token,heavyUnloaded);broadcastAudioEffect(scene.id,/гранатом[её]т/i.test(weaponText(heavyUnloaded))?'heavy.reload.grenadeLauncher':'heavy.reload.machinegun',{tokenId:token.id,x:token.x,y:token.y},null);steps.push({type:'reload',weapon:heavyUnloaded.name,cost:result.cost});await wait(250);continue;}
      if(crossbowUnloaded&&aiOd(token)>=specialRangedReloadCost(crossbowUnloaded)){try{const result=reloadSpecialRangedWeapon(token,crossbowUnloaded);steps.push({type:'crossbow-reload',weapon:crossbowUnloaded.name,cost:result.cost});await wait(220);continue;}catch(error){/* heavy crossbow may be unable to reload after movement; choose another action */}}
      const currentCover=shootTarget?automaticCoverInfo(scene,speciesCombatPoint(shootTarget),speciesCombatPoint(token),{originToken:shootTarget}).mz:0;
      if(shootTarget&&tokenAdjacentToCover(scene,token)&&!tokenActions(token).peek)aiUseTacticalAction(token,'peek',steps);

      if(shootTarget&&bestRanged&&aiShouldRepositionBeforeAttack(scene,token,shootTarget,role,bestRanged,currentCover,morale)){
        let destination=aiPlanPoint(config,scene,round,shootTarget.id),tactical=null;if(!destination){tactical=aiBestTacticalPosition(scene,token,shootTarget,role,bestRanged);if(tactical){destination=tactical.point;aiSetPlan(config,'position',destination,shootTarget.id,scene,round);}}
        if(destination&&distanceFeet(scene,token,destination)>3&&await aiMoveToward(scene,token,destination,body,steps))continue;config.plan=null;
      }

      const inRange=ranged.filter(w=>shootTarget&&distanceFeet(scene,token,shootTarget)<=safeNumber(w.range,0)+.01);
      if(config.useSpecials&&(role==='gunner'||config.profile==='support')){const suppression=inRange.find(w=>weaponSupportsSuppression(w)&&aiOb(token)>0);if(suppression&&await aiWeaponZone(scene,token,suppression,visible,'suppression',body,steps)){board.suppressedTargetId=shootTarget?.id||null;continue;}}
      if(config.useGrenades&&visible.length&&(role==='grenadier'||role==='assault'||config.profile!=='defensive')&&await aiThrowGrenade(scene,token,visible,body,steps))continue;
      const areaWeapon=shootTarget?weapons.filter(w=>safeNumber(w.radius,0)>0&&w.loaded!==false&&distanceFeet(scene,token,shootTarget)<=safeNumber(w.range,0)+.01).sort((a,b)=>aiWeaponScore(b)-aiWeaponScore(a))[0]:null;if(areaWeapon&&await aiAreaWeaponAttack(scene,token,areaWeapon,visible,body,steps))continue;
      const cone=inRange.filter(w=>w.coneAttack&&safeNumber(w.coneFeet,0)>0).sort((a,b)=>aiWeaponScore(b)-aiWeaponScore(a))[0];if(cone&&aiOd(token)>=safeNumber(cone.odCost,2)&&await aiShotgunCone(scene,token,cone,visible,body,steps))continue;
      if(config.useSpecials){const barrage=inRange.find(w=>weaponSupportsBarrage(w)&&aiOb(token)>0);if(barrage&&(role==='gunner'||role==='grenadier'||config.profile==='support')&&await aiWeaponZone(scene,token,barrage,visible,'barrage',body,steps))continue;}
      const weapon=[...inRange].filter(w=>!w.coneAttack||w.singleTargetOnly).sort((a,b)=>aiWeaponScore(b,distanceFeet(scene,token,shootTarget))-aiWeaponScore(a,distanceFeet(scene,token,shootTarget)))[0];if(weapon&&shootTarget&&aiOd(token)>=safeNumber(weapon.odCost,2)){config.plan=null;await aiRangedAttack(scene,token,shootTarget,weapon,body,steps);continue;}

      if(config.preferCover&&shootTarget&&(config.profile==='defensive'||morale.state!=='steady')&&currentCover<=0){const cover=aiCoverPoint(scene,token,shootTarget);if(cover&&await aiMoveToward(scene,token,cover.point,body,steps))continue;}
      const movement=movementSummary(token);if(!movement||movement.remaining<=.1)break;
      let destination=null,reason='search';const planned=aiPlanPoint(config,scene,round,shootTarget?.id||null);if(planned){destination=planned;reason=config.plan?.type||'plan';}
      else if(shootTarget){const tactical=aiBestTacticalPosition(scene,token,shootTarget,role,bestRanged||weapons[0]);if(tactical&&role!=='monster'){destination=tactical.point;reason='tactical-position';aiSetPlan(config,'position',destination,shootTarget.id,scene,round);}else{destination=speciesCombatPoint(shootTarget);reason='visible-enemy';}}
      else if(remembered){destination={x:remembered.x,y:remembered.y};reason=remembered.source==='squad'?'squad-last-seen':'last-seen';aiSetPlan(config,'search',destination,remembered.id,scene,round);}
      else{const door=(scene.doors||[]).filter(item=>!item.open&&!item.locked).sort((a,b)=>Math.hypot(doorGeometry(scene,a).center.x-token.x,doorGeometry(scene,a).center.y-token.y)-Math.hypot(doorGeometry(scene,b).center.x-token.x,doorGeometry(scene,b).center.y-token.y))[0];if(door){destination=doorGeometry(scene,door).center;reason='door-search';}else{const patrol=[{x:scene.mapWidth*.2,y:scene.mapHeight*.2},{x:scene.mapWidth*.8,y:scene.mapHeight*.2},{x:scene.mapWidth*.8,y:scene.mapHeight*.8},{x:scene.mapWidth*.2,y:scene.mapHeight*.8},{x:scene.mapWidth*.5,y:scene.mapHeight*.5}];destination=patrol[config.searchStep++%patrol.length];reason='patrol';}}
      const distanceToGoal=distanceFeet(scene,token,destination),aggressiveMove=config.profile==='aggressive'||['assault','monster'].includes(role);if(shootTarget&&aggressiveMove&&!inRange.length&&distanceToGoal>5&&!tokenActions(token).charge)aiUseTacticalAction(token,'charge',steps);if((distanceToGoal>movement.remaining+5||config.stationaryTurns>=1)&&!tokenActions(token).sprint)aiUseTacticalAction(token,'sprint',steps);if(visible.length&&currentCover<=0&&!tokenActions(token).crossing&&role!=='monster')aiUseTacticalAction(token,'crossing',steps);
      if(!await aiMoveToward(scene,token,destination,body,steps)){config.searchStep++;config.plan=null;if(aiOd(token)>=1&&!tokenActions(token).block)aiUseTacticalAction(token,'block',steps);steps.push({type:'wait',reason:`Маршрут не найден (${reason}).`});break;}
    }
    const moved=distanceFeet(scene,start,token),morale=aiMoralePosture(token);config.stationaryTurns=moved<1?config.stationaryTurns+1:0;config.lastPosition={x:token.x,y:token.y};token.ai=config;if(!steps.length)steps.push({type:'wait',reason:'Нет допустимого действия по правилам, дальности или линии огня.'});return{steps,role,roleLabel:AI_ROLE_LABELS[role]||role,morale,visibleEnemyIds:Object.keys(config.lastSeen),stationaryTurns:config.stationaryTurns,squadTargetId:board.priorityTargetId,squadKey:board.key};
  }

  function gmTokenStatsSnapshot(token){
    if(!token)return null;const character=linkedCharacter(token),npc=linkedNpc(token);
    if(character){const st=ensureSpeciesRuntime(character.state||(character.state={}))||{};ensureCharacterMedicalState(st);return{type:'character',tokenId:token.id,name:token.name,wounds:{light:safeNumber(st.wounds.light,0),lightMax:safeNumber(st.wounds.lightMax,2),medium:safeNumber(st.wounds.medium,0),mediumMax:safeNumber(st.wounds.mediumMax,1),serious:safeNumber(st.wounds.serious,0),seriousMax:safeNumber(st.wounds.seriousMax,1),critical:Boolean(st.wounds.critical)},morale:{current:safeNumber(st.morale?.current,0),max:safeNumber(st.morale?.max,0)},od:{current:safeNumber(st.odCurrent,st.od||0),max:safeNumber(st.od,0)},ob:{current:safeNumber(st.obCurrent,st.ob||0),max:safeNumber(st.ob,0)},speed:{effective:tokenSpeedFeet(token),bonus:safeNumber(st.speedBonus,0)},mzOverride:token.mzOverride,bz:{current:safeNumber(st.bz,0),max:safeNumber(st.armorBzMax,Math.max(0,safeNumber(st.bz,0)))},dead:Boolean(st.medical?.dead||token.defeated),bleeding:Boolean(st.medical?.bleeding)};}
    if(npc){npc.wounds ||= {light:0,lightMax:1,medium:0,mediumMax:0,serious:0,seriousMax:0,critical:false};npc.morale ||= {current:0,max:0};npc.od ||= {current:0,max:0};npc.ob ||= {current:0,max:0};npc.armor ||= {bzCurrent:0,bzMax:0};return{type:'npc',tokenId:token.id,name:token.name,wounds:{light:safeNumber(npc.wounds.light,0),lightMax:safeNumber(npc.wounds.lightMax,1),medium:safeNumber(npc.wounds.medium,0),mediumMax:safeNumber(npc.wounds.mediumMax,0),serious:safeNumber(npc.wounds.serious,0),seriousMax:safeNumber(npc.wounds.seriousMax,0),critical:Boolean(npc.wounds.critical)},morale:{current:safeNumber(npc.morale.current,0),max:safeNumber(npc.morale.max,0)},od:{current:safeNumber(npc.od.current,0),max:safeNumber(npc.od.max,0)},ob:{current:safeNumber(npc.ob.current,npc.obCurrent||0),max:safeNumber(npc.ob.max,npc.obCurrent||0)},speed:{effective:tokenSpeedFeet(token),bonus:0},mzOverride:token.mzOverride,bz:{current:safeNumber(npc.armor.bzCurrent,0),max:safeNumber(npc.armor.bzMax,0)},dead:Boolean(npc.dead||npc.outOfCombat||token.defeated),bleeding:Boolean(npc.bleeding)};}
    return{type:token.kind,tokenId:token.id,name:token.name,mzOverride:token.mzOverride,dead:Boolean(token.defeated)};
  }
  function gmSetResource(pair,current,max,maxLimit=999){pair.max=clamp(Math.round(safeNumber(max,pair.max||0)),0,maxLimit);pair.current=clamp(Math.round(safeNumber(current,pair.current||0)),0,pair.max);}
  function reviveTokenForGm(token){const info=criticalState(token);if(['character','npc'].includes(token.kind)){info.wounds.critical=false;info.medical.dead=false;info.medical.stabilized=false;info.medical.criticalRounds=0;info.medical.bleeding=false;info.medical.failedStabilizers=[];info.medical.failedStabilizerIds=[];delete info.medical._criticalSkipCurrentTurn;delete info.medical._battlemapDeathHandled;delete info.host._battlemapDeathHandled;if(token.kind==='npc'){const npc=linkedNpc(token);if(npc){npc.dead=false;npc.outOfCombat=false;}}}token.defeated=false;}
  function applyGmTokenStats(scene,token,body={}){
    const character=linkedCharacter(token),npc=linkedNpc(token),w=body.wounds&&typeof body.wounds==='object'?body.wounds:null;
    if(character){const st=ensureSpeciesRuntime(character.state||(character.state={}))||{};ensureCharacterMedicalState(st);st.morale ||= {current:0,max:0};if(w){for(const type of ['light','medium','serious']){const maxKey=`${type}Max`;if(w[maxKey]!==undefined)st.wounds[maxKey]=clamp(Math.round(safeNumber(w[maxKey],st.wounds[maxKey])),0,99);if(w[type]!==undefined)st.wounds[type]=clamp(Math.round(safeNumber(w[type],st.wounds[type])),0,Math.max(0,safeNumber(st.wounds[maxKey],99)));}if(w.critical!==undefined)st.wounds.critical=Boolean(w.critical);}
      if(body.morale)gmSetResource(st.morale,body.morale.current,body.morale.max,999);if(body.od){st.od=clamp(Math.round(safeNumber(body.od.max,st.od||0)),0,20);st.odCurrent=clamp(Math.round(safeNumber(body.od.current,st.odCurrent??st.od)),0,st.od);}if(body.ob){st.ob=clamp(Math.round(safeNumber(body.ob.max,st.ob||0)),0,99);st.obCurrent=clamp(Math.round(safeNumber(body.ob.current,st.obCurrent??st.ob)),0,st.ob);}if(body.bz){st.armorBzMax=clamp(Math.round(safeNumber(body.bz.max,st.armorBzMax||0)),0,99);st.bz=clamp(Math.round(safeNumber(body.bz.current,st.bz||0)),0,st.armorBzMax);}if(body.speedDelta!==undefined){const delta=clamp(Math.round(safeNumber(body.speedDelta,0)),-200,200);st.speedBonus=safeNumber(st.speedBonus,0)+delta;st.speed=Math.max(0,safeNumber(st.speed,30)+delta);}character.updatedAt=nowIso();}
    else if(npc){npc.wounds ||= {light:0,lightMax:1,medium:0,mediumMax:0,serious:0,seriousMax:0,critical:false};if(w){for(const type of ['light','medium','serious']){const maxKey=`${type}Max`;if(w[maxKey]!==undefined)npc.wounds[maxKey]=clamp(Math.round(safeNumber(w[maxKey],npc.wounds[maxKey])),0,99);if(w[type]!==undefined)npc.wounds[type]=clamp(Math.round(safeNumber(w[type],npc.wounds[type])),0,Math.max(0,safeNumber(npc.wounds[maxKey],99)));}if(w.critical!==undefined)npc.wounds.critical=Boolean(w.critical);}npc.morale ||= {current:0,max:0};npc.od ||= {current:0,max:0};npc.ob ||= {current:0,max:0};npc.armor ||= {bzCurrent:0,bzMax:0};if(body.morale)gmSetResource(npc.morale,body.morale.current,body.morale.max,999);if(body.od)gmSetResource(npc.od,body.od.current,body.od.max,20);if(body.ob)gmSetResource(npc.ob,body.ob.current,body.ob.max,99);if(body.bz){npc.armor.bzMax=clamp(Math.round(safeNumber(body.bz.max,npc.armor.bzMax||0)),0,99);npc.armor.bzCurrent=clamp(Math.round(safeNumber(body.bz.current,npc.armor.bzCurrent||0)),0,npc.armor.bzMax);}if(body.speedDelta!==undefined)npc.speed=Math.max(0,safeNumber(npc.speed,30)+clamp(Math.round(safeNumber(body.speedDelta,0)),-200,200));npc.updatedAt=nowIso();}
    if(body.mzOverride!==undefined)token.mzOverride=body.mzOverride===null||body.mzOverride===''?null:clamp(Math.round(safeNumber(body.mzOverride,4)),0,99);
    if(body.lifeAction==='kill'&&['character','npc'].includes(token.kind))markTokenDead(scene,token,body,'Мгновенное действие Мастера');else if(body.lifeAction==='revive')reviveTokenForGm(token);
    token.updatedAt=scene.updatedAt=nowIso();return gmTokenStatsSnapshot(token);
  }
  async function handleApi(req, res, requestUrl) {
    const pathname = requestUrl.pathname;
    if (!pathname.startsWith('/api/battlemap')) return false;

    if (pathname === '/api/battlemap' && req.method === 'GET') {
      const mode = requestUrl.searchParams.get('mode') === 'master' ? 'master' : 'player';
      if (mode === 'master' && !isMasterAuthorized(req, requestUrl)) { sendJson(res, 403, { ok: false, error: 'Это действие доступно только мастеру.' }); return true; }
      const clientId = cleanId(requestUrl.searchParams.get('clientId'), null);
      sendJson(res, 200, { ok: true, battlemap: viewFor(mode, clientId), features: { maps:true,tokens:true,walls:true,curvedWalls:true,doors:true,covers:true,curvedCovers:true,fog:true,vision:true,lights:true,globalDaylight:true,audioSources:true,vehicles:true,hitAnimations:true,attacks:true,combatMode:true,possession:true,mapSkillChecks:true,diceVisuals:true,miniSheets:true,actionDock:true,melee:true,liveEditing:true,wasdMovement:true,weatherLayers:true,parallaxLayers:true,parallaxObjects:true,pseudo3d:true,mapPing:true,mapDrawing:true,peekFromCover:true,damageAudio:true,sceneDeletion:true,mapDeletion:true,clearSceneObjects:true,deleteKey:true,objectClipboard:true,coverTemplates:true,autoTokenRotation:true,multiAudioUpload:true,progressiveMaps:true,mapPreload:true,mapOptimization:true,meleeWeaponProfiles:true,projectileVisuals:true,elevationRules:true,elevationZones:true,masterPause:true,forcedCheckZones:true,aberrantGifts:true,zoneFireVisuals:true,weatherAudio:true,heavyWeaponReload:true,specialRangedReadiness:true,bowDraw:true,crossbowReload:true,coverDestruction:true,zoneFireLineVisibility:true,triggerZoneOneShot:true,shotgunCones:true,canonicalTraumas:true,clickTokenPlacement:true,coreAudioLibrary:true,sharedAudioLibrary:true,lazyAudioSources:true,boundedAudioCache:true,tokenGroups:true,globalTokenGroups:true,dynamicCombatParticipants:true,narrativeCombatControl:true,criticalCountdown:true,medicalStabilization:true,bleedingTurnDamage:true,npcTacticalAi:true,npcTacticalAiV2:true,groupRelations:true,dualSkillDiceVisual:true,oneShotZoneAudio:true,heavyReloadAudio:true,playerSidebarRestricted:true,triggerZoneCombatStart:true,tokenGroupMarkerToggle:true,combatMovementRange:true,adjacentContactActions:true,tokenCellCollision:true,masterForceMovement:true,masterMovementModes:true,gridMovementCells:true,cellBasedContactDistance:true,npcCreatureTypes:true,customAttackBuilder:true,customWeaponProfiles:true,customAttackAudio:true,naturalAttackAudio:true,shotgunMeleeFire:true,interactiveObjects:true,mobileObjectCover:true,vehicleCoverMz:true,interactiveObjectShotChecks:true,thrownGrenadeReactions:true,grenadeDiveCover:true,grenadeOdDebt:true,optionalOpportunityAttacks:true,bowCrossbowInventoryAmmo:true,characterCompendium:true,manualOneShotAudio:true,alphabeticalSkillChecks:true,splitLostLimbTrauma:true,sniperTactics:true,counterSniperObservation:true,combatStealth:true,sceneStealth:true,hiddenStealthTokens:true,weaponModCombat:true,weaponModActions:true,badVisibilityRule:true,vehicleSeats:true,vehicleMountedWeapons:true,vehicleBuilder:true,vehicleActionAnimations:true,mapWidgets:true,gmCounters:true,playerMarkers:true } });
      return true;
    }

    if (pathname === '/api/battlemap/audio/catalog' && req.method === 'GET') {
      if (!isMasterAuthorized(req, requestUrl)) { sendJson(res,403,{ok:false,error:'Библиотека звуков оружия доступна только мастеру.'}); return true; }
      sendJson(res,200,{ok:true,items:combinedAudioLibrary().filter(item=>item.kind==='effect').map(item=>({id:item.id,name:item.name,kind:item.kind,scope:item.scope,url:item.url,mime:item.mime,size:item.size}))});
      return true;
    }
    if (pathname === '/api/battlemap/audio/one-shot' && req.method === 'POST') {
      const body=await readJsonBody(req);if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Одиночный звук может запускать только мастер.'});return true;}
      const trackId=cleanId(body.trackId,null),item=audioItemById(trackId);if(!item||item.kind!=='effect'){sendJson(res,404,{ok:false,error:'Выберите звуковой эффект из аудиобиблиотеки.'});return true;}
      const volume=clamp(safeNumber(body.volume,1),0,1);broadcastOneShotAudio(item.id,volume,cleanId(body.clientId,null));sendJson(res,200,{ok:true,trackId:item.id,name:item.name,volume});return true;
    }

    if (pathname === '/api/battlemap/pause' && req.method === 'PUT') {
      const body=await readJsonBody(req);if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Мастерскую паузу может переключать только мастер.'});return true;}
      state.masterPause={active:Boolean(body.active),reason:cleanText(body.reason||'',300),activatedAt:body.active?nowIso():null};await persist();
      const entry=appendTableLog({type:'system',actorName:'Мастер',actorId:cleanId(body.clientId,null),text:state.masterPause.active?`Мастерская пауза${state.masterPause.reason?`: ${state.masterPause.reason}`:''}.`:'Мастерская пауза снята.',sceneId:state.activeSceneId});broadcastTableLog(entry);broadcast('battlemap-replaced',body.clientId,{reason:'master-pause'});sendJson(res,200,{ok:true,masterPause:clone(state.masterPause)});return true;
    }

    if (state.masterPause?.active && !['GET','HEAD'].includes(req.method) && !pathname.startsWith('/api/battlemap/chat') && !isMasterAuthorized(req, requestUrl)) {
      sendJson(res, 423, { ok:false, error:'Игра поставлена на мастерскую паузу. Действия игроков временно заблокированы.', masterPause:clone(state.masterPause) }); return true;
    }

    if (pathname === '/api/battlemap/audio/upload' && req.method === 'POST') {
      const bodyAuth={master:requestUrl.searchParams.get('master')==='1'};if(!isMasterAuthorized(req,requestUrl,bodyAuth)){sendJson(res,403,{ok:false,error:'Загружать аудио может только мастер.'});return true;}
      const originalName = cleanName(requestUrl.searchParams.get('name'), 'audio', 180);
      const kind=cleanAudioKind(requestUrl.searchParams.get('kind'));
      const scope=requestUrl.searchParams.get('scope')==='shared'?'shared':'campaign';
      const mime = cleanText(req.headers?.['content-type'] || '', 100).split(';')[0].trim().toLowerCase();
      const ext = audioExtension(mime, originalName);
      if(!ext){sendJson(res,400,{ok:false,error:'Поддерживаются MP3, OGG, WAV, WEBM, M4A и AAC.'});return true;}
      const buffer=await readBinaryBody(req,48*1024*1024);if(!buffer.length){sendJson(res,400,{ok:false,error:'Пустой аудиофайл.'});return true;}
      const base = path.basename(originalName, path.extname(originalName)).replace(/[^A-Za-z0-9_.-]+/g,'_').slice(0,80) || 'audio';
      const fileName=`${base}-${Date.now()}-${Math.random().toString(16).slice(2,8)}.${ext}`;
      const folder=scope==='shared'?SHARED_AUDIO_DIR:AUDIO_DIR;await fs.promises.mkdir(folder,{recursive:true});await fs.promises.writeFile(path.join(folder,fileName),buffer);
      const rawId=makeId('audio'),item={id:scope==='shared'?`shared:${audioSlug(rawId)}`:rawId,name:originalName,kind,scope,fileName,url:scope==='shared'?`/shared-audio/${fileName}`:`/audio/${fileName}`,mime,size:buffer.length,uploadedAt:nowIso(),readOnly:false};
      if(scope==='shared'){sharedAudioLibrary.push(item);await persistSharedAudioLibrary();}
      else{state.audio ||= makeEmptyAudioState();state.audio.library.push(item);state.audio=normalizeAudioState(state.audio);await persist();}
      broadcast('battlemap-replaced',null,{reason:`audio-uploaded-${scope}`});sendJson(res,201,{ok:true,item,audio:audioView(),warning:(ext==='wav'||(kind==='effect'&&buffer.length>5*1024*1024)||(kind!=='effect'&&buffer.length>25*1024*1024))?'Файл крупный; для Radmin лучше OGG/MP3 меньшего размера.':null});return true;
    }
    if (pathname === '/api/battlemap/audio/channel'  && req.method === 'PUT') {
      const body = await readJsonBody(req); if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res,403,{ok:false,error:'Управлять аудио может только мастер.'}); return true; }
      const name = body.channel === 'ambient' ? 'ambient' : 'music'; state.audio ||= makeEmptyAudioState();
      const channel = state.audio.channels[name];
      if (body.trackId !== undefined) {
        const trackId = cleanId(body.trackId, null); const item = audioItemById(trackId);
        channel.trackId = item?.id || null; channel.position = 0; channel.startedAt = null; channel.playing = false;
      }
      if (body.volume !== undefined) channel.volume = clamp(safeNumber(body.volume, channel.volume),0,1);
      if (body.loop !== undefined) channel.loop = Boolean(body.loop);
      const action = String(body.action||'');
      if (action === 'play') { channel.position = body.position !== undefined ? Math.max(0,safeNumber(body.position,0)) : currentChannelPosition(channel); channel.startedAt=nowIso(); channel.playing=Boolean(channel.trackId); }
      else if (action === 'pause') { channel.position=currentChannelPosition(channel); channel.startedAt=null; channel.playing=false; }
      else if (action === 'stop') { channel.position=0; channel.startedAt=null; channel.playing=false; }
      else if (body.position !== undefined) { channel.position=Math.max(0,safeNumber(body.position,0)); if(channel.playing)channel.startedAt=nowIso(); }
      channel.updatedAt=nowIso(); state.audio=normalizeAudioState(state.audio); await persist(); broadcast('battlemap-replaced',body.clientId,{reason:'audio-channel'}); sendJson(res,200,{ok:true,audio:audioView()}); return true;
    }
    if (pathname === '/api/battlemap/audio/bindings' && req.method === 'PUT') {
      const body=await readJsonBody(req); if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Настраивать звуки может только мастер.'});return true;}
      state.audio ||= makeEmptyAudioState(); const bindings=body.bindings&&typeof body.bindings==='object'?body.bindings:{}; const ids=combinedAudioIds();
      for(const key of AUDIO_EFFECT_KEYS) if(bindings[key]!==undefined){const rawValue=bindings[key];if(rawValue==='off')state.audio.effectBindings[key]='off';else{const value=cleanId(rawValue,null);state.audio.effectBindings[key]=ids.has(value)?value:null;}}
      state.audio=normalizeAudioState(state.audio);await persist();broadcast('battlemap-replaced',body.clientId,{reason:'audio-bindings'});sendJson(res,200,{ok:true,audio:audioView()});return true;
    }
    const audioDelete = pathname.match(/^\/api\/battlemap\/audio\/([^/]+)$/);
    if (audioDelete && req.method === 'DELETE') {
      const body=await readJsonBody(req).catch(()=>({}));if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Удалять аудио может только мастер.'});return true;}
      const audioId=cleanId(decodeURIComponent(audioDelete[1]),null),item=audioItemById(audioId);if(!item){sendJson(res,404,{ok:false,error:'Аудиофайл не найден.'});return true;}
      if(item.scope==='core'){sendJson(res,400,{ok:false,error:'Встроенные звуки удаляются только из папки public/assets/audio/core с последующим пересканированием.'});return true;}
      if(item.scope==='shared'){sharedAudioLibrary=sharedAudioLibrary.filter(x=>x.id!==audioId);try{await fs.promises.unlink(path.join(SHARED_AUDIO_DIR,item.fileName));}catch{}await persistSharedAudioLibrary();}
      else{state.audio.library=state.audio.library.filter(x=>x.id!==audioId);try{await fs.promises.unlink(path.join(AUDIO_DIR,item.fileName));}catch{}}
      for(const channel of Object.values(state.audio.channels||{}))if(channel.trackId===audioId){channel.trackId=null;channel.playing=false;channel.position=0;channel.startedAt=null;}
      for(const key of AUDIO_EFFECT_KEYS)if(state.audio.effectBindings[key]===audioId)state.audio.effectBindings[key]=null;
      let customSoundCleared=false;
      for(const scene of state.scenes||[]){for(const source of scene.audioSources||[])if(source.trackId===audioId){source.trackId=null;source.enabled=false;}for(const layer of scene.weatherLayers||[])if(layer.soundTrackId===audioId){layer.soundTrackId=null;layer.soundEnabled=false;}for(const token of scene.tokens||[])if(token.kind==='vehicle')for(const weapon of token.vehicle?.mountedWeapons||[])if(weapon.soundId===audioId){weapon.soundId=null;customSoundCleared=true;}}
      const campaign=getCampaign();
      for(const npc of campaign.npcs||[]){let changed=false;for(const attack of npc.attacks||[])if(attack?.soundId===audioId){attack.soundId=null;changed=true;customSoundCleared=true;}if(changed)npc.updatedAt=nowIso();}
      for(const character of campaign.characters||[]){let changed=false;for(const attack of character?.state?._lanCustomWeapons||[])if(attack?.soundId===audioId){attack.soundId=null;changed=true;customSoundCleared=true;}if(changed){character.revision=Math.max(0,Math.round(safeNumber(character.revision,0)))+1;character.updatedAt=nowIso();}}
      if(customSoundCleared)await persistCampaign();
      state.audio=normalizeAudioState(state.audio);await persist();broadcast('battlemap-replaced',body.clientId,{reason:'audio-deleted'});if(customSoundCleared)broadcastCampaignReplaced(body.clientId,'custom-attack-audio-cleared');sendJson(res,200,{ok:true,audio:audioView(),customSoundCleared});return true;
    }
    if(pathname==='/api/battlemap/audio/rescan-core'&&req.method==='POST'){
      const body=await readJsonBody(req).catch(()=>({}));if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Пересканировать встроенные звуки может только мастер.'});return true;}
      scanCoreAudioLibrary();state.audio=normalizeAudioState(state.audio);await persist();broadcast('battlemap-replaced',body.clientId,{reason:'core-audio-rescanned'});sendJson(res,200,{ok:true,audio:audioView(),found:coreAudioLibrary.length});return true;
    }
    if(pathname==='/api/battlemap/audio/cleanup-campaign'&&req.method==='POST'){
      const body=await readJsonBody(req).catch(()=>({}));if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Очищать аудио может только мастер.'});return true;}
      const used=new Set();for(const channel of Object.values(state.audio.channels||{}))if(channel.trackId)used.add(channel.trackId);for(const value of Object.values(state.audio.effectBindings||{}))if(value&&value!=='off')used.add(value);for(const scene of state.scenes||[]){for(const source of scene.audioSources||[])if(source.trackId)used.add(source.trackId);for(const layer of scene.weatherLayers||[])if(layer.soundTrackId)used.add(layer.soundTrackId);for(const token of scene.tokens||[])if(token.kind==='vehicle')for(const weapon of token.vehicle?.mountedWeapons||[])if(weapon.soundId&&weapon.soundId!=='off')used.add(weapon.soundId);}
      const campaign=getCampaign();for(const npc of campaign.npcs||[])for(const attack of npc.attacks||[])if(attack?.soundId&&attack.soundId!=='off')used.add(attack.soundId);for(const character of campaign.characters||[])for(const attack of character?.state?._lanCustomWeapons||[])if(attack?.soundId&&attack.soundId!=='off')used.add(attack.soundId);
      const removed=[];for(const item of [...state.audio.library])if(!used.has(item.id)){removed.push(item);try{await fs.promises.unlink(path.join(AUDIO_DIR,item.fileName));}catch{}}
      state.audio.library=state.audio.library.filter(item=>used.has(item.id));state.audio=normalizeAudioState(state.audio);await persist();broadcast('battlemap-replaced',body.clientId,{reason:'campaign-audio-cleaned'});sendJson(res,200,{ok:true,removed:removed.length,freedBytes:removed.reduce((s,i)=>s+Number(i.size||0),0),audio:audioView()});return true;
    }
    if (pathname === '/api/battlemap/assets/cleanup' && req.method === 'POST') {
      const body = await readJsonBody(req);
      if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok:false, error:'Удалять временные файлы может только мастер.' }); return true; }
      const urls = (Array.isArray(body.urls) ? body.urls : []).map(url => validAssetUrl(url, 'map')).filter(Boolean).slice(0, 20);
      const removed = await deleteMapAssetsIfUnused(urls);
      sendJson(res, 200, { ok:true, removed });
      return true;
    }

    if (pathname === '/api/battlemap/assets/upload' && req.method === 'POST') {
      const kind = requestUrl.searchParams.get('kind') === 'token' ? 'token' : 'map';
      if (kind === 'map' && !isMasterAuthorized(req, requestUrl)) { sendJson(res, 403, { ok:false, error:'Загружать карты может только мастер.' }); return true; }
      if (kind === 'token' && !isMasterAuthorized(req, requestUrl) && !cleanId(requestUrl.searchParams.get('clientId'), null)) { sendJson(res, 403, { ok:false, error:'Сначала войдите в игровую сессию.' }); return true; }
      const originalName = cleanName(requestUrl.searchParams.get('name'), kind, 180);
      const mime = cleanText(req.headers?.['content-type'] || '', 100).split(';')[0].trim().toLowerCase();
      const limit = kind === 'map' ? 36 * 1024 * 1024 : 10 * 1024 * 1024;
      const buffer = await readBinaryBody(req, limit + 1024, `Изображение слишком большое. Лимит: ${Math.round(limit / 1024 / 1024)} МБ.`);
      const url = saveAssetBuffer(kind, buffer, originalName, mime);
      sendJson(res, 201, { ok:true, url, size:buffer.length, mime });
      return true;
    }

    if (pathname === '/api/battlemap/assets' && req.method === 'POST') {
      const body = await readJsonBody(req);
      const kind = body.kind === 'token' ? 'token' : 'map';
      if (kind === 'map' && !isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok: false, error: 'Загружать карты может только мастер.' }); return true; }
      if (kind === 'token' && !isMasterAuthorized(req, requestUrl, body) && !cleanId(body.clientId, null)) { sendJson(res, 403, { ok: false, error: 'Сначала войдите в игровую сессию.' }); return true; }
      const url = saveAssetDataUrl(kind, body.dataUrl, body.name);
      sendJson(res, 201, { ok: true, url });
      return true;
    }

    if (pathname === '/api/battlemap/daylight' && req.method === 'PUT') {
      const body = await readJsonBody(req);
      if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok:false, error:'Изменять время суток может только мастер.' }); return true; }
      applyGlobalDaylight({
        ...(body.dayPhase !== undefined ? { dayPhase: body.dayPhase } : {}),
        ...(body.daylightEnabled !== undefined ? { daylightEnabled: body.daylightEnabled } : {})
      });
      await persist();
      broadcast('battlemap-replaced', body.clientId, { reason:'global-daylight' });
      sendJson(res, 200, { ok:true, daylight:clone(state.daylight), battlemap:viewFor('master', body.clientId) });
      return true;
    }

    if (pathname === '/api/battlemap/scenes' && req.method === 'POST') {
      const body = await readJsonBody(req);
      if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok: false, error: 'Это действие доступно только мастеру.' }); return true; }
      if (state.scenes.length >= MAX_SCENES) { sendJson(res, 409, { ok: false, error: 'Достигнут лимит сцен.' }); return true; }
      const scene = normalizeScene({ ...body, id: makeId('scene') }, state.scenes.length);
      scene.settings = normalizeSceneSettings({ ...scene.settings, ...(state.daylight || {}) });
      scene.tokenGroups = clone(state.tokenGroups || []);
      state.scenes.push(scene);
      if (!state.activeSceneId) state.activeSceneId = scene.id;
      await persist(); await recordMapHistory(body, 'scene-create', 'battlemap-scene', scene.id, `Создана сцена «${scene.name}»`);
      broadcast('battlemap-replaced', body.clientId, { reason: 'scene-created' });
      sendJson(res, 201, { ok: true, scene, battlemap: viewFor('master', body.clientId) });
      return true;
    }

    if (pathname === '/api/battlemap/active' && req.method === 'PUT') {
      const body = await readJsonBody(req);
      if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok: false, error: 'Это действие доступно только мастеру.' }); return true; }
      const sceneId = cleanId(body.sceneId, null);
      if (sceneId && !findScene(sceneId)) { sendJson(res, 404, { ok: false, error: 'Сцена не найдена.' }); return true; }
      state.activeSceneId = sceneId;
      await persist(); await recordMapHistory(body, 'scene-activate', 'battlemap', sceneId, `Активная сцена: ${findScene(sceneId)?.name || 'нет'}`);
      // Смена публичной сцены также меняет видимость скрытого/открытого боя и его инициативы.
      if (broadcastCampaignReplaced) broadcastCampaignReplaced(body.clientId, 'active-scene');
      broadcast('battlemap-replaced', body.clientId, { reason: 'active-scene' });
      sendJson(res, 200, { ok: true, activeSceneId: state.activeSceneId });
      return true;
    }

    const scenePreloadMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/preload$/);
    if (scenePreloadMatch && req.method === 'POST') {
      const body = await readJsonBody(req);
      if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok:false, error:'Предзагрузка доступна только мастеру.' }); return true; }
      const scene = findScene(cleanId(decodeURIComponent(scenePreloadMatch[1]), null));
      if (!scene) { sendJson(res, 404, { ok:false, error:'Сцена не найдена.' }); return true; }
      const visibleParallax = { ...clone(scene.parallax || { enabled:false, strength:.35, maxShift:18, layers:[], objects:[] }), layers:(scene.parallax?.layers || []).filter(layer => layer.showToPlayers !== false).map(layer => clone(layer)), objects:(scene.parallax?.objects || []).filter(object => object.showToPlayers !== false).map(object => clone(object)) };
      if (!scene.mapUrl && !scene.mapPreviewUrl && !visibleParallax.layers.length) { sendJson(res, 409, { ok:false, error:'У сцены нет карты или 2.5D-слоёв для предзагрузки.' }); return true; }
      const preload = {
        sceneId: scene.id, name: scene.name, mapUrl: scene.mapUrl, mapPreviewUrl: scene.mapPreviewUrl,
        mapThumbnailUrl: scene.mapThumbnailUrl, mapWidth: scene.mapWidth, mapHeight: scene.mapHeight,
        mapOptimization: clone(scene.mapOptimization), parallax: visibleParallax
      };
      broadcast('battlemap-map-preload', body.clientId, { preload });
      sendJson(res, 200, { ok:true, preload });
      return true;
    }

    const sceneMapMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/map$/);
    if (sceneMapMatch && req.method === 'DELETE') {
      const body = await readJsonBody(req).catch(() => ({}));
      if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok:false, error:'Удалять карту может только мастер.' }); return true; }
      const scene = findScene(cleanId(decodeURIComponent(sceneMapMatch[1]), null));
      if (!scene) { sendJson(res, 404, { ok:false, error:'Сцена не найдена.' }); return true; }
      if (!scene.mapUrl) { sendJson(res, 409, { ok:false, error:'У этой сцены нет загруженной карты.' }); return true; }
      if (createSnapshot) await createSnapshot('before-map-delete');
      const oldMapUrls = sceneMapAssetUrls(scene);
      scene.mapUrl = null;
      scene.mapPreviewUrl = null;
      scene.mapThumbnailUrl = null;
      scene.mapOriginalUrl = null;
      scene.mapOptimization = null;
      scene.updatedAt = nowIso();
      await persist();
      await deleteMapAssetsIfUnused(oldMapUrls);
      await recordMapHistory(body, 'map-delete', 'battlemap-scene', scene.id, `Удалена карта сцены «${scene.name}»`);
      broadcast('battlemap-replaced', body.clientId, { reason:'map-deleted', sceneId:scene.id });
      sendJson(res, 200, { ok:true, scene });
      return true;
    }

    const sceneObjectsMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/objects$/);
    if (sceneObjectsMatch && req.method === 'DELETE') {
      const body = await readJsonBody(req).catch(() => ({}));
      if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok:false, error:'Очищать сцену может только мастер.' }); return true; }
      const scene = findScene(cleanId(decodeURIComponent(sceneObjectsMatch[1]), null));
      if (!scene) { sendJson(res, 404, { ok:false, error:'Сцена не найдена.' }); return true; }
      if (createSnapshot) await createSnapshot('before-scene-clear');
      const combatStopped = await stopCombatForScene(scene.id);
      const removed = clearSceneObjects(scene);
      await persist();
      await recordMapHistory(body, 'scene-clear', 'battlemap-scene', scene.id, `Сцена «${scene.name}» очищена от объектов`);
      broadcast('battlemap-replaced', body.clientId, { reason:'scene-cleared', sceneId:scene.id, combatStopped });
      sendJson(res, 200, { ok:true, removed, combatStopped, scene });
      return true;
    }

    const sceneParallaxMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/parallax$/);
    if (sceneParallaxMatch && req.method === 'PUT') {
      const body = await readJsonBody(req);
      if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok:false, error:'Изменять 2.5D может только мастер.' }); return true; }
      const sceneId = cleanId(decodeURIComponent(sceneParallaxMatch[1]), null);
      const scene = findScene(sceneId);
      if (!scene) { sendJson(res, 404, { ok:false, error:'Сцена не найдена.' }); return true; }
      scene.parallax = normalizeParallax(body.parallax !== undefined ? body.parallax : body, scene);
      scene.updatedAt = nowIso();
      if (body.flush === false) await persist({ defer:true, delayMs:500 }); else await persist();
      broadcast('battlemap-parallax-updated', body.clientId, { sceneId });
      sendJson(res, 200, { ok:true, sceneId, sceneUpdatedAt:scene.updatedAt, parallax:publicParallax(scene, 'master') });
      return true;
    }

    const sceneMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)$/);
    if (sceneMatch) {
      const sceneId = cleanId(decodeURIComponent(sceneMatch[1]), null);
      const scene = findScene(sceneId);
      if (!scene) { sendJson(res, 404, { ok: false, error: 'Сцена не найдена.' }); return true; }
      if (req.method === 'PUT') {
        const body = await readJsonBody(req);
        if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok: false, error: 'Это действие доступно только мастеру.' }); return true; }
        const previousMapUrls = sceneMapAssetUrls(scene);
        if (body.name !== undefined) scene.name = cleanName(body.name, scene.name);
        if (body.mapUrl !== undefined) {
          const nextMapUrl = validAssetUrl(body.mapUrl, 'map');
          const changed = nextMapUrl !== scene.mapUrl;
          scene.mapUrl = nextMapUrl;
          if (changed && body.mapPreviewUrl === undefined) scene.mapPreviewUrl = null;
          if (changed && body.mapThumbnailUrl === undefined) scene.mapThumbnailUrl = null;
          if (changed && body.mapOriginalUrl === undefined) scene.mapOriginalUrl = null;
          if (changed && body.mapOptimization === undefined) scene.mapOptimization = null;
        }
        if (body.mapPreviewUrl !== undefined) scene.mapPreviewUrl = validAssetUrl(body.mapPreviewUrl, 'map');
        if (body.mapThumbnailUrl !== undefined) scene.mapThumbnailUrl = validAssetUrl(body.mapThumbnailUrl, 'map');
        if (body.mapOriginalUrl !== undefined) scene.mapOriginalUrl = validAssetUrl(body.mapOriginalUrl, 'map');
        if (body.mapOptimization !== undefined) scene.mapOptimization = normalizeScene({ mapOptimization: body.mapOptimization }).mapOptimization;
        if (body.mapWidth !== undefined) scene.mapWidth = clamp(Math.round(safeNumber(body.mapWidth, scene.mapWidth)), 100, 30000);
        if (body.mapHeight !== undefined) scene.mapHeight = clamp(Math.round(safeNumber(body.mapHeight, scene.mapHeight)), 100, 30000);
        if (body.background !== undefined) scene.background = cleanColor(body.background, scene.background);
        if (body.grid !== undefined) scene.grid = normalizeGrid({ ...scene.grid, ...body.grid });
        if (body.settings !== undefined) {
          scene.settings = normalizeSceneSettings({ ...scene.settings, ...body.settings });
          if (Object.prototype.hasOwnProperty.call(body.settings, 'dayPhase') || Object.prototype.hasOwnProperty.call(body.settings, 'daylightEnabled')) {
            applyGlobalDaylight({
              ...(Object.prototype.hasOwnProperty.call(body.settings, 'dayPhase') ? { dayPhase: body.settings.dayPhase } : {}),
              ...(Object.prototype.hasOwnProperty.call(body.settings, 'daylightEnabled') ? { daylightEnabled: body.settings.daylightEnabled } : {})
            });
          }
        }
        if (body.weatherLayers !== undefined) scene.weatherLayers = (Array.isArray(body.weatherLayers) ? body.weatherLayers : []).map(normalizeWeatherLayer).slice(0, MAX_WEATHER_LAYERS);
        if (body.parallax !== undefined) scene.parallax = normalizeParallax(body.parallax, scene);
        if (body.elevationZones !== undefined) scene.elevationZones = (Array.isArray(body.elevationZones) ? body.elevationZones : []).map(normalizeElevationZone).slice(0, MAX_ELEVATION_ZONES);
        if (body.triggerZones !== undefined) scene.triggerZones = (Array.isArray(body.triggerZones) ? body.triggerZones : []).map(normalizeTriggerZone).slice(0, MAX_TRIGGER_ZONES);
        if (body.tokenGroups !== undefined) replaceGlobalTokenGroups(body.tokenGroups);
        scene.updatedAt = nowIso();
        await persist();
        await deleteMapAssetsIfUnused(previousMapUrls);
        broadcast('battlemap-replaced', body.clientId, { reason: 'scene-updated', sceneId });
        sendJson(res, 200, { ok: true, scene });
        return true;
      }
      if (req.method === 'DELETE') {
        const body = await readJsonBody(req).catch(() => ({}));
        if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok: false, error: 'Это действие доступно только мастеру.' }); return true; }
        if (createSnapshot) await createSnapshot('before-scene-delete');
        const oldMapUrls = sceneMapAssetUrls(scene);
        const combatStopped = await stopCombatForScene(sceneId);
        state.scenes = state.scenes.filter(item => item.id !== sceneId);
        if (state.activeSceneId === sceneId) state.activeSceneId = state.scenes[0]?.id || null;
        await persist();
        await deleteMapAssetsIfUnused(oldMapUrls);
        await recordMapHistory(body, 'scene-delete', 'battlemap-scene', sceneId, `Удалена сцена «${scene.name}»`);
        broadcast('battlemap-replaced', body.clientId, { reason: 'scene-deleted' });
        sendJson(res, 200, { ok: true });
        return true;
      }
    }

    const tokensMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/tokens$/);
    if (tokensMatch && req.method === 'POST') {
      const body = await readJsonBody(req);
      if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok: false, error: 'Это действие доступно только мастеру.' }); return true; }
      const scene = findScene(cleanId(decodeURIComponent(tokensMatch[1]), null));
      if (!scene) { sendJson(res, 404, { ok: false, error: 'Сцена не найдена.' }); return true; }
      const source = { ...body, id: makeId('token') };
      if (source.kind === 'character') {
        const character = getCampaign().characters.find(item => item.id === cleanId(source.refId, null));
        if (character) { source.name ||= character.name; source.imageUrl ||= character.portrait; source.ownerId ||= character.ownerId; }
      } else if (source.kind === 'npc') {
        const npc = getCampaign().npcs.find(item => item.id === cleanId(source.refId, null));
        if (npc) source.name ||= npc.name;
      }
      const token = normalizeToken(source, scene, scene.tokens.length);
      const blocker = tokenPositionBlocker(scene, token, token);
      if (blocker) { sendJson(res, 409, { ok:false, error:`Клетка занята токеном «${blocker.name}». Выберите свободную клетку.` }); return true; }
      scene.tokens.push(token); scene.updatedAt = nowIso();
      await persist(); await recordMapHistory(body, 'token-create', 'battlemap-token', token.id, `На сцену добавлен токен «${token.name}»`);
      broadcast('battlemap-replaced', body.clientId, { reason: 'token-created', sceneId: scene.id, tokenId: token.id });
      sendJson(res, 201, { ok: true, token });
      return true;
    }

    const globalTokenGroupsMatch = pathname === '/api/battlemap/token-groups';
    const legacyTokenGroupsMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/token-groups$/);
    if ((globalTokenGroupsMatch || legacyTokenGroupsMatch) && req.method === 'PUT') {
      const body = await readJsonBody(req);
      if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok:false, error:'Управлять группами может только мастер.' }); return true; }
      if (legacyTokenGroupsMatch && !findScene(cleanId(decodeURIComponent(legacyTokenGroupsMatch[1]), null))) { sendJson(res,404,{ok:false,error:'Сцена не найдена.'}); return true; }
      const groups = replaceGlobalTokenGroups(body.groups);
      await persist();
      broadcast('battlemap-replaced', body.clientId, { reason:'token-groups-global' });
      sendJson(res, 200, { ok:true, groups:clone(groups) });
      return true;
    }

    const legacyGroupTransferMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/groups\/([^/]+)\/transfer$/);
    const globalGroupTransferMatch = pathname.match(/^\/api\/battlemap\/groups\/([^/]+)\/transfer$/);
    if ((legacyGroupTransferMatch || globalGroupTransferMatch) && req.method === 'POST') {
      const body=await readJsonBody(req);
      if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Переносить группы может только мастер.'});return true;}
      const groupId = cleanId(decodeURIComponent(globalGroupTransferMatch ? globalGroupTransferMatch[1] : legacyGroupTransferMatch[2]), null);
      const sourceSceneId = globalGroupTransferMatch ? cleanId(body.sourceSceneId, null) : cleanId(decodeURIComponent(legacyGroupTransferMatch[1]), null);
      const sourceScene=findScene(sourceSceneId),targetScene=findScene(cleanId(body.targetSceneId,null));
      const group=findGlobalTokenGroup(groupId),members=(sourceScene?.tokens||[]).filter(token=>token.groupId===groupId);
      if(!sourceScene||!targetScene||!group){sendJson(res,404,{ok:false,error:'Группа или сцена не найдена.'});return true;}
      if(sourceScene.id===targetScene.id){sendJson(res,409,{ok:false,error:'Исходная и целевая сцены совпадают.'});return true;}
      if(!members.length){sendJson(res,409,{ok:false,error:'На исходной сцене нет токенов этой группы.'});return true;}
      const cx=members.reduce((sum,t)=>sum+t.x,0)/members.length,cy=members.reduce((sum,t)=>sum+t.y,0)/members.length;
      const targetX=body.x===undefined?targetScene.mapWidth/2:safeNumber(body.x,targetScene.mapWidth/2),targetY=body.y===undefined?targetScene.mapHeight/2:safeNumber(body.y,targetScene.mapHeight/2);
      const moved=[],shadowScene={...targetScene,tokens:[...(targetScene.tokens||[])]};
      for(const token of members){
        const copy=normalizeToken({...clone(token),x:token.x-cx+targetX,y:token.y-cy+targetY,updatedAt:nowIso()},targetScene,targetScene.tokens.length+moved.length);
        if(shadowScene.tokens.some(item=>item.id===copy.id))copy.id=makeId('token');
        const freePoint=nearestFreeTokenPoint(shadowScene,copy,{x:copy.x,y:copy.y});
        if(!freePoint){sendJson(res,409,{ok:false,error:`Не удалось найти свободную клетку для «${copy.name}» рядом с местом переноса группы.`});return true;}
        copy.x=freePoint.x;copy.y=freePoint.y;shadowScene.tokens.push(copy);moved.push(copy);
      }
      targetScene.tokens.push(...moved);
      const movedIds=new Set(members.map(t=>t.id)),movedRefs=new Set(members.map(t=>`${t.kind}:${t.refId}`));
      sourceScene.tokens=sourceScene.tokens.filter(token=>!movedIds.has(token.id));
      if(state.combat?.sceneId===sourceScene.id){
        const campaign=getCampaign();
        campaign.initiative.entries=(campaign.initiative.entries||[]).filter(entry=>!movedIds.has(entry.tokenId)&&!movedRefs.has(`${entry.type}:${entry.refId}`));
        state.combat.participantTokenIds=(state.combat.participantTokenIds||[]).filter(id=>!movedIds.has(id));
        for (const id of movedIds) delete state.combat.movement?.[id];
        if(!campaign.initiative.entries.length){clearCombatOnlyActions(sourceScene);state.combat={active:false,sceneId:null,participantTokenIds:[],startedAt:null,movement:{}};campaign.initiative={round:1,currentIndex:0,entries:[]};}
        else campaign.initiative.currentIndex=Math.min(campaign.initiative.currentIndex||0,campaign.initiative.entries.length-1);
      }
      syncTokenGroupMirrors();
      sourceScene.updatedAt=targetScene.updatedAt=nowIso();
      await persistCampaign();await persist();
      broadcast('battlemap-replaced',body.clientId,{reason:'token-group-transferred',sourceSceneId:sourceScene.id,targetSceneId:targetScene.id,groupId});
      sendJson(res,200,{ok:true,moved,group:clone(group),sourceSceneId:sourceScene.id,targetSceneId:targetScene.id});return true;
    }

    const tokenTransferMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/tokens\/([^/]+)\/transfer$/);
    if (tokenTransferMatch && req.method === 'POST') {
      const body=await readJsonBody(req);
      if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Переносить токены между сценами может только мастер.'});return true;}
      const sourceScene=findScene(cleanId(decodeURIComponent(tokenTransferMatch[1]),null)),token=findToken(sourceScene,cleanId(decodeURIComponent(tokenTransferMatch[2]),null)),targetScene=findScene(cleanId(body.targetSceneId,null));
      if(!sourceScene||!token||!targetScene){sendJson(res,404,{ok:false,error:'Исходная сцена, токен или целевая сцена не найдены.'});return true;}
      if(sourceScene.id===targetScene.id){sendJson(res,409,{ok:false,error:'Токен уже находится на выбранной сцене.'});return true;}
      const moved=normalizeToken({...clone(token),x:body.x===undefined?targetScene.mapWidth/2:body.x,y:body.y===undefined?targetScene.mapHeight/2:body.y,updatedAt:nowIso()},targetScene,targetScene.tokens.length);
      if(targetScene.tokens.some(item=>item.id===moved.id))moved.id=makeId('token');
      const preferred={x:body.x===undefined?targetScene.mapWidth/2:safeNumber(body.x,targetScene.mapWidth/2),y:body.y===undefined?targetScene.mapHeight/2:safeNumber(body.y,targetScene.mapHeight/2)},freePoint=nearestFreeTokenPoint(targetScene,moved,preferred);
      if(!freePoint){sendJson(res,409,{ok:false,error:'Не удалось найти свободную клетку рядом с точкой переноса.'});return true;}
      moved.x=freePoint.x;moved.y=freePoint.y;
      if(moved.groupId){const group=(sourceScene.tokenGroups||[]).find(item=>item.id===moved.groupId);if(group&&!(targetScene.tokenGroups||[]).some(item=>item.id===group.id))targetScene.tokenGroups.push(normalizeTokenGroup(clone(group),targetScene.tokenGroups.length));}
      sourceScene.tokens=sourceScene.tokens.filter(item=>item.id!==token.id);targetScene.tokens.push(moved);sourceScene.updatedAt=nowIso();targetScene.updatedAt=nowIso();
      if(state.combat?.sceneId===sourceScene.id){const campaign=getCampaign(),current=campaign.initiative.entries?.[campaign.initiative.currentIndex||0],currentRef=current?`${current.type}:${current.refId}`:null;campaign.initiative.entries=(campaign.initiative.entries||[]).filter(entry=>entry.tokenId?entry.tokenId!==token.id:!(entry.type===token.kind&&entry.refId===token.refId));state.combat.participantTokenIds=(state.combat.participantTokenIds||[]).filter(id=>id!==token.id);delete state.combat.movement?.[token.id];if(!campaign.initiative.entries.length){clearCombatOnlyActions(sourceScene);state.combat={active:false,sceneId:null,participantTokenIds:[],startedAt:null,movement:{}};campaign.initiative={round:1,currentIndex:0,entries:[]};}else{campaign.initiative.currentIndex=Math.max(0,campaign.initiative.entries.findIndex(entry=>`${entry.type}:${entry.refId}`===currentRef));}}
      await persist();await recordMapHistory(body,'token-transfer','battlemap-token',moved.id,`Токен «${moved.name}» перенесён на сцену «${targetScene.name}»`);broadcast('battlemap-replaced',body.clientId,{reason:'token-transferred',sceneId:targetScene.id,tokenId:moved.id});sendJson(res,200,{ok:true,token:moved,sourceSceneId:sourceScene.id,targetSceneId:targetScene.id});return true;
    }

    const bulkMoveMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/tokens\/bulk-move$/);
    if (bulkMoveMatch && req.method === 'POST') {
      const body=await readJsonBody(req);
      if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Групповое перемещение токенов доступно только мастеру.'});return true;}
      const scene=findScene(cleanId(decodeURIComponent(bulkMoveMatch[1]),null));
      if(!scene){sendJson(res,404,{ok:false,error:'Сцена не найдена.'});return true;}
      const rawMoves=Array.isArray(body.moves)?body.moves.slice(0,100):[];
      if(!rawMoves.length){sendJson(res,400,{ok:false,error:'Не выбраны токены для перемещения.'});return true;}
      const moves=[],movingIds=new Set();
      for(const item of rawMoves){
        const token=findToken(scene,cleanId(item?.tokenId,null));if(!token){sendJson(res,404,{ok:false,error:'Один из выбранных токенов не найден.'});return true;}
        if(movingIds.has(token.id))continue;movingIds.add(token.id);
        moves.push({token,x:clamp(safeNumber(item.x,token.x),-100000,100000),y:clamp(safeNumber(item.y,token.y),-100000,100000),rotation:item.rotation===undefined?token.rotation:((safeNumber(item.rotation,token.rotation)%360)+360)%360});
      }
      const shadow={...scene,tokens:(scene.tokens||[]).filter(token=>!movingIds.has(token.id))};
      for(const move of moves){
        const next={x:move.x,y:move.y};
        if(body.forceMove!==true){try{assertTokenCanAct(move.token,{movement:true});assertTokenMovementUnlocked(move.token);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:`${move.token.name}: ${error.message}`});return true;}}
        if(scene.settings.enforceWalls&&body.ignoreWalls!==true&&movementBlocked(scene,move.token,{x:move.token.x,y:move.token.y},next)){sendJson(res,409,{ok:false,error:`Перемещение «${move.token.name}» блокирует стена или закрытая дверь.`});return true;}
        const preview={...move.token,x:move.x,y:move.y};const blocker=tokenPositionBlocker(shadow,preview,preview);
        if(blocker){sendJson(res,409,{ok:false,error:`Новая позиция «${move.token.name}» занята токеном «${blocker.name}».`});return true;}
        shadow.tokens.push(preview);
      }
      for(const move of moves){move.token.x=move.x;move.token.y=move.y;move.token.rotation=move.rotation;move.token.updatedAt=nowIso();if(move.token.kind==='vehicle'&&move.token.vehicle){for(const occupantId of move.token.vehicle.occupants||[]){const occupant=findToken(scene,occupantId);if(occupant){occupant.x=move.x;occupant.y=move.y;occupant.updatedAt=nowIso();}}}}
      scene.updatedAt=nowIso();await persist();
      await recordMapHistory(body,'token-bulk-move','battlemap-token',null,`Мастер переместил токены: ${moves.map(item=>item.token.name).join(', ')}`);
      broadcast('battlemap-replaced',body.clientId,{reason:'tokens-bulk-moved',sceneId:scene.id,tokenIds:moves.map(item=>item.token.id)});
      sendJson(res,200,{ok:true,tokens:moves.map(item=>publicToken(item.token,'master',cleanId(body.clientId,null)))});return true;
    }

    const gmStatsMatch=pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/tokens\/([^/]+)\/gm-stats$/);
    if(gmStatsMatch){
      const scene=findScene(cleanId(decodeURIComponent(gmStatsMatch[1]),null)),token=scene?findToken(scene,cleanId(decodeURIComponent(gmStatsMatch[2]),null)):null;if(!scene||!token){sendJson(res,404,{ok:false,error:'Токен не найден.'});return true;}
      if(req.method==='GET'){if(!isMasterAuthorized(req,requestUrl)){sendJson(res,403,{ok:false,error:'Это действие доступно только мастеру.'});return true;}sendJson(res,200,{ok:true,stats:gmTokenStatsSnapshot(token)});return true;}
      if(req.method==='PUT'){const body=await readJsonBody(req);if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Это действие доступно только мастеру.'});return true;}if(!['character','npc'].includes(token.kind)){sendJson(res,409,{ok:false,error:'Расширенные параметры доступны для персонажей и NPC.'});return true;}const stats=applyGmTokenStats(scene,token,body);await persistCampaign();await persist();if(token.kind==='character'&&broadcastCharacterUpdated)broadcastCharacterUpdated(linkedCharacter(token),body.clientId);if(token.kind==='npc'&&broadcastCampaignReplaced)broadcastCampaignReplaced(body.clientId,'gm-token-stats');broadcast('battlemap-replaced',body.clientId,{reason:'gm-token-stats',sceneId:scene.id,tokenId:token.id});sendJson(res,200,{ok:true,stats,token:publicToken(token,'master',cleanId(body.clientId,null))});return true;}
    }

    const tokenMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/tokens\/([^/]+)$/);
    if (tokenMatch) {
      const scene = findScene(cleanId(decodeURIComponent(tokenMatch[1]), null));
      const token = findToken(scene, cleanId(decodeURIComponent(tokenMatch[2]), null));
      if (!scene || !token) { sendJson(res, 404, { ok: false, error: 'Токен не найден.' }); return true; }
      if (req.method === 'PUT') {
        const body = await readJsonBody(req);
        if (!canControlToken(token, req, requestUrl, body)) { sendJson(res, 403, { ok: false, error: 'Вы не управляете этим токеном.' }); return true; }
        const master = isMasterAuthorized(req, requestUrl, body);
        const oldPoint = { x: token.x, y: token.y };
        const nextPoint = { x: body.x === undefined ? token.x : clamp(safeNumber(body.x, token.x), -100000, 100000), y: body.y === undefined ? token.y : clamp(safeNumber(body.y, token.y), -100000, 100000) };
        const movedPx = Math.hypot(nextPoint.x - oldPoint.x, nextPoint.y - oldPoint.y);
        const movedFeet = movedPx / Math.max(1, scene.grid.size) * scene.grid.feet;
        const movementFeet = Math.max(movedFeet, clamp(safeNumber(body.movementDeltaFeet, movedFeet), 0, 100000));
        if(token.boardedVehicleId&&movementFeet>0.001&&!(master&&body.forceMove===true)){sendJson(res,409,{ok:false,error:'Персонаж находится в транспорте. Сначала используйте действие «Выйти».',token,movement:movementSummary(token)});return true;}
        if(movementFeet>0.001&&!(master&&body.forceMove===true)){try{assertTokenCanAct(token,{movement:true});assertTokenMovementUnlocked(token);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message,token,movement:movementSummary(token)});return true;}}
        let acceptedMovementSpent = null;
        if (movementFeet > 0.001 && token.kind === 'vehicle' && state.combat?.active && state.combat.sceneId === scene.id) {
          const round=getCampaign().initiative?.round||0,driver=findToken(scene,token.vehicle?.driverTokenId);
          if (!driver) { sendJson(res,409,{ok:false,error:'У транспорта нет водителя.',token,movement:movementSummary(token)}); return true; }
          if (!isCurrentCombatToken(scene,driver) && !(master && body.forceMove === true)) { sendJson(res,409,{ok:false,error:'Перемещать транспорт можно в ход водителя.',token,movement:movementSummary(token)}); return true; }
          if (token.vehicle?.movedRound !== round && !(master && body.forceMove === true)) { sendJson(res,409,{ok:false,error:'Сначала водитель должен потратить 1 ОД на действие «Вести транспорт».',token,movement:movementSummary(token)}); return true; }
          if (!(master && body.ignoreMovementLimit === true)) {
            const movement=movementSummary(token),nextSpent=movement.spent+movementFeet;
            if(nextSpent>movement.limit+0.01){sendJson(res,409,{ok:false,error:`Недостаточно движения транспорта: осталось ${movement.remaining.toFixed(1)} фт.`,token,movement});return true;}
            acceptedMovementSpent=Math.round(nextSpent*10)/10;
          }
        } else if (movementFeet > 0.001 && state.combat?.active && state.combat.sceneId === scene.id && state.combat.participantTokenIds?.includes(token.id)) {
          if (!isCurrentCombatToken(scene, token) && !(master && body.forceMove === true)) { sendJson(res, 409, { ok:false, error:'Сейчас ход другого участника.', token, movement:movementSummary(token) }); return true; }
          if (!(master && body.ignoreMovementLimit === true)) {
            const movement = movementSummary(token), nextSpent = movement.spent + movementFeet;
            if (nextSpent > movement.limit + 0.01) { sendJson(res, 409, { ok:false, error:`Недостаточно движения: осталось ${movement.remaining.toFixed(1)} фт.`, token, movement }); return true; }
            acceptedMovementSpent = Math.round(nextSpent * 10) / 10;
          }
        }
        const playerSimulationMovement = master && body.playerSimulation === true;
        if ((scene.settings.enforceWalls || playerSimulationMovement) && !(master && body.ignoreWalls === true && !playerSimulationMovement) && movementBlocked(scene, token, oldPoint, nextPoint)) { sendJson(res, 409, { ok: false, error: 'Перемещение блокирует стена или закрытая дверь.', token, movement:movementSummary(token) }); return true; }
        if (movementFeet > 0.001) {
          const blocker = tokenPositionBlocker(scene, token, nextPoint);
          if (blocker) { sendJson(res, 409, { ok:false, error:`Клетка занята токеном «${blocker.name}».`, token, blockerTokenId:blocker.id, movement:movementSummary(token) }); return true; }
        }
        let reactions=[],forcedChecks=[],movementDamageResults=[];
        if(movementFeet>0.001&&(!(master&&body.forceMove===true)||isCurrentCombatToken(scene,token)))reactions=await resolveMovementReactions(scene,token,oldPoint,nextPoint,body);
        if (movementFeet > 0.001) { for (const effect of (scene.effects||[])) { if (effect.type!=='barrage'||effect.remainingRounds<=0||!effect.zoneDamage) continue; const circle={shape:'circle',x:effect.x,y:effect.y,radius:feetToScenePixels(scene,effect.radius)}; if (lineIntersectsCover(oldPoint,nextPoint,circle)||pointInCover(nextPoint,circle)) { effect.hitTokens ||= {}; const round=getCampaign().initiative?.round||0; if(effect.hitTokens[token.id]!==round){ const movementDamage=await applyDamageToTarget(scene,token,{...body,damage:effect.zoneDamage,damageTag:effect.damageTag,sourceText:effect.name,bleeding:false},{persist:false,recordHistory:false,role:'system'}); movementDamageResults.push(movementDamage); effect.hitTokens[token.id]=round; } } } }
        if(movementFeet>0.001)forcedChecks=await resolveForcedCheckZones(scene,token,oldPoint,nextPoint,body);
        if (acceptedMovementSpent !== null) movementRecord(token).spent = acceptedMovementSpent;
        token.x = nextPoint.x; token.y = nextPoint.y;
        if (body.rotation !== undefined) token.rotation = ((safeNumber(body.rotation, token.rotation) % 360) + 360) % 360;
        if (body.imageUrl !== undefined && (master || canControlToken(token, req, requestUrl, body))) token.imageUrl = validAssetUrl(body.imageUrl) || null;
        if (body.formImages !== undefined && (master || canControlToken(token, req, requestUrl, body))) token.formImages = normalizeToken({ ...token, formImages:{...token.formImages,...body.formImages} }, scene).formImages;
        if (body.display !== undefined && (master || canControlToken(token, req, requestUrl, body))) token.display = normalizeToken({ ...token, display: { ...token.display, ...body.display } }, scene).display;
        if (master) {
          for (const key of ['name','kind','refId','imageUrl','size','ownerId','groupId','hidden','locked','defeated','elevation','mzOverride','coverBonus','notes','boardedVehicleId','ai']) {
            if (body[key] === undefined) continue;
            if (key === 'name') token.name = cleanName(body.name, token.name);
            else if (key === 'kind') token.kind = ['character','npc','generic','vehicle','interactive'].includes(body.kind) ? body.kind : token.kind;
            else if (key === 'refId' || key === 'ownerId' || key === 'groupId') token[key] = cleanId(body[key], null);
            else if (key === 'imageUrl') token.imageUrl = validAssetUrl(body.imageUrl) || null;
            else if (key === 'size') token.size = clamp(safeNumber(body.size, token.size), 0.25, 12);
            else if (key === 'hidden' || key === 'locked' || key === 'defeated') token[key] = Boolean(body[key]);
            else if (key === 'elevation') token.elevation = clamp(safeNumber(body.elevation, token.elevation), -1000, 10000);
            else if (key === 'mzOverride') token.mzOverride = body.mzOverride === null || body.mzOverride === '' ? null : clamp(Math.round(safeNumber(body.mzOverride, 4)), 0, 99);
            else if (key === 'coverBonus') token.coverBonus = clamp(Math.round(safeNumber(body.coverBonus, 0)), -20, 30);
            else if (key === 'notes') token.notes = cleanText(body.notes, 2000);
            else if (key === 'boardedVehicleId') token.boardedVehicleId = cleanId(body.boardedVehicleId, null);
            else if (key === 'ai' && token.kind === 'npc') token.ai = normalizeAiControl({ ...token.ai, ...body.ai });
          }
          if (body.vision !== undefined) token.vision = normalizeVision({ ...token.vision, ...body.vision });
          if (body.light !== undefined) token.light = normalizeLight({ ...token.light, ...body.light });
          if (token.kind === 'vehicle' && body.vehicle !== undefined) { const nextVehicle=normalizeVehicle({ ...token.vehicle, ...body.vehicle }, token.name),usedSlots=(nextVehicle.mountedWeapons||[]).reduce((sum,weapon)=>sum+Math.max(1,safeNumber(weapon.slotCost,1)),0);if(usedSlots>nextVehicle.slots){sendJson(res,409,{ok:false,error:`Встроенное оружие занимает ${usedSlots} слотов при доступных ${nextVehicle.slots}.`});return true;}token.vehicle=nextVehicle; }
          if (token.kind === 'interactive' && body.interactive !== undefined) token.interactive = normalizeInteractiveObject({ ...token.interactive, ...body.interactive }, token.name);
        }
        if(token.kind==='vehicle'&&token.vehicle&&('x' in body||'y' in body)){for(const occupantId of token.vehicle.occupants||[]){const occupant=findToken(scene,occupantId);if(occupant){occupant.x=token.x;occupant.y=token.y;occupant.updatedAt=nowIso();}}}
        token.updatedAt = nowIso(); scene.updatedAt = nowIso();
        const movementDamageFormulas=movementDamageResults.flatMap(result=>journalRollFormulas(null,result));const movementDamageEntry=movementDamageFormulas.length?appendTableLog({type:'roll',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,token.name),text:`${token.name}: урон при пересечении зоны огня.`,sceneId:scene.id,tokenId:token.id,meta:{formulas:movementDamageFormulas}}):null;
        if(reactions.length||forcedChecks.length||movementDamageResults.length)await persistCampaign();
        const deferMovementPersist=tokenUpdateIsMovementOnly(body)&&!reactions.length&&!forcedChecks.length&&!movementDamageResults.length;
        if(deferMovementPersist)persist({defer:true,delayMs:120});else await persist();
        if(movementDamageEntry)broadcastTableLog(movementDamageEntry);
        if(forcedChecks.length){
          if(token.kind==='character'&&broadcastCharacterUpdated)broadcastCharacterUpdated(linkedCharacter(token),body.clientId);
          if(token.kind==='npc'&&broadcastCampaignReplaced)broadcastCampaignReplaced(body.clientId,'forced-zone-effect');
          broadcast('battlemap-replaced',body.clientId,{reason:'forced-zone-effect',sceneId:scene.id,tokenId:token.id});
        }
        broadcast('battlemap-token-updated', body.clientId, { reason: 'token-updated', sceneId: scene.id, tokenId: token.id });
        sendJson(res, 200, { ok: true, token: publicToken(token, master ? 'master' : 'player', cleanId(body.clientId, null)), movement:movementSummary(token), reactions, forcedChecks, masterPause:clone(state.masterPause) });
        return true;
      }
      if (req.method === 'DELETE') {
        const body = await readJsonBody(req).catch(() => ({}));
        if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok: false, error: 'Это действие доступно только мастеру.' }); return true; }
        scene.tokens = scene.tokens.filter(item => item.id !== token.id); scene.updatedAt = nowIso();
        await persist(); await recordMapHistory(body, 'token-delete', 'battlemap-token', token.id, `Удалён токен «${token.name}»`);
        broadcast('battlemap-replaced', body.clientId, { reason: 'token-deleted', sceneId: scene.id });
        sendJson(res, 200, { ok: true });
        return true;
      }
    }


    const elevationZonesMatch=pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/elevation-zones$/);
    if(elevationZonesMatch&&req.method==='PUT'){const body=await readJsonBody(req);if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Редактировать зоны высоты может только мастер.'});return true;}const scene=findScene(cleanId(decodeURIComponent(elevationZonesMatch[1]),null));if(!scene){sendJson(res,404,{ok:false,error:'Сцена не найдена.'});return true;}scene.elevationZones=(Array.isArray(body.zones)?body.zones:[]).map(normalizeElevationZone).slice(0,MAX_ELEVATION_ZONES);scene.updatedAt=nowIso();await persist();broadcast('battlemap-replaced',body.clientId,{reason:'elevation-zones',sceneId:scene.id});sendJson(res,200,{ok:true,zones:clone(scene.elevationZones)});return true;}
    const triggerZonesMatch=pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/trigger-zones$/);
    if(triggerZonesMatch&&req.method==='PUT'){const body=await readJsonBody(req);if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Редактировать зоны проверок может только мастер.'});return true;}const scene=findScene(cleanId(decodeURIComponent(triggerZonesMatch[1]),null));if(!scene){sendJson(res,404,{ok:false,error:'Сцена не найдена.'});return true;}scene.triggerZones=(Array.isArray(body.zones)?body.zones:[]).map(normalizeTriggerZone).slice(0,MAX_TRIGGER_ZONES);scene.updatedAt=nowIso();await persist();broadcast('battlemap-replaced',body.clientId,{reason:'trigger-zones',sceneId:scene.id});sendJson(res,200,{ok:true,zones:clone(scene.triggerZones)});return true;}

    const wallsMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/walls$/);
    if (wallsMatch && req.method === 'PUT') {
      const body = await readJsonBody(req);
      if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok: false, error: 'Это действие доступно только мастеру.' }); return true; }
      const scene = findScene(cleanId(decodeURIComponent(wallsMatch[1]), null));
      if (!scene) { sendJson(res, 404, { ok: false, error: 'Сцена не найдена.' }); return true; }
      scene.walls = (Array.isArray(body.walls) ? body.walls : []).map(normalizeWall).slice(0, MAX_WALLS); scene.updatedAt = nowIso();
      await persist(); broadcast('battlemap-replaced', body.clientId, { reason: 'walls-updated', sceneId: scene.id }); sendJson(res, 200, { ok: true, walls: scene.walls }); return true;
    }

    const wallToggleMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/walls\/([^/]+)\/toggle$/);
    if (wallToggleMatch && req.method === 'POST') {
      const body = await readJsonBody(req);
      const scene = findScene(cleanId(decodeURIComponent(wallToggleMatch[1]), null));
      const wall = scene?.walls.find(item => item.id === cleanId(decodeURIComponent(wallToggleMatch[2]), null));
      if (!scene || !wall || !wall.door) { sendJson(res, 404, { ok: false, error: 'Дверь не найдена.' }); return true; }
      const master = isMasterAuthorized(req, requestUrl, body);
      if (!master) { sendJson(res, 403, { ok: false, error: 'Открывать двери сейчас может только мастер.' }); return true; }
      wall.open = body.open === undefined ? !wall.open : Boolean(body.open); scene.updatedAt = nowIso();
      await persist(); broadcast('battlemap-replaced', body.clientId, { reason: 'door-toggled', sceneId: scene.id, wallId: wall.id }); sendJson(res, 200, { ok: true, wall }); return true;
    }

    const lightsMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/lights$/);
    if (lightsMatch && req.method === 'PUT') {
      const body = await readJsonBody(req);
      if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok: false, error: 'Это действие доступно только мастеру.' }); return true; }
      const scene = findScene(cleanId(decodeURIComponent(lightsMatch[1]), null));
      if (!scene) { sendJson(res, 404, { ok: false, error: 'Сцена не найдена.' }); return true; }
      scene.lights = (Array.isArray(body.lights) ? body.lights : []).map(normalizeStaticLight).slice(0, MAX_LIGHTS); scene.updatedAt = nowIso();
      await persist(); broadcast('battlemap-replaced', body.clientId, { reason: 'lights-updated', sceneId: scene.id }); sendJson(res, 200, { ok: true, lights: scene.lights }); return true;
    }

    const doorsMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/doors$/);
    if (doorsMatch && req.method === 'PUT') {
      const body = await readJsonBody(req);
      if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok: false, error: 'Это действие доступно только мастеру.' }); return true; }
      const scene = findScene(cleanId(decodeURIComponent(doorsMatch[1]), null));
      if (!scene) { sendJson(res, 404, { ok: false, error: 'Сцена не найдена.' }); return true; }
      scene.doors = (Array.isArray(body.doors) ? body.doors : []).map(normalizeDoor).slice(0, MAX_DOORS); scene.updatedAt = nowIso();
      await persist(); broadcast('battlemap-replaced', body.clientId, { reason: 'doors-updated', sceneId: scene.id }); sendJson(res, 200, { ok: true, doors: scene.doors }); return true;
    }

    const doorToggleMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/doors\/([^/]+)\/toggle$/);
    if (doorToggleMatch && req.method === 'POST') {
      const body = await readJsonBody(req);
      const scene = findScene(cleanId(decodeURIComponent(doorToggleMatch[1]), null));
      const door = findDoor(scene, cleanId(decodeURIComponent(doorToggleMatch[2]), null));
      if (!scene || !door) { sendJson(res, 404, { ok: false, error: 'Дверь не найдена.' }); return true; }
      const master = isMasterAuthorized(req, requestUrl, body);
      const playerSemantics = !master || body.playerSimulation === true;
      if (playerSemantics) {
        if (door.hidden) { sendJson(res, 403, { ok: false, error: 'Эта дверь вам неизвестна.' }); return true; }
        if (!door.allowPlayers || door.locked) { sendJson(res, 403, { ok: false, error: door.locked ? 'Дверь заперта.' : 'Эту дверь может открыть только мастер.' }); return true; }
        const actor = findToken(scene, cleanId(body.actorTokenId, null));
        if (!actor || actor.defeated || actor.boardedVehicleId || !['character','npc'].includes(actor.kind)) { sendJson(res, 400, { ok: false, error: 'Нужен находящийся рядом персонаж.' }); return true; }
        if (!master && !canControlToken(actor, req, requestUrl, body)) { sendJson(res, 403, { ok: false, error: 'Вы не управляете этим персонажем.' }); return true; }
        const center = doorGeometry(scene, door).center;
        if (distanceFeet(scene, actor, center) > 10.01) { sendJson(res, 409, { ok: false, error: 'Подойдите ближе к двери.' }); return true; }
      }
      door.open = body.open === undefined ? !door.open : Boolean(body.open); scene.updatedAt = nowIso();
      await persist(); broadcast('battlemap-replaced', body.clientId, { reason: 'door-toggled', sceneId: scene.id, doorId: door.id }); broadcastAudioEffect(scene.id, door.open ? 'door.open' : 'door.close', { x:safeNumber(door.x, safeNumber(door.x1,0)), y:safeNumber(door.y, safeNumber(door.y1,0)), doorId:door.id }, body.clientId); sendJson(res, 200, { ok: true, door }); return true;
    }

    const coversMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/covers$/);
    if (coversMatch && req.method === 'PUT') {
      const body = await readJsonBody(req);
      if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok: false, error: 'Это действие доступно только мастеру.' }); return true; }
      const scene = findScene(cleanId(decodeURIComponent(coversMatch[1]), null));
      if (!scene) { sendJson(res, 404, { ok: false, error: 'Сцена не найдена.' }); return true; }
      scene.covers = (Array.isArray(body.covers) ? body.covers : []).map(normalizeCover).slice(0, MAX_COVERS); scene.updatedAt = nowIso();
      await persist(); broadcast('battlemap-replaced', body.clientId, { reason: 'covers-updated', sceneId: scene.id }); sendJson(res, 200, { ok: true, covers: scene.covers }); return true;
    }

    const fogMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/fog$/);
    if (fogMatch && req.method === 'PUT') {
      const body = await readJsonBody(req);
      if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok: false, error: 'Это действие доступно только мастеру.' }); return true; }
      const scene = findScene(cleanId(decodeURIComponent(fogMatch[1]), null));
      if (!scene) { sendJson(res, 404, { ok: false, error: 'Сцена не найдена.' }); return true; }
      scene.fog = normalizeFog({ ...scene.fog, ...body.fog, explored: scene.fog.explored }); scene.updatedAt = nowIso();
      await persist(); broadcast('battlemap-replaced', body.clientId, { reason: 'fog-updated', sceneId: scene.id }); sendJson(res, 200, { ok: true, fog: scene.fog }); return true;
    }

    const exploredMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/explored$/);
    if (exploredMatch && req.method === 'PUT') {
      const body = await readJsonBody(req);
      const scene = findScene(cleanId(decodeURIComponent(exploredMatch[1]), null));
      if (!scene) { sendJson(res, 404, { ok: false, error: 'Сцена не найдена.' }); return true; }
      const clientId = cleanId(body.clientId, null);
      if (!clientId) { sendJson(res, 400, { ok: false, error: 'Нет идентификатора игрока.' }); return true; }
      const incoming = (Array.isArray(body.cells) ? body.cells : []).map(String).filter(value => /^-?\d+:-?\d+$/.test(value));
      const current = new Set(scene.fog.explored[clientId] || []);
      for (const cell of incoming) current.add(cell);
      scene.fog.explored[clientId] = [...current].slice(-MAX_EXPLORED_CELLS);
      await persist();
      sendJson(res, 200, { ok: true, count: scene.fog.explored[clientId].length });
      return true;
    }


    const effectsMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/effects(?:\/([^/]+))?$/);
    if (effectsMatch && req.method === 'DELETE') {
      const body=await readJsonBody(req).catch(()=>({}));if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Это действие доступно только мастеру.'});return true;}
      const scene=findScene(cleanId(decodeURIComponent(effectsMatch[1]),null));if(!scene){sendJson(res,404,{ok:false,error:'Сцена не найдена.'});return true;}
      if(state.combat?.active&&state.combat.sceneId===scene.id){sendJson(res,409,{ok:false,error:'Постоянные области можно удалять через эту панель только вне боя.'});return true;}
      const effectId=effectsMatch[2]?cleanId(decodeURIComponent(effectsMatch[2]),null):null,before=scene.effects.length;
      scene.effects=effectId?scene.effects.filter(effect=>effect.id!==effectId):[];scene.updatedAt=nowIso();await persist();broadcast('battlemap-replaced',body.clientId,{reason:'effects-cleared',sceneId:scene.id});sendJson(res,200,{ok:true,removed:before-scene.effects.length,effects:scene.effects});return true;
    }

    const audioSourcesMatch = pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/audio-sources$/);
    if(audioSourcesMatch&&req.method==='PUT'){
      const body=await readJsonBody(req);if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Это действие доступно только мастеру.'});return true;}
      const scene=findScene(cleanId(decodeURIComponent(audioSourcesMatch[1]),null));if(!scene){sendJson(res,404,{ok:false,error:'Сцена не найдена.'});return true;}
      const libraryIds=combinedAudioIds();scene.audioSources=(Array.isArray(body.audioSources)?body.audioSources:[]).map(normalizeAudioSource).filter(source=>libraryIds.has(source.trackId)).slice(0,MAX_AUDIO_SOURCES);scene.updatedAt=nowIso();await persist();broadcast('battlemap-replaced',body.clientId,{reason:'audio-sources-updated',sceneId:scene.id});sendJson(res,200,{ok:true,audioSources:scene.audioSources});return true;
    }

    if(pathname==='/api/battlemap/move-path'&&req.method==='POST'){
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null));
      if(!scene||!token){sendJson(res,404,{ok:false,error:'Сцена или токен не найдены.'});return true;}
      if(!canControlToken(token,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете этим токеном.'});return true;}
      const points=(Array.isArray(body.points)?body.points:[]).slice(0,320).map(point=>({x:clamp(safeNumber(point?.x,token.x),0,scene.mapWidth),y:clamp(safeNumber(point?.y,token.y),0,scene.mapHeight)}));
      if(points.length<2){sendJson(res,400,{ok:false,error:'Маршрут должен содержать хотя бы две точки.'});return true;}
      const durationMs=clamp(Math.round(safeNumber(body.durationMs,1600)),450,30000),authorizedMaster=isMasterAuthorized(req,requestUrl,body);
      const motion={id:makeId('move-path'),sceneId:scene.id,tokenId:token.id,tokenName:token.name,points,color:cleanColor(body.color,token.display?.borderColor||'#62d8ff'),durationMs,actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,authorizedMaster?'Мастер':'Игрок'),at:nowIso()};
      for(const client of getSseClients().values())try{sseWrite(client.response,'battlemap-move-path',{motion:clone(motion),sourceClientId:body.clientId,at:nowIso()});}catch{}
      sendJson(res,201,{ok:true,motion});return true;
    }

    if(pathname==='/api/battlemap/ping'&&req.method==='POST'){
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,null));if(!scene){sendJson(res,404,{ok:false,error:'Сцена не найдена.'});return true;}
      const authorizedMaster=isMasterAuthorized(req,requestUrl,body);if(!authorizedMaster&&scene.settings.playerCanPing===false){sendJson(res,403,{ok:false,error:'Мастер отключил пинги игроков на этой сцене.'});return true;}
      const ping={id:makeId('ping'),sceneId:scene.id,x:clamp(safeNumber(body.x,0),0,scene.mapWidth),y:clamp(safeNumber(body.y,0),0,scene.mapHeight),color:cleanColor(body.color,'#ffd36a'),actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,authorizedMaster?'Мастер':'Игрок'),at:nowIso()};
      for(const client of getSseClients().values())try{sseWrite(client.response,'battlemap-ping',{ping:clone(ping),sourceClientId:body.clientId,at:nowIso()});}catch{}
      sendJson(res,201,{ok:true,ping});return true;
    }
    const drawingsMatch=pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/drawings(?:\/([^/]+))?$/);
    if(drawingsMatch){
      const body=await readJsonBody(req).catch(()=>({})),scene=findScene(cleanId(decodeURIComponent(drawingsMatch[1]),null));if(!scene){sendJson(res,404,{ok:false,error:'Сцена не найдена.'});return true;}
      const authorizedMaster=isMasterAuthorized(req,requestUrl,body),drawingId=drawingsMatch[2]?cleanId(decodeURIComponent(drawingsMatch[2]),null):null;
      if(!authorizedMaster&&scene.settings.playerCanDraw===false){sendJson(res,403,{ok:false,error:'Мастер отключил рисование игроков на этой сцене.'});return true;}
      if(req.method==='POST'&&!drawingId){
        const drawing=normalizeDrawing({...body.drawing,id:makeId('drawing'),authorId:cleanId(body.clientId,null),authorName:cleanName(body.playerName,authorizedMaster?'Мастер':'Игрок'),createdAt:nowIso()},scene.drawings.length);
        if(drawing.points.length<2){sendJson(res,400,{ok:false,error:'Линия слишком короткая.'});return true;}scene.drawings.push(drawing);if(scene.drawings.length>MAX_DRAWINGS)scene.drawings.splice(0,scene.drawings.length-MAX_DRAWINGS);scene.updatedAt=nowIso();await persist();broadcast('battlemap-replaced',body.clientId,{reason:'drawing-created',sceneId:scene.id,drawingId:drawing.id});sendJson(res,201,{ok:true,drawing});return true;
      }
      if(req.method==='DELETE'){
        const before=scene.drawings.length;if(drawingId){const existing=scene.drawings.find(item=>item.id===drawingId);if(!existing){sendJson(res,404,{ok:false,error:'Рисунок не найден.'});return true;}if(!authorizedMaster&&existing.authorId!==cleanId(body.clientId,null)){sendJson(res,403,{ok:false,error:'Игрок может стереть только собственный рисунок.'});return true;}scene.drawings=scene.drawings.filter(item=>item.id!==drawingId);}else if(authorizedMaster&&body.scope!=='own')scene.drawings=[];else{const actorId=cleanId(body.clientId,null);scene.drawings=scene.drawings.filter(item=>item.authorId!==actorId);}scene.updatedAt=nowIso();await persist();broadcast('battlemap-replaced',body.clientId,{reason:'drawings-cleared',sceneId:scene.id});sendJson(res,200,{ok:true,removed:before-scene.drawings.length,drawings:scene.drawings});return true;
      }
    }


    const mapWidgetsMatch=pathname.match(/^\/api\/battlemap\/scenes\/([^/]+)\/map-widgets$/);
    if(mapWidgetsMatch&&req.method==='PUT'){
      const body=await readJsonBody(req);if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Маркеры и счётчики может изменять только мастер.'});return true;}
      const scene=findScene(cleanId(decodeURIComponent(mapWidgetsMatch[1]),null));if(!scene){sendJson(res,404,{ok:false,error:'Сцена не найдена.'});return true;}
      scene.mapWidgets=(Array.isArray(body.mapWidgets)?body.mapWidgets:[]).map(normalizeMapWidget).slice(0,MAX_MAP_WIDGETS);scene.updatedAt=nowIso();await persist();
      broadcast('battlemap-replaced',body.clientId,{reason:'map-widgets-updated',sceneId:scene.id});sendJson(res,200,{ok:true,mapWidgets:scene.mapWidgets});return true;
    }

    if(pathname==='/api/battlemap/vehicle-profiles'&&req.method==='GET'){sendJson(res,200,{ok:true,profiles:Object.entries(VEHICLE_PROFILES).map(([id,value])=>({id,...value}))});return true;}
    if(pathname==='/api/battlemap/vehicle/board'&&req.method==='POST'){
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,null)),vehicle=findToken(scene,cleanId(body.vehicleTokenId,null)),rider=findToken(scene,cleanId(body.tokenId,null));
      if(!scene||!vehicle||vehicle.kind!=='vehicle'||!rider||rider.kind==='vehicle'){sendJson(res,404,{ok:false,error:'Транспорт или пассажир не найден.'});return true;}
      if(!canControlToken(rider,req,requestUrl,body)&&!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Нет права управлять этим токеном.'});return true;}
      if(contactDistanceFeet(scene,vehicle,rider)>5.01){sendJson(res,409,{ok:false,error:'Чтобы сесть, персонаж должен стоять вплотную к транспорту.'});return true;}
      if(rider.boardedVehicleId){sendJson(res,409,{ok:false,error:'Персонаж уже находится в транспорте.'});return true;}
      const requestedRole=['driver','gunner','passenger'].includes(body.role)?body.role:(vehicle.vehicle.driverTokenId?'passenger':'driver');
      const assignments=vehicle.vehicle.seatAssignments||(vehicle.vehicle.seatAssignments={});
      const occupied=(role)=>(vehicle.vehicle.occupants||[]).filter(id=>vehicleSeatRole(vehicle,id)===role).length;
      if(requestedRole==='driver'&&vehicle.vehicle.driverTokenId){sendJson(res,409,{ok:false,error:'Место водителя уже занято.'});return true;}
      if(requestedRole==='gunner'&&occupied('gunner')>=Math.max(0,safeNumber(vehicle.vehicle.gunnerCapacity,0))){sendJson(res,409,{ok:false,error:'Свободных мест стрелка нет.'});return true;}
      if(requestedRole==='passenger'&&occupied('passenger')>=Math.max(0,safeNumber(vehicle.vehicle.passengerCapacity,0))){sendJson(res,409,{ok:false,error:'Свободных пассажирских мест нет.'});return true;}
      vehicle.vehicle.occupants.push(rider.id);assignments[rider.id]={role:requestedRole};if(requestedRole==='driver')vehicle.vehicle.driverTokenId=rider.id;
      rider.boardedVehicleId=vehicle.id;rider.x=vehicle.x;rider.y=vehicle.y;await persist();broadcast('battlemap-replaced',body.clientId,{reason:'vehicle-boarded',sceneId:scene.id});sendJson(res,200,{ok:true,vehicle,rider,role:requestedRole});return true;
    }
    if(pathname==='/api/battlemap/vehicle/exit'&&req.method==='POST'){
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,null)),vehicle=findToken(scene,cleanId(body.vehicleTokenId,null)),rider=findToken(scene,cleanId(body.tokenId,null));
      if(!scene||!vehicle||vehicle.kind!=='vehicle'||!rider||rider.boardedVehicleId!==vehicle.id){sendJson(res,404,{ok:false,error:'Пассажир не находится в этом транспорте.'});return true;}
      if(!canControlToken(rider,req,requestUrl,body)&&!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Нет права управлять этим токеном.'});return true;}
      const oldRole=vehicleSeatRole(vehicle,rider.id);vehicle.vehicle.occupants=vehicle.vehicle.occupants.filter(id=>id!==rider.id);if(vehicle.vehicle.seatAssignments)delete vehicle.vehicle.seatAssignments[rider.id];if(vehicle.vehicle.driverTokenId===rider.id)vehicle.vehicle.driverTokenId=null;
      rider.boardedVehicleId=null;const offset=tokenFootprintHalfSize(scene,vehicle)+tokenFootprintHalfSize(scene,rider)+8;rider.x=clamp(vehicle.x+offset,0,scene.mapWidth);rider.y=clamp(vehicle.y,0,scene.mapHeight);await persist();broadcast('battlemap-replaced',body.clientId,{reason:'vehicle-exited',sceneId:scene.id});sendJson(res,200,{ok:true,vehicle,rider,role:oldRole});return true;
    }
    if(pathname==='/api/battlemap/vehicle/action'&&req.method==='POST'){
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,null)),vehicle=findToken(scene,cleanId(body.vehicleTokenId,null));if(!scene||!vehicle||vehicle.kind!=='vehicle'){sendJson(res,404,{ok:false,error:'Транспорт не найден.'});return true;}
      const driver=findToken(scene,vehicle.vehicle.driverTokenId);if(!driver||vehicleSeatRole(vehicle,driver.id)!=='driver'){sendJson(res,409,{ok:false,error:'У транспорта нет водителя.'});return true;}const vehicleMaster=isMasterAuthorized(req,requestUrl,body);if(!canControlToken(driver,req,requestUrl,body)&&!vehicleMaster){sendJson(res,403,{ok:false,error:'Действие доступно водителю или мастеру.'});return true;}if(state.combat?.active&&!vehicleMaster&&!isCurrentCombatToken(scene,driver)){sendJson(res,409,{ok:false,error:'Сейчас ход другого участника.'});return true;}
      const action=String(body.action||''),cost=action==='gas'?2:action==='ram'?2:action==='emergency'?Math.max(1,Math.min(2,Math.round(safeNumber(body.cost,1)))):1;spendTokenOd(driver,cost);const round=getCampaign().initiative?.round||0;
      if(action==='sharp'){vehicle.vehicle.sharpManeuverRound=round;vehicle.vehicle.evasiveUntilDriverTurn=true;vehicle.vehicle.roughUntilDriverTurn=true;}else if(action==='stabilize'){vehicle.vehicle.stabilizedRound=round;vehicle.vehicle.stabilizedUntilDriverTurn=true;vehicle.vehicle.roughUntilDriverTurn=false;}else if(action==='drive'){vehicle.vehicle.movedRound=round;resetTokenMovement(vehicle);}else if(action==='gas'){vehicle.vehicle.movedRound=round;resetTokenMovement(vehicle);}else if(action==='ram'||action==='emergency'){vehicle.vehicle.stabilizedUntilDriverTurn=false;vehicle.vehicle.roughUntilDriverTurn=true;vehicle.vehicle.movedRound=round;resetTokenMovement(vehicle);}else{refundTokenOd(driver,cost);sendJson(res,400,{ok:false,error:'Неизвестное действие транспорта.'});return true;}
      await persistCampaign();await persist();broadcastVehicleEffect(scene.id,{vehicleTokenId:vehicle.id,action,durationMs:action==='stabilize'?1000:action==='sharp'?900:action==='ram'?1100:action==='emergency'?1200:800},body.clientId);broadcast('battlemap-replaced',body.clientId,{reason:'vehicle-action',sceneId:scene.id});sendJson(res,200,{ok:true,vehicle,action,cost});return true;
    }
    if(pathname==='/api/battlemap/vehicle/attack'&&req.method==='POST'){
      const body=await readJsonBody(req),key=requestKey(body,'vehicle-attack'),cached=cachedRequest(key);if(cached){sendJson(res,200,cached);return true;}
      const scene=findScene(cleanId(body.sceneId,null)),vehicle=findToken(scene,cleanId(body.vehicleTokenId,null)),gunner=findToken(scene,cleanId(body.gunnerTokenId||body.attackerTokenId,null)),target=findToken(scene,cleanId(body.targetTokenId,null));
      if(!scene||!vehicle||vehicle.kind!=='vehicle'||!gunner||!target){sendJson(res,404,{ok:false,error:'Транспорт, стрелок или цель не найдены.'});return true;}
      if(target.id===vehicle.id||target.id===gunner.id){sendJson(res,409,{ok:false,error:'Нельзя выбрать собственный транспорт или самого стрелка целью встроенного оружия.'});return true;}
      if(gunner.boardedVehicleId!==vehicle.id||vehicleSeatRole(vehicle,gunner.id)!=='gunner'){sendJson(res,409,{ok:false,error:'Персонаж должен занимать место стрелка в этом транспорте.'});return true;}
      if(!canControlToken(gunner,req,requestUrl,body)&&!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Нет права управлять стрелком.'});return true;}
      if(state.combat?.active&&!isMasterAuthorized(req,requestUrl,body)&&!isCurrentCombatToken(scene,gunner)){sendJson(res,409,{ok:false,error:'Сейчас ход другого участника.'});return true;}
      if(target.kind==='interactive'){sendJson(res,409,{ok:false,error:'Установленное оружие пока не может выбирать интерактивный объект целью. Выберите живую цель или транспорт.'});return true;}
      const rawWeapon=(vehicle.vehicle.mountedWeapons||[]).find(item=>item.enabled!==false&&(item.id===body.weaponId||item.name===body.weaponId));if(!rawWeapon){sendJson(res,404,{ok:false,error:'Установленное оружие не найдено или отключено.'});return true;}const weapon=mountedWeaponForGunner(gunner,rawWeapon);try{assertMountedWeaponReady(vehicle,weapon);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}
      const origin=speciesCombatPoint(vehicle),shotMode=body.shotMode==='aimed'&&weapon.hitDieAimed?'aimed':'normal';let attack;
      try{attack=makeAttackRoll({...body,attackerTokenId:gunner.id,weaponId:weapon.id,shotMode,moved:false,targetMz:body.targetMz??null,situationalModifier:body.situationalModifier??0},scene,gunner,target,{weaponOverride:weapon,vehicleMounted:true,attackOrigin:origin,ignoreNearOriginCover:true,skipEngagedAttackerCheck:true,label:`${gunner.name} · ${vehicle.name}: ${weapon.name}${shotMode==='aimed'?' (прицельно)':''} → ${target.name}`});}
      catch(error){sendJson(res,error.statusCode||400,{ok:false,error:error.message||'Не удалось выполнить атаку транспорта.'});return true;}
      attack.kind='vehicle-mounted-attack';attack.vehicleTokenId=vehicle.id;attack.vehicleName=vehicle.name;attack.vehicleSeatRole='gunner';
      let roll=combatRollRecord(scene,gunner,attack,'Установленное оружие');roll=await awaitAttackRollResolution(scene,roll);attack=roll.battlemapAttack;
      try{await spendAttackResources(gunner,attack,{...body,spendResources:body.spendResources!==false},isMasterAuthorized(req,requestUrl,body));markMountedWeaponFired(vehicle,weapon);}
      catch(error){sendJson(res,error.statusCode||400,{ok:false,error:error.message||'Недостаточно ресурсов для атаки.'});return true;}
      const projectileTarget=targetPointForProjectile(scene,attack,target);broadcastProjectileEffect(scene.id,{id:attack.id,kind:projectileKindForWeapon(weapon),from:origin,to:projectileTarget,durationMs:projectileDurationMs(scene,origin,projectileTarget,weapon),hit:Boolean(attack.damageTargetTokenId),label:weapon.name},body.clientId);
      const damageTarget=attack.damageTargetTokenId?findToken(scene,attack.damageTargetTokenId):null;let damageResult=null;
      if(damageTarget&&body.autoApplyDamage){damageResult=damageTarget.kind==='vehicle'?await applyDamageToVehicle(scene,damageTarget,{...body,damage:attack.damage*(weaponIsHeavy(weapon)?2:1),damageTag:attack.damageTag,...attack.flags},{persistNow:false}):await applyDamageToTarget(scene,damageTarget,{...body,damage:attack.damage,damageTag:attack.damageTag,...attack.flags,sourceText:`${weapon.profile||''} ${weapon.description||''}`},{persist:false,recordHistory:true,role:isMasterAuthorized(req,requestUrl,body)?'master':'player'});}
      const damageText=damageResult?(damageTarget?.kind==='vehicle'?` Корпус: ${damageResult.afterHull}/${damageTarget.vehicle?.hullMax||'?'}; ${damageResult.status||'повреждение'}.`:(damageResult.blocked?' Урон заблокирован.':` Ранения: ${(damageResult.applied||[]).join(', ')||'нет'}${damageResult.moraleLoss?`; мораль −${damageResult.moraleLoss}`:''}.`)):'';
      const entry=appendTableLog({type:'roll',actorId:attack.actorId,actorName:attack.actorName,text:`${attack.label}: ${attackTotalBreakdown(attack,false)} против МЗ ${attack.targetMz} — ${attack.hit?'попадание':'промах'}.${damageText}`,visibility:attack.visibility,sceneId:scene.id,tokenId:gunner.id,meta:{attackId:attack.id,vehicleTokenId:vehicle.id,formulas:journalRollFormulas(attack.formula,damageResult)}});broadcastTableLog(entry);
      broadcastAudioEffect(scene.id,weaponSoundKey(weapon),{tokenId:vehicle.id,x:vehicle.x,y:vehicle.y,targetTokenId:target.id},body.clientId);
      await persistCampaign();await persist();broadcast('battlemap-replaced',body.clientId,{reason:'vehicle-mounted-attack',sceneId:scene.id});const payload={ok:true,attack,roll,entry,damageResult};storeRequest(key,payload);sendJson(res,201,payload);return true;
    }
    if(pathname==='/api/battlemap/vehicle/reload'&&req.method==='POST'){
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,null)),vehicle=findToken(scene,cleanId(body.vehicleTokenId,null)),gunner=findToken(scene,cleanId(body.gunnerTokenId||body.tokenId,null));
      if(!scene||!vehicle||vehicle.kind!=='vehicle'||!gunner){sendJson(res,404,{ok:false,error:'Транспорт или стрелок не найдены.'});return true;}
      if(gunner.boardedVehicleId!==vehicle.id||vehicleSeatRole(vehicle,gunner.id)!=='gunner'){sendJson(res,409,{ok:false,error:'Перезаряжать встроенное оружие может стрелок, занимающий стрелковое место.'});return true;}
      const vehicleMaster=isMasterAuthorized(req,requestUrl,body);if(!canControlToken(gunner,req,requestUrl,body)&&!vehicleMaster){sendJson(res,403,{ok:false,error:'Нет права управлять стрелком.'});return true;}try{assertTokenCanAct(gunner);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}if(state.combat?.active&&!vehicleMaster&&!isCurrentCombatToken(scene,gunner)){sendJson(res,409,{ok:false,error:'Сейчас ход другого участника.'});return true;}
      const weapon=(vehicle.vehicle.mountedWeapons||[]).find(item=>item.enabled!==false&&(item.id===body.weaponId||item.name===body.weaponId));if(!weapon){sendJson(res,404,{ok:false,error:'Встроенное оружие не найдено.'});return true;}
      let result;try{result=reloadMountedWeapon(vehicle,gunner,weapon);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}
      const entry=appendTableLog({type:'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text:`${gunner.name} · ${vehicle.name}: перезаряжает «${weapon.name}» за ${result.cost} ОД.`,sceneId:scene.id,tokenId:gunner.id});
      await persistCampaign();await persist();broadcastTableLog(entry);broadcast('battlemap-replaced',body.clientId,{reason:'vehicle-mounted-reload',sceneId:scene.id});broadcastVehicleEffect(scene.id,{vehicleTokenId:vehicle.id,action:'reload',durationMs:750},body.clientId);broadcastAudioEffect(scene.id,/гранатом[её]т|пушк|оруди|излучатель/i.test(weaponText(weapon))?'heavy.reload.grenadeLauncher':'heavy.reload.machinegun',{tokenId:vehicle.id,x:vehicle.x,y:vehicle.y},body.clientId);sendJson(res,200,{ok:true,weaponId:weapon.id,loaded:true,cost:result.cost,entry});return true;
    }
    if(pathname==='/api/battlemap/vehicle/area-attack'&&req.method==='POST'){
      const body=await readJsonBody(req),key=requestKey(body,'vehicle-area-attack'),cached=cachedRequest(key);if(cached){sendJson(res,200,cached);return true;}
      const scene=findScene(cleanId(body.sceneId,null)),vehicle=findToken(scene,cleanId(body.vehicleTokenId,null)),gunner=findToken(scene,cleanId(body.gunnerTokenId||body.attackerTokenId,null));
      if(!scene||!vehicle||vehicle.kind!=='vehicle'||!gunner){sendJson(res,404,{ok:false,error:'Транспорт или стрелок не найдены.'});return true;}
      if(gunner.boardedVehicleId!==vehicle.id||vehicleSeatRole(vehicle,gunner.id)!=='gunner'){sendJson(res,409,{ok:false,error:'Персонаж должен занимать место стрелка в этом транспорте.'});return true;}
      const vehicleMaster=isMasterAuthorized(req,requestUrl,body);if(!canControlToken(gunner,req,requestUrl,body)&&!vehicleMaster){sendJson(res,403,{ok:false,error:'Нет права управлять стрелком.'});return true;}try{assertTokenCanAct(gunner,{attack:true});}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}
      if(state.combat?.active&&!vehicleMaster&&!isCurrentCombatToken(scene,gunner)){sendJson(res,409,{ok:false,error:'Сейчас ход другого участника.'});return true;}
      const rawWeapon=(vehicle.vehicle.mountedWeapons||[]).find(item=>item.enabled!==false&&(item.id===body.weaponId||item.name===body.weaponId));if(!rawWeapon||safeNumber(rawWeapon.radius,0)<=0){sendJson(res,400,{ok:false,error:'Выбранный профиль встроенного оружия не имеет радиуса поражения.'});return true;}const weapon=mountedWeaponForGunner(gunner,rawWeapon);try{assertMountedWeaponReady(vehicle,weapon);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}
      let point={x:clamp(safeNumber(body.x,vehicle.x),0,scene.mapWidth),y:clamp(safeNumber(body.y,vehicle.y),0,scene.mapHeight)},aimPoint={...point},origin=speciesCombatPoint(vehicle);const distance=distanceFeet(scene,vehicle,point);if(distance>weapon.range+.01){sendJson(res,409,{ok:false,error:`Точка вне дальности: ${distance.toFixed(1)} фт при максимуме ${weapon.range} фт.`});return true;}if(contactBlockedByWall(scene,origin,point)){sendJson(res,409,{ok:false,error:'Траектория установленного орудия перекрыта стеной или закрытой дверью.'});return true;}
      const featureAttack=consumeFeatureEffect(gunner,'nextAttack'),featureAttackRoll=featureEffectRoll(featureAttack),sides=dieSides(weapon.hitDieNormal,6),rollMode=mergeRollCondition(featureAttack?.condition==='advantage',featureAttack?.condition==='hindrance','normal'),initialRolls=rollMode===0?[rollOne(sides)]:[rollOne(sides),rollOne(sides)],initialRoll=rollMode<0?Math.min(...initialRolls):rollMode>0?Math.max(...initialRolls):initialRolls[0],baseHitBonus=Math.round(safeNumber(weapon.hitBonus,0)+safeNumber(featureAttack?.flat,0)),hitBonus=baseHitBonus+featureAttackRoll,targetNumber=3;
      let attack={id:makeId('vehicle-area'),at:nowIso(),actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),kind:'vehicle-area-attack',visibility:body.visibility==='master'?'master':'public',sceneId:scene.id,attackerTokenId:gunner.id,attackerName:gunner.name,vehicleTokenId:vehicle.id,vehicleName:vehicle.name,targetTokenId:null,targetName:'точка области',weapon,hitDie:weapon.hitDieNormal,attackRolls:[...initialRolls],reactionRollMode:rollMode,rolls:[...initialRolls,...(featureAttackRoll?[featureAttackRoll]:[])],roll:initialRoll,baseHitBonus,hitBonus,total:initialRoll+hitBonus,targetMz:targetNumber,hit:initialRoll+hitBonus>=targetNumber,damage:weapon.damage,damageTag:weapon.damageTag||'heavy',flags:attackFlagsFromWeapon(weapon),featureEffects:{attack:featureAttack,attackRoll:featureAttackRoll},formula:attackFormulaText(weapon.hitDieNormal,rollMode,featureAttack?.extraDie,baseHitBonus,'3'),label:`${gunner.name} · ${vehicle.name}: ${weapon.name} по области`};
      let areaRoll=combatRollRecord(scene,gunner,attack,'Установленное оружие: атака по области');areaRoll=await awaitAttackRollResolution(scene,areaRoll);attack=areaRoll.battlemapAttack;const hit=Boolean(attack.hit),roll=attack.roll,total=attack.total,finalRolls=attack.attackRolls||initialRolls;
      let scatter=0,wallImpact=null;if(!hit){const scatterResolved=await resolveScalarRoll(scene,gunner,{body,label:`${gunner.name}: отклонение выстрела встроенного орудия`,sides:6,kind:'scatter',purpose:'scatter'});scatter=scatterResolved.value*5;const angle=Math.random()*Math.PI*2,px=feetToScenePixels(scene,scatter),scattered={x:clamp(point.x+Math.cos(angle)*px,0,scene.mapWidth),y:clamp(point.y+Math.sin(angle)*px,0,scene.mapHeight)};wallImpact=projectileWallImpact(scene,origin,scattered);point=wallImpact?{x:wallImpact.x,y:wallImpact.y}:scattered;}
      const cost={id:makeId('vehicle-area-cost'),sceneId:scene.id,odCost:weapon.odCost,obCost:Math.max(0,weapon.obCost||0),weapon};try{await spendAttackResources(gunner,cost,{...body,spendResources:body.spendResources!==false},vehicleMaster);markMountedWeaponFired(vehicle,weapon);}catch(error){sendJson(res,error.statusCode||400,{ok:false,error:error.message||'Недостаточно ресурсов для выстрела.'});return true;}
      const minimumSafeRange=Math.max(0,safeNumber(weapon.minimumSafeRange,weaponIsExplosiveHeavy(weapon)?20:0)),unsafeHeavyShot=weaponIsExplosiveHeavy(weapon)&&minimumSafeRange>0&&distance<minimumSafeRange,affected=[];
      for(const target of scene.tokens){if(!['character','npc','vehicle'].includes(target.kind))continue;const feet=distanceFeet(scene,target,point),forcedOuter=unsafeHeavyShot&&target.id===vehicle.id;if(feet>weapon.radius+.01&&!forcedOuter)continue;const zoneDamage=forcedOuter?Math.floor(attack.damage/2):(feet<=weapon.radius/2?attack.damage:Math.floor(attack.damage/2)),wallBlocked=!forcedOuter&&explosionBlockedByWall(scene,point,target),coverReduction=forcedOuter||wallBlocked?0:explosionCoverReduction(scene,point,target),baseDealt=wallBlocked?0:Math.max(0,zoneDamage-coverReduction),dealt=target.kind==='vehicle'&&weaponIsHeavy(weapon)?baseDealt*2:baseDealt;let result=null;if(dealt>0)result=target.kind==='vehicle'?await applyDamageToVehicle(scene,target,{...body,damage:dealt,damageTag:weapon.damageTag||'heavy'},{persistNow:false}):await applyDamageToTarget(scene,target,{...body,damage:dealt,damageTag:weapon.damageTag||'heavy',explosive:true,armorPiercing:attack.flags?.armorPiercing,anaxion:attack.flags?.anaxion,anaxionArmorAllowed:attack.flags?.anaxionArmorAllowed,sourceText:weapon.name,bleeding:false},{persist:false,recordHistory:false,role:vehicleMaster?'master':'player'});let extraMorale=0;if(/анаксионный излучатель/i.test(weaponText(weapon))&&!wallBlocked){const moraleRoll=await resolveScalarRoll(scene,target,{body,label:`${target.name}: дополнительная потеря морали от анаксионного излучателя`,sides:6,kind:'anaxion-morale',purpose:'morale-loss'});extraMorale=-(await adjustTokenMoraleResolved(scene,target,-moraleRoll.total,body));}affected.push({tokenId:target.id,name:target.name,distance:Math.round(feet*10)/10,damage:dealt,coverReduction,wallBlocked,result,extraMorale,unsafeOuterZone:forcedOuter});}
      const damagedCovers=blastDamageCovers(scene,point,weapon.radius,weapon.damage,{heavy:weaponIsHeavy(weapon)}),visualZone=normalizeEffectZone({id:makeId('blast'),name:`${weapon.name}: область`,type:'explosion',x:point.x,y:point.y,radius:weapon.radius,color:'#ff9b43',opacity:.24,remainingRounds:1,visualOnly:true,pulse:true,sourceName:weapon.name},scene.effects.length),entry=appendTableLog({type:'roll',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text:`${gunner.name} · ${vehicle.name}: ${weapon.name} по области — ${total} против 3; ${hit?'точное попадание':`отклонение ${scatter} фт`}; затронуто целей: ${affected.length}${damagedCovers.length?`, повреждено укрытий: ${damagedCovers.length}`:''}${unsafeHeavyShot?' Транспорт попал во внешнюю зону собственного взрыва.':''}.`,sceneId:scene.id,tokenId:gunner.id,meta:{formulas:[attack.formula,...(!hit?['Отклонение: 1d6 × 5 фт']:[]),...affected.flatMap(item=>journalRollFormulas(null,item.result))]}});
      await persistCampaign();await persist();broadcastTableLog(entry);broadcastProjectileEffect(scene.id,{id:`vehicle-launcher-${entry.id}`,kind:projectileKindForWeapon(weapon),from:origin,to:{...point,elevation:0},durationMs:clamp(650+distanceFeet(scene,vehicle,point)*2.5,700,1600),hit:true,radius:blastRadius,label:weapon.name},body.clientId);broadcastTransientEffect(scene.id,visualZone,9000,body.clientId);broadcastAudioEffect(scene.id,weaponSoundKey(weapon),{tokenId:vehicle.id,x:vehicle.x,y:vehicle.y},body.clientId);broadcastAudioEffect(scene.id,'grenade.explosion',{tokenId:vehicle.id,x:point.x,y:point.y},body.clientId);broadcast('battlemap-replaced',body.clientId,{reason:'vehicle-area-attack',sceneId:scene.id});const payload={ok:true,attack,hit,rolls:[...finalRolls,...(featureAttackRoll?[featureAttackRoll]:[])],roll,hitBonus:attack.hitBonus,total,targetNumber,scatter,wallImpact:Boolean(wallImpact),point,weapon,affected,damagedCovers,unsafeHeavyShot,visualZone,visualTtlMs:9000,rollRecord:areaRoll,entry};storeRequest(key,payload);sendJson(res,201,payload);return true;
    }
    if(pathname==='/api/battlemap/vehicle/weapon-zone'&&req.method==='POST'){
      const body=await readJsonBody(req),key=requestKey(body,'vehicle-weapon-zone'),cached=cachedRequest(key);if(cached){sendJson(res,200,cached);return true;}
      const scene=findScene(cleanId(body.sceneId,null)),vehicle=findToken(scene,cleanId(body.vehicleTokenId,null)),gunner=findToken(scene,cleanId(body.gunnerTokenId||body.attackerTokenId,null));if(!scene||!vehicle||vehicle.kind!=='vehicle'||!gunner){sendJson(res,404,{ok:false,error:'Транспорт или стрелок не найдены.'});return true;}
      if(gunner.boardedVehicleId!==vehicle.id||vehicleSeatRole(vehicle,gunner.id)!=='gunner'){sendJson(res,409,{ok:false,error:'Персонаж должен занимать место стрелка в этом транспорте.'});return true;}const vehicleMaster=isMasterAuthorized(req,requestUrl,body);if(!canControlToken(gunner,req,requestUrl,body)&&!vehicleMaster){sendJson(res,403,{ok:false,error:'Нет права управлять стрелком.'});return true;}try{assertTokenCanAct(gunner,{attack:true});}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}if(state.combat?.active&&!vehicleMaster&&!isCurrentCombatToken(scene,gunner)){sendJson(res,409,{ok:false,error:'Сейчас ход другого участника.'});return true;}
      const rawWeapon=(vehicle.vehicle.mountedWeapons||[]).find(item=>item.enabled!==false&&(item.id===body.weaponId||item.name===body.weaponId));if(!rawWeapon){sendJson(res,400,{ok:false,error:'Встроенное оружие не найдено.'});return true;}const weapon=mountedWeaponForGunner(gunner,rawWeapon);try{assertMountedWeaponReady(vehicle,weapon);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}const modeName=String(body.mode||''),point={x:clamp(safeNumber(body.x,vehicle.x),0,scene.mapWidth),y:clamp(safeNumber(body.y,vehicle.y),0,scene.mapHeight)},origin=speciesCombatPoint(vehicle);if(distanceFeet(scene,vehicle,point)>weapon.range+.01){sendJson(res,409,{ok:false,error:'Точка вне дальности встроенного оружия.'});return true;}if(modeName==='suppression'&&!weaponSupportsSuppression(weapon)){sendJson(res,409,{ok:false,error:weapon.operatorTraining?.trained===false?'У стрелка недостаточный уровень владения для специального режима этого профиля.':'Этот профиль не может использовать Подавление.'});return true;}if(modeName==='barrage'&&!weaponSupportsBarrage(weapon)){sendJson(res,409,{ok:false,error:weapon.operatorTraining?.trained===false?'У стрелка недостаточный уровень владения для специального режима этого профиля.':'Этот профиль не может использовать Шквальный огонь.'});return true;}if(!['suppression','barrage'].includes(modeName)){sendJson(res,400,{ok:false,error:'Неизвестный зональный режим.'});return true;}if(contactBlockedByWall(scene,origin,point)){sendJson(res,409,{ok:false,error:'Линия огня перекрыта стеной или закрытой дверью.'});return true;}
      const cost={id:makeId('vehicle-zone-cost'),sceneId:scene.id,odCost:weapon.odCost,obCost:1,weapon};try{await spendAttackResources(gunner,cost,{...body,spendResources:body.spendResources!==false},vehicleMaster);markMountedWeaponFired(vehicle,weapon);}catch(error){sendJson(res,error.statusCode||400,{ok:false,error:error.message||'Недостаточно ресурсов для режима огня.'});return true;}
      const zoneProfile=canonicalCombatWeaponProfile(weapon),effect=normalizeEffectZone({id:makeId(modeName),name:modeName==='barrage'?'Шквальный огонь':'Подавление',type:modeName==='barrage'?'barrage':'suppression',x:point.x,y:point.y,radius:modeName==='barrage'?(zoneProfile==='Тяжёлый пулемёт'?10.6:7.1):7.5,color:modeName==='barrage'?'#df6955':'#d7b45a',zoneDamage:modeName==='barrage'?(zoneProfile==='Тяжёлый пулемёт'?2:1):0,hitPenalty:modeName==='suppression'?((zoneProfile==='Автоматический карабин'?-1:0)+(weaponHasMod(weapon,'carbine_suppression_kit')?-1:0)):0,damageTag:weapon.damageTag||'medium',remainingRounds:1,durationMode:'owner-turn',createdRound:getCampaign().initiative?.round||0,ownerTokenId:gunner.id,sourceName:`${vehicle.name}: ${weapon.name}`,notes:modeName==='barrage'?'Урон при входе, пересечении или начале хода.':'Помеха на дальнобойные атаки из этой позиции.'},scene.effects.length);scene.effects.push(effect);
      const entry=appendTableLog({type:'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text:`${gunner.name} · ${vehicle.name}: ${effect.name} (${weapon.name}).`,sceneId:scene.id,tokenId:gunner.id});await persistCampaign();await persist();broadcastTableLog(entry);broadcast('battlemap-replaced',body.clientId,{reason:'vehicle-weapon-zone',sceneId:scene.id});broadcastAudioEffect(scene.id,modeName==='barrage'?'zone.barrage':'zone.suppression',{tokenId:vehicle.id,x:vehicle.x,y:vehicle.y,targetX:point.x,targetY:point.y},body.clientId);const payload={ok:true,effect,entry,weapon};storeRequest(key,payload);sendJson(res,201,payload);return true;
    }
    if(pathname==='/api/battlemap/vehicle/damage'&&req.method==='POST'){
      const body=await readJsonBody(req);if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Прямое применение урона транспорту доступно только мастеру.'});return true;}const scene=findScene(cleanId(body.sceneId,null)),vehicle=findToken(scene,cleanId(body.vehicleTokenId,null));const result=await applyDamageToVehicle(scene,vehicle,body);broadcast('battlemap-replaced',body.clientId,{reason:'vehicle-damaged',sceneId:scene.id});sendJson(res,200,result);return true;
    }


    if (pathname === '/api/battlemap/catalog/items' && req.method === 'GET') {
      const items=[...weaponCatalog.values()].map(item=>({name:item.name,type:item.type||'',desc:item.desc||item.description||'',damageTag:item.damageTag||'',price:item.price||0,models:Array.isArray(item.models)?item.models:[],armorClass:item.armorClass||'',armorBz:item.armorBz??null,armorFeature:item.armorFeature||'',anaxionSteps:item.anaxionSteps??null}));
      sendJson(res,200,{ok:true,items});return true;
    }

    if (pathname === '/api/battlemap/chat' && req.method === 'POST') {
      const body=await readJsonBody(req),text=cleanText(body.text,2000);if(!text){sendJson(res,400,{ok:false,error:'Сообщение пустое.'});return true;}
      const masterAuthorized=isMasterAuthorized(req,requestUrl,body),entry=appendTableLog({type:'chat',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,masterAuthorized?'Мастер':'Игрок'),text,visibility:body.visibility==='master'&&masterAuthorized?'master':'public',sceneId:cleanId(body.sceneId,state.activeSceneId)});
      await persist();broadcastTableLog(entry);sendJson(res,201,{ok:true,entry});return true;
    }
    if (pathname === '/api/battlemap/chat' && req.method === 'DELETE') {
      const body=await readJsonBody(req).catch(()=>({}));
      if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Очистить чат может только мастер.'});return true;}
      if(createSnapshot)await createSnapshot('before-battlemap-chat-clear');state.tableLog=[];await persist();broadcast('battlemap-replaced',body.clientId,{reason:'chat-cleared'});sendJson(res,200,{ok:true,tableLog:[]});return true;
    }
    const chatEntryMatch=pathname.match(/^\/api\/battlemap\/chat\/([^/]+)$/);
    if(chatEntryMatch&&req.method==='DELETE'){
      const body=await readJsonBody(req).catch(()=>({})),id=cleanId(decodeURIComponent(chatEntryMatch[1]),null),index=(state.tableLog||[]).findIndex(entry=>entry.id===id);
      if(index<0){sendJson(res,404,{ok:false,error:'Сообщение не найдено.'});return true;}
      const entry=state.tableLog[index],masterAuthorized=isMasterAuthorized(req,requestUrl,body),clientId=cleanId(body.clientId,null);
      if(!masterAuthorized&&!(entry.type==='chat'&&entry.actorId===clientId)){sendJson(res,403,{ok:false,error:'Можно удалить только своё сообщение.'});return true;}
      state.tableLog.splice(index,1);await persist();broadcast('battlemap-replaced',body.clientId,{reason:'chat-entry-deleted',entryId:id});sendJson(res,200,{ok:true,id});return true;
    }
    if(pathname==='/api/battlemap/weapon-action'&&req.method==='POST'){
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null));if(!scene||!token){sendJson(res,404,{ok:false,error:'Токен не найден.'});return true;}if(!canControlToken(token,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете токеном.'});return true;}try{assertTokenCanAct(token);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}if(state.combat?.active&&!isMasterAuthorized(req,requestUrl,body)&&!isCurrentCombatToken(scene,token)){sendJson(res,409,{ok:false,error:'Сейчас ход другого участника.'});return true;}
      const weapon=weaponsForToken(token).find(item=>item.id===body.weaponId||item.slot===body.weaponId||item.name===body.weaponId);if(!weapon){sendJson(res,404,{ok:false,error:'Оружие не найдено.'});return true;}
      const action=String(body.action||'');let result;if(action==='draw')result=drawSpecialRangedWeapon(token,weapon);else if(action==='reload')result=reloadSpecialRangedWeapon(token,weapon);else{sendJson(res,400,{ok:false,error:'Неизвестное действие оружия.'});return true;}
      const actionText=action==='draw'?'натягивает': 'перезаряжает',entry=appendTableLog({type:'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text:`${token.name} ${actionText} «${weapon.name}»${result.cost?` за ${result.cost} ОД`:''}.`,sceneId:scene.id,tokenId:token.id});await persistCampaign();await persist();broadcastTableLog(entry);broadcast('battlemap-replaced',body.clientId,{reason:`weapon-${action}`});sendJson(res,200,{ok:true,action,weaponId:specialRangedWeaponKey(weapon),...result,entry});return true;
    }
    if(pathname==='/api/battlemap/weapon-mod-action'&&req.method==='POST'){
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null));
      if(!scene||!token){sendJson(res,404,{ok:false,error:'Токен не найден.'});return true;}if(!canControlToken(token,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете этим токеном.'});return true;}
      const weapon=weaponsForToken(token).find(item=>item.id===body.weaponId||item.slot===body.weaponId||item.name===body.weaponId);if(!weapon){sendJson(res,404,{ok:false,error:'Оружие не найдено.'});return true;}if(weapon.modificationsActive===false){sendJson(res,409,{ok:false,error:`Модификации «${weapon.name}» неактивны: владение ниже итогового порога ${weapon.threshold||0}.`});return true;}
      const action=String(body.action||''),actions=tokenActions(token),key=heavyWeaponKey(weapon);let cost=0,message='';
      try{
        if(action==='rest') {if(!weaponHasMod(weapon,'carbine_rest_rail'))throw Object.assign(new Error('На оружии нет «Упорной планки».'),{statusCode:409});if(state.combat?.active){if(safeNumber(movementRecord(token)?.spent,0)>.001)throw Object.assign(new Error('Нельзя подготовить упор после перемещения в этом ходу.'),{statusCode:409});cost=1;spendTokenOd(token,cost);}actions.weaponModRest={roundAction:true,weaponKey:key};message='подготавливает стрельбу с упора';}
        else if(action==='mount'){if(!weaponHasMod(weapon,'heavy_mount'))throw Object.assign(new Error('На оружии нет «Станка».'),{statusCode:409});if(state.combat?.active){if(safeNumber(movementRecord(token)?.spent,0)>.001)throw Object.assign(new Error('Нельзя установить станок после перемещения в этом ходу.'),{statusCode:409});cost=1;spendTokenOd(token,cost);}actions.weaponModMount={roundAction:false,weaponKey:key};message='устанавливает оружие на станок';}
        else if(action==='overcharge-damage'||action==='overcharge-radius'){if(!weaponHasMod(weapon,'heavy_overcharge'))throw Object.assign(new Error('На оружии нет «Усиленного заряда».'),{statusCode:409});const mode=action.endsWith('radius')?'radius':'damage';if(mode==='radius'&&safeNumber(weapon.radius,0)<=0)throw Object.assign(new Error('У этого профиля нет радиуса поражения для усиления.'),{statusCode:409});actions.weaponModOvercharge={roundAction:true,weaponKey:key,mode};message=`готовит усиленный заряд (${mode==='damage'?'+1 урон':'+5 фт радиуса'})`;}
        else if(action==='cooling-bypass'){weaponModCoolingBypass(token,weapon);message='использует охлаждающий кожух и пропускает требование охлаждения';}
        else throw Object.assign(new Error('Неизвестное действие модификации.'),{statusCode:400});
      }catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}
      const entry=appendTableLog({type:'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text:`${token.name}: ${message} для «${weapon.name}»${cost?` за ${cost} ОД`:''}.`,sceneId:scene.id,tokenId:token.id});await persistCampaign();await persist();broadcastTableLog(entry);broadcast('battlemap-replaced',body.clientId,{reason:'weapon-mod-action'});sendJson(res,200,{ok:true,action,cost,entry});return true;
    }
    if(pathname==='/api/battlemap/heavy-reload'&&req.method==='POST'){
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null));if(!scene||!token){sendJson(res,404,{ok:false,error:'Токен не найден.'});return true;}if(!canControlToken(token,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете токеном.'});return true;}try{assertTokenCanAct(token);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}if(state.combat?.active&&!isMasterAuthorized(req,requestUrl,body)&&!isCurrentCombatToken(scene,token)){sendJson(res,409,{ok:false,error:'Сейчас ход другого участника.'});return true;}
      const weapon=weaponsForToken(token).find(item=>item.id===body.weaponId||item.slot===body.weaponId||item.name===body.weaponId);if(!weapon){sendJson(res,404,{ok:false,error:'Оружие не найдено.'});return true;}const result=reloadHeavyWeapon(token,weapon);const entry=appendTableLog({type:'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text:`${token.name} перезаряжает «${weapon.name}»${result.cost?` за ${result.cost} ОД`:''}.`,sceneId:scene.id,tokenId:token.id});await persistCampaign();await persist();broadcastTableLog(entry);broadcast('battlemap-replaced',body.clientId,{reason:'heavy-reload'});broadcastAudioEffect(scene.id,/гранатом[её]т/i.test(weaponText(weapon))?'heavy.reload.grenadeLauncher':'heavy.reload.machinegun',{tokenId:token.id,x:token.x,y:token.y},body.clientId);sendJson(res,200,{ok:true,weaponId:heavyWeaponKey(weapon),loaded:true,cost:result.cost,entry});return true;
    }
    if(pathname==='/api/battlemap/cover-attack'&&req.method==='POST'){
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,null)),attacker=findToken(scene,cleanId(body.attackerTokenId,null));if(!scene||!attacker){sendJson(res,404,{ok:false,error:'Сцена или атакующий не найдены.'});return true;}if(!canControlToken(attacker,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете атакующим токеном.'});return true;}try{assertTokenCanAct(attacker,{attack:true});}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}if(state.combat?.active&&!isMasterAuthorized(req,requestUrl,body)&&!isCurrentCombatToken(scene,attacker)){sendJson(res,409,{ok:false,error:'Сейчас ход другого участника.'});return true;}const attackerVehicle=attacker.boardedVehicleId?findToken(scene,attacker.boardedVehicleId):null,attackerSeat=attackerVehicle?.kind==='vehicle'?vehicleSeatRole(attackerVehicle,attacker.id):null;if(attackerSeat==='driver'||attackerSeat==='gunner'){sendJson(res,409,{ok:false,error:attackerSeat==='driver'?'Водитель занят управлением транспортом и не может стрелять личным оружием.':'Стрелок использует встроенное оружие транспорта; личное оружие с этого места недоступно.'});return true;}if(tokenEngagedInMelee(scene,attacker)){sendJson(res,409,{ok:false,error:'Нельзя стрелять по укрытию, пока персонаж связан ближним боем.'});return true;}
      const weapon=weaponsForToken(attacker).find(item=>item.id===body.weaponId||item.slot===body.weaponId||item.name===body.weaponId);if(!weapon||(!weaponIsRanged(weapon)&&safeNumber(weapon.radius,0)<=0)){sendJson(res,400,{ok:false,error:'Нужно выбрать дальнобойное оружие.'});return true;}assertHeavyWeaponReady(attacker,weapon);assertSpecialRangedReady(attacker,weapon);
      const kind=body.coverKind==='wall'?'wall':'cover',obj=kind==='wall'?(scene.walls||[]).find(item=>item.id===cleanId(body.coverId,null)):(scene.covers||[]).find(item=>item.id===cleanId(body.coverId,null));if(!obj){sendJson(res,404,{ok:false,error:'Укрытие не найдено.'});return true;}const durability=Math.max(0,safeNumber(kind==='wall'?obj.coverDurability:obj.durability,0));if(!durability){sendJson(res,409,{ok:false,error:'У этого объекта не задана Прочность.'});return true;}const point=coverAimPoint(kind,obj),distance=distanceFeet(scene,attacker,point);if(distance>safeNumber(weapon.range,5)+.01){sendJson(res,409,{ok:false,error:'Укрытие находится вне дальности оружия.'});return true;}
      const featureAttack=consumeFeatureEffect(attacker,'nextAttack'),featureCoverDamage=consumeFeatureEffect(attacker,'nextCoverDamage'),featureAttackRoll=featureEffectRoll(featureAttack),sides=dieSides(weapon.hitDieNormal,6),moved=Boolean(body.moved),rollMode=mergeRollCondition(featureAttack?.condition==='advantage',moved&&weaponIsHeavy(weapon)||featureAttack?.condition==='hindrance','normal'),rolls=rollMode===0?[rollOne(sides)]:[rollOne(sides),rollOne(sides)],roll=rollMode>0?Math.max(...rolls):rollMode<0?Math.min(...rolls):rolls[0],baseHitBonus=Math.round(safeNumber(weapon.hitBonus,0)+safeNumber(featureAttack?.flat,0)),hitBonus=baseHitBonus+featureAttackRoll,total=roll+hitBonus,mz=Math.max(0,Math.round(safeNumber(kind==='wall'?obj.coverMz:obj.mz,0))),coverDamage=Math.max(0,safeNumber(weapon.damage,0)+safeNumber(featureCoverDamage?.flat,0));
      let attack={id:makeId('coverattack'),at:nowIso(),actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),kind:'cover-attack',visibility:body.visibility==='master'?'master':'public',sceneId:scene.id,attackerTokenId:attacker.id,attackerName:attacker.name,targetTokenId:null,targetName:kind==='wall'?(obj.coverName||'Укрытие-стена'):(obj.name||'Укрытие'),weapon,hitDie:weapon.hitDieNormal,attackRolls:[...rolls],reactionRollMode:rollMode,rolls:[...rolls,...(featureAttackRoll?[featureAttackRoll]:[])],roll,baseHitBonus,hitBonus,total,targetMz:mz,hit:total>=mz,damage:coverDamage,odCost:specialRangedAttackOdCost(attacker,weapon),obCost:weapon.obCost,featureEffects:{attack:featureAttack,attackRoll:featureAttackRoll,coverDamage:featureCoverDamage},formula:attackFormulaText(weapon.hitDieNormal,rollMode,featureAttack?.extraDie,baseHitBonus,`МЗ ${mz}`),label:`${attacker.name}: ${weapon.name} → ${kind==='wall'?(obj.coverName||'укрытие'):(obj.name||'укрытие')}`};
      let attackRoll=combatRollRecord(scene,attacker,attack,'Атака укрытия');attackRoll=await awaitAttackRollResolution(scene,attackRoll);attack=attackRoll.battlemapAttack;
      await spendAttackResources(attacker,attack,{...body,spendResources:body.spendResources!==false},isMasterAuthorized(req,requestUrl,body));markHeavyWeaponFired(attacker,weapon);markSpecialRangedFired(attacker,weapon);
      const coverResult=attack.hit?damageCoverObject(kind,obj,coverDamage,{heavy:weaponIsHeavy(weapon)}):null;broadcastProjectileEffect(scene.id,{id:attack.id,kind:projectileKindForWeapon(weapon),from:speciesCombatPoint(attacker),to:point,durationMs:projectileDurationMs(scene,speciesCombatPoint(attacker),point,weapon),hit:attack.hit,label:weapon.name},body.clientId);const entry=appendTableLog({type:'roll',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text:`${attack.label}: ${attackTotalBreakdown(attack,false)} против МЗ ${mz} — ${attack.hit?'попадание':'промах'}${coverResult?`; урон укрытию ${coverResult.damage}, накоплено ${coverResult.totalDamage}/${coverResult.durability}${coverResult.destroyed?' — РАЗРУШЕНО':''}`:''}.`,sceneId:scene.id,tokenId:attacker.id,meta:{formula:attack.formula,rollId:attackRoll.id}});await persistCampaign();await persist();broadcastTableLog(entry);broadcast('battlemap-replaced',body.clientId,{reason:'cover-damaged'});broadcastAudioEffect(scene.id,weaponSoundKey(weapon),{tokenId:attacker.id,x:attacker.x,y:attacker.y},body.clientId);sendJson(res,201,{ok:true,attack,roll:attackRoll,coverResult,entry});return true;
    }

    if (pathname === '/api/battlemap/items' && req.method === 'GET') {
      const scene=findScene(cleanId(requestUrl.searchParams.get('sceneId'),null)),token=findToken(scene,cleanId(requestUrl.searchParams.get('tokenId'),null)),body={clientId:requestUrl.searchParams.get('clientId')};
      if(!scene||!token){sendJson(res,404,{ok:false,error:'Токен не найден.'});return true;}if(!canControlToken(token,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете этим токеном.'});return true;}if(!['character','npc'].includes(token.kind)){sendJson(res,200,{ok:true,items:[]});return true;}
      const holder=inventoryForToken(token),throwRange=grenadeThrowRange(token),equipment=actionHost(token)?.equipment||{},items=holder.items.map(raw=>{const catalog=weaponCatalog.get(String(raw?.name||''))||{},item={...catalog,...raw,desc:raw?.desc||raw?.description||catalog.desc||''},type=String(item.type||'');if(type!=='Граната'&&!GRENADE_PROFILES[item.name]&&!/Перевязочный комплект|Аптечка|Антидот|Турбина|Энергетический напиток|Энергетический стимулятор|Медицинский набор|Хирургический набор|ПАСИ|Дымовая шашка|Противогаз/i.test(String(item.name||'')))return null;const grenade=Boolean(type==='Граната'||GRENADE_PROFILES[item.name]||/Дымовая шашка/i.test(item.name)),id=String(item.uid||item.id||item.name),gasMask=/Противогаз/i.test(String(item.name||''));return{id,name:item.name,type,qty:itemQuantity(raw),usesRemaining:Number.isFinite(Number(raw.usesRemaining))?Number(raw.usesRemaining):null,desc:item.desc||'',grenade,gasMask,equipped:gasMask&&String(equipment.gasMask||'')===id,profile:grenade?grenadeProfile(item):null,throwRange:grenade?throwRange:null};}).filter(Boolean);
      sendJson(res,200,{ok:true,items});return true;
    }

    if (pathname === '/api/battlemap/medical-action' && req.method === 'POST') {
      const body=await readJsonBody(req),key=requestKey(body,'medical-action');const cached=cachedRequest(key);if(cached){sendJson(res,200,cached);return true;}
      const scene=findScene(cleanId(body.sceneId,null)),source=findToken(scene,cleanId(body.tokenId,null)),target=findToken(scene,cleanId(body.targetTokenId,null)),action=cleanId(body.action,null);
      if(!scene||!source||!target){sendJson(res,404,{ok:false,error:'Токен или цель не найдены.'});return true;}
      if(action!=='stabilize'){sendJson(res,400,{ok:false,error:'Неизвестное медицинское действие.'});return true;}
      if(source.id===target.id||(source.kind===target.kind&&source.refId&&source.refId===target.refId)){sendJson(res,409,{ok:false,error:'Стабилизацию должен проводить другой персонаж.'});return true;}
      if(!['character','npc'].includes(source.kind)||!['character','npc'].includes(target.kind)){sendJson(res,400,{ok:false,error:'Стабилизация доступна только персонажам и NPC.'});return true;}
      if(!canControlToken(source,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете этим токеном.'});return true;}
      try{assertTokenCanAct(source);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}
      if(state.combat?.active&&!isCurrentCombatToken(scene,source)){sendJson(res,409,{ok:false,error:'Сейчас ход другого участника.'});return true;}
      if(contactDistanceFeet(scene,source,target)>Math.max(5,meleeReachFeet(scene,source,target))+0.01){sendJson(res,409,{ok:false,error:'Для Стабилизации нужно находиться на соседней клетке от цели.'});return true;}if(contactBlockedByWall(scene,speciesCombatPoint(source),speciesCombatPoint(target))){sendJson(res,409,{ok:false,error:'Стабилизация невозможна через стену или закрытую дверь.'});return true;}
      const targetInfo=criticalState(target),sourceKey=stabilizerIdentity(source);
      if(!targetInfo.critical||targetInfo.dead){sendJson(res,409,{ok:false,error:'Цель не находится в Критическом ранении или уже погибла.'});return true;}
      if(failedStabilizerIdsFor(target).includes(sourceKey)){sendJson(res,409,{ok:false,error:'Этот персонаж уже провалил попытку Стабилизации данного Критического ранения.'});return true;}
      const sourceHost=tokenMedicalHost(source),targetHost=tokenMedicalHost(target),sourceBefore=clone(sourceHost.entity),targetBefore=clone(targetHost.entity),tokenBefore={defeated:target.defeated};
      try{
        const odCost=state.combat?.active?2:0;if(odCost)spendTokenOd(source,odCost);
        const result=await performStabilization(scene,source,target,body);
        const check=result.check,checkText=`${check.successTotal} против ${check.difficultyTotal??check.difficultyRoll}`;
        const outcomeText=result.outcome==='critical-failure'?'критический провал':result.success?'успех':'провал';
        const entry=appendTableLog({type:'roll',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text:`${source.name} пытается стабилизировать ${target.name}: Медицина ${checkText} — ${outcomeText}. ${result.resultText}`,visibility:'public',sceneId:scene.id,tokenId:source.id,meta:{rollId:result.roll?.id,formula:result.roll?.formula}});
        await persistCampaign();await persist();broadcastTableLog(entry);broadcastAudioEffect(scene.id,'item.use',{tokenId:source.id,x:source.x,y:source.y,targetTokenId:target.id},body.clientId);
        if(source.kind==='npc'||target.kind==='npc')broadcastCampaignReplaced(body.clientId,'npc-stabilization');
        const payload={ok:true,action:'stabilize',odCost,...result,entry};storeRequest(key,payload);sendJson(res,200,payload);return true;
      }catch(error){restoreEntity(sourceHost.entity,sourceBefore);restoreEntity(targetHost.entity,targetBefore);target.defeated=tokenBefore.defeated;throw error;}
    }

    if (pathname === '/api/battlemap/use-item' && req.method === 'POST') {
      const body=await readJsonBody(req),key=requestKey(body,'item');const cached=cachedRequest(key);if(cached){sendJson(res,200,cached);return true;}
      const scene=findScene(cleanId(body.sceneId,null)),source=findToken(scene,cleanId(body.tokenId,null)),target=findToken(scene,cleanId(body.targetTokenId,source?.id));
      if(!scene||!source||!target){sendJson(res,404,{ok:false,error:'Токен или цель не найдены.'});return true;}if(!canControlToken(source,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете этим токеном.'});return true;}try{assertTokenCanAct(source);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}if(!['character','npc'].includes(source.kind)){sendJson(res,400,{ok:false,error:'У токена нет инвентаря.'});return true;}
      if(state.combat?.active&&!isCurrentCombatToken(scene,source)){sendJson(res,409,{ok:false,error:'Сейчас ход другого участника.'});return true;}
      if(source.id!==target.id&&contactDistanceFeet(scene,source,target)>Math.max(5,meleeReachFeet(scene,source,target))+0.01){sendJson(res,409,{ok:false,error:'Для применения предмета цель должна находиться на соседней клетке.'});return true;}if(source.id!==target.id&&contactBlockedByWall(scene,speciesCombatPoint(source),speciesCombatPoint(target))){sendJson(res,409,{ok:false,error:'Нельзя применить предмет к цели через стену или закрытую дверь.'});return true;}
      const holder=inventoryItemById(source,body.itemId);if(!holder.item){sendJson(res,404,{ok:false,error:'Предмет не найден в инвентаре.'});return true;}
      const name=String(holder.item.name||''),desc=String(holder.item.desc||''),sourceHost=tokenMedicalHost(source),targetHost=tokenMedicalHost(target);
      if(!sourceHost||!targetHost){sendJson(res,400,{ok:false,error:'Этот расходник можно применить только к персонажу или NPC.'});return true;}
      let odCost=state.combat?.active?1:0,resultText='Предмет использован.';const itemFormulas=[];
      const isGasMask=/Противогаз/i.test(name),gasMaskKey=String(holder.raw?.uid||holder.raw?.id||holder.item?.uid||holder.item?.id||name),gasMaskEquipped=String(sourceHost.state?.equipment?.gasMask||'')===gasMaskKey;
      if(isGasMask){if(source.id!==target.id){sendJson(res,409,{ok:false,error:'Противогаз можно надеть только на себя.'});return true;}odCost=gasMaskEquipped?0:(state.combat?.active?1:0);}
      if(/Энергетический напиток|Энергетический стимулятор/i.test(name))odCost=0;
      if(/Аптечка/i.test(name)&&state.combat?.active){sendJson(res,409,{ok:false,error:'Аптечка используется только вне боя.'});return true;}
      const sourceBefore=clone(sourceHost.entity),targetBefore=targetHost.entity===sourceHost.entity?sourceBefore:clone(targetHost.entity);
      try {
        if(state.combat?.active&&odCost)spendTokenOd(source,odCost);
        if(isGasMask){sourceHost.state.equipment=sourceHost.state.equipment&&typeof sourceHost.state.equipment==='object'?sourceHost.state.equipment:{};if(gasMaskEquipped){delete sourceHost.state.equipment.gasMask;resultText='Противогаз снят.';}else{sourceHost.state.equipment.gasMask=gasMaskKey;resultText=`Противогаз надет${state.combat?.active?' за 1 ОД':''}. Газовая защита активна.`;}}
        else if(/Перевязочный комплект/i.test(name)){
          if(!['bleeding','light'].includes(body.itemMode))throw Object.assign(new Error('Выберите: остановить Кровотечение или снять Лёгкое ранение.'),{statusCode:400});
          if(body.itemMode==='bleeding'){if(!targetHost.bleeding)throw Object.assign(new Error('У цели нет Кровотечения.'),{statusCode:409});targetHost.bleeding=false;resultText='Кровотечение остановлено.';}else{const healed=healWound(targetHost.state,'light',1);if(!healed)throw Object.assign(new Error('У цели нет Лёгкого ранения.'),{statusCode:409});resultText='Снято 1 Лёгкое ранение.';}
          if(!Number.isFinite(Number(holder.raw.usesRemaining)))holder.raw.usesRemaining=3;holder.raw.usesMax=3;consumeInventoryItem(holder,1,3);
        }else if(/Аптечка/i.test(name)){const healed=healWound(targetHost.state,'medium',1)||healWound(targetHost.state,'light',1);if(!healed)throw Object.assign(new Error('Нет подходящих ранений.'),{statusCode:409});resultText='Ранение вылечено Аптечкой.';consumeInventoryItem(holder,1);
        }else if(/ПАСИ/i.test(name)){let healed=0;if(body.itemMode==='light')healed=healWound(targetHost.state,'light',2);else healed=healWound(targetHost.state,'medium',1)||healWound(targetHost.state,'light',2);const toxins=removeToxicEffectsFromHost(targetHost);if(!healed&&!toxins)throw Object.assign(new Error('Нет подходящих ранений или токсинов.'),{statusCode:409});resultText=`ПАСИ: снято ранений ${healed}, токсичных эффектов ${toxins}.`;consumeInventoryItem(holder,1);
        }else if(/Антидот/i.test(name)){const removed=removeToxicEffectsFromHost(targetHost);resultText=removed?`Снято токсичных эффектов: ${removed}.`:'Антидот применён.';consumeInventoryItem(holder,1);
        }else if(/Турбина/i.test(name)){const moraleResolved=await resolveScalarRoll(scene,source,{body,label:`${source.name}: Турбина — восстановление морали`,sides:10,kind:'item-morale-restore',purpose:'morale-restore'}),roll=moraleResolved.value;itemFormulas.push(moraleResolved.roll?.formula||'Восстановление морали: 1d10');const morale=targetHost.state.morale||(targetHost.state.morale={current:0,max:10}),before=safeNumber(morale.current,0);morale.current=Math.min(safeNumber(morale.max,before),before+roll);if(body.injuryName)addTemporaryEffectToHost(targetHost,`Турбина: подавлена травма «${cleanText(body.injuryName,120)}»`,'Штрафы выбранной травмы временно не применяются.','до конца сцены');resultText=`Восстановлено морали: ${roll}.`;consumeInventoryItem(holder,1);
        }else if(/Энергетический напиток/i.test(name)){const od=tokenOd(source);if(od)od.host[od.currentKey]=Math.min(od.max,od.current+1);addTemporaryEffectToHost(sourceHost,'Энергетический напиток','+1 к Физической силе.','3 хода');resultText='Восстановлено 1 ОД; +1 к Физической силе на 3 хода.';consumeInventoryItem(holder,1);
        }else if(/Энергетический стимулятор/i.test(name)){const od=tokenOd(source);if(od)od.host[od.currentKey]=Math.min(od.max,od.current+1);addTemporaryEffectToHost(sourceHost,'Энергетический стимулятор','+5 футов к Скорости.','до конца боя');resultText='Восстановлено 1 ОД; +5 футов к Скорости до конца боя.';consumeInventoryItem(holder,1);
        }else if(/Медицинский набор|Хирургический набор/i.test(name)){const injury=cleanText(body.injuryName,120);if(!injury)throw Object.assign(new Error('Выберите травму, которую нужно лечить.'),{statusCode:400});const before=targetHost.injuries.length;targetHost.injuries=targetHost.injuries.filter(item=>item?.name!==injury);if(targetHost.type==='character')targetHost.state.injuries=targetHost.injuries;else targetHost.entity.injuries=targetHost.injuries;if(targetHost.injuries.length===before)throw Object.assign(new Error('У цели нет такой травмы.'),{statusCode:409});resultText=`Травма «${injury}» вылечена.`;
        }else{addTemporaryEffectToHost(targetHost,name,desc||'Расходник применён.','по описанию');resultText=`${name}: применён.`;consumeInventoryItem(holder,1);}
        for(const host of new Set([sourceHost,targetHost])){if(host.type==='character'){host.entity.revision=Math.max(0,Number(host.entity.revision||0))+1;host.entity.updatedAt=nowIso();host.entity.updatedBy=cleanId(body.clientId,null);if(broadcastCharacterUpdated)broadcastCharacterUpdated(host.entity,body.clientId);}else host.entity.updatedAt=nowIso();}
        const entry=appendTableLog({type:itemFormulas.length?'roll':'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text:`${source.name} использует «${name}»${target.id!==source.id?` на ${target.name}`:''}: ${resultText}`,sceneId:scene.id,tokenId:source.id,meta:{formulas:itemFormulas}});
        await persistCampaign();await persist();broadcastTableLog(entry);broadcastAudioEffect(scene.id,'item.use',{tokenId:source.id,x:source.x,y:source.y,targetTokenId:target.id},body.clientId);if(sourceHost.type==='npc'||targetHost.type==='npc')broadcastCampaignReplaced(body.clientId,'npc-item-used');const payload={ok:true,itemName:name,resultText,entry,source:sourceHost.entity,target:targetHost.entity};storeRequest(key,payload);sendJson(res,200,payload);return true;
      } catch(error) { restoreEntity(sourceHost.entity,sourceBefore);if(targetHost.entity!==sourceHost.entity)restoreEntity(targetHost.entity,targetBefore);throw error; }
    }

    if (pathname === '/api/battlemap/grenade-preview' && req.method === 'POST') {
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null));
      if(!scene||!token){sendJson(res,404,{ok:false,error:'Токен не найден.'});return true;}if(!canControlToken(token,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете этим токеном.'});return true;}
      const holder=inventoryItemById(token,body.itemId);if(!holder.item){sendJson(res,404,{ok:false,error:'Граната не найдена в инвентаре.'});return true;}
      const maxRange=grenadeThrowRange(token),point={x:safeNumber(body.x,token.x),y:safeNumber(body.y,token.y)},distance=distanceFeet(scene,token,point),origin=speciesCombatPoint(token);
      if(distance>maxRange+.01){sendJson(res,409,{ok:false,error:`Точка дальше максимальной дальности броска ${maxRange} фт.`});return true;}if(contactBlockedByWall(scene,origin,point)){sendJson(res,409,{ok:false,error:'Траектория броска перекрыта стеной или закрытой дверью.'});return true;}
      const difficulty=grenadeThrowDifficulty(scene,token,point,maxRange,Boolean(body.difficult));sendJson(res,200,{ok:true,maxRange,distance:Math.round(distance*10)/10,difficult:difficulty.difficult,reasons:difficulty.reasons,suggestedSkill:bestGrenadeThrowSkill(token)});return true;
    }

    if (pathname === '/api/battlemap/grenade-reaction' && req.method === 'POST') {
      const body=await readJsonBody(req),reactionId=cleanId(body.reactionId,null),pending=pendingGrenadeReactions.get(reactionId);
      if(!pending||pending.expiresAt<Date.now()){if(pending){clearTimeout(pending.timer);pendingGrenadeReactions.delete(reactionId);}sendJson(res,410,{ok:false,error:'Время реакции на гранату истекло.'});return true;}
      const masterAuthorized=isMasterAuthorized(req,requestUrl,body),clientId=cleanId(body.clientId,null);
      const allowed=pending.recipientKind==='master'?masterAuthorized:Boolean(clientId&&clientId===pending.ownerId);
      if(!allowed){sendJson(res,403,{ok:false,error:'Эта реакция принадлежит другому участнику.'});return true;}
      const choice=['fall','dive'].includes(body.choice)?body.choice:'none';clearTimeout(pending.timer);pendingGrenadeReactions.delete(reactionId);pending.resolve(choice);sendJson(res,200,{ok:true,reactionId,choice});return true;
    }
    if (pathname === '/api/battlemap/combat-reaction' && req.method === 'POST') {
      const body=await readJsonBody(req),reactionId=cleanId(body.reactionId,null),pending=pendingCombatReactions.get(reactionId);
      if(!pending||pending.expiresAt<Date.now()){if(pending){clearTimeout(pending.timer);pendingCombatReactions.delete(reactionId);}sendJson(res,410,{ok:false,error:'Время выбора атаки по возможности истекло.'});return true;}
      const masterAuthorized=isMasterAuthorized(req,requestUrl,body),clientId=cleanId(body.clientId,null),allowed=pending.recipientKind==='master'?masterAuthorized:Boolean(clientId&&clientId===pending.ownerId);
      if(!allowed){sendJson(res,403,{ok:false,error:'Эта реакция принадлежит другому участнику.'});return true;}
      const choice=body.choice==='attack'?'attack':'skip';clearTimeout(pending.timer);pendingCombatReactions.delete(reactionId);pending.resolve(choice);sendJson(res,200,{ok:true,reactionId,choice});return true;
    }

    if (pathname === '/api/battlemap/grenade' && req.method === 'POST') {
      const body=await readJsonBody(req),key=requestKey(body,'grenade');const cached=cachedRequest(key);if(cached){sendJson(res,200,cached);return true;}
      const scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null));if(!scene||!token){sendJson(res,404,{ok:false,error:'Токен не найден.'});return true;}if(!canControlToken(token,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете этим токеном.'});return true;}try{assertTokenCanAct(token);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}if(!['character','npc'].includes(token.kind)){sendJson(res,400,{ok:false,error:'Для броска гранаты нужен инвентарь персонажа или NPC.'});return true;}if(state.combat?.active&&!isCurrentCombatToken(scene,token)){sendJson(res,409,{ok:false,error:'Сейчас ход другого участника.'});return true;}
      const holder=inventoryItemById(token,body.itemId);if(!holder.item){sendJson(res,404,{ok:false,error:'Граната не найдена в инвентаре.'});return true;}const profile=grenadeProfile(holder.item),maxRange=grenadeThrowRange(token),point={x:safeNumber(body.x,token.x),y:safeNumber(body.y,token.y)},distance=distanceFeet(scene,token,point),origin=speciesCombatPoint(token);if(distance>maxRange+0.01){sendJson(res,409,{ok:false,error:`Точка дальше максимальной дальности броска ${maxRange} фт.`});return true;}if(contactBlockedByWall(scene,origin,point)){sendJson(res,409,{ok:false,error:'Траектория броска перекрыта стеной или закрытой дверью.'});return true;}
      if(state.combat?.active)spendTokenOd(token,1);
      let finalPoint={...point},check=null,checkRoll=null;const throwDifficulty=grenadeThrowDifficulty(scene,token,point,maxRange,Boolean(body.difficult)),difficult=throwDifficulty.difficult;
      if(difficult){
        const skill=['Физическая сила','Меткость'].includes(body.skillName)?body.skillName:bestGrenadeThrowSkill(token);
        check=runAnyTokenSkillCheck(token,skill,6,0);
        if(check){
          check.difficultyReasons=throwDifficulty.reasons;
          checkRoll=storeSpeciesCheckRoll(scene,token,check,body,`${token.name}: бросок гранаты — ${skill}`,{reactionSafe:true});
          if(checkRoll){checkRoll=await awaitCheckRollResolution(scene,checkRoll);syncCheckFromReactionRoll(check,checkRoll);}
          if(!check.success){const scatterResolved=await resolveScalarRoll(scene,token,{body,label:`${token.name}: отклонение гранаты`,sides:6,kind:'scatter',purpose:'scatter'}),scatter=scatterResolved.value*5,angle=Math.random()*Math.PI*2,px=scatter/Math.max(0.01,scene.grid.feet)*Math.max(1,scene.grid.size),scattered={x:clamp(point.x+Math.cos(angle)*px,0,scene.mapWidth),y:clamp(point.y+Math.sin(angle)*px,0,scene.mapHeight)},impact=projectileWallImpact(scene,origin,scattered);finalPoint=impact?{x:impact.x,y:impact.y}:scattered;check.scatter=scatter;check.wallImpact=Boolean(impact);check.scatterRoll=scatterResolved.roll;}
        }
      }
      consumeInventoryItem(holder,1);
      // Сначала показываем полёт гранаты. Взрыв разрешается только после того,
      // как все видящие её персонажи успели выбрать реакцию (до 25 секунд).
      broadcastProjectileEffect(scene.id,{id:makeId('grenade-flight'),kind:'grenade',from:speciesCombatPoint(token),to:{...finalPoint,elevation:0},durationMs:clamp(650+distance*4,700,1700),hit:true,radius:profile.radius,label:profile.name,effectType:profile.type,explosive:profile.type==='explosive',deferExplosion:true},body.clientId);
      broadcastAudioEffect(scene.id,'grenade.throw',{tokenId:token.id,x:token.x,y:token.y},body.clientId);
      const grenadeReactions=await resolveThrownGrenadeReactions(scene,token,finalPoint,profile,body),affected=[];
      if(profile.damage>0){for(const target of scene.tokens){if(!['character','npc','vehicle'].includes(target.kind))continue;if(profile.hostileOnly&&!tokensHostile(token,target))continue;if(profile.gasHazard&&target.kind==='vehicle')continue;const feet=distanceFeet(scene,target,finalPoint);if(feet>profile.radius+0.01)continue;const zoneDamage=feet<=profile.radius/2?profile.damage:Math.floor(profile.damage/2);const wallBlocked=explosionBlockedByWall(scene,finalPoint,target),coverReduction=profile.gasHazard||wallBlocked?0:explosionCoverReduction(scene,finalPoint,target),reaction=grenadeReactions.get(target.id)||null,reactionReduction=profile.gasHazard?0:(reaction?.choice&&reaction.choice!=='none'?1:0),gasProtection=profile.gasHazard?gasProtectionForToken(target):{protected:false,source:null};const dealt=wallBlocked||gasProtection.protected?0:Math.max(0,zoneDamage-coverReduction-reactionReduction);if(dealt<=0){affected.push({tokenId:target.id,name:target.name,distance:Math.round(feet*10)/10,damage:0,coverReduction,reactionReduction,reaction,gasProtection,wallBlocked,result:null});continue;}const result=target.kind==='vehicle'?await applyDamageToVehicle(scene,target,{...body,damage:dealt,damageTag:profile.damageTag||'heavy'},{persistNow:false}):await applyDamageToTarget(scene,target,{...body,damage:dealt,damageTag:profile.damageTag||'heavy',explosive:!profile.gasHazard,ignoreArmor:Boolean(profile.gasHazard),environmentalHazard:profile.gasHazard?'gas':'',armorPiercing:Boolean(profile.armorPiercing),anaxion:Boolean(profile.anaxion),sourceText:profile.name,bleeding:Boolean(profile.bleeding)},{persist:false,recordHistory:false,role:'player'});affected.push({tokenId:target.id,name:target.name,distance:Math.round(feet*10)/10,damage:dealt,coverReduction,reactionReduction,reaction,gasProtection,wallBlocked:false,result});}}
      const damagedCovers=profile.damage>0&&!profile.gasHazard?blastDamageCovers(scene,finalPoint,profile.radius,profile.damage,{heavy:false}):[];
      let zone=null;if(['smoke','gas','toxin','panic','anaxion'].includes(profile.type)&&profile.rounds){zone=normalizeEffectZone({id:makeId('zone'),name:profile.name,type:profile.type,x:finalPoint.x,y:finalPoint.y,radius:profile.radius,color:profile.type==='smoke'?'#aab4bd':profile.type==='panic'?'#c2a45a':profile.type==='anaxion'?'#9b75d1':'#75b86b',mzBonus:profile.mzBonus||0,visionLimit:profile.visionLimit||0,gasHazard:Boolean(profile.gasHazard),damage:profile.zoneDamage||0,zoneDamage:profile.zoneDamage||0,damageTag:profile.damageTag||'light',remainingRounds:profile.rounds,delayRounds:profile.delayRounds||0,createdRound:getCampaign().initiative?.round||0,ownerTokenId:token.id,sourceName:profile.name,attackHindrance:Boolean(profile.attackHindrance),skipTurn:Boolean(profile.skipTurn),hostileOnly:Boolean(profile.hostileOnly),notes:profile.notes||''},scene.effects.length);scene.effects.push(zone);}
      const visualTtlMs=profile.type==='explosive'?9000:3200;
      const visualZone=normalizeEffectZone({id:makeId('blast'),name:`${profile.name}: область`,type:profile.type==='explosive'?'explosion':profile.type,x:finalPoint.x,y:finalPoint.y,radius:profile.radius,color:profile.type==='explosive'?'#ff9b43':(zone?.color||'#f2d375'),opacity:profile.type==='explosive'?.24:.12,remainingRounds:1,visualOnly:true,expiresAt:null,pulse:true,sourceName:profile.name},scene.effects.length);
      if(holder.character){holder.character.revision=Math.max(0,Number(holder.character.revision||0))+1;holder.character.updatedAt=nowIso();if(broadcastCharacterUpdated)broadcastCharacterUpdated(holder.character,body.clientId);}else if(holder.npc){holder.npc.updatedAt=nowIso();broadcastCampaignReplaced(body.clientId,'npc-grenade-used');}const text=`${token.name} бросает «${profile.name}»${check?check.success?' — проверка успешна':` — промах, отклонение ${check.scatter} фт`:''}. ${affected.length?`Затронуто целей: ${affected.length}.`:zone?'Создана область эффекта.':''}`;const grenadeFormulas=[];if(check){if(checkRoll?.formula)grenadeFormulas.push(checkRoll.formula);else grenadeFormulas.push(`${check.successDie||'1d6'}${signedFormulaBonus(check.bonus)} vs ${check.difficultyDie||'1d6'}`);if(!check.success)grenadeFormulas.push('Отклонение: 1d6 × 5 фт');}for(const item of affected)grenadeFormulas.push(...journalRollFormulas(null,item.result));const entry=appendTableLog({type:grenadeFormulas.length?'roll':'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text,sceneId:scene.id,tokenId:token.id,meta:{formulas:grenadeFormulas}});await persistCampaign();await persist();broadcastTableLog(entry);broadcast('battlemap-replaced',body.clientId,{reason:'grenade',sceneId:scene.id});broadcastProjectileEffect(scene.id,{id:makeId('grenade-impact'),kind:'grenade',from:finalPoint,to:finalPoint,durationMs:120,hit:true,radius:profile.radius,label:profile.name,effectType:profile.type,explosive:profile.type==='explosive',explodeOnly:true},body.clientId);broadcastTransientEffect(scene.id,visualZone,visualTtlMs,body.clientId);if(profile.type==='explosive')broadcastAudioEffect(scene.id,'grenade.explosion',{x:finalPoint.x,y:finalPoint.y,tokenId:token.id},body.clientId);if(['smoke','gas','tear-gas','toxin'].includes(profile.type))broadcastAudioEffect(scene.id,'grenade.smokeGas',{x:finalPoint.x,y:finalPoint.y,tokenId:token.id},body.clientId);const payload={ok:true,profile,point:finalPoint,check,checkRoll,affected,reactions:Object.fromEntries(grenadeReactions),damagedCovers,zone,visualZone,visualTtlMs,entry};storeRequest(key,payload);sendJson(res,201,payload);return true;
    }

    if (pathname === '/api/battlemap/area-attack' && req.method === 'POST') {
      const body=await readJsonBody(req);const key=requestKey(body,'area-attack');const cached=cachedRequest(key);if(cached){sendJson(res,200,cached);return true;}
      const scene=findScene(cleanId(body.sceneId,null)),attacker=findToken(scene,cleanId(body.attackerTokenId,null));if(!scene||!attacker){sendJson(res,404,{ok:false,error:'Атакующий или сцена не найдены.'});return true;}
      if(!canControlToken(attacker,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете атакующим токеном.'});return true;}try{assertTokenCanAct(attacker,{attack:true});}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}
      const weapon=weaponsForToken(attacker).find(item=>item.id===body.weaponId||item.slot===body.weaponId||item.name===body.weaponId);if(!weapon||weapon.radius<=0){sendJson(res,400,{ok:false,error:'Выбранное оружие не имеет радиуса поражения.'});return true;}if(tokenEngagedInMelee(scene,attacker)){sendJson(res,409,{ok:false,error:'Нельзя использовать дальнобойное оружие по области, пока атакующий связан ближним боем.'});return true;}assertHeavyWeaponReady(attacker,weapon);
      const specialMode=body.specialMode==='anaxion'?'anaxion':null;if(specialMode==='anaxion'&&!weaponSupportsAnaxion(weapon)){sendJson(res,409,{ok:false,error:'Этот профиль не может использовать Анаксионный режим.'});return true;}
      if(state.combat?.active&&!isMasterAuthorized(req,requestUrl,body)&&!isCurrentCombatToken(scene,attacker)){sendJson(res,409,{ok:false,error:'Сейчас ход другого участника.'});return true;}
      let point={x:clamp(safeNumber(body.x,attacker.x),0,scene.mapWidth),y:clamp(safeNumber(body.y,attacker.y),0,scene.mapHeight)},aimPoint={...point},origin=speciesCombatPoint(attacker);const distance=distanceFeet(scene,attacker,point);if(distance>weapon.range+.01){sendJson(res,409,{ok:false,error:`Точка вне дальности: ${distance.toFixed(1)} фт при максимуме ${weapon.range} фт.`});return true;}if(contactBlockedByWall(scene,origin,point)){sendJson(res,409,{ok:false,error:'Траектория гранатомёта перекрыта стеной или закрытой дверью.'});return true;}
      const movedThisTurn=body.moved===true||Boolean(state.combat?.active&&state.combat.sceneId===scene.id&&safeNumber(state.combat?.movement?.[attacker.id]?.spent,0)>.001),badVisibility=Boolean(scene.settings?.badVisibility||body.badVisibility===true),modEffects=weaponModAttackEffects(weapon,{distance,shotMode:'normal',moved:movedThisTurn,badVisibility,smoke:Boolean(counterSniperSmokeBlock(scene,origin,point)),attacker,specialMode}),stabilityPenalty=weaponModInstabilityPenalty(weapon);
      const featureAttack=consumeFeatureEffect(attacker,'nextAttack'),featureAttackRoll=featureEffectRoll(featureAttack),sides=dieSides(weapon.hitDieNormal,6),hindrance=(movedThisTurn&&weaponIsHeavy(weapon))||badVisibility,rollMode=mergeRollCondition(featureAttack?.condition==='advantage',hindrance||featureAttack?.condition==='hindrance','normal'),initialRolls=rollMode===0?[rollOne(sides)]:[rollOne(sides),rollOne(sides)],initialRoll=rollMode<0?Math.min(...initialRolls):rollMode>0?Math.max(...initialRolls):initialRolls[0],baseHitBonus=Math.round(safeNumber(weapon.hitBonus,0)+safeNumber(featureAttack?.flat,0)+safeNumber(modEffects.hitBonus,0)+stabilityPenalty),hitBonus=baseHitBonus+featureAttackRoll,targetNumber=3,effectiveRadius=Math.max(0,safeNumber(weapon.radius,0)+(tokenActions(attacker)?.weaponModOvercharge?.weaponKey===heavyWeaponKey(weapon)&&tokenActions(attacker)?.weaponModOvercharge?.mode==='radius'?5:0));
      const areaFlags=attackFlagsFromWeapon(weapon);if(specialMode==='anaxion')areaFlags.anaxion=true;
      let attack={id:makeId('areaattack'),at:nowIso(),actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),kind:'area-attack',visibility:body.visibility==='master'?'master':'public',sceneId:scene.id,attackerTokenId:attacker.id,attackerName:attacker.name,targetTokenId:null,targetName:'точка области',weapon,hitDie:weapon.hitDieNormal,attackRolls:[...initialRolls],reactionRollMode:rollMode,rolls:[...initialRolls,...(featureAttackRoll?[featureAttackRoll]:[])],roll:initialRoll,baseHitBonus,hitBonus,total:initialRoll+hitBonus,targetMz:targetNumber,hit:initialRoll+hitBonus>=targetNumber,damage:Math.max(0,safeNumber(weapon.damage,0)+safeNumber(modEffects.damageBonus,0)+(specialMode==='anaxion'?1:0)),damageTag:weapon.damageTag||'heavy',specialMode,flags:areaFlags,featureEffects:{attack:featureAttack,attackRoll:featureAttackRoll},weaponModEffects:{...modEffects,overchargeRadiusBonus:Math.max(0,effectiveRadius-safeNumber(weapon.radius,0))},effectiveRadius,conditionalReasons:[...modEffects.reasons,...(stabilityPenalty?[`${stabilityPenalty}: перегрев / нестабильность / отдача профиля`]:[])],formula:attackFormulaText(weapon.hitDieNormal,rollMode,featureAttack?.extraDie,baseHitBonus,'3'),label:`${attacker.name}: ${weapon.name}${specialMode==='anaxion'?' (Анаксионный режим)':''} по области`};
      let areaRoll=combatRollRecord(scene,attacker,attack,'Атака по области');areaRoll=await awaitAttackRollResolution(scene,areaRoll);attack=areaRoll.battlemapAttack;
      const hit=Boolean(attack.hit),roll=attack.roll,total=attack.total,finalRolls=attack.attackRolls||initialRolls,finalAreaShift=attack.areaShift||null;
      let scatter=0,wallImpact=null,areaShiftApplied=0;if(!hit){const scatterResolved=await resolveScalarRoll(scene,attacker,{body,label:`${attacker.name}: отклонение выстрела по области`,sides:6,kind:'scatter',purpose:'scatter'});scatter=scatterResolved.value*5;const angle=Math.random()*Math.PI*2,px=feetToScenePixels(scene,scatter),scattered={x:clamp(point.x+Math.cos(angle)*px,0,scene.mapWidth),y:clamp(point.y+Math.sin(angle)*px,0,scene.mapHeight)};let corrected=scattered;if(finalAreaShift?.feet){const maxShift=Math.max(0,safeNumber(finalAreaShift.feet,0)),backDistance=distanceFeet(scene,scattered,aimPoint),shift=Math.min(maxShift,backDistance);if(shift>0){const dx=aimPoint.x-scattered.x,dy=aimPoint.y-scattered.y,len=Math.max(.001,Math.hypot(dx,dy)),shiftPx=feetToScenePixels(scene,shift);corrected={x:clamp(scattered.x+dx/len*shiftPx,0,scene.mapWidth),y:clamp(scattered.y+dy/len*shiftPx,0,scene.mapHeight)};areaShiftApplied=shift;scatter=Math.max(0,scatter-shift);}}wallImpact=projectileWallImpact(scene,origin,corrected);point=wallImpact?{x:wallImpact.x,y:wallImpact.y}:corrected;}
      const cost={id:makeId('area-cost'),sceneId:scene.id,odCost:weapon.odCost,obCost:Math.max(0,weapon.obCost||0)+(specialMode==='anaxion'?1:0),weapon};await spendAttackResources(attacker,cost,{...body,spendResources:body.spendResources!==false},isMasterAuthorized(req,requestUrl,body));finalizeWeaponModAttack(attacker,weapon,attack);markHeavyWeaponFired(attacker,weapon);const unsafeHeavyShot=weaponIsExplosiveHeavy(weapon)&&distance<20,blastRadius=Math.max(0,safeNumber(attack.effectiveRadius,effectiveRadius));
      const affected=[];for(const target of scene.tokens){if(!['character','npc','vehicle'].includes(target.kind))continue;const feet=distanceFeet(scene,target,point),forcedOuter=unsafeHeavyShot&&target.id===attacker.id;if(feet>blastRadius+.01&&!forcedOuter)continue;const zoneDamage=forcedOuter?Math.floor(attack.damage/2):(feet<=blastRadius/2?attack.damage:Math.floor(attack.damage/2)),wallBlocked=!forcedOuter&&explosionBlockedByWall(scene,point,target),coverReduction=forcedOuter||wallBlocked?0:explosionCoverReduction(scene,point,target),baseDealt=wallBlocked?0:Math.max(0,zoneDamage-coverReduction),dealt=target.kind==='vehicle'&&weaponIsHeavy(weapon)?baseDealt*2:baseDealt;let result=null;if(dealt>0)result=target.kind==='vehicle'?await applyDamageToVehicle(scene,target,{...body,damage:dealt,damageTag:attack.damageTag,...attack.flags},{persistNow:false}):await applyDamageToTarget(scene,target,{...body,damage:dealt,damageTag:attack.damageTag,...attack.flags,explosive:true,sourceText:weapon.name,bleeding:false},{persist:false,recordHistory:false,role:isMasterAuthorized(req,requestUrl,body)?'master':'player'});let extraMorale=0;if(/анаксионный излучатель/i.test(weaponText(weapon))&&!wallBlocked){const moraleRoll=await resolveScalarRoll(scene,target,{body,label:`${target.name}: дополнительная потеря морали от анаксионного излучателя`,sides:6,kind:'anaxion-morale',purpose:'morale-loss'});extraMorale=-(await adjustTokenMoraleResolved(scene,target,-moraleRoll.total,body));}affected.push({tokenId:target.id,name:target.name,distance:Math.round(feet*10)/10,damage:dealt,coverReduction,wallBlocked,result,extraMorale,unsafeOuterZone:forcedOuter});}const damagedCovers=blastDamageCovers(scene,point,blastRadius,attack.damage,{heavy:weaponIsHeavy(weapon)});
      const visualZone=normalizeEffectZone({id:makeId('blast'),name:`${weapon.name}: область`,type:'explosion',x:point.x,y:point.y,radius:blastRadius,color:'#ff9b43',opacity:.24,remainingRounds:1,visualOnly:true,pulse:true,sourceName:weapon.name},scene.effects.length);
      const areaFormula=attack.formula,areaFormulas=[areaFormula,...(!hit?['Отклонение: 1d6 × 5 фт']:[]),...affected.flatMap(item=>journalRollFormulas(null,item.result)),...(/анаксионный излучатель/i.test(weaponText(weapon))&&affected.length?[`Доп. потеря морали: ${affected.length}×1d6 (по одному на цель)`]:[])];
      const entry=appendTableLog({type:'roll',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text:`${attacker.name}: ${weapon.name} по области — бросок ${featureAttackRoll?`${roll} + 1к${featureAttack?.extraDie}=${featureAttackRoll}${safeNumber(weapon.hitBonus,0)+safeNumber(featureAttack?.flat,0)?` + ${Math.round(safeNumber(weapon.hitBonus,0)+safeNumber(featureAttack?.flat,0))}`:''} = ${total}`:total} против 3; ${hit?'точное попадание':`отклонение ${scatter} фт${areaShiftApplied?` после коррекции «${finalAreaShift?.sourceName||'Гранатомётчик'}» на ${areaShiftApplied} фт`:''}`}; затронуто целей: ${affected.length}${damagedCovers.length?`, повреждено укрытий: ${damagedCovers.length}`:''}${unsafeHeavyShot?' Стрелок попал во внешнюю зону взрыва.':''}.`,sceneId:scene.id,tokenId:attacker.id,meta:{formulas:areaFormulas}});await persistCampaign();await persist();broadcastTableLog(entry);broadcastProjectileEffect(scene.id,{id:`launcher-${entry.id}`,kind:'launcher',from:speciesCombatPoint(attacker),to:{...point,elevation:0},durationMs:clamp(650+distanceFeet(scene,attacker,point)*2.5,700,1600),hit:true,radius:blastRadius,label:weapon.name},body.clientId);broadcastTransientEffect(scene.id,visualZone,9000,body.clientId);broadcastAudioEffect(scene.id,weaponSoundKey(weapon),{tokenId:attacker.id,x:attacker.x,y:attacker.y},body.clientId);broadcastAudioEffect(scene.id,'grenade.explosion',{tokenId:attacker.id,x:point.x,y:point.y},body.clientId);const payload={ok:true,attack,specialMode,hit,rolls:[...finalRolls,...(featureAttackRoll?[featureAttackRoll]:[])],roll,hitBonus:attack.hitBonus,total,targetNumber,scatter,wallImpact:Boolean(wallImpact),featureAttack,featureAreaShift:finalAreaShift,areaShiftApplied,point,weapon,affected,damagedCovers,unsafeHeavyShot,visualZone,visualTtlMs:9000,rollRecord:areaRoll,entry};storeRequest(key,payload);sendJson(res,201,payload);return true;
    }
    if (pathname === '/api/battlemap/weapon-zone' && req.method === 'POST') {
      const body=await readJsonBody(req);const key=requestKey(body,'weapon-zone');const cached=cachedRequest(key);if(cached){sendJson(res,200,cached);return true;}
      const scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null));if(!scene||!token){sendJson(res,404,{ok:false,error:'Токен или сцена не найдены.'});return true;}
      if(!canControlToken(token,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете токеном.'});return true;}try{assertTokenCanAct(token,{attack:true});}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}
      const weapon=weaponsForToken(token).find(item=>item.id===body.weaponId||item.slot===body.weaponId||item.name===body.weaponId);if(!weapon){sendJson(res,400,{ok:false,error:'Оружие не найдено.'});return true;}assertHeavyWeaponReady(token,weapon);if(tokenEngagedInMelee(scene,token)){sendJson(res,409,{ok:false,error:'Нельзя использовать режимы дальнобойного оружия, пока токен связан ближним боем.'});return true;}
      const modeName=String(body.mode||''),point={x:clamp(safeNumber(body.x,token.x),0,scene.mapWidth),y:clamp(safeNumber(body.y,token.y),0,scene.mapHeight)};
      if(distanceFeet(scene,token,point)>weapon.range+.01){sendJson(res,409,{ok:false,error:'Точка вне дальности оружия.'});return true;}
      if(modeName==='suppression'&&!weaponSupportsSuppression(weapon)){sendJson(res,409,{ok:false,error:'Этот профиль не может использовать Подавление.'});return true;}
      if(modeName==='barrage'&&!weaponSupportsBarrage(weapon)){sendJson(res,409,{ok:false,error:'Этот профиль не может использовать Шквальный огонь.'});return true;}
      const origin=speciesCombatPoint(token);
      if(contactBlockedByWall(scene,origin,point)){sendJson(res,409,{ok:false,error:'Линия огня перекрыта стеной или закрытой дверью.'});return true;}
      let barrageCover={mz:0,source:null,ignored:[]},peeking=false;
      if(modeName==='barrage'){
        peeking=Boolean(tokenActions(token)?.peek)&&tokenAdjacentToCover(scene,token);
        barrageCover=automaticCoverInfo(scene,origin,point,{ignoreNearOrigin:peeking,originToken:token,includeTargetInsideCover:true});
        if(barrageCover.mz>0){sendJson(res,409,{ok:false,error:`Шквальный огонь нельзя создать за укрытием «${barrageCover.source?.name||'Укрытие'}». Используйте «Выглянуть» у ближайшего укрытия или займите зону «Очень высоко».`});return true;}
      }
      const cost={id:makeId('zone-cost'),sceneId:scene.id,odCost:weapon.odCost,obCost:1,weapon};await spendAttackResources(token,cost,{...body,spendResources:true},isMasterAuthorized(req,requestUrl,body));markHeavyWeaponFired(token,weapon);
      const zoneProfile=canonicalCombatWeaponProfile(weapon);
      // compatibility marker for v1.7.6 regression: hitPenalty:modeName==='suppression'&&zoneProfile==='Автоматический карабин'?-1:0
      const effect=normalizeEffectZone({id:makeId(modeName),name:modeName==='barrage'?'Шквальный огонь':'Подавление',type:modeName==='barrage'?'barrage':'suppression',x:point.x,y:point.y,radius:modeName==='barrage'?(zoneProfile==='Тяжёлый пулемёт'?10.6:7.1):7.5,color:modeName==='barrage'?'#df6955':'#d7b45a',zoneDamage:modeName==='barrage'?(zoneProfile==='Тяжёлый пулемёт'?2:1):0,hitPenalty:modeName==='suppression'?((zoneProfile==='Автоматический карабин'?-1:0)+(weaponHasMod(weapon,'carbine_suppression_kit')?-1:0)):0,damageTag:weapon.damageTag||'medium',remainingRounds:1,durationMode:'owner-turn',createdRound:getCampaign().initiative?.round||0,ownerTokenId:token.id,sourceName:weapon.name,notes:modeName==='barrage'?'Урон при входе, пересечении или начале хода.':'Помеха на дальнобойные атаки из этой позиции.'},scene.effects.length);
      scene.effects.push(effect);const entry=appendTableLog({type:'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text:`${token.name}: ${effect.name} (${weapon.name}).`,sceneId:scene.id,tokenId:token.id});await persistCampaign();await persist();broadcastTableLog(entry);broadcast('battlemap-replaced',body.clientId,{reason:'weapon-zone'});broadcastAudioEffect(scene.id,modeName==='barrage'?'zone.barrage':'zone.suppression',{tokenId:token.id,x:token.x,y:token.y,targetX:point.x,targetY:point.y},body.clientId);const payload={ok:true,effect,entry};storeRequest(key,payload);sendJson(res,201,payload);return true;
    }

    if(pathname==='/api/battlemap/interactive/trigger'&&req.method==='POST'){
      const body=await readJsonBody(req);if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Срабатывать интерактивные объекты вручную может только мастер.'});return true;}
      const scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null));if(!scene||!token||token.kind!=='interactive'){sendJson(res,404,{ok:false,error:'Интерактивный объект не найден.'});return true;}
      try{const result=await triggerInteractiveObject(scene,token,body,{sourceToken:null,persistNow:true});sendJson(res,200,result);}catch(error){sendJson(res,error.statusCode||400,{ok:false,error:error.message});}return true;
    }
    if(pathname==='/api/battlemap/interactive/reset'&&req.method==='POST'){
      const body=await readJsonBody(req);if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Сбрасывать интерактивные объекты может только мастер.'});return true;}
      const scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null));if(!scene||!token||token.kind!=='interactive'){sendJson(res,404,{ok:false,error:'Интерактивный объект не найден.'});return true;}
      token.interactive=normalizeInteractiveObject({...token.interactive,active:true,triggered:false},token.name);token.updatedAt=scene.updatedAt=nowIso();await persist();broadcast('battlemap-replaced',body.clientId,{reason:'interactive-reset',sceneId:scene.id,tokenId:token.id});sendJson(res,200,{ok:true,token});return true;
    }

    if(pathname==='/api/battlemap/features'&&req.method==='GET'){
      const scene=findScene(cleanId(requestUrl.searchParams.get('sceneId'),state.activeSceneId)),token=findToken(scene,cleanId(requestUrl.searchParams.get('tokenId'),null)),body={clientId:requestUrl.searchParams.get('clientId')};
      if(!scene||!token){sendJson(res,404,{ok:false,error:'Токен не найден.'});return true;}
      if(!canControlToken(token,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете этим токеном.'});return true;}
      if(!['character','npc'].includes(token.kind)){sendJson(res,400,{ok:false,error:'Особенности доступны персонажам и NPC.'});return true;}
      const character=token.kind==='character'?linkedCharacter(token):linkedNpc(token),featureHost=actionHost(token),sourceEntries=token.kind==='character'?characterFeatureEntries(character):mainTraitFeatureEntries(character),entries=sourceEntries.map(entry=>({...entry,kindLabel:token.kind==='npc'?'Способность NPC':featureKindLabel(entry.kind),used:featureUsedForHost(featureHost,scene,entry),actions:featureMechanics(entry)}));
      const targets=(scene.tokens||[]).filter(item=>['character','npc'].includes(item.kind)&&!criticalState(item).dead).map(item=>({
        id:item.id,name:item.name,kind:item.kind,self:item.id===token.id,hostile:tokensHostile(token,item),
        distance:Math.round(distanceFeet(scene,speciesCombatPoint(token),speciesCombatPoint(item))*10)/10,
        canHear:reactionSourceCanHear(scene,token,item,30),visible:reactionSourceCanSee(scene,token,item)
      }));
      sendJson(res,200,{ok:true,tokenId:token.id,features:entries,targets,pending:clone(featureEffects(token)),bonusStatus:token.kind==='character'?bonusTraitStatus(scene,token,character):null,canResetBonusScene:token.kind==='character'&&isMasterAuthorized(req,requestUrl,body),bonusSceneSerial:bonusSceneSerial(scene)});return true;
    }
    if(pathname==='/api/battlemap/bonus-traits/new-scene'&&req.method==='POST'){
      const body=await readJsonBody(req);
      if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Начать новую сцену Бонусных черт может только мастер.'});return true;}
      const scene=findScene(cleanId(body.sceneId,state.activeSceneId));if(!scene){sendJson(res,404,{ok:false,error:'Сцена не найдена.'});return true;}
      scene._bonusTraitSceneSerial=bonusSceneSerial(scene)+1;scene.updatedAt=nowIso();
      for(const item of scene.tokens||[]){
        const effects=featureEffects(item);
        for(const [slot,effect] of Object.entries(effects||{}))if(String(effect?.sourceKey||'').startsWith('bonusTrait:'))delete effects[slot];
      }
      const entry=appendTableLog({type:'system',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Мастер'),text:'Начата новая нарративная сцена: Фортуна, Изученные цели и сценовые применения Бонусных черт обновлены.',sceneId:scene.id});
      await persistCampaign();await persist();broadcastTableLog(entry);broadcast('battlemap-replaced',body.clientId,{reason:'bonus-traits-new-scene',sceneId:scene.id});
      sendJson(res,200,{ok:true,sceneId:scene.id,serial:scene._bonusTraitSceneSerial,entry});return true;
    }
    if(pathname==='/api/battlemap/feature-use'&&req.method==='POST'){
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,state.activeSceneId)),token=findToken(scene,cleanId(body.tokenId,null));
      if(!scene||!token){sendJson(res,404,{ok:false,error:'Токен не найден.'});return true;}
      if(!canControlToken(token,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете этим токеном.'});return true;}
      if(!['character','npc'].includes(token.kind)){sendJson(res,400,{ok:false,error:'У этого токена нет таких особенностей.'});return true;}
      const character=token.kind==='character'?linkedCharacter(token):linkedNpc(token),featureHost=actionHost(token),availableEntries=token.kind==='character'?characterFeatureEntries(character):mainTraitFeatureEntries(character),entry=availableEntries.find(item=>item.key===String(body.featureKey||''));
      if(!entry){sendJson(res,404,{ok:false,error:token.kind==='npc'?'Способность не назначена этому NPC.':'Особенность не найдена в листе персонажа.'});return true;}
      if(featureUsedForHost(featureHost,scene,entry)){sendJson(res,409,{ok:false,error:'Эта особенность уже использована в текущем бою или сцене.'});return true;}
      const action=featureMechanics(entry).find(item=>item.id===String(body.actionId||''));
      if(!action){sendJson(res,400,{ok:false,error:'Для этой особенности выбран неподдерживаемый эффект.'});return true;}
      if(action.reactionOnly){sendJson(res,409,{ok:false,error:'Эта особенность применяется после броска через окно реакций.'});return true;}
      const selectedTarget=findToken(scene,cleanId(body.targetTokenId,token.id))||token,target=action.target==='self'?token:selectedTarget;
      if(!['character','npc'].includes(target.kind)){sendJson(res,400,{ok:false,error:'Выбранная цель не имеет подходящего статблока.'});return true;}
      const inCombat=Boolean(state.combat?.active&&state.combat.sceneId===scene.id),requireOwnCombatTurn=()=>{if(inCombat&&!isCurrentCombatToken(scene,token))throw Object.assign(new Error('Это действие можно выполнить только в свой ход.'),{statusCode:409});};
      const requireAlly=(candidate,{self=false}={})=>{
        if(!candidate||tokensHostile(token,candidate)||(candidate.id===token.id&&!self))throw Object.assign(new Error('Нужно выбрать подходящего союзника.'),{statusCode:409});
        if(distanceFeet(scene,speciesCombatPoint(token),speciesCombatPoint(candidate))>30.01)throw Object.assign(new Error('Союзник должен находиться в пределах 30 футов.'),{statusCode:409});
        if(!reactionSourceCanHear(scene,token,candidate,30))throw Object.assign(new Error('Союзник должен быть способен вас слышать.'),{statusCode:409});
      };
      let result={type:action.slot,targetTokenId:target.id,targetName:target.name},message='',odCost=0,markUse=true,targetCharacter=null;
      try{
        if(action.slot==='main-mark'){
          if(!inCombat)throw Object.assign(new Error('«Метка» используется во время боя.'),{statusCode:409});requireOwnCombatTurn();
          if(target.id===token.id)throw Object.assign(new Error('Нельзя пометить себя.'),{statusCode:409});
          if(!mainTraitTargetVisibleToToken(scene,token,target))throw Object.assign(new Error('Цель Метки должна быть видима и находиться на прямой линии наблюдения.'),{statusCode:409});
          odCost=3;spendTokenOd(token,odCost);const mark=setMainTraitMark(character,scene,target);
          result={...result,mark:{targetTokenId:target.id,targetName:target.name,mzPenalty:2,firstAttackAdvantage:true}};message=`помечает ${target.name}: −2 МЗ против своих атак; первая атака по цели в каждом своём ходу получает преимущество. Урон не увеличивается.`;
        }else if(action.slot==='main-experienced-look'){
          if(!inCombat)throw Object.assign(new Error('«Опытный взгляд» используется во время боя.'),{statusCode:409});requireOwnCombatTurn();
          if(target.id===token.id)throw Object.assign(new Error('Нельзя применять «Опытный взгляд» к себе.'),{statusCode:409});
          if(!mainTraitTargetVisibleToToken(scene,token,target))throw Object.assign(new Error('Цель «Опытного взгляда» должна быть видима.'),{statusCode:409});
          odCost=1;spendTokenOd(token,odCost);const check=token.kind==='npc'?runAnyTokenSkillCheck(token,'Анализ',10,0):runSkillAgainstDifficulty(token,'Анализ',10,{combatContext:true});
          if(!check)throw Object.assign(new Error('Не удалось провести проверку Анализа.'),{statusCode:409});
          let roll=storeSpeciesCheckRoll(scene,token,check,body,`${token.name}: Опытный взгляд — Анализ ${target.name}`,{reactionSafe:true});
          if(roll){roll=await awaitCheckRollResolution(scene,roll);syncCheckFromReactionRoll(check,roll);}
          const morale=moraleHost(target),health=studiedObservableFact(scene,token,target,'wounds'),moraleText=morale?`Мораль: ${Math.max(0,Math.round(safeNumber(morale.current,0)))}/${Math.max(0,Math.round(safeNumber(morale.max,morale.current||0)))}.`:'Мораль цели не определена.',vulnerability='Уязвимость: если у цели есть особая уязвимость, её сообщает Мастер.';
          if(check.success){setExperiencedLookTarget(character,scene,target);message=`успешно анализирует ${target.name}. ${health} ${moraleText} ${vulnerability} До конца боя +3 к попаданию по этой цели; бонуса к урону нет.`;}
          else message=`не смог определить слабые места ${target.name}: проверка Анализа провалена.`;
          result={...result,success:Boolean(check.success),check,rollRecord:roll,health:check.success?health:null,morale:check.success?moraleText:null,vulnerability:check.success?vulnerability:null,hitBonus:check.success?3:0};
        }else if(action.slot==='bonus-support'){
          if(!inCombat)throw Object.assign(new Error('«Поддержать» используется во время боя.'),{statusCode:409});requireOwnCombatTurn();requireAlly(target);
          odCost=1;spendTokenOd(token,odCost);
          const moraleResolved=await resolveScalarRoll(scene,token,{body,label:`${token.name}: Поддержать — восстановление морали`,sides:6,kind:'bonus-support',purpose:'morale-restore'}),roll=moraleResolved.value,applied=adjustTokenMorale(target,roll);
          result={...result,die:'1d6',roll,applied,formula:moraleResolved.roll?.formula||'1d6',rollRecord:moraleResolved.roll};message=`поддерживает ${target.name}: восстановлено ${applied} морали (1к6: ${roll}).`;
        }else if(action.slot==='bonus-morale-brace'){
          requireAlly(target,{self:true});
          const effect={sourceKey:entry.key,sourceName:entry.name,sourceKind:entry.kind,die:8,leaderTokenId:token.id};
          armFeatureEffect(target,'moraleReduction',effect);result={...result,effect};message=`готовится поддержать ${target.name}: следующая фиксированная потеря морали может быть уменьшена на 1к8. Для бросковой потери морали реакция появится автоматически.`;
        }else if(action.slot==='bonus-study'){
          if(target.id===token.id)throw Object.assign(new Error('Нельзя выбрать себя Изученной целью.'),{statusCode:409});
          if(!reactionSourceCanSee(scene,token,target))throw Object.assign(new Error('Изучаемая цель должна быть видима.'),{statusCode:409});
          if(inCombat){requireOwnCombatTurn();odCost=1;spendTokenOd(token,odCost);}
          const allowed=new Set(['wounds','armor','weapon','effects','mz','speed']),category=allowed.has(String(body.studyCategory||''))?String(body.studyCategory):'wounds',fact=studiedObservableFact(scene,token,target,category),studied=studiedTargetState(character,scene);
          studied.targetTokenId=target.id;studied.studiedAt=nowIso();studied.lastFact={category,text:fact,at:nowIso()};markUse=false;
          result={...result,category,fact,studiedTarget:{id:target.id,name:target.name}};message=`изучает ${target.name}. ${fact}`;
        }else if(action.slot==='bonus-calculated'){
          if(!inCombat)throw Object.assign(new Error('«Просчитанный момент» используется во время боя.'),{statusCode:409});
          const studied=studiedTargetToken(character,scene);if(!studied||criticalState(studied).dead)throw Object.assign(new Error('Сначала выберите живую Изученную цель.'),{statusCode:409});
          const effect={sourceKey:entry.key,sourceName:entry.name,sourceKind:entry.kind,condition:'advantage',targetTokenId:studied.id,expiresAfterOwnerTurn:true,skipCurrentOwnerTurnEnd:isCurrentCombatToken(scene,token)};
          armFeatureEffect(token,'nextAttack',effect);result={...result,targetTokenId:studied.id,targetName:studied.name,effect};message=`фиксирует просчитанный момент против ${studied.name}: следующая атака получает преимущество.`;
        }else if(action.slot==='bonus-point-weakness'){
          if(!inCombat)throw Object.assign(new Error('«Указать слабость» используется во время боя.'),{statusCode:409});requireOwnCombatTurn();requireAlly(target);
          const studied=studiedTargetToken(character,scene);if(!studied||criticalState(studied).dead)throw Object.assign(new Error('Сначала выберите живую Изученную цель.'),{statusCode:409});
          odCost=1;spendTokenOd(token,odCost);
          const effect={sourceKey:entry.key,sourceName:entry.name,sourceKind:entry.kind,condition:'advantage',targetTokenId:studied.id,expiresAfterOwnerTurn:true,skipCurrentOwnerTurnEnd:isCurrentCombatToken(scene,target)};
          armFeatureEffect(target,'nextAttack',effect);result={...result,studiedTargetId:studied.id,studiedTargetName:studied.name,effect};message=`указывает ${target.name} слабость ${studied.name}: следующая атака по Изученной цели получает преимущество.`;
          targetCharacter=target.kind==='character'?linkedCharacter(target):null;
        }else if(action.slot==='bonus-follow-me'){
          if(!inCombat)throw Object.assign(new Error('«За мной!» используется во время боя.'),{statusCode:409});requireOwnCombatTurn();
          const choices=body.followChoices&&typeof body.followChoices==='object'&&!Array.isArray(body.followChoices)?body.followChoices:{},eligible=(scene.tokens||[]).filter(item=>item.id!==token.id&&['character','npc'].includes(item.kind)&&!tokenUnableToReact(item)&&!tokensHostile(token,item)&&reactionSourceCanHear(scene,token,item,30));
          const picked=eligible.filter(item=>['morale','cover'].includes(String(choices[item.id]||'')));
          if(!picked.length)throw Object.assign(new Error('Ни один союзник не выбрал эффект «За мной!».') ,{statusCode:409});
          odCost=2;spendTokenOd(token,odCost);const effects=[];
          for(const ally of picked){
            const choice=String(choices[ally.id]);
            if(choice==='morale'){
              const moraleResolved=await resolveScalarRoll(scene,token,{body,label:`${token.name}: За мной! — мораль ${ally.name}`,sides:8,kind:'bonus-follow-me',purpose:'morale-restore'}),roll=moraleResolved.value,applied=adjustTokenMorale(ally,roll);effects.push({tokenId:ally.id,name:ally.name,choice,roll,applied,formula:moraleResolved.roll?.formula||'1d8'});markCharacterChanged(ally,body.clientId);
            }else{
              const point=bonusCoverStepPoint(scene,ally,10);
              if(!point){effects.push({tokenId:ally.id,name:ally.name,choice,success:false,reason:'Нет доступного маршрута к укрытию.'});continue;}
              const oldPoint={x:ally.x,y:ally.y},reactions=await resolveMovementReactions(scene,ally,oldPoint,point,{...body,ignoreZoneFire:true,clientId:null,playerName:`${token.name}: За мной!`});
              if(!criticalState(ally).dead){ally.x=point.x;ally.y=point.y;ally.updatedAt=nowIso();markCharacterChanged(ally,body.clientId);}
              effects.push({tokenId:ally.id,name:ally.name,choice,success:!criticalState(ally).dead,to:{x:point.x,y:point.y},coverName:point.coverName,reactions});
            }
          }
          result={...result,effects};message=`отдаёт команду «За мной!». Союзников затронуто: ${effects.length}.`;
        }else if(action.slot==='bonus-foresaw'){
          if(!inCombat)throw Object.assign(new Error('Боевая реакция «Я это предусмотрел» доступна во время боя.'),{statusCode:409});
          const payment=spendThoughtfulReactionCost(scene,token,1),actions=tokenActions(token);actions.thoughtfulReactionPermission={sourceKey:entry.key,sourceName:entry.name,createdAt:nowIso(),scope:bonusSceneScope(scene),note:cleanText(body.reactionNote,500)};
          result={...result,payment,permission:actions.thoughtfulReactionPermission};message=`заявляет реакцию «Я это предусмотрел»: зарезервировано подходящее неатакующее действие стоимостью 1 ОД.`;
        }else{
          odCost=inCombat?Math.max(0,Math.round(safeNumber(action.odCost,0))):0;if(odCost)spendTokenOd(token,odCost);
          if(action.slot==='moraleRestore'){const moraleResolved=await resolveScalarRoll(scene,token,{body,label:`${token.name}: ${entry.name} — восстановление морали`,sides:action.die,kind:'feature-morale-restore',purpose:'morale-restore'}),roll=moraleResolved.value,applied=adjustTokenMorale(target,roll);result={...result,die:`1d${action.die}`,roll,applied,formula:moraleResolved.roll?.formula||`1d${action.die}`,rollRecord:moraleResolved.roll};message=`${target.name} восстанавливает ${applied} морали (1к${action.die}: ${roll}).`;}
          else if(action.slot==='safeMove'){const actions=tokenActions(target),feet=Math.max(0,safeNumber(action.feet,0));actions.aberrantSafeMoveFeet=Math.max(safeNumber(actions.aberrantSafeMoveFeet,0),feet);result={...result,feet};message=`подготавливает «${entry.name}»: ${feet} фт перемещения без провоцирования реакций.`;}
          else if(action.slot==='ignoreZeroMorale'){const actions=tokenActions(target),ownTurn=Boolean(inCombat&&isCurrentCombatToken(scene,target));actions.ignoreZeroMoralePenalty={roundAction:false,sourceKey:entry.key,sourceName:entry.name,ownTurnsRemaining:ownTurn?2:1};result={...result,ownTurnsRemaining:actions.ignoreZeroMoralePenalty.ownTurnsRemaining};message=`${target.name} игнорирует штраф от нулевой морали до конца следующего собственного хода.`;}
          else if(action.slot==='declare'){message=`заявляет использование «${entry.name}». Нечисловой или контекстный эффект разрешает Мастер.`;}
          else{const effect={sourceKey:entry.key,sourceName:entry.name,sourceKind:entry.kind,flat:action.flat||0,extraDie:action.extraDie||0,afterFailure:Boolean(action.afterFailure),condition:action.condition||null,reroll:Boolean(action.reroll),rerollPenalty:safeNumber(action.rerollPenalty,0),die:action.die||0,feet:action.feet||0,onHitTargetAttackPenalty:safeNumber(action.onHitTargetAttackPenalty,0)};armFeatureEffect(target,action.slot,effect);result={...result,effect};message=`подготавливает «${entry.name}»: ${action.label}${target.id!==token.id?` для ${target.name}`:''}.`;}
        }
      }catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message||'Не удалось применить особенность.'});return true;}
      if(markUse)markFeatureUsedForHost(featureHost,scene,entry);
      if(token.kind==='character'){character.revision=Math.max(0,Number(character.revision||0))+1;character.updatedAt=nowIso();}else if(character)character.updatedAt=nowIso();
      targetCharacter=targetCharacter||(target.kind==='character'?linkedCharacter(target):null);if(targetCharacter&&targetCharacter.id!==character?.id){targetCharacter.revision=Math.max(0,Number(targetCharacter.revision||0))+1;targetCharacter.updatedAt=nowIso();}
      if(odCost){result.odCost=odCost;message+=` Потрачено ${odCost} ОД.`;}
      const log=appendTableLog({type:'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,token.name),text:`${token.name} ${message}`,sceneId:scene.id,tokenId:token.id,meta:result.formula?{formula:result.formula}:{}});
      await persistCampaign();await persist();if(broadcastCharacterUpdated&&token.kind==='character'){broadcastCharacterUpdated(character,body.clientId);if(targetCharacter&&targetCharacter.id!==character.id)broadcastCharacterUpdated(targetCharacter,body.clientId);}else if(token.kind==='npc')broadcastCampaignReplaced?.(body.clientId,'npc-feature-used');broadcast('battlemap-replaced',body.clientId,{reason:'feature-use',sceneId:scene.id,tokenId:token.id});broadcastTableLog(log);sendJson(res,201,{ok:true,feature:entry,action,result,bonusStatus:token.kind==='character'?bonusTraitStatus(scene,token,character):null,log});return true;
    }

    if(pathname==='/api/battlemap/roll-reactions'&&req.method==='GET'){
      const scene=findScene(cleanId(requestUrl.searchParams.get('sceneId'),state.activeSceneId)),rollId=cleanId(requestUrl.searchParams.get('rollId'),null),body={clientId:requestUrl.searchParams.get('clientId')},campaign=getCampaign(),roll=(campaign.diceLog||[]).find(item=>item?.id===rollId);
      if(!scene||!roll||roll.sceneId!==scene.id){sendJson(res,404,{ok:false,error:'Бросок или сцена не найдены.'});return true;}
      if(roll.visibility==='master'&&!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Этот бросок виден только мастеру.'});return true;}
      const reactions=checkRollReactionOptions(scene,roll,req,requestUrl,body);
      sendJson(res,200,{ok:true,rollId:roll.id,supersededBy:roll.supersededBy||null,reactions});return true;
    }
    if(pathname==='/api/battlemap/roll-finalize'&&req.method==='POST'){
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,state.activeSceneId)),campaign=getCampaign(),source=(campaign.diceLog||[]).find(item=>item?.id===cleanId(body.rollId,null));
      if(!scene||!source||source.sceneId!==scene.id){sendJson(res,404,{ok:false,error:'Бросок или сцена не найдены.'});return true;}
      const current=latestReactionRoll(source),rollerIds=reactionRollerTokenIds(current),rollerControlled=rollerIds.some(id=>{const token=findToken(scene,id);return token&&canControlToken(token,req,requestUrl,body);}),available=checkRollReactionOptions(scene,current,req,requestUrl,body);
      if(!isMasterAuthorized(req,requestUrl,body)&&!rollerControlled&&!available.length){sendJson(res,403,{ok:false,error:'У вас нет права завершить это окно реакции.'});return true;}
      const finalized=finalizePendingRollResolution(scene,current);
      await persistCampaign();
      sendJson(res,200,{ok:true,rollId:finalized.id,rootRollId:finalized.reactionRootId||source.reactionRootId||source.id});return true;
    }
    if(pathname==='/api/battlemap/roll-reaction'&&req.method==='POST'){
      // A post-roll reaction is not a turn action. Never gate this endpoint with
      // isCurrentCombatToken(): Zone of Fire, opportunity attacks, defensive rerolls and
      // Foresight are deliberately usable while another combatant owns the active turn.
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,state.activeSceneId)),campaign=getCampaign(),source=(campaign.diceLog||[]).find(item=>item?.id===cleanId(body.rollId,null));
      if(!scene||!source||source.sceneId!==scene.id){sendJson(res,404,{ok:false,error:'Бросок или сцена не найдены.'});return true;}
      if(source.supersededBy){sendJson(res,409,{ok:false,error:'Этот результат уже был изменён другой реакцией.',supersededBy:source.supersededBy});return true;}
      if(rollReactionFinalized(source)){sendJson(res,409,{ok:false,error:'Окно реакций для этого броска уже закрыто.'});return true;}
      const reactions=checkRollReactionOptions(scene,source,req,requestUrl,body),reaction=reactions.find(item=>item.id===String(body.reactionId||''));
      if(!reaction){sendJson(res,409,{ok:false,error:'Эта реакция сейчас недоступна или её условие больше не выполнено.'});return true;}
      const roller=findToken(scene,cleanId(reaction.rollTokenId||source.tokenId,null));if(!roller){sendJson(res,404,{ok:false,error:'Токен бросавшего больше не найден.'});return true;}
      const next=clone(source);next.id=makeId(attackRollFromRecord(source)?'attack':'roll');next.at=nowIso();next.reactionOf=source.id;next.reactionRootId=source.reactionRootId||source.id;next.supersededBy=null;next.resolutionFinal=false;next.resolutionPending=true;next.reactionExpiresAt=null;next.reaction={id:reaction.id,kind:reaction.kind,label:reaction.label,rollPart:reaction.rollPart||null,rollTokenId:reaction.rollTokenId||null,sourceTokenId:reaction.sourceTokenId||null,sourceName:reaction.sourceName||null,featureName:reaction.featureName||null,trait:reaction.trait||null,rank:reaction.rank||null,luckyMode:reaction.luckyMode||null,gift:reaction.gift||null};next.appliedReactionKeys=[...new Set([...(Array.isArray(source.appliedReactionKeys)?source.appliedReactionKeys:[]),reaction.applyKey||reaction.id])];
      if(attackRollFromRecord(source)){
        if(reaction.kind==='reroll'){applyAttackRerollReaction(scene,next,reaction);applyLuckyOwnRerollBonus(scene,next,reaction);}
        else if(reaction.kind==='second-wind'){const attack=clone(next.battlemapAttack);attack.id=next.id;attack.at=next.at;attack.secondWindDeclared={targetTokenId:reaction.sourceTokenId,sourceName:reaction.sourceName};next.battlemapAttack=attack;next.formula=attack.formula;next.total=String(attack.kind||'').startsWith('melee')?attack.attackerTotal:attack.total;next.modifier=String(attack.kind||'').startsWith('melee')?attack.attackerBonus:attack.hitBonus;next.rolls=Array.isArray(attack.rolls)?[...attack.rolls]:next.rolls;}
        else if(reaction.kind==='area-shift'){const attack=clone(next.battlemapAttack);attack.id=next.id;attack.at=next.at;attack.areaShift={feet:Math.max(0,safeNumber(reaction.feet,5)),sourceName:reaction.featureName||reaction.label,sourceFeatureKey:reaction.featureKey||null};next.battlemapAttack=attack;next.formula=attack.formula;next.total=attack.total;next.modifier=attack.hitBonus;next.rolls=Array.isArray(attack.rolls)?[...attack.rolls]:next.rolls;}
        else{sendJson(res,400,{ok:false,error:'Неподдерживаемый тип реакции на атаку.'});return true;}
      }else if(reaction.kind==='reroll'){
        if(source.kind!=='check'){
          const sides=Math.max(2,Math.round(safeNumber(next.scalarSides,dieSides(next.formula,6)))),count=clamp(Math.round(safeNumber(next.scalarCount,Array.isArray(next.rolls)?next.rolls.length:1)),1,20),firstValues=Array.isArray(source.rolls)&&source.rolls.length?[...source.rolls]:[Math.round(safeNumber(source.scalarRoll,source.total))],first=firstValues.reduce((sum,value)=>sum+Math.round(safeNumber(value,0)),0),secondValues=Array.from({length:count},()=>rollOne(sides)),second=secondValues.reduce((sum,value)=>sum+value,0),modifier=Math.round(safeNumber(next.scalarModifier,next.modifier));next.scalarCount=count;next.scalarRoll=second;next.rolls=secondValues;next.modifier=modifier;next.total=second+modifier;next.rerolled={name:reaction.gift||reaction.label,part:'scalar',first,second,firstValues,secondValues,penalty:0,obligatory:true};next.formula=`${count}d${sides} → ${count}d${sides} (переброс, используется второй)${modifier?signedFormulaBonus(modifier):''}`;
        }else if(reaction.rollPart==='difficulty'){
          const first=Math.round(safeNumber(next.difficultyRoll,0)),sides=dieSides(next.difficultyDie,6),double=String(next.difficultyDie||'').startsWith('2d'),values=double?[rollOne(sides),rollOne(sides)]:[rollOne(sides)],second=double?(next.condition==='advantage'?Math.min(...values):next.condition==='hindrance'?Math.max(...values):values[0]):values[0];
          next.difficultyRolls=values;next.difficultyRoll=second;next.difficultyTotal=Math.round(second+safeNumber(next.difficultyModifier,0));next.rerolled={name:reaction.featureName||reaction.trait||reaction.gift||reaction.label,part:'difficulty',first,second,values,penalty:0,obligatory:true};recalculateReactionCheck(next);next.formula=rebuildReactionFormula(next,reaction);
        }else{
          const first=Math.round(safeNumber(next.successRoll,0)),second=rollOne(dieSides(next.successDie,6)),penalty=Math.round(safeNumber(reaction.penalty,0));
          next.successRoll=second;next.successBonus=Math.round(safeNumber(next.successBonus,0)+penalty);next.rerolled={name:reaction.featureName||reaction.trait||reaction.gift||reaction.label,part:'success',first,second,penalty,obligatory:true};next.rolls=[first,second,...(Array.isArray(next.extraRolls)?next.extraRolls.map(item=>item.roll):[])];recalculateReactionCheck(next);next.formula=rebuildReactionFormula(next,reaction);
        }
        applyLuckyOwnRerollBonus(scene,next,reaction);
      }else if(reaction.kind==='morale-reduce'){
        const sides=8,value=rollOne(sides),before=Math.max(0,Math.round(safeNumber(next.total,0))),reduction=Math.min(before,value);next.total=Math.max(0,before-reduction);next.moraleTraitReduction={die:'1d8',roll:value,reduction,before,after:next.total,sourceName:reaction.sourceName};next.formula=`${source.formula} − 1d8(${value}) [Не падать духом]`;next.rolls=[...(Array.isArray(source.rolls)?source.rolls:[]),value];
      }else if(reaction.kind==='morale-floor-one'){
        const morale=moraleHost(roller),before=Math.max(0,Math.round(safeNumber(next.total,0))),current=Math.max(0,Math.round(safeNumber(morale?.current,0))),allowedLoss=Math.max(0,current-1);next.total=Math.min(before,allowedLoss);next.moraleFloorOne={before,after:next.total,sourceName:reaction.sourceName};next.formula=`${source.formula} → потеря ${next.total} [Не сломаться]`;
      }else if(reaction.kind==='lucky-edge'){
        const originalMargin=Math.round(safeNumber(next.margin,0)),difference=Math.abs(originalMargin),severity=difference<=1?'none':difference===2?'light':'serious';next.luckyEdge={originalMargin,difference,severity,sourceName:reaction.sourceName};next.outcome='success';next.margin=0;next.formula=`${source.formula} [На волосок: последствие ${severity==='none'?'нет':severity==='light'?'лёгкое':'серьёзное'}]`;
      }else if(reaction.kind==='extra-die'){
        const sides=[4,6,8,10,12].includes(Math.round(safeNumber(reaction.sides,4)))?Math.round(safeNumber(reaction.sides,4)):4,value=rollOne(sides);next.extraRolls=Array.isArray(next.extraRolls)?next.extraRolls:[];next.extraRolls.push({name:reaction.featureName||reaction.label,die:`1d${sides}`,roll:value,reaction:true});next.successBonus=Math.round(safeNumber(next.successBonus,0)+value);next.rolls=[Math.round(safeNumber(next.successRoll,0)),...next.extraRolls.map(item=>item.roll)];recalculateReactionCheck(next);next.formula=rebuildReactionFormula(next,reaction);
      }else{sendJson(res,400,{ok:false,error:'Неподдерживаемый тип реакции.'});return true;}
      source.supersededBy=next.id;source.supersededAt=next.at;
      const changedCharacters=new Map();let tension=null,willRoll=null;
      if(reaction.featureKey&&roller.kind==='character'){
        const character=linkedCharacter(roller),entry=characterFeatureEntries(character).find(item=>item.key===reaction.featureKey);if(entry){markFeatureUsedForHost(character.state,scene,entry);changedCharacters.set(character.id,character);}if(reaction.prepared)consumeFeatureEffect(roller,reaction.kind==='area-shift'?'areaShift':'nextCheck');
      }
      if(reaction.trait==='Удачливый'){
        const luckyToken=findToken(scene,cleanId(reaction.sourceTokenId||reaction.rollTokenId,null));if(luckyToken?.kind==='character'){const character=linkedCharacter(luckyToken);spendFortune(character,scene);traitUsageState(character.state).luckyRerollUsedAt=nowIso();changedCharacters.set(character.id,character);}
      }
      if(reaction.trait==='Крепкий'&&Number(reaction.rank)===4){
        const sourceToken=findToken(scene,cleanId(reaction.sourceTokenId,null));if(sourceToken?.kind==='character'){const character=linkedCharacter(sourceToken),rt=bonusTraitRuntime(character.state,true);rt.secondWindPrepared={source:'Крепкий 4 — Второе дыхание',preparedAt:nowIso(),attackRollId:next.id};markBonusAbilityUsed(character.state,scene,'Крепкий:4','battle');changedCharacters.set(character.id,character);}
      }
      if(reaction.trait==='Уверенный'&&[4,5].includes(Number(reaction.rank))){
        const sourceToken=findToken(scene,cleanId(reaction.sourceTokenId,null));if(sourceToken?.kind==='character'){const character=linkedCharacter(sourceToken);markBonusAbilityUsed(character.state,scene,`Уверенный:${Number(reaction.rank)}`,'battle');changedCharacters.set(character.id,character);}
      }
      if(reaction.gift==='Предвидение'&&Number(reaction.rank)===2){
        const sourceToken=findToken(scene,cleanId(reaction.sourceTokenId,null));if(!sourceToken||sourceToken.kind!=='character'||!canControlToken(sourceToken,req,requestUrl,body)){sendJson(res,409,{ok:false,error:'Источник Предвидения II больше недоступен.'});return true;}tension=await resolveAberrationTension(scene,sourceToken,2,body);const sourceCharacter=linkedCharacter(sourceToken);if(sourceCharacter)changedCharacters.set(sourceCharacter.id,sourceCharacter);willRoll=tension?.willRoll||null;
      }
      for(const character of changedCharacters.values()){character.revision=Math.max(0,Number(character.revision||0))+1;character.updatedAt=nowIso();}
      scene.updatedAt=nowIso();campaign.diceLog.push(next);if(campaign.diceLog.length>200)campaign.diceLog.splice(0,campaign.diceLog.length-200);notePendingRollReaction(scene,next);
      let resultText='';const nextAttack=attackRollFromRecord(next);if(nextAttack){resultText=String(nextAttack.kind||'').startsWith('melee')?`${nextAttack.attackerTotal} против ${nextAttack.defenderTotal} — ${nextAttack.hit?'попадание':nextAttack.tie?'ничья':'защитник победил'}`:`${nextAttack.total} против МЗ ${nextAttack.targetMz} — ${nextAttack.hit?'попадание':'промах'}`;}else if(next.kind==='check')resultText=`${checkTotalBreakdown(next)} против ${next.difficultyTotal} — ${outcomeTextForCheck(next.outcome)}`;else resultText=`${next.total}${next.modifier?` (модификатор ${signedFormulaBonus(next.modifier)})`:''}`;
      const entry=appendTableLog({type:'roll',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,reaction.sourceName||source.actorName||'Участник'),text:`${source.label}: ${reaction.label} → ${resultText}`,visibility:source.visibility,sceneId:scene.id,tokenId:roller.id,meta:{rollId:next.id,reactionOf:source.id,reaction:reaction.label}});
      await persistCampaign();await persist();if(broadcastDice)broadcastDice(next);for(const character of changedCharacters.values())if(broadcastCharacterUpdated)broadcastCharacterUpdated(character,body.clientId);broadcast('battlemap-replaced',body.clientId,{reason:'roll-reaction',sceneId:scene.id,tokenId:roller.id});broadcastTableLog(entry);sendJson(res,201,{ok:true,roll:next,reaction,entry,tension,willRoll});return true;
    }

    if (pathname === '/api/battlemap/skill-profile' && req.method === 'GET') {
      const scene=findScene(cleanId(requestUrl.searchParams.get('sceneId'),null)),token=findToken(scene,cleanId(requestUrl.searchParams.get('tokenId'),null));if(!scene||!token){sendJson(res,404,{ok:false,error:'Токен не найден.'});return true;}
      const body={clientId:requestUrl.searchParams.get('clientId')};if(!canControlToken(token,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете этим токеном.'});return true;}
      const combatContext=requestUrl.searchParams.get('combatContext')==='1';
      if(token.kind==='character'){const character=linkedCharacter(token),skills=ALL_SKILLS.map(name=>characterSkillProfileDetailed(character,name,combatContext));sendJson(res,200,{ok:true,tokenId:token.id,skills,optionsBySkill:Object.fromEntries(skills.map(skill=>[skill.name,rollOptionsForCharacter(character,skill.name,scene)]))});return true;}
      if(token.kind==='npc'){const npc=linkedNpc(token)||{},c=npc.characteristics||{},die=normalizeDie(npc.successDie,'1d6'),armorProfile=normalizedNpcArmor(npc).profile,map={'Физическая сила':'strength','Взлом':'dexterity','Акробатика':'dexterity','Скрытность':'dexterity','Выдержка':'endurance','Стойкость':'endurance','Иммунитет':'endurance','Бдительность':'concentration','Воля':'concentration','Меткость':'concentration','Выживание':'concentration','Анализ':'intelligence','Эрудиция':'intelligence','Память':'intelligence','Медицина':'intelligence','Механика':'intelligence','Убеждение':'charisma','Обман':'charisma','Интуиция':'charisma','Запугивание':'charisma','Очарование':'charisma'};const skills=ALL_SKILLS.map(name=>{const injury=injurySkillPenalty(npc,name),serious=safeNumber(npc?.wounds?.serious,0)>0?armorSeriousPenaltyForProfile(armorProfile):0,armorMod=armorSkillModifierForProfile(armorProfile,name),breakdown=[...injury.parts];if(serious)breakdown.push({label:armorProfile==='Стабилизирующая тяжёлая броня'?'Серьёзное ранение — стабилизирующая броня':'Серьёзное ранение',value:serious});if(armorMod)breakdown.push({label:armorProfile,value:armorMod});return{name,cube:die,bonus:Math.round(safeNumber(c[map[name]],0)+injury.value+serious+armorMod),group:skillGroup(name),advantages:[],hindrances:[],breakdown};});sendJson(res,200,{ok:true,tokenId:token.id,skills,optionsBySkill:Object.fromEntries(skills.map(skill=>[skill.name,armorContextualSkillOptions(armorProfile,skill.name)]))});return true;}
      sendJson(res,400,{ok:false,error:'У этого токена нет навыков.'});return true;
    }
    if (pathname === '/api/battlemap/skill-check' && req.method === 'POST') {
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null));if(!scene||!token){sendJson(res,404,{ok:false,error:'Токен не найден.'});return true;}if(!canControlToken(token,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете этим токеном.'});return true;}
      const skillName=cleanText(body.skillName,100);let character=null,profile=null,options=[];
      if(token.kind==='character'){character=linkedCharacter(token);profile=characterSkillProfileDetailed(character,skillName,Boolean(body.combatContext));options=rollOptionsForCharacter(character,skillName,scene);if(profile.criticalBlocked){sendJson(res,409,{ok:false,error:'Критически раненый персонаж не может совершать проверки.'});return true;}}
      else if(token.kind==='npc'){const npc=linkedNpc(token)||{},c=npc.characteristics||{},armorProfile=normalizedNpcArmor(npc).profile,map={'Физическая сила':'strength','Взлом':'dexterity','Акробатика':'dexterity','Скрытность':'dexterity','Выдержка':'endurance','Стойкость':'endurance','Иммунитет':'endurance','Бдительность':'concentration','Воля':'concentration','Меткость':'concentration','Выживание':'concentration','Анализ':'intelligence','Эрудиция':'intelligence','Память':'intelligence','Медицина':'intelligence','Механика':'intelligence','Убеждение':'charisma','Обман':'charisma','Интуиция':'charisma','Запугивание':'charisma','Очарование':'charisma'};const injury=injurySkillPenalty(npc,skillName),serious=safeNumber(npc?.wounds?.serious,0)>0?armorSeriousPenaltyForProfile(armorProfile):0,armorMod=armorSkillModifierForProfile(armorProfile,skillName),contextOptions=armorContextualSkillOptions(armorProfile,skillName),chosenIds=new Set(Array.isArray(body.optionIds)?body.optionIds.map(String):[]),contextBonus=contextOptions.some(opt=>chosenIds.has(opt.id))?1:0,breakdown=[...injury.parts];if(serious)breakdown.push({label:armorProfile==='Стабилизирующая тяжёлая броня'?'Серьёзное ранение — стабилизирующая броня':'Серьёзное ранение',value:serious});if(armorMod)breakdown.push({label:armorProfile,value:armorMod});if(contextBonus)breakdown.push({label:'Силовой каркас: тяжёлая нагрузка',value:contextBonus});profile={name:skillName,cube:normalizeDie(npc.successDie,'1d6'),bonus:Math.round(safeNumber(c[map[skillName]],0)+injury.value+serious+armorMod+contextBonus),advantages:[],hindrances:[],breakdown};}
      if(!profile){sendJson(res,400,{ok:false,error:'Навык не найден.'});return true;}const roll=makeMapSkillRoll(body,token,character,profile,options),campaign=getCampaign();if(character&&roll.chosenOptions?.some(option=>option.id==='species:pallid-memory'))removeSpeciesEffect(ensureSpeciesRuntime(character.state),'pallidMemory');campaign.diceLog.push(roll);if(campaign.diceLog.length>200)campaign.diceLog.splice(0,campaign.diceLog.length-200);const outcomeText=({'success':'успех','failure':'провал','edge':'успех на грани','critical-success':'критический успех','critical-failure':'критический провал'})[roll.outcome]||roll.outcome;const entry=appendTableLog({type:'roll',actorId:roll.actorId,actorName:roll.actorName,text:`${roll.label}: ${checkTotalBreakdown(roll)} против ${roll.difficultyTotal} — ${outcomeText}`,visibility:roll.visibility,sceneId:scene.id,tokenId:token.id,meta:{rollId:roll.id}});const reactions=checkRollReactionOptions(scene,roll,req,requestUrl,body);roll.resolutionPending=reactions.length>0;roll.resolutionFinal=!roll.resolutionPending;await persistCampaign();await persist();if(broadcastDice)broadcastDice(roll);broadcastTableLog(entry);sendJson(res,201,{ok:true,roll,entry,reactions});return true;
    }

    if(pathname==='/api/battlemap/token-narrative'&&req.method==='PUT'){
      const body=await readJsonBody(req);if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Нарративные модификаторы доступны только мастеру.'});return true;}
      const scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null));if(!scene||!token){sendJson(res,404,{ok:false,error:'Токен не найден.'});return true;}
      token.gmNarrative=normalizeNarrativeControl(body.narrative);token.updatedAt=nowIso();await persist();broadcast('battlemap-token-updated',body.clientId,{reason:'token-narrative',sceneId:scene.id,tokenId:token.id});sendJson(res,200,{ok:true,narrative:clone(token.gmNarrative)});return true;
    }
    if(pathname==='/api/battlemap/ai/turn'&&req.method==='POST'){
      const body=await readJsonBody(req);if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Запускать ИИ может только мастер.'});return true;}
      const scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null)),campaign=getCampaign();if(!scene||!token){sendJson(res,404,{ok:false,error:'NPC или сцена не найдены.'});return true;}const current=initiativeToken(scene,campaign.initiative?.entries?.[campaign.initiative?.currentIndex||0]);if(!state.combat?.active||state.combat.sceneId!==scene.id||current?.id!==token.id){sendJson(res,409,{ok:false,error:'Сейчас не ход этого NPC.'});return true;}if(aiTurnLocks.has(token.id)){sendJson(res,409,{ok:false,error:'Ход этого NPC уже выполняется.'});return true;}aiTurnLocks.add(token.id);try{const result=await runNpcAiTurn(scene,token,body);const entry=appendTableLog({type:'system',actorId:null,actorName:'Тактический ИИ',text:`ИИ завершил действия ${token.name}: ${result.steps.length} шаг(а).`,sceneId:scene.id,tokenId:token.id});broadcastTableLog(entry);await persistCampaign();await persist();broadcast('battlemap-replaced',body.clientId,{reason:'ai-turn',sceneId:scene.id,tokenId:token.id});sendJson(res,200,{ok:true,steps:result.steps,entry});}catch(error){sendJson(res,error.statusCode||500,{ok:false,error:error.message||'Ошибка хода ИИ.'});}finally{aiTurnLocks.delete(token.id);}return true;
    }

    if(pathname==='/api/battlemap/sniper-observation'&&req.method==='POST'){
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null));
      if(!scene||!token||!['character','npc'].includes(token.kind)){sendJson(res,404,{ok:false,error:'Боевой токен не найден.'});return true;}
      if(!canControlToken(token,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете этим токеном.'});return true;}
      if(!state.combat?.active||state.combat.sceneId!==scene.id||!state.combat.participantTokenIds?.includes(token.id)){sendJson(res,409,{ok:false,error:'Контрснайперское наблюдение доступно только участнику активного боя.'});return true;}
      if(!isCurrentCombatToken(scene,token)){sendJson(res,409,{ok:false,error:'Контрснайперское наблюдение можно объявить только в свой ход.'});return true;}
      try{assertTokenCanAct(token);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}
      const movement=movementSummary(token);if(safeNumber(movement?.spent,0)>.001){sendJson(res,409,{ok:false,error:'Контрснайперское наблюдение нельзя объявить после перемещения в этом ходу.'});return true;}
      const weaponId=String(body.weaponId||''),weapon=weaponsForToken(token).find(item=>String(item.id||item.slot||item.name)===weaponId),rifle=rifleProfileForWeapon(weapon);
      if(!weapon||!rifle){sendJson(res,400,{ok:false,error:'Для Контрснайперского наблюдения выберите снайперскую винтовку.'});return true;}
      if(rifle.proficiency<rifle.effectiveThreshold){sendJson(res,409,{ok:false,error:`Для Контрснайперского наблюдения владение винтовками должно быть не ниже порога ${rifle.effectiveThreshold}.`});return true;}
      if(counterSniperObservation(token,scene)){sendJson(res,409,{ok:false,error:'Контрснайперское наблюдение уже активно.'});return true;}
      try{spendTokenOd(token,1);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}
      const point=speciesCombatPoint(token),actions=tokenActions(token);actions.counterSniperObservation={roundAction:true,weaponId:String(weapon.id||weapon.slot||weapon.name),anchorX:point.x,anchorY:point.y,activatedAt:nowIso(),used:false};
      const entry=appendTableLog({type:'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,token.name),text:`${token.name} переходит в Контрснайперское наблюдение (${weapon.name}).`,sceneId:scene.id,tokenId:token.id});
      await persistCampaign();await persist();broadcastTableLog(entry);broadcast('battlemap-replaced',body.clientId,{reason:'counter-sniper-observation',sceneId:scene.id,tokenId:token.id});
      sendJson(res,201,{ok:true,cost:1,entry,sniperRuntime:publicSniperRuntime(scene,token)});return true;
    }

    if(pathname==='/api/battlemap/stealth'&&req.method==='POST'){
      const body=await readJsonBody(req);if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Назначать Скрытность может только мастер.'});return true;}
      const scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null));
      if(!scene||!token||!['character','npc'].includes(token.kind)){sendJson(res,404,{ok:false,error:'Токен персонажа или NPC не найден.'});return true;}
      const action=['check','grant','remove','visibility'].includes(body.action)?body.action:'check',difficultySides=[4,6,8,10,12].includes(Number(body.difficultySides))?Number(body.difficultySides):6,difficultyModifier=clamp(Math.round(safeNumber(body.difficultyModifier,0)),-20,20);
      if(action==='remove'){
        const host=actionHost(token);if(host)delete host._battlemapCombatStealth;
        const entry=appendTableLog({type:'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Мастер'),text:`${token.name}: Скрытность снята мастером.`,sceneId:scene.id,tokenId:token.id});
        await persistCampaign();await persist();broadcastTableLog(entry);broadcast('battlemap-replaced',body.clientId,{reason:'stealth-removed',sceneId:scene.id,tokenId:token.id});sendJson(res,200,{ok:true,entry,stealth:{active:false}});return true;
      }
      if(action==='visibility'){
        const rt=stealthRuntime(token,false);if(!rt?.active){sendJson(res,409,{ok:false,error:'Сначала назначьте персонажу Скрытность.'});return true;}
        rt.hideFromPlayers=Boolean(body.hideFromPlayers);
        const entry=appendTableLog({type:'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Мастер'),text:`${token.name}: ${rt.hideFromPlayers?'скрытый токен теперь виден только мастеру и владельцу':'токен снова виден другим игрокам, Скрытность сохраняется'}.`,sceneId:scene.id,tokenId:token.id,visibility:'master'});
        await persistCampaign();await persist();broadcastTableLog(entry);broadcast('battlemap-replaced',body.clientId,{reason:'stealth-visibility',sceneId:scene.id,tokenId:token.id});sendJson(res,200,{ok:true,entry,stealth:{active:true,hideFromPlayers:rt.hideFromPlayers,grantedWithoutCheck:Boolean(rt.grantedWithoutCheck)}});return true;
      }
      if(action==='grant'){
        const rt=stealthRuntime(token,true);rt.active=true;rt.grantedWithoutCheck=true;rt.lastCheckAt=nowIso();rt.lastOutcome='granted';delete rt.revealedAt;
        // Никаких кубов и модификаторов: это прямое мастерское назначение состояния.
        // Видимость токена остаётся такой, какой мастер настроил её ранее (по умолчанию — видим другим игрокам).
        rt.hideFromPlayers=Boolean(rt.hideFromPlayers);
        const visibilityText=rt.hideFromPlayers?' Токен виден только мастеру и владельцу.':'';
        const entry=appendTableLog({type:'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Мастер'),text:`${token.name}: Скрытность назначена мастером без проверки.${visibilityText}`,sceneId:scene.id,tokenId:token.id});
        await persistCampaign();await persist();broadcastTableLog(entry);broadcast('battlemap-replaced',body.clientId,{reason:'stealth-granted',sceneId:scene.id,tokenId:token.id});sendJson(res,201,{ok:true,entry,stealth:{active:true,hideFromPlayers:Boolean(rt.hideFromPlayers),grantedWithoutCheck:true}});return true;
      }
      const hideFromPlayers=Boolean(body.hideFromPlayers);
      try{
        const result=await resolveCombatStealthCheck(scene,token,{...body,playerName:body.playerName||'Мастер'},{difficultySides,difficultyModifier,hideFromPlayers,label:`${token.name}: вход в Скрытность`});
        await persistCampaign();await persist();broadcast('battlemap-replaced',body.clientId,{reason:'stealth-check',sceneId:scene.id,tokenId:token.id});sendJson(res,201,{ok:true,...result});
      }catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message||'Не удалось провести проверку Скрытности.'});}
      return true;
    }

    if(pathname==='/api/battlemap/combat/participant'&&req.method==='POST'){
      const body=await readJsonBody(req);if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Состав боя меняет только мастер.'});return true;}
      const scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null)),campaign=getCampaign();if(!state.combat?.active||state.combat.sceneId!==scene?.id){sendJson(res,409,{ok:false,error:'На этой сцене сейчас нет активного боя.'});return true;}if(!token||!['character','npc'].includes(token.kind)){sendJson(res,404,{ok:false,error:'Боевой токен не найден.'});return true;}
      const action=body.action==='remove'?'remove':'add',entries=campaign.initiative.entries||(campaign.initiative.entries=[]),currentToken=initiativeToken(scene,entries[campaign.initiative.currentIndex||0]),already=(state.combat.participantTokenIds||[]).includes(token.id);
      let participantRollEntry=null;
      if(action==='add'){
        if(already){sendJson(res,409,{ok:false,error:'Токен уже участвует в бою.'});return true;}if(tokenIsDead(token)){sendJson(res,409,{ok:false,error:'Мёртвый токен нельзя добавить в бой.'});return true;}
        if(token.kind==='npc'&&entries.some(entry=>entry.type==='npc'&&entry.refId===token.refId))cloneNpcSheetForToken(token);
        const entry=(await rollCombatInitiativeWithReactions(scene,[{token}],body))[0];entries.push(entry);entries.sort((a,b)=>b.score-a.score||String(a.refId).localeCompare(String(b.refId)));state.combat.participantTokenIds.push(token.id);clearCombatRuntimeForToken(token);resetTurnResources(token);resetTokenMovement(token);campaign.initiative.currentIndex=Math.max(0,entries.findIndex(item=>initiativeToken(scene,item)?.id===currentToken?.id));participantRollEntry=appendTableLog({type:'roll',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Мастер'),text:`${token.name} добавлен в бой. Инициатива: ${entry.score}.`,sceneId:scene.id,tokenId:token.id,meta:{formulas:initiativeFormulaLines(scene,[entry])}});
      }else{
        if(!already){sendJson(res,409,{ok:false,error:'Токен не участвует в бою.'});return true;}const wasCurrent=currentToken?.id===token.id,nextBefore=wasCurrent?initiativeToken(scene,entries[(campaign.initiative.currentIndex+1)%entries.length]):currentToken;campaign.initiative.entries=entries.filter(item=>item.tokenId?item.tokenId!==token.id:initiativeToken(scene,item)?.id!==token.id);state.combat.participantTokenIds=state.combat.participantTokenIds.filter(id=>id!==token.id);delete state.combat.movement?.[token.id];clearCombatRuntimeForToken(token);if(!campaign.initiative.entries.length){clearCombatOnlyActions(scene);state.combat={active:false,sceneId:null,participantTokenIds:[],startedAt:null,movement:{}};campaign.initiative={round:1,currentIndex:0,entries:[]};}else campaign.initiative.currentIndex=Math.max(0,campaign.initiative.entries.findIndex(item=>initiativeToken(scene,item)?.id===nextBefore?.id));
      }
      await persistCampaign();await persist();if(participantRollEntry)broadcastTableLog(participantRollEntry);broadcast('battlemap-replaced',body.clientId,{reason:'combat-participant',sceneId:scene.id,tokenId:token.id,action});if(broadcastCampaignReplaced)broadcastCampaignReplaced(body.clientId,'combat-participant');sendJson(res,200,{ok:true,combat:clone(state.combat),initiative:clone(campaign.initiative),entry:participantRollEntry});return true;
    }

    if (pathname === '/api/battlemap/combat/start' && req.method === 'POST') {
      const body = await readJsonBody(req);
      if (!isMasterAuthorized(req, requestUrl, body)) { sendJson(res, 403, { ok:false, error:'Начать бой может только мастер.' }); return true; }
      const scene = findScene(cleanId(body.sceneId, null)); if (!scene) { sendJson(res,404,{ok:false,error:'Сцена не найдена.'}); return true; }
      const ids = [...new Set((Array.isArray(body.tokenIds)?body.tokenIds:[]).map(value=>cleanId(value,null)).filter(Boolean))];
      // Старые сцены могли содержать несколько токенов, связанных с одним листом NPC.
      // Перед инициативой автоматически разделяем такие копии на независимые листы.
      const seenNpcRefs=new Set(),clonedNpcIds=[];
      for(const tokenId of ids){const token=findToken(scene,tokenId);if(!token||token.kind!=='npc'||!token.refId)continue;if(seenNpcRefs.has(token.refId)){const npc=cloneNpcSheetForToken(token);if(npc)clonedNpcIds.push(npc.id);}seenNpcRefs.add(token.refId);}
      const linked = new Set();
      const items = ids.map(tokenId => ({ token: findToken(scene, tokenId) })).filter(item => {
        if (!item.token || !['character','npc'].includes(item.token.kind) || item.token.defeated || !item.token.refId) return false;
        const key = `${item.token.kind}:${item.token.refId}`; if (linked.has(key)) return false; linked.add(key); return true;
      });
      if (!items.length) { sendJson(res,400,{ok:false,error:'Выберите хотя бы одного персонажа или NPC.'}); return true; }
      const campaign = getCampaign(); campaign.initiative = { round:1, currentIndex:0, entries:await rollCombatInitiativeWithReactions(scene,items,body) };
      for (const item of items) { clearCombatRuntimeForToken(item.token); resetTurnResources(item.token); }
      // v1.4.0: мастер может подготовить бой на своей сцене, не раскрывая её игрокам.
      // Публичная сцена меняется только явной командой «Показать игрокам».
      state.combat = { active:true, sceneId:scene.id, participantTokenIds:items.map(item=>item.token.id), startedAt:nowIso(), movement:Object.fromEntries(items.map(item=>[item.token.id,{spent:0,opportunityAttackers:[],zoneFireShooters:[]}])) };
      const tableEntry=appendTableLog({type:'roll',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Мастер'),text:`Начат бой: участников ${items.length}.${clonedNpcIds.length?` Для копий NPC создано отдельных листов: ${clonedNpcIds.length}.`:''}`,sceneId:scene.id,meta:{formulas:initiativeFormulaLines(scene,campaign.initiative.entries)}});
      await persistCampaign(); await persist(); broadcastTableLog(tableEntry);
      if (broadcastCampaignReplaced) broadcastCampaignReplaced(body.clientId, 'combat-start');
      broadcast('battlemap-replaced', body.clientId, { reason:'combat-started', sceneId:scene.id }); broadcastAudioEffect(scene.id,'ui.combatStart',{},body.clientId);
      sendJson(res,201,{ok:true,combat:clone(state.combat),initiative:clone(campaign.initiative),clonedNpcIds}); return true;
    }
    if (pathname === '/api/battlemap/combat/advance' && req.method === 'POST') {
      const body = await readJsonBody(req); const scene=findScene(state.combat?.sceneId);
      if (!state.combat?.active || !scene) { sendJson(res,409,{ok:false,error:'Боевой режим не активен.'}); return true; }
      const campaign=getCampaign(), entries=campaign.initiative?.entries||[], current=entries[campaign.initiative.currentIndex||0], token=initiativeToken(scene,current);
      const masterAuthorized=isMasterAuthorized(req,requestUrl,body);
      if (!masterAuthorized && (!token || !canControlToken(token,req,requestUrl,body))) { sendJson(res,403,{ok:false,error:'Завершить ход может активный игрок или мастер.'}); return true; }
      const bleedingResult=processBleedingAtTurnEnd(scene,token,body);
      const criticalCountdown=processCriticalCountdownAtTurnEnd(scene,token,body);
      let roundChanged=false,endTurnBeastCheck=null,endTurnRoll=null;
      const stealthResult=await resolveStealthAtTurnEnd(scene,token,body);
      if(token){advanceWeaponModTurnState(token);const move=movementRecord(token);tokenActions(token).previousTurnMovement={roundAction:false,moved:safeNumber(move?.spent,0)>.001,spent:Math.max(0,safeNumber(move?.spent,0)),round:Math.max(1,getCampaign().initiative?.round||1),at:nowIso()};}
      const expiredFeatureEffects=expireFeatureEffectsAtOwnerTurnEnd(token),expiredPristrelka=expirePristrelkaAtOwnerTurnEnd(token,scene);
      if(expiredFeatureEffects||expiredPristrelka)markCharacterChanged(token,body.clientId);
      const currentSpecies=speciesStateForToken(token);if(currentSpecies?.species==='werewolf'&&currentSpecies.werewolf?.transformed&&currentSpecies.werewolf.beastState!=='calm'){
        const resolved=await resolveWerewolfBeastCheck(scene,token,'конец хода: проверка Зверя',body,{label:`${token.name}: конец хода — Проверка Зверя`});endTurnBeastCheck=resolved.check;endTurnRoll=resolved.roll;markCharacterChanged(token,body.clientId);
      }
      if (entries.length) { campaign.initiative.currentIndex=(campaign.initiative.currentIndex+1)%entries.length; if (campaign.initiative.currentIndex===0){campaign.initiative.round=Math.max(1,campaign.initiative.round+1);roundChanged=true;} resetTurnResources(initiativeToken(scene,entries[campaign.initiative.currentIndex])); }
      const endedHost=actionHost(token),endedAb=endedHost?._battlemapAberration,endedActions=tokenActions(token);if(endedActions.ignoreZeroMoralePenalty){endedActions.ignoreZeroMoralePenalty.ownTurnsRemaining=Math.max(0,Math.round(safeNumber(endedActions.ignoreZeroMoralePenalty.ownTurnsRemaining,1))-1);if(endedActions.ignoreZeroMoralePenalty.ownTurnsRemaining<=0)delete endedActions.ignoreZeroMoralePenalty;}if(endedAb?.invisibleUntilTurnEnd){delete endedAb.invisibleUntargetable;delete endedAb.invisibleUntilTurnEnd;}const nextEntry=entries[campaign.initiative.currentIndex||0],nextToken=initiativeToken(scene,nextEntry);if(nextToken){for(const vehicle of scene.tokens||[]){if(vehicle.kind!=='vehicle'||vehicle.vehicle?.driverTokenId!==nextToken.id)continue;vehicle.vehicle.stabilizedUntilDriverTurn=false;vehicle.vehicle.roughUntilDriverTurn=false;vehicle.vehicle.evasiveUntilDriverTurn=false;vehicle.vehicle.stabilizedRound=0;vehicle.vehicle.sharpManeuverRound=0;}const h=actionHost(nextToken),ab=h?._battlemapAberration;if(ab?.invisibleRounds){ab.invisibleRounds-=1;if(ab.invisibleRounds<=0){delete ab.invisibleRounds;delete ab.invisibleHindrance;delete ab.invisibleFirstAttackAdvantage;}}if(ab?.hoverRounds){ab.hoverRounds-=1;if(ab.hoverRounds<=0){delete ab.hoverRounds;delete ab.hoverLevel;delete tokenActions(nextToken).aberrantHoverLevel;delete tokenActions(nextToken).aberrantMzBonus;}}if(h?._battlemapSkipNextTurn){delete h._battlemapSkipNextTurn;const info=tokenOd(nextToken);if(info)info.host[info.currentKey]=0;}}const turnStartZoneResults=await processEffectZonesAtTurnStart(scene,nextToken,roundChanged,body),turnAdvanceFormulas=journalRollFormulas(endTurnRoll?.formula,stealthResult?.roll?.formula,...turnStartZoneResults);const beastSuffix=endTurnBeastCheck?` Проверка Зверя: ${endTurnBeastCheck.success?'контроль восстановлен':beastStateLabel(endTurnBeastCheck.state)}.`:'',stealthSuffix=stealthResult?.check?` Скрытность ${token.name}: ${stealthResult.check.success?'сохранена':'утрачена'}.`:stealthResult?.ended?` Скрытность ${token.name}: снята.`:'',bleedingSuffix=bleedingResult?.advanced?` Кровотечение ${token.name}: получено Лёгкое ранение${bleedingResult.wound==='critical'?' с переходом в Критическое ранение':bleedingResult.died?' — персонаж погиб':''}.`:'',criticalSuffix=criticalCountdown?.died?` ${token.name} погибает: истёк отсчёт Критического ранения.`:criticalCountdown?.advanced?` Критическое ранение ${token.name}: осталось ${criticalCountdown.info.remaining} ход(а).`:'';const tableEntry=appendTableLog({type:turnAdvanceFormulas.length?'roll':'system',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text:`Конец хода.${beastSuffix}${stealthSuffix}${bleedingSuffix}${criticalSuffix} Теперь действует ${nextToken?.name||'следующий участник'}.`,sceneId:scene.id,tokenId:nextToken?.id,meta:{formulas:turnAdvanceFormulas}});await persist();broadcastTableLog(tableEntry);
      await persistCampaign(); if (broadcastCampaignReplaced) broadcastCampaignReplaced(body.clientId,'combat-advance'); broadcast('battlemap-replaced',body.clientId,{reason:'combat-advance'}); broadcastAudioEffect(scene.id,'ui.turn',{tokenId:nextToken?.id,x:nextToken?.x,y:nextToken?.y},body.clientId);
      sendJson(res,200,{ok:true,initiative:clone(campaign.initiative),beastCheck:endTurnBeastCheck,roll:endTurnRoll,stealthResult,bleedingResult,criticalCountdown}); return true;
    }
    if (pathname === '/api/battlemap/combat/end' && req.method === 'POST') {
      const body=await readJsonBody(req); if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Завершить бой может только мастер.'});return true;}
      const campaign=getCampaign(), endedSceneId=state.combat?.sceneId,endedScene=findScene(endedSceneId);if(endedScene){endedScene.effects=(endedScene.effects||[]).filter(effect=>effect.durationMode!=='owner-turn');clearCombatOnlyActions(endedScene);}state.combat={active:false,sceneId:null,participantTokenIds:[],startedAt:null,movement:{}}; campaign.initiative={round:1,currentIndex:0,entries:[]};
      const tableEntry=appendTableLog({type:'system',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Мастер'),text:'Бой завершён.',sceneId:endedSceneId});await persistCampaign(); await persist();broadcastTableLog(tableEntry); if(broadcastCampaignReplaced)broadcastCampaignReplaced(body.clientId,'combat-end'); broadcast('battlemap-replaced',body.clientId,{reason:'combat-ended'}); broadcastAudioEffect(endedSceneId,'ui.combatEnd',{},body.clientId); sendJson(res,200,{ok:true}); return true;
    }

    if (pathname === '/api/battlemap/push' && req.method === 'POST') {
      const body=await readJsonBody(req),key=requestKey(body,'push');const cached=cachedRequest(key);if(cached){sendJson(res,200,cached);return true;}
      const scene=findScene(cleanId(body.sceneId,null)),pusher=findToken(scene,cleanId(body.pusherTokenId,null)),target=findToken(scene,cleanId(body.targetTokenId,null));
      if(!scene||!pusher||!target){sendJson(res,404,{ok:false,error:'Толкающий или целевой токен не найден.'});return true;}if(pusher.id===target.id){sendJson(res,400,{ok:false,error:'Нельзя оттолкнуть самого себя.'});return true;}
      if(!['character','npc'].includes(pusher.kind)||!['character','npc'].includes(target.kind)){sendJson(res,400,{ok:false,error:'Отталкивание доступно персонажам и NPC против персонажей и NPC.'});return true;}
      try{assertTokenCanAct(pusher);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}if(!canControlToken(pusher,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете толкающим токеном.'});return true;}
      if(contactDistanceFeet(scene,pusher,target)>5.01||contactBlockedByWall(scene,speciesCombatPoint(pusher),speciesCombatPoint(target))){sendJson(res,409,{ok:false,error:'Для Отталкивания цель должна находиться на соседней клетке без стены между токенами.'});return true;}
      const inCombat=Boolean(state.combat?.active&&state.combat.sceneId===scene.id);if(inCombat&&!isCurrentCombatToken(scene,pusher)){sendJson(res,409,{ok:false,error:'Сейчас ход другого участника.'});return true;}if(inCombat)spendTokenOd(pusher,1);
      const result=await resolvePushChainWithReactions(scene,pusher,target,body),rolls=result.checks.map(item=>item.roll).filter(Boolean);
      const movedNames=result.planned.map(item=>item.tokenName),doorText=result.openedDoors.length?` Открыто дверей: ${result.openedDoors.map(item=>item.name).join(', ')}.`:'',outcome=result.moved?`отброшены: ${movedNames.join(', ')}`:`сдвинуть цель не удалось: ${result.blockedReason||'путь перекрыт'}`;
      const entry=appendTableLog({type:rolls.length?'roll':'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text:`${pusher.name} применяет «Оттолкнуть» к ${target.name}: ${outcome}.${doorText}`,sceneId:scene.id,tokenId:pusher.id,meta:{formulas:rolls.map(item=>item?.formula).filter(Boolean)}});
      await persistCampaign();await persist();broadcastTableLog(entry);broadcast('battlemap-replaced',body.clientId,{reason:'push',sceneId:scene.id});broadcastAudioEffect(scene.id,'melee.hit',{tokenId:pusher.id,x:pusher.x,y:pusher.y,targetTokenId:target.id},body.clientId);const payload={ok:true,cost:inCombat?1:0,preview:!inCombat,result,rolls,entry};storeRequest(key,payload);sendJson(res,201,payload);return true;
    }

    if (pathname === '/api/battlemap/tactical-action' && req.method === 'POST') {
      const body=await readJsonBody(req),key=requestKey(body,'tactical');const cached=cachedRequest(key);if(cached){sendJson(res,200,cached);return true;}
      const scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null));
      if(!scene||!token){sendJson(res,404,{ok:false,error:'Токен не найден.'});return true;}try{assertTokenCanAct(token);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}if(!canControlToken(token,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете этим токеном.'});return true;}
      const speciesSt=speciesStateForToken(token),sprintCost=speciesSt?.species==='werewolf'&&speciesSt.werewolf?.transformed?1:2;
      const defs={retreat:{cost:2,roundAction:true},sprint:{cost:sprintCost,movementMultiplier:2,roundAction:true},crossing:{cost:1,mzBonus:2,roundAction:true},charge:{cost:1,roundAction:true},block:{cost:1,blockMeleeDamage:true,roundAction:true},jump:{cost:1,oneShot:true},peek:{cost:0,roundAction:true}};
      const actionId=cleanId(body.actionId,null),def=defs[actionId];if(!def){sendJson(res,400,{ok:false,error:'Неизвестное действие.'});return true;}
      if(tokenMovementLocked(token)&&['sprint','crossing','charge','jump'].includes(actionId)){sendJson(res,409,{ok:false,error:'Блок активен: действия перемещения недоступны до снятия Блока.'});return true;}
      if(actionId==='retreat'&&speciesSt?.species==='werewolf'&&speciesSt.werewolf?.transformed&&speciesSt.werewolf.beastState!=='calm'){sendJson(res,409,{ok:false,error:'Во время Звериного или Полного срыва волколак не может применять Отход.'});return true;}
      if(['sprint','charge'].includes(actionId)&&(speciesConditions(token)?.prone||speciesConditions(token)?.wrappedByTokenId)){sendJson(res,409,{ok:false,error:'Это действие недоступно: токен сбит с ног или Обвит.'});return true;}
      const traumaHost=actionHost(token)||{};
      if(['sprint','jump'].includes(actionId)&&(hasTrauma(traumaHost,'Повреждённое колено')||hasTrauma(traumaHost,'Потеря конечности','leg'))){sendJson(res,409,{ok:false,error:'Эта травма не позволяет совершать Прыжки и Рывки.'});return true;}
      if(actionId==='peek'&&!tokenAdjacentToCover(scene,token)){sendJson(res,409,{ok:false,error:'Чтобы выглянуть, токен должен находиться на соседней клетке от укрытия с МЗ или ближе.'});return true;}
      const preview=!state.combat?.active||state.combat.sceneId!==scene.id;let toggledOff=false;
      if(preview&&actionId==='peek'){const actions=tokenActions(token);if(actions.peek){delete actions.peek;toggledOff=true;}else actions.peek={...def,at:nowIso()};}
      else if(!preview){if(!isCurrentCombatToken(scene,token)){sendJson(res,409,{ok:false,error:'Сейчас ход другого участника.'});return true;}const actions=tokenActions(token);if(!def.oneShot&&actions[actionId]){const previous=actions[actionId];delete actions[actionId];const movement=movementSummary(token);if(movement&&movement.spent>movement.limit+.01){actions[actionId]=previous;sendJson(res,409,{ok:false,error:'Нельзя снять действие: часть дополнительного движения уже использована.',movement});return true;}refundTokenOd(token,def.cost);toggledOff=true;}else{spendTokenOd(token,def.cost);if(!def.oneShot)actions[actionId]={...def,at:nowIso()};}}
      let traumaWound=false;if(!toggledOff&&['sprint','jump'].includes(actionId)&&hasTrauma(traumaHost,'Трещина в ребре'))traumaWound=directWound(token,'light');
      await persistCampaign();if(token.kind==='character'&&broadcastCharacterUpdated)broadcastCharacterUpdated(linkedCharacter(token),body.clientId);else if(broadcastCampaignReplaced)broadcastCampaignReplaced(body.clientId,'tactical-action');
      const actionTitle=({retreat:'Отход',sprint:'Рывок',crossing:'Перебежка',charge:'Натиск',block:'Блок',jump:'Прыжок',peek:'Выглянуть'})[actionId]||actionId;const tableEntry=appendTableLog({type:'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text:`${token.name}: ${actionTitle}${preview?' (вне боя)':toggledOff?' — снято':' — применено'}${traumaWound?' Трещина в ребре наносит 1 Лёгкое ранение.':''}.`,sceneId:scene.id,tokenId:token.id});await persist();broadcastTableLog(tableEntry);const payload={ok:true,preview,toggledOff,actionId,cost:def.cost,traumaWound,actions:clone(tokenActions(token)),movement:movementSummary(token),entry:tableEntry};storeRequest(key,payload);sendJson(res,201,payload);return true;
    }

    if (pathname === '/api/battlemap/species-action' && req.method === 'POST') {
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null));
      if(!scene||!token){sendJson(res,404,{ok:false,error:'Токен не найден.'});return true;}
      if(!canControlToken(token,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете этим токеном.'});return true;}try{assertTokenCanAct(token);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}
      const character=linkedCharacter(token),st=speciesStateForToken(token),action=cleanId(body.action,null);if(!character||!st){sendJson(res,400,{ok:false,error:'Действия вида доступны только связанному листу персонажа.'});return true;}
      const log=[],speciesManualFormulas=[];let beastCheck=null,preCheck=null,infectionCheck=null,preRoll=null,beastRoll=null,infectionRoll=null;const speciesOdBefore=tokenOd(token)?.current??null;
      const spend=amount=>{if(state.combat?.active&&state.combat.sceneId===scene.id&&!isCurrentCombatToken(scene,token)&&!isMasterAuthorized(req,requestUrl,body))throw Object.assign(new Error('Сейчас ход другого участника.'),{statusCode:409});spendTokenOd(token,amount);};
      const startWerewolfForm=(involuntary=false,{reason='непроизвольная трансформация',beastHindrance=false}={})=>{
        if(st.species!=='werewolf'||st.werewolf.transformed)throw Object.assign(new Error('Звериная форма недоступна или уже активна.'),{statusCode:409});
        if(!involuntary&&st.werewolf.uncontrolled)throw Object.assign(new Error('Неконтролируемая ликантропия не позволяет добровольную трансформацию.'),{statusCode:409});
        if(involuntary){const od=tokenOd(token),paid=Math.min(2,Math.max(0,Math.floor(od.current)));if(paid)spendTokenOd(token,paid);st.werewolf.odDebt+=2-paid;}else spend(2);
        st.werewolf.transformed=true;st.werewolf.hideUsed=false;setSpeciesEffect(st,'werewolfForm','Звериная форма','+40 футов Скорости; Рывок 1 ОД; Дикая ловкость, естественное оружие и Звериная шкура.');
        if(st.werewolf.uncontrolled){st.werewolf.beastState='full';st.werewolf.beastFailures=3;setSpeciesEffect(st,'werewolfBeast','Полный срыв','Не менее 2 ОД в ход тратится на преследование, атаку или пожирание; ближайшее живое существо является допустимой добычей.',{roundAction:false});}
        else if(involuntary)beastCheck=runWerewolfBeastCheck(token,reason,{hindrance:beastHindrance,applyOutcome:false});
      };
      try {
        if(action==='pallid-transform'){
          if(st.species!=='pallid')throw Object.assign(new Error('Персонаж не является паллидом.'),{statusCode:409});if(st.pallid.transformed)throw Object.assign(new Error('Форма Вечного уже активна.'),{statusCode:409});if(st.pallid.bloodDoses<1)throw Object.assign(new Error('Для трансформации нужна 1 Доза крови.'),{statusCode:409});spend(2);st.pallid.bloodDoses-=1;st.pallid.transformed=true;refundTokenOd(token,1);setSpeciesEffect(st,'pallidForm','Форма Вечного','+1 ОД в начале хода; +30 футов Скорости; Плоть Вечного и естественное оружие.');log.push('принята Форма Вечного');
        } else if(action==='pallid-end'){
          if(!st.pallid.transformed)throw Object.assign(new Error('Форма Вечного не активна.'),{statusCode:409});st.pallid.transformed=false;removeSpeciesEffect(st,'pallidForm');log.push('Форма Вечного прекращена');
        } else if(action==='pallid-blood'){
          st.pallid.bloodDoses=Math.max(0,st.pallid.bloodDoses+clamp(Math.round(safeNumber(body.delta,0)),-20,20));log.push(`Доз крови: ${st.pallid.bloodDoses}`);
        } else if(action==='pallid-memory'){
          if(st.species!=='pallid'||st.pallid.memoryUsed)throw Object.assign(new Error('Память прожитых жизней уже использована или недоступна.'),{statusCode:409});st.pallid.memoryUsed=true;setSpeciesEffect(st,'pallidMemory','Память прожитых жизней','Преимущество на одну связанную проверку Памяти или Эрудиции.');log.push('активирована Память прожитых жизней');
        } else if(action==='pallid-jump'){
          assertTokenMovementUnlocked(token);if(st.species!=='pallid'||!st.pallid.transformed)throw Object.assign(new Error('Прыжок Вечного доступен только в Форме Вечного.'),{statusCode:409});const point={x:safeNumber(body.x,token.x),y:safeNumber(body.y,token.y)},distance=distanceFeet(scene,token,point);if(distance>60.01)throw Object.assign(new Error(`Прыжок Вечного ограничен 60 футами; выбрано ${distance.toFixed(1)}.`),{statusCode:409});if(scene.settings.enforceWalls&&movementBlocked(scene,token,token,point))throw Object.assign(new Error('Путь прыжка перекрыт препятствием.'),{statusCode:409});const blocker=tokenPositionBlocker(scene,token,point);if(blocker)throw Object.assign(new Error(`Клетка занята токеном «${blocker.name}».`),{statusCode:409});spend(1);token.x=point.x;token.y=point.y;log.push(`Прыжок Вечного на ${distance.toFixed(1)} фт`);
        } else if(action==='werewolf-transform'||action==='werewolf-involuntary'){
          const involuntary=action==='werewolf-involuntary';startWerewolfForm(involuntary,{reason:'непроизвольная трансформация'});log.push(involuntary?'непроизвольная Звериная форма':'принята Звериная форма');
        } else if(action==='werewolf-lunar-check'){
          if(st.species!=='werewolf'||st.werewolf.transformed)throw Object.assign(new Error('Лунная проверка проводится до трансформации.'),{statusCode:409});preCheck=runSkillAgainstDifficulty(token,'Воля',8,{combatContext:true});if(!preCheck)throw Object.assign(new Error('Не удалось провести проверку Воли.'),{statusCode:409});preRoll=storeSpeciesCheckRoll(scene,token,preCheck,body,`${token.name}: лунная проверка Воли`,{reactionSafe:true});if(preRoll){preRoll=await awaitCheckRollResolution(scene,preRoll);syncCheckFromReactionRoll(preCheck,preRoll);}if(preCheck.success)log.push('лунная проверка Воли успешна: трансформация не началась');else{startWerewolfForm(true,{reason:'лунная трансформация',beastHindrance:true});log.push('лунная проверка провалена: началась непроизвольная трансформация');}
        } else if(action==='werewolf-emotion-check'){
          if(st.species!=='werewolf'||st.werewolf.transformed)throw Object.assign(new Error('Проверка сильной эмоции проводится в человеческой форме.'),{statusCode:409});preCheck=runSkillAgainstDifficulty(token,'Воля',6,{combatContext:true});if(!preCheck)throw Object.assign(new Error('Не удалось провести проверку Воли.'),{statusCode:409});preRoll=storeSpeciesCheckRoll(scene,token,preCheck,body,`${token.name}: сильная эмоция`,{reactionSafe:true});if(preRoll){preRoll=await awaitCheckRollResolution(scene,preRoll);syncCheckFromReactionRoll(preCheck,preRoll);}if(preCheck.success)log.push('сильная эмоция преодолена: трансформация не началась');else{startWerewolfForm(true,{reason:'трансформация из-за сильной эмоции'});log.push('проверка Воли провалена: началась непроизвольная трансформация');}
        } else if(action==='werewolf-end'){
          if(st.species!=='werewolf'||!st.werewolf.transformed)throw Object.assign(new Error('Звериная форма не активна.'),{statusCode:409});if(st.werewolf.beastState!=='calm')throw Object.assign(new Error('Нельзя прекратить форму во время Звериного срыва.'),{statusCode:409});spend(1);st.werewolf.transformed=false;st.werewolf.aftereffects=true;st.werewolf.hideUsed=false;removeSpeciesEffect(st,'werewolfForm');removeSpeciesEffect(st,'werewolfBeast');const moraleResolved=await resolveScalarRoll(scene,token,{body,label:`${token.name}: последствия трансформации — потеря морали`,sides:6,kind:'werewolf-aftereffect',purpose:'morale-loss'}),moraleLoss=moraleResolved.total;speciesManualFormulas.push(moraleResolved.roll?.formula||'Последствия трансформации — потеря морали: 1d6');st.morale ||= {current:0,max:0};st.morale.current=Math.max(0,safeNumber(st.morale.current,0)-moraleLoss);setSpeciesEffect(st,'werewolfAftereffects','Последствия трансформации',`Мораль −${moraleLoss}; −1 к Физической силе, Акробатике и Выдержке до короткого привала.`);log.push(`Звериная форма прекращена; мораль −${moraleLoss}`);
        } else if(action==='werewolf-check'){
          {const resolved=await resolveWerewolfBeastCheck(scene,token,cleanText(body.reason||'ручная проверка Зверя',180),body);beastCheck=resolved.check;beastRoll=resolved.roll;}if(!beastCheck)throw Object.assign(new Error('Проверка Зверя сейчас недоступна.'),{statusCode:409});log.push(`Проверка Зверя: ${beastCheck.success?'контроль восстановлен':beastStateLabel(beastCheck.state)}`);
        } else if(action==='werewolf-rest'){
          st.werewolf.aftereffects=false;removeSpeciesEffect(st,'werewolfAftereffects');log.push('последствия трансформации сняты коротким привалом');
        } else if(action==='werewolf-hunt'){
          assertTokenMovementUnlocked(token);if(st.species!=='werewolf'||!st.werewolf.transformed)throw Object.assign(new Error('Охота на раненого доступна только в Звериной форме.'),{statusCode:409});const target=findToken(scene,cleanId(body.targetTokenId,null));if(!target||target.id===token.id)throw Object.assign(new Error('Выберите раненую живую цель.'),{statusCode:409});const condition=target.kind==='character'?(linkedCharacter(target)?.state?.wounds||{}):(linkedNpc(target)?.wounds||{}),wounded=Boolean(condition.medium||condition.serious||condition.critical);if(!wounded)throw Object.assign(new Error('Охота на раненого требует хотя бы Среднего, Серьёзного или Критического ранения.'),{statusCode:409});const dist=distanceFeet(scene,token,target);if(dist>30.01)throw Object.assign(new Error('Цель дальше 30 футов.'),{statusCode:409});const actions=tokenActions(token);if(actions.werewolfHunt)throw Object.assign(new Error('Охота на раненого уже использована в этом ходу.'),{statusCode:409});const move=Math.min(10,dist),ratio=dist?move/dist:0,desired={x:token.x+(target.x-token.x)*ratio,y:token.y+(target.y-token.y)*ratio},next=farthestFreeTokenPoint(scene,token,{x:token.x,y:token.y},desired);if(scene.settings.enforceWalls&&movementBlocked(scene,token,token,next))throw Object.assign(new Error('Путь к цели перекрыт.'),{statusCode:409});const actualMove=distanceFeet(scene,token,next);token.x=next.x;token.y=next.y;actions.werewolfHunt={roundAction:true,at:nowIso()};log.push(`Охота на раненого: перемещение на ${actualMove.toFixed(1)} фт`);
        } else if(action==='roko-extend'){
          if(st.species!=='rokurokubi'||st.rokurokubi.neckExtended)throw Object.assign(new Error('Шея уже расправлена или действие недоступно.'),{statusCode:409});const needsGearPreparation=Boolean(st.equipment?.armor&&!st.rokurokubi.neckGearReady),neckCost=1+(needsGearPreparation?1:0);spend(neckCost);if(needsGearPreparation)st.rokurokubi.neckGearReady=true;st.rokurokubi.neckExtended=true;st.rokurokubi.headPoint={x:token.x,y:token.y};setSpeciesEffect(st,'rokurokubiNeck','Расправленная шея','+10 футов Скорости; дистанционное восприятие; естественные атаки на 10 футов; руки заняты.');log.push(`шея расправлена${needsGearPreparation?' после подготовки экипировки':''} (${neckCost} ОД)`);
        } else if(action==='roko-retract'){
          if(st.species!=='rokurokubi'||!st.rokurokubi.neckExtended)throw Object.assign(new Error('Шея уже втянута.'),{statusCode:409});if(st.rokurokubi.wrappedTargetTokenId)throw Object.assign(new Error('Нельзя втянуть шею, пока цель Обвита.'),{statusCode:409});spend(1);st.rokurokubi.neckExtended=false;st.rokurokubi.headPoint=null;removeSpeciesEffect(st,'rokurokubiNeck');log.push('шея втянута');
        } else if(action==='roko-head'){
          if(st.species!=='rokurokubi'||!st.rokurokubi.neckExtended)throw Object.assign(new Error('Сначала расправьте шею.'),{statusCode:409});const point={x:safeNumber(body.x,token.x),y:safeNumber(body.y,token.y)},dist=distanceFeet(scene,token,point);if(dist>10.01)throw Object.assign(new Error(`Голова может находиться не дальше 10 футов от тела; выбрано ${dist.toFixed(1)}.`),{statusCode:409});st.rokurokubi.headPoint=point;log.push('положение головы изменено');
        } else if(action==='roko-perception'){
          if(st.species!=='rokurokubi'||!st.rokurokubi.neckExtended)throw Object.assign(new Error('Дистанционное восприятие требует расправленной шеи.'),{statusCode:409});setSpeciesEffect(st,'rokurokubiPerception','Дистанционное восприятие','Преимущество на Бдительность, если помогает вынесенная вперёд голова.',{roundAction:true});log.push('активировано дистанционное восприятие');
        } else if(action==='roko-release'){
          if(st.species!=='rokurokubi'||!st.rokurokubi.wrappedTargetTokenId)throw Object.assign(new Error('Нет Обвитой цели.'),{statusCode:409});clearWrappedTarget(scene,token);log.push('Обвитая цель отпущена');
        } else if(action==='roko-pull'){
          if(st.species!=='rokurokubi'||!st.rokurokubi.wrappedTargetTokenId)throw Object.assign(new Error('Нет Обвитой цели.'),{statusCode:409});const target=findToken(scene,st.rokurokubi.wrappedTargetTokenId);if(!target)throw Object.assign(new Error('Обвитая цель не найдена.'),{statusCode:404});spend(1);const dist=distanceFeet(scene,target,token),move=Math.min(5,Math.max(0,dist-meleeReachFeet(scene,target,token))),ratio=dist?move/dist:0,desired={x:target.x+(token.x-target.x)*ratio,y:target.y+(token.y-target.y)*ratio},next=farthestFreeTokenPoint(scene,target,{x:target.x,y:target.y},desired);if(scene.settings.enforceWalls&&movementBlocked(scene,target,target,next))throw Object.assign(new Error('Цель нельзя протянуть через препятствие.'),{statusCode:409});const actualMove=distanceFeet(scene,target,next);target.x=next.x;target.y=next.y;log.push(`цель подтянута на ${actualMove.toFixed(1)} фт`);
        } else if(action==='escape-wrap'){
          const wrapper=findToken(scene,speciesConditions(token)?.wrappedByTokenId);if(!wrapper)throw Object.assign(new Error('Токен не Обвит.'),{statusCode:409});spend(1);
          const chooseBest=(candidate,names)=>names.map(name=>({...opposedSkillProfile(candidate,name,true),skillName:name})).filter(item=>item.sides).sort((a,b)=>safeNumber(b.bonus,0)-safeNumber(a.bonus,0))[0]||null,actorBest=chooseBest(token,['Физическая сила','Акробатика']),wrapperBest=chooseBest(wrapper,['Физическая сила','Акробатика']);
          const opposed=await resolveOpposedSkillCheck(scene,token,wrapper,actorBest?.skillName||'Физическая сила',wrapperBest?.skillName||'Физическая сила',body,`${token.name}: Освобождение от Обвития`,{source:actorBest,target:wrapperBest});if(opposed?.roll?.formula)speciesManualFormulas.push(opposed.roll.formula);
          if(opposed?.success){clearWrappedTarget(scene,wrapper);log.push(`освобождение успешно: ${opposed.source?.total||0} против ${opposed.target?.total||0}`);}else log.push(`освобождение провалено: ${opposed?.source?.total||0} против ${opposed?.target?.total||0}`);
        } else if(action==='resolve-lycanthropy'){
          const conditions=speciesConditionHost(token);if(!conditions?.lycanthropyExposure)throw Object.assign(new Error('Нет ожидающей проверки заражения ликантропией.'),{statusCode:409});infectionCheck=runSkillAgainstDifficulty(token,'Иммунитет',8,{combatContext:false});if(!infectionCheck)throw Object.assign(new Error('Не удалось провести проверку Иммунитета.'),{statusCode:409});infectionRoll=storeSpeciesCheckRoll(scene,token,infectionCheck,body,`${token.name}: Иммунитет против ликантропии`,{reactionSafe:true});if(infectionRoll){infectionRoll=await awaitCheckRollResolution(scene,infectionRoll);syncCheckFromReactionRoll(infectionCheck,infectionRoll);}delete conditions.lycanthropyExposure;if(infectionCheck.success){delete conditions.lycanthropyInfected;removeSpeciesEffect(st,'lycanthropyInfection');log.push('Иммунитет выдержал: заражения нет');}else{conditions.lycanthropyInfected=true;setSpeciesEffect(st,'lycanthropyInfection','Заражение ликантропией','Проверка Иммунитета провалена. Дальнейшее получение ликантропии разрешается по правилам кампании и решению Мастера.');log.push('проверка Иммунитета провалена: заражение ликантропией');}
        } else if(action==='stand'){
          if(!speciesConditions(token)?.prone)throw Object.assign(new Error('Токен не сбит с ног.'),{statusCode:409});spend(1);delete speciesConditionHost(token).prone;log.push('персонаж поднялся');
        } else if(action==='species-scene-reset'){
          st.pallid.memoryUsed=false;st.werewolf.seriousTriggerUsed=false;st.werewolf.hideUsed=false;st.rokurokubi.ambushUsed=false;
          removeSpeciesEffect(st,'pallidMemory');removeSpeciesEffect(st,'rokurokubiPerception');
          if(st.species==='pallid'&&st.pallid.transformed){st.pallid.transformed=false;removeSpeciesEffect(st,'pallidForm');log.push('Форма Вечного завершена');}
          if(st.species==='werewolf'&&st.werewolf.transformed&&st.werewolf.beastState==='calm'){
            st.werewolf.transformed=false;st.werewolf.aftereffects=true;removeSpeciesEffect(st,'werewolfForm');const moraleResolved=await resolveScalarRoll(scene,token,{body,label:`${token.name}: конец сцены — последствия трансформации`,sides:6,kind:'werewolf-aftereffect',purpose:'morale-loss'}),moraleLoss=moraleResolved.total;speciesManualFormulas.push(moraleResolved.roll?.formula||'Конец сцены — последствия трансформации, потеря морали: 1d6');st.morale ||= {current:0,max:0};st.morale.current=Math.max(0,safeNumber(st.morale.current,0)-moraleLoss);setSpeciesEffect(st,'werewolfAftereffects','Последствия трансформации',`Мораль −${moraleLoss}; −1 к Физической силе, Акробатике и Выдержке до короткого привала.`);log.push(`Звериная форма завершена; мораль −${moraleLoss}`);
          } else if(st.species==='werewolf'&&st.werewolf.transformed){log.push('Звериная форма не завершена: персонаж всё ещё в срыве');}
          log.push('сценовые способности вида восстановлены');
        } else throw Object.assign(new Error('Неизвестное действие вида.'),{statusCode:400});
      } catch(error){sendJson(res,error.statusCode||400,{ok:false,error:error.message});return true;}
      const speciesRolls=[];if(preRoll)speciesRolls.push(preRoll);if(beastCheck&&!beastRoll){beastRoll=storeSpeciesCheckRoll(scene,token,beastCheck,body,`${token.name}: Проверка Зверя`,{reactionSafe:true});if(beastRoll){beastRoll=await awaitCheckRollResolution(scene,beastRoll);syncCheckFromReactionRoll(beastCheck,beastRoll);}applyWerewolfBeastCheckOutcome(token,beastCheck);}if(beastRoll)speciesRolls.push(beastRoll);if(infectionRoll)speciesRolls.push(infectionRoll);
      const speciesOdAfter=tokenOd(token)?.current??null;character.revision=Math.max(0,Number(character.revision||0))+1;character.updatedAt=nowIso();token.updatedAt=nowIso();scene.updatedAt=nowIso();await persistCampaign();await persist();if(broadcastCharacterUpdated)broadcastCharacterUpdated(character,body.clientId);broadcast('battlemap-replaced',body.clientId,{reason:'species-action',sceneId:scene.id,tokenId:token.id});const odSuffix=speciesOdBefore!==null&&speciesOdAfter!==null&&speciesOdBefore!==speciesOdAfter?` (ОД ${speciesOdBefore}→${speciesOdAfter})`:'';const text=`${token.name}: ${log.join('; ')||action}${odSuffix}.`;const speciesFormulas=[...speciesManualFormulas,...speciesRolls.filter(Boolean).map(item=>item.formula).filter(Boolean)];const entry=appendTableLog({type:speciesFormulas.length?'roll':'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text,sceneId:scene.id,tokenId:token.id,meta:{formulas:speciesFormulas}});broadcastTableLog(entry);sendJson(res,200,{ok:true,action,odBefore:speciesOdBefore,odAfter:speciesOdAfter,character:clone(character),token:publicToken(token,isMasterAuthorized(req,requestUrl,body)?'master':'player',cleanId(body.clientId,null)),beastCheck,preCheck,infectionCheck,rolls:speciesRolls.filter(Boolean),entry});return true;
    }


    if(pathname==='/api/battlemap/aberration-action'&&req.method==='POST'){
      const body=await readJsonBody(req),scene=findScene(cleanId(body.sceneId,null)),token=findToken(scene,cleanId(body.tokenId,null));if(!scene||!token){sendJson(res,404,{ok:false,error:'Токен не найден.'});return true;}if(!canControlToken(token,req,requestUrl,body)){sendJson(res,403,{ok:false,error:state.masterPause?.active?'Игра на мастерской паузе.':'Вы не управляете токеном.'});return true;}try{assertTokenCanAct(token);}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}const gift=cleanName(body.gift,'',80),rank=clamp(Math.round(safeNumber(body.rank,1)),1,3),known=giftRankForToken(token,gift);if(!known||rank>known){sendJson(res,409,{ok:false,error:'Этот Дар или выбранный ранг недоступен персонажу.'});return true;}const character=linkedCharacter(token),st=character.state,rt=ensureAberrationRuntime(st);if(rt.lockedUntilDay){sendJson(res,409,{ok:false,error:'Дар заблокирован до конца дня из-за Срыва.'});return true;}const mode=cleanId(body.mode,'default');let target=findToken(scene,cleanId(body.targetTokenId,null));const point=body.point&&Number.isFinite(Number(body.point.x))?{x:safeNumber(body.point.x,token.x),y:safeNumber(body.point.y,token.y)}:null;let result={gift,rank,mode},log=[],aberrationFormulas=[];
      try{
        if(gift==='Сверхинтеллект'){if(rank===1){rt.nextCheckAdvantage=true;log.push('преимущество на следующую проверку после вывода мастера');}else if(rank===2){rt.superPlanActive=true;if(target?.kind==='character')ensureAberrationRuntime(linkedCharacter(target)?.state||{}).superPlanActive=true;log.push('план: +1к4 к проверкам персонажа и союзника до конца сцены');}else{rt.undoRequest={at:nowIso(),text:cleanText(body.text||'Отменить последнее действие',300)};state.masterPause={active:true,reason:`${token.name}: Сверхинтеллект III — запрос отката`,activatedAt:nowIso()};log.push('запрос отката передан мастеру, включена пауза');}}
        else if(gift==='Телекинез'){
          if(rank===3&&mode==='block'){rt.cancelNextRangedAttack=true;log.push('следующая дальнобойная атака будет заблокирована');}
          else if(rank===3&&point){
            const pending=[];
            for(const other of scene.tokens||[]){if(!['character','npc'].includes(other.kind)||distanceFeet(scene,point,other)>10)continue;pending.push({other,promise:resolveAberrationAttack(scene,token,other,{body,label:'Телекинез III',kind:'aberration-attack',sides:8,damage:3,damageTag:'medium'})});}
            const resolved=await Promise.all(pending.map(async item=>({other:item.other,...await item.promise}))),victims=[];result.attacks=[];
            for(const item of resolved){const finalAttack=item.attack;let teleDamage=null;if(finalAttack.hit){teleDamage=await applyDamageToTarget(scene,item.other,{...body,damage:3,damageTag:'medium',sourceText:'Телекинез III'},{persist:false,recordHistory:false,role:'system'});victims.push(item.other.name);}aberrationFormulas.push(...journalRollFormulas(finalAttack.formula,teleDamage));result.attacks.push({attack:finalAttack,roll:item.roll,damageResult:teleDamage});}
            broadcastProjectileEffect(scene.id,{kind:'anaxion',from:token,to:point,durationMs:500,hit:true,radius:10},body.clientId);result.victims=victims;log.push(`импульс по зоне 10 фт${victims.length?`: ${victims.join(', ')}`:''}`);
          }else{
            if(!target)throw Object.assign(new Error('Нужно выбрать цель.'),{statusCode:400});const sides=rank===1?6:8,damage=rank===1?2:3,range=rank===1?30:40;if(distanceFeet(scene,token,target)>range)throw Object.assign(new Error(`Цель дальше ${range} фт.`),{statusCode:409});
            const resolved=await resolveAberrationAttack(scene,token,target,{body,label:`Телекинез ${rank}`,kind:'aberration-attack',sides,damage,damageTag:'medium'}),finalAttack=resolved.attack;result.attack=finalAttack;result.attackRoll=resolved.roll;let teleDamage=null;
            if(finalAttack.hit){if(mode==='prone')speciesConditionHost(target).prone=true;else if(mode==='push')pushTokenAway(token,target,rank===1?5:10,scene);else if(mode==='disarm'){const h=actionHost(target);if(h)h._battlemapDisarmed=true;}else teleDamage=await applyDamageToTarget(scene,target,{...body,damage,damageTag:'medium',sourceText:`Телекинез ${rank}`},{persist:false,recordHistory:false,role:'system'});}
            aberrationFormulas.push(...journalRollFormulas(finalAttack.formula,teleDamage));broadcastProjectileEffect(scene.id,{kind:'anaxion',from:token,to:target,durationMs:420,hit:finalAttack.hit},body.clientId);log.push(`атака ${finalAttack.total} против МЗ ${finalAttack.targetMz} — ${finalAttack.hit?'успех':'промах'}`);
          }
        }
        else if(gift==='Краткосрочная невидимость'){if(rank===1){rt.invisibleUntargetable=true;rt.invisibleUntilTurnEnd=true;}else if(rank===2){rt.invisibleHindrance=true;rt.invisibleFirstAttackAdvantage=true;rt.invisibleRounds=2;}else{rt.invisibleHindrance=true;rt.invisibleRounds=3;if(target?.kind==='character'&&contactDistanceFeet(scene,token,target)<=Math.max(5,meleeReachFeet(scene,token,target))+.01){const t=ensureAberrationRuntime(linkedCharacter(target)?.state||{});t.invisibleHindrance=true;t.invisibleRounds=3;}}log.push(`невидимость ранга ${rank}`);}
        else if(gift==='Предвидение'){if(rank===1){rt.nextCheckAdvantage=true;rt.cancelNextHindrance=true;log.push('готовность к ближайшей опасности');}else if(rank===2){throw Object.assign(new Error('Предвидение II теперь применяется после броска через кнопку рядом со счётчиком результата.'),{statusCode:409});}else if(mode==='cancel-hit'){target=target||token;if(target.kind==='character')ensureAberrationRuntime(linkedCharacter(target)?.state||{}).cancelNextHit=true;log.push(`следующее попадание по ${target.name} будет отменено`);}else{rt.futureQuestion=cleanText(body.text||'Каковы ближайшие последствия?',400);state.masterPause={active:true,reason:`${token.name}: вопрос Предвидения III`,activatedAt:nowIso()};log.push('вопрос мастеру записан, включена пауза');}}
        else if(gift==='Манипуляция сознанием'||gift==='Гипноз'){
          if(!target)throw Object.assign(new Error('Нужно выбрать цель.'),{statusCode:400});
          if(rank===1){const h=actionHost(target);if(h){h.activeEffects=Array.isArray(h.activeEffects)?h.activeEffects:[];h.activeEffects.unshift({id:makeId('effect'),title:gift,desc:gift==='Гипноз'?'Честный ответ на один безопасный вопрос после спокойного разговора.':'Мастер сообщает текущий эмоциональный мотив цели.',source:`aberration:${gift}`,createdAt:nowIso()});}log.push('создан мастерский социальный маркер');}
          else{
            const skill=gift==='Гипноз'?'Убеждение':'Интуиция',opposed=await resolveOpposedSkillCheck(scene,token,target,skill,'Воля',body,`${token.name}: ${gift} — ${skill} против Воли`);result.opposed=opposed;if(opposed?.roll?.formula)aberrationFormulas.push(opposed.roll.formula);
            if(opposed?.success){const h=actionHost(target),a=tokenActions(target);if(rank===2&&gift==='Гипноз'&&mode==='lose-ap'){const info=tokenOd(target);if(info)info.host[info.currentKey]=Math.max(0,info.current-1);}else if(rank===3&&mode==='lose-turn'){if(h)h._battlemapSkipNextTurn=true;}else a.mindCommand={roundAction:true,command:cleanText(body.text||mode||'Короткая команда',300),source:gift};}
            log.push(`${skill} ${opposed?.source?.total||0} против Воли ${opposed?.target?.total||0} — ${opposed?.success?'успех':'провал'}`);
          }
        }
        else if(gift==='Невероятная сила'){const d=rank===1?{bonus:2,feet:10}:rank===2?{bonus:3,feet:15}:{bonus:4,feet:20};tokenActions(token).aberrantStrength={mode:mode==='push'?'push':mode==='area'&&rank===3?'area':'damage',bonus:d.bonus,feet:d.feet,roundAction:false};log.push('эффект будет применён к следующей атаке ближнего боя');}
        else if(gift==='Невероятная ловкость'){const a=tokenActions(token);if(rank===1)a.aberrantSafeMoveFeet=20;else if(rank===2){a.aberrantMzBonus=2;rt.dodgeNextAttack=true;}else{a.aberrantSafeMoveFeet=30;a.aberrantMzBonus=3;refundTokenOd(token,1);}log.push(`ловкость ранга ${rank} активирована`);}
        else if(gift==='Парение'){const a=tokenActions(token);a.aberrantHoverLevel=rank===3?2:1;a.aberrantMzBonus=rank===3?2:0;rt.hoverRounds=rank===1?1:rank===2?3:1;rt.hoverLevel=a.aberrantHoverLevel;log.push(rank===3?'воздушный рывок':'парение над поверхностью');}
        const tension=await resolveAberrationTension(scene,token,rank,body);result.tension=tension;if(tension?.willRoll){result.willRoll=tension.willRoll;if(result.willRoll?.formula)aberrationFormulas.push(result.willRoll.formula);}if(tension?.breakdown){aberrationFormulas.push('Таблица Срыва Дара: 1d6');if(tension.breakdown.moraleLoss!==undefined)aberrationFormulas.push('Потеря морали от Срыва: 1d8');log.push(`Срыв Дара: ${tension.breakdown.roll} на 1к6`);}
      }catch(error){sendJson(res,error.statusCode||400,{ok:false,error:error.message});return true;}
      character.revision=Math.max(0,Number(character.revision||0))+1;character.updatedAt=nowIso();token.updatedAt=nowIso();scene.updatedAt=nowIso();await persistCampaign();await persist();if(broadcastCharacterUpdated)broadcastCharacterUpdated(character,body.clientId);broadcast('battlemap-replaced',body.clientId,{reason:'aberration-action',sceneId:scene.id,tokenId:token.id});const entry=appendTableLog({type:aberrationFormulas.length?'roll':'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,token.name),text:`${token.name}: ${gift} ${rank} — ${log.join('; ')}.`,sceneId:scene.id,tokenId:token.id,meta:{formulas:aberrationFormulas}});broadcastTableLog(entry);sendJson(res,200,{ok:true,result,entry,token:publicToken(token,isMasterAuthorized(req,requestUrl,body)?'master':'player',cleanId(body.clientId,null)),masterPause:clone(state.masterPause)});return true;
    }

    if (pathname === '/api/battlemap/melee' && req.method === 'POST') {
      const body=await readJsonBody(req),key=requestKey(body,'melee');const cached=cachedRequest(key);if(cached){sendJson(res,200,cached);return true;}
      const scene=findScene(cleanId(body.sceneId,null)),attacker=findToken(scene,cleanId(body.attackerTokenId,null)),target=findToken(scene,cleanId(body.targetTokenId,null));
      if(!scene||!attacker||!target){sendJson(res,404,{ok:false,error:'Атакующий или цель не найдены.'});return true;}if(!canControlToken(attacker,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете атакующим токеном.'});return true;}
      if(state.combat?.active&&!isMasterAuthorized(req,requestUrl,body)&&!isCurrentCombatToken(scene,attacker)){sendJson(res,409,{ok:false,error:'Сейчас ход другого участника.'});return true;}
      let attack=makeMeleeRoll(body,scene,attacker,target);let roll=combatRollRecord(scene,attacker,attack,'Ближний бой');roll=await awaitAttackRollResolution(scene,roll);attack=roll.battlemapAttack;
      await spendAttackResources(attacker,attack,body,isMasterAuthorized(req,requestUrl,body));delete tokenActions(attacker).charge;
      const onHitPenalty=Math.round(safeNumber(attack.featureEffects?.attack?.onHitTargetAttackPenalty,0));if(attack.hit&&onHitPenalty){armFeatureEffect(target,'nextAttack',{sourceKey:attack.featureEffects.attack.sourceKey,sourceName:`${attack.featureEffects.attack.sourceName}: эффект попадания`,sourceKind:attack.featureEffects.attack.sourceKind,flat:onHitPenalty});attack.conditionalReasons=Array.isArray(attack.conditionalReasons)?attack.conditionalReasons:[];attack.conditionalReasons.push(`${attack.featureEffects.attack.sourceName}: цель получает ${onHitPenalty} к своей следующей атаке.`);}
      let damageResult=null,shockResult=null,shockRoll=null;
      if(attack.hit&&attack.flags?.shock){shockResult=fixedDifficultySkillCheck(target,'Стойкость',attack.attackerTotal);if(shockResult){shockRoll=storeSpeciesCheckRoll(scene,target,shockResult,body,`${target.name}: Стойкость против Шока`,{reactionSafe:true});if(shockRoll){shockRoll=await awaitCheckRollResolution(scene,shockRoll);syncCheckFromReactionRoll(shockResult,shockRoll);shockResult.formula=shockRoll.formula;shockResult.rollRecord=shockRoll;}if(!shockResult.success){const host=actionHost(target);if(host)host._battlemapShockDebt=Math.max(1,Math.round(safeNumber(host._battlemapShockDebt,0))+1);}}}
      else if(attack.hit&&body.autoApplyDamage){damageResult=await applyDamageToTarget(scene,target,{...body,damage:attack.damage,damageTag:attack.damageTag,...attack.flags,melee:true,stun:Boolean(attack.flags?.stun),sourceText:`${attack.weapon?.profile||''} ${attack.weapon?.description||''}`},{persist:false,recordHistory:true,role:isMasterAuthorized(req,requestUrl,body)?'master':'player'});}
      const speciesNotes=await applySpeciesPostAttack(scene,attacker,target,attack,damageResult,body);
      if(attack.hit&&attack.flags?.aberrantStrength){const power=attack.flags.aberrantStrength;if(power.mode==='push'){pushTokenAway(attacker,target,power.feet||10,scene);speciesNotes.push(`цель отброшена на ${power.feet||10} фт`);}else if(power.mode==='area'){for(const other of scene.tokens||[]){if(other.id===attacker.id||other.id===target.id||!tokensHostile(attacker,other)||distanceFeet(scene,target,other)>10)continue;await applyDamageToTarget(scene,other,{...body,damage:3,damageTag:'medium',sourceText:'Невероятная сила III'},{persist:false,recordHistory:false,role:'system'});}speciesNotes.push('удар по зоне 10 фт');}delete tokenActions(attacker).aberrantStrength;}
      if(attack.counterAvailable)pendingMeleeCounters.set(attack.id,{attack:clone(attack),defenderTokenId:target.id,attackerTokenId:attacker.id,createdAt:Date.now(),expiresAt:Date.now()+120000});
      const damageText=damageResult?(damageResult.blocked?' Урон заблокирован.':` Ранения: ${(damageResult.applied||[]).join(', ')||'нет'}${damageResult.moraleLoss?`; мораль −${damageResult.moraleLoss}`:''}.`):'';const shockText=shockResult?` Шок: ${shockResult.success?'цель выдержала':'провал Стойкости, −1 ОД в следующий ход'}.`:'';const tableEntry=appendTableLog({type:'roll',actorId:attack.actorId,actorName:attack.actorName,text:`${attack.label}: ${attackTotalBreakdown(attack,true)} против ${attack.defenderTotal} — ${attack.hit?'попадание':attack.tie?'ничья':'защитник победил'}.${damageText}${shockText}`,visibility:attack.visibility,sceneId:scene.id,tokenId:attacker.id,meta:{attackId:attack.id,formulas:journalRollFormulas(attack.formula,damageResult,shockResult)}});await persistCampaign();await persist();broadcastTableLog(tableEntry);broadcastAudioEffect(scene.id,weaponSoundKey(attack.weapon,{melee:true,unarmed:Boolean(attack.flags?.unarmed)}),{tokenId:attacker.id,x:attacker.x,y:attacker.y,targetTokenId:target.id},body.clientId);const payload={ok:true,attack,roll,entry:tableEntry,damageResult,shockResult,shockRoll,speciesNotes};storeRequest(key,payload);sendJson(res,201,payload);return true;
    }

    if (pathname === '/api/battlemap/melee-counter' && req.method === 'POST') {
      const body=await readJsonBody(req),key=requestKey(body,'counter');const cached=cachedRequest(key);if(cached){sendJson(res,200,cached);return true;}
      const pending=pendingMeleeCounters.get(cleanId(body.attackId,null));if(!pending||Date.now()-pending.createdAt>120000){sendJson(res,409,{ok:false,error:'Возможность Встречного удара уже истекла.'});return true;}
      const scene=findScene(pending.attack.sceneId),defender=findToken(scene,pending.defenderTokenId),attacker=findToken(scene,pending.attackerTokenId);if(!scene||!defender||!attacker){sendJson(res,404,{ok:false,error:'Участники ближнего боя не найдены.'});return true;}
      if(!canControlToken(defender,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Встречный удар может провести защитник или мастер.'});return true;}try{assertTokenCanAct(defender,{attack:true});}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}
      const weapon=meleeWeaponForToken(defender,body.weaponId,{forCounter:true}),counterCost=/Тяж[её]лое двуручное|Громоздк/i.test(`${weapon.profile||''} ${weapon.description||''}`)?2:1;spendCounterCost(scene,defender,counterCost);
      const attack=makeMeleeCounter(body,scene,pending,defender,attacker);let damageResult=null;if(body.autoApplyDamage!==false)damageResult=await applyDamageToTarget(scene,attacker,{...body,damage:attack.damage,damageTag:attack.damageTag,...attack.flags,melee:true,sourceText:`${attack.weapon?.profile||''} ${attack.weapon?.description||''}`},{persist:false,recordHistory:true,role:isMasterAuthorized(req,requestUrl,body)?'master':'player'});pendingMeleeCounters.delete(pending.attack.id);const campaign=getCampaign(),roll={id:attack.id,at:attack.at,actorId:attack.actorId,actorName:attack.actorName,characterId:linkedCharacter(defender)?.id||null,characterName:defender.name,formula:attack.formula,label:attack.label,rolls:[],modifier:0,total:0,visibility:'public',kind:'formula',skillName:'Встречный удар',battlemapAttack:attack};campaign.diceLog.push(roll);const tableEntry=appendTableLog({type:'roll',actorId:attack.actorId,actorName:attack.actorName,text:attack.label,sceneId:scene.id,tokenId:defender.id,meta:{attackId:attack.id,formulas:journalRollFormulas(attack.formula,damageResult)}});await persistCampaign();await persist();if(broadcastDice)broadcastDice(roll);broadcastTableLog(tableEntry);broadcastAudioEffect(scene.id,weaponSoundKey(attack.weapon,{melee:true,unarmed:Boolean(attack.flags?.unarmed)}),{tokenId:defender.id,x:defender.x,y:defender.y,targetTokenId:attacker.id},body.clientId);const payload={ok:true,attack,roll,entry:tableEntry,damageResult};storeRequest(key,payload);sendJson(res,201,payload);return true;
    }

    if (pathname === '/api/battlemap/shotgun-cone' && req.method === 'POST') {
      const body=await readJsonBody(req),key=requestKey(body,'shotgun-cone');const cached=cachedRequest(key);if(cached){sendJson(res,200,cached);return true;}
      const scene=findScene(cleanId(body.sceneId,null)),attacker=findToken(scene,cleanId(body.attackerTokenId,null));
      if(!scene||!attacker){sendJson(res,404,{ok:false,error:'Сцена или атакующий не найдены.'});return true;}
      if(!canControlToken(attacker,req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Вы не управляете атакующим токеном.'});return true;}
      if(state.combat?.active&&!isMasterAuthorized(req,requestUrl,body)&&!isCurrentCombatToken(scene,attacker)){sendJson(res,409,{ok:false,error:'Сейчас ход другого участника.'});return true;}
      try{assertTokenCanAct(attacker,{attack:true});}catch(error){sendJson(res,error.statusCode||409,{ok:false,error:error.message});return true;}
      const weapon=weaponsForToken(attacker).find(item=>item.id===body.weaponId||item.slot===body.weaponId||item.name===body.weaponId),profile=shotgunProfileForWeapon(weapon);
      if(!weapon||!profile||profile.coneDepthFeet<=0){sendJson(res,409,{ok:false,error:'У выбранного профиля нет конусной атаки.'});return true;}
      if(weapon.unavailable){sendJson(res,409,{ok:false,error:weapon.unavailableReason||'Оружие недоступно из-за травмы.'});return true;}
      assertHeavyWeaponReady(attacker,weapon);
      const origin=speciesCombatPoint(attacker),rawAim={x:clamp(safeNumber(body.x,origin.x),0,scene.mapWidth),y:clamp(safeNumber(body.y,origin.y),0,scene.mapHeight)},dx=rawAim.x-origin.x,dy=rawAim.y-origin.y,len=Math.hypot(dx,dy);
      if(len<1){sendJson(res,400,{ok:false,error:'Укажите направление выстрела дальше от токена.'});return true;}
      const cursorFeet=distanceFeet(scene,origin,rawAim),depthFeet=clamp(safeNumber(body.coneDepthFeet,cursorFeet),1,Math.min(30,profile.coneDepthFeet,safeNumber(weapon.range,30))),depthPx=feetToScenePixels(scene,depthFeet),widthFeet=Math.max(5,profile.coneWidthFeet),widthPx=feetToScenePixels(scene,widthFeet);
      const endpoint={x:clamp(origin.x+dx/len*depthPx,0,scene.mapWidth),y:clamp(origin.y+dy/len*depthPx,0,scene.mapHeight)},aim=endpoint;
      const masterShot=isMasterAuthorized(req,requestUrl,body),directMeleeIds=new Set(hostileMeleeOpponents(scene,attacker,origin).map(item=>item.id)),attackerRadius=tokenFootprintHalfSize(scene,attacker);
      const candidates=(scene.tokens||[]).filter(target=>{
        if(target.id===attacker.id||!['character','npc','vehicle'].includes(target.kind)||target.defeated||(target.hidden&&!masterShot))return false;
        if(attacker.kind==='npc'&&['character','npc'].includes(target.kind)&&isStealthed(target))return false;
        const targetPoint=speciesCombatPoint(target),targetRadius=tokenFootprintHalfSize(scene,target),meleeLateralBonus=directMeleeIds.has(target.id)?attackerRadius*.40:0;
        return pointInsideShotgunConePixels(origin,aim,targetPoint,depthPx,widthPx,targetRadius,meleeLateralBonus)&&!contactBlockedByWall(scene,origin,targetPoint);
      });
      if(!candidates.length){sendJson(res,409,{ok:false,error:'В выбранном конусе нет доступных целей. Выстрел отменён без траты ОД.',emptyCone:true});return true;}
      const requestedPrimary=cleanId(body.primaryTargetTokenId,null);let primary=requestedPrimary?candidates.find(target=>target.id===requestedPrimary):null;
      if(!primary&&candidates.length===1)primary=candidates[0];
      if(candidates.length>1&&!primary){sendJson(res,409,{ok:false,error:'Выберите основную цель дробовой атаки.',requiresPrimaryTarget:true,targets:candidates.map(target=>({id:target.id,name:target.name}))});return true;}
      // Подготовленные эффекты расходуются только после окончательного подтверждения
      // основной цели, чтобы окно выбора не съедало Специализацию/Доктрину.
      const narrativeAttack=consumeNarrative(attacker,'attack'),featureAttack=consumeFeatureEffect(attacker,'nextAttack'),featureAttackRoll=featureEffectRoll(featureAttack);
      const attacks=[];
      for(const target of candidates){
        const isPrimary=Boolean(primary&&target.id===primary.id),distance=distanceFeet(scene,origin,speciesCombatPoint(target));
        const attack=makeAttackRoll({...body,targetTokenId:target.id,weaponId:weapon.id||weapon.slot||weapon.name,shotMode:'normal',specialMode:null,targetMz:null,autoApplyDamage:true},scene,attacker,target,{allowShotgunSingle:true,shotgunCone:true,ignoreTargetMelee:!hostileMeleeOpponents(scene,attacker,origin).some(item=>item.id===target.id),label:`${attacker.name}: ${weapon.name} (конус) → ${target.name}`,narrativeAttack,narrativeDefense:consumeNarrative(target,'defense'),featureAttack,featureAttackRoll});
        attack.kind='shotgun-cone';attack.coneFeet=depthFeet;attack.coneDepthFeet=depthFeet;attack.coneWidthFeet=widthFeet;attack.primaryTarget=isPrimary;
        let reduction=0;if(!isPrimary&&distance>10)reduction+=1;if(profile.spreader)reduction+=1;
        if(reduction){attack.damage=Math.max(1,attack.damage-reduction);attack.conditionalReasons.push(`${profile.spreader?'Расширенный раструб'+(!isPrimary&&distance>10?' и ':'') : ''}${!isPrimary&&distance>10?'вторичная цель 11–30 фт':''}: урон −${reduction}`);}
        attacks.push({attack,target,isPrimary,distance:Math.round(distance*10)/10});
      }
      const costAttack={id:makeId('shotgun-cost'),sceneId:scene.id,weapon,odCost:Math.max(0,safeNumber(weapon.odCost,2)),obCost:0};
      await spendAttackResources(attacker,costAttack,{...body,spendResources:body.spendResources!==false},isMasterAuthorized(req,requestUrl,body));finalizeWeaponModAttack(attacker,weapon,attacks[0]?.attack||null);markHeavyWeaponFired(attacker,weapon);
      const results=[];
      for(const item of attacks){let attack=item.attack;const target=item.target,targetRuntime=actionHost(target)?._battlemapAberration;if(attack.hit&&targetRuntime?.cancelNextRangedAttack){attack.hit=false;attack.forcedMissReason='Телекинез III: дальнобойная атака заблокирована';attack.damageTargetTokenId=null;attack.damageTargetName=null;attack.conditionalReasons.push(attack.forcedMissReason);delete targetRuntime.cancelNextRangedAttack;}let roll=combatRollRecord(scene,attacker,attack,'Конус дробовика');roll=await awaitAttackRollResolution(scene,roll);attack=roll.battlemapAttack;finalizePristrelkaAttack(scene,attacker,target,attack);const damageTarget=attack.damageTargetTokenId?findToken(scene,attack.damageTargetTokenId):null;let damageResult=null;if(damageTarget)damageResult=damageTarget.kind==='vehicle'?await applyDamageToVehicle(scene,damageTarget,{...body,damage:attack.damage,damageTag:attack.damageTag,...attack.flags},{persistNow:false}):await applyDamageToTarget(scene,damageTarget,{...body,damage:attack.damage,damageTag:attack.damageTag,...attack.flags,sourceText:`${attack.weapon?.profile||''} ${attack.weapon?.description||''}`},{persist:false,recordHistory:true,role:isMasterAuthorized(req,requestUrl,body)?'master':'player'});results.push({attack,roll,damageResult,distance:item.distance,isPrimary:item.isPrimary});}
      broadcastProjectileEffect(scene.id,{id:`shotgun-${costAttack.id}`,kind:'shotgun',from:origin,to:endpoint,durationMs:clamp(300+depthFeet*8,360,620),hit:results.some(item=>item.attack.hit),label:weapon.name},body.clientId);broadcastAudioEffect(scene.id,weaponSoundKey(weapon),{tokenId:attacker.id,x:attacker.x,y:attacker.y},body.clientId);
      const hits=results.filter(item=>item.attack.hit).length,formulas=results.flatMap(item=>journalRollFormulas(`${item.attack.targetName}: ${item.attack.formula}`,item.damageResult)),entry=appendTableLog({type:'roll',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),text:`${attacker.name}: ${weapon.name}, конус ${depthFeet}×${widthFeet} фт — целей ${candidates.length}, попаданий ${hits}${primary?`; основная цель: ${primary.name}`:''}.`,sceneId:scene.id,tokenId:attacker.id,meta:{formulas}});
      await persistCampaign();await persist();broadcastTableLog(entry);broadcast('battlemap-replaced',body.clientId,{reason:'shotgun-cone',sceneId:scene.id});
      const payload={ok:true,weapon,cone:{from:origin,to:endpoint,depthFeet,widthFeet},primaryTargetTokenId:primary?.id||null,results,entry};storeRequest(key,payload);sendJson(res,201,payload);return true;
    }

    const attackPath = pathname === '/api/battlemap/attack';
    if (attackPath && req.method === 'POST') {
      const body = await readJsonBody(req);
      const key = requestKey(body, 'attack');
      const cached = cachedRequest(key);
      if (cached) { sendJson(res, 200, cached); return true; }
      const scene = findScene(cleanId(body.sceneId, null));
      const attacker = findToken(scene, cleanId(body.attackerTokenId, null));
      const target = findToken(scene, cleanId(body.targetTokenId, null));
      if (!scene || !attacker || !target) { sendJson(res, 404, { ok: false, error: 'Атакующий или цель не найдены.' }); return true; }
      if (!canControlToken(attacker, req, requestUrl, body)) { sendJson(res, 403, { ok: false, error: 'Вы не управляете атакующим токеном.' }); return true; }
      if (state.combat?.active && !isMasterAuthorized(req, requestUrl, body) && !isCurrentCombatToken(scene, attacker)) { sendJson(res, 409, { ok: false, error: 'Сейчас ход другого участника.' }); return true; }
      if(target.kind==='interactive'){
        try{const payload=await resolveInteractiveShot(scene,attacker,target,body,isMasterAuthorized(req,requestUrl,body));storeRequest(key,payload);sendJson(res,201,payload);}catch(error){sendJson(res,error.statusCode||400,{ok:false,error:error.message||'Не удалось выстрелить по интерактивному объекту.'});}return true;
      }
      let attack = makeAttackRoll(body, scene, attacker, target);
      const attackOriginHidden=stealthHidesTokenLocation(attacker,scene);if(attackOriginHidden)attack.visibility='master';
      const targetRuntime=actionHost(target)?._battlemapAberration;if(attack.hit&&targetRuntime?.cancelNextRangedAttack){attack.hit=false;attack.forcedMissReason='Телекинез III: дальнобойная атака полностью заблокирована';attack.damageTargetTokenId=null;attack.damageTargetName=null;attack.conditionalReasons.push(attack.forcedMissReason);delete targetRuntime.cancelNextRangedAttack;}
      let roll=combatRollRecord(scene,attacker,attack,'Атака');roll=await awaitAttackRollResolution(scene,roll);attack=roll.battlemapAttack;
      await spendAttackResources(attacker, attack, body, isMasterAuthorized(req, requestUrl, body));finalizePristrelkaAttack(scene,attacker,target,attack);finalizeWeaponModAttack(attacker,attack.weapon,attack);markHeavyWeaponFired(attacker,attack.weapon);markSpecialRangedFired(attacker,attack.weapon);
      const sniperPosition=attack.shotMode==='measured'?recordMeasuredShotPosition(scene,attacker):null;if(sniperPosition)attack.sniperPosition=sniperPosition;
      if(!stealthHidesTokenLocation(attacker,scene))broadcastProjectileEffect(scene.id,{id:attack.id,kind:projectileKindForWeapon(attack.weapon),from:speciesCombatPoint(attacker),to:targetPointForProjectile(scene,attack,target),durationMs:projectileDurationMs(scene,speciesCombatPoint(attacker),targetPointForProjectile(scene,attack,target),attack.weapon),hit:Boolean(attack.damageTargetTokenId),label:attack.weapon?.name},body.clientId);
      const damageTarget=attack.damageTargetTokenId?findToken(scene,attack.damageTargetTokenId):null;
      let damageResult=null;if(damageTarget&&body.autoApplyDamage){damageResult=damageTarget.kind==='vehicle'?await applyDamageToVehicle(scene,damageTarget,{...body,damage:attack.damage*(weaponIsHeavy(attack.weapon)?2:1),damageTag:attack.damageTag,...attack.flags},{persistNow:false}):await applyDamageToTarget(scene,damageTarget,{...body,damage:attack.damage,damageTag:attack.damageTag,...attack.flags,sourceText:`${attack.weapon?.profile||''} ${attack.weapon?.description||''}`},{persist:false,recordHistory:true,role:isMasterAuthorized(req,requestUrl,body)?'master':'player'});}
      const onHitEffect=damageTarget&&body.autoApplyDamage?await applyDirectWeaponOnHitEffects(scene,attacker,damageTarget,attack.weapon,body):null;
      const damageText=damageResult?(damageResult.blocked?' Урон заблокирован.':` Ранения: ${(damageResult.applied||[]).join(', ')||'нет'}${damageResult.moraleLoss?`; мораль −${damageResult.moraleLoss}`:''}.`):'';const onHitText=onHitEffect?.moraleLoss?` Анаксионный импульс: мораль −${onHitEffect.moraleLoss}.`:onHitEffect?.burningZone?' Создана зона горения.':'';const redirectText=attack.missRedirectTargetName?` Промах по основной цели; попадание в ${attack.missRedirectTargetName}.`:'';const hiddenAttackerLocation=stealthHidesTokenLocation(attacker,scene),tableEntry=appendTableLog({type:'roll',actorId:attack.actorId,actorName:hiddenAttackerLocation?'Скрытый стрелок':attack.actorName,text:hiddenAttackerLocation?`Скрытый стрелок совершает дальнобойную атаку: ${attackTotalBreakdown(attack,false)} против МЗ ${attack.targetMz} — ${attack.hit?'попадание':'промах'}.${damageText}${onHitText}`:`${attack.label}: ${attackTotalBreakdown(attack,false)} против МЗ ${attack.targetMz} — ${attack.hit?'попадание':'промах'}.${redirectText}${damageText}${onHitText}`,visibility:attack.visibility,sceneId:scene.id,tokenId:hiddenAttackerLocation?null:attacker.id,meta:{attackId:attack.id,formulas:[...journalRollFormulas(attack.formula,damageResult),...(onHitEffect?.moraleRoll?[`Анаксионный пистолет: 1d4 морали = ${onHitEffect.moraleRoll.total}`]:[])]}});
      broadcastTableLog(tableEntry);
      broadcastAudioEffect(scene.id, weaponSoundKey(attack.weapon), hiddenAttackerLocation?{}:{ tokenId:attacker.id, x:attacker.x, y:attacker.y, targetTokenId:target.id }, body.clientId);
      const counterSniperReactions=attack.shotMode==='measured'?await resolveCounterSniperReactions(scene,attacker,attack,body):[];
      await persistCampaign(); await persist();
      const payload = { ok: true, attack, roll, entry: tableEntry, damageResult, onHitEffect, counterSniperReactions };
      storeRequest(key, payload);
      sendJson(res, 201, payload);
      return true;
    }

    if (pathname === '/api/battlemap/apply-damage' && req.method === 'POST') {
      const body=await readJsonBody(req);if(!isMasterAuthorized(req,requestUrl,body)){sendJson(res,403,{ok:false,error:'Применять ранения может только мастер.'});return true;}
      const scene=findScene(cleanId(body.sceneId,null)),target=findToken(scene,cleanId(body.targetTokenId,null));if(!scene||!target){sendJson(res,404,{ok:false,error:'Цель не найдена.'});return true;}
      const result=target.kind==='vehicle'?await applyDamageToVehicle(scene,target,body,{persistNow:true}):await applyDamageToTarget(scene,target,body,{persist:true,recordHistory:true,role:'master'});const damageFormulas=journalRollFormulas(null,result);const entry=appendTableLog({type:damageFormulas.length?'roll':'action',actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Мастер'),text:`${target.name}: применён урон ${Math.max(0,Math.round(safeNumber(body.damage,0)))}${result.moraleLoss?`, мораль -${result.moraleLoss}`:''}.`,sceneId:scene.id,tokenId:target.id,meta:{formulas:damageFormulas}});await persist();broadcastTableLog(entry);sendJson(res,200,{...result,entry});return true;
    }

    sendJson(res, 404, { ok: false, error: 'API карты не найден.' });
    return true;
  }

  return {
    ensureDataFiles,
    handleApi,
    viewFor,
    broadcast,
    snapshotPayload,
    restorePayload,
    assetFileFromUrl,
    getState: () => state,
    _test: { hiddenTokenName, tokenNameForMode, publicTableLogEntry, automaticCoverInfo, tokenAdjacentToCover, coverDistanceFromPoint, tokenOd, spendTokenOd, resetTurnResources, tokenBaseMz, tokenNaturalMz, tokenDefensiveMzBonus, shortRangeNaturalMz, rifleProfileForWeapon, combatMzBreakdown, grenadeThrowRange, bestGrenadeThrowSkill, grenadeThrowDifficulty, tokenSeesThrownGrenade, grenadeDiveCandidate, applyGrenadeReactionChoice, resolveThrownGrenadeReactions, normalizeWeatherLayer, normalizeDrawing, normalizeTriggerZone, weaponIsMelee, weaponIsRanged, weaponIsHeavy, weaponIsExplosiveHeavy, hostileMeleeOpponents, tokenEngagedInMelee, makeAttackRoll, makeMeleeRoll, resolveMovementReactions, trajectoryClearsCover, coverIntersectionT, runSkillAgainstTarget, damageCoverObject, applyTriggerZoneEffect, shotgunProfileForWeapon, weaponIsShotgun, decorateShotgunWeapon, canonicalTraumaName, canonicalTraumaVariant, traumaItemVariant, traumaItemProsthesis, injurySkillPenalty, traumaBlocksWeapon, hasLostLimb, addCanonicalTrauma, recalculateCharacterAfterTrauma, pointInsideConePixels, pointInsideShotgunConePixels, interactiveChainCandidates, aiInteractiveBlastCluster, aiInteractiveDamageAt, aiInteractiveOpportunity, aiInferRole, aiResolvedRole, aiMoralePosture, aiSquadKey, aiSquadBoard, aiRememberSquadVisible, aiTargetThreatScore, aiSelectTarget, aiLatestRemembered, aiPreferredDistance, aiPositionScore, aiBestTacticalPosition, aiRetreatPoint, aiShouldRepositionBeforeAttack, gmTokenStatsSnapshot, applyGmTokenStats, nearestFreeTokenPoint, clearCombatOnlyActions, tokenSpeedFeet, scanCoreAudioLibrary, loadSharedAudioLibrary, audioView, combinedAudioLibrary, normalizeAiControl, normalizeEffectZone, processEffectZonesAtTurnStart, effectCanReachToken, gasProtectionForToken, viewerCanSeePoint, resolvePushChain, runOpposedPushCheck, runOpposedSkillCheck, makeOpposedCheckFromProfiles, fixedDifficultySkillCheck, makeAberrationAttack, makeMapSkillRoll, checkRollReactionOptions, recalculateReactionCheck, applyAttackRerollReaction, attackRollPotentialReaction, awaitAttackRollResolution, resolveForcedCheckZones, projectileWallImpact, explosionBlockedByWall, aiFindRoute, tokenGroupRelation, tokensHostile, runNpcAiTurn, aiAreaWeaponAttack, aiWeaponZone, weaponSoundKey, sniperRuntime, stealthRuntime, isStealthed, isCombatStealthed, sniperPositionAtToken, recordMeasuredShotPosition, counterSniperObservation, counterSniperSmokeBlock, publicSniperRuntime, resolveCounterSniperReactions, resolveCombatStealthCheck, resolveStealthAtTurnEnd, mainTraitLevel, mainTraitFeatureEntries, activeMainTraitMark, activeExperiencedLook, activePristrelka, finalizePristrelkaAttack, expirePristrelkaAtOwnerTurnEnd, consumeMarkedFirstAttackAdvantage, bonusTraitLevel, bonusTraitFeatureEntries, bonusTraitStatus, fortuneState, spendFortune, studiedTargetState, studiedTargetToken, addCharacterWoundWithBonus, fixedMoraleLossWithBonusTraits, spendThoughtfulReactionCost, normalizeVehicleWeapon, normalizeVehicle, vehicleSeatRole, npcWeaponProficiencyCategory, npcCombatBonus, npcCatalogWeapon, mountedWeaponForGunner, mountedWeaponState, mountedWeaponNeedsReload, weaponSupportsSuppression, weaponSupportsBarrage, weaponSupportsAnaxion, weaponSupportsDual, fallbackWeaponsForCharacter, canonicalCombatWeaponProfile, canonicalBaseObCost, weaponSpecialRangedKind, specialRangedHitBonus, specialRangedAttackOdCost, specialRangedReloadCost, specialRangedState, specialRangedAmmoName, specialRangedAmmoCount, assertSpecialRangedAmmo, consumeSpecialRangedAmmo, markSpecialRangedFired, drawSpecialRangedWeapon, reloadSpecialRangedWeapon, conditionalWeaponModifier, canonicalArmorProfileAlias, normalizedArmorItem, normalizedNpcArmor, armorSpeedPenaltyForProfile, armorSkillModifierForProfile, armorContextualSkillOptions, armorSeriousPenaltyForProfile, equippedArmorForCharacter, armorResolutionForCharacter, armorResolutionForNpc, applyDirectWeaponOnHitEffects, weaponModIds, weaponHasMod, weaponModThresholdBonus, weaponModAttackEffects, weaponModStateSummary, weaponModCoolingBypass, weaponModInstabilityPenalty, heavyReloadCost, finalizeWeaponModAttack, advanceWeaponModTurnState },
    syncCharacterOwner: async (characterId, ownerId) => {
      const id = cleanId(characterId, null);
      const nextOwner = cleanId(ownerId, null);
      if (!id || !state) return 0;
      let changed = 0;
      for (const scene of state.scenes || []) {
        for (const token of scene.tokens || []) {
          if (token?.kind !== 'character' || token.refId !== id) continue;
          if ((token.ownerId || null) === nextOwner) continue;
          token.ownerId = nextOwner;
          token.updatedAt = nowIso();
          scene.updatedAt = nowIso();
          changed += 1;
        }
      }
      if (changed) await persist();
      return changed;
    },
    getStatus: () => ({ scenes: state?.scenes?.length || 0, activeSceneId: state?.activeSceneId || null, combatActive:Boolean(state?.combat?.active), combatSceneId:state?.combat?.sceneId||null, mapsFolder: MAP_DIR, tokensFolder: TOKEN_DIR, audioFolder: AUDIO_DIR, sharedAudioFolder:SHARED_AUDIO_DIR, coreAudioFolder:CORE_AUDIO_DIR, dataDir: currentDataDir }),
    get paths() { return { BATTLEMAP_FILE, MAP_DIR, TOKEN_DIR, AUDIO_DIR, SHARED_AUDIO_DIR, CORE_AUDIO_DIR, dataDir: currentDataDir }; },
    flush: () => flushPendingPersist(),
    switchStorage: async nextDataDir => { await flushPendingPersist(); configureStorage(nextDataDir); ensureDataFiles(); return state; }
  };
}

module.exports = { createBattlemapModule };
