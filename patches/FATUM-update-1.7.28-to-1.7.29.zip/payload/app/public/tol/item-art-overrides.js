/* ToL external item artwork overrides shared with Classic Battlemap.
   Keep this file lightweight: Battlemap already owns the Classic art catalog;
   ToL only supplies stable profile/profileId overrides. */
(function(){
  const profileIcons = {
    "Кинжал": "/assets/items/profiles/tol/weapons/kinzhal.webp",
    "Короткий клинок": "/assets/items/profiles/tol/weapons/korotkiy_klinok.webp",
    "Меч": "/assets/items/profiles/tol/weapons/mech.webp",
    "Длинный меч": "/assets/items/profiles/tol/weapons/dlinnyy_mech.webp",
    "Одноручный топор": "/assets/items/profiles/tol/weapons/odnoruchnyy_topor.webp",
    "Секира": "/assets/items/profiles/tol/weapons/sekira.webp",
    "Булава": "/assets/items/profiles/tol/weapons/bulava.webp",
    "Боевой молот": "/assets/items/profiles/tol/weapons/boevoy_molot.webp",
    "Кистень": "/assets/items/profiles/tol/weapons/kisten.webp",
    "Копьё": "/assets/items/profiles/tol/weapons/kopyo.webp",
    "Короткое копьё": "/assets/items/profiles/tol/weapons/korotkoe_kopyo.webp",
    "Глефа": "/assets/items/profiles/tol/weapons/glefa.webp",
    "Алебарда": "/assets/items/profiles/tol/weapons/alebarda.webp",
    "Двуручный меч": "/assets/items/profiles/tol/weapons/dvuruchnyy_mech.webp",
    "Короткий лук": "/assets/items/profiles/tol/weapons/korotkiy_luk.webp",
    "Охотничий лук": "/assets/items/profiles/tol/weapons/okhotnichiy_luk.webp",
    "Длинный лук": "/assets/items/profiles/tol/weapons/dlinnyy_luk.webp",
    "Тяжёлый боевой лук": "/assets/items/profiles/tol/weapons/tyazhelyy_boevoy_luk.webp",
    "Ручной арбалет": "/assets/items/profiles/tol/weapons/ruchnoy_arbalet.webp",
    "Лёгкий арбалет": "/assets/items/profiles/tol/weapons/lyogkiy_arbalet.webp",
    "Военный арбалет": "/assets/items/profiles/tol/weapons/voennyy_arbalet.webp",
    "Тяжёлый арбалет": "/assets/items/profiles/tol/weapons/tyazhelyy_arbalet.webp",
    "Револьверный пистолет": "/assets/items/profiles/tol/weapons/revolvernyy_pistolet.webp",
    "Тяжёлый револьверный пистолет": "/assets/items/profiles/tol/weapons/tyazhelyy_revolvernyy_pistolet.webp",
    "Револьверное ружьё": "/assets/items/profiles/tol/weapons/revolvernoe_ruzhyo.webp",
    "Тяжёлое револьверное ружьё": "/assets/items/profiles/tol/weapons/tyazheloe_revolvernoe_ruzhyo.webp"
  };
  const profileIds = {
    "weapons-1":"Кинжал", "weapons-2":"Короткий клинок", "weapons-3":"Меч", "weapons-4":"Длинный меч",
    "weapons-5":"Одноручный топор", "weapons-6":"Секира", "weapons-7":"Булава", "weapons-8":"Боевой молот",
    "weapons-9":"Кистень", "weapons-10":"Копьё", "weapons-11":"Короткое копьё", "weapons-12":"Глефа",
    "weapons-13":"Алебарда", "weapons-14":"Двуручный меч", "weapons-22":"Короткий лук", "weapons-23":"Охотничий лук",
    "weapons-24":"Длинный лук", "weapons-25":"Тяжёлый боевой лук", "weapons-26":"Ручной арбалет", "weapons-27":"Лёгкий арбалет",
    "weapons-28":"Военный арбалет", "weapons-29":"Тяжёлый арбалет", "weapons-30":"Револьверный пистолет",
    "weapons-31":"Тяжёлый револьверный пистолет", "weapons-32":"Револьверное ружьё", "weapons-33":"Тяжёлое револьверное ружьё"
  };
  window.FATUM_TOL_ITEM_ART_OVERRIDES = { profileIcons, profileIds };
})();
