'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function normalizedRelativePublicPath(urlPath) {
  let text = String(urlPath || '/').split('?')[0].split('#')[0].replace(/\\/g, '/');
  try { text = decodeURIComponent(text); } catch {}
  text = text.replace(/^\/+/, '');
  if (!text) return 'index.html';
  const parts = text.split('/');
  if (parts.some(part => !part || part === '.' || part === '..' || part.includes('\0'))) return null;
  return parts.join('/');
}

function safeJoin(root, relativePath) {
  const base = path.resolve(root);
  const target = path.resolve(base, relativePath);
  if (target !== base && !target.startsWith(`${base}${path.sep}`)) return null;
  return target;
}

function fileExists(filePath) {
  try { return fs.statSync(filePath).isFile(); } catch { return false; }
}

function isOverrideEligible(relativePath) {
  const normalized = String(relativePath || '').replace(/\\/g, '/').toLowerCase();
  return normalized.startsWith('assets/items/') ||
    normalized.startsWith('assets/audio/core/') ||
    normalized.startsWith('assets/cursors/');
}

// FATUM 1.7.19: hashes of historical *official* item art that may have
// been auto-captured into overrides by older updater versions.  When an
// override matches one of these hashes it is not a real user customization,
// so the refreshed built-in asset is allowed through.  Any different hash
// remains a genuine user override and keeps priority.
const LEGACY_OFFICIAL_ITEM_HASHES = new Map([
  ['assets/items/profiles-stable/consumables/batareya.webp', new Set(['6d0503c37f5af11964aca63d3710e45c9126f28313a93cfbb84d2f929a919221'])],
  ['assets/items/profiles-stable/consumables/bolty.webp', new Set(['75e2853622b7c5726d348977125ef6436c65994f53e2403714b2f28c5e60e905'])],
  ['assets/items/profiles-stable/consumables/dymovaya-shashka.webp', new Set(['04bd66dd2169387440ef064460f03cda6a03c7e4c691429606b0dddf0774d2fa'])],
  ['assets/items/profiles-stable/consumables/himicheskiy-neytralizator.webp', new Set(['00def9c2fe6bd7d553e2032c31fe9f76682f1f8840eef8fe00fee179cc8f7de7'])],
  ['assets/items/profiles-stable/consumables/mikrofonnyy-signalizator.webp', new Set(['68ec36e61f722e07850619a09354988703f09463a4301407d90213e0aeb04a3a', '934c3cb2a1d9521aae3500f914d6817096fc5fd7d1ff2457ec38ffaf7f9fdae6'])],
  ['assets/items/profiles-stable/consumables/podavitel-radiochastot.webp', new Set(['917aa940e3a43fed4c991894643e9ce2ef910f3bef585df283605705a5ad3f8d', 'fd268ab8b9436d5f00a833ca605be009618d767549f3984010fae1094ec16ee3'])],
  ['assets/items/profiles-stable/consumables/portativnyy-generator.webp', new Set(['d71f6bcb02347080330451166f1ce0e2c7cdae4a124d6f10661fbf0920a724fb', 'b0069eb02b44bca552dbb549b4eef494656d2ea9a4a0c27e4e2f772a852352bc'])],
  ['assets/items/profiles-stable/consumables/skript-detonator.webp', new Set(['9c927c597a54e34e2406063313aec0bb5d076fd5e589fe7d7129debd5fffa9df'])],
  ['assets/items/profiles-stable/consumables/strely.webp', new Set(['71765b454a6ae1a1b3dd54b0c29de8dd2a9dccb671db97cdad7d4ee751ae385d'])],
  ['assets/items/profiles/consumables/item-1233afc7.webp', new Set(['68ec36e61f722e07850619a09354988703f09463a4301407d90213e0aeb04a3a', '934c3cb2a1d9521aae3500f914d6817096fc5fd7d1ff2457ec38ffaf7f9fdae6'])],
  ['assets/items/profiles/consumables/item-61e61c6f.webp', new Set(['d71f6bcb02347080330451166f1ce0e2c7cdae4a124d6f10661fbf0920a724fb', 'b0069eb02b44bca552dbb549b4eef494656d2ea9a4a0c27e4e2f772a852352bc'])],
  ['assets/items/profiles/consumables/item-638ee485.webp', new Set(['917aa940e3a43fed4c991894643e9ce2ef910f3bef585df283605705a5ad3f8d', 'fd268ab8b9436d5f00a833ca605be009618d767549f3984010fae1094ec16ee3'])],
  ['assets/items/profiles/consumables/item-88460b76.webp', new Set(['9c927c597a54e34e2406063313aec0bb5d076fd5e589fe7d7129debd5fffa9df'])],
  ['assets/items/profiles/consumables/item-8ac4c194.webp', new Set(['04bd66dd2169387440ef064460f03cda6a03c7e4c691429606b0dddf0774d2fa'])],
  ['assets/items/profiles/consumables/item-96a4c39f.webp', new Set(['6d0503c37f5af11964aca63d3710e45c9126f28313a93cfbb84d2f929a919221'])],
  ['assets/items/profiles/consumables/item-97aea1d8.webp', new Set(['75e2853622b7c5726d348977125ef6436c65994f53e2403714b2f28c5e60e905'])],
  ['assets/items/profiles/consumables/item-e7a240e1.webp', new Set(['71765b454a6ae1a1b3dd54b0c29de8dd2a9dccb671db97cdad7d4ee751ae385d'])],
  ['assets/items/profiles/consumables/item-ecb618a7.webp', new Set(['00def9c2fe6bd7d553e2032c31fe9f76682f1f8840eef8fe00fee179cc8f7de7'])],
]);

function sha256File(filePath) { return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex'); }
function isHistoricalOfficialOverride(relativePath, filePath) {
  const hashes = LEGACY_OFFICIAL_ITEM_HASHES.get(String(relativePath || '').replace(/\\/g, '/').toLowerCase());
  if (!hashes || !hashes.size) return false;
  try { return hashes.has(sha256File(filePath)); } catch { return false; }
}

function resolvePublicAsset(publicDir, overridePublicDir, urlPath, fallback = 'index.html') {
  const relative = normalizedRelativePublicPath(urlPath === '/' ? fallback : urlPath);
  if (!relative) return null;

  if (overridePublicDir && isOverrideEligible(relative)) {
    const override = safeJoin(overridePublicDir, relative);
    if (override && fileExists(override) && !isHistoricalOfficialOverride(relative, override)) return { file: override, overridden: true, relative };
  }

  const normal = safeJoin(publicDir, relative);
  return normal ? { file: normal, overridden: false, relative } : null;
}

module.exports = {
  normalizedRelativePublicPath,
  safeJoin,
  isOverrideEligible,
  resolvePublicAsset
};
