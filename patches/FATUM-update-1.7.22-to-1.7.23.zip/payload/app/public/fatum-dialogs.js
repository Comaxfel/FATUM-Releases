(() => {
  'use strict';

  const queue = [];
  let active = false;
  let sequence = 0;

  function desktopBridge() {
    return globalThis.fatumDesktop && globalThis.fatumDesktop.isDesktop ? globalThis.fatumDesktop : null;
  }

  function installDesktopMessageDialogs() {
    const bridge = desktopBridge();
    if (!bridge) return;
    if (typeof bridge.alertSync === 'function') {
      window.alert = message => { bridge.alertSync(String(message ?? ''), document.title || 'FATUM'); };
    }
    if (typeof bridge.confirmSync === 'function') {
      window.confirm = message => Boolean(bridge.confirmSync(String(message ?? ''), document.title || 'FATUM'));
    }
  }

  function ensureUi() {
    if (document.getElementById('fatum-dialog-layer')) return;
    const style = document.createElement('style');
    style.id = 'fatum-dialog-style';
    style.textContent = `
      #fatum-dialog-layer{position:fixed;inset:0;z-index:2147483646;display:grid;place-items:center;padding:24px;background:rgba(2,4,8,.72);backdrop-filter:blur(7px);font-family:Inter,Segoe UI,Arial,sans-serif}
      #fatum-dialog-layer[hidden]{display:none!important}
      .fatum-dialog-box{width:min(560px,calc(100vw - 32px));max-height:calc(100vh - 48px);overflow:auto;border:1px solid rgba(170,187,222,.28);border-radius:18px;background:linear-gradient(155deg,#171c27,#0d1119 72%);box-shadow:0 26px 80px rgba(0,0,0,.62),inset 0 1px rgba(255,255,255,.04);color:#edf2ff;padding:22px}
      .fatum-dialog-kicker{margin:0 0 7px;color:#8fa8db;font-size:11px;font-weight:800;letter-spacing:.14em;text-transform:uppercase}
      .fatum-dialog-title{margin:0 0 10px;font-size:22px;line-height:1.2}
      .fatum-dialog-message{margin:0 0 16px;color:#c6cede;font-size:14px;line-height:1.55;white-space:pre-wrap;overflow-wrap:anywhere}
      .fatum-dialog-input{box-sizing:border-box;width:100%;min-height:44px;border:1px solid rgba(163,181,218,.34);border-radius:10px;background:#090d14;color:#f6f8ff;padding:10px 12px;font:inherit;outline:none}
      .fatum-dialog-input:focus{border-color:#8aa9ed;box-shadow:0 0 0 3px rgba(99,137,219,.18)}
      textarea.fatum-dialog-input{min-height:110px;resize:vertical}
      .fatum-dialog-choices{display:grid;gap:9px;margin-top:8px}.fatum-dialog-choices[hidden]{display:none!important}.fatum-dialog-choice{display:block;width:100%;text-align:left;border:1px solid rgba(159,178,216,.28);border-radius:11px;background:#131b28;color:#edf2ff;padding:11px 13px;cursor:pointer}.fatum-dialog-choice:hover{border-color:#7899e1;background:#1b2740}.fatum-dialog-choice strong{display:block;font-size:14px}.fatum-dialog-choice small{display:block;margin-top:3px;color:#aebad0;line-height:1.35}
      .fatum-dialog-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:18px}
      .fatum-dialog-button{min-width:104px;border:1px solid rgba(159,178,216,.28);border-radius:10px;background:#1a2231;color:#e9efff;padding:10px 16px;font-weight:750;cursor:pointer}
      .fatum-dialog-button:hover{filter:brightness(1.13)}
      .fatum-dialog-button.primary{border-color:#7094e6;background:linear-gradient(#6288df,#456bc5);color:white}
      @media(max-width:640px){#fatum-dialog-layer{padding:12px}.fatum-dialog-box{padding:18px;border-radius:14px}.fatum-dialog-actions{display:grid;grid-template-columns:1fr 1fr}.fatum-dialog-button{min-width:0}}
    `;
    document.head.appendChild(style);

    const layer = document.createElement('div');
    layer.id = 'fatum-dialog-layer';
    layer.hidden = true;
    layer.setAttribute('role', 'presentation');
    layer.innerHTML = `
      <form class="fatum-dialog-box" id="fatum-dialog-form" role="dialog" aria-modal="true" aria-labelledby="fatum-dialog-title">
        <p class="fatum-dialog-kicker">FATUM</p>
        <h2 class="fatum-dialog-title" id="fatum-dialog-title">Введите значение</h2>
        <p class="fatum-dialog-message" id="fatum-dialog-message"></p>
        <div class="fatum-dialog-choices" id="fatum-dialog-choices" hidden></div>
        <input class="fatum-dialog-input" id="fatum-dialog-input" autocomplete="off">
        <div class="fatum-dialog-actions" id="fatum-dialog-actions">
          <button class="fatum-dialog-button" id="fatum-dialog-cancel" type="button">Отмена</button>
          <button class="fatum-dialog-button primary" id="fatum-dialog-ok" type="submit">Подтвердить</button>
        </div>
      </form>`;
    document.body.appendChild(layer);

    const cancel = () => finish(null);
    layer.querySelector('#fatum-dialog-cancel').addEventListener('click', cancel);
    layer.addEventListener('mousedown', event => { if (event.target === layer) cancel(); });
    layer.querySelector('#fatum-dialog-form').addEventListener('submit', event => {
      event.preventDefault();
      const input = layer.querySelector('#fatum-dialog-input');
      if(input.hidden)return;
      finish(input.value);
    });
    document.addEventListener('keydown', event => {
      if (layer.hidden || event.key !== 'Escape') return;
      event.preventDefault();
      cancel();
    }, true);
  }

  function renderCurrent() {
    if (active || !queue.length) return;
    ensureUi();
    active = true;
    const item = queue[0];
    const layer = document.getElementById('fatum-dialog-layer');
    const title = layer.querySelector('#fatum-dialog-title');
    const message = layer.querySelector('#fatum-dialog-message');
    const oldInput = layer.querySelector('#fatum-dialog-input');
    const multiline = Boolean(item.options.multiline);
    let input = oldInput;
    if ((multiline && oldInput.tagName !== 'TEXTAREA') || (!multiline && oldInput.tagName !== 'INPUT')) {
      input = document.createElement(multiline ? 'textarea' : 'input');
      input.id = 'fatum-dialog-input';
      input.className = 'fatum-dialog-input';
      input.autocomplete = 'off';
      oldInput.replaceWith(input);
    }
    title.textContent = item.options.title || 'Введите значение';
    message.textContent = item.message;
    message.hidden = !item.message;
    const choices = Array.isArray(item.options.choices) ? item.options.choices : [];
    const choicesBox=layer.querySelector('#fatum-dialog-choices'),actions=layer.querySelector('#fatum-dialog-actions');
    choicesBox.replaceChildren();
    if(choices.length){
      input.hidden=true;actions.hidden=true;choicesBox.hidden=false;
      for(const choice of choices){const button=document.createElement('button');button.type='button';button.className='fatum-dialog-choice';const strong=document.createElement('strong');strong.textContent=choice.label;button.appendChild(strong);if(choice.description){const small=document.createElement('small');small.textContent=choice.description;button.appendChild(small);}button.addEventListener('click',()=>finish(choice.value));choicesBox.appendChild(button);}
    }else{
      input.hidden=false;actions.hidden=false;choicesBox.hidden=true;input.value = item.defaultValue;input.placeholder = item.options.placeholder || '';if (item.options.maxLength) input.maxLength = Number(item.options.maxLength);else input.removeAttribute('maxlength');layer.querySelector('#fatum-dialog-ok').textContent = item.options.okText || 'Подтвердить';layer.querySelector('#fatum-dialog-cancel').textContent = item.options.cancelText || 'Отмена';
    }
    layer.hidden = false;
    requestAnimationFrame(() => {
      if(choices.length){choicesBox.querySelector('button')?.focus();return;}
      input.focus();
      const select = item.options.select !== false;
      if (select && typeof input.select === 'function') input.select();
      else if (typeof input.setSelectionRange === 'function') input.setSelectionRange(input.value.length, input.value.length);
    });
  }

  function finish(value) {
    if (!active || !queue.length) return;
    const item = queue.shift();
    const layer = document.getElementById('fatum-dialog-layer');
    if (layer) layer.hidden = true;
    active = false;
    item.resolve(value);
    queueMicrotask(renderCurrent);
  }

  function prompt(message, defaultValue = '', options = {}) {
    return new Promise(resolve => {
      queue.push({ id: ++sequence, message: String(message ?? ''), defaultValue: String(defaultValue ?? ''), options: options || {}, resolve });
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', renderCurrent, { once:true });
      else renderCurrent();
    });
  }
  function choose(message, choices = [], options = {}) {
    const normalized=(Array.isArray(choices)?choices:[]).map((choice,index)=>typeof choice==='object'&&choice!==null?{value:String(choice.value??index),label:String(choice.label??choice.value??index),description:String(choice.description??'')}:{value:String(choice),label:String(choice),description:''});
    return prompt(message,'',{...options,choices:normalized,title:options.title||'Выберите действие'});
  }

  globalThis.FatumDialogs = Object.freeze({ prompt, choose });
  globalThis.fatumPrompt = prompt;
  globalThis.fatumChoose = choose;
  installDesktopMessageDialogs();
})();


// FATUM v1.7.12 — master party graph: create a blank character sheet directly on the graph.
(() => {
  'use strict';
  let lan = false;

  let contextCreatePosition = null;
  let observer = null;
  let deleteObserver = null;
  const MENU_ID = 'party-create-character-context-v1712';
  const STYLE_ID = 'party-create-character-style-v1712';
  const DELETE_STYLE_ID = 'party-delete-character-style-v1723';
  const TOP_BUTTON_ID = 'party-new-character-btn';

  function toast(message, kind = '') {
    if (typeof lanToast === 'function') lanToast(message, kind);
    else if (kind === 'error') alert(message);
  }

  function canCreate() {
    return !lan || (typeof FATUM_APP_MODE !== 'undefined' && FATUM_APP_MODE === 'master');
  }

  function worldPositionFromClient(clientX, clientY) {
    const viewport = document.getElementById('party-canvas-viewport');
    if (!viewport || typeof loadPartyCanvasState !== 'function') return null;
    const canvas = loadPartyCanvasState();
    const rect = viewport.getBoundingClientRect();
    const width = typeof PARTY_NODE_WIDTH !== 'undefined' ? PARTY_NODE_WIDTH : 1400;
    const height = typeof PARTY_NODE_HEIGHT !== 'undefined' ? PARTY_NODE_HEIGHT : 920;
    return {
      x: (clientX - rect.left - canvas.x) / canvas.scale - width / 2,
      y: (clientY - rect.top - canvas.y) / canvas.scale - height / 2
    };
  }

  function suggestedPosition() {
    const viewport = document.getElementById('party-canvas-viewport');
    if (!viewport) return null;
    const rect = viewport.getBoundingClientRect();
    return worldPositionFromClient(rect.left + rect.width / 2, rect.top + rect.height / 2);
  }

  function placeCharacter(characterId, preferredPosition = null) {
    if (!characterId || typeof loadPartyCanvasState !== 'function') return;
    const canvas = loadPartyCanvasState();
    canvas.hiddenCharacterIds = (canvas.hiddenCharacterIds || []).filter(id => id !== characterId);
    const position = preferredPosition && Number.isFinite(Number(preferredPosition.x)) && Number.isFinite(Number(preferredPosition.y))
      ? { x: Number(preferredPosition.x), y: Number(preferredPosition.y) }
      : suggestedPosition();
    if (position) canvas.positions[characterId] = position;
    if (typeof savePartyCanvasState === 'function') savePartyCanvasState();
    if (typeof renderPartyScreen === 'function') renderPartyScreen();
    if (typeof renderPartySheetManager === 'function') renderPartySheetManager();
    requestAnimationFrame(() => {
      enhanceEmptyState();
      if (typeof focusPartyNode === 'function') focusPartyNode(characterId);
    });
  }

  async function chooseOwner() {
    if (!lan || typeof lanPlayerDirectory !== 'function') return { ownerId: null, ownerName: null };
    const players = lanPlayerDirectory();
    if (!players.length) return { ownerId: null, ownerName: null };
    const choice = await fatumChoose(
      'Можно сразу закрепить новый лист за подключённым игроком или оставить его без владельца.',
      [
        { value: '', label: 'Пока никому', description: 'Создать лист без назначения игроку.' },
        ...players.map(player => ({
          value: player.id,
          label: player.name,
          description: `Подключённый игрок · ${String(player.id).slice(0, 8)}`
        }))
      ],
      { title: 'Назначить игроку' }
    );
    if (choice === null) return null;
    const ownerId = choice || null;
    return {
      ownerId,
      ownerName: ownerId ? (players.find(player => player.id === ownerId)?.name || 'Игрок') : null
    };
  }

  async function createCharacter(options = {}) {
    if (!canCreate()) return null;
    const requestedName = await fatumPrompt(
      'Введите имя нового персонажа. Поле можно оставить пустым — будет создан «Новый персонаж».',
      '',
      { title: 'Новый лист персонажа', placeholder: 'Имя персонажа', maxLength: 180, select: false, okText: 'Далее' }
    );
    if (requestedName === null) return null;
    const name = String(requestedName || '').trim() || 'Новый персонаж';
    const owner = await chooseOwner();
    if (owner === null) return null;
    const initialState = getDefaultState();
    initialState.name = name;
    const preferredPosition = options.position || suggestedPosition();

    try {
      let character;
      if (lan) {
        const result = await lanFetchJson('/api/characters', {
          method: 'POST',
          body: JSON.stringify({
            clientId: FATUM_LAN_CLIENT_ID,
            name,
            state: initialState,
            portrait: null,
            ownerId: owner.ownerId,
            ownerName: owner.ownerName
          })
        });
        character = result.character;
        lanUpsertCharacter(character);
        buildCharSelector();
        lanUpdateEmptyOverlay();
      } else {
        const allData = loadAllData();
        const newId = `char_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
        character = { id: newId, name, state: initialState };
        allData.characters.push(character);
        if (!allData.activeId) allData.activeId = newId;
        saveAllData(allData);
        buildCharSelector();
      }
      placeCharacter(character.id, preferredPosition);
      toast(owner.ownerId
        ? `Создан лист «${name}» и назначен игроку «${owner.ownerName}».`
        : `Создан новый лист «${name}».`, 'success');
      return character;
    } catch (error) {
      toast(`Не удалось создать персонажа: ${error.message}`, 'error');
      return null;
    }
  }

  function cleanupDeletedCharacterFromGraph(characterId) {
    if (typeof loadPartyCanvasState !== 'function') return;
    const canvas = loadPartyCanvasState();
    if (canvas.positions && typeof canvas.positions === 'object') delete canvas.positions[characterId];
    canvas.hiddenCharacterIds = (canvas.hiddenCharacterIds || []).filter(id => id !== characterId);
    if (typeof savePartyCanvasState === 'function') savePartyCanvasState();
  }

  async function deleteCharacterFromGraph(characterId) {
    if (!canCreate()) return false;
    if (typeof loadAllData !== 'function') return false;

    const allData = loadAllData();
    const character = (allData.characters || []).find(item => item.id === characterId);
    if (!character) {
      toast('Персонаж уже удалён или не найден.', 'error');
      if (typeof renderPartyScreen === 'function') renderPartyScreen();
      if (typeof renderPartySheetManager === 'function') renderPartySheetManager();
      return false;
    }

    const name = character.name || character.state?.name || 'Безымянный персонаж';
    const ownerNote = character.ownerName ? `\nНазначенный игрок: ${character.ownerName}.` : '';
    const backupNote = lan
      ? '\nПеред удалением сервер автоматически создаст резервную копию, а действие попадёт в историю изменений.'
      : '';
    const warning = `Полностью удалить лист «${name}»?${ownerNote}\n\nЭто НЕ скрытие с графа: персонаж будет удалён из кампании и перестанет быть доступен игроку.${backupNote}`;
    if (!confirm(warning)) return false;

    try {
      const wasSelected = typeof getRuntimeCharacterId === 'function'
        ? getRuntimeCharacterId(allData) === characterId
        : allData.activeId === characterId;

      if (lan) {
        await lanFetchJson(`/api/characters/${encodeURIComponent(characterId)}`, {
          method: 'DELETE',
          body: JSON.stringify({ clientId: FATUM_LAN_CLIENT_ID })
        });

        if (typeof lanCampaignCache !== 'undefined' && lanCampaignCache) {
          lanCampaignCache.characters = (lanCampaignCache.characters || []).filter(item => item.id !== characterId);
          lanCampaignCache.updatedAt = new Date().toISOString();
        }

        if (localStorage.getItem('fatumMasterCharacterId') === characterId) {
          localStorage.removeItem('fatumMasterCharacterId');
        }
      } else {
        if ((allData.characters || []).length <= 1) {
          toast('В локальном режиме должен оставаться хотя бы один персонаж.', 'error');
          return false;
        }
        allData.characters = allData.characters.filter(item => item.id !== characterId);
        if (allData.activeId === characterId) allData.activeId = allData.characters[0]?.id || null;
        if (typeof deleteImageFromIdb === 'function') await deleteImageFromIdb(characterId + '_portrait');
        saveAllData(allData);
      }

      cleanupDeletedCharacterFromGraph(characterId);

      if (typeof buildCharSelector === 'function') buildCharSelector();
      if (lan) {
        if (typeof lanUpdateRevisionLabel === 'function') lanUpdateRevisionLabel();
        if (typeof lanUpdateEmptyOverlay === 'function') lanUpdateEmptyOverlay();
      }

      const remaining = loadAllData().characters || [];
      if (wasSelected && remaining.length && typeof load === 'function') {
        try { await load(); }
        catch (error) { console.warn('Не удалось сразу открыть следующий лист после удаления', error); }
      }

      if (typeof renderPartyScreen === 'function') renderPartyScreen();
      if (typeof renderPartySheetManager === 'function') renderPartySheetManager();
      toast(`Лист «${name}» удалён полностью.`, 'success');
      return true;
    } catch (error) {
      console.error('Party graph character delete failed', error);
      toast(`Не удалось удалить персонажа: ${error?.message || error}`, 'error');
      return false;
    }
  }

  function makeDeleteButton(characterId, manager = false) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `btn btn-danger btn-sm party-delete-character-v1723${manager ? ' party-sheet-manager-delete-v1723' : ''}`;
    button.textContent = '🗑 Удалить';
    button.title = 'Полностью удалить персонажа, а не скрыть его с графа';
    button.dataset.partyDeleteCharacter = characterId;
    button.addEventListener('pointerdown', event => event.stopPropagation());
    button.addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      deleteCharacterFromGraph(characterId);
    });
    return button;
  }

  function enhancePartyDeleteCards() {
    if (!canCreate()) return;
    document.querySelectorAll('.party-card[data-party-character-id]').forEach(card => {
      const toolbar = card.querySelector('.party-card-toolbar');
      const characterId = card.dataset.partyCharacterId;
      if (!toolbar || !characterId || toolbar.querySelector('.party-delete-character-v1723')) return;
      toolbar.appendChild(makeDeleteButton(characterId, false));
    });
  }

  function enhancePartyDeleteManager() {
    if (!canCreate() || typeof loadAllData !== 'function') return;

    const managerButton = document.getElementById('party-sheet-manager-btn');
    if (managerButton && managerButton.title !== 'Показать, скрыть или полностью удалить листы') {
      managerButton.title = 'Показать, скрыть или полностью удалить листы';
    }

    const help = document.querySelector('.party-sheet-manager-head span');
    const helpText = 'Скрытие только убирает лист с графа. «Удалить» полностью удаляет персонажа с сервера.';
    if (help && help.textContent !== helpText) help.textContent = helpText;

    const characters = loadAllData().characters || [];
    const rows = Array.from(document.querySelectorAll('.party-sheet-manager-row'));
    rows.forEach((originalRow, index) => {
      const character = characters[index];
      if (!character) return;

      let row = originalRow;
      if (row.tagName === 'LABEL') {
        const replacement = document.createElement('div');
        replacement.className = row.className;
        for (const attr of Array.from(row.attributes)) {
          if (attr.name !== 'class') replacement.setAttribute(attr.name, attr.value);
        }
        while (row.firstChild) replacement.appendChild(row.firstChild);
        row.replaceWith(replacement);
        row = replacement;
      }

      if (!row.querySelector('.party-delete-character-v1723')) {
        row.appendChild(makeDeleteButton(character.id, true));
      }
      row.dataset.partyDeleteEnhanced = '1';
    });
  }

  function enhancePartyDeleteSurfaces() {
    enhancePartyDeleteCards();
    enhancePartyDeleteManager();
  }

  function installDeleteStyle() {
    if (document.getElementById(DELETE_STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = DELETE_STYLE_ID;
    style.textContent = `
      .party-card-toolbar{grid-template-columns:auto minmax(220px,1fr) minmax(240px,330px) auto auto auto auto}
      .party-sheet-manager-row[data-party-delete-enhanced="1"]{grid-template-columns:auto minmax(0,1fr) auto auto}
      .party-sheet-manager-delete-v1723{min-width:86px;white-space:nowrap}
    `;
    document.head.appendChild(style);
  }

  function installDeleteObserver() {
    const screen = document.getElementById('party-screen');
    if (!screen || deleteObserver) return;
    deleteObserver = new MutationObserver(() => enhancePartyDeleteSurfaces());
    deleteObserver.observe(screen, { childList: true, subtree: true });
  }

  function installStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
      .party-create-context-v1712{position:fixed;z-index:1250;min-width:230px;padding:7px;background:var(--paper);border:2px solid var(--border-dark);box-shadow:0 12px 34px rgba(0,0,0,.32)}
      .party-create-context-v1712[hidden]{display:none!important}
      .party-create-context-v1712-title{padding:5px 8px 7px;color:var(--text2);font-family:var(--font-heading);font-size:10px;font-weight:bold;text-transform:uppercase;letter-spacing:1px;border-bottom:1px dashed var(--border-dark);margin-bottom:5px}
      .party-create-context-v1712 button{width:100%;justify-content:flex-start;text-align:left}
    `;
    document.head.appendChild(style);
  }

  function closeContextMenu() {
    const menu = document.getElementById(MENU_ID);
    if (menu) menu.hidden = true;
  }

  function installContextMenu() {
    if (document.getElementById(MENU_ID)) return;
    const screen = document.getElementById('party-screen');
    if (!screen) return;
    const menu = document.createElement('div');
    menu.id = MENU_ID;
    menu.className = 'party-create-context-v1712';
    menu.hidden = true;
    menu.innerHTML = '<div class="party-create-context-v1712-title">Создать на графе</div><button class="btn btn-ghost btn-sm" type="button">＋ Пустой лист персонажа</button>';
    menu.querySelector('button').addEventListener('click', async () => {
      const position = contextCreatePosition;
      contextCreatePosition = null;
      closeContextMenu();
      await createCharacter({ position });
    });
    screen.appendChild(menu);

    const viewport = document.getElementById('party-canvas-viewport');
    if (viewport) {
      viewport.addEventListener('contextmenu', event => {
        if (!canCreate() || (event.target instanceof Element && event.target.closest('.party-card'))) return;
        event.preventDefault();
        contextCreatePosition = worldPositionFromClient(event.clientX, event.clientY);
        menu.hidden = false;
        const width = menu.offsetWidth || 230;
        const height = menu.offsetHeight || 70;
        menu.style.left = `${Math.max(8, Math.min(window.innerWidth - width - 8, event.clientX))}px`;
        menu.style.top = `${Math.max(8, Math.min(window.innerHeight - height - 8, event.clientY))}px`;
      });
    }
    window.addEventListener('mousedown', event => {
      if (!menu.hidden && !menu.contains(event.target)) closeContextMenu();
    }, true);
  }

  function makeButton(id, label, className = 'btn btn-primary btn-sm lan-master-only') {
    const button = document.createElement('button');
    button.type = 'button';
    if (id) button.id = id;
    button.className = className;
    button.textContent = label;
    button.title = 'Создать новый пустой лист персонажа на графе';
    button.addEventListener('click', () => createCharacter());
    return button;
  }

  function enhanceEmptyState() {
    const empty = document.querySelector('.party-world-empty');
    if (!empty || empty.querySelector('[data-party-create-v1712]')) return;
    const actions = empty.querySelector('div[style*="display:flex"]');
    if (!actions) return;
    const button = makeButton('', '＋ Новый лист');
    button.dataset.partyCreateV1712 = '1';
    actions.insertBefore(button, actions.firstChild);
  }

  function installButtons() {
    const actions = document.querySelector('.party-screen-actions');
    if (actions && !document.getElementById(TOP_BUTTON_ID)) {
      const button = makeButton(TOP_BUTTON_ID, '＋ Новый лист');
      const importButton = document.getElementById('party-import-btn');
      actions.insertBefore(button, importButton || null);
    }
    const managerActions = document.querySelector('.party-sheet-manager-actions');
    if (managerActions && !managerActions.querySelector('[data-party-create-v1712]')) {
      const button = makeButton('', '＋ Новый лист');
      button.dataset.partyCreateV1712 = '1';
      const importButton = Array.from(managerActions.querySelectorAll('button')).find(item => /Импорт/.test(item.textContent || ''));
      managerActions.insertBefore(button, importButton || null);
    }
    const help = document.querySelector('.party-canvas-help');
    if (help && !help.textContent.includes('ПКМ по фону')) {
      help.textContent = help.textContent.replace('ЛКМ по пустому фону — перемещение', 'ЛКМ по пустому фону — перемещение · ПКМ по фону — создать персонажа');
    }
  }

  function installObserver() {
    const world = document.getElementById('party-canvas-world');
    if (!world || observer) return;
    observer = new MutationObserver(enhanceEmptyState);
    observer.observe(world, { childList: true });
  }

  function install() {
    if (typeof FATUM_EMBEDDED !== 'undefined' && FATUM_EMBEDDED) return;
    if (typeof FATUM_APP_MODE !== 'undefined' && FATUM_APP_MODE === 'player') return;
    lan = typeof FATUM_LAN_SYNC !== 'undefined' && FATUM_LAN_SYNC;
    if (!canCreate()) return;
    installStyle();
    installDeleteStyle();
    installButtons();
    installContextMenu();
    installObserver();
    installDeleteObserver();
    enhanceEmptyState();
    enhancePartyDeleteSurfaces();
    window.partyCreateNewCharacterFromGraph = createCharacter;
    window.partyDeleteCharacterFromGraph = deleteCharacterFromGraph;
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', install, { once: true });
  else install();
})();
