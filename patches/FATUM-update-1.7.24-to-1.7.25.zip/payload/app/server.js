'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');
const { randomBytes, randomUUID } = require('crypto');
const { createBattlemapModule } = require('./battlemap-server');
const { sha256, createZip, parseZip, compactProcessorAvailable, optimizeMediaFile } = require('./archive-utils');
const { secureEquals: secureSecretEquals, parseCookies: parseRequestCookies, isLoopbackRequest: isLocalRequest, requestIp, requestOriginAllowed, applySecurityHeaders, FixedWindowRateLimiter } = require('./core/security');
const { atomicWriteFile, atomicWriteJsonSync, replaceFile } = require('./core/io');
const { resolveSafePath: resolveSafePathCore, parseByteRange: parseByteRangeCore, readRequestBuffer: readRequestBufferCore, createHttpHelpers } = require('./core/http');
const { makeTimeline, setModuleEnabled, advanceTime, setClock, setSupplies, setHungerStage, applyRest, addCriticalRecoveryEffect, statusForCharacter } = require('./core/campaign-time');
const { resolvePublicAsset } = require('./core/public-assets');

const ROOT_DIR = __dirname;
const PUBLIC_DIR = path.join(ROOT_DIR, 'public');
const DATA_DIR = process.env.FATUM_DATA_DIR ? path.resolve(process.env.FATUM_DATA_DIR) : path.join(ROOT_DIR, 'data');
const PUBLIC_OVERRIDE_DIR = path.join(DATA_DIR, 'overrides', 'public');
const CAMPAIGNS_DIR = path.join(DATA_DIR, 'campaigns');
const CAMPAIGN_INDEX_FILE = path.join(DATA_DIR, 'campaigns.json');
const LEGACY_BACKUP_DIR = path.join(ROOT_DIR, 'backups');
const MASTER_KEY_FILE = path.join(DATA_DIR, 'master-key.txt');
let activeCampaignId = 'default';
let activeDataDir = path.join(CAMPAIGNS_DIR, activeCampaignId);
let PORTRAIT_DIR = path.join(activeDataDir, 'portraits');
let BACKUP_DIR = path.join(activeDataDir, 'backups');
let CAMPAIGN_FILE = path.join(activeDataDir, 'campaign.json');
let HISTORY_FILE = path.join(activeDataDir, 'history.json');
const HOST = '0.0.0.0';
const START_PORT = Number.parseInt(process.env.FATUM_PORT || process.env.PORT || '3000', 10) || 3000;
const MAX_PORT_ATTEMPTS = 20;
const VERSION = String(require('./package.json').version || '0.0.0'); // single source of truth for all server/UI version labels
// compatibility marker: const VERSION = '1.6.6';
// compatibility marker: const VERSION = '1.3.0';
// compatibility marker: const VERSION = '1.2.1';
// compatibility marker: const VERSION = '1.2.0';
// compatibility marker: const VERSION = '1.1.14';
// compatibility marker: const VERSION = '1.0.30';
// compatibility marker: const VERSION = '1.0.28';
// compatibility marker for v1.0.11: const VERSION = '1.0.11';
// compatibility marker for v1.0.8 regression tests: const VERSION = '1.0.8'
// compatibility marker for v1.0.7 regression tests: const VERSION = '1.0.7'
// compatibility marker for v1.0.5 regression tests: const VERSION = '1.0.5'
const MAX_BODY_BYTES = 96 * 1024 * 1024;
// Legacy JSON snapshots can contain base64 maps, tokens and audio. New .fatum
// archives keep media as normal ZIP entries, while rolling snapshots remain
// lightweight and only reference files already stored in the campaign folder.
const MAX_IMPORT_BYTES = 512 * 1024 * 1024;
const MAX_CAMPAIGN_COVER_BYTES = 16 * 1024 * 1024;
const HISTORY_LIMIT = 300;
const DICE_LOG_LIMIT = 200;
const AUTO_BACKUP_CHANGES = 10;
const SNAPSHOT_RETENTION = 40;

// High ceilings keep this invisible in normal play while bounding LAN abuse.
const API_WRITE_RATE_LIMITER = new FixedWindowRateLimiter({ windowMs:60_000, limit:2400, maxKeys:2048 });
const API_UPLOAD_RATE_LIMITER = new FixedWindowRateLimiter({ windowMs:5*60_000, limit:120, maxKeys:2048 });

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif',
  '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8',
  '.mp3':'audio/mpeg', '.ogg':'audio/ogg', '.wav':'audio/wav', '.webm':'audio/webm', '.m4a':'audio/mp4', '.aac':'audio/aac'
};
const HTTP_HELPERS = createHttpHelpers({ mimeTypes:MIME_TYPES });

const sseClients = new Map();
// v1.7.25: authoritative synchronization generations.  They are deliberately
// runtime-scoped: a server restart receives a new epoch, which tells every
// connected/reconnecting client to discard stale local state and take a fresh
// atomic snapshot instead of trying to continue an old SSE stream.
const SYNC_EPOCH = randomUUID();
const syncRevisions = { scene:1, campaign:1, combat:1, force:0 };
function bumpSceneRevision(){ syncRevisions.scene += 1; return syncRevisions.scene; }
function bumpCampaignRevision(mode='refresh'){
  syncRevisions.campaign += 1;
  if(/combat|initiative|trigger-zone-combat|combat-reset/i.test(String(mode||''))) syncRevisions.combat += 1;
  return syncRevisions.campaign;
}
function forceSyncRevision(){
  syncRevisions.scene += 1; syncRevisions.campaign += 1; syncRevisions.combat += 1; syncRevisions.force += 1;
  return currentSyncState();
}
function currentSyncState(){
  const initiative=campaign?.initiative||{round:1,currentIndex:0,entries:[]};
  const entries=Array.isArray(initiative.entries)?initiative.entries:[];
  const index=Math.max(0,Math.min(entries.length?entries.length-1:0,Math.round(Number(initiative.currentIndex)||0)));
  const active=entries[index]||null;
  const mapState=battlemapModule?.getState?.()||null;
  return {
    epoch:SYNC_EPOCH,
    sceneRevision:syncRevisions.scene,
    campaignRevision:syncRevisions.campaign,
    combatRevision:syncRevisions.combat,
    forceRevision:syncRevisions.force,
    activeSceneId:mapState?.activeSceneId||null,
    combatActive:Boolean(mapState?.combat?.active),
    combatSceneId:mapState?.combat?.sceneId||null,
    round:Math.max(1,Math.round(Number(initiative.round)||1)),
    currentIndex:index,
    activeTokenId:active?.tokenId||null,
    activeRef:active?`${active.type||''}:${active.refId||''}`:null,
    at:nowIso()
  };
}
let campaign = null;
let history = [];
let campaignIndex = null;
let masterKey = null;
let writeChain = Promise.resolve();
let historyWriteChain = Promise.resolve();
let changesSinceBackup = 0;
let lastBackupAt = 0;
let battlemapModule = null;

function nowIso() { return new Date().toISOString(); }
function clone(value) { return value === undefined ? undefined : JSON.parse(JSON.stringify(value)); }
function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
function cleanId(value, fallback = null) {
  const text = String(value || '').trim();
  return /^[A-Za-z0-9_.:-]{1,160}$/.test(text) ? text : fallback;
}
function cleanName(value, fallback = 'Без названия', max = 180) {
  const text = String(value || '').trim();
  return (text || fallback).slice(0, max);
}
function cleanText(value, max = 5000) { return String(value || '').slice(0, max); }
function cleanCoverFileName(value) {
  const text = path.basename(String(value || '').trim());
  return /^cover\.(?:png|jpe?g|webp|gif)$/i.test(text) ? text : null;
}
function launcherPortraitUrl(campaignId, portraitUrl, active = false) {
  if (typeof portraitUrl !== 'string' || !portraitUrl.startsWith('/portraits/')) return null;
  const fileName = path.basename(portraitUrl);
  if (!/^[A-Za-z0-9_.-]+$/.test(fileName)) return null;
  return active ? portraitUrl : `/campaign-assets/${encodeURIComponent(campaignId)}/portraits/${encodeURIComponent(fileName)}`;
}
function campaignCoverUrl(record) {
  const fileName = cleanCoverFileName(record?.cover);
  if (!fileName || !record?.id) return null;
  const stamp = encodeURIComponent(String(record.coverUpdatedAt || record.updatedAt || '1'));
  return `/campaign-covers/${encodeURIComponent(record.id)}/${encodeURIComponent(fileName)}?v=${stamp}`;
}
function coverExtensionFromMime(mime, fallbackName = '') {
  const normalized = String(mime || '').toLowerCase().split(';')[0].trim();
  const byMime = { 'image/png':'png', 'image/jpeg':'jpg', 'image/webp':'webp', 'image/gif':'gif' };
  if (byMime[normalized]) return byMime[normalized];
  const extension = path.extname(String(fallbackName || '')).toLowerCase();
  return ['.png','.jpg','.jpeg','.webp','.gif'].includes(extension) ? extension.slice(1).replace('jpeg','jpg') : null;
}
function safeNumber(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}
function makeId(prefix) { return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`; }
function validVisibility(value) { return ['private', 'summary', 'full'].includes(value) ? value : 'private'; }

function makeEmptyCampaign(campaignId = activeCampaignId || 'default', name = 'Новая кампания') {
  const now = nowIso();
  return {
    format: 'fatum-campaign', version: 6, campaignId: cleanId(campaignId, 'default'), name: cleanName(name, 'Новая кампания'),
    createdAt: now, updatedAt: now, characters: [], npcs: [],
    initiative: { round: 1, currentIndex: 0, entries: [] },
    cargo: { money: 0, notes: '', playerCanEdit: false, items: [] },
    globalEffects: [], diceLog: [],
    timeline: makeTimeline(),
    settings: { groupViewEnabled: true }
  };
}

function normalizeState(rawState) {
  const state = rawState && typeof rawState === 'object' ? clone(rawState) : {};
  state.portrait = null;

  // v1.6.2 rules migration. Base OD is a derived character value, so old
  // level-10 saves carrying 6 OD must not keep a stale combat maximum. Keep
  // the existing rib-trauma penalty consistent with the character sheet.
  const level = Math.max(1, Math.round(safeNumber(state.level, 1)));
  const baseOd = level <= 4 ? 3 : level <= 9 ? 4 : 5;
  const injuries = Array.isArray(state.injuries) ? state.injuries : [];
  const effects = Array.isArray(state.activeEffects) ? state.activeEffects : [];
  const ribSuppressed = effects.some(effect => String(effect?.suppressedInjury || '') === 'Трещина в ребре');
  const ribPenalty = !ribSuppressed && injuries.some(injury => String(injury?.name || '') === 'Трещина в ребре') ? 1 : 0;
  const previousOd = Math.max(0, Math.round(safeNumber(state.od, baseOd - ribPenalty)));
  const migratedOd = Math.max(0, baseOd - ribPenalty);
  const previousCurrentOd = Number(state.odCurrent);
  // Only trim an obviously stale full-pool value from the old rules. Do not
  // subtract from partially spent OD or from values above the old maximum, as
  // those can represent a legitimate temporary +OD effect.
  if (previousOd > migratedOd && Number.isFinite(previousCurrentOd) && previousCurrentOd > migratedOd && previousCurrentOd <= previousOd) {
    state.odCurrent = migratedOd;
  }
  state.od = migratedOd;

  // Weapon mastery is allocated by category and each category is hard-capped
  // at 6. Preserve unknown/future categories instead of deleting save data.
  if (state.weaponProficiencies && typeof state.weaponProficiencies === 'object' && !Array.isArray(state.weaponProficiencies)) {
    for (const key of Object.keys(state.weaponProficiencies)) {
      state.weaponProficiencies[key] = Math.max(0, Math.min(6, Math.round(safeNumber(state.weaponProficiencies[key], 0))));
    }
  }
  return state;
}

function portraitExtension(mime) {
  const map = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif' };
  return map[String(mime || '').toLowerCase()] || 'webp';
}
function portraitPathToFile(urlPath) {
  if (typeof urlPath !== 'string' || !urlPath.startsWith('/portraits/')) return null;
  const fileName = path.basename(urlPath);
  if (!/^[A-Za-z0-9_.-]+$/.test(fileName)) return null;
  return path.join(PORTRAIT_DIR, fileName);
}
function savePortraitDataUrl(characterId, dataUrl) {
  const match = /^data:(image\/(?:png|jpeg|webp|gif));base64,([A-Za-z0-9+/=\s]+)$/i.exec(String(dataUrl || ''));
  if (!match) return null;
  const buffer = Buffer.from(match[2].replace(/\s+/g, ''), 'base64');
  if (!buffer.length || buffer.length > 12 * 1024 * 1024) return null;
  const safeId = cleanId(characterId, 'character').replace(/[^A-Za-z0-9_.-]/g, '_');
  const fileName = `${safeId}-${Date.now()}-${Math.random().toString(16).slice(2, 8)}.${portraitExtension(match[1])}`;
  fs.writeFileSync(path.join(PORTRAIT_DIR, fileName), buffer);
  return `/portraits/${fileName}`;
}
function normalizePortrait(characterId, value, fallback = null) {
  if (typeof value !== 'string' || !value.trim()) return null;
  const text = value.trim();
  if (text.startsWith('data:image/')) return savePortraitDataUrl(characterId, text) || fallback;
  const file = portraitPathToFile(text);
  if (file && fs.existsSync(file)) return text;
  return fallback;
}

function normalizeCharacter(raw, index = 0, preserveRevision = true) {
  const rawState = raw && typeof raw.state === 'object' ? raw.state : {};
  const id = cleanId(raw?.id, makeId(`char${index + 1}`));
  const portraitSource = typeof raw?.portrait === 'string' ? raw.portrait : rawState?.portrait;
  return {
    id,
    name: cleanName(raw?.name || rawState?.name, `Персонаж ${index + 1}`),
    revision: preserveRevision ? Math.max(0, Number.parseInt(raw?.revision, 10) || 0) : 0,
    state: normalizeState(rawState),
    portrait: normalizePortrait(id, portraitSource, typeof raw?.portrait === 'string' && raw.portrait.startsWith('/portraits/') ? raw.portrait : null),
    ownerId: cleanId(raw?.ownerId, null),
    ownerName: raw?.ownerId ? cleanName(raw?.ownerName, 'Игрок') : null,
    visibility: validVisibility(raw?.visibility),
    updatedAt: raw?.updatedAt || nowIso(),
    updatedBy: cleanId(raw?.updatedBy, null)
  };
}

const NPC_RANKS = {
  mob: { label: 'Массовка', successDie: '1d4', combatBonus: 0, od: 2, speed: 30, characteristic: 0, wounds: { lightMax: 1, mediumMax: 0, seriousMax: 0 } },
  regular: { label: 'Рядовой', successDie: '1d6', combatBonus: 1, od: 3, speed: 30, characteristic: 1, wounds: { lightMax: 2, mediumMax: 1, seriousMax: 0 } },
  veteran: { label: 'Ветеран', successDie: '1d8', combatBonus: 2, od: 3, speed: 35, characteristic: 2, wounds: { lightMax: 3, mediumMax: 1, seriousMax: 1 } },
  elite: { label: 'Элитный', successDie: '1d8', combatBonus: 3, od: 4, speed: 35, characteristic: 3, wounds: { lightMax: 2, mediumMax: 1, seriousMax: 1 } },
  boss: { label: 'Главный противник', successDie: '1d10', combatBonus: 4, od: 4, speed: 40, characteristic: 4, wounds: { lightMax: 3, mediumMax: 2, seriousMax: 1 } }
};

// Armor profiles are canonical mechanical packages. The campaign API must
// preserve the selected profile for NPCs instead of collapsing it back to the
// old model-only armor record. Keeping a compact copy here also lets legacy
// NPC armor migrate safely before the battlemap module is involved.
const NPC_ARMOR_PROFILES = Object.freeze({
  'Скрытая броня': { class:'light', bz:2 },
  'Полевой бронежилет': { class:'light', bz:3 },
  'Армейский бронежилет': { class:'medium', bz:4 },
  'Противоосколочный бронекомплект': { class:'medium', bz:4 },
  'Усиленный бронекомплект': { class:'medium', bz:5 },
  'Стабилизирующая тяжёлая броня': { class:'heavy', bz:8 },
  'Анаксионно-изолированная броня': { class:'heavy', bz:8 },
  'Тяжёлый экзоскелет': { class:'heavy', bz:9 },
  'Адаптивный экзоскелет': { class:'heavy', bz:10 }
});
const NPC_ARMOR_MODEL_PROFILES = Object.freeze({
  'Stahlmantel':'Скрытая броня', 'Veste Défenseur':'Скрытая броня', 'Цинцзя':'Скрытая броня',
  'Буря-М':'Полевой бронежилет', 'Gilet Guerrier':'Армейский бронежилет', 'Дуншань':'Армейский бронежилет',
  'Kriegskorps':'Противоосколочный бронекомплект', 'Титан-М':'Усиленный бронекомплект',
  'Berg M8':'Стабилизирующая тяжёлая броня', 'Armure Titanique':'Анаксионно-изолированная броня',
  'Экзоскелет Т-1':'Тяжёлый экзоскелет', 'Шаньхэй':'Адаптивный экзоскелет'
});
const NPC_LEGACY_ARMOR_BZ = Object.freeze({
  'Stahlmantel':3, 'Veste Défenseur':2, 'Буря-М':2, 'Цинцзя':2,
  'Kriegskorps':4, 'Gilet Guerrier':3, 'Титан-М':5, 'Дуншань':3,
  'Berg M8':8, 'Armure Titanique':8, 'Экзоскелет Т-1':9, 'Шаньхэй':10
});
function canonicalNpcArmorProfile(armorRaw = {}) {
  const direct = cleanText(armorRaw.profile || armorRaw.armorProfile, 120).trim();
  if (direct && NPC_ARMOR_PROFILES[direct]) return direct;
  const name = cleanText(armorRaw.name || armorRaw.model, 120).trim();
  if (!name) return '';
  if (NPC_ARMOR_PROFILES[name]) return name;
  return NPC_ARMOR_MODEL_PROFILES[name] || '';
}
function validNpcRank(value) { return Object.prototype.hasOwnProperty.call(NPC_RANKS, value) ? value : 'regular'; }
function normalizeDie(value, fallback = '1d6') {
  const text = String(value || fallback).trim().toLowerCase().replace('к', 'd');
  return /^1d(?:4|6|8|10|12|20)$/.test(text) ? text : fallback;
}

function normalizeCustomAttack(raw, index = 0) {
  const source = raw && typeof raw === 'object' ? raw : {};
  const category = ['natural', 'melee', 'ranged'].includes(source.category) ? source.category : (source.naturalWeapon ? 'natural' : source.melee ? 'melee' : 'ranged');
  const melee = category !== 'ranged';
  const bonusMode = ['rank', 'formula', 'manual'].includes(source.bonusMode) ? source.bonusMode : 'manual';
  const properties = (Array.isArray(source.properties) ? source.properties : String(source.properties || '').split(','))
    .map(item => cleanText(item, 80).trim()).filter(Boolean).slice(0, 20);
  return {
    id: cleanId(source.id, makeId(`attack${index + 1}`)),
    name: cleanName(source.name, melee ? 'Новая атака' : 'Новое оружие'),
    profile: cleanText(source.profile || source.name, 160),
    category,
    type: cleanText(source.type, 120) || (melee ? 'Оружие ближнего боя' : 'Особое оружие'),
    melee,
    naturalWeapon: category === 'natural' || Boolean(source.naturalWeapon),
    hitDie: normalizeDie(source.hitDie || source.hitDieNormal, '1d6'),
    hitDieAimed: source.hitDieAimed ? normalizeDie(source.hitDieAimed, '') : '',
    damage: clamp(Math.round(safeNumber(source.damage, 2)), 0, 20),
    damageTag: ['light', 'medium', 'heavy'].includes(source.damageTag) ? source.damageTag : 'medium',
    odCost: clamp(Math.round(safeNumber(source.odCost, 2)), 0, 10),
    aimedOdCost: source.hitDieAimed ? clamp(Math.round(safeNumber(source.aimedOdCost, safeNumber(source.odCost, 2) + 1)), 0, 10) : null,
    obCost: clamp(Math.round(safeNumber(source.obCost, 0)), 0, 10),
    range: Math.max(melee ? 5 : 1, Math.round(safeNumber(source.range, melee ? 5 : 100))),
    radius: Math.max(0, Math.round(safeNumber(source.radius, 0))),
    ignoreMz: Math.max(0, Math.round(safeNumber(source.ignoreMz, 0))),
    bonusMode,
    manualBonus: Math.round(safeNumber(source.manualBonus, 0)),
    proficiency: clamp(Math.round(safeNumber(source.proficiency, 0)), 0, 20),
    accuracy: clamp(Math.round(safeNumber(source.accuracy, 0)), 0, 20),
    threshold: clamp(Math.round(safeNumber(source.threshold, 0)), 0, 20),
    counterAllowed: source.counterAllowed !== false,
    freeAttackAllowed: source.freeAttackAllowed !== false,
    enabled: source.enabled !== false,
    // Empty = use the global sound selected for this weapon type; "off" = mute this profile.
    soundId: source.soundId === 'off' ? 'off' : cleanId(source.soundId, null),
    properties,
    description: cleanText(source.description, 3000)
  };
}
function defaultCreatureAttacks(creatureType) {
  if (creatureType === 'animal') return [normalizeCustomAttack({ name:'Укус', profile:'Укус', category:'natural', hitDie:'1d6', damage:2, damageTag:'medium', odCost:2, range:5, bonusMode:'rank', properties:['Естественное оружие'], description:'Естественная атака. Параметры можно изменить в конструкторе.' }, 0)];
  if (creatureType === 'monster') return [
    normalizeCustomAttack({ name:'Когти', profile:'Когти', category:'natural', hitDie:'1d8', damage:3, damageTag:'medium', odCost:2, range:5, bonusMode:'rank', properties:['Естественное оружие'], description:'Обычная естественная атака; может использоваться для Встречного и свободного удара.' }, 0),
    normalizeCustomAttack({ name:'Укус', profile:'Укус', category:'natural', hitDie:'1d8', damage:4, damageTag:'heavy', odCost:3, range:5, bonusMode:'rank', counterAllowed:false, freeAttackAllowed:false, properties:['Естественное оружие'], description:'Сильная естественная атака; не используется для Встречного или свободного удара.' }, 1)
  ];
  return [];
}
function normalizeNpc(raw, index = 0) {
  const rank = validNpcRank(raw?.rank);
  const preset = NPC_RANKS[rank];
  const oldArmor = typeof raw?.armor === 'number' ? raw.armor : null;
  const armorRaw = raw?.armor && typeof raw.armor === 'object' ? raw.armor : {};
  const oldHealthMax = Math.max(0, Math.round(safeNumber(raw?.health?.max, 0)));
  const characteristicRaw = raw?.characteristics && typeof raw.characteristics === 'object' ? raw.characteristics : {};
  const charValue = key => clamp(Math.round(safeNumber(characteristicRaw[key], preset.characteristic)), 0, 10);
  const woundPreset = preset.wounds;
  const woundRaw = raw?.wounds && typeof raw.wounds === 'object' ? raw.wounds : {};
  const lightMax = Math.max(0, Math.round(safeNumber(woundRaw.lightMax, oldHealthMax ? Math.max(1, Math.ceil(oldHealthMax / 5)) : woundPreset.lightMax)));
  const mediumMax = Math.max(0, Math.round(safeNumber(woundRaw.mediumMax, woundPreset.mediumMax)));
  const seriousMax = Math.max(0, Math.round(safeNumber(woundRaw.seriousMax, woundPreset.seriousMax)));
  const moraleMax = Math.max(0, Math.round(safeNumber(raw?.morale?.max, 10)));
  const obMax = clamp(Math.round(safeNumber(raw?.ob?.max, raw?.obMax ?? 4)), 0, 20);
  const armorProfile = canonicalNpcArmorProfile(armorRaw);
  const armorProfileDef = armorProfile ? NPC_ARMOR_PROFILES[armorProfile] : null;
  const legacyArmorModel = !cleanText(armorRaw.profile || armorRaw.armorProfile, 120).trim() && NPC_ARMOR_MODEL_PROFILES[cleanText(armorRaw.name, 120).trim()]
    ? cleanText(armorRaw.name, 120).trim() : '';
  const bzMax = armorProfileDef ? armorProfileDef.bz : Math.max(0, Math.round(safeNumber(armorRaw.bzMax, oldArmor ?? 0)));
  let armorBzCurrent = Math.max(0, Math.round(safeNumber(armorRaw.bzCurrent, bzMax)));
  if (armorProfileDef && legacyArmorModel) {
    const legacyMax = Math.max(1, Math.round(safeNumber(NPC_LEGACY_ARMOR_BZ[legacyArmorModel], armorRaw.bzMax || bzMax)));
    const ratio = clamp(armorBzCurrent / legacyMax, 0, 1);
    armorBzCurrent = Math.round(bzMax * ratio);
  }
  armorBzCurrent = clamp(armorBzCurrent, 0, bzMax);
  const weaponRaw = raw?.weapon && typeof raw.weapon === 'object' ? raw.weapon : {};
  const bonusMode = ['rank', 'formula', 'manual'].includes(weaponRaw.bonusMode) ? weaponRaw.bonusMode : 'rank';
  // v1.6.9: NPC weapon training is a real, separate setting instead of a
  // misleading field attached to the old fallback weapon.  The default keeps
  // the rulebook's simplified NPC combat bonus; "detailed" opts into the same
  // proficiency formula used by player characters.
  const legacyTrainingMode = bonusMode === 'formula' ? 'detailed' : bonusMode;
  const weaponTrainingMode = ['rank', 'detailed', 'manual'].includes(raw?.weaponTrainingMode) ? raw.weaponTrainingMode : legacyTrainingMode;
  const legacyProficiency = clamp(Math.round(safeNumber(weaponRaw.proficiency, 0)), 0, 6);
  const profRaw = raw?.weaponProficiencies && typeof raw.weaponProficiencies === 'object' ? raw.weaponProficiencies : {};
  const weaponProficiencies = {};
  for (const category of ['Пистолеты','Карабины','Винтовки','Дробовики','Тяжёлое']) {
    weaponProficiencies[category] = clamp(Math.round(safeNumber(profRaw[category], legacyProficiency)), 0, 6);
  }
  const weaponAccuracy = clamp(Math.round(safeNumber(raw?.weaponAccuracy, weaponRaw.accuracy ?? characteristicRaw.concentration ?? preset.characteristic)), 0, 20);
  const manualCombatBonus = clamp(Math.round(safeNumber(raw?.manualCombatBonus, weaponRaw.manualBonus ?? preset.combatBonus)), -20, 30);
  const abilityIds = [...new Set((Array.isArray(raw?.abilityIds) ? raw.abilityIds : []).map(value => String(value || '').trim()).filter(value => ['main-pristrelka','main-mark','main-experienced-look'].includes(value)))];
  const inventoryRaw = Array.isArray(raw?.inventory) ? raw.inventory : [];
  const inventory = inventoryRaw.map((item, itemIndex) => ({
    uid: cleanId(item?.uid || item?.id, makeId(`npcitem${itemIndex + 1}`)),
    name: cleanText(item?.name, 180),
    qty: clamp(Math.round(safeNumber(item?.qty, item?.quantity ?? 1)), 0, 999),
    usesRemaining: item?.usesRemaining === null || item?.usesRemaining === undefined || item?.usesRemaining === '' ? null : clamp(Math.round(safeNumber(item.usesRemaining, 0)), 0, 999),
    notes: cleanText(item?.notes, 500)
  })).filter(item => item.name && item.qty > 0).slice(0, 100);
  const equipmentRaw = raw?.equipment && typeof raw.equipment === 'object' ? raw.equipment : {};
  const inventoryIds = new Set(inventory.map(item => item.uid));
  const equipment = {
    weapon1: inventoryIds.has(cleanId(equipmentRaw.weapon1, null)) ? cleanId(equipmentRaw.weapon1, null) : null,
    weapon2: inventoryIds.has(cleanId(equipmentRaw.weapon2, null)) ? cleanId(equipmentRaw.weapon2, null) : null
  };
  const creatureType = ['human', 'animal', 'monster'].includes(raw?.creatureType) ? raw.creatureType : 'human';
  const attacksSource = Array.isArray(raw?.attacks) ? raw.attacks : [];
  const attacks = (attacksSource.length ? attacksSource.map(normalizeCustomAttack) : (raw?.createDefaultAttacks ? defaultCreatureAttacks(creatureType) : []))
    .filter(item => item.enabled !== false).slice(0, 30);
  // null means the legacy automatic value: 4 + Dexterity. A number is a
  // master-defined base MZ and is used by every VTT attack against this NPC.
  const baseMz = raw?.baseMz === null || raw?.baseMz === undefined || raw?.baseMz === ''
    ? null
    : clamp(Math.round(safeNumber(raw.baseMz, 4 + charValue('dexterity'))), 0, 99);
  return {
    id: cleanId(raw?.id, makeId(`npc${index + 1}`)),
    name: cleanName(raw?.name, `NPC ${index + 1}`),
    kind: ['enemy', 'ally', 'neutral'].includes(raw?.kind) ? raw.kind : 'enemy',
    creatureType,
    visibility: raw?.visibility === 'master' ? 'master' : 'public',
    rank,
    successDie: normalizeDie(raw?.successDie, preset.successDie),
    baseMz,
    characteristics: {
      strength: charValue('strength'), dexterity: charValue('dexterity'), endurance: charValue('endurance'),
      concentration: charValue('concentration'), intelligence: charValue('intelligence'), charisma: charValue('charisma')
    },
    od: { current: clamp(Math.round(safeNumber(raw?.od?.current, raw?.odCurrent ?? preset.od)), 0, 10), max: clamp(Math.round(safeNumber(raw?.od?.max, raw?.odMax ?? preset.od)), 0, 10) },
    ob: { current: clamp(Math.round(safeNumber(raw?.ob?.current, raw?.obCurrent ?? obMax)), 0, obMax), max: obMax },
    speed: Math.max(0, Math.round(safeNumber(raw?.speed, preset.speed))),
    initiative: Math.round(safeNumber(raw?.initiative, 0)),
    armor: {
      profile: armorProfile,
      name: cleanText(armorRaw.name || armorRaw.model, 120),
      class: armorProfileDef?.class || (['none', 'light', 'medium', 'heavy', 'special'].includes(armorRaw.class) ? armorRaw.class : (bzMax > 0 ? 'light' : 'none')),
      bzCurrent: armorBzCurrent,
      bzMax
    },
    morale: { current: clamp(Math.round(safeNumber(raw?.morale?.current, moraleMax)), 0, moraleMax), max: moraleMax },
    wounds: {
      light: clamp(Math.round(safeNumber(woundRaw.light, 0)), 0, lightMax), lightMax,
      medium: clamp(Math.round(safeNumber(woundRaw.medium, 0)), 0, mediumMax), mediumMax,
      serious: clamp(Math.round(safeNumber(woundRaw.serious, 0)), 0, seriousMax), seriousMax,
      critical: Boolean(woundRaw.critical)
    },
    bleeding: Boolean(raw?.bleeding),
    injuries: Array.isArray(raw?.injuries) ? raw.injuries.map(item => typeof item === 'string' ? { name: cleanText(item, 160), desc: '', source: 'legacy' } : { name: cleanText(item?.name, 160), desc: cleanText(item?.desc || item?.description, 1000), source: cleanText(item?.source, 160), createdAt: item?.createdAt || nowIso() }).filter(item => item.name).slice(0, 50) : [],
    outOfCombat: Boolean(raw?.outOfCombat),
    dead: Boolean(raw?.dead),
    _battlemapActions: raw?._battlemapActions && typeof raw._battlemapActions === 'object' ? clone(raw._battlemapActions) : {},
    _battlemapCounterDebt: Math.max(0, Math.round(safeNumber(raw?._battlemapCounterDebt, 0))),
    _battlemapShockDebt: Math.max(0, Math.round(safeNumber(raw?._battlemapShockDebt, 0))),
    _battlemapMeleeDefensePenalty: Math.max(0, Math.round(safeNumber(raw?._battlemapMeleeDefensePenalty, 0))),
    inventory,
    equipment,
    attacks,
    weaponTrainingMode,
    weaponProficiencies,
    weaponAccuracy,
    manualCombatBonus,
    abilityIds,
    weapon: {
      name: cleanText(weaponRaw.name, 160), profile: cleanText(weaponRaw.profile, 120), hitDie: normalizeDie(weaponRaw.hitDie, '1d8'),
      damage: Math.max(0, Math.round(safeNumber(weaponRaw.damage, 2))), bonusMode,
      manualBonus: Math.round(safeNumber(weaponRaw.manualBonus, preset.combatBonus)), proficiency: clamp(Math.round(safeNumber(weaponRaw.proficiency, 1)), 0, 10),
      accuracy: clamp(Math.round(safeNumber(weaponRaw.accuracy, characteristicRaw.concentration ?? preset.characteristic)), 0, 10), threshold: clamp(Math.round(safeNumber(weaponRaw.threshold, 1)), 0, 10),
      melee: Boolean(weaponRaw.melee || /(?:ближн|безоруж|меч|нож|кинжал|дубин|топор|копь|алебард|кастет|штык|когт|клык|укус|естествен)/i.test(`${weaponRaw.profile || ''} ${weaponRaw.name || ''}`)),
      damageTag: ['light', 'medium', 'heavy'].includes(weaponRaw.damageTag) ? weaponRaw.damageTag : 'medium',
      odCost: clamp(Math.round(safeNumber(weaponRaw.odCost, 2)), 0, 10),
      obCost: clamp(Math.round(safeNumber(weaponRaw.obCost, 0)), 0, 10),
      range: Math.max(5, Math.round(safeNumber(weaponRaw.range, (weaponRaw.melee || /(?:ближн|безоруж|меч|нож|кинжал|дубин|топор|копь|алебард|кастет|штык|когт|клык|укус|естествен)/i.test(`${weaponRaw.profile || ''} ${weaponRaw.name || ''}`)) ? 5 : 100))),
      ignoreMz: Math.max(0, Math.round(safeNumber(weaponRaw.ignoreMz, 0))),
      radius: Math.max(0, Math.round(safeNumber(weaponRaw.radius, 0))),
      description: cleanText(weaponRaw.description, 2000)
    },
    abilities: cleanText(raw?.abilities, 5000), behavior: cleanText(raw?.behavior, 5000),
    effects: Array.isArray(raw?.effects) ? raw.effects.map(item => ({
      id: cleanId(item?.id, makeId('npceffect')), name: cleanName(item?.name, 'Эффект'),
      description: cleanText(item?.description, 1000), duration: cleanText(item?.duration, 100)
    })).slice(0, 50) : [],
    notes: cleanText(raw?.notes, 5000), updatedAt: raw?.updatedAt || nowIso()
  };
}
function npcHitBonus(npc) {
  const preset = NPC_RANKS[validNpcRank(npc?.rank)];
  const weapon = npc?.weapon || {};
  if (weapon.bonusMode === 'formula') return Math.round(safeNumber(weapon.proficiency, 0) + Math.floor(safeNumber(weapon.accuracy, 0) / 2) - safeNumber(weapon.threshold, 0));
  if (weapon.bonusMode === 'manual') return Math.round(safeNumber(weapon.manualBonus, preset.combatBonus));
  return preset.combatBonus;
}

function normalizeInitiative(raw, characterIds, npcIds) {
  const entries = [];
  for (const item of (Array.isArray(raw?.entries) ? raw.entries : [])) {
    const type = item?.type === 'npc' ? 'npc' : 'character';
    const refId = cleanId(item?.refId, null);
    if (!refId || (type === 'npc' ? !npcIds.has(refId) : !characterIds.has(refId))) continue;
    entries.push({
      id: cleanId(item?.id, makeId('init')), type, refId, score: Math.round(safeNumber(item?.score, 0)), delayed: Boolean(item?.delayed),
      roll: Math.round(safeNumber(item?.roll, 0)), cube: normalizeDie(item?.cube, '1d6'), bonus: Math.round(safeNumber(item?.bonus, 0)),
      tieBreaks: Array.isArray(item?.tieBreaks) ? item.tieBreaks.map(Number).filter(Number.isFinite).slice(0, 20) : []
    });
  }
  const maxIndex = Math.max(0, entries.length - 1);
  return { round: Math.max(1, Math.round(safeNumber(raw?.round, 1))), currentIndex: clamp(Math.round(safeNumber(raw?.currentIndex, 0)), 0, maxIndex), entries };
}

function normalizeCargo(raw) {
  return {
    money: safeNumber(raw?.money, 0), notes: cleanText(raw?.notes, 10000), playerCanEdit: Boolean(raw?.playerCanEdit),
    items: (Array.isArray(raw?.items) ? raw.items : []).map(item => ({
      id: cleanId(item?.id, makeId('cargo')), name: cleanName(item?.name, 'Предмет'),
      quantity: Math.max(0, safeNumber(item?.quantity, 1)), weight: Math.max(0, safeNumber(item?.weight, 0)),
      description: cleanText(item?.description, 2000)
    })).slice(0, 500)
  };
}
function normalizeGlobalEffects(raw) {
  return (Array.isArray(raw) ? raw : []).map(item => ({
    id: cleanId(item?.id, makeId('effect')), name: cleanName(item?.name, 'Глобальный эффект'),
    description: cleanText(item?.description, 3000), duration: cleanText(item?.duration, 120),
    scope: ['all', 'players', 'npcs'].includes(item?.scope) ? item.scope : 'all', active: item?.active !== false,
    createdAt: item?.createdAt || nowIso()
  })).slice(0, 100);
}
function normalizeDiceLog(raw) {
  return (Array.isArray(raw) ? raw : []).map(item => ({
    id: cleanId(item?.id, makeId('roll')), at: item?.at || nowIso(), actorId: cleanId(item?.actorId, null),
    actorName: cleanName(item?.actorName, 'Участник'), sceneId: cleanId(item?.sceneId, null), tokenId: cleanId(item?.tokenId, null),
    characterId: cleanId(item?.characterId, null), characterName: cleanName(item?.characterName, ''), formula: cleanText(item?.formula, 60), label: cleanText(item?.label, 200),
    rolls: Array.isArray(item?.rolls) ? item.rolls.map(Number).filter(Number.isFinite).slice(0, 100) : [],
    modifier: safeNumber(item?.modifier, 0), total: safeNumber(item?.total, 0), visibility: item?.visibility === 'master' ? 'master' : 'public',
    kind: item?.kind === 'check' ? 'check' : 'formula', skillName: cleanText(item?.skillName, 100),
    successDie: normalizeDie(item?.successDie, '1d6'), successRoll: safeNumber(item?.successRoll, 0), successBonus: safeNumber(item?.successBonus, 0), successTotal: safeNumber(item?.successTotal, 0),
    difficultyDie: cleanText(item?.difficultyDie || '1d6', 20), difficultyRolls: Array.isArray(item?.difficultyRolls) ? item.difficultyRolls.map(Number).filter(Number.isFinite).slice(0, 4) : [],
    difficultyRoll: safeNumber(item?.difficultyRoll, 0), difficultyModifier: safeNumber(item?.difficultyModifier, 0), difficultyTotal: safeNumber(item?.difficultyTotal, 0),
    outcome: ['success','failure','critical-success','critical-failure','edge'].includes(item?.outcome) ? item.outcome : null, margin: safeNumber(item?.margin, 0), condition: ['advantage','hindrance','normal'].includes(item?.condition) ? item.condition : 'normal'
  })).slice(-DICE_LOG_LIMIT);
}

function normalizeCampaign(raw) {
  const base = makeEmptyCampaign();
  const source = raw && typeof raw === 'object' ? raw : {};
  const used = new Set();
  const characters = [];
  for (const [index, item] of (Array.isArray(source.characters) ? source.characters : []).entries()) {
    const character = normalizeCharacter(item, index, true);
    while (used.has(character.id)) character.id = makeId('char');
    used.add(character.id); characters.push(character);
  }
  const npcs = (Array.isArray(source.npcs) ? source.npcs : []).map(normalizeNpc);
  const charIds = new Set(characters.map(item => item.id));
  const npcIds = new Set(npcs.map(item => item.id));
  return {
    ...base, campaignId: cleanId(source.campaignId, 'default'), name: cleanName(source.name, 'Новая кампания'),
    createdAt: source.createdAt || base.createdAt, updatedAt: source.updatedAt || base.updatedAt,
    characters, npcs, initiative: normalizeInitiative(source.initiative, charIds, npcIds), cargo: normalizeCargo(source.cargo),
    globalEffects: normalizeGlobalEffects(source.globalEffects), diceLog: normalizeDiceLog(source.diceLog),
    timeline: makeTimeline(source.timeline),
    settings: { groupViewEnabled: source.settings?.groupViewEnabled !== false }
  };
}

function ensureMasterKey() {
  if (fs.existsSync(MASTER_KEY_FILE)) {
    const existing = fs.readFileSync(MASTER_KEY_FILE, 'utf8').trim();
    if (/^[a-f0-9]{48,128}$/i.test(existing)) {
      masterKey = existing;
      try { if (process.platform !== 'win32') fs.chmodSync(MASTER_KEY_FILE, 0o600); } catch {}
      return;
    }
  }
  masterKey = randomBytes(32).toString('hex');
  fs.writeFileSync(MASTER_KEY_FILE, `${masterKey}
`, { encoding:'utf8', mode:0o600 });
}
function secureEquals(a, b) { return secureSecretEquals(a, b); }
function parseCookies(req) { return parseRequestCookies(req); }
function extractMasterKey(req, requestUrl, body = null) {
  return req.headers['x-fatum-master-key'] || requestUrl.searchParams.get('masterKey') || body?.masterKey || parseCookies(req).fatum_master_key || null;
}
function isLoopbackRequest(req) { return isLocalRequest(req); }
function isMasterAuthorized(req, requestUrl, body = null) { return secureEquals(extractMasterKey(req, requestUrl, body), masterKey); }
function requireMaster(req, res, requestUrl, body = null) {
  if (isMasterAuthorized(req, requestUrl, body)) return true;
  sendJson(res, 403, { ok: false, error: 'Это действие доступно только мастеру.' }); return false;
}

function configureCampaignPaths(campaignId) {
  activeCampaignId = cleanId(campaignId, 'default');
  activeDataDir = path.join(CAMPAIGNS_DIR, activeCampaignId);
  PORTRAIT_DIR = path.join(activeDataDir, 'portraits');
  BACKUP_DIR = path.join(activeDataDir, 'backups');
  CAMPAIGN_FILE = path.join(activeDataDir, 'campaign.json');
  HISTORY_FILE = path.join(activeDataDir, 'history.json');
}

function copyPathSync(source, target) {
  if (!fs.existsSync(source)) return 0;
  const stat = fs.statSync(source);
  if (stat.isDirectory()) {
    fs.mkdirSync(target, { recursive: true });
    let copied = 0;
    for (const name of fs.readdirSync(source)) copied += copyPathSync(path.join(source, name), path.join(target, name));
    return copied;
  }
  if (fs.existsSync(target)) return 0;
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.copyFileSync(source, target);
  return 1;
}

function defaultCampaignIndex() {
  const now = nowIso();
  return { format: 'fatum-campaign-index', version: 2, activeId: 'default', campaigns: [{ id: 'default', name: 'Новая кампания', cover: null, coverUpdatedAt: null, createdAt: now, updatedAt: now, lastOpenedAt: now }] };
}

function persistCampaignIndexSync() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  atomicWriteJsonSync(CAMPAIGN_INDEX_FILE, campaignIndex, 2);
}

function ensureCampaignWorkspace(campaignId, name = 'Новая кампания') {
  const id = cleanId(campaignId, 'default');
  const dir = path.join(CAMPAIGNS_DIR, id);
  fs.mkdirSync(dir, { recursive: true });
  for (const folder of ['portraits', 'maps', 'tokens', 'audio', 'backups', 'assets-trash']) fs.mkdirSync(path.join(dir, folder), { recursive: true });
  const campaignFile = path.join(dir, 'campaign.json');
  const historyFile = path.join(dir, 'history.json');
  const battlemapFile = path.join(dir, 'battlemap.json');
  if (!fs.existsSync(campaignFile)) fs.writeFileSync(campaignFile, JSON.stringify(makeEmptyCampaign(id, name), null, 2), 'utf8');
  if (!fs.existsSync(historyFile)) fs.writeFileSync(historyFile, '[]', 'utf8');
  if (!fs.existsSync(battlemapFile)) fs.writeFileSync(battlemapFile, JSON.stringify({ format:'fatum-battlemap', version:5, tableLog:[], activeSceneId:null, combat:{active:false,sceneId:null,participantTokenIds:[],startedAt:null}, updatedAt:nowIso(), scenes:[] }, null, 2), 'utf8');
  return dir;
}

function migrateLegacyWorkspace() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(CAMPAIGNS_DIR, { recursive: true });
  if (fs.existsSync(CAMPAIGN_INDEX_FILE)) return;
  const index = defaultCampaignIndex();
  const defaultDir = ensureCampaignWorkspace('default', 'Новая кампания');
  const legacyCampaign = path.join(DATA_DIR, 'campaign.json');
  const legacyHistory = path.join(DATA_DIR, 'history.json');
  const legacyBattlemap = path.join(DATA_DIR, 'battlemap.json');
  if (fs.existsSync(legacyCampaign)) {
    copyPathSync(legacyCampaign, path.join(defaultDir, 'campaign.json.legacy-copy'));
    fs.copyFileSync(legacyCampaign, path.join(defaultDir, 'campaign.json'));
    try {
      const parsed = JSON.parse(fs.readFileSync(legacyCampaign, 'utf8'));
      index.campaigns[0].name = cleanName(parsed?.name, 'Новая кампания');
    } catch {}
  }
  if (fs.existsSync(legacyHistory)) fs.copyFileSync(legacyHistory, path.join(defaultDir, 'history.json'));
  if (fs.existsSync(legacyBattlemap)) fs.copyFileSync(legacyBattlemap, path.join(defaultDir, 'battlemap.json'));
  for (const folder of ['portraits','maps','tokens','audio']) copyPathSync(path.join(DATA_DIR, folder), path.join(defaultDir, folder));
  copyPathSync(LEGACY_BACKUP_DIR, path.join(defaultDir, 'backups'));
  campaignIndex = index;
  persistCampaignIndexSync();
}

function collectReferencedAssetNames(value, target = new Map()) {
  if (typeof value === 'string') {
    const match = /^\/(portraits|maps|tokens|audio)\/([^/?#]+)$/i.exec(value);
    if (!match) return target;
    let decoded = match[2];
    try { decoded = decodeURIComponent(decoded); } catch {}
    const fileName = path.basename(decoded);
    if (fileName === decoded && /^[A-Za-z0-9А-Яа-яЁё_. -]+$/i.test(fileName)) {
      const category = match[1].toLowerCase();
      if (!target.has(category)) target.set(category, new Set());
      target.get(category).add(fileName);
    }
    return target;
  }
  if (Array.isArray(value)) { for (const item of value) collectReferencedAssetNames(item, target); return target; }
  if (value && typeof value === 'object') for (const item of Object.values(value)) collectReferencedAssetNames(item, target);
  return target;
}


const assetRecoveryMisses = new Map();
const RECOVERABLE_ASSET_RULES = {
  portraits: { pattern:/^[A-Za-z0-9_.-]+\.(?:png|jpe?g|webp|gif)$/i, maxBytes:12*1024*1024, snapshotKey:'portraits' },
  maps: { pattern:/^[A-Za-z0-9_.-]+\.(?:png|jpe?g|webp|gif)$/i, maxBytes:40*1024*1024, snapshotKey:'mapAssets' },
  tokens: { pattern:/^[A-Za-z0-9_.-]+\.(?:png|jpe?g|webp|gif)$/i, maxBytes:40*1024*1024, snapshotKey:'tokenAssets' },
  audio: { pattern:/^[A-Za-z0-9_.-]+\.(?:mp3|ogg|wav|webm|m4a|aac)$/i, maxBytes:90*1024*1024, snapshotKey:'audioAssets' }
};

function assetFileLooksUsableSync(filePath) {
  try { const stat=fs.statSync(filePath); return stat.isFile() && stat.size > 0; }
  catch { return false; }
}

function findNamedAssetRecursivelySync(root, category, fileName, excludedFile, maxDepth = 8) {
  if (!root || !fs.existsSync(root)) return null;
  const queue=[{dir:root,depth:0}];
  let visited=0;
  while(queue.length && visited<30000){
    const {dir,depth}=queue.shift();
    let entries; try { entries=fs.readdirSync(dir,{withFileTypes:true}); } catch { continue; }
    for(const entry of entries){
      if(++visited>=30000)break;
      const full=path.join(dir,entry.name);
      if(entry.isFile() && entry.name===fileName && full!==excludedFile){
        const parts=full.split(path.sep).map(item=>item.toLowerCase());
        if(parts.includes(category) && assetFileLooksUsableSync(full))return full;
      } else if(entry.isDirectory() && depth<maxDepth){
        if(['node_modules','.git'].includes(entry.name.toLowerCase()))continue;
        queue.push({dir:full,depth:depth+1});
      }
    }
  }
  return null;
}

function backupSearchDirectories(preferredCampaignDir = null) {
  const result=[];
  if(preferredCampaignDir)result.push(path.join(preferredCampaignDir,'backups'));
  if(BACKUP_DIR)result.push(BACKUP_DIR);
  result.push(LEGACY_BACKUP_DIR);
  for(const record of campaignIndex?.campaigns||[])result.push(path.join(CAMPAIGNS_DIR,record.id,'backups'));
  return [...new Set(result.map(item=>path.resolve(item)))].filter(item=>fs.existsSync(item));
}

function writeEmbeddedAssetSync(category, fileName, encoded, targetFile) {
  const rule=RECOVERABLE_ASSET_RULES[category];
  if(!rule || typeof encoded!=='string')return false;
  let buffer; try { buffer=Buffer.from(encoded.replace(/\s+/g,''),'base64'); } catch { return false; }
  if(!buffer.length || buffer.length>rule.maxBytes)return false;
  fs.mkdirSync(path.dirname(targetFile),{recursive:true});
  fs.writeFileSync(targetFile,buffer);
  return assetFileLooksUsableSync(targetFile);
}

function restoreEmbeddedCollectionSync(category, collection, targetDir) {
  const rule=RECOVERABLE_ASSET_RULES[category];
  if(!rule || !collection || typeof collection!=='object')return 0;
  let restored=0;
  for(const [name,encoded] of Object.entries(collection)){
    if(!rule.pattern.test(name))continue;
    const target=path.join(targetDir,name);
    if(assetFileLooksUsableSync(target))continue;
    if(writeEmbeddedAssetSync(category,name,encoded,target))restored+=1;
  }
  return restored;
}

function restoreAssetFromSnapshotFileSync(snapshotFile, category, fileName, targetFile) {
  let stat; try { stat=fs.statSync(snapshotFile); } catch { return false; }
  if(!stat.isFile() || stat.size<=0 || stat.size>MAX_IMPORT_BYTES)return false;
  const lower=snapshotFile.toLowerCase();
  try {
    if(lower.endsWith('.json')){
      const text=fs.readFileSync(snapshotFile,'utf8').replace(/^\uFEFF/,'');
      if(!text.includes(fileName))return false;
      const payload=JSON.parse(text);
      const collection=payload?.[RECOVERABLE_ASSET_RULES[category].snapshotKey];
      if(!collection || typeof collection[fileName]!=='string')return false;
      restoreEmbeddedCollectionSync(category,collection,path.dirname(targetFile));
      return assetFileLooksUsableSync(targetFile);
    }
    if(lower.endsWith('.zip') || lower.endsWith('.fatum')){
      const entries=parseZip(fs.readFileSync(snapshotFile),{maxEntryBytes:160*1024*1024,maxTotalBytes:1024*1024*1024});
      const manifestBuffer=entries.get('manifest.json');
      if(manifestBuffer){
        const manifest=JSON.parse(manifestBuffer.toString('utf8'));
        const expectedUrl=`/${category}/${fileName}`;
        const asset=(manifest?.assets||[]).find(item=>item?.targetUrl===expectedUrl && typeof item?.archivePath==='string');
        const data=asset?entries.get(asset.archivePath):null;
        if(data && data.length<=RECOVERABLE_ASSET_RULES[category].maxBytes){fs.mkdirSync(path.dirname(targetFile),{recursive:true});fs.writeFileSync(targetFile,data);return true;}
      }
      const jsonEntries=[...entries.entries()].filter(([name])=>/(?:^|\/)(?:snapshot[^/]*|campaign)\.json$/i.test(name));
      for(const [,buffer] of jsonEntries){
        const text=buffer.toString('utf8').replace(/^\uFEFF/,'');
        if(!text.includes(fileName))continue;
        const payload=JSON.parse(text),collection=payload?.[RECOVERABLE_ASSET_RULES[category].snapshotKey];
        if(collection && typeof collection[fileName]==='string'){
          restoreEmbeddedCollectionSync(category,collection,path.dirname(targetFile));
          if(assetFileLooksUsableSync(targetFile))return true;
        }
      }
    }
  } catch {}
  return false;
}

function recoverAssetToTargetSync(category, fileName, targetFile, preferredCampaignDir = null) {
  const rule=RECOVERABLE_ASSET_RULES[category];
  if(!rule || !rule.pattern.test(fileName))return null;
  if(assetFileLooksUsableSync(targetFile))return targetFile;
  const direct=[];
  direct.push(path.join(DATA_DIR,category,fileName));
  if(preferredCampaignDir)direct.push(path.join(preferredCampaignDir,category,fileName));
  for(const record of campaignIndex?.campaigns||[])direct.push(path.join(CAMPAIGNS_DIR,record.id,category,fileName));
  let source=[...new Set(direct.map(item=>path.resolve(item)))].find(item=>item!==path.resolve(targetFile)&&assetFileLooksUsableSync(item));
  if(!source)source=findNamedAssetRecursivelySync(DATA_DIR,category,fileName,path.resolve(targetFile));
  if(source){
    try { fs.mkdirSync(path.dirname(targetFile),{recursive:true});fs.copyFileSync(source,targetFile);if(assetFileLooksUsableSync(targetFile))return source; } catch {}
  }
  const backupFiles=[];
  for(const dir of backupSearchDirectories(preferredCampaignDir)){
    let names=[];try{names=fs.readdirSync(dir).filter(name=>/\.(?:json|zip|fatum)$/i.test(name));}catch{continue;}
    names.sort((a,b)=>{try{return fs.statSync(path.join(dir,b)).mtimeMs-fs.statSync(path.join(dir,a)).mtimeMs;}catch{return 0;}});
    for(const name of names.slice(0,80))backupFiles.push(path.join(dir,name));
  }
  for(const backup of [...new Set(backupFiles)])if(restoreAssetFromSnapshotFileSync(backup,category,fileName,targetFile))return backup;
  return null;
}

function recoverRequestedCampaignAssetSync(urlPath, targetFile = null) {
  const match=/^\/(portraits|maps|tokens|audio)\/([A-Za-z0-9_.-]+)$/.exec(String(urlPath||''));
  if(!match)return null;
  const category=match[1],fileName=match[2],key=`${activeCampaignId}:${category}:${fileName}`;
  const lastMiss=assetRecoveryMisses.get(key)||0;if(Date.now()-lastMiss<5000)return null;
  const target=targetFile || path.join(activeDataDir,category,fileName);
  const source=recoverAssetToTargetSync(category,fileName,target,activeDataDir);
  if(source){console.log(`Восстановлен отсутствующий ресурс ${urlPath} из ${path.relative(ROOT_DIR,source).replace(/\\/g,'/')}.`);return target;}
  assetRecoveryMisses.set(key,Date.now());
  console.warn(`Не удалось найти отсутствующий ресурс кампании: ${urlPath}`);
  return null;
}

function repairReferencedCampaignAssetsSync() {
  if (!campaignIndex?.campaigns?.length) return { copied:0, byCategory:{} };
  const categories = ['portraits','maps','tokens','audio'];
  const sourceDirectories = Object.fromEntries(categories.map(category => [category, []]));
  for (const category of categories) sourceDirectories[category].push(path.join(DATA_DIR, category));
  for (const record of campaignIndex.campaigns) {
    const dir = path.join(CAMPAIGNS_DIR, record.id);
    for (const category of categories) sourceDirectories[category].push(path.join(dir, category));
  }
  let copied = 0;
  const byCategory = {};
  for (const record of campaignIndex.campaigns) {
    const dir = ensureCampaignWorkspace(record.id, record.name);
    const references = new Map();
    for (const name of ['campaign.json','battlemap.json']) {
      try { collectReferencedAssetNames(JSON.parse(fs.readFileSync(path.join(dir, name), 'utf8')), references); } catch {}
    }
    for (const [category, names] of references) {
      const targetDir = path.join(dir, category);
      fs.mkdirSync(targetDir, { recursive:true });
      for (const fileName of names) {
        const target = path.join(targetDir, fileName);
        if (fs.existsSync(target)) continue;
        const source = recoverAssetToTargetSync(category, fileName, target, dir);
        if (!source) continue;
        copied += 1;
        byCategory[category] = (byCategory[category] || 0) + 1;
      }
    }
  }
  return { copied, byCategory };
}

function loadCampaignIndexSync() {
  migrateLegacyWorkspace();
  try {
    const raw = JSON.parse(fs.readFileSync(CAMPAIGN_INDEX_FILE, 'utf8'));
    const campaigns = (Array.isArray(raw?.campaigns) ? raw.campaigns : []).map((item, index) => ({
      id: cleanId(item?.id, `campaign_${index + 1}`),
      name: cleanName(item?.name, `Кампания ${index + 1}`),
      cover: cleanCoverFileName(item?.cover),
      coverUpdatedAt: item?.coverUpdatedAt || null,
      createdAt: item?.createdAt || nowIso(),
      updatedAt: item?.updatedAt || nowIso(),
      lastOpenedAt: item?.lastOpenedAt || item?.updatedAt || item?.createdAt || nowIso()
    }));
    campaignIndex = { format:'fatum-campaign-index', version:2, activeId:cleanId(raw?.activeId, campaigns[0]?.id || 'default'), campaigns };
  } catch {
    campaignIndex = defaultCampaignIndex();
  }
  if (!campaignIndex.campaigns.length) campaignIndex = defaultCampaignIndex();
  if (!campaignIndex.campaigns.some(item => item.id === campaignIndex.activeId)) campaignIndex.activeId = campaignIndex.campaigns[0].id;
  for (const item of campaignIndex.campaigns) ensureCampaignWorkspace(item.id, item.name);
  const repaired = repairReferencedCampaignAssetsSync();
  if (repaired.copied) console.log(`Восстановлено потерянных ресурсов кампаний: ${repaired.copied} (${Object.entries(repaired.byCategory).map(([key,value]) => `${key}: ${value}`).join(', ')}).`);
  persistCampaignIndexSync();
}

function loadActiveWorkspaceSync() {
  const record = campaignIndex.campaigns.find(item => item.id === activeCampaignId) || campaignIndex.campaigns[0];
  configureCampaignPaths(record.id);
  ensureCampaignWorkspace(record.id, record.name);
  try { campaign = normalizeCampaign(JSON.parse(fs.readFileSync(CAMPAIGN_FILE, 'utf8'))); }
  catch (error) { try { fs.copyFileSync(CAMPAIGN_FILE, path.join(BACKUP_DIR, `campaign-broken-${Date.now()}.json`)); } catch {} campaign = makeEmptyCampaign(record.id, record.name); console.error('campaign.json повреждён:', error.message); }
  campaign.campaignId = record.id;
  campaign.name = cleanName(campaign.name || record.name, record.name);
  record.name = campaign.name;
  record.updatedAt = campaign.updatedAt || nowIso();
  atomicWriteJsonSync(CAMPAIGN_FILE, campaign, 2);
  try { history = JSON.parse(fs.readFileSync(HISTORY_FILE, 'utf8')); if (!Array.isArray(history)) history = []; } catch { history = []; }
  history = history.slice(-HISTORY_LIMIT);
  atomicWriteJsonSync(HISTORY_FILE, history, 2);
  persistCampaignIndexSync();
}

async function activateCampaignWorkspace(campaignId, sourceClientId = null) {
  const id = cleanId(campaignId, null);
  const record = campaignIndex?.campaigns?.find(item => item.id === id);
  if (!record) throw Object.assign(new Error('Кампания не найдена.'), { statusCode: 404 });
  await Promise.all([persistCampaign(), persistHistory(), battlemapModule?.flush?.()]);
  campaignIndex.activeId = id;
  record.lastOpenedAt = nowIso();
  configureCampaignPaths(id);
  loadActiveWorkspaceSync();
  if (battlemapModule) await battlemapModule.switchStorage(activeDataDir);
  assetRecoveryMisses.clear();
  const repaired = repairReferencedCampaignAssetsSync();
  if (repaired.copied) console.log(`Восстановлено ресурсов после переключения кампании: ${repaired.copied}.`);
  changesSinceBackup = 0;
  lastBackupAt = Date.now();
  persistCampaignIndexSync();
  broadcastCampaignReplaced(sourceClientId, 'campaign-switch');
  battlemapModule?.broadcast?.('battlemap-replaced', sourceClientId, { reason:'campaign-switch', campaignId:id });
  broadcastPresence();
  return record;
}

function readCampaignWorkspaceSummary(item) {
  let raw = null, mapRaw = null;
  try {
    raw = item.id === activeCampaignId ? campaign : JSON.parse(fs.readFileSync(path.join(CAMPAIGNS_DIR, item.id, 'campaign.json'), 'utf8'));
  } catch {}
  try {
    const mapFile = item.id === activeCampaignId ? battlemapModule?.paths?.BATTLEMAP_FILE : path.join(CAMPAIGNS_DIR, item.id, 'battlemap.json');
    mapRaw = mapFile ? JSON.parse(fs.readFileSync(mapFile, 'utf8')) : null;
  } catch {}
  const characters = Array.isArray(raw?.characters) ? raw.characters : [];
  const npcs = Array.isArray(raw?.npcs) ? raw.npcs : [];
  const scenes = Array.isArray(mapRaw?.scenes) ? mapRaw.scenes : [];
  return { raw, mapRaw, characters, npcs, scenes };
}

function campaignListView() {
  return campaignIndex.campaigns.map(item => {
    const summary = readCampaignWorkspaceSummary(item);
    return {
      ...item,
      coverUrl: campaignCoverUrl(item),
      active:item.id === activeCampaignId,
      characters:summary.characters.length,
      npcs:summary.npcs.length,
      scenes:summary.scenes.length
    };
  });
}

function playerCampaignListView(clientId) {
  const id = cleanId(clientId, null);
  const result = [];
  for (const item of campaignIndex.campaigns) {
    const summary = readCampaignWorkspaceSummary(item);
    const assigned = id ? summary.characters.filter(character => character?.ownerId === id) : [];
    const active = item.id === activeCampaignId;
    if (!active && !assigned.length) continue;
    result.push({
      id:item.id,
      name:item.name,
      coverUrl:campaignCoverUrl(item),
      active,
      available:active,
      createdAt:item.createdAt,
      updatedAt:item.updatedAt,
      lastOpenedAt:item.lastOpenedAt,
      characters:assigned.map(character => ({
        id:character.id,
        name:character.name || character.state?.name || 'Персонаж',
        portrait:launcherPortraitUrl(item.id, character.portrait, active),
        revision:character.revision || 0
      })),
      waitingForAssignment:active && !assigned.length
    });
  }
  return result.sort((a,b) => Number(b.active)-Number(a.active) || String(b.lastOpenedAt||b.updatedAt||'').localeCompare(String(a.lastOpenedAt||a.updatedAt||'')));
}
function ensureDataFiles() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(CAMPAIGNS_DIR, { recursive: true });
  fs.mkdirSync(PUBLIC_OVERRIDE_DIR, { recursive: true });
  ensureMasterKey();
  loadCampaignIndexSync();
  configureCampaignPaths(campaignIndex.activeId);
  loadActiveWorkspaceSync();
  if (!battlemapModule) {
    battlemapModule = createBattlemapModule({
      rootDir: ROOT_DIR,
      dataDir: activeDataDir,
      getCampaign: () => campaign,
      persistCampaign,
      persistHistory,
      recordHistory,
      publicHistoryEntry,
      broadcastHistory,
      broadcastCharacterUpdated,
      broadcastDice,
      broadcastCampaignReplaced,
      getSseClients: () => sseClients,
      sseWrite,
      isMasterAuthorized,
      readJsonBody,
      sendJson,
      nowIso,
      clone,
      cleanId,
      cleanName,
      cleanText,
      safeNumber,
      clamp,
      makeId,
      normalizeDie,
      dieSides,
      rollOne,
      createSnapshot: reason => createSnapshot(reason),
      bumpSceneRevision,
      getSyncState: currentSyncState
    });
  }
  battlemapModule.ensureDataFiles();
}

function persistCampaign() {
  campaign.updatedAt = nowIso();
  campaign.campaignId = activeCampaignId;
  const record = campaignIndex?.campaigns?.find(item => item.id === activeCampaignId);
  if (record) { record.name = cleanName(campaign.name, record.name); record.updatedAt = campaign.updatedAt; persistCampaignIndexSync(); }
  const snapshot = JSON.stringify(campaign, null, 2);
  const campaignFile = CAMPAIGN_FILE;
  writeChain = writeChain.then(() => atomicWriteFile(campaignFile, snapshot, 'utf8'));
  return writeChain;
}
function persistHistory() {
  const snapshot = JSON.stringify(history.slice(-HISTORY_LIMIT), null, 2);
  const historyFile = HISTORY_FILE;
  historyWriteChain = historyWriteChain.then(() => atomicWriteFile(historyFile, snapshot, 'utf8'));
  return historyWriteChain;
}
function actorFrom(body, role = 'player') {
  return { id: cleanId(body?.clientId, null), name: cleanName(body?.playerName, role === 'master' ? 'Мастер' : 'Игрок'), role };
}
function recordHistory({ actor, action, entityType, entityId = null, summary, undoData = null }) {
  const entry = { id: makeId('history'), at: nowIso(), actor: actor || { id: null, name: 'Система', role: 'system' }, action, entityType, entityId, summary: cleanText(summary, 1000), undoable: Boolean(undoData), undoData, undoneAt: null, undoneBy: null };
  history.push(entry); if (history.length > HISTORY_LIMIT) history.splice(0, history.length - HISTORY_LIMIT); return entry;
}
function publicHistoryEntry(entry) { const { undoData, ...safe } = entry; return safe; }
function backupName(reason) { return `snapshot-${new Date().toISOString().replace(/[:.]/g, '-')}-${String(reason || 'manual').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 40)}.json`; }
function snapshotSlotForReason(reason, requestedSlot = null) {
  const explicit = String(requestedSlot || '').trim().toLowerCase();
  if (['autosave','safety','quicksave'].includes(explicit)) return explicit;
  const value = String(reason || '').trim().toLowerCase();
  if (value === 'quicksave' || value === 'quick-save') return 'quicksave';
  if (value === 'shutdown' || value.startsWith('auto-')) return 'autosave';
  if (value.startsWith('before-') || value === 'after-undo') return 'safety';
  return null;
}
function snapshotFileName(reason, requestedSlot = null) {
  const slot = snapshotSlotForReason(reason, requestedSlot);
  return slot ? `snapshot-${slot}.json` : backupName(reason);
}
function snapshotDisplayKind(name) {
  if (name === 'snapshot-autosave.json') return 'autosave';
  if (name === 'snapshot-safety.json') return 'safety';
  if (name === 'snapshot-quicksave.json') return 'quicksave';
  return 'manual';
}
function safeArchiveBaseName(value) {
  return cleanName(value, 'campaign', 80).replace(/[<>:\"/\|?*\x00-\x1F]+/g, '_').replace(/\s+/g, ' ').trim() || 'campaign';
}
function extensionMime(extension) {
  return MIME_TYPES[String(extension || '').toLowerCase()] || 'application/octet-stream';
}
function collectAssetUrls(value, target = new Set()) {
  if (Array.isArray(value)) { for (const item of value) collectAssetUrls(item, target); return target; }
  if (!value || typeof value !== 'object') {
    if (typeof value === 'string' && /^\/(?:portraits|maps|tokens|audio)\/[^?#]+$/i.test(value)) target.add(value);
    return target;
  }
  for (const item of Object.values(value)) collectAssetUrls(item, target);
  return target;
}
function assetDescriptor(url) {
  const match = /^\/(portraits|maps|tokens|audio)\/([^/?#]+)$/i.exec(String(url || ''));
  if (!match) return null;
  let decoded; try { decoded = decodeURIComponent(match[2]); } catch { decoded = match[2]; }
  const fileName = path.basename(decoded);
  if (!fileName || fileName !== decoded || !/^[A-Za-z0-9А-Яа-яЁё_. -]+$/i.test(fileName)) return null;
  const roots = {
    portraits: PORTRAIT_DIR,
    maps: battlemapModule?.paths?.MAP_DIR || path.join(activeDataDir, 'maps'),
    tokens: battlemapModule?.paths?.TOKEN_DIR || path.join(activeDataDir, 'tokens'),
    audio: battlemapModule?.paths?.AUDIO_DIR || path.join(activeDataDir, 'audio')
  };
  const kindMap = { portraits:'portrait', maps:'map', tokens:'token', audio:'audio' };
  return { url, category:match[1].toLowerCase(), kind:kindMap[match[1].toLowerCase()], fileName, filePath:path.join(roots[match[1].toLowerCase()], fileName) };
}
function rewriteAssetReferences(value, replacements, metadata) {
  if (typeof value === 'string') return replacements.get(value) || value;
  if (Array.isArray(value)) return value.map(item => rewriteAssetReferences(item, replacements, metadata));
  if (!value || typeof value !== 'object') return value;
  const result = {};
  for (const [key, item] of Object.entries(value)) result[key] = rewriteAssetReferences(item, replacements, metadata);
  if (typeof value.url === 'string' && replacements.has(value.url)) {
    const newUrl = replacements.get(value.url);
    const info = metadata.get(newUrl);
    result.url = newUrl;
    if (Object.prototype.hasOwnProperty.call(value, 'fileName')) result.fileName = path.posix.basename(newUrl);
    if (info && Object.prototype.hasOwnProperty.call(value, 'size')) result.size = info.size;
    if (info && Object.prototype.hasOwnProperty.call(value, 'mime')) result.mime = info.mime;
  }
  return result;
}
async function lightweightSnapshotPayload(reason = 'manual', options = {}) {
  const battlemapSnapshot = battlemapModule ? await battlemapModule.snapshotPayload(false) : {};
  const snapshotHistory = options.fullHistory
    ? clone(history)
    : history.slice(-100).map(entry => ({ ...publicHistoryEntry(entry), undoable:false, undoData:null }));
  return { format:'fatum-snapshot', version:4, assetMode:'references', createdAt:nowIso(), reason, campaign:clone(campaign), history:snapshotHistory, ...battlemapSnapshot };
}
async function replaceFileFromTemporary(temporary, destination) { return replaceFile(temporary, destination); }
async function createSnapshot(reason = 'manual', options = {}) {
  const slot = snapshotSlotForReason(reason, options.slot);
  const payload = await lightweightSnapshotPayload(reason);
  payload.snapshotSlot = slot || null;
  const fileName = snapshotFileName(reason, options.slot);
  const destination = path.join(BACKUP_DIR, fileName);
  const temporary = `${destination}.${process.pid}-${Date.now()}-${randomBytes(3).toString('hex')}.tmp`;
  await fs.promises.writeFile(temporary, JSON.stringify(payload, null, 2), 'utf8');
  await replaceFileFromTemporary(temporary, destination);
  // System snapshots are fixed slots and overwrite themselves. Retention applies
  // only to timestamped manual snapshots, so AppData no longer fills with a new
  // file every ten changes or every fifteen minutes.
  const snapshots = (await fs.promises.readdir(BACKUP_DIR))
    .filter(name => /^snapshot-.*\.json$/.test(name) && !/^snapshot-(?:autosave|safety|quicksave)\.json$/.test(name))
    .sort().reverse();
  await Promise.all(snapshots.slice(SNAPSHOT_RETENTION).map(name => fs.promises.unlink(path.join(BACKUP_DIR, name)).catch(() => {})));
  changesSinceBackup = 0; lastBackupAt = Date.now(); return fileName;
}
async function countUnusedAssets(usedUrls) {
  const usedByCategory = new Map();
  for (const url of usedUrls) {
    const descriptor = assetDescriptor(url); if (!descriptor) continue;
    if (!usedByCategory.has(descriptor.category)) usedByCategory.set(descriptor.category, new Set());
    usedByCategory.get(descriptor.category).add(descriptor.fileName);
  }
  const categories = ['portraits','maps','tokens','audio'];
  let count = 0, bytes = 0;
  for (const category of categories) {
    const probe = assetDescriptor(`/${category}/placeholder.bin`);
    const directory = probe ? path.dirname(probe.filePath) : path.join(activeDataDir, category);
    let names=[]; try { names=await fs.promises.readdir(directory); } catch { continue; }
    for (const name of names) {
      if (usedByCategory.get(category)?.has(name)) continue;
      const file=path.join(directory,name); let stat; try { stat=await fs.promises.stat(file); } catch { continue; }
      if (!stat.isFile()) continue;
      count += 1; bytes += stat.size;
    }
  }
  return { count, bytes };
}
async function createCampaignArchive(mode = 'full') {
  mode = mode === 'compact' ? 'compact' : 'full';
  const base = await lightweightSnapshotPayload(`export-${mode}`, { fullHistory:mode === 'full' });
  if (mode === 'compact') {
    base.history = [];
    if (base.battlemap?.tableLog) base.battlemap.tableLog = base.battlemap.tableLog.slice(-50);
    if (base.campaign?.diceLog) base.campaign.diceLog = base.campaign.diceLog.slice(-50);
  }
  const usedUrls = collectAssetUrls({ campaign:base.campaign, battlemap:base.battlemap });
  const temporaryDirectory = await fs.promises.mkdtemp(path.join(os.tmpdir(), 'fatum-export-'));
  const replacements = new Map();
  const metadata = new Map();
  const archiveAssets = new Map();
  const manifestAssets = [];
  let sourceBytes = 0, storedBytes = 0, optimizedCount = 0, missingCount = 0;
  try {
    for (const url of [...usedUrls].sort()) {
      const descriptor = assetDescriptor(url);
      if (!descriptor) continue;
      let stat; try { stat = await fs.promises.stat(descriptor.filePath); } catch { missingCount += 1; continue; }
      if (!stat.isFile()) continue;
      sourceBytes += stat.size;
      const prepared = mode === 'compact' ? await optimizeMediaFile(descriptor.filePath, descriptor.kind, temporaryDirectory) : { data:await fs.promises.readFile(descriptor.filePath), extension:path.extname(descriptor.fileName).toLowerCase() || '.bin', optimized:false, processor:'original' };
      if (prepared.optimized) optimizedCount += 1;
      const digest = sha256(prepared.data);
      const extension = /^\.[A-Za-z0-9]{1,8}$/.test(prepared.extension) ? prepared.extension.toLowerCase() : '.bin';
      const targetName = `asset-${digest.slice(0,24)}${extension}`;
      const targetUrl = `/${descriptor.category}/${targetName}`;
      const archivePath = `assets/${descriptor.category}/${targetName}`;
      replacements.set(url, targetUrl);
      metadata.set(targetUrl, { size:prepared.data.length, mime:extensionMime(extension), sha256:digest });
      if (!archiveAssets.has(archivePath)) {
        archiveAssets.set(archivePath, prepared.data);
        storedBytes += prepared.data.length;
      }
      manifestAssets.push({ sourceUrl:url, targetUrl, archivePath, category:descriptor.category, size:prepared.data.length, sha256:digest, optimized:Boolean(prepared.optimized), processor:prepared.processor });
    }
    base.campaign = rewriteAssetReferences(base.campaign, replacements, metadata);
    base.battlemap = rewriteAssetReferences(base.battlemap, replacements, metadata);
    base.assetMode = 'archive';
    const activeRecord = campaignIndex.campaigns.find(item => item.id === activeCampaignId);
    let coverManifest = null;
    let coverEntry = null;
    const coverFileName = cleanCoverFileName(activeRecord?.cover);
    if (coverFileName) {
      const coverPath = path.join(activeDataDir, coverFileName);
      try {
        const coverData = await fs.promises.readFile(coverPath);
        const coverDigest = sha256(coverData);
        coverManifest = { fileName:coverFileName, archivePath:`cover/${coverFileName}`, size:coverData.length, sha256:coverDigest, mime:extensionMime(path.extname(coverFileName)) };
        coverEntry = { name:coverManifest.archivePath, data:coverData, compress:false };
      } catch {}
    }
    const unused = await countUnusedAssets(usedUrls);
    const manifest = {
      format:'fatum-archive', version:1, createdAt:nowIso(), mode,
      campaignName:campaign.name, campaignId:activeCampaignId,
      cover:coverManifest,
      assets:manifestAssets,
      stats:{ sourceBytes, storedBytes, referencedAssets:usedUrls.size, uniqueAssets:archiveAssets.size, deduplicated:Math.max(0,manifestAssets.length-archiveAssets.size), optimizedCount, missingCount, omittedUnusedFiles:unused.count, omittedUnusedBytes:unused.bytes },
      compactProcessor:mode === 'compact' ? await compactProcessorAvailable() : 'none'
    };
    const readme = `FATUM campaign archive\nMode: ${mode}\nCreated: ${manifest.createdAt}\nCampaign: ${campaign.name}\n\nImport this .fatum file through the campaign import button.\n`;
    const entries = [
      { name:'manifest.json', data:Buffer.from(JSON.stringify(manifest,null,2),'utf8') },
      { name:'snapshot.json', data:Buffer.from(JSON.stringify(base, mode === 'compact' ? null : 2),'utf8') },
      { name:'README.txt', data:Buffer.from(readme,'utf8') },
      ...(coverEntry ? [coverEntry] : []),
      ...[...archiveAssets.entries()].map(([name,data]) => ({ name, data, compress:false }))
    ];
    return { buffer:createZip(entries), manifest };
  } finally {
    await fs.promises.rm(temporaryDirectory,{recursive:true,force:true}).catch(()=>{});
  }
}
async function parseCampaignImportBuffer(buffer) {
  if (buffer.length >= 4 && buffer.readUInt32LE(0) === 0x04034B50) {
    const entries = parseZip(buffer, { maxEntryBytes:160*1024*1024, maxTotalBytes:1024*1024*1024 });
    const manifestBuffer = entries.get('manifest.json');
    const snapshotBuffer = entries.get('snapshot.json') || entries.get('campaign.json');
    if (!manifestBuffer) {
      const legacyJsonEntries = [...entries.entries()].filter(([name]) => /(?:^|\/)snapshot[^/]*\.json$|(?:^|\/)campaign\.json$/i.test(name));
      const legacyBuffer = snapshotBuffer || (legacyJsonEntries.length === 1 ? legacyJsonEntries[0][1] : null);
      if (!legacyBuffer) throw Object.assign(new Error('В архиве не найден единственный snapshot/campaign JSON.'), { statusCode:400 });
      try { return { payload:JSON.parse(legacyBuffer.toString('utf8').replace(/^\uFEFF/,'')), archivePackage:null }; }
      catch { throw Object.assign(new Error('Повреждён JSON старого архива кампании.'), { statusCode:400 }); }
    }
    if (!snapshotBuffer) throw Object.assign(new Error('В архиве нет snapshot.json или campaign.json.'), { statusCode:400 });
    let manifest, payload;
    try { manifest=JSON.parse(manifestBuffer.toString('utf8')); payload=JSON.parse(snapshotBuffer.toString('utf8')); }
    catch { throw Object.assign(new Error('Повреждены служебные JSON-файлы архива.'), { statusCode:400 }); }
    if (manifest?.format !== 'fatum-archive' || !Array.isArray(manifest.assets)) throw Object.assign(new Error('Это не архив кампании FATUM.'), { statusCode:400 });
    return { payload, archivePackage:{ manifest, entries } };
  }
  try { return { payload:JSON.parse(buffer.toString('utf8').replace(/^\uFEFF/,'')), archivePackage:null }; }
  catch { throw Object.assign(new Error('Не удалось прочитать JSON или .fatum архив кампании.'), { statusCode:400 }); }
}
async function restoreArchiveAssets(archivePackage) {
  if (!archivePackage) return;
  const roots = {
    portraits:PORTRAIT_DIR,
    maps:battlemapModule?.paths?.MAP_DIR || path.join(activeDataDir,'maps'),
    tokens:battlemapModule?.paths?.TOKEN_DIR || path.join(activeDataDir,'tokens'),
    audio:battlemapModule?.paths?.AUDIO_DIR || path.join(activeDataDir,'audio')
  };
  const written = new Set();
  for (const asset of archivePackage.manifest.assets) {
    const category=String(asset?.category||'').toLowerCase();
    if (!roots[category] || typeof asset?.targetUrl !== 'string' || typeof asset?.archivePath !== 'string') continue;
    const expectedPrefix=`/${category}/`;
    if (!asset.targetUrl.startsWith(expectedPrefix)) continue;
    const fileName=path.posix.basename(asset.targetUrl);
    if (!/^[A-Za-z0-9_.-]+$/.test(fileName)) continue;
    const key=`${category}/${fileName}`; if(written.has(key))continue;
    const data=archivePackage.entries.get(asset.archivePath); if(!data)throw Object.assign(new Error(`В архиве отсутствует ${asset.archivePath}.`),{statusCode:400});
    if(asset.sha256&&sha256(data)!==asset.sha256)throw Object.assign(new Error(`Повреждён ресурс ${asset.archivePath}.`),{statusCode:400});
    await fs.promises.mkdir(roots[category],{recursive:true});
    await fs.promises.writeFile(path.join(roots[category],fileName),data); written.add(key);
  }
}
async function restoreArchiveCover(archivePackage, record) {
  const cover = archivePackage?.manifest?.cover;
  if (!cover || !record || typeof cover.archivePath !== 'string') return false;
  const fileName = cleanCoverFileName(cover.fileName || path.posix.basename(cover.archivePath));
  if (!fileName) return false;
  const data = archivePackage.entries.get(cover.archivePath);
  if (!data || !data.length || data.length > MAX_CAMPAIGN_COVER_BYTES) return false;
  if (cover.sha256 && sha256(data) !== cover.sha256) throw Object.assign(new Error('Повреждена обложка кампании в архиве.'), { statusCode:400 });
  const directory = path.join(CAMPAIGNS_DIR, record.id);
  await fs.promises.mkdir(directory,{recursive:true});
  for (const name of await fs.promises.readdir(directory)) if (/^cover\.(?:png|jpe?g|webp|gif)$/i.test(name)) await fs.promises.unlink(path.join(directory,name)).catch(()=>{});
  await fs.promises.writeFile(path.join(directory,fileName),data);
  record.cover=fileName; record.coverUpdatedAt=nowIso(); record.updatedAt=record.coverUpdatedAt;
  return true;
}

async function cleanupUnusedAssets() {
  const battlemapState = battlemapModule ? await battlemapModule.snapshotPayload(false) : {};
  const usedUrls = collectAssetUrls({ campaign, battlemap:battlemapState.battlemap });
  const usedByCategory=new Map();
  for(const url of usedUrls){const d=assetDescriptor(url);if(!d)continue;if(!usedByCategory.has(d.category))usedByCategory.set(d.category,new Set());usedByCategory.get(d.category).add(d.fileName);}
  const stamp=new Date().toISOString().replace(/[:.]/g,'-');
  const trashRoot=path.join(activeDataDir,'assets-trash',stamp);
  let moved=0,bytes=0;
  for(const category of ['portraits','maps','tokens','audio']){
    const probe=assetDescriptor(`/${category}/placeholder.bin`);const directory=probe?path.dirname(probe.filePath):path.join(activeDataDir,category);
    let names=[];try{names=await fs.promises.readdir(directory);}catch{continue;}
    for(const name of names){if(usedByCategory.get(category)?.has(name))continue;const source=path.join(directory,name);let stat;try{stat=await fs.promises.stat(source);}catch{continue;}if(!stat.isFile())continue;const targetDir=path.join(trashRoot,category);await fs.promises.mkdir(targetDir,{recursive:true});await fs.promises.rename(source,path.join(targetDir,name));moved+=1;bytes+=stat.size;}
  }
  return { moved, bytes, trash:path.relative(ROOT_DIR,trashRoot).replace(/\\/g,'/') };
}
async function commitChange(historySpec, { backupBefore = null } = {}) {
  if (backupBefore) await createSnapshot(backupBefore);
  const entry = recordHistory(historySpec); changesSinceBackup += 1;
  await Promise.all([persistCampaign(), persistHistory(), battlemapModule?.flush?.()]);
  if (changesSinceBackup >= AUTO_BACKUP_CHANGES) await createSnapshot('auto-10-changes');
  broadcastHistory(entry); return entry;
}

function characterSummary(character) {
  const st = character.state || {};
  return {
    id: character.id, name: character.name, portrait: character.portrait, ownerName: character.ownerName,
    visibility: character.visibility, accessMode: 'summary', revision: character.revision,
    summary: {
      odCurrent: st.odCurrent ?? st.od ?? 0, odMax: st.od ?? 0,
      obCurrent: st.obCurrent ?? st.ob ?? 0, obMax: st.ob ?? 0,
      moraleCurrent: st.morale?.current ?? 0, moraleMax: st.morale?.max ?? 0,
      wounds: clone(st.wounds || {}), bleeding: Boolean(st.medical?.bleeding), activeEffects: clone(st.activeEffects || []).slice(0, 20)
    }
  };
}
function sharedCharacterView(character) {
  if (character.visibility === 'summary') return characterSummary(character);
  if (character.visibility === 'full') return { ...clone(character), accessMode: 'read' };
  return null;
}
function visibleNpc(npc, mode) { return mode === 'master' || npc.visibility !== 'master'; }
function initiativeView(mode, ownedIds, sharedIds) {
  const mapStatus=battlemapModule?.getStatus?.();
  if(mode!=='master'&&mapStatus?.combatActive&&mapStatus.combatSceneId&&mapStatus.combatSceneId!==mapStatus.activeSceneId){
    return { ...campaign.initiative, currentIndex:0, entries:[] };
  }
  const visibleNpcIds = new Set(campaign.npcs.filter(npc => visibleNpc(npc, mode)).map(npc => npc.id));
  const entries = campaign.initiative.entries.filter(entry => entry.type === 'npc' ? visibleNpcIds.has(entry.refId) : (mode === 'master' || ownedIds.has(entry.refId) || sharedIds.has(entry.refId)));
  return { ...campaign.initiative, entries: clone(entries) };
}
function diceLogView(mode, clientId) {
  return campaign.diceLog.filter(item => mode === 'master' || item.visibility === 'public' || item.actorId === clientId).slice(-100);
}
function campaignViewFor(mode, clientId) {
  if (mode === 'master') return clone(campaign);
  const owned = campaign.characters.filter(character => character.ownerId && character.ownerId === clientId).map(character => ({ ...clone(character), accessMode: 'owner' }));
  const shared = campaign.settings.groupViewEnabled ? campaign.characters.filter(character => character.ownerId !== clientId).map(sharedCharacterView).filter(Boolean) : [];
  const ownedIds = new Set(owned.map(item => item.id)); const sharedIds = new Set(shared.map(item => item.id));
  return {
    format: campaign.format, version: campaign.version, campaignId: campaign.campaignId, name: campaign.name,
    createdAt: campaign.createdAt, updatedAt: campaign.updatedAt, characters: owned, sharedCharacters: shared,
    npcs: campaign.npcs.filter(npc => visibleNpc(npc, mode)).map(clone), initiative: initiativeView(mode, ownedIds, sharedIds),
    cargo: clone(campaign.cargo), globalEffects: clone(campaign.globalEffects.filter(effect => effect.active)),
    diceLog: clone(diceLogView(mode, clientId)), timeline: clone(campaign.timeline), settings: clone(campaign.settings)
  };
}

function sendJson(res, statusCode, payload) { return HTTP_HELPERS.sendJson(res, statusCode, payload); }
function sendText(res, statusCode, text) { return HTTP_HELPERS.sendText(res, statusCode, text); }
function redirect(res, location, extraHeaders = {}) { return HTTP_HELPERS.redirect(res, location, extraHeaders); }
function readRequestBuffer(req, maxBytes, tooLargeMessage = 'Слишком большой запрос.') { return readRequestBufferCore(req, maxBytes, tooLargeMessage); }
// Compatibility note: Do not destroy the socket on oversized uploads; core/http.js drains it so clients receive HTTP 413.
function readJsonBody(req) {
  return readRequestBuffer(req, MAX_BODY_BYTES).then(buffer => {
    if (!buffer.length) return {};
    try { return JSON.parse(buffer.toString('utf8').replace(/^\uFEFF/, '')); }
    catch { throw Object.assign(new Error('Некорректный JSON.'), { statusCode: 400 }); }
  });
}
function readCampaignSnapshotBody(req) {
  return readRequestBuffer(req, MAX_IMPORT_BYTES, 'Файл кампании превышает предел 512 МБ.').then(buffer => {
    if (!buffer.length) throw Object.assign(new Error('Файл кампании пуст.'), { statusCode: 400 });
    return parseCampaignImportBuffer(buffer);
  });
}
function resolveSafePath(root, urlPath, defaultFile = null) { return resolveSafePathCore(root, urlPath, defaultFile); }
function parseByteRange(header, size) { return parseByteRangeCore(header, size); }
function serveFile(req, res, filePath, cacheOverride = null) { return HTTP_HELPERS.serveFile(req, res, filePath, cacheOverride); }
// Compatibility markers retained for historical source-audit tests. Runtime
// byte-range handling lives in core/http.js: 'Accept-Ranges': 'bytes'; res.writeHead(206, headers)
// static-cache compatibility markers: if (!cacheOverride) { headers.Pragma = 'no-cache'; headers.Expires = '0'; } 'ETag': etag

function sendDownloadBuffer(res, buffer, fileName, contentType = 'application/octet-stream', extraHeaders = {}) {
  const fallback = safeArchiveBaseName(path.basename(fileName, path.extname(fileName))) + path.extname(fileName);
  res.writeHead(200, {
    'Content-Type': contentType,
    'Content-Length': buffer.length,
    'Content-Disposition': `attachment; filename="${fallback.replace(/[^A-Za-z0-9_.-]/g, '_')}"; filename*=UTF-8''${encodeURIComponent(fileName)}`,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    ...extraHeaders
  });
  res.end(buffer);
}

function sseWrite(res, event, data) { res.write(`event: ${event}\n`); res.write(`data: ${JSON.stringify(data)}\n\n`); }
let presenceBroadcastTimer = null;
let presenceMetricBroadcastTimer = null;
let lastPresenceMetricBroadcastAt = 0;
const PRESENCE_METRIC_BROADCAST_MIN_MS = 5000;
function presenceQuality(pingMs) {
  const ping = Number(pingMs);
  if (!Number.isFinite(ping)) return 'unknown';
  if (ping <= 80) return 'good';
  if (ping <= 180) return 'fair';
  if (ping <= 350) return 'weak';
  return 'poor';
}
function currentPresence() {
  const grouped = new Map();
  for (const client of sseClients.values()) {
    const groupKey = `${client.mode}:${client.clientId}`;
    let item = grouped.get(groupKey);
    if (!item) {
      item = {
        clientId: client.clientId,
        playerName: client.playerName,
        characterId: client.characterId,
        mode: client.mode,
        connectedAt: client.connectedAt,
        remoteAddress: client.remoteAddress || null,
        connections: 0,
        pingMs: null,
        lastSeenAt: client.lastHeartbeatAt || client.connectedAt
      };
      grouped.set(groupKey, item);
    }
    item.connections += 1;
    if (Date.parse(client.connectedAt || '') < Date.parse(item.connectedAt || '')) item.connectedAt = client.connectedAt;
    const seen = client.lastHeartbeatAt || client.connectedAt;
    if (!item.lastSeenAt || Date.parse(seen || '') > Date.parse(item.lastSeenAt || '')) item.lastSeenAt = seen;
    if (Number.isFinite(Number(client.lastPingMs))) item.pingMs = Math.round(Number(client.lastPingMs));
  }
  return [...grouped.values()].map(item => ({ ...item, quality: presenceQuality(item.pingMs) }));
}
function publicPresenceItem(item, viewer) {
  return {
    playerName: item.playerName,
    mode: item.mode,
    connectedAt: item.connectedAt,
    lastSeenAt: item.lastSeenAt,
    connections: item.connections,
    pingMs: Number.isFinite(Number(item.pingMs)) ? Math.round(Number(item.pingMs)) : null,
    quality: item.quality || presenceQuality(item.pingMs),
    self: Boolean(viewer && item.clientId === viewer.clientId && item.mode === viewer.mode)
  };
}
function visiblePresenceFor(client) {
  const all = currentPresence();
  if (client.mode === 'master') return all.map(item => ({ ...item, self:Boolean(item.clientId === client.clientId && item.mode === client.mode) }));
  // Never expose other players' clientId/characterId: clientId is an authorization identity in legacy FATUM APIs.
  return all.map(item => publicPresenceItem(item, client));
}
function broadcastPresence() {
  lastPresenceMetricBroadcastAt = Date.now();
  for (const client of sseClients.values()) try { sseWrite(client.response, 'presence', { clients: visiblePresenceFor(client), at: nowIso() }); } catch {}
}
function schedulePresenceBroadcast(delayMs = 180) {
  // Join/leave and explicit presence changes are important: let them pre-empt a
  // delayed telemetry-only broadcast instead of making users wait for the ping throttle.
  if (presenceMetricBroadcastTimer) {
    clearTimeout(presenceMetricBroadcastTimer);
    presenceMetricBroadcastTimer = null;
  }
  if (presenceBroadcastTimer) return;
  presenceBroadcastTimer = setTimeout(() => {
    presenceBroadcastTimer = null;
    broadcastPresence();
  }, Math.max(20, Math.min(1000, Number(delayMs) || 180)));
  presenceBroadcastTimer.unref?.();
}
function schedulePresenceMetricBroadcast() {
  if (presenceBroadcastTimer || presenceMetricBroadcastTimer) return;
  const elapsed = Date.now() - lastPresenceMetricBroadcastAt;
  const delay = Math.max(220, PRESENCE_METRIC_BROADCAST_MIN_MS - elapsed);
  presenceMetricBroadcastTimer = setTimeout(() => {
    presenceMetricBroadcastTimer = null;
    broadcastPresence();
  }, delay);
  presenceMetricBroadcastTimer.unref?.();
}
function broadcastHistory(entry) { for (const client of sseClients.values()) if (client.mode === 'master') try { sseWrite(client.response, 'history-updated', { entry: publicHistoryEntry(entry) }); } catch {} }
function broadcastCharacterUpdated(character, sourceClientId = null) {
  bumpCampaignRevision('character-updated');
  const sync=currentSyncState();
  for (const client of sseClients.values()) {
    try {
      if (client.mode === 'master' || character.ownerId === client.clientId) sseWrite(client.response, 'character-updated', { character, sourceClientId, sync });
      else if (campaign.settings.groupViewEnabled) { const shared = sharedCharacterView(character); if (shared) sseWrite(client.response, 'shared-character-updated', { character: shared, sourceClientId, sync }); }
    } catch {}
  }
}
function broadcastCampaignReplaced(sourceClientId = null, mode = 'refresh') {
  bumpCampaignRevision(mode);
  const sync=currentSyncState();
  for (const client of sseClients.values()) try { sseWrite(client.response, 'campaign-replaced', { campaign: campaignViewFor(client.mode, client.clientId), sourceClientId, mode, sync }); } catch {}
}
function broadcastSyncRequired(reason='master-force-sync',sourceClientId=null){
  const sync=forceSyncRevision();
  for(const client of sseClients.values())try{sseWrite(client.response,'sync-required',{reason,sourceClientId,sync,at:nowIso()});}catch{}
  return sync;
}
function broadcastDice(roll) {
  for (const client of sseClients.values()) if (client.mode === 'master' || roll.visibility === 'public' || roll.actorId === client.clientId) try { sseWrite(client.response, 'dice-rolled', { roll }); } catch {}
}

function registerSseClient(req, res, requestUrl) {
  const mode = requestUrl.searchParams.get('mode') === 'master' ? 'master' : 'player';
  if (mode === 'master' && !isMasterAuthorized(req, requestUrl)) return sendJson(res, 403, { ok: false, error: 'Неверный мастерский ключ.' });
  const key = randomUUID(); const clientId = cleanId(requestUrl.searchParams.get('clientId'), key);
  let characterId = cleanId(requestUrl.searchParams.get('characterId'), null);
  if (mode === 'player' && characterId && !campaign.characters.some(item => item.id === characterId && item.ownerId === clientId)) characterId = null;
  const connectedAt = nowIso();
  const client = { response: res, clientId, playerName: cleanName(requestUrl.searchParams.get('playerName'), mode === 'master' ? 'Мастер' : 'Игрок'), characterId, mode, connectedAt, remoteAddress: req.socket.remoteAddress || null, lastPingMs: null, lastHeartbeatAt: connectedAt };
  res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' }); res.write(': connected\n\n');
  sseClients.set(key, client); sseWrite(res, 'hello', { version: VERSION, campaignId: campaign.campaignId, mode, presenceToken:key, sync:currentSyncState(), at: nowIso() }); sseWrite(res, 'presence', { clients: visiblePresenceFor(client), at: nowIso() }); schedulePresenceBroadcast(40);
  const cleanup = () => { if (sseClients.delete(key)) schedulePresenceBroadcast(40); }; req.once('close', cleanup); req.once('error', cleanup);
}

function clientIdFrom(body, requestUrl) { return cleanId(body?.clientId || requestUrl.searchParams.get('clientId'), null); }
function canEditCharacter(character, req, requestUrl, body = null) { return isMasterAuthorized(req, requestUrl, body) || Boolean(clientIdFrom(body, requestUrl) && character.ownerId === clientIdFrom(body, requestUrl)); }
function summarizeCharacterDiff(before, after) {
  const a = before.state || {}, b = after.state || {}, parts = [];
  const compare = (label, av, bv) => { if (String(av) !== String(bv)) parts.push(`${label}: ${av ?? '—'} → ${bv ?? '—'}`); };
  compare('ОД', a.odCurrent ?? a.od, b.odCurrent ?? b.od); compare('ОБ', a.obCurrent ?? a.ob, b.obCurrent ?? b.ob);
  compare('мораль', a.morale?.current, b.morale?.current); compare('кровотечение', a.medical?.bleeding ? 'да' : 'нет', b.medical?.bleeding ? 'да' : 'нет');
  for (const key of ['light', 'medium', 'serious', 'critical']) compare(`ранения ${key}`, a.wounds?.[key], b.wounds?.[key]);
  if ((a.activeEffects || []).length !== (b.activeEffects || []).length) parts.push(`активные эффекты: ${(a.activeEffects || []).length} → ${(b.activeEffects || []).length}`);
  return parts.length ? parts.slice(0, 6).join('; ') : 'обновлён лист персонажа';
}
function ensureQuickMedical(next) {
  next.wounds = next.wounds || { light: 0, lightMax: 2, medium: 0, mediumMax: 1, serious: 0, seriousMax: 1, critical: false };
  next.medical = next.medical || {};
  next.activeEffects = Array.isArray(next.activeEffects) ? next.activeEffects : [];
}
function quickActionState(state, body) {
  const next = clone(state || {}); const type = String(body.type || ''); const amount = safeNumber(body.amount, 1); ensureQuickMedical(next);
  if (type === 'od') next.odCurrent = clamp(safeNumber(next.odCurrent, next.od || 0) + amount, 0, Math.max(0, safeNumber(next.od, 0)));
  else if (type === 'ob') next.obCurrent = clamp(safeNumber(next.obCurrent, next.ob || 0) + amount, 0, Math.max(0, safeNumber(next.ob, 0)));
  else if (type === 'bz') next.bz = clamp(safeNumber(next.bz, next.bzMax || 0) + amount, 0, Math.max(0, safeNumber(next.bzMax, next.bz || 0)));
  else if (type === 'morale') { next.morale = next.morale || { current: 0, max: 0, base: 0 }; next.morale.current = clamp(safeNumber(next.morale.current, 0) + amount, 0, Math.max(0, safeNumber(next.morale.max, 0))); }
  else if (type === 'wound') {
    const woundType = ['light', 'medium', 'serious'].includes(body.woundType) ? body.woundType : 'light';
    const maxKey = `${woundType}Max`; const max = Math.max(0, safeNumber(next.wounds[maxKey], 99));
    next.wounds[woundType] = clamp(Math.round(safeNumber(next.wounds[woundType], 0) + amount), 0, max || 99);
  }
  else if (type === 'critical') {
    const value = body.value === undefined ? !next.wounds.critical : Boolean(body.value); next.wounds.critical = value;
    next.medical.criticalRounds = value ? Math.max(0, Math.round(safeNumber(next.medical.criticalRounds, 0))) : 0;
  }
  else if (type === 'stabilize') { next.wounds.critical = false; next.medical.criticalRounds = 0; next.medical.bleeding = false; next.medical.failedStabilizers = []; addCriticalRecoveryEffect(next); }
  else if (type === 'bleeding') next.medical.bleeding = body.value === undefined ? !next.medical.bleeding : Boolean(body.value);
  else if (type === 'heal-all') { next.wounds.light = 0; next.wounds.medium = 0; next.wounds.serious = 0; next.wounds.critical = false; next.medical.criticalRounds = 0; next.medical.bleeding = false; next.medical.failedStabilizers = []; }
  else if (type === 'effect-add') next.activeEffects.push({ id: makeId('effect'), name: cleanName(body.name, 'Эффект'), description: cleanText(body.description, 2000), duration: cleanText(body.duration, 120), source: 'gmQuickAction' });
  else if (type === 'effect-remove') next.activeEffects = next.activeEffects.filter(item => item.id !== body.effectId);
  else throw Object.assign(new Error('Неизвестное быстрое действие.'), { statusCode: 400 });
  next.portrait = null; return next;
}

function parseDiceFormula(formula) {
  const compact = String(formula || '').replace(/\s+/g, '').toLowerCase().replace(/к/g, 'd');
  const match = /^(\d{0,2})d(\d{1,4})([+-]\d{1,5})?$/.exec(compact);
  if (!match) throw Object.assign(new Error('Формат броска: NdM+K, например 2d10+3.'), { statusCode: 400 });
  const count = clamp(Number(match[1] || 1), 1, 100); const sides = clamp(Number(match[2]), 2, 1000); const modifier = Number(match[3] || 0);
  const rolls = Array.from({ length: count }, () => Math.floor(Math.random() * sides) + 1); return { formula: `${count}d${sides}${modifier > 0 ? `+${modifier}` : modifier < 0 ? modifier : ''}`, rolls, modifier, total: rolls.reduce((a, b) => a + b, 0) + modifier };
}
function dieSides(value, fallback = 6) { const match = /(?:1)?[dк](4|6|8|10|12|20)/i.exec(String(value || '')); return match ? Number(match[1]) : fallback; }
function rollOne(sides) { return Math.floor(Math.random() * sides) + 1; }
function adjustedDifficulty(die, condition) {
  const orders = [4, 6, 8, 10, 12]; let sides = dieSides(die, 6); const index = orders.indexOf(sides);
  if (condition === 'advantage') {
    if (sides === 4) { const rolls = [rollOne(4), rollOne(4)]; return { die: '2d4', rolls, chosen: Math.min(...rolls) }; }
    sides = orders[Math.max(0, index - 1)];
  } else if (condition === 'hindrance') {
    if (sides === 12) { const rolls = [rollOne(12), rollOne(12)]; return { die: '2d12', rolls, chosen: Math.max(...rolls) }; }
    sides = orders[Math.min(orders.length - 1, index + 1)];
  }
  const roll = rollOne(sides); return { die: `1d${sides}`, rolls: [roll], chosen: roll };
}
function consumePreparedCharacterCheck(character) {
  const effects=character?.state?._battlemapFeatureEffects;
  if(!effects||typeof effects!=='object'||Array.isArray(effects))return null;
  const value=effects.nextCheck||null;if(value)delete effects.nextCheck;return value;
}
function mergeCheckCondition(manual, featureCondition) {
  const score=(manual==='advantage'?1:manual==='hindrance'?-1:0)+(featureCondition==='advantage'?1:featureCondition==='hindrance'?-1:0);
  return score>0?'advantage':score<0?'hindrance':'normal';
}
function normalizeManualExtraDice(value) {
  const raw=Array.isArray(value)?value:[];const result=[];
  for(const item of raw){
    const sides=Number(typeof item==='object'&&item?item.sides:item);if(![4,6,8,10,12].includes(sides))continue;
    const count=typeof item==='object'&&item?clamp(Math.round(safeNumber(item.count,1)),1,10):1;
    for(let i=0;i<count&&result.length<20;i++)result.push(sides);
    if(result.length>=20)break;
  }
  return result;
}
function rollManualExtraDice(value) { return normalizeManualExtraDice(value).map(sides=>({name:'Произвольный куб',die:`1d${sides}`,sides,roll:rollOne(sides),manual:true})); }
function rollSkillCheck(body, character) {
  const prepared=consumePreparedCharacterCheck(character),successDie=normalizeDie(body.successDie,'1d6'),successSides=dieSides(successDie,6);
  let successRoll=rollOne(successSides);const manualExtraRolls=rollManualExtraDice(body.extraDice),manualExtraTotal=manualExtraRolls.reduce((sum,item)=>sum+item.roll,0),ruleSuccessBonus=Math.round(safeNumber(body.successBonus,0)+safeNumber(prepared?.flat,0)),baseSuccessBonus=ruleSuccessBonus+manualExtraTotal;
  const manualCondition=['advantage','hindrance'].includes(body.condition)?body.condition:'normal',condition=mergeCheckCondition(manualCondition,prepared?.condition);
  const difficultyBase=normalizeDie(body.difficultyDie,'1d6'),diff=adjustedDifficulty(difficultyBase,condition),difficultyModifier=Math.round(safeNumber(body.difficultyModifier,0)),difficultyTotal=diff.chosen+difficultyModifier;
  let baseSuccessTotal=successRoll+baseSuccessBonus,preparedExtraRoll=0;
  if(prepared?.extraDie&&(!prepared.afterFailure||baseSuccessTotal<difficultyTotal))preparedExtraRoll=rollOne(dieSides(`1d${prepared.extraDie}`,prepared.extraDie));
  let rerolled=null;if(prepared?.reroll&&baseSuccessTotal+preparedExtraRoll<difficultyTotal){const first=successRoll,second=rollOne(successSides),penalty=Math.round(safeNumber(prepared.rerollPenalty,0));successRoll=second;rerolled={first,second,penalty};baseSuccessTotal=successRoll+baseSuccessBonus+penalty;}
  const successBonus=baseSuccessBonus+preparedExtraRoll+(rerolled?.penalty||0),successTotal=successRoll+successBonus,margin=successTotal-difficultyTotal;let outcome=margin>=0?'success':margin>=-3?'edge':'failure';
  const difficultySides=dieSides(diff.die,dieSides(difficultyBase,6));if(successRoll===diff.chosen&&successSides>difficultySides)outcome='critical-success';else if(successRoll===diff.chosen&&difficultySides>successSides)outcome='critical-failure';
  const extraRolls=[...manualExtraRolls,...(preparedExtraRoll?[{name:prepared?.sourceName||'Особенность',die:`1d${prepared.extraDie}`,roll:preparedExtraRoll,afterFailure:Boolean(prepared?.afterFailure)}]:[])];
  const signed=n=>n?`${n>0?'+':''}${n}`:'',manualFormula=manualExtraRolls.map(item=>` + ${item.die}`).join(''),preparedFormula=preparedExtraRoll?` + 1d${prepared.extraDie}`:'',successFormula=`${rerolled?`${successDie} → ${successDie} (переброс, используется второй)`:successDie}${manualFormula}${preparedFormula}${signed(ruleSuccessBonus)}${rerolled?signed(rerolled.penalty):''}`,difficultyFormula=`${diff.die}${diff.rolls?.length>1?` (${condition==='advantage'?'меньший':'больший'})`:''}${signed(difficultyModifier)}`;
  return {
    id:makeId('roll'),at:nowIso(),actorId:cleanId(body.clientId,null),actorName:cleanName(body.playerName,'Участник'),sceneId:cleanId(body.sceneId,null),tokenId:cleanId(body.tokenId||body.battlemapTokenId,null),
    characterId:character?.id||null,characterName:character?.name||'',label:cleanText(body.label||body.skillName,200),visibility:body.visibility==='master'?'master':'public',kind:'check',skillName:cleanText(body.skillName,100),
    formula:`${successFormula} vs ${difficultyFormula}`,
    rolls:[successRoll,...extraRolls.map(item=>item.roll)],modifier:successBonus,total:successTotal,successDie,successRoll,baseSuccessBonus:ruleSuccessBonus,successBonus,baseSuccessTotal,successTotal,extraRolls,manualExtraRolls,pendingFeature:prepared,rerolled,
    difficultyDie:diff.die,difficultyRolls:diff.rolls,difficultyRoll:diff.chosen,difficultyModifier,difficultyTotal,condition,outcome,margin
  };
}
function rollInitiativeParticipants(participants) {
  const rolled = participants.map(item => {
    const sides = dieSides(item.cube, 6); const roll = rollOne(sides); const bonus = Math.round(safeNumber(item.bonus, 0));
    return { id: makeId('init'), type: item.type === 'npc' ? 'npc' : 'character', refId: item.refId, cube: `1d${sides}`, roll, bonus, score: roll + bonus, tieBreaks: [], delayed: false };
  });
  let guard = 0;
  while (guard++ < 30) {
    const groups = new Map(); for (const entry of rolled) { const list = groups.get(entry.score) || []; list.push(entry); groups.set(entry.score, list); }
    const tied = [...groups.values()].filter(list => list.length > 1); if (!tied.length) break;
    for (const group of tied) for (const entry of group) { const reroll = rollOne(dieSides(entry.cube, 6)) + entry.bonus; entry.tieBreaks.push(reroll); entry.score = reroll; }
  }
  rolled.sort((a, b) => b.score - a.score || a.refId.localeCompare(b.refId)); return rolled;
}

function fallbackCharacterSkillProfile(state, skillName) {
  const stored = state?._lanRollProfile?.skills?.[skillName];
  if (stored) return { cube: normalizeDie(stored.cube, '1d6'), bonus: Math.round(safeNumber(stored.bonus, 0)) };
  const groups = {
    'Физическая сила': 'Сильный', 'Взлом': 'Ловкий', 'Акробатика': 'Ловкий', 'Скрытность': 'Ловкий',
    'Выдержка': 'Выносливый', 'Стойкость': 'Выносливый', 'Иммунитет': 'Выносливый',
    'Бдительность': 'Бдительный', 'Воля': 'Бдительный', 'Меткость': 'Бдительный', 'Выживание': 'Бдительный',
    'Анализ': 'Умный', 'Эрудиция': 'Умный', 'Память': 'Умный', 'Медицина': 'Умный', 'Механика': 'Умный',
    'Убеждение': 'Обаятельный', 'Обман': 'Обаятельный', 'Интуиция': 'Обаятельный', 'Запугивание': 'Обаятельный', 'Очарование': 'Обаятельный'
  };
  const trait = groups[skillName]; const level = Math.max(0, Math.round(safeNumber(state?.traits?.main?.[trait], 0)));
  const orders = [4, 6, 8, 10, 12]; let idx = level === 0 ? 0 : level <= 2 ? 1 : level <= 4 ? 2 : 3;
  if (state?.skills?.[skillName]?.prof) idx = Math.min(idx + 1, orders.length - 1);
  const traitBonus = [2, 4, 5].filter(x => level >= x).length + (trait === 'Бдительный' && level >= 5 && ['Бдительность', 'Выживание'].includes(skillName) ? 1 : 0);
  return { cube: normalizeDie(state?.skills?.[skillName]?.customCube, `1d${orders[idx]}`), bonus: traitBonus + Math.round(safeNumber(state?.skills?.[skillName]?.bonus, 0)) };
}

async function undoHistoryEntry(entry, actor) {
  if (!entry?.undoable || !entry.undoData || entry.undoneAt) throw Object.assign(new Error('Это изменение нельзя отменить.'), { statusCode: 409 });
  const data = entry.undoData;
  if (data.kind === 'restore-character') {
    const index = campaign.characters.findIndex(item => item.id === data.character.id);
    const restored = clone(data.character); restored.revision = (index >= 0 ? campaign.characters[index].revision : restored.revision) + 1; restored.updatedAt = nowIso(); restored.updatedBy = actor.id;
    if (index >= 0) campaign.characters[index] = restored; else campaign.characters.push(restored);
  } else if (data.kind === 'delete-character') campaign.characters = campaign.characters.filter(item => item.id !== data.characterId);
  else if (data.kind === 'insert-character') campaign.characters.push(clone(data.character));
  else if (data.kind === 'restore-campaign') campaign = normalizeCampaign(data.campaign);
  else if (data.kind === 'restore-module') campaign[data.module] = clone(data.before);
  else throw Object.assign(new Error('Неизвестный тип отмены.'), { statusCode: 409 });
  entry.undoneAt = nowIso(); entry.undoneBy = actor;
  recordHistory({ actor, action: 'undo', entityType: entry.entityType, entityId: entry.entityId, summary: `Отменено: ${entry.summary}`, undoData: null });
  await Promise.all([persistCampaign(), persistHistory()]); await createSnapshot('after-undo');
  broadcastCampaignReplaced(actor.id, 'undo');
}

async function handleApi(req, res, requestUrl) {
  const pathname = requestUrl.pathname;
  if (battlemapModule && pathname.startsWith('/api/battlemap')) return battlemapModule.handleApi(req, res, requestUrl);
  if (pathname === '/api/status' && req.method === 'GET') { sendJson(res, 200, { ok: true, app: 'FATUM LAN Server', version: VERSION, time: nowIso(), synchronization: true, portraitsFolder: true, history: true, initiative: true, npcs: true, dice: true, cargo: true, globalEffects: true, automatedInitiative: true, skillChecks: true, diceVisuals: true, battlemap: true, dynamicLight: true, fogOfWar: true, mapStatus: battlemapModule?.getStatus?.() || null, characters: campaign.characters.length, npcs: campaign.npcs.length, connectedClients: currentPresence().length, campaignWorkspaces: true, activeCampaignId, activeCampaignName: campaign.name }); return true; }
  if (pathname === '/api/events' && req.method === 'GET') { registerSseClient(req, res, requestUrl); return true; }
  if (pathname === '/api/sync/snapshot' && req.method === 'GET') {
    const mode=requestUrl.searchParams.get('mode')==='master'?'master':'player';
    if(mode==='master'&&!requireMaster(req,res,requestUrl))return true;
    const clientId=cleanId(requestUrl.searchParams.get('clientId'),null);
    sendJson(res,200,{ok:true,campaign:campaignViewFor(mode,clientId),battlemap:battlemapModule?.viewFor?.(mode,clientId)||null,sync:currentSyncState()});
    return true;
  }
  if (pathname === '/api/sync/force' && req.method === 'POST') {
    const body=await readJsonBody(req);if(!requireMaster(req,res,requestUrl,body))return true;
    const sync=broadcastSyncRequired('master-force-sync',cleanId(body.clientId,null));
    sendJson(res,200,{ok:true,sync});return true;
  }
  if (pathname === '/api/network/ping' && req.method === 'GET') {
    const presenceToken = String(requestUrl.searchParams.get('presenceToken') || '').trim();
    const client = presenceToken ? sseClients.get(presenceToken) : null;
    if (!client) { sendJson(res, 404, { ok:false, error:'Соединение не найдено.' }); return true; }
    const previousPing = Number(client.lastPingMs);
    const sample = Number(requestUrl.searchParams.get('sample'));
    if (Number.isFinite(sample) && sample >= 0 && sample <= 60_000) client.lastPingMs = Math.round(sample);
    client.lastHeartbeatAt = nowIso();
    const qualityChanged = presenceQuality(previousPing) !== presenceQuality(client.lastPingMs);
    const delta = Number.isFinite(previousPing) && Number.isFinite(Number(client.lastPingMs)) ? Math.abs(previousPing - Number(client.lastPingMs)) : 9999;
    if (qualityChanged || delta >= 10 || Date.now() - lastPresenceMetricBroadcastAt >= 30_000) schedulePresenceMetricBroadcast();
    sendJson(res, 200, { ok:true, serverAt:Date.now(), sync:currentSyncState() });
    return true;
  }
  if (pathname === '/api/presence' && req.method === 'GET') { if (!requireMaster(req, res, requestUrl)) return true; sendJson(res, 200, { clients: currentPresence() }); return true; }
  if (pathname === '/api/launcher/campaigns' && req.method === 'GET') {
    const mode = requestUrl.searchParams.get('mode') === 'master' ? 'master' : 'player';
    if (mode === 'master') {
      if (!requireMaster(req, res, requestUrl)) return true;
      sendJson(res, 200, { ok:true, mode, activeId:activeCampaignId, campaigns:campaignListView(), server:{ version:VERSION, activeCampaignName:campaign.name } });
      return true;
    }
    const clientId = cleanId(requestUrl.searchParams.get('clientId'), null);
    sendJson(res, 200, { ok:true, mode, activeId:activeCampaignId, campaigns:playerCampaignListView(clientId), server:{ version:VERSION, activeCampaignName:campaign.name } });
    return true;
  }

  async function importCampaignBackupPayload(raw, options = {}) {
    let payload = raw;
    if (raw?.format === 'fatum-campaign' || (Array.isArray(raw?.characters) && !raw?.campaign)) payload = { format:'fatum-snapshot', version:1, campaign:raw, history:[] };
    if (payload?.format !== 'fatum-snapshot' || !payload.campaign || typeof payload.campaign !== 'object') {
      throw Object.assign(new Error('Файл не является backup/snapshot FATUM или campaign.json.'), { statusCode: 400 });
    }
    const id = `campaign_${Date.now()}_${Math.random().toString(16).slice(2,8)}`;
    const importedName = cleanName(options.name || payload.campaign.name || `Импорт ${campaignIndex.campaigns.length + 1}`, 'Импортированная кампания');
    const record = { id, name:importedName, cover:null, coverUpdatedAt:null, createdAt:nowIso(), updatedAt:nowIso(), lastOpenedAt:nowIso() };
    campaignIndex.campaigns.push(record); ensureCampaignWorkspace(id, record.name); persistCampaignIndexSync();
    await activateCampaignWorkspace(id, options.clientId);
    if (options.archivePackage) {
      await restoreArchiveAssets(options.archivePackage);
      await restoreArchiveCover(options.archivePackage, record);
    }
    campaign = normalizeCampaign(payload.campaign); campaign.campaignId=id; campaign.name=importedName;
    history = Array.isArray(payload.history) ? payload.history.slice(-HISTORY_LIMIT) : [];
    if (payload.portraits && typeof payload.portraits === 'object') {
      for (const [portraitName, encoded] of Object.entries(payload.portraits)) {
        if (!/^[A-Za-z0-9_.-]+\.(?:png|jpe?g|webp|gif)$/i.test(portraitName) || typeof encoded !== 'string') continue;
        const buffer=Buffer.from(encoded,'base64'); if(buffer.length&&buffer.length<=12*1024*1024) await fs.promises.writeFile(path.join(PORTRAIT_DIR,portraitName),buffer);
      }
    }
    if (battlemapModule) await battlemapModule.restorePayload(payload);
    record.name=campaign.name; record.updatedAt=nowIso();
    await Promise.all([persistCampaign(),persistHistory()]); persistCampaignIndexSync();
    const importedSnapshot=await createSnapshot('imported-backup');
    broadcastCampaignReplaced(options.clientId,'campaign-import-backup'); battlemapModule?.broadcast?.('battlemap-replaced',options.clientId,{reason:'campaign-import-backup',campaignId:id});
    return { ok:true, activeId:id, campaign:record, snapshot:importedSnapshot, campaigns:campaignListView() };
  }

  if (pathname === '/api/campaigns/export' && req.method === 'GET') {
    if (!requireMaster(req, res, requestUrl)) return true;
    const mode = requestUrl.searchParams.get('mode') === 'compact' ? 'compact' : 'full';
    const result = await createCampaignArchive(mode);
    const timestamp = new Date().toISOString().slice(0,19).replace(/:/g,'-');
    const fileName = `${safeArchiveBaseName(campaign.name)}-${mode}-${timestamp}.fatum`;
    sendDownloadBuffer(res, result.buffer, fileName, 'application/vnd.fatum.campaign+zip', {
      'X-Fatum-Archive-Mode': mode,
      'X-Fatum-Source-Bytes': String(result.manifest.stats.sourceBytes || 0),
      'X-Fatum-Stored-Bytes': String(result.manifest.stats.storedBytes || 0),
      'X-Fatum-Optimized-Count': String(result.manifest.stats.optimizedCount || 0),
      'X-Fatum-Deduplicated-Count': String(result.manifest.stats.deduplicated || 0),
      'X-Fatum-Omitted-Unused': String(result.manifest.stats.omittedUnusedFiles || 0),
      'X-Fatum-Compact-Processor': String(result.manifest.compactProcessor || 'none')
    });
    return true;
  }

  if (pathname === '/api/campaigns/assets/cleanup' && req.method === 'POST') {
    const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true;
    const result = await cleanupUnusedAssets();
    recordHistory({ actor:actorFrom(body,'master'), action:'asset-cleanup', entityType:'campaign', summary:`Неиспользуемые ресурсы перемещены: ${result.moved} файлов`, undoData:null });
    await persistHistory();
    sendJson(res,200,{ok:true,...result}); return true;
  }

  if (pathname === '/api/campaigns/import-backup-file' && req.method === 'POST') {
    if (!requireMaster(req, res, requestUrl)) { req.resume(); return true; }
    const declaredSize = Number(req.headers['content-length'] || 0);
    if (declaredSize > MAX_IMPORT_BYTES) {
      req.resume();
      sendJson(res, 413, { ok:false, error:'Файл кампании превышает предел 512 МБ.' });
      return true;
    }
    const imported = await readCampaignSnapshotBody(req);
    const options = {
      name: requestUrl.searchParams.get('name') || req.headers['x-fatum-campaign-name'],
      clientId: requestUrl.searchParams.get('clientId') || req.headers['x-fatum-client-id'],
      archivePackage: imported.archivePackage
    };
    const result = await importCampaignBackupPayload(imported.payload, options);
    sendJson(res, 201, result); return true;
  }

  if (pathname === '/api/campaigns/import-backup' && req.method === 'POST') {
    const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true;
    const raw = body.snapshot && typeof body.snapshot === 'object' ? body.snapshot : body;
    const result = await importCampaignBackupPayload(raw, { name:body.name, clientId:body.clientId });
    sendJson(res, 201, result); return true;
  }

  if (pathname === '/api/campaigns' && req.method === 'GET') {
    if (!requireMaster(req, res, requestUrl)) return true;
    sendJson(res, 200, { ok:true, activeId:activeCampaignId, campaigns:campaignListView() }); return true;
  }
  if (pathname === '/api/campaigns' && req.method === 'POST') {
    const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true;
    const id = `campaign_${Date.now()}_${Math.random().toString(16).slice(2,8)}`;
    const record = { id, name:cleanName(body.name, `Кампания ${campaignIndex.campaigns.length + 1}`), cover:null, coverUpdatedAt:null, createdAt:nowIso(), updatedAt:nowIso(), lastOpenedAt:nowIso() };
    campaignIndex.campaigns.push(record); ensureCampaignWorkspace(id, record.name); persistCampaignIndexSync();
    if (body.activate !== false) await activateCampaignWorkspace(id, body.clientId);
    sendJson(res, 201, { ok:true, campaign:record, activeId:activeCampaignId, campaigns:campaignListView() }); return true;
  }
  const campaignCoverMatch = pathname.match(/^\/api\/campaigns\/([^/]+)\/cover$/);
  if (campaignCoverMatch) {
    const id = cleanId(decodeURIComponent(campaignCoverMatch[1]), null);
    const record = campaignIndex.campaigns.find(item => item.id === id);
    if (!record) { sendJson(res,404,{ok:false,error:'Кампания не найдена.'}); return true; }
    if (req.method === 'POST') {
      if (!requireMaster(req,res,requestUrl)) { req.resume(); return true; }
      const declaredSize = Number(req.headers['content-length'] || 0);
      if (declaredSize > MAX_CAMPAIGN_COVER_BYTES) { req.resume(); sendJson(res,413,{ok:false,error:'Обложка превышает предел 16 МБ.'}); return true; }
      const fileNameHint = requestUrl.searchParams.get('name') || req.headers['x-fatum-file-name'] || '';
      const extension = coverExtensionFromMime(req.headers['content-type'], fileNameHint);
      if (!extension) { req.resume(); sendJson(res,400,{ok:false,error:'Поддерживаются PNG, JPEG, WebP и GIF.'}); return true; }
      const buffer = await readRequestBuffer(req, MAX_CAMPAIGN_COVER_BYTES, 'Обложка превышает предел 16 МБ.');
      if (!buffer.length) { sendJson(res,400,{ok:false,error:'Файл обложки пуст.'}); return true; }
      const dir = path.join(CAMPAIGNS_DIR,id);
      await fs.promises.mkdir(dir,{recursive:true});
      for (const name of await fs.promises.readdir(dir)) if (/^cover\.(?:png|jpe?g|webp|gif)$/i.test(name)) await fs.promises.unlink(path.join(dir,name)).catch(()=>{});
      const fileName = `cover.${extension}`;
      await fs.promises.writeFile(path.join(dir,fileName),buffer);
      record.cover=fileName; record.coverUpdatedAt=nowIso(); record.updatedAt=record.coverUpdatedAt;
      persistCampaignIndexSync();
      sendJson(res,200,{ok:true,campaign:{...record,coverUrl:campaignCoverUrl(record)},campaigns:campaignListView()}); return true;
    }
    if (req.method === 'DELETE') {
      const body = await readJsonBody(req).catch(()=>({})); if(!requireMaster(req,res,requestUrl,body))return true;
      const fileName=cleanCoverFileName(record.cover); if(fileName)await fs.promises.unlink(path.join(CAMPAIGNS_DIR,id,fileName)).catch(()=>{});
      record.cover=null;record.coverUpdatedAt=nowIso();record.updatedAt=record.coverUpdatedAt;persistCampaignIndexSync();
      sendJson(res,200,{ok:true,campaign:{...record,coverUrl:null},campaigns:campaignListView()});return true;
    }
  }

  const campaignWorkspaceMatch = pathname.match(/^\/api\/campaigns\/([^/]+)$/);
  if (campaignWorkspaceMatch) {
    const id = cleanId(decodeURIComponent(campaignWorkspaceMatch[1]), null);
    const record = campaignIndex.campaigns.find(item => item.id === id);
    if (!record) { sendJson(res, 404, { ok:false, error:'Кампания не найдена.' }); return true; }
    if (req.method === 'PUT') {
      const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true;
      record.name = cleanName(body.name, record.name); record.updatedAt = nowIso();
      const file = path.join(CAMPAIGNS_DIR, id, 'campaign.json');
      try { const raw=normalizeCampaign(JSON.parse(fs.readFileSync(file,'utf8'))); raw.campaignId=id; raw.name=record.name; fs.writeFileSync(file,JSON.stringify(raw,null,2),'utf8'); if(id===activeCampaignId){campaign.name=record.name;await persistCampaign();broadcastCampaignReplaced(body.clientId,'campaign-rename');} } catch {}
      persistCampaignIndexSync(); sendJson(res,200,{ok:true,campaign:record,campaigns:campaignListView()}); return true;
    }
    if (req.method === 'DELETE') {
      const body = await readJsonBody(req).catch(()=>({})); if (!requireMaster(req,res,requestUrl,body)) return true;
      if (id === activeCampaignId) { sendJson(res,409,{ok:false,error:'Сначала переключитесь на другую кампанию.'}); return true; }
      if (campaignIndex.campaigns.length <= 1) { sendJson(res,409,{ok:false,error:'Нельзя удалить единственную кампанию.'}); return true; }
      const trashDir=path.join(DATA_DIR,'campaigns-trash');fs.mkdirSync(trashDir,{recursive:true});const source=path.join(CAMPAIGNS_DIR,id),target=path.join(trashDir,`${id}-${Date.now()}`);if(fs.existsSync(source))fs.renameSync(source,target);
      campaignIndex.campaigns=campaignIndex.campaigns.filter(item=>item.id!==id);persistCampaignIndexSync();sendJson(res,200,{ok:true,campaigns:campaignListView()});return true;
    }
  }
  const activateCampaignMatch = pathname.match(/^\/api\/campaigns\/([^/]+)\/activate$/);
  if (activateCampaignMatch && req.method === 'POST') {
    const body=await readJsonBody(req);if(!requireMaster(req,res,requestUrl,body))return true;
    const record=await activateCampaignWorkspace(cleanId(decodeURIComponent(activateCampaignMatch[1]),null),body.clientId);
    sendJson(res,200,{ok:true,activeId:activeCampaignId,campaign:record,campaigns:campaignListView()});return true;
  }
  if (pathname === '/api/campaign' && req.method === 'GET') { const mode = requestUrl.searchParams.get('mode') === 'master' ? 'master' : 'player'; if (mode === 'master' && !requireMaster(req, res, requestUrl)) return true; sendJson(res, 200, campaignViewFor(mode, cleanId(requestUrl.searchParams.get('clientId'), null))); return true; }

  if (pathname === '/api/campaign/import' && req.method === 'POST') {
    const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true; const before = clone(campaign); const incoming = Array.isArray(body.characters) ? body.characters : []; const mode = body.mode === 'replace' ? 'replace' : 'merge'; const used = new Set(mode === 'merge' ? campaign.characters.map(item => item.id) : []); const imported = [];
    for (const [index, raw] of incoming.entries()) { const character = normalizeCharacter(raw, index, false); while (used.has(character.id)) character.id = makeId('char_import'); used.add(character.id); character.revision = 1; character.updatedBy = cleanId(body.clientId, null); imported.push(character); }
    if (mode === 'replace') campaign.characters = imported; else campaign.characters.push(...imported); if (body.name) campaign.name = cleanName(body.name, campaign.name);
    await commitChange({ actor: actorFrom(body, 'master'), action: 'campaign-import', entityType: 'campaign', summary: `Импортировано персонажей: ${imported.length}`, undoData: { kind: 'restore-campaign', campaign: before } }, { backupBefore: `before-import-${mode}` });
    broadcastCampaignReplaced(body.clientId, `import_${mode}`); sendJson(res, 200, { ok: true, imported: imported.length, campaign }); return true;
  }

  if (pathname === '/api/characters' && req.method === 'POST') {
    const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true; const character = normalizeCharacter({ id: body.id || makeId('char'), name: body.name, state: body.state, portrait: body.portrait, ownerId: body.ownerId, ownerName: body.ownerName, visibility: body.visibility }, campaign.characters.length, false); while (campaign.characters.some(item => item.id === character.id)) character.id = makeId('char'); character.revision = 1; character.updatedBy = cleanId(body.clientId, null); campaign.characters.push(character);
    await commitChange({ actor: actorFrom(body, 'master'), action: 'character-create', entityType: 'character', entityId: character.id, summary: `Создан персонаж «${character.name}»`, undoData: { kind: 'delete-character', characterId: character.id } });
    broadcastCampaignReplaced(body.clientId, 'character-created'); sendJson(res, 201, { ok: true, character }); return true;
  }

  const assignmentMatch = pathname.match(/^\/api\/characters\/([^/]+)\/assignment$/);
  if (assignmentMatch && req.method === 'PUT') {
    const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true; const id = cleanId(decodeURIComponent(assignmentMatch[1]), null); const index = campaign.characters.findIndex(item => item.id === id); if (index < 0) return sendJson(res, 404, { ok: false, error: 'Персонаж не найден.' }), true; const before = clone(campaign.characters[index]); const ownerId = cleanId(body.ownerId, null); const updated = { ...before, ownerId, ownerName: ownerId ? cleanName(body.ownerName, 'Игрок') : null, revision: before.revision + 1, updatedAt: nowIso(), updatedBy: cleanId(body.clientId, null) }; campaign.characters[index] = updated;
    const synchronizedTokens = battlemapModule?.syncCharacterOwner ? await battlemapModule.syncCharacterOwner(id, ownerId) : 0;
    await commitChange({ actor: actorFrom(body, 'master'), action: 'assignment', entityType: 'character', entityId: id, summary: ownerId ? `«${updated.name}» закреплён за ${updated.ownerName}` : `Закрепление «${updated.name}» снято`, undoData: { kind: 'restore-character', character: before } }, { backupBefore: 'before-assignment' });
    broadcastCampaignReplaced(body.clientId, 'assignment'); battlemapModule?.broadcast?.('battlemap-replaced', body.clientId, { reason: 'character-assignment', characterId: id }); sendJson(res, 200, { ok: true, character: updated, synchronizedTokens }); return true;
  }

  const visibilityMatch = pathname.match(/^\/api\/characters\/([^/]+)\/visibility$/);
  if (visibilityMatch && req.method === 'PUT') {
    const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true; const id = cleanId(decodeURIComponent(visibilityMatch[1]), null); const index = campaign.characters.findIndex(item => item.id === id); if (index < 0) return sendJson(res, 404, { ok: false, error: 'Персонаж не найден.' }), true; const before = clone(campaign.characters[index]); const updated = { ...before, visibility: validVisibility(body.visibility), revision: before.revision + 1, updatedAt: nowIso(), updatedBy: cleanId(body.clientId, null) }; campaign.characters[index] = updated;
    await commitChange({ actor: actorFrom(body, 'master'), action: 'visibility', entityType: 'character', entityId: id, summary: `Доступ к «${updated.name}»: ${updated.visibility}`, undoData: { kind: 'restore-character', character: before } });
    broadcastCampaignReplaced(body.clientId, 'visibility'); sendJson(res, 200, { ok: true, character: updated }); return true;
  }

  const quickMatch = pathname.match(/^\/api\/characters\/([^/]+)\/quick-action$/);
  if (quickMatch && req.method === 'POST') {
    const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true; const id = cleanId(decodeURIComponent(quickMatch[1]), null); const index = campaign.characters.findIndex(item => item.id === id); if (index < 0) return sendJson(res, 404, { ok: false, error: 'Персонаж не найден.' }), true; const before = clone(campaign.characters[index]); const state = quickActionState(before.state, body); const updated = { ...before, state, revision: before.revision + 1, updatedAt: nowIso(), updatedBy: cleanId(body.clientId, null) }; campaign.characters[index] = updated;
    await commitChange({ actor: actorFrom(body, 'master'), action: 'quick-action', entityType: 'character', entityId: id, summary: `Быстрое действие для «${updated.name}»: ${summarizeCharacterDiff(before, updated)}`, undoData: { kind: 'restore-character', character: before } });
    broadcastCharacterUpdated(updated, body.clientId); sendJson(res, 200, { ok: true, character: updated }); return true;
  }

  const characterMatch = pathname.match(/^\/api\/characters\/([^/]+)$/);
  if (characterMatch) {
    const id = cleanId(decodeURIComponent(characterMatch[1]), null); const index = campaign.characters.findIndex(item => item.id === id); if (index < 0) return sendJson(res, 404, { ok: false, error: 'Персонаж не найден.' }), true; const current = campaign.characters[index];
    if (req.method === 'GET') { if (isMasterAuthorized(req, requestUrl) || current.ownerId === clientIdFrom(null, requestUrl)) return sendJson(res, 200, current), true; const shared = sharedCharacterView(current); if (!shared) return sendJson(res, 403, { ok: false, error: 'Этот лист скрыт.' }), true; return sendJson(res, 200, shared), true; }
    if (req.method === 'PUT') {
      const body = await readJsonBody(req); if (!canEditCharacter(current, req, requestUrl, body)) return sendJson(res, 403, { ok: false, error: 'Этот персонаж закреплён за другим игроком.' }), true; const baseRevision = Number.parseInt(body.baseRevision, 10); if (Number.isFinite(baseRevision) && baseRevision !== current.revision) return sendJson(res, 409, { ok: false, error: 'Состояние персонажа уже изменилось.', character: current }), true;
      const incomingState = normalizeState(body.state); let portrait = current.portrait; if (Object.prototype.hasOwnProperty.call(body, 'portrait')) portrait = normalizePortrait(id, body.portrait, typeof body.portrait === 'string' && body.portrait.startsWith('/portraits/') ? current.portrait : null);
      const updated = { ...current, name: cleanName(body.name || incomingState.name, current.name), revision: current.revision + 1, state: incomingState, portrait, updatedAt: nowIso(), updatedBy: cleanId(body.clientId, null) }; campaign.characters[index] = updated;
      await commitChange({ actor: actorFrom(body, isMasterAuthorized(req, requestUrl, body) ? 'master' : 'player'), action: 'character-update', entityType: 'character', entityId: id, summary: `«${updated.name}»: ${summarizeCharacterDiff(current, updated)}`, undoData: { kind: 'restore-character', character: clone(current) } });
      broadcastCharacterUpdated(updated, body.clientId); sendJson(res, 200, { ok: true, character: updated }); return true;
    }
    if (req.method === 'DELETE') {
      const body = await readJsonBody(req).catch(() => ({})); if (!requireMaster(req, res, requestUrl, body)) return true; const removed = campaign.characters.splice(index, 1)[0]; campaign.initiative.entries = campaign.initiative.entries.filter(entry => !(entry.type === 'character' && entry.refId === id));
      await commitChange({ actor: actorFrom(body, 'master'), action: 'character-delete', entityType: 'character', entityId: id, summary: `Удалён персонаж «${removed.name}»`, undoData: { kind: 'insert-character', character: removed } }, { backupBefore: 'before-character-delete' });
      broadcastCampaignReplaced(body.clientId, 'character-deleted'); sendJson(res, 200, { ok: true, character: removed }); return true;
    }
  }

  if (pathname === '/api/custom-attacks' && req.method === 'POST') {
    const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true;
    const targetType = body.targetType === 'character' ? 'character' : 'npc';
    const targetId = cleanId(body.targetId, null);
    const attack = normalizeCustomAttack(body.attack, 0);
    if (!targetId) { sendJson(res, 400, { ok:false, error:'Не выбрана цель для профиля атаки.' }); return true; }
    if (targetType === 'npc') {
      const index = campaign.npcs.findIndex(item => item.id === targetId);
      if (index < 0) { sendJson(res, 404, { ok:false, error:'NPC не найден.' }); return true; }
      const before = clone(campaign.npcs[index]);
      const list = Array.isArray(campaign.npcs[index].attacks) ? campaign.npcs[index].attacks : [];
      const existing = list.findIndex(item => item.id === attack.id);
      if (existing >= 0) list[existing] = attack; else list.push(attack);
      campaign.npcs[index].attacks = list.slice(0, 30); campaign.npcs[index].updatedAt = nowIso();
      await commitChange({ actor:actorFrom(body,'master'), action:'custom-attack-save', entityType:'npc', entityId:targetId, summary:`${campaign.npcs[index].name}: сохранён профиль «${attack.name}»`, undoData:{kind:'restore-module',module:'npcs',before:campaign.npcs.map((item,i)=>i===index?before:item)} });
      broadcastCampaignReplaced(body.clientId, 'custom-attack-updated'); sendJson(res, 200, { ok:true, targetType, attack, npc:campaign.npcs[index] }); return true;
    }
    const index = campaign.characters.findIndex(item => item.id === targetId);
    if (index < 0) { sendJson(res, 404, { ok:false, error:'Персонаж не найден.' }); return true; }
    const before = clone(campaign.characters[index]); const character = campaign.characters[index]; character.state ||= {};
    const list = Array.isArray(character.state._lanCustomWeapons) ? character.state._lanCustomWeapons : [];
    const existing = list.findIndex(item => item.id === attack.id);
    if (existing >= 0) list[existing] = attack; else list.push(attack);
    character.state._lanCustomWeapons = list.slice(0, 30); character.revision += 1; character.updatedAt = nowIso(); character.updatedBy = cleanId(body.clientId, null);
    await commitChange({ actor:actorFrom(body,'master'), action:'custom-attack-save', entityType:'character', entityId:targetId, summary:`${character.name}: сохранён профиль «${attack.name}»`, undoData:{kind:'restore-character',character:before} });
    broadcastCharacterUpdated(character, body.clientId); sendJson(res, 200, { ok:true, targetType, attack, character }); return true;
  }
  const customAttackDeleteMatch = pathname.match(/^\/api\/custom-attacks\/(npc|character)\/([^/]+)\/([^/]+)$/);
  if (customAttackDeleteMatch && req.method === 'DELETE') {
    const body = await readJsonBody(req).catch(() => ({})); if (!requireMaster(req, res, requestUrl, body)) return true;
    const targetType = customAttackDeleteMatch[1], targetId = cleanId(decodeURIComponent(customAttackDeleteMatch[2]), null), attackId = cleanId(decodeURIComponent(customAttackDeleteMatch[3]), null);
    if (targetType === 'npc') {
      const index = campaign.npcs.findIndex(item => item.id === targetId); if (index < 0) { sendJson(res,404,{ok:false,error:'NPC не найден.'}); return true; }
      const before = clone(campaign.npcs); campaign.npcs[index].attacks = (campaign.npcs[index].attacks || []).filter(item => item.id !== attackId); campaign.npcs[index].updatedAt = nowIso();
      await commitChange({actor:actorFrom(body,'master'),action:'custom-attack-delete',entityType:'npc',entityId:targetId,summary:`${campaign.npcs[index].name}: удалён пользовательский профиль`,undoData:{kind:'restore-module',module:'npcs',before}});
      broadcastCampaignReplaced(body.clientId,'custom-attack-deleted');sendJson(res,200,{ok:true,npc:campaign.npcs[index]});return true;
    }
    const index = campaign.characters.findIndex(item => item.id === targetId); if (index < 0) { sendJson(res,404,{ok:false,error:'Персонаж не найден.'}); return true; }
    const before = clone(campaign.characters[index]), character = campaign.characters[index]; character.state ||= {}; character.state._lanCustomWeapons = (character.state._lanCustomWeapons || []).filter(item => item.id !== attackId); character.revision += 1; character.updatedAt=nowIso(); character.updatedBy=cleanId(body.clientId,null);
    await commitChange({actor:actorFrom(body,'master'),action:'custom-attack-delete',entityType:'character',entityId:targetId,summary:`${character.name}: удалён пользовательский профиль`,undoData:{kind:'restore-character',character:before}});
    broadcastCharacterUpdated(character,body.clientId);sendJson(res,200,{ok:true,character});return true;
  }

  if (pathname === '/api/npcs' && req.method === 'POST') {
    const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true; const before = clone(campaign.npcs); const npc = normalizeNpc(body, campaign.npcs.length); while (campaign.npcs.some(item => item.id === npc.id)) npc.id = makeId('npc'); campaign.npcs.push(npc);
    await commitChange({ actor: actorFrom(body, 'master'), action: 'npc-create', entityType: 'npcs', entityId: npc.id, summary: `Создан NPC «${npc.name}»`, undoData: { kind: 'restore-module', module: 'npcs', before } }); broadcastCampaignReplaced(body.clientId, 'npc-created'); sendJson(res, 201, { ok: true, npc }); return true;
  }
  const npcMatch = pathname.match(/^\/api\/npcs\/([^/]+)$/);
  if (npcMatch) {
    const id = cleanId(decodeURIComponent(npcMatch[1]), null); const index = campaign.npcs.findIndex(item => item.id === id); if (index < 0) return sendJson(res, 404, { ok: false, error: 'NPC не найден.' }), true;
    if (req.method === 'PUT') { const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true; const before = clone(campaign.npcs); const npc = normalizeNpc({ ...campaign.npcs[index], ...body, id }, index); campaign.npcs[index] = npc; await commitChange({ actor: actorFrom(body, 'master'), action: 'npc-update', entityType: 'npcs', entityId: id, summary: `Обновлён NPC «${npc.name}»`, undoData: { kind: 'restore-module', module: 'npcs', before } }); broadcastCampaignReplaced(body.clientId, 'npc-updated'); sendJson(res, 200, { ok: true, npc }); return true; }
    if (req.method === 'DELETE') { const body = await readJsonBody(req).catch(() => ({})); if (!requireMaster(req, res, requestUrl, body)) return true; const before = clone(campaign.npcs); const npc = campaign.npcs.splice(index, 1)[0]; campaign.initiative.entries = campaign.initiative.entries.filter(entry => !(entry.type === 'npc' && entry.refId === id)); await commitChange({ actor: actorFrom(body, 'master'), action: 'npc-delete', entityType: 'npcs', entityId: id, summary: `Удалён NPC «${npc.name}»`, undoData: { kind: 'restore-module', module: 'npcs', before } }, { backupBefore: 'before-npc-delete' }); broadcastCampaignReplaced(body.clientId, 'npc-deleted'); sendJson(res, 200, { ok: true, npc }); return true; }
  }

  if (pathname === '/api/initiative' && req.method === 'PUT') {
    const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true; const before = clone(campaign.initiative); campaign.initiative = normalizeInitiative(body.initiative || body, new Set(campaign.characters.map(item => item.id)), new Set(campaign.npcs.map(item => item.id)));
    await commitChange({ actor: actorFrom(body, 'master'), action: 'initiative-update', entityType: 'initiative', summary: `Обновлена инициатива, участников: ${campaign.initiative.entries.length}`, undoData: { kind: 'restore-module', module: 'initiative', before } }); broadcastCampaignReplaced(body.clientId, 'initiative'); sendJson(res, 200, { ok: true, initiative: campaign.initiative }); return true;
  }
  if (pathname === '/api/initiative/roll' && req.method === 'POST') {
    const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true;
    const before = clone(campaign.initiative); const mode = body.mode === 'all' ? 'all' : 'current';
    let refs = mode === 'all'
      ? [...campaign.characters.map(item => ({ type: 'character', refId: item.id })), ...campaign.npcs.map(item => ({ type: 'npc', refId: item.id }))]
      : campaign.initiative.entries.map(item => ({ type: item.type, refId: item.refId }));
    const unique = new Set(); refs = refs.filter(item => { const key = `${item.type}:${item.refId}`; if (unique.has(key)) return false; unique.add(key); return true; });
    const profiles = body.characterProfiles && typeof body.characterProfiles === 'object' ? body.characterProfiles : {};
    const participants = [];
    for (const ref of refs) {
      if (ref.type === 'npc') {
        const npc = campaign.npcs.find(item => item.id === ref.refId); if (!npc || npc.outOfCombat) continue;
        participants.push({ type: 'npc', refId: npc.id, cube: npc.successDie, bonus: npc.characteristics.concentration });
      } else {
        const character = campaign.characters.find(item => item.id === ref.refId); if (!character) continue;
        const supplied = profiles[character.id]; const profile = supplied && typeof supplied === 'object'
          ? { cube: normalizeDie(supplied.cube, '1d6'), bonus: Math.round(safeNumber(supplied.bonus, 0)) }
          : fallbackCharacterSkillProfile(character.state, 'Бдительность');
        participants.push({ type: 'character', refId: character.id, cube: profile.cube, bonus: profile.bonus });
      }
    }
    campaign.initiative = { round: body.keepRound ? Math.max(1, campaign.initiative.round) : 1, currentIndex: 0, entries: rollInitiativeParticipants(participants) };
    for (const entry of campaign.initiative.entries) if (entry.type === 'npc') { const npc = campaign.npcs.find(item => item.id === entry.refId); if (npc) npc.initiative = entry.score; }
    await commitChange({ actor: actorFrom(body, 'master'), action: 'initiative-roll', entityType: 'initiative', summary: `Инициатива брошена по Бдительности, участников: ${campaign.initiative.entries.length}`, undoData: { kind: 'restore-module', module: 'initiative', before } });
    broadcastCampaignReplaced(body.clientId, 'initiative-roll'); sendJson(res, 200, { ok: true, initiative: campaign.initiative }); return true;
  }

  if (pathname === '/api/initiative/advance' && req.method === 'POST') {
    const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true; const before = clone(campaign.initiative); const count = campaign.initiative.entries.length; if (count) { campaign.initiative.currentIndex += body.direction === 'back' ? -1 : 1; if (campaign.initiative.currentIndex >= count) { campaign.initiative.currentIndex = 0; campaign.initiative.round += 1; } if (campaign.initiative.currentIndex < 0) { campaign.initiative.round = Math.max(1, campaign.initiative.round - 1); campaign.initiative.currentIndex = count - 1; } }
    await commitChange({ actor: actorFrom(body, 'master'), action: 'initiative-advance', entityType: 'initiative', summary: `Раунд ${campaign.initiative.round}, ход ${campaign.initiative.currentIndex + 1}`, undoData: { kind: 'restore-module', module: 'initiative', before } }); broadcastCampaignReplaced(body.clientId, 'initiative-advance'); sendJson(res, 200, { ok: true, initiative: campaign.initiative }); return true;
  }

  if (pathname === '/api/cargo' && req.method === 'PUT') {
    const body = await readJsonBody(req); const master = isMasterAuthorized(req, requestUrl, body); if (!master && !campaign.cargo.playerCanEdit) return sendJson(res, 403, { ok: false, error: 'Редактирование общего груза отключено мастером.' }), true; const before = clone(campaign.cargo); campaign.cargo = normalizeCargo(body.cargo || body);
    await commitChange({ actor: actorFrom(body, master ? 'master' : 'player'), action: 'cargo-update', entityType: 'cargo', summary: `Общий груз обновлён, предметов: ${campaign.cargo.items.length}`, undoData: { kind: 'restore-module', module: 'cargo', before } }); broadcastCampaignReplaced(body.clientId, 'cargo'); sendJson(res, 200, { ok: true, cargo: campaign.cargo }); return true;
  }

  if (pathname === '/api/global-effects' && req.method === 'POST') {
    const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true; const before = clone(campaign.globalEffects); const effect = normalizeGlobalEffects([{ ...body, id: body.id || makeId('effect'), createdAt: nowIso() }])[0]; campaign.globalEffects.push(effect);
    await commitChange({ actor: actorFrom(body, 'master'), action: 'global-effect-create', entityType: 'globalEffects', entityId: effect.id, summary: `Добавлен глобальный эффект «${effect.name}»`, undoData: { kind: 'restore-module', module: 'globalEffects', before } }); broadcastCampaignReplaced(body.clientId, 'global-effect'); sendJson(res, 201, { ok: true, effect }); return true;
  }
  const effectMatch = pathname.match(/^\/api\/global-effects\/([^/]+)$/);
  if (effectMatch) {
    const id = cleanId(decodeURIComponent(effectMatch[1]), null); const index = campaign.globalEffects.findIndex(item => item.id === id); if (index < 0) return sendJson(res, 404, { ok: false, error: 'Эффект не найден.' }), true;
    if (req.method === 'PUT') { const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true; const before = clone(campaign.globalEffects); campaign.globalEffects[index] = normalizeGlobalEffects([{ ...campaign.globalEffects[index], ...body, id }])[0]; await commitChange({ actor: actorFrom(body, 'master'), action: 'global-effect-update', entityType: 'globalEffects', entityId: id, summary: `Изменён глобальный эффект «${campaign.globalEffects[index].name}»`, undoData: { kind: 'restore-module', module: 'globalEffects', before } }); broadcastCampaignReplaced(body.clientId, 'global-effect'); sendJson(res, 200, { ok: true, effect: campaign.globalEffects[index] }); return true; }
    if (req.method === 'DELETE') { const body = await readJsonBody(req).catch(() => ({})); if (!requireMaster(req, res, requestUrl, body)) return true; const before = clone(campaign.globalEffects); const effect = campaign.globalEffects.splice(index, 1)[0]; await commitChange({ actor: actorFrom(body, 'master'), action: 'global-effect-delete', entityType: 'globalEffects', entityId: id, summary: `Удалён глобальный эффект «${effect.name}»`, undoData: { kind: 'restore-module', module: 'globalEffects', before } }); broadcastCampaignReplaced(body.clientId, 'global-effect'); sendJson(res, 200, { ok: true, effect }); return true; }
  }

  if (pathname === '/api/campaign/timeline' && req.method === 'GET') {
    const mode = requestUrl.searchParams.get('mode') === 'master' ? 'master' : 'player';
    if (mode === 'master' && !requireMaster(req, res, requestUrl)) return true;
    const visibleCharacters = mode === 'master'
      ? campaign.characters
      : campaign.characters.filter(character => character.ownerId === cleanId(requestUrl.searchParams.get('clientId'), null) || (campaign.settings.groupViewEnabled && character.visibility === 'full'));
    sendJson(res, 200, { ok:true, timeline:clone(campaign.timeline), characters:visibleCharacters.map(character => statusForCharacter(character,campaign.timeline)) });
    return true;
  }

  if (pathname === '/api/campaign/timeline' && req.method === 'PUT') {
    const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true;
    const before = clone(campaign); const oldModule = campaign.timeline.modules.exhaustionSleep;
    if (body.day !== undefined || body.minuteOfDay !== undefined) setClock(campaign.timeline, campaign.characters, body.day ?? campaign.timeline.day, body.minuteOfDay ?? campaign.timeline.minuteOfDay);
    if (body.suppliesMode !== undefined || body.suppliesCurrent !== undefined) setSupplies(campaign.timeline, body.suppliesMode ?? campaign.timeline.supplies.mode, body.suppliesCurrent ?? campaign.timeline.supplies.current);
    if (body.exhaustionSleep !== undefined && Boolean(body.exhaustionSleep) !== oldModule) setModuleEnabled(campaign.timeline, campaign.characters, Boolean(body.exhaustionSleep));
    for (const character of campaign.characters) { character.revision = Math.max(1,Math.round(safeNumber(character.revision,1))+1); character.updatedAt=nowIso(); character.updatedBy=cleanId(body.clientId,null); }
    await commitChange({ actor:actorFrom(body,'master'), action:'timeline-update', entityType:'campaign', summary:`Календарь кампании: день ${campaign.timeline.day}, ${String(Math.floor(campaign.timeline.minuteOfDay/60)).padStart(2,'0')}:${String(campaign.timeline.minuteOfDay%60).padStart(2,'0')}; припасы: ${campaign.timeline.supplies.mode==='permanent'?'постоянные':campaign.timeline.supplies.current}; модуль истощения и сна: ${campaign.timeline.modules.exhaustionSleep?'включён':'выключен'}`, undoData:{kind:'restore-campaign',campaign:before} });
    broadcastCampaignReplaced(body.clientId,'timeline-update'); battlemapModule?.broadcast?.('battlemap-replaced',body.clientId,{reason:'timeline-update'});
    sendJson(res,200,{ok:true,timeline:campaign.timeline,characters:campaign.characters.map(character=>statusForCharacter(character,campaign.timeline))}); return true;
  }

  if (pathname === '/api/campaign/survival' && req.method === 'PUT') {
    const body=await readJsonBody(req); if(!requireMaster(req,res,requestUrl,body))return true;
    if(!campaign.timeline.modules.exhaustionSleep){sendJson(res,409,{ok:false,error:'Сначала включите модуль истощения и сна.'});return true;}
    const character=campaign.characters.find(item=>item.id===cleanId(body.characterId,null));
    if(!character){sendJson(res,404,{ok:false,error:'Персонаж не найден.'});return true;}
    const before=clone(campaign), survival=setHungerStage(character,campaign.timeline,String(body.hungerStage||'satiated'));
    character.revision=Math.max(1,Math.round(safeNumber(character.revision,1))+1);character.updatedAt=nowIso();character.updatedBy=cleanId(body.clientId,null);
    await commitChange({actor:actorFrom(body,'master'),action:'survival-stage',entityType:'character',entityId:character.id,summary:`${character.name}: стадия питания — ${survival.hungerStage}`,undoData:{kind:'restore-campaign',campaign:before}});
    broadcastCampaignReplaced(body.clientId,'survival-stage');battlemapModule?.broadcast?.('battlemap-replaced',body.clientId,{reason:'survival-stage',characterId:character.id});
    sendJson(res,200,{ok:true,timeline:campaign.timeline,character:statusForCharacter(character,campaign.timeline)});return true;
  }

  if (pathname === '/api/campaign/time/advance' && req.method === 'POST') {
    const body = await readJsonBody(req); if (!requireMaster(req,res,requestUrl,body)) return true;
    const minutes = clamp(Math.round(safeNumber(body.minutes,0)),1,5256000), before=clone(campaign);
    const result=advanceTime(campaign.timeline,campaign.characters,minutes);
    for(const character of campaign.characters){character.revision=Math.max(1,Math.round(safeNumber(character.revision,1))+1);character.updatedAt=nowIso();character.updatedBy=cleanId(body.clientId,null);}
    await commitChange({actor:actorFrom(body,'master'),action:'time-advance',entityType:'campaign',summary:`Время кампании продвинуто на ${minutes} мин.; день ${campaign.timeline.day}, ${String(Math.floor(campaign.timeline.minuteOfDay/60)).padStart(2,'0')}:${String(campaign.timeline.minuteOfDay%60).padStart(2,'0')}`,undoData:{kind:'restore-campaign',campaign:before}});
    broadcastCampaignReplaced(body.clientId,'time-advance');battlemapModule?.broadcast?.('battlemap-replaced',body.clientId,{reason:'time-advance'});
    sendJson(res,200,{ok:true,result,timeline:campaign.timeline,characters:campaign.characters.map(character=>statusForCharacter(character,campaign.timeline))});return true;
  }

  if (pathname === '/api/campaign/rest' && req.method === 'POST') {
    const body=await readJsonBody(req); if(!requireMaster(req,res,requestUrl,body))return true;
    if (battlemapModule?.getState?.()?.combat?.active) { sendJson(res,409,{ok:false,error:'Нельзя проводить привал во время активного боя. Завершите бой.'}); return true; }
    const kind=body.kind==='long'?'long':'short',before=clone(campaign);
    let result;try{result=applyRest(campaign.timeline,campaign.characters,{kind,participantIds:body.participantIds,fedCharacterIds:body.fedCharacterIds});}catch(error){sendJson(res,error.statusCode||400,{ok:false,error:error.message||'Не удалось провести привал.'});return true;}
    const touched=new Set(result.results.map(item=>item.characterId));
    for(const character of campaign.characters){if(!touched.has(character.id)&&!campaign.timeline.modules.exhaustionSleep)continue;character.revision=Math.max(1,Math.round(safeNumber(character.revision,1))+1);character.updatedAt=nowIso();character.updatedBy=cleanId(body.clientId,null);}
    const healed=result.results.reduce((sum,item)=>sum+item.healing.light+item.healing.medium+item.healing.serious,0),fed=result.results.filter(item=>item.fed).length;
    await commitChange({actor:actorFrom(body,'master'),action:'campaign-rest',entityType:'campaign',summary:`${kind==='long'?'Длительный':'Короткий'} привал: участников ${result.results.length}, накормлено ${fed}, снято ранений ${healed}; день ${campaign.timeline.day}`,undoData:{kind:'restore-campaign',campaign:before}});
    broadcastCampaignReplaced(body.clientId,'campaign-rest');battlemapModule?.broadcast?.('battlemap-replaced',body.clientId,{reason:'campaign-rest'});
    sendJson(res,200,{ok:true,result,timeline:campaign.timeline,characters:campaign.characters.map(character=>statusForCharacter(character,campaign.timeline))});return true;
  }

  if (pathname === '/api/dice/roll' && req.method === 'POST') {
    const body = await readJsonBody(req); const parsed = parseDiceFormula(body.formula); const character = campaign.characters.find(item => item.id === cleanId(body.characterId, null)); const roll = { id: makeId('roll'), at: nowIso(), actorId: cleanId(body.clientId, null), actorName: cleanName(body.playerName, 'Участник'), characterId: character?.id || null, characterName: character?.name || '', label: cleanText(body.label, 200), visibility: body.visibility === 'master' ? 'master' : 'public', ...parsed };
    campaign.diceLog.push(roll); if (campaign.diceLog.length > DICE_LOG_LIMIT) campaign.diceLog.splice(0, campaign.diceLog.length - DICE_LOG_LIMIT); await persistCampaign(); broadcastDice(roll); sendJson(res, 201, { ok: true, roll }); return true;
  }

  if (pathname === '/api/dice/check' && req.method === 'POST') {
    const body = await readJsonBody(req); const character = campaign.characters.find(item => item.id === cleanId(body.characterId, null));
    if (character && !isMasterAuthorized(req, requestUrl, body) && character.ownerId !== cleanId(body.clientId, null)) return sendJson(res, 403, { ok: false, error: 'Нельзя бросать навык чужого персонажа.' }), true;
    const roll = rollSkillCheck(body, character); campaign.diceLog.push(roll); if (campaign.diceLog.length > DICE_LOG_LIMIT) campaign.diceLog.splice(0, campaign.diceLog.length - DICE_LOG_LIMIT);
    await persistCampaign(); broadcastDice(roll); sendJson(res, 201, { ok: true, roll }); return true;
  }

  if (pathname === '/api/settings' && req.method === 'PUT') {
    const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true; const before = clone(campaign.settings); campaign.settings = { groupViewEnabled: body.groupViewEnabled !== false };
    await commitChange({ actor: actorFrom(body, 'master'), action: 'settings-update', entityType: 'settings', summary: `Просмотр группы игроками: ${campaign.settings.groupViewEnabled ? 'включён' : 'выключен'}`, undoData: { kind: 'restore-module', module: 'settings', before } }); broadcastCampaignReplaced(body.clientId, 'settings'); sendJson(res, 200, { ok: true, settings: campaign.settings }); return true;
  }

  if (pathname === '/api/history' && req.method === 'GET') { if (!requireMaster(req, res, requestUrl)) return true; const limit = clamp(Math.round(safeNumber(requestUrl.searchParams.get('limit'), 100)), 1, HISTORY_LIMIT); sendJson(res, 200, { entries: history.slice(-limit).reverse().map(publicHistoryEntry) }); return true; }
  if (pathname === '/api/history' && req.method === 'DELETE') { const body = await readJsonBody(req).catch(() => ({})); if (!requireMaster(req, res, requestUrl, body)) return true; await createSnapshot('before-history-clear'); history = []; await persistHistory(); sendJson(res, 200, { ok: true, entries: [] }); return true; }
  const undoMatch = pathname.match(/^\/api\/history\/([^/]+)\/undo$/);
  if (undoMatch && req.method === 'POST') { const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true; const entry = history.find(item => item.id === cleanId(decodeURIComponent(undoMatch[1]), null)); if (!entry) return sendJson(res, 404, { ok: false, error: 'Запись журнала не найдена.' }), true; await createSnapshot('before-undo'); await undoHistoryEntry(entry, actorFrom(body, 'master')); sendJson(res, 200, { ok: true, campaign, entry: publicHistoryEntry(entry) }); return true; }

  if (pathname === '/api/backups' && req.method === 'GET') { if (!requireMaster(req, res, requestUrl)) return true; const files = (await fs.promises.readdir(BACKUP_DIR)).filter(name => /^snapshot-.*\.json$/.test(name)).sort((a,b) => { const order={quicksave:0,autosave:1,safety:2,manual:3}; const da=order[snapshotDisplayKind(a)]??9,db=order[snapshotDisplayKind(b)]??9; return da-db || b.localeCompare(a); }); const result = await Promise.all(files.slice(0, 100).map(async name => { const stat = await fs.promises.stat(path.join(BACKUP_DIR, name)); return { name, kind:snapshotDisplayKind(name), size: stat.size, modifiedAt: stat.mtime.toISOString() }; })); sendJson(res, 200, { backups: result }); return true; }
  if (pathname === '/api/backups' && req.method === 'POST') { const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true; const reason=cleanName(body.reason, 'manual', 40),slot=['autosave','safety','quicksave'].includes(String(body.slot||'').toLowerCase())?String(body.slot).toLowerCase():null; const name = await createSnapshot(reason,{slot}); sendJson(res, 201, { ok: true, name, kind:snapshotDisplayKind(name) }); return true; }
  const backupMatch = pathname.match(/^\/api\/backups\/([^/]+)$/);
  if (backupMatch && req.method === 'GET') { if (!requireMaster(req, res, requestUrl)) return true; const name = path.basename(decodeURIComponent(backupMatch[1])); if (!/^snapshot-.*\.json$/.test(name)) return sendJson(res, 400, { ok: false, error: 'Некорректное имя снимка.' }), true; serveFile(req, res, path.join(BACKUP_DIR, name), 'no-store'); return true; }
  if (backupMatch && req.method === 'DELETE') { const body = await readJsonBody(req).catch(() => ({})); if (!requireMaster(req, res, requestUrl, body)) return true; const name=path.basename(decodeURIComponent(backupMatch[1])); if(!/^snapshot-.*\.json$/.test(name)) return sendJson(res,400,{ok:false,error:'Некорректное имя снимка.'}),true; const file=path.join(BACKUP_DIR,name); try{await fs.promises.unlink(file);}catch(error){if(error?.code==='ENOENT')return sendJson(res,404,{ok:false,error:'Снимок не найден.'}),true;throw error;} sendJson(res,200,{ok:true,name}); return true; }
  const restoreMatch = pathname.match(/^\/api\/backups\/([^/]+)\/restore$/);
  if (restoreMatch && req.method === 'POST') { const body = await readJsonBody(req); if (!requireMaster(req, res, requestUrl, body)) return true; const name = path.basename(decodeURIComponent(restoreMatch[1])); if (!/^snapshot-.*\.json$/.test(name)) return sendJson(res, 400, { ok: false, error: 'Некорректное имя снимка.' }), true; const payload = JSON.parse(await fs.promises.readFile(path.join(BACKUP_DIR, name), 'utf8')); if (payload.format !== 'fatum-snapshot' || !payload.campaign) return sendJson(res, 400, { ok: false, error: 'Это не снимок FATUM.' }), true; await createSnapshot('before-restore');
    if (payload.portraits && typeof payload.portraits === 'object') {
      for (const [portraitName, encoded] of Object.entries(payload.portraits)) {
        if (!/^[A-Za-z0-9_.-]+\.(?:png|jpe?g|webp|gif)$/i.test(portraitName) || typeof encoded !== 'string') continue;
        const buffer = Buffer.from(encoded, 'base64');
        if (buffer.length && buffer.length <= 12 * 1024 * 1024) await fs.promises.writeFile(path.join(PORTRAIT_DIR, portraitName), buffer);
      }
    }
    campaign = normalizeCampaign(payload.campaign); history = Array.isArray(payload.history) ? payload.history.slice(-HISTORY_LIMIT) : history; if (battlemapModule) await battlemapModule.restorePayload(payload); recordHistory({ actor: actorFrom(body, 'master'), action: 'backup-restore', entityType: 'campaign', summary: `Восстановлен снимок ${name}`, undoData: null }); await Promise.all([persistCampaign(), persistHistory()]); broadcastCampaignReplaced(body.clientId, 'backup-restore'); if (battlemapModule) battlemapModule.broadcast('battlemap-replaced', body.clientId, { reason: 'backup-restore' }); sendJson(res, 200, { ok: true, campaign }); return true; }

  return false;
}

function requestHandler(port) {
  return async (req, res) => {
    applySecurityHeaders(res);
    try {
      const requestUrl = new URL(req.url || '/', `http://${req.headers.host || `localhost:${port}`}`);
      if (requestUrl.pathname.startsWith('/api/')) {
        const mutating = !['GET','HEAD','OPTIONS'].includes(String(req.method || '').toUpperCase());
        if (mutating && !requestOriginAllowed(req)) {
          sendJson(res, 403, { ok:false, error:'Запрос отклонён: недоверенный источник.' });
          return;
        }
        if (mutating) {
          const ip = requestIp(req);
          const rate = API_WRITE_RATE_LIMITER.consume(ip);
          if (!rate.allowed) {
            res.setHeader('Retry-After', String(Math.max(1, Math.ceil(rate.retryAfterMs / 1000))));
            sendJson(res, 429, { ok:false, error:'Слишком много запросов. Повторите действие чуть позже.' });
            return;
          }
          if (/(?:upload|import|cover)/i.test(requestUrl.pathname)) {
            const uploadRate = API_UPLOAD_RATE_LIMITER.consume(ip);
            if (!uploadRate.allowed) {
              res.setHeader('Retry-After', String(Math.max(1, Math.ceil(uploadRate.retryAfterMs / 1000))));
              sendJson(res, 429, { ok:false, error:'Слишком много загрузок с одного клиента.' });
              return;
            }
          }
        }
        const handled = await handleApi(req, res, requestUrl);
        if (!handled) sendJson(res, 404, { ok: false, error: 'API-метод не найден.' });
        return;
      }
      if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, { Allow: 'GET, HEAD' }); return res.end(); }
      if (requestUrl.pathname === '/master') { if (!isLoopbackRequest(req)) return sendText(res, 403, 'Мастерский вход разрешён только на компьютере сервера.'); return redirect(res, '/launcher.html?mode=master', { 'Set-Cookie': `fatum_master_key=${encodeURIComponent(masterKey)}; Path=/; HttpOnly; SameSite=Strict` }); }
      if (requestUrl.pathname === '/master-sheet') { if (!isLoopbackRequest(req)) return sendText(res, 403, 'Мастерский вход разрешён только на компьютере сервера.'); return redirect(res, '/?mode=master', { 'Set-Cookie': `fatum_master_key=${encodeURIComponent(masterKey)}; Path=/; HttpOnly; SameSite=Strict` }); }
      if (requestUrl.pathname === '/master-map') { if (!isLoopbackRequest(req)) return sendText(res, 403, 'Мастерский вход разрешён только на компьютере сервера.'); return redirect(res, `/battlemap.html?mode=master${requestUrl.searchParams.get('noSse') === '1' ? '&noSse=1' : ''}`, { 'Set-Cookie': `fatum_master_key=${encodeURIComponent(masterKey)}; Path=/; HttpOnly; SameSite=Strict` }); }
      if (requestUrl.pathname === '/player') return redirect(res, '/launcher.html?mode=player');
      if (requestUrl.pathname === '/player-sheet') return redirect(res, '/?mode=player');
      if (requestUrl.pathname.startsWith('/campaign-assets/')) {
        const match = /^\/campaign-assets\/([^/]+)\/(portraits)\/([^/]+)$/.exec(requestUrl.pathname);
        if (!match) return sendText(res,400,'Недопустимый путь.');
        const campaignId=cleanId(decodeURIComponent(match[1]),null),category=match[2],fileName=path.basename(decodeURIComponent(match[3]));
        if(!campaignId||!campaignIndex.campaigns.some(item=>item.id===campaignId)||!/^[A-Za-z0-9_.-]+$/.test(fileName))return sendText(res,404,'Ресурс не найден.');
        return serveFile(req,res,path.join(CAMPAIGNS_DIR,campaignId,category,fileName),'public, max-age=86400');
      }
      if (requestUrl.pathname.startsWith('/campaign-covers/')) {
        const match = /^\/campaign-covers\/([^/]+)\/([^/]+)$/.exec(requestUrl.pathname);
        if (!match) return sendText(res,400,'Недопустимый путь.');
        const campaignId=cleanId(decodeURIComponent(match[1]),null),fileName=cleanCoverFileName(decodeURIComponent(match[2]));
        if(!campaignId||!fileName||!campaignIndex.campaigns.some(item=>item.id===campaignId))return sendText(res,404,'Обложка не найдена.');
        return serveFile(req,res,path.join(CAMPAIGNS_DIR,campaignId,fileName),'public, max-age=86400');
      }
      if (requestUrl.pathname.startsWith('/portraits/')) { const file = resolveSafePath(PORTRAIT_DIR, requestUrl.pathname.slice('/portraits/'.length)); if (!file) return sendText(res, 400, 'Недопустимый путь.'); if(!assetFileLooksUsableSync(file))recoverRequestedCampaignAssetSync(requestUrl.pathname,file); return serveFile(req, res, file, 'public, max-age=31536000, immutable'); }
      if (requestUrl.pathname.startsWith('/assets/audio/core/')) { const asset = resolvePublicAsset(PUBLIC_DIR, PUBLIC_OVERRIDE_DIR, requestUrl.pathname); if (!asset) return sendText(res, 400, 'Недопустимый путь.'); return serveFile(req, res, asset.file, 'public, max-age=31536000, immutable'); }
      if (requestUrl.pathname.startsWith('/maps/') || requestUrl.pathname.startsWith('/tokens/') || requestUrl.pathname.startsWith('/audio/') || requestUrl.pathname.startsWith('/shared-audio/')) { const file = battlemapModule?.assetFileFromUrl(requestUrl.pathname); if (!file) return sendText(res, 400, 'Недопустимый путь.'); if(!requestUrl.pathname.startsWith('/shared-audio/')&&!assetFileLooksUsableSync(file))recoverRequestedCampaignAssetSync(requestUrl.pathname,file); return serveFile(req, res, file, 'public, max-age=31536000, immutable'); }
      const asset = resolvePublicAsset(PUBLIC_DIR, PUBLIC_OVERRIDE_DIR, requestUrl.pathname, 'index.html'); if (!asset) return sendText(res, 400, 'Недопустимый путь.'); serveFile(req, res, asset.file);
    } catch (error) { console.error('Ошибка запроса:', error); if (!res.headersSent) sendJson(res, error.statusCode || 500, { ok: false, error: error.message || 'Ошибка сервера.' }); else res.end(); }
  };
}

function getLanAddresses(port) { const result = []; for (const [name, entries] of Object.entries(os.networkInterfaces())) for (const entry of (entries || [])) if (entry.family === 'IPv4' && !entry.internal) result.push({ name, address: entry.address, url: `http://${entry.address}:${port}` }); return result.filter((item, index, all) => all.findIndex(other => other.address === item.address) === index); }
function openBrowser(url) { if (process.env.FATUM_NO_BROWSER === '1') return; try { if (process.platform === 'win32') spawn('cmd', ['/c', 'start', '', url], { detached: true, stdio: 'ignore', windowsHide: true }).unref(); else if (process.platform === 'darwin') spawn('open', [url], { detached: true, stdio: 'ignore' }).unref(); else spawn('xdg-open', [url], { detached: true, stdio: 'ignore' }).unref(); } catch (error) { console.warn('Не удалось открыть браузер:', error.message); } }
function printStartupInfo(port) {
  const local = `http://localhost:${port}`; console.log('\n============================================================'); console.log(` FATUM LAN Server v${VERSION}`); console.log('============================================================'); console.log(` Master launcher: ${local}/master`); console.log(` Battlemap: ${local}/master-map`); console.log(` Player launcher: ${local}/player\n`); const addresses = getLanAddresses(port); if (addresses.length) { console.log(' Player addresses (LAN / Radmin / VPN):'); for (const item of addresses) console.log(`   [${item.name}] ${item.url}/?mode=player`); } console.log(`\n Characters: ${campaign.characters.length} | NPCs: ${campaign.npcs.length}`); console.log(` Active campaign: ${campaign.name} [${activeCampaignId}]`); console.log(` Workspace: data/campaigns/${activeCampaignId}/`); console.log(' Portraits, maps, tokens, campaign audio, history and backups are isolated per campaign. Shared audio is stored in data/shared/audio.'); console.log(' Auto-save: ENABLED (single overwrite slot)'); console.log(' Stop server: Ctrl+C'); console.log('============================================================\n');
}
function startServer(port, attemptsLeft) {
  const server = http.createServer(requestHandler(port));
  server.maxHeadersCount = 100;
  server.headersTimeout = 15_000;
  server.requestTimeout = 5 * 60_000;
  server.keepAliveTimeout = 10_000;
  server.maxRequestsPerSocket = 2000;
  const keepAlive = setInterval(() => { for (const client of sseClients.values()) try { client.response.write(`: keepalive ${Date.now()}\n\n`); } catch {} }, 15000); keepAlive.unref();
  const timedBackup = setInterval(() => { if (changesSinceBackup > 0 && Date.now() - lastBackupAt > 15 * 60 * 1000) createSnapshot('auto-15-min').catch(console.error); }, 60000); timedBackup.unref();
  server.on('error', error => { if (error.code === 'EADDRINUSE' && attemptsLeft > 1) { clearInterval(keepAlive); clearInterval(timedBackup); return startServer(port + 1, attemptsLeft - 1); } console.error('Failed to start FATUM server:', error); process.exitCode = 1; });
  server.listen(port, HOST, () => { printStartupInfo(port); if (typeof process.send === 'function') process.send({ type:'fatum-ready', port, version:VERSION }); console.log(`FATUM_READY ${JSON.stringify({port,version:VERSION})}`); setTimeout(() => openBrowser(`http://localhost:${port}/master`), 350); });
  const shutdown = async signal => { console.log(`\n${signal}: stopping server...`); clearInterval(keepAlive); clearInterval(timedBackup); try { await Promise.all([persistCampaign(), persistHistory()]); if (changesSinceBackup > 0) await createSnapshot('shutdown'); } catch (error) { console.error(error); } for (const client of sseClients.values()) try { client.response.end(); } catch {} server.close(() => process.exit(0)); setTimeout(() => process.exit(1), 4000).unref(); };
  process.once('SIGINT', () => shutdown('SIGINT')); process.once('SIGTERM', () => shutdown('SIGTERM'));
}

try { ensureDataFiles(); startServer(START_PORT, MAX_PORT_ATTEMPTS); } catch (error) { console.error('Critical startup error:', error); process.exitCode = 1; }
