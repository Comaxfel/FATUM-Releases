'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('fatumDesktop', {
  isDesktop:true,
  getContext:() => ipcRenderer.invoke('desktop:get-context'),
  connectServer:value => ipcRenderer.invoke('desktop:connect-server', value),
  changeServer:() => ipcRenderer.send('desktop:change-server'),
  goCampaigns:() => ipcRenderer.invoke('desktop:go-campaigns'),
  requestExit:() => ipcRenderer.invoke('desktop:request-exit'),
  toggleFullscreen:() => ipcRenderer.invoke('desktop:toggle-fullscreen'),
  getServerUrl:() => ipcRenderer.invoke('desktop:get-server-url'),
  launchRole:role => ipcRenderer.invoke('desktop:launch-role', role),
  runUpdater:() => ipcRenderer.invoke('desktop:run-updater'),
  runRestore:() => ipcRenderer.invoke('desktop:run-restore'),
  openInstallDirectory:() => ipcRenderer.invoke('desktop:open-install-dir'),
  saveHtmlAsPng:payload => ipcRenderer.invoke('desktop:save-html-png', payload),
  alertSync:(message,title='FATUM') => ipcRenderer.sendSync('desktop:alert-sync',{message,title}),
  confirmSync:(message,title='FATUM') => ipcRenderer.sendSync('desktop:confirm-sync',{message,title}),
  onServerStopped:handler => ipcRenderer.on('fatum-server-stopped',(_event,payload)=>handler(payload))
});

window.addEventListener('DOMContentLoaded', () => {
  try{if(/^https?:$/.test(location.protocol)&&/\/battlemap\.html$/i.test(location.pathname)){const s=document.createElement('script');s.textContent="(()=>{if(window.__fatumTN18)return;window.__fatumTN18=1;const P=CanvasRenderingContext2D.prototype,T=P.fillText,R=P.fillRect,c=(v,a,b)=>Math.max(a,Math.min(b,v)),n=s=>String(s||'').replace(/\\s+/g,'').toLowerCase(),q=s=>{s=n(s);return s==='rgba(10,12,16,0.82)'||s==='rgba(48,24,52,0.9)'},k=s=>{s=n(s);return['#f2eadc','#aaa','#b77070','#ff8a83','#e6b4dd','rgb(242,234,220)','rgb(170,170,170)','rgb(183,112,112)','rgb(255,138,131)','rgb(230,180,221)'].includes(s)},z=o=>{try{let t=o.getTransform();return Math.max(.05,Math.hypot(t.a,t.b)||1)}catch{return 1}},w=f=>{let m=String(f||'').match(/(?:^|\\s)(400|500|600|700)(?:\\s|$)/);return m?+m[1]:400};P.fillRect=function(x,y,a,b){let s=z(this);if(q(this.fillStyle)&&Math.abs(+b||0)*s>=15&&Math.abs(+b||0)*s<=21&&this.textAlign==='center')return;return R.apply(this,arguments)};P.fillText=function(t,x,y,m){let f=String(this.font||''),a=w(f);if(this.textAlign==='center'&&this.textBaseline==='top'&&/Segoe UI/i.test(f)&&k(this.fillStyle)&&(a===400||a===600)){let s=z(this),p=c(12-3.2*Math.log2(s),11,17)/s;this.save();this.font=`${a===600?700:500} ${p}px Segoe UI`;this.lineJoin='round';this.miterLimit=2;this.strokeStyle='rgba(0,0,0,.96)';this.lineWidth=3.4/s;m===undefined?this.strokeText(t,x,y):this.strokeText(t,x,y,m);m===undefined?T.call(this,t,x,y):T.call(this,t,x,y,m);this.restore();return}return T.apply(this,arguments)}})();";(document.head||document.documentElement).appendChild(s);s.remove()}}catch{}
  document.documentElement.classList.add('fatum-desktop');
  document.querySelectorAll('[data-fatum-desktop-only]').forEach(node => { node.hidden = false; });
});
