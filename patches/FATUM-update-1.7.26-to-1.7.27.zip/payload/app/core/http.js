'use strict';

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const DEFAULT_COMPRESSION_THRESHOLD = 1024;
const DEFAULT_MAX_CONCURRENT_REQUEST_BYTES = 128 * 1024 * 1024;
let activeBufferedRequestBytes = 0;

function resolveSafePath(root, urlPath, defaultFile = null) {
  let decoded;
  try { decoded = decodeURIComponent(urlPath); }
  catch { return null; }
  if (decoded.includes('\0')) return null;
  const normalized = path.posix.normalize(decoded).replace(/^\/+/, '');
  const rootPath = path.resolve(root);
  const candidate = path.resolve(rootPath, normalized || defaultFile || '');
  const prefix = rootPath + path.sep;
  return candidate === rootPath || candidate.startsWith(prefix) ? candidate : null;
}

function parseByteRange(header, size) {
  const match = /^bytes=(\d*)-(\d*)$/i.exec(String(header || '').trim());
  if (!match || (!match[1] && !match[2])) return null;
  let start = match[1] ? Number(match[1]) : null;
  let end = match[2] ? Number(match[2]) : null;
  if ((start !== null && !Number.isSafeInteger(start)) || (end !== null && !Number.isSafeInteger(end))) return { invalid:true };
  if (start === null) {
    const suffix = Math.max(0, end || 0);
    if (!suffix) return { invalid:true };
    start = Math.max(0, size - suffix);
    end = size - 1;
  } else if (end === null || end >= size) {
    end = size - 1;
  }
  if (start < 0 || start >= size || end < start) return { invalid:true };
  return { start, end };
}

function readRequestBuffer(req, maxBytes, tooLargeMessage = 'Слишком большой запрос.', options = {}) {
  return new Promise((resolve, reject) => {
    const maxConcurrentBytes = Math.max(maxBytes, Number(options.maxConcurrentBytes) || DEFAULT_MAX_CONCURRENT_REQUEST_BYTES);
    const declared = Number(req?.headers?.['content-length']);
    let size = 0;
    let reserved = 0;
    let tooLarge = Number.isFinite(declared) && declared > maxBytes;
    let overloaded = !tooLarge && Number.isFinite(declared) && declared > 0 && activeBufferedRequestBytes + declared > maxConcurrentBytes;
    let settled = false;
    const chunks = [];
    const release = () => {
      if (reserved > 0) activeBufferedRequestBytes = Math.max(0, activeBufferedRequestBytes - reserved);
      reserved = 0;
    };
    const finishReject = error => {
      if (settled) return;
      settled = true;
      release();
      reject(error);
    };
    const finishResolve = buffer => {
      if (settled) return;
      settled = true;
      release();
      resolve(buffer);
    };
    req.on('data', chunk => {
      size += chunk.length;
      if (size > maxBytes) {
        tooLarge = true;
        chunks.length = 0;
        release();
        return;
      }
      if (tooLarge || overloaded) return;
      if (activeBufferedRequestBytes + chunk.length > maxConcurrentBytes) {
        overloaded = true;
        chunks.length = 0;
        release();
        return;
      }
      chunks.push(chunk);
      reserved += chunk.length;
      activeBufferedRequestBytes += chunk.length;
    });
    req.on('end', () => {
      if (tooLarge) return finishReject(Object.assign(new Error(tooLargeMessage), { statusCode:413 }));
      if (overloaded) return finishReject(Object.assign(new Error('Сервер временно перегружен входящими данными. Повторите запрос позже.'), { statusCode:503 }));
      finishResolve(Buffer.concat(chunks));
    });
    req.on('aborted', () => finishReject(Object.assign(new Error('Запрос был прерван.'), { statusCode:400 })));
    req.on('error', finishReject);
  });
}

function contentTypeCompressible(contentType) {
  const type = String(contentType || '').toLowerCase();
  return type.startsWith('text/') || type.includes('json') || type.includes('javascript') || type.includes('xml') || type.includes('svg');
}

function acceptedContentEncoding(req) {
  const header = String(req?.headers?.['accept-encoding'] || '').toLowerCase();
  if (!header) return null;
  const quality = name => {
    const match = new RegExp(`(?:^|,)\\s*${name}\\s*(?:;\\s*q=([0-9.]+))?`, 'i').exec(header);
    return match ? (match[1] === undefined ? 1 : Number(match[1])) : 0;
  };
  const br = quality('br');
  const gzip = quality('gzip');
  if (br > 0 && br >= gzip) return 'br';
  if (gzip > 0) return 'gzip';
  return null;
}

function appendVary(headers, value) {
  const existing = String(headers.Vary || headers.vary || '').split(',').map(item => item.trim()).filter(Boolean);
  if (!existing.some(item => item.toLowerCase() === String(value).toLowerCase())) existing.push(value);
  headers.Vary = existing.join(', ');
  delete headers.vary;
}

function compressBuffer(buffer, encoding) {
  return new Promise((resolve, reject) => {
    const done = (error, result) => error ? reject(error) : resolve(result);
    if (encoding === 'br') return zlib.brotliCompress(buffer, { params:{ [zlib.constants.BROTLI_PARAM_QUALITY]:4 } }, done);
    if (encoding === 'gzip') return zlib.gzip(buffer, { level:4 }, done);
    resolve(buffer);
  });
}

function compressionStream(encoding) {
  if (encoding === 'br') return zlib.createBrotliCompress({ params:{ [zlib.constants.BROTLI_PARAM_QUALITY]:4 } });
  if (encoding === 'gzip') return zlib.createGzip({ level:4 });
  return null;
}

function createHttpHelpers({ mimeTypes = {}, defaultCacheControl = 'no-store, max-age=0, must-revalidate', compressionThreshold = DEFAULT_COMPRESSION_THRESHOLD } = {}) {
  function sendBuffer(res, statusCode, body, headers) {
    const buffer = Buffer.isBuffer(body) ? body : Buffer.from(body);
    const req = res.req;
    const encoding = buffer.length >= compressionThreshold && contentTypeCompressible(headers['Content-Type']) ? acceptedContentEncoding(req) : null;
    if (!encoding || req?.method === 'HEAD') {
      headers['Content-Length'] = buffer.length;
      res.writeHead(statusCode, headers);
      return res.end(req?.method === 'HEAD' ? undefined : buffer);
    }
    appendVary(headers, 'Accept-Encoding');
    headers['Content-Encoding'] = encoding;
    compressBuffer(buffer, encoding).then(compressed => {
      if (res.destroyed || res.writableEnded) return;
      headers['Content-Length'] = compressed.length;
      res.writeHead(statusCode, headers);
      res.end(compressed);
    }).catch(() => {
      if (res.destroyed || res.writableEnded) return;
      delete headers['Content-Encoding'];
      headers['Content-Length'] = buffer.length;
      res.writeHead(statusCode, headers);
      res.end(buffer);
    });
  }

  function sendJson(res, statusCode, payload) {
    const body = Buffer.from(JSON.stringify(payload, null, 2));
    return sendBuffer(res, statusCode, body, {
      'Content-Type':'application/json; charset=utf-8',
      'Cache-Control':'no-store',
      'X-Content-Type-Options':'nosniff'
    });
  }

  function sendText(res, statusCode, text) {
    const body = Buffer.from(String(text ?? ''));
    return sendBuffer(res, statusCode, body, {
      'Content-Type':'text/plain; charset=utf-8',
      'Cache-Control':'no-store',
      'X-Content-Type-Options':'nosniff'
    });
  }

  function redirect(res, location, extraHeaders = {}) {
    res.writeHead(302, { Location:location, 'Cache-Control':'no-store', ...extraHeaders });
    res.end();
  }

  function serveFile(req, res, filePath, cacheOverride = null) {
    fs.stat(filePath, (error, stats) => {
      if (error || !stats.isFile()) return sendText(res, 404, 'Файл не найден.');
      const ext = path.extname(filePath).toLowerCase();
      const contentType = mimeTypes[ext] || 'application/octet-stream';
      const range = req.headers.range ? parseByteRange(req.headers.range, stats.size) : null;
      const canCompress = !range && req.method !== 'HEAD' && stats.size >= compressionThreshold && contentTypeCompressible(contentType);
      const encoding = canCompress ? acceptedContentEncoding(req) : null;
      const etagSuffix = encoding ? `-${encoding}` : '';
      const etag = `"${stats.size.toString(16)}-${Math.floor(stats.mtimeMs).toString(16)}${etagSuffix}"`;
      const headers = {
        'Content-Type':contentType,
        'Accept-Ranges':'bytes',
        'Cache-Control':cacheOverride || defaultCacheControl,
        'ETag':etag,
        'Last-Modified':stats.mtime.toUTCString(),
        'X-Content-Type-Options':'nosniff',
        'Referrer-Policy':'same-origin'
      };
      if (!cacheOverride) { headers.Pragma='no-cache'; headers.Expires='0'; }
      if (encoding) { headers['Content-Encoding']=encoding; appendVary(headers, 'Accept-Encoding'); }
      else headers['Content-Length']=stats.size;
      if (range?.invalid) {
        delete headers['Content-Length'];
        headers['Content-Range'] = `bytes */${stats.size}`;
        res.writeHead(416, headers);
        return res.end();
      }
      if (!range && req.headers['if-none-match'] === etag) {
        delete headers['Content-Length'];
        res.writeHead(304, headers);
        return res.end();
      }
      if (range) {
        headers['Content-Range'] = `bytes ${range.start}-${range.end}/${stats.size}`;
        headers['Content-Length'] = range.end - range.start + 1;
        res.writeHead(206, headers);
        if (req.method === 'HEAD') return res.end();
        return fs.createReadStream(filePath, { start:range.start, end:range.end })
          .on('error', () => { if (!res.headersSent) sendText(res, 500, 'Не удалось прочитать файл.'); else res.destroy(); })
          .pipe(res);
      }
      res.writeHead(200, headers);
      if (req.method === 'HEAD') return res.end();
      const source = fs.createReadStream(filePath)
        .on('error', () => { if (!res.headersSent) sendText(res, 500, 'Не удалось прочитать файл.'); else res.destroy(); });
      if (!encoding) return source.pipe(res);
      const compressor = compressionStream(encoding);
      compressor.on('error', () => res.destroy());
      return source.pipe(compressor).pipe(res);
    });
  }

  return { sendJson, sendText, redirect, serveFile };
}

module.exports = {
  DEFAULT_COMPRESSION_THRESHOLD,
  DEFAULT_MAX_CONCURRENT_REQUEST_BYTES,
  resolveSafePath,
  parseByteRange,
  readRequestBuffer,
  contentTypeCompressible,
  acceptedContentEncoding,
  createHttpHelpers
};
