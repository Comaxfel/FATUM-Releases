@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call "%~dp0UPDATE_FATUM.cmd" --capture-assets --yes
exit /b %ERRORLEVEL%
