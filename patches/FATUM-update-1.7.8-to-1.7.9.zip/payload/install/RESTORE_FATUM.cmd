@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call "%~dp0UPDATE_FATUM.cmd" --restore-latest --yes
exit /b %ERRORLEVEL%
