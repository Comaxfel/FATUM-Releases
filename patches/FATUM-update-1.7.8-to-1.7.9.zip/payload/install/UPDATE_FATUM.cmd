@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"

set "INSTALL_ROOT=%~dp0"
set "APP_ROOT=%~dp0"
set "UPDATER_JS=%~dp0updater\update.js"

if exist "%~dp0resources\app\package.json" set "APP_ROOT=%~dp0resources\app"
if not exist "%UPDATER_JS%" if exist "%APP_ROOT%\updater\update.js" set "UPDATER_JS=%APP_ROOT%\updater\update.js"

if not exist "%UPDATER_JS%" (
  echo FATUM updater was not found.
  echo File: %UPDATER_JS%
  pause
  exit /b 1
)

if exist "%~dp0FATUM.exe" (
  set "ELECTRON_RUN_AS_NODE=1"
  "%~dp0FATUM.exe" "%UPDATER_JS%" --install-root "%INSTALL_ROOT%" --app-root "%APP_ROOT%" %*
  set "RC=%ERRORLEVEL%"
  set "ELECTRON_RUN_AS_NODE="
) else (
  where node.exe >nul 2>nul
  if errorlevel 1 (
    echo Node.js was not found. Run this updater from the installed FATUM folder.
    pause
    exit /b 1
  )
  node.exe "%UPDATER_JS%" --install-root "%INSTALL_ROOT%" --app-root "%APP_ROOT%" %*
  set "RC=%ERRORLEVEL%"
)

echo.
if "%RC%"=="0" (
  echo FATUM updater finished successfully.
) else (
  echo FATUM updater finished with an error. Code: %RC%
)
pause
exit /b %RC%
