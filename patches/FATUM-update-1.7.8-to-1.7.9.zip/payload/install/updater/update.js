'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const readline = require('readline');
const { execFileSync } = require('child_process');

function parseArgs(argv) {
  const result = { yes:false, check:false, captureAssets:false, restoreLatest:false };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--yes' || arg === '-y') result.yes = true;
    else if (arg === '--check') result.check = true;
    else if (arg === '--capture-assets') result.captureAssets = true;
    else if (arg === '--restore-latest') result.restoreLatest = true;
    else if (arg === '--package') result.packagePath = argv[++i];
    else if (arg === '--manifest') result.manifestUrl = argv[++i];
    else if (arg === '--install-root') result.installRoot = argv[++i];
    else if (arg === '--app-root') result.appRoot = argv[++i];
    else if (arg === '--data-dir') result.dataDir = argv[++i];
    else if (arg === '--help' || arg === '-h' || arg === '/?') result.help = true;
  }
  return result;
}

function normalizeVersion(value) {
  const text = String(value || '').trim().replace(/^v/i, '');
  const match = /^(\d+)\.(\d+)\.(\d+)(?:[-+.]?([A-Za-z0-9.-]+))?$/.exec(text);
  if (!match) return null;
  return { text, major:Number(match[1]), minor:Number(match[2]), patch:Number(match[3]), suffix:match[4] || '' };
}

function compareVersions(a, b) {
  const left = normalizeVersion(a), right = normalizeVersion(b);
  if (!left || !right) throw new Error(`Некорректная версия: ${a} / ${b}`);
  for (const key of ['major','minor','patch']) {
    if (left[key] !== right[key]) return left[key] < right[key] ? -1 : 1;
  }
  if (left.suffix === right.suffix) return 0;
  if (!left.suffix) return 1;
  if (!right.suffix) return -1;
  return left.suffix.localeCompare(right.suffix, 'en', { numeric:true, sensitivity:'base' });
}

function sha256(buffer) { return crypto.createHash('sha256').update(buffer).digest('hex'); }
function sha256File(filePath) { return sha256(fs.readFileSync(filePath)); }

function safeRelative(value) {
  const text = String(value || '').replace(/\\/g, '/').replace(/^\/+/, '');
  if (!text || text.includes('\0') || text.split('/').some(part => !part || part === '.' || part === '..')) throw new Error(`Недопустимый путь обновления: ${value}`);
  return text;
}

function safeJoin(root, relative) {
  const rel = safeRelative(relative);
  const base = path.resolve(root);
  const target = path.resolve(base, rel);
  if (target !== base && !target.startsWith(`${base}${path.sep}`)) throw new Error(`Путь выходит за каталог FATUM: ${relative}`);
  return target;
}

function protectedAppPath(relative) {
  const rel = safeRelative(relative).toLowerCase();
  return rel === 'data' || rel.startsWith('data/') || rel === 'backups' || rel.startsWith('backups/') || rel === 'node_modules' || rel.startsWith('node_modules/') || rel === 'dist' || rel.startsWith('dist/');
}

function protectedInstallPath(relative) {
  const rel = safeRelative(relative).toLowerCase();
  return rel === 'fatum-data' || rel.startsWith('fatum-data/') || rel === 'resources/app/data' || rel.startsWith('resources/app/data/');
}

function readJson(filePath, fallback = null) {
  try { return JSON.parse(fs.readFileSync(filePath, 'utf8').replace(/^\uFEFF/, '')); }
  catch { return fallback; }
}

function writeJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive:true });
  const temp = `${filePath}.tmp-${process.pid}-${Date.now()}`;
  fs.writeFileSync(temp, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
  fs.copyFileSync(temp, filePath);
  fs.rmSync(temp, { force:true });
}

function determineRoots(args) {
  const scriptUpdaterDir = __dirname;
  const scriptInstallRoot = path.resolve(scriptUpdaterDir, '..');
  const installRoot = path.resolve(args.installRoot || scriptInstallRoot);
  let appRoot = path.resolve(args.appRoot || installRoot);
  const packaged = path.join(installRoot, 'resources', 'app');
  if (!args.appRoot && fs.existsSync(path.join(packaged, 'package.json'))) appRoot = packaged;
  if (!fs.existsSync(path.join(appRoot, 'package.json'))) throw new Error(`Не найден package.json FATUM: ${appRoot}`);
  return { installRoot, appRoot };
}

function determineDataDir(args, roots) {
  if (args.dataDir) return path.resolve(args.dataDir);
  if (process.env.FATUM_UPDATE_DATA_DIR) return path.resolve(process.env.FATUM_UPDATE_DATA_DIR);
  const portable = path.join(roots.installRoot, 'FATUM-data');
  if (fs.existsSync(portable)) return portable;
  const packaged = path.basename(path.dirname(roots.appRoot)).toLowerCase() === 'resources';
  if (packaged && process.env.APPDATA) {
    const masterData = path.join(process.env.APPDATA, 'FATUM Master', 'data');
    if (fs.existsSync(masterData)) return masterData;
    if (process.env.LOCALAPPDATA) return path.join(process.env.LOCALAPPDATA, 'FATUM', 'UpdaterData');
    return masterData;
  }
  return path.join(roots.appRoot, 'data');
}

function loadConfig(roots) {
  const candidates = [
    path.join(roots.installRoot, 'updater', 'updater-config.json'),
    path.join(roots.appRoot, 'updater', 'updater-config.json')
  ];
  for (const file of candidates) {
    const config = readJson(file);
    if (config) return { ...config, file };
  }
  return { schemaVersion:1, channel:'stable', manifestUrl:'', captureLegacyAssetsOnFirstUpdate:true, customAssetRoots:['public/assets/items','public/assets/audio/core','public/assets/cursors'] };
}

function currentVersion(appRoot) {
  const pkg = readJson(path.join(appRoot, 'package.json'));
  if (!pkg?.version || !normalizeVersion(pkg.version)) throw new Error('Не удалось определить текущую версию FATUM.');
  return pkg.version;
}

function ensureUpdaterData(dataDir) {
  fs.mkdirSync(dataDir, { recursive:true });
  fs.mkdirSync(path.join(dataDir, 'update-backups'), { recursive:true });
  fs.mkdirSync(path.join(dataDir, 'update-downloads'), { recursive:true });
  fs.mkdirSync(path.join(dataDir, 'overrides', 'public'), { recursive:true });
}

function walkFiles(root) {
  if (!fs.existsSync(root)) return [];
  const out = [];
  const walk = (dir, prefix = '') => {
    for (const entry of fs.readdirSync(dir, { withFileTypes:true })) {
      const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full, rel);
      else if (entry.isFile()) out.push({ relative:rel.replace(/\\/g, '/'), full });
    }
  };
  walk(root);
  return out;
}

function captureAssets(roots, dataDir, config, options = {}) {
  const overridePublic = path.join(dataDir, 'overrides', 'public');
  const copied = [];
  const rootsToCopy = Array.isArray(config.customAssetRoots) && config.customAssetRoots.length ? config.customAssetRoots : ['public/assets/items','public/assets/audio/core','public/assets/cursors'];
  for (const relativeRoot of rootsToCopy) {
    const normalizedRoot = safeRelative(relativeRoot);
    if (!normalizedRoot.toLowerCase().startsWith('public/assets/')) continue;
    const sourceRoot = safeJoin(roots.appRoot, normalizedRoot);
    const publicRelativeRoot = normalizedRoot.slice('public/'.length);
    for (const file of walkFiles(sourceRoot)) {
      const target = safeJoin(overridePublic, `${publicRelativeRoot}/${file.relative}`);
      fs.mkdirSync(path.dirname(target), { recursive:true });
      if (!options.force && fs.existsSync(target)) continue;
      fs.copyFileSync(file.full, target);
      copied.push(path.relative(roots.appRoot, file.full).replace(/\\/g, '/'));
    }
  }
  writeJson(path.join(dataDir, 'overrides', 'capture-state.json'), {
    format:'fatum-resource-overrides', schemaVersion:1, capturedAt:new Date().toISOString(), sourceVersion:currentVersion(roots.appRoot), copiedFiles:copied.length
  });
  return copied;
}

function shouldAutoCapture(dataDir, config) {
  if (config.captureLegacyAssetsOnFirstUpdate === false) return false;
  return !fs.existsSync(path.join(dataDir, 'overrides', 'capture-state.json'));
}

function ensureNoOtherFatumProcesses() {
  if (process.platform !== 'win32') return;
  try {
    const output = execFileSync('tasklist.exe', ['/FI','IMAGENAME eq FATUM.exe','/FO','CSV','/NH'], { encoding:'utf8', windowsHide:true });
    const count = output.split(/\r?\n/).filter(line => /^"FATUM\.exe"/i.test(line.trim())).length;
    const selfIsFatum = path.basename(process.execPath).toLowerCase() === 'fatum.exe';
    const allowed = selfIsFatum ? 1 : 0;
    if (count > allowed) throw new Error('FATUM сейчас запущен. Закройте окна Мастера/Игрока и повторите обновление.');
  } catch (error) {
    if (/FATUM сейчас запущен/.test(error.message)) throw error;
  }
}

async function ask(question, yes) {
  if (yes) return true;
  if (!process.stdin.isTTY) return false;
  const rl = readline.createInterface({ input:process.stdin, output:process.stdout });
  try {
    const answer = await new Promise(resolve => rl.question(`${question} [Y/N]: `, resolve));
    return /^y(?:es)?$|^д(?:а)?$/i.test(String(answer).trim());
  } finally { rl.close(); }
}

function loadArchiveUtils(appRoot) {
  const modulePath = path.join(appRoot, 'archive-utils.js');
  delete require.cache[require.resolve(modulePath)];
  return require(modulePath);
}

function validatePackageManifest(manifest, entries, current) {
  if (!manifest || manifest.format !== 'fatum-update' || Number(manifest.schemaVersion) !== 1) throw new Error('Архив не является обновлением FATUM поддерживаемого формата.');
  if (!normalizeVersion(manifest.version)) throw new Error('В обновлении указан некорректный номер версии.');
  if (manifest.minimumVersion && compareVersions(current, manifest.minimumVersion) < 0) throw new Error(`Для этого патча нужна FATUM ${manifest.minimumVersion} или новее.`);
  if (manifest.maximumVersion && compareVersions(current, manifest.maximumVersion) > 0) throw new Error(`Этот патч предназначен для FATUM не новее ${manifest.maximumVersion}.`);
  if (manifest.fromVersion && compareVersions(current, manifest.fromVersion) !== 0) throw new Error(`Патч предназначен для FATUM ${manifest.fromVersion}, а установлена ${current}.`);
  if (!Array.isArray(manifest.files)) throw new Error('В манифесте обновления нет списка файлов.');
  const seen = new Set();
  for (const file of manifest.files) {
    const scope = file.scope === 'install' ? 'install' : 'app';
    const rel = safeRelative(file.path);
    const key = `${scope}:${rel.toLowerCase()}`;
    if (seen.has(key)) throw new Error(`Дублирующийся файл в патче: ${file.path}`);
    seen.add(key);
    if ((scope === 'app' && protectedAppPath(rel)) || (scope === 'install' && protectedInstallPath(rel))) throw new Error(`Патч пытается изменить защищённые пользовательские данные: ${file.path}`);
    const entryName = `payload/${scope}/${rel}`;
    const data = entries.get(entryName);
    if (!data) throw new Error(`В ZIP отсутствует файл ${entryName}.`);
    if (Number.isFinite(Number(file.size)) && Number(file.size) !== data.length) throw new Error(`Размер ${file.path} не совпадает с манифестом.`);
    if (!/^[a-f0-9]{64}$/i.test(String(file.sha256 || '')) || sha256(data) !== String(file.sha256).toLowerCase()) throw new Error(`SHA-256 ${file.path} не совпадает.`);
  }
  for (const item of Array.isArray(manifest.delete) ? manifest.delete : []) {
    const scope = item.scope === 'install' ? 'install' : 'app';
    const rel = safeRelative(item.path);
    if ((scope === 'app' && protectedAppPath(rel)) || (scope === 'install' && protectedInstallPath(rel))) throw new Error(`Патч пытается удалить защищённые данные: ${item.path}`);
  }
  return manifest;
}

function readUpdatePackage(packagePath, roots) {
  const { parseZip } = loadArchiveUtils(roots.appRoot);
  const buffer = fs.readFileSync(packagePath);
  const entries = parseZip(buffer, { maxEntries:20000, maxEntryBytes:256*1024*1024, maxTotalBytes:1024*1024*1024 });
  const manifestBuffer = entries.get('update-manifest.json');
  if (!manifestBuffer) throw new Error('В ZIP нет update-manifest.json.');
  let manifest;
  try { manifest = JSON.parse(manifestBuffer.toString('utf8')); } catch { throw new Error('Повреждён update-manifest.json.'); }
  return { buffer, entries, manifest };
}

function backupDirectory(dataDir, fromVersion, toVersion) {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  return path.join(dataDir, 'update-backups', `${stamp}-${fromVersion}-to-${toVersion}`);
}

function targetFor(roots, scope, relative) {
  return safeJoin(scope === 'install' ? roots.installRoot : roots.appRoot, relative);
}

function createBackup(roots, dataDir, manifest, fromVersion) {
  const dir = backupDirectory(dataDir, fromVersion, manifest.version);
  const records = [];
  const requested = [
    ...manifest.files.map(item => ({ scope:item.scope === 'install' ? 'install' : 'app', path:safeRelative(item.path) })),
    ...(Array.isArray(manifest.delete) ? manifest.delete.map(item => ({ scope:item.scope === 'install' ? 'install' : 'app', path:safeRelative(item.path) })) : [])
  ];
  const unique = new Map(requested.map(item => [`${item.scope}:${item.path.toLowerCase()}`, item]));
  for (const item of unique.values()) {
    const source = targetFor(roots, item.scope, item.path);
    const existed = fs.existsSync(source) && fs.statSync(source).isFile();
    if (existed) {
      const destination = safeJoin(path.join(dir, 'files', item.scope), item.path);
      fs.mkdirSync(path.dirname(destination), { recursive:true });
      fs.copyFileSync(source, destination);
    }
    records.push({ ...item, existed, sha256:existed ? sha256File(source) : null });
  }
  const metadata = { format:'fatum-update-backup', schemaVersion:1, createdAt:new Date().toISOString(), fromVersion, toVersion:manifest.version, records };
  writeJson(path.join(dir, 'backup-manifest.json'), metadata);
  return { dir, metadata };
}

function restoreBackup(roots, backupDir) {
  const manifest = readJson(path.join(backupDir, 'backup-manifest.json'));
  if (!manifest || manifest.format !== 'fatum-update-backup' || !Array.isArray(manifest.records)) throw new Error('Некорректная резервная копия FATUM.');
  for (const record of manifest.records) {
    const scope = record.scope === 'install' ? 'install' : 'app';
    const destination = targetFor(roots, scope, record.path);
    if (record.existed) {
      const source = safeJoin(path.join(backupDir, 'files', scope), record.path);
      if (!fs.existsSync(source)) throw new Error(`В резервной копии отсутствует ${record.path}.`);
      fs.mkdirSync(path.dirname(destination), { recursive:true });
      fs.copyFileSync(source, destination);
    } else {
      fs.rmSync(destination, { force:true });
    }
  }
  return manifest;
}

function latestBackup(dataDir) {
  const root = path.join(dataDir, 'update-backups');
  if (!fs.existsSync(root)) return null;
  const dirs = fs.readdirSync(root, { withFileTypes:true }).filter(entry => entry.isDirectory() && fs.existsSync(path.join(root, entry.name, 'backup-manifest.json'))).map(entry => path.join(root, entry.name)).sort().reverse();
  return dirs[0] || null;
}

function writePayloadFile(destination, data) {
  fs.mkdirSync(path.dirname(destination), { recursive:true });
  const temp = `${destination}.fatum-update-${process.pid}-${Date.now()}.tmp`;
  fs.writeFileSync(temp, data);
  fs.copyFileSync(temp, destination);
  fs.rmSync(temp, { force:true });
}

function applyUpdatePackage(packagePath, roots, dataDir, options = {}) {
  ensureNoOtherFatumProcesses();
  const fromVersion = currentVersion(roots.appRoot);
  const parsed = readUpdatePackage(packagePath, roots);
  const manifest = validatePackageManifest(parsed.manifest, parsed.entries, fromVersion);
  if (compareVersions(manifest.version, fromVersion) <= 0 && !options.allowSameVersion) throw new Error(`Патч ${manifest.version} не новее установленной версии ${fromVersion}.`);
  const backup = createBackup(roots, dataDir, manifest, fromVersion);
  try {
    for (const file of manifest.files) {
      const scope = file.scope === 'install' ? 'install' : 'app';
      const rel = safeRelative(file.path);
      const data = parsed.entries.get(`payload/${scope}/${rel}`);
      const destination = targetFor(roots, scope, rel);
      writePayloadFile(destination, data);
      if (sha256File(destination) !== String(file.sha256).toLowerCase()) throw new Error(`Проверка записанного файла ${file.path} не прошла.`);
    }
    for (const item of Array.isArray(manifest.delete) ? manifest.delete : []) {
      const scope = item.scope === 'install' ? 'install' : 'app';
      fs.rmSync(targetFor(roots, scope, safeRelative(item.path)), { force:true });
    }
    const after = currentVersion(roots.appRoot);
    if (compareVersions(after, manifest.version) !== 0) throw new Error(`После обновления package.json сообщает версию ${after}, ожидалась ${manifest.version}.`);
    writeJson(path.join(dataDir, 'update-state.json'), { format:'fatum-update-state', schemaVersion:1, version:after, previousVersion:fromVersion, updatedAt:new Date().toISOString(), backupDir:backup.dir });
    return { fromVersion, toVersion:after, backupDir:backup.dir, manifest };
  } catch (error) {
    try { restoreBackup(roots, backup.dir); } catch (rollbackError) { error.message += `; откат тоже завершился ошибкой: ${rollbackError.message}`; }
    throw error;
  }
}

async function fetchJson(url) {
  const response = await fetch(url, { headers:{ 'User-Agent':'FATUM-Updater/1.0', 'Accept':'application/json' }, redirect:'follow' });
  if (!response.ok) throw new Error(`Не удалось получить манифест обновлений: HTTP ${response.status}.`);
  return response.json();
}

async function downloadFile(url, destination) {
  const response = await fetch(url, { headers:{ 'User-Agent':'FATUM-Updater/1.0', 'Accept':'application/octet-stream' }, redirect:'follow' });
  if (!response.ok) throw new Error(`Не удалось скачать обновление: HTTP ${response.status}.`);
  const maxBytes = 1024 * 1024 * 1024;
  const declared = Number(response.headers.get('content-length') || 0);
  if (declared > maxBytes) throw new Error('Файл обновления слишком большой.');
  const buffer = Buffer.from(await response.arrayBuffer());
  if (buffer.length > maxBytes) throw new Error('Файл обновления слишком большой.');
  fs.mkdirSync(path.dirname(destination), { recursive:true });
  fs.writeFileSync(destination, buffer);
  return buffer;
}

function validateChannel(channel) {
  if (!channel || channel.format !== 'fatum-update-channel' || Number(channel.schemaVersion) !== 1) throw new Error('Сервер обновлений вернул неизвестный формат latest.json.');
  const latest = channel.latestVersion || channel.version;
  if (!normalizeVersion(latest)) throw new Error('В latest.json нет корректной latestVersion.');
  if (!Array.isArray(channel.packages)) throw new Error('В latest.json нет списка packages.');
  return { ...channel, latestVersion:latest };
}

function nextPackage(channel, fromVersion) {
  const candidates = channel.packages.filter(item => String(item.from || '') === String(fromVersion) && normalizeVersion(item.to) && compareVersions(item.to, fromVersion) > 0);
  candidates.sort((a,b) => compareVersions(a.to,b.to));
  return candidates[0] || null;
}

async function onlineUpdate(args, roots, dataDir, config) {
  const manifestUrl = args.manifestUrl || config.manifestUrl;
  if (!manifestUrl || /OWNER|YOUR_|example\.com/i.test(manifestUrl)) throw new Error('GitHub-канал обновлений ещё не настроен в updater/updater-config.json.');
  let current = currentVersion(roots.appRoot);
  const channel = validateChannel(await fetchJson(manifestUrl));
  if (compareVersions(current, channel.latestVersion) >= 0) {
    console.log(`FATUM ${current}: установлена актуальная версия.`);
    return { updated:false, current, latest:channel.latestVersion };
  }
  console.log(`Установлено: FATUM ${current}`);
  console.log(`Доступно:   FATUM ${channel.latestVersion}`);
  if (args.check) return { updated:false, current, latest:channel.latestVersion, updateAvailable:true };
  if (!(await ask('Установить обновление?', args.yes))) {
    console.log('Обновление отменено.');
    return { updated:false, current, latest:channel.latestVersion, cancelled:true };
  }
  if (shouldAutoCapture(dataDir, config)) {
    const captured = captureAssets(roots, dataDir, config, { force:false });
    console.log(`Пользовательские ресурсы защищены: ${captured.length} файлов сохранено в overrides.`);
  }
  let hops = 0;
  while (compareVersions(current, channel.latestVersion) < 0) {
    if (++hops > 20) throw new Error('Слишком длинная цепочка обновлений.');
    const pkg = nextPackage(channel, current);
    if (!pkg) throw new Error(`Для FATUM ${current} нет подходящего дельта-патча до ${channel.latestVersion}.`);
    if (!pkg.url || !/^[a-f0-9]{64}$/i.test(String(pkg.sha256 || ''))) throw new Error(`Некорректная запись пакета ${pkg.from} → ${pkg.to}.`);
    const destination = path.join(dataDir, 'update-downloads', `FATUM-${pkg.from}-to-${pkg.to}.zip`);
    console.log(`Скачивание патча ${pkg.from} → ${pkg.to}...`);
    const buffer = await downloadFile(pkg.url, destination);
    if (sha256(buffer) !== String(pkg.sha256).toLowerCase()) { fs.rmSync(destination, { force:true }); throw new Error('SHA-256 скачанного патча не совпадает. Обновление отменено.'); }
    const result = applyUpdatePackage(destination, roots, dataDir);
    console.log(`Обновлено: ${result.fromVersion} → ${result.toVersion}`);
    current = result.toVersion;
  }
  return { updated:true, current, latest:channel.latestVersion };
}

function printHelp() {
  console.log(`FATUM Updater\n\n` +
    `UPDATE_FATUM.cmd                 Проверить и установить обновления.\n` +
    `UPDATE_FATUM.cmd --check         Только проверить наличие новой версии.\n` +
    `UPDATE_FATUM.cmd --package X.zip Установить локальный проверенный патч.\n` +
    `SAVE_MY_RESOURCES.cmd            Сохранить текущие иконки/звуки как overrides.\n` +
    `RESTORE_FATUM.cmd                Откатить последнее обновление.\n`);
}

async function main(argv = process.argv.slice(2)) {
  const args = parseArgs(argv);
  if (args.help) { printHelp(); return 0; }
  const roots = determineRoots(args);
  const dataDir = determineDataDir(args, roots);
  const config = loadConfig(roots);
  ensureUpdaterData(dataDir);

  console.log('============================================================');
  console.log(` FATUM Updater — текущая версия ${currentVersion(roots.appRoot)}`);
  console.log('============================================================');

  if (args.captureAssets) {
    const copied = captureAssets(roots, dataDir, config, { force:true });
    console.log(`Сохранено пользовательских ресурсов: ${copied.length}`);
    console.log(`Каталог: ${path.join(dataDir, 'overrides', 'public')}`);
    return 0;
  }

  if (args.restoreLatest) {
    ensureNoOtherFatumProcesses();
    const backup = latestBackup(dataDir);
    if (!backup) throw new Error('Резервные копии обновлений не найдены.');
    const meta = readJson(path.join(backup, 'backup-manifest.json'));
    if (!(await ask(`Откатить FATUM ${meta?.toVersion || '?'} → ${meta?.fromVersion || '?'}?`, args.yes))) return 0;
    const restored = restoreBackup(roots, backup);
    writeJson(path.join(dataDir, 'update-state.json'), { format:'fatum-update-state', schemaVersion:1, version:restored.fromVersion, restoredAt:new Date().toISOString(), restoredFromBackup:backup });
    console.log(`FATUM восстановлен до версии ${restored.fromVersion}.`);
    return 0;
  }

  if (args.packagePath) {
    if (shouldAutoCapture(dataDir, config)) {
      const captured = captureAssets(roots, dataDir, config, { force:false });
      console.log(`Пользовательские ресурсы защищены: ${captured.length} файлов сохранено в overrides.`);
    }
    const packagePath = path.resolve(args.packagePath);
    if (!fs.existsSync(packagePath)) throw new Error(`Патч не найден: ${packagePath}`);
    const parsed = readUpdatePackage(packagePath, roots);
    validatePackageManifest(parsed.manifest, parsed.entries, currentVersion(roots.appRoot));
    if (!(await ask(`Установить локальный патч до FATUM ${parsed.manifest.version}?`, args.yes))) return 0;
    const result = applyUpdatePackage(packagePath, roots, dataDir);
    console.log(`FATUM успешно обновлён: ${result.fromVersion} → ${result.toVersion}.`);
    console.log(`Резервная копия: ${result.backupDir}`);
    return 0;
  }

  await onlineUpdate(args, roots, dataDir, config);
  return 0;
}

if (require.main === module) {
  main().then(code => { process.exitCode = code; }).catch(error => {
    console.error('');
    console.error(`ОШИБКА: ${error.message}`);
    process.exitCode = 1;
  });
}

module.exports = {
  parseArgs,
  normalizeVersion,
  compareVersions,
  safeRelative,
  protectedAppPath,
  protectedInstallPath,
  determineRoots,
  determineDataDir,
  captureAssets,
  readUpdatePackage,
  validatePackageManifest,
  applyUpdatePackage,
  restoreBackup,
  latestBackup,
  validateChannel,
  nextPackage,
  sha256,
  main
};
