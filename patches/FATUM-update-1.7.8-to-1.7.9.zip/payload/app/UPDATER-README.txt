FATUM Updater v1.7.9
====================

Главные файлы рядом с FATUM.exe:
  UPDATE_FATUM.cmd       — проверить GitHub-канал и установить обновления.
  RESTORE_FATUM.cmd      — откатить последнее обновление.
  SAVE_MY_RESOURCES.cmd  — вручную сохранить текущие иконки/звуки/курсоры в persistent overrides.

Пользовательские данные
-----------------------
Обновлятор НИКОГДА не имеет права записывать патчем в data/ или FATUM-data/.
Перед изменением программных файлов создаётся резервная копия в:
  <data>/update-backups/

Пользовательские ресурсы сохраняются в:
  <data>/overrides/public/assets/items/
  <data>/overrides/public/assets/audio/core/
  <data>/overrides/public/assets/cursors/

Сервер FATUM сначала ищет разрешённый ресурс в overrides и только затем использует штатный файл из public/.
HTML и JS через overrides заменять нельзя — это сделано специально для безопасности обновлений.

Локальный патч
--------------
  UPDATE_FATUM.cmd --package FATUM-update-X-to-Y.zip

Онлайн-канал
------------
Настраивается в updater/updater-config.json.
Текущий адрес подготовлен для публичного репозитория:
  Comaxfel/FATUM-Releases

Репозиторий релизов должен быть публичным, потому что игроки не должны хранить GitHub-токен.
Исходный код FATUM при этом можно держать в отдельном приватном репозитории.

Формат latest.json: updater/latest.example.json.
Патчи создаются командой:
  node updater/build-update.js --base OLD_DIR --target NEW_DIR --out PATCH.zip
