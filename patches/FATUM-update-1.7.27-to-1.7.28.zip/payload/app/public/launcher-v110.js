(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const query = new URLSearchParams(location.search);
  const mode = query.get('mode') === 'master' ? 'master' : 'player';
  const clientId = localStorage.getItem('fatumLanClientId') || (() => {
    const value = globalThis.crypto?.randomUUID?.() || `player_${Date.now()}_${Math.random().toString(16).slice(2)}`;
    localStorage.setItem('fatumLanClientId', value); return value;
  })();
  const desktop = globalThis.fatumDesktop || null;
  let selectedRuleset=query.get('ruleset')==='tol'?'tol':localStorage.getItem('fatumLauncherRuleset')==='tol'?'tol':'classic';
  const state = { campaigns:[], activeId:null, menu:null, loading:false };
  let refreshTimer = 0;
  let pendingImportFile = null;
  let importInProgress = false;

  function esc(value){return String(value??'').replace(/[&<>'"]/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));}
  function formatDate(value){if(!value)return 'ещё не открывалась';const date=new Date(value);if(Number.isNaN(date.getTime()))return '';return new Intl.DateTimeFormat('ru-RU',{day:'2-digit',month:'short',year:date.getFullYear()!==new Date().getFullYear()?'numeric':undefined}).format(date);}
  function formatBytes(value){const bytes=Math.max(0,Number(value)||0);if(bytes<1024)return `${bytes} Б`;const units=['КБ','МБ','ГБ'];let amount=bytes/1024,index=0;while(amount>=1024&&index<units.length-1){amount/=1024;index++;}return `${amount>=100?amount.toFixed(0):amount>=10?amount.toFixed(1):amount.toFixed(2)} ${units[index]}`;}
  function hueFromId(id){let h=0;for(const ch of String(id||''))h=(h*31+ch.charCodeAt(0))%360;return h;}
  function initials(name){return String(name||'F').split(/\s+/).filter(Boolean).slice(0,2).map(v=>v[0]).join('').toUpperCase()||'F';}
  function playerName(){return (localStorage.getItem('fatumLanPlayerName')||localStorage.getItem('fatumPlayerName')||'').trim();}
  function savePlayerName(value){const name=String(value||'').trim().slice(0,80);localStorage.setItem('fatumLanPlayerName',name);localStorage.setItem('fatumPlayerName',name);$('player-name-btn').textContent=name||'Указать имя';return name;}
  async function api(url, options={}){const response=await fetch(url,{credentials:'same-origin',...options,headers:{'Content-Type':'application/json',...(options.headers||{})}});let payload={};try{payload=await response.json();}catch{}if(!response.ok)throw new Error(payload.error||`HTTP ${response.status}`);return payload;}
  function toast(text,kind=''){const node=$('launcher-toast');node.textContent=text;node.className=`launcher-toast ${kind}`;node.hidden=false;clearTimeout(node._timer);node._timer=setTimeout(()=>node.hidden=true,3300);}
  function setStatus(kind,text){const node=$('launcher-status');node.className=`launcher-status ${kind||''}`;node.querySelector('b').textContent=text;}
  function setBusy(value){state.loading=value;document.querySelectorAll('button').forEach(btn=>{if(btn.dataset.keepEnabled!=='1')btn.disabled=value;});}

  function configureMode(){
    document.body.dataset.mode=mode;
    $('master-actions').hidden=mode!=='master';
    $('player-identity').hidden=mode!=='player';
    $('role-label').textContent=mode==='master'?'Менеджер кампаний · Мастер':'Библиотека игрока';
    $('hero-kicker').textContent=mode==='master'?'БИБЛИОТЕКА МАСТЕРА':'ВАШИ ИСТОРИИ';
    $('hero-title').textContent=mode==='master'?'Ваши кампании':'Кампании и персонажи';
    $('hero-subtitle').textContent=mode==='master'?'Выберите кампанию, чтобы открыть поле группы, или подготовьте новую историю.':'Выберите активную кампанию, чтобы открыть лист назначенного вам персонажа.';
    $('library-note').textContent=mode==='master'?'Недавние кампании показываются первыми':'Кампания доступна, когда Мастер открыл её на своём компьютере';
    if(mode==='player')savePlayerName(playerName());
    if(desktop){document.querySelectorAll('.desktop-only').forEach(node=>node.hidden=false);$('server-btn').hidden=mode!=='player';}
  }

  async function loadCampaigns(silent=false){
    if(state.loading&&!silent)return;
    try{
      if(!silent)setStatus('','Подключение…');
      const params=new URLSearchParams({mode,clientId});
      const payload=await api(`/api/launcher/campaigns?${params}`);
      state.campaigns=payload.campaigns||[];state.activeId=payload.activeId||null;
      state.campaigns.sort((a,b)=>Number(b.active)-Number(a.active)||String(b.lastOpenedAt||b.updatedAt||'').localeCompare(String(a.lastOpenedAt||a.updatedAt||'')));
      renderCampaigns();setStatus('online',`Сервер v${payload.server?.version||'1.1.1'} · ${payload.server?.activeCampaignName||'готов'}`);
    }catch(error){if(!silent)toast(error.message,'error');setStatus('error','Нет связи с сервером');}
  }

  function cardCharacterHtml(campaign){
    if(mode!=='player')return '';
    const character=campaign.characters?.[0];
    if(character){const avatar=character.portrait?`<img src="${esc(character.portrait)}" alt="">`:`<span class="character-fallback">${esc(initials(character.name))}</span>`;return `<div class="campaign-character">${avatar}<div><strong>${esc(character.name)}</strong><small>${campaign.active?'Персонаж готов к игре':'Кампания сейчас не запущена'}</small></div></div>`;}
    return `<div class="campaign-character"><span class="character-fallback">?</span><div><strong>Персонаж не назначен</strong><small>Откройте кампанию и дождитесь Мастера</small></div></div>`;
  }
  function renderCampaigns(){
    const filtered=state.campaigns.filter(c=>(c.ruleset||'classic')===selectedRuleset);
    const grid=$('campaign-grid');$('campaign-count').textContent=String(filtered.length);
    $('launcher-empty').hidden=Boolean(filtered.length);
    if(!filtered.length){grid.innerHTML='';if(mode==='player'){$('empty-title').textContent='Нет доступных кампаний';$('empty-text').textContent='Подключитесь к серверу Мастера или дождитесь назначения персонажа.';}return;}
    grid.innerHTML=filtered.map(c=>{
      const cover=c.coverUrl?`<img src="${esc(c.coverUrl)}" alt="Обложка ${esc(c.name)}" onerror="this.remove()">`:`<span class="cover-fallback">${esc(initials(c.name))}</span>`;
      const available=mode==='master'||c.available;
      const badges=`<div class="campaign-badges">${c.active?'<span class="campaign-badge active">активна</span>':''}${mode==='player'&&!c.available?'<span class="campaign-badge">не запущена</span>':''}</div>`;
      const ruleLabel=(c.ruleset==='tol'?'TOL · Эпоха Анафемы':'Classic');
      const meta=mode==='master'?`<span>${c.characters||0} персонажей</span><span>${c.scenes||0} сцен</span>`:`<span>${c.characters?.length||0} назначено</span>`;
      const menu=mode==='master'?`<button class="campaign-menu" type="button" data-menu="${esc(c.id)}" aria-label="Меню кампании">•••</button>`:'';
      const openLabel=available?(mode==='master'?'Открыть граф группы →':(c.characters?.length?'Открыть лист →':'Войти и ждать →')):'Мастер не открыл кампанию';
      return `<article class="campaign-card ${available?'':'unavailable'}" data-campaign="${esc(c.id)}" style="--hue:${hueFromId(c.id)}">
        <div class="campaign-cover">${cover}${badges}${menu}</div>
        <div class="campaign-card-body"><small>${esc(ruleLabel)}</small><h3>${esc(c.name)}</h3><div class="campaign-meta">${meta}</div>${cardCharacterHtml(c)}
          <div class="campaign-card-footer"><span class="campaign-open-label">${esc(openLabel)}</span><span class="campaign-date">${esc(formatDate(c.lastOpenedAt||c.updatedAt))}</span></div>
        </div></article>`;
    }).join('');
  }

  async function openCampaign(id){
    const campaign=state.campaigns.find(c=>c.id===id);if(!campaign)return;
    if(mode==='master'){
      setBusy(true);try{if(!campaign.active)await api(`/api/campaigns/${encodeURIComponent(id)}/activate`,{method:'POST',body:JSON.stringify({clientId,playerName:'Мастер'})});location.href='/?mode=master&fromLauncher=1';}catch(error){toast(error.message,'error');setBusy(false);}return;
    }
    if(!campaign.available){toast('Мастер пока не открыл эту кампанию.','error');return;}
    let name=playerName();if(!name){openNameModal();return;}
    const character=campaign.characters?.[0];if(character)localStorage.setItem('fatumPlayerCharacterId',character.id);else localStorage.removeItem('fatumPlayerCharacterId');
    const params=new URLSearchParams({mode:'player',fromLauncher:'1',playerName:name});if(character)params.set('characterId',character.id);location.href=`/?${params}`;
  }

  function closeMenu(){state.menu?.remove();state.menu=null;}
  function showMenu(id,anchor){closeMenu();const c=state.campaigns.find(item=>item.id===id);if(!c)return;const box=document.createElement('div');box.className='card-popover';box.innerHTML=`<button data-action="open">Открыть</button><button data-action="rename">Переименовать</button><button data-action="cover">Заменить обложку</button><button data-action="remove-cover">Убрать обложку</button><button class="danger" data-action="delete">Удалить кампанию</button>`;document.body.appendChild(box);const r=anchor.getBoundingClientRect();box.style.left=`${Math.min(innerWidth-box.offsetWidth-12,r.right-box.offsetWidth)}px`;box.style.top=`${Math.min(innerHeight-box.offsetHeight-12,r.bottom+7)}px`;box.onclick=event=>{const action=event.target.closest('button')?.dataset.action;if(action)handleMenuAction(action,c);};state.menu=box;}
  async function handleMenuAction(action,c){closeMenu();try{
    if(action==='open')return openCampaign(c.id);
    if(action==='rename'){const name=(await fatumPrompt('Новое название кампании:',c.name,{title:'Переименовать кампанию',maxLength:180}))?.trim();if(!name||name===c.name)return;await api(`/api/campaigns/${encodeURIComponent(c.id)}`,{method:'PUT',body:JSON.stringify({name,clientId})});toast('Кампания переименована.');return loadCampaigns(true);}
    if(action==='cover'){const input=document.createElement('input');input.type='file';input.accept='image/png,image/jpeg,image/webp,image/gif';input.onchange=()=>input.files?.[0]&&uploadCover(c.id,input.files[0]).then(()=>loadCampaigns(true)).catch(e=>toast(e.message,'error'));input.click();return;}
    if(action==='remove-cover'){await api(`/api/campaigns/${encodeURIComponent(c.id)}/cover`,{method:'DELETE',body:JSON.stringify({clientId})});toast('Обложка удалена.');return loadCampaigns(true);}
    if(action==='delete'){if(!confirm(`Удалить кампанию «${c.name}»? Она будет перемещена в локальную корзину.`))return;let active=c.active;if(active){const alternate=state.campaigns.find(x=>x.id!==c.id);if(!alternate)throw new Error('Нельзя удалить единственную кампанию.');await api(`/api/campaigns/${encodeURIComponent(alternate.id)}/activate`,{method:'POST',body:JSON.stringify({clientId})});}await api(`/api/campaigns/${encodeURIComponent(c.id)}`,{method:'DELETE',body:JSON.stringify({clientId})});toast('Кампания перемещена в корзину.');return loadCampaigns(true);}
  }catch(error){toast(error.message,'error');}}

  async function uploadCover(id,file){if(file.size>16*1024*1024)throw new Error('Обложка превышает 16 МБ.');const params=new URLSearchParams({name:file.name});const response=await fetch(`/api/campaigns/${encodeURIComponent(id)}/cover?${params}`,{method:'POST',credentials:'same-origin',headers:{'Content-Type':file.type||'application/octet-stream'},body:file});let payload={};try{payload=await response.json();}catch{}if(!response.ok)throw new Error(payload.error||`HTTP ${response.status}`);return payload;}

  function openCreateModal(){$('creation-ruleset-label').textContent=selectedRuleset==='tol'?'The Tale of the Lost · Эпоха Анафемы':'FATUM: Classic';const modal=$('campaign-modal');$('campaign-name').value='';$('campaign-cover').value='';$('cover-preview').style.backgroundImage='';$('cover-preview').classList.remove('has-image');modal.hidden=false;setTimeout(()=>$('campaign-name').focus(),50);}
  function closeCreateModal(){$('campaign-modal').hidden=true;}
  function openNameModal(){$('player-name-input').value=playerName();$('name-modal').hidden=false;setTimeout(()=>$('player-name-input').focus(),50);}
  function closeNameModal(){$('name-modal').hidden=true;}
  function openImportModal(file){
    if(!file)return;
    const valid=/\.(?:fatum|zip|json)$/i.test(file.name||'');
    if(!valid){toast('Поддерживаются файлы .fatum, .zip и .json.','error');return;}
    pendingImportFile=file;importInProgress=false;
    const suggested=String(file.name||'').replace(/\.(?:fatum|zip|json)$/i,'').trim()||'Импортированная кампания';
    $('import-file-name').textContent=file.name||'Кампания';
    $('import-file-size').textContent=formatBytes(file.size);
    $('import-campaign-name').value=suggested;
    $('import-progress').hidden=true;$('import-progress-bar').style.width='0%';
    $('import-progress-text').hidden=true;$('import-progress-text').textContent='Подготовка импорта…';
    $('import-submit').textContent='Импортировать';
    $('import-form').classList.remove('importing');
    $('import-modal').hidden=false;
    setTimeout(()=>{$('import-campaign-name').focus();$('import-campaign-name').select();},50);
  }
  function closeImportModal(){if(importInProgress)return;$('import-modal').hidden=true;pendingImportFile=null;$('import-file').value='';}

  async function createCampaign(event){event.preventDefault();const name=$('campaign-name').value.trim();if(!name)return;const cover=$('campaign-cover').files?.[0]||null;setBusy(true);try{const created=await api('/api/campaigns',{method:'POST',body:JSON.stringify({name,ruleset:selectedRuleset,activate:true,clientId})});if(cover)await uploadCover(created.campaign.id,cover);location.href='/?mode=master&fromLauncher=1';}catch(error){toast(error.message,'error');setBusy(false);}}
  function importCampaign(event){
    event?.preventDefault?.();
    const file=pendingImportFile;
    const name=$('import-campaign-name').value.trim();
    if(!file||!name||importInProgress)return;
    importInProgress=true;setBusy(true);
    $('import-form').classList.add('importing');
    $('import-progress').hidden=false;$('import-progress-text').hidden=false;
    $('import-progress-text').textContent='Загрузка файла…';$('import-submit').textContent='Импортирование…';
    const params=new URLSearchParams({name,clientId});
    const xhr=new XMLHttpRequest();
    xhr.open('POST',`/api/campaigns/import-backup-file?${params}`);
    xhr.withCredentials=true;xhr.timeout=15*60*1000;
    xhr.setRequestHeader('Content-Type',file.type||'application/octet-stream');
    xhr.upload.onprogress=progress=>{if(!progress.lengthComputable)return;const percent=Math.max(1,Math.min(96,Math.round(progress.loaded/progress.total*96)));$('import-progress-bar').style.width=`${percent}%`;$('import-progress-text').textContent=`Загрузка файла: ${percent}%`;};
    const fail=message=>{importInProgress=false;setBusy(false);$('import-form').classList.remove('importing');$('import-submit').textContent='Повторить импорт';$('import-progress-text').textContent=message;toast(message,'error');};
    xhr.onload=()=>{let payload={};try{payload=JSON.parse(xhr.responseText||'{}');}catch{}if(xhr.status>=200&&xhr.status<300){$('import-progress-bar').style.width='100%';$('import-progress-text').textContent='Кампания импортирована. Открываем…';location.href='/?mode=master&fromLauncher=1';}else fail(payload.error||`Ошибка импорта: HTTP ${xhr.status}`);};
    xhr.onerror=()=>fail('Соединение прервано при импорте.');
    xhr.ontimeout=()=>fail('Импорт занял слишком много времени. Повторите попытку.');
    xhr.onabort=()=>fail('Импорт отменён.');
    xhr.send(file);
  }

  $('campaign-grid').addEventListener('click',event=>{const menu=event.target.closest('[data-menu]');if(menu){event.stopPropagation();showMenu(menu.dataset.menu,menu);return;}const card=event.target.closest('[data-campaign]');if(card)openCampaign(card.dataset.campaign);});
  $('create-btn').onclick=openCreateModal;$('campaign-form').onsubmit=createCampaign;
  document.querySelectorAll('[data-close-modal]').forEach(node=>node.onclick=closeCreateModal);
  $('cover-picker').onclick=event=>{if(event.target!==$('campaign-cover'))$('campaign-cover').click();};$('campaign-cover').onchange=()=>{const file=$('campaign-cover').files?.[0];if(!file)return;const url=URL.createObjectURL(file);$('cover-preview').style.backgroundImage=`linear-gradient(rgba(0,0,0,.08),rgba(0,0,0,.28)),url("${url}")`;$('cover-preview').classList.add('has-image');};
  $('import-btn').onclick=()=>{$('import-file').value='';$('import-file').click();};$('import-file').onchange=()=>openImportModal($('import-file').files?.[0]);
  $('import-form').onsubmit=importCampaign;document.querySelectorAll('[data-close-import]').forEach(node=>node.onclick=closeImportModal);
  $('refresh-btn').onclick=()=>loadCampaigns();$('player-name-btn').onclick=openNameModal;$('name-form').onsubmit=event=>{event.preventDefault();savePlayerName($('player-name-input').value);closeNameModal();loadCampaigns(true);};document.querySelectorAll('[data-close-name]').forEach(node=>node.onclick=closeNameModal);
  document.addEventListener('click',event=>{if(state.menu&&!event.target.closest('.card-popover')&&!event.target.closest('[data-menu]'))closeMenu();});
  document.addEventListener('keydown',event=>{if(event.key==='Escape'){closeMenu();closeCreateModal();closeNameModal();closeImportModal();}});
  if(desktop){$('server-btn').onclick=()=>desktop.changeServer?.();$('window-btn').onclick=()=>desktop.toggleFullscreen?.();const exitBtn=$('exit-btn');if(exitBtn)exitBtn.onclick=()=>desktop.requestExit?.();}

  function applyRuleset(){document.documentElement.dataset.ruleset=selectedRuleset;$('ruleset-select').value=selectedRuleset;localStorage.setItem('fatumLauncherRuleset',selectedRuleset);renderCampaigns();}
  $('ruleset-select').onchange=()=>{selectedRuleset=$('ruleset-select').value;applyRuleset();};
  configureMode();applyRuleset();
  if(mode==='player'&&!playerName())openNameModal();
  loadCampaigns();
  refreshTimer=setInterval(()=>loadCampaigns(true),mode==='player'?3000:8000);
  addEventListener('beforeunload',()=>clearInterval(refreshTimer));
})();
