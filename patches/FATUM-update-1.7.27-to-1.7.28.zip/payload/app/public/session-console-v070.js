'use strict';
// compatibility marker: <small class="sc-build">v1.0.4</small>
// FATUM session console v1.1.1 — campaign launcher and desktop shell.
// compatibility marker: FATUM session console v1.0.30
// compatibility marker: Все изменения, включая инвентарь, сохраняются автоматически.
(() => {
  if (typeof FATUM_LAN_SYNC === 'undefined' || !FATUM_LAN_SYNC || (typeof FATUM_EMBEDDED !== 'undefined' && FATUM_EMBEDDED)) return;

  const master = FATUM_APP_MODE === 'master';
  const SKILLS = [
    'Физическая сила','Взлом','Акробатика','Скрытность','Выдержка','Стойкость','Иммунитет',
    'Бдительность','Воля','Меткость','Выживание','Анализ','Эрудиция','Память','Медицина','Механика',
    'Убеждение','Обман','Интуиция','Запугивание','Очарование'
  ];
  const NPC_PRESETS = {
    mob:{label:'Массовка',successDie:'1d4',combatBonus:0,od:2,speed:30,characteristic:0,wounds:{lightMax:1,mediumMax:0,seriousMax:0}},
    regular:{label:'Рядовой',successDie:'1d6',combatBonus:1,od:3,speed:30,characteristic:1,wounds:{lightMax:2,mediumMax:1,seriousMax:0}},
    veteran:{label:'Ветеран',successDie:'1d8',combatBonus:2,od:3,speed:35,characteristic:2,wounds:{lightMax:3,mediumMax:1,seriousMax:1}},
    elite:{label:'Элитный',successDie:'1d8',combatBonus:3,od:4,speed:35,characteristic:3,wounds:{lightMax:2,mediumMax:1,seriousMax:1}},
    boss:{label:'Главный противник',successDie:'1d10',combatBonus:4,od:4,speed:40,characteristic:4,wounds:{lightMax:3,mediumMax:2,seriousMax:1}}
  };

  const NPC_WEAPON_CATEGORIES=['Пистолеты','Карабины','Винтовки','Дробовики','Тяжёлое'];
  const NPC_AUTOMATED_ABILITIES=[
    {id:'main-pristrelka',name:'Пристрелка',note:'После промаха следующая дальнобойная атака по той же цели получает +2 к попаданию.'},
    {id:'main-mark',name:'Метка',note:'1 раз за бой, 3 ОД: −2 МЗ цели против атак NPC; первая атака по ней в ход — с преимуществом.'},
    {id:'main-experienced-look',name:'Опытный взгляд',note:'1 ОД: Анализ 1к10; при успехе +3 к попаданию по цели до конца боя.'}
  ];

  const ATTACK_PRESETS = {
    blank:{label:'Пустой профиль ближнего боя',name:'Новая атака',profile:'Пользовательская атака',category:'melee',hitDie:'1d6',hitDieAimed:'',damage:2,damageTag:'medium',odCost:2,aimedOdCost:3,obCost:0,range:5,radius:0,ignoreMz:0,bonusMode:'manual',manualBonus:0,proficiency:0,accuracy:0,threshold:0,counterAllowed:true,freeAttackAllowed:true,properties:[],description:''},
    ranged:{label:'Пустое дальнобойное оружие',name:'Новое оружие',profile:'Пользовательское оружие',category:'ranged',hitDie:'1d6',hitDieAimed:'',damage:2,damageTag:'medium',odCost:2,aimedOdCost:3,obCost:0,range:100,radius:0,ignoreMz:0,bonusMode:'manual',manualBonus:0,proficiency:0,accuracy:0,threshold:0,counterAllowed:false,freeAttackAllowed:false,properties:[],description:''},
    claws:{label:'Когти · профиль волколака',name:'Когти',profile:'Когти',category:'natural',hitDie:'1d8',hitDieAimed:'',damage:3,damageTag:'medium',odCost:2,range:5,radius:0,ignoreMz:0,bonusMode:'rank',manualBonus:0,proficiency:0,accuracy:0,threshold:0,counterAllowed:true,freeAttackAllowed:true,properties:['Естественное оружие'],description:'Обычная атака, Встречный удар и свободная атака.'},
    bite:{label:'Укус · профиль волколака',name:'Укус',profile:'Укус',category:'natural',hitDie:'1d8',hitDieAimed:'',damage:4,damageTag:'heavy',odCost:3,range:5,radius:0,ignoreMz:0,bonusMode:'rank',manualBonus:0,proficiency:0,accuracy:0,threshold:0,counterAllowed:false,freeAttackAllowed:false,properties:['Естественное оружие'],description:'Сильный укус. Не используется для Встречного или свободного удара.'},
    takedown:{label:'Сбивающий бросок · профиль волколака',name:'Сбивающий бросок',profile:'Сбивающий бросок',category:'natural',hitDie:'1d6',hitDieAimed:'',damage:2,damageTag:'light',odCost:2,range:5,radius:0,ignoreMz:0,bonusMode:'rank',manualBonus:0,proficiency:0,accuracy:0,threshold:0,counterAllowed:false,freeAttackAllowed:false,properties:['Естественное оружие','Сбивание'],description:'После нанесения ранения мастер может применить эффект сбивания по правилам существа.'},
    rending:{label:'Разрывающий удар · профиль паллида',name:'Разрывающий удар',profile:'Разрывающий удар',category:'natural',hitDie:'1d8',hitDieAimed:'',damage:4,damageTag:'heavy',odCost:3,range:5,radius:0,ignoreMz:0,bonusMode:'rank',manualBonus:0,proficiency:0,accuracy:0,threshold:0,counterAllowed:false,freeAttackAllowed:false,properties:['Естественное оружие','Тяжёлый удар'],description:'Тяжёлая естественная атака. Не используется для Встречного или свободного удара.'},
    lunge:{label:'Молниеносный выпад · профиль рокурокуби',name:'Молниеносный выпад',profile:'Молниеносный выпад',category:'natural',hitDie:'1d8',hitDieAimed:'',damage:3,damageTag:'medium',odCost:2,range:10,radius:0,ignoreMz:0,bonusMode:'rank',manualBonus:0,proficiency:0,accuracy:0,threshold:0,counterAllowed:true,freeAttackAllowed:true,properties:['Естественное оружие','Дистанция 10 футов'],description:'Естественная атака с дистанцией 10 футов.'},
    wrap:{label:'Обвивающий захват · профиль рокурокуби',name:'Обвивающий захват',profile:'Обвивающий захват',category:'natural',hitDie:'1d6',hitDieAimed:'',damage:1,damageTag:'light',odCost:2,range:10,radius:0,ignoreMz:0,bonusMode:'rank',manualBonus:0,proficiency:0,accuracy:0,threshold:0,counterAllowed:false,freeAttackAllowed:false,properties:['Естественное оружие','Дистанция 10 футов','Захват'],description:'После нанесения ранения мастер может применить состояние захвата по правилам существа.'}
  };

  let data = null;
  let historyEntries = [];
  let backups = [];
  let campaignWorkspaces = [];
  let officialItems = [];
  let activeTab = master ? 'overview' : 'group';
  let eventSource = null;
  let viewerCharacter = null;
  let panelDocked = true;
  const pendingActions = { effectAdd:false, roll:false, rollSkill:false };
  const diceUi = { characterId:'', skillName:'Бдительность', difficultyDie:'1d6', difficultyModifier:0, condition:'normal', visibility:'public', label:'', extraDice:[] };
  const npcSaveStates = new Map();
  let npcCollapsedIds = new Set();
  let npcCollapseStorageKey = '';
  let npcInputDelegationReady = false;
  let attackBuilderTarget = '';
  let attackBuilderDraft = null;
  let attackAudioLibrary = [];
  let attackSoundPreview = null;

  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const body = extra => JSON.stringify({ clientId: FATUM_LAN_CLIENT_ID, playerName: lanPlayerName(), ...extra });
  const api = (url, options = {}) => lanFetchJson(url, options);
  const byId = id => data?.characters?.find(x => x.id === id);
  const npcById = id => data?.npcs?.find(x => x.id === id);
  const entryName = entry => entry.type === 'npc' ? (npcById(entry.refId)?.name || 'NPC') : (byId(entry.refId)?.name || data?.sharedCharacters?.find(x => x.id === entry.refId)?.name || 'Персонаж');
  const dateText = value => { try { return new Date(value).toLocaleString('ru-RU'); } catch { return value || ''; } };

  function npcState(id) {
    if (!npcSaveStates.has(id)) npcSaveStates.set(id, { timer:null, dirty:false, saving:false, queued:false, revision:0, lastError:'' });
    return npcSaveStates.get(id);
  }
  function ensureNpcCollapseState() {
    const key = `fatum:npc-collapsed:${data?.campaignId || data?.id || 'default'}`;
    if (key === npcCollapseStorageKey) return;
    npcCollapseStorageKey = key;
    try {
      const stored = JSON.parse(localStorage.getItem(key) || '[]');
      npcCollapsedIds = new Set(Array.isArray(stored) ? stored.map(String) : []);
    } catch { npcCollapsedIds = new Set(); }
  }
  function persistNpcCollapseState() {
    if (!npcCollapseStorageKey) ensureNpcCollapseState();
    try { localStorage.setItem(npcCollapseStorageKey, JSON.stringify([...npcCollapsedIds])); } catch {}
  }
  function adoptCampaignData(incoming) {
    const oldCampaignId = data?.campaignId || data?.id || '';
    const newCampaignId = incoming?.campaignId || incoming?.id || '';
    if (oldCampaignId && newCampaignId && oldCampaignId !== newCampaignId) {
      for (const state of npcSaveStates.values()) if (state.timer) clearTimeout(state.timer);
      npcSaveStates.clear(); npcCollapseStorageKey = ''; npcCollapsedIds = new Set();
    } else if (data?.npcs && incoming?.npcs) {
      for (const [id,state] of npcSaveStates) {
        if (!(state.dirty || state.saving || state.timer)) continue;
        const local = data.npcs.find(npc => npc.id === id), index = incoming.npcs.findIndex(npc => npc.id === id);
        if (local && index >= 0) incoming.npcs[index] = structuredClone(local);
      }
    }
    data = incoming;
    const validIds = new Set((data?.npcs || []).map(npc => npc.id));
    for (const [id,state] of npcSaveStates) if (!validIds.has(id)) { if (state.timer) clearTimeout(state.timer); npcSaveStates.delete(id); }
  }

  function refreshNpcSaveIndicators() {
    const states = [...npcSaveStates.values()];
    const hasError = states.some(state => state.lastError);
    const isBusy = states.some(state => state.dirty || state.saving || state.timer);
    const global = document.getElementById('sc-save-indicator');
    if (global) {
      global.textContent = hasError ? 'ошибка автосохранения NPC' : isBusy ? 'сохраняем изменения NPC…' : 'автосохранение активно';
      global.classList.toggle('sc-danger', hasError);
      global.classList.toggle('sc-ok', !hasError && !isBusy);
    }
    document.querySelectorAll('[data-npc-save]').forEach(el => {
      const state = npcSaveStates.get(el.dataset.npcSave);
      if (!state) { el.textContent = 'автосохранение'; el.className = 'sc-npc-save-state'; return; }
      el.textContent = state.lastError ? 'ошибка сохранения' : state.saving ? 'сохраняется…' : state.dirty || state.timer ? 'изменено' : 'сохранено';
      el.className = `sc-npc-save-state${state.lastError ? ' error' : state.saving || state.dirty || state.timer ? ' pending' : ' saved'}`;
    });
  }
  function npcPayloadFromData(id) {
    const n = npcById(id) || {}, a=n.armor||{}, w=n.wounds||{}, wp=n.weapon||{}, ch=n.characteristics||{}, od=n.od||{};
    return {
      name:n.name||'NPC', kind:n.kind||'enemy', creatureType:n.creatureType||'human', rank:n.rank||'regular', visibility:n.visibility||'public', outOfCombat:Boolean(n.outOfCombat),
      successDie:n.successDie||'1d6', baseMz:n.baseMz===null||n.baseMz===undefined||n.baseMz===''?null:+n.baseMz, od:{...structuredClone(od),current:+od.current||0,max:+od.max||0}, speed:+n.speed||0,
      characteristics:{...structuredClone(ch),strength:+ch.strength||0,dexterity:+ch.dexterity||0,endurance:+ch.endurance||0,concentration:+ch.concentration||0,intelligence:+ch.intelligence||0,charisma:+ch.charisma||0},
      morale:{...structuredClone(n.morale||{}),current:+n.morale?.current||0,max:+n.morale?.max||0},
      wounds:{...structuredClone(w),light:+w.light||0,lightMax:+w.lightMax||0,medium:+w.medium||0,mediumMax:+w.mediumMax||0,serious:+w.serious||0,seriousMax:+w.seriousMax||0,critical:Boolean(w.critical)},
      bleeding:Boolean(n.bleeding), armor:{...structuredClone(a),profile:npcArmorProfileName(a),name:a.name||'',class:a.class||officialItemByName(npcArmorProfileName(a))?.armorClass||'none',bzCurrent:+a.bzCurrent||0,bzMax:+a.bzMax||(+officialItemByName(npcArmorProfileName(a))?.armorBz||0)},
      inventory:structuredClone(Array.isArray(n.inventory)?n.inventory:[]), equipment:structuredClone(n.equipment||{}), attacks:structuredClone(Array.isArray(n.attacks)?n.attacks:[]),
      weaponTrainingMode:n.weaponTrainingMode||((wp.bonusMode==='formula')?'detailed':(wp.bonusMode||'rank')),
      weaponProficiencies:structuredClone(n.weaponProficiencies||{}), weaponAccuracy:+n.weaponAccuracy||0, manualCombatBonus:+n.manualCombatBonus||0,
      abilityIds:structuredClone(Array.isArray(n.abilityIds)?n.abilityIds:[]),
      weapon:structuredClone(wp), abilities:n.abilities||'', behavior:n.behavior||'', notes:n.notes||''
    };
  }
  function applyNpcDraft(id, payload) {
    const index = data?.npcs?.findIndex(npc => npc.id === id) ?? -1;
    if (index < 0) return null;
    data.npcs[index] = { ...data.npcs[index], ...payload, id };
    return data.npcs[index];
  }
  function syncNpcDraftFromDom(id) {
    const el = document.querySelector(`[data-npc="${CSS.escape(id)}"]`);
    if (!el || !el.querySelector('[data-f="name"]')) return npcById(id);
    return applyNpcDraft(id, npcPayload(id));
  }
  function updateNpcDerivedUi(id) {
    const n = npcById(id); if (!n) return;
    const card = document.querySelector(`[data-npc="${CSS.escape(id)}"]`); if (!card) return;
    const name = card.querySelector('[data-npc-name]'); if (name) name.textContent = n.name || 'NPC';
    const hit = card.querySelector('.sc-npc-hit strong'); if (hit) hit.textContent=npcTrainingSummary(n);
    const mzInput = card.querySelector('[data-f="baseMz"]'); if (mzInput) mzInput.placeholder=`Авто: ${4 + Number(n.characteristics?.dexterity||0)}`;
    const condition = card.querySelector('.sc-npc-condition'); if (condition) { condition.textContent=npcConditionText(n); condition.classList.toggle('sc-danger',Boolean(n.outOfCombat)); }
  }
  function queueNpcSave(id, delay=750) {
    const state = npcState(id);
    state.revision += 1; state.dirty = true; state.lastError = '';
    if (state.timer) clearTimeout(state.timer);
    state.timer = setTimeout(() => { state.timer=null; flushNpcSave(id).catch(showError); }, Math.max(0, delay));
    refreshNpcSaveIndicators();
  }
  async function flushNpcSave(id) {
    const state = npcState(id);
    if (state.saving) { state.queued = true; return; }
    if (!state.dirty) { refreshNpcSaveIndicators(); return; }
    state.saving = true; state.dirty = false; state.queued = false; state.lastError = '';
    const revision = state.revision;
    const payload = npcPayloadFromData(id);
    refreshNpcSaveIndicators();
    try {
      const result = await api(`/api/npcs/${encodeURIComponent(id)}`, { method:'PUT', body:body({ ...payload, autosave:true }) });
      const index = data?.npcs?.findIndex(npc => npc.id === id) ?? -1;
      if (index >= 0 && state.revision === revision && !state.dirty) data.npcs[index] = result.npc;
      else if (index >= 0 && result.npc?.updatedAt) data.npcs[index].updatedAt = result.npc.updatedAt;
    } catch (error) {
      state.dirty = true; state.lastError = error?.message || String(error);
      throw error;
    } finally {
      state.saving = false;
      if (state.queued || state.dirty && !state.lastError) {
        if (state.timer) clearTimeout(state.timer);
        state.timer = setTimeout(() => { state.timer=null; flushNpcSave(id).catch(showError); }, 180);
      }
      refreshNpcSaveIndicators();
    }
  }
  function npcEditorChanged(event) {
    // NPC editor has three kinds of editable controls:
    // ordinary fields (data-f), category proficiencies (data-prof) and
    // automated ability toggles (data-npc-ability). v1.6.9 only listened
    // to data-f, so proficiency/ability changes stayed in the DOM but were
    // never copied into the autosave draft and disappeared after reopening.
    const field = event.target.closest?.('[data-f], [data-prof], [data-npc-ability]');
    if (!field) return;
    const card = field.closest('[data-npc]'); if (!card) return;
    const id = card.dataset.npc;
    syncNpcDraftFromDom(id); updateNpcDerivedUi(id);
    // Checkbox/select changes should be persisted quickly; free text keeps
    // the longer debounce so typing does not spam the LAN server.
    queueNpcSave(id, event.type === 'change' ? 180 : 750);
  }
  function bindNpcInputDelegation() {
    if (npcInputDelegationReady) return;
    const root = document.getElementById('sc-body'); if (!root) return;
    root.addEventListener('input', npcEditorChanged);
    root.addEventListener('change', npcEditorChanged);
    npcInputDelegationReady = true;
  }

  function inject() {
    const target = document.querySelector('.char-management') || document.querySelector('.sheet-header');
    if (target && !document.getElementById('sc-launch-btn')) {
      const button = document.createElement('button');
      button.id = 'sc-launch-btn'; button.className = 'btn btn-primary';
      button.textContent = master ? '🎛 Сессия' : '🎲 Группа и сессия'; button.onclick = open;
      target.appendChild(button);
    }
    const partyButton = document.getElementById('sc-party-launch-btn');
    if (partyButton) partyButton.style.display = master ? '' : 'none';
    if (!document.getElementById('sc-overlay')) {
      document.body.insertAdjacentHTML('beforeend', `
        <div id="sc-effect-banner" class="sc-effect-banner" onclick="scOpenTab('effects')"></div>
        <div id="sc-overlay" class="sc-overlay">
          <div class="sc-panel">
            <div class="sc-head">
              <h2>${master ? 'Пульт мастера' : 'Сессия FATUM'} <small class="sc-build">v1.1.1</small><!-- compatibility marker: <small class="sc-build">v1.0.30</small> --><!-- compatibility marker: v1.0.29</small> --><!-- compatibility marker: v1.0.28</small> --></h2>
              <span id="sc-save-indicator" class="sc-sub">автосохранение активно</span>
              ${master ? '<button id="sc-dock-btn" class="btn btn-ghost" onclick="scToggleDock()">На граф</button>' : ''}
              <button class="btn btn-ghost" onclick="scRefresh()">↻</button>
              <button class="btn btn-danger" onclick="scClose()">Закрыть</button>
            </div>
            <div id="sc-tabs" class="sc-tabs"></div>
            <div id="sc-body" class="sc-body"></div>
          </div>
        </div>
        <div id="sc-viewer" class="sc-viewer">
          <div class="sc-viewer-head"><strong id="sc-viewer-title">Лист</strong><span class="sc-sub">режим чтения</span><button class="btn btn-danger" onclick="scCloseViewer()">Закрыть</button></div>
          <iframe id="sc-viewer-frame"></iframe>
        </div>`);
    }
    bindNpcInputDelegation();
    updateBanner();
  }

  const masterTabs = [['campaigns','Кампании'],['overview','Быстрые действия'],['initiative','Инициатива'],['npcs','NPC'],['history','Журнал'],['cargo','Общий груз'],['effects','Глобальные эффекты'],['dice','Кубики'],['access','Доступ'],['saves','Сохранения']];
  const playerTabs = [['group','Группа'],['initiative','Инициатива'],['cargo','Общий груз'],['effects','Эффекты'],['dice','Кубики']];

  function renderTabs() {
    const tabs = master ? masterTabs : playerTabs;
    document.getElementById('sc-tabs').innerHTML = tabs.map(([id,label]) => `<button class="sc-tab ${activeTab===id?'active':''}" onclick="scOpenTab('${id}')">${label}</button>`).join('');
  }
  function applyDockMode() {
    const overlay = document.getElementById('sc-overlay');
    if (!overlay) return;
    const onGraph = master && document.body.classList.contains('party-mode-active');
    overlay.classList.toggle('docked', onGraph && panelDocked);
    const button = document.getElementById('sc-dock-btn');
    if (button) button.textContent = onGraph && panelDocked ? 'Развернуть' : 'На граф';
  }
  function open() {
    const overlay = document.getElementById('sc-overlay');
    overlay.classList.add('open'); applyDockMode(); refresh().catch(showError);
  }
  function syncVisibleNpcDrafts() {
    document.querySelectorAll('[data-npc]').forEach(card => {
      const id = card.dataset.npc;
      if (id && card.querySelector('[data-f="name"]')) syncNpcDraftFromDom(id);
    });
  }
  function close() {
    // Capture the live DOM before the panel disappears. This is deliberately
    // redundant with change/input autosave and protects fast click → close
    // sequences as well as future NPC controls added outside data-f.
    syncVisibleNpcDrafts();
    document.getElementById('sc-overlay')?.classList.remove('open');
    for (const id of npcSaveStates.keys()) {
      const state=npcState(id);
      if (state.timer) { clearTimeout(state.timer); state.timer=null; }
      if (state.dirty) flushNpcSave(id).catch(showError);
    }
  }
  function toggleDock() { panelDocked = !panelDocked; applyDockMode(); }
  function openTab(id) {
    if (activeTab==='npcs' && id!=='npcs') {
      syncVisibleNpcDrafts();
      for (const npcId of npcSaveStates.keys()) {
        const state=npcState(npcId);
        if (state.timer) { clearTimeout(state.timer); state.timer=null; }
        if (state.dirty) flushNpcSave(npcId).catch(showError);
      }
    }
    activeTab = id; render();
  }
  function showError(error) { lanToast(error?.message || String(error), 'error'); }

  async function refresh() {
    adoptCampaignData(await api(`/api/campaign?mode=${master?'master':'player'}&clientId=${encodeURIComponent(FATUM_LAN_CLIENT_ID)}`, { method:'GET', headers:{} }));
    if (master) {
      const [h,b,cw,catalog,audioCatalog] = await Promise.all([api('/api/history?limit=160',{method:'GET',headers:{}}), api('/api/backups',{method:'GET',headers:{}}), api('/api/campaigns',{method:'GET',headers:{}}), api('/api/battlemap/catalog/items',{method:'GET',headers:{}}), api(`/api/battlemap/audio/catalog?mode=master&clientId=${encodeURIComponent(FATUM_LAN_CLIENT_ID)}`,{method:'GET',headers:{}}).catch(()=>({items:[]}))]);
      historyEntries = h.entries || []; backups = b.backups || []; campaignWorkspaces = cw.campaigns || []; officialItems = catalog.items || []; attackAudioLibrary = audioCatalog.items || [];
    }
    if (!diceUi.characterId || !(data.characters||[]).some(c => c.id === diceUi.characterId)) diceUi.characterId = data.characters?.[0]?.id || '';
    render(); updateBanner(); applyDockMode();
  }

  function updateBanner() {
    const banner = document.getElementById('sc-effect-banner'); if (!banner) return;
    const effects = (data?.globalEffects || []).filter(x => x.active);
    banner.classList.toggle('visible', effects.length > 0);
    banner.innerHTML = effects.length ? `<strong>Эффекты сцены:</strong> ${effects.slice(0,3).map(x=>`<span class="sc-effect-pill">${esc(x.name)}${x.duration?` · ${esc(x.duration)}`:''}</span>`).join('')}${effects.length>3?` +${effects.length-3}`:''}` : '';
  }

  function render() {
    if (!document.getElementById('sc-body')) return;
    renderTabs();
    const fn = {campaigns:renderCampaigns,overview:renderOverview,initiative:renderInitiative,npcs:renderNpcs,history:renderHistory,cargo:renderCargo,effects:renderEffects,dice:renderDice,access:renderAccess,saves:renderSaves,group:renderGroup}[activeTab];
    document.getElementById('sc-body').innerHTML = fn ? fn() : '<div class="sc-empty">Раздел недоступен.</div>';
    updateBanner(); applyDockMode();
  }

  function portrait(x) { return x?.portrait ? `<img class="sc-portrait" src="${esc(x.portrait)}" alt="">` : '<div class="sc-portrait"></div>'; }
  function statSummary(c) {
    const s = c.summary || c.state || {}, w = s.wounds || {}, m = s.morale || {};
    return `<div class="sc-statline"><span>ОД ${s.odCurrent??s.od??0}/${s.odMax??s.od??0}</span><span>ОБ ${s.obCurrent??s.ob??0}/${s.obMax??s.ob??0}</span><span>БЗ ${s.bz??0}/${s.bzMax??0}</span><span>Мораль ${s.moraleCurrent??m.current??0}/${s.moraleMax??m.max??0}</span><span>Раны ${w.light||0}/${w.medium||0}/${w.serious||0}${w.critical?' ⚠':''}</span>${(s.bleeding??s.medical?.bleeding)?'<span class="sc-danger">Кровотечение</span>':''}</div>`;
  }

  function quickButtons(c) {
    const effects = c.state?.activeEffects || [];
    return `<div class="sc-quick-sections">
      <div><div class="sc-mini-title">Ресурсы</div><div class="sc-actions">
        <button class="btn btn-sm" onclick="scQuick('${c.id}','od',-1)">ОД −</button><button class="btn btn-sm" onclick="scQuick('${c.id}','od',1)">ОД +</button>
        <button class="btn btn-sm" onclick="scQuick('${c.id}','ob',-1)">ОБ −</button><button class="btn btn-sm" onclick="scQuick('${c.id}','ob',1)">ОБ +</button>
        <button class="btn btn-sm" onclick="scQuick('${c.id}','bz',-1)">БЗ −</button><button class="btn btn-sm" onclick="scQuick('${c.id}','bz',1)">БЗ +</button>
        <button class="btn btn-sm" onclick="scQuick('${c.id}','morale',-1)">Мораль −</button><button class="btn btn-sm" onclick="scQuick('${c.id}','morale',1)">Мораль +</button>
      </div></div>
      <div><div class="sc-mini-title">Ранить</div><div class="sc-actions">
        <button class="btn btn-danger btn-sm" onclick="scQuick('${c.id}','wound',1,'light')">+ лёгкое</button>
        <button class="btn btn-danger btn-sm" onclick="scQuick('${c.id}','wound',1,'medium')">+ среднее</button>
        <button class="btn btn-danger btn-sm" onclick="scQuick('${c.id}','wound',1,'serious')">+ серьёзное</button>
        <button class="btn btn-danger btn-sm" onclick="scQuickValue('${c.id}','critical',true)">+ критическое</button>
        <button class="btn btn-danger btn-sm" onclick="scQuickValue('${c.id}','bleeding',true)">Начать кровотечение</button>
      </div></div>
      <div><div class="sc-mini-title">Лечение</div><div class="sc-actions">
        <button class="btn btn-sm sc-heal" onclick="scQuick('${c.id}','wound',-1,'light')">− лёгкое</button>
        <button class="btn btn-sm sc-heal" onclick="scQuick('${c.id}','wound',-1,'medium')">− среднее</button>
        <button class="btn btn-sm sc-heal" onclick="scQuick('${c.id}','wound',-1,'serious')">− серьёзное</button>
        <button class="btn btn-sm sc-heal" onclick="scQuickValue('${c.id}','bleeding',false)">Остановить кровь</button>
        <button class="btn btn-sm sc-heal" onclick="scQuick('${c.id}','stabilize',0)">Стабилизировать</button>
        <button class="btn btn-sm sc-heal" onclick="scQuick('${c.id}','heal-all',0)">Полное лечение</button>
      </div></div>
      <div><div class="sc-mini-title">Эффекты</div><div class="sc-actions"><button class="btn btn-sm" onclick="scQuickEffect('${c.id}')">+ эффект</button>${effects.map(e=>`<button class="btn btn-ghost btn-sm" title="Снять эффект" onclick="scQuickRemoveEffect('${c.id}','${e.id}')">× ${esc(e.name||e.title||'Эффект')}</button>`).join('')}</div></div>
    </div>`;
  }

  function renderCampaigns() {
    const active = campaignWorkspaces.find(item => item.active);
    const emptyWorkspace = campaignWorkspaces.length <= 1 && active && !(active.characters||0) && !(active.npcs||0) && !(active.scenes||0);
    return `<div class="sc-section"><div class="sc-section-head"><div><h3>Кампании</h3><p class="sc-sub">Каждая кампания хранит собственные листы, NPC, карты, токены, журнал и сохранения.</p></div><div class="sc-actions"><button class="btn btn-primary" onclick="scCampaignCreate()">＋ Новая кампания</button><button class="btn" onclick="document.getElementById('sc-campaign-import-file')?.click()">⇧ Импорт .fatum / JSON</button><input id="sc-campaign-import-file" type="file" accept=".fatum,.zip,application/zip,application/json,.json" hidden onchange="scCampaignImportFile(this)"></div></div>
      ${emptyWorkspace?`<div class="sc-card accent"><div class="sc-title">Первый запуск</div><div class="sc-sub">Можно начать с пустой кампании или импортировать .fatum, старый snapshot/backup/campaign.json целиком. Импорт создаст отдельную кампанию и не затронет текущую.</div><div class="sc-actions"><button class="btn btn-primary" onclick="document.getElementById('sc-campaign-import-file')?.click()">Выбрать архив кампании</button></div></div>`:''}
      <div class="sc-list">${campaignWorkspaces.map(item=>`<article class="sc-card ${item.active?'active':''}"><div><strong>${esc(item.name)}</strong>${item.active?'<span class="sc-badge">активна</span>':''}<div class="sc-sub">Листов: ${item.characters||0} · NPC: ${item.npcs||0} · сцен: ${item.scenes||0}</div></div><div class="sc-actions">${item.active?'':`<button class="btn btn-primary btn-sm" onclick="scCampaignActivate('${item.id}')">Открыть</button>`}<button class="btn btn-ghost btn-sm" onclick="scCampaignRename('${item.id}')">✎</button>${item.active?'':`<button class="btn btn-danger btn-sm" onclick="scCampaignDelete('${item.id}')">🗑</button>`}</div></article>`).join('')}</div>
      ${active?`<div class="sc-note">Сейчас открыта: <strong>${esc(active.name)}</strong>. Подключённые игроки автоматически перейдут в неё.</div>`:''}</div>`;
  }

  async function campaignCreate() { const name=await fatumPrompt('Название новой кампании:','Новая кампания',{title:'Создать кампанию',maxLength:180});if(!name?.trim())return;await api('/api/campaigns',{method:'POST',body:body({name:name.trim(),activate:true})});location.reload(); }
  async function campaignActivate(id) { if(!confirm('Переключить сервер на выбранную кампанию? Все подключённые игроки перейдут вместе с вами.'))return;await api(`/api/campaigns/${encodeURIComponent(id)}/activate`,{method:'POST',body:body({})});location.reload(); }
  async function campaignRename(id) { const item=campaignWorkspaces.find(x=>x.id===id);const name=await fatumPrompt('Новое название кампании:',item?.name||'',{title:'Переименовать кампанию',maxLength:180});if(!name?.trim())return;await api(`/api/campaigns/${encodeURIComponent(id)}`,{method:'PUT',body:body({name:name.trim()})});await refresh(); }
  async function campaignDelete(id) { const item=campaignWorkspaces.find(x=>x.id===id);if(!confirm(`Удалить кампанию «${item?.name||id}»? Она будет перемещена в data/campaigns-trash.`))return;await api(`/api/campaigns/${encodeURIComponent(id)}`,{method:'DELETE',body:body({})});await refresh(); }
  function formatBytes(bytes){const value=Math.max(0,Number(bytes)||0);if(value<1024)return`${value} Б`;if(value<1024*1024)return`${(value/1024).toFixed(1)} КБ`;return`${(value/1024/1024).toFixed(1)} МБ`;}
  function uploadCampaignArchive(file,name){return new Promise((resolve,reject)=>{const query=new URLSearchParams({name,clientId:FATUM_LAN_CLIENT_ID,playerName:lanPlayerName()});const xhr=new XMLHttpRequest();xhr.open('POST',`/api/campaigns/import-backup-file?${query}`);xhr.withCredentials=true;xhr.setRequestHeader('Content-Type','application/octet-stream');xhr.upload.onprogress=e=>{if(e.lengthComputable)lanToast(`Загрузка: ${Math.round(e.loaded/e.total*100)}% · ${formatBytes(e.loaded)} из ${formatBytes(e.total)}`);};xhr.onerror=()=>reject(new Error('Соединение прервано при загрузке кампании.'));xhr.onload=()=>{let payload={};try{payload=JSON.parse(xhr.responseText||'{}');}catch{}if(xhr.status>=200&&xhr.status<300)resolve(payload);else reject(new Error(payload.error||`HTTP ${xhr.status}`));};xhr.send(file);});}
  async function campaignImportFile(input) {
    const file=input?.files?.[0]; if(!file)return;
    try {
      if(file.size>512*1024*1024)throw new Error('Файл кампании превышает предел 512 МБ.');
      const suggested=file.name.replace(/\.(?:fatum|zip|json)$/i,'')||'Импортированная кампания';
      const name=await fatumPrompt('Название импортируемой кампании:',suggested,{title:'Импорт кампании',maxLength:180}); if(!name?.trim())return;
      await uploadCampaignArchive(file,name.trim());
      location.reload();
    } catch(error) { showError(error); }
    finally { if(input)input.value=''; }
  }

  function renderOverview() {
    if (!master) return '';
    return `<div class="sc-grid">${(data.characters||[]).map(c=>`<div class="sc-card accent">${portrait(c)}<div class="sc-title">${esc(c.name)}</div><div class="sc-sub">${esc(c.ownerName||'не назначен')} · доступ: ${esc(c.visibility)}</div>${statSummary(c)}${quickButtons(c)}</div>`).join('') || '<div class="sc-empty">Нет персонажей.</div>'}</div>`;
  }

  function initiativeBreakdown(e) {
    const tie = e.tieBreaks?.length ? ` · перебросы: ${e.tieBreaks.join(', ')}` : '';
    return `${esc(e.cube||'1d6')} (${e.roll||0}) ${Number(e.bonus)>=0?'+':''}${e.bonus||0}${tie}`;
  }
  function renderInitiative() {
    const init = data.initiative || {round:1,currentIndex:0,entries:[]};
    const rows = (init.entries||[]).map((e,i)=>`<tr class="${i===init.currentIndex?'sc-current':''}"><td>${i===init.currentIndex?'▶':''}</td><td class="sc-initiative-name">${esc(entryName(e))}<div class="sc-sub">${initiativeBreakdown(e)}</div></td><td>${e.type==='npc'?'NPC':'Персонаж'}</td><td>${master?`<input type="number" value="${e.score}" style="width:70px" onchange="scInitScore(${i},this.value)">`:e.score}</td><td>${master?`<div class="sc-inline"><button class="btn btn-sm" onclick="scInitMove(${i},-1)">↑</button><button class="btn btn-sm" onclick="scInitMove(${i},1)">↓</button><button class="btn btn-danger btn-sm" onclick="scInitRemove(${i})">×</button></div>`:''}</td></tr>`).join('');
    const controls = master ? `<div class="sc-card blue"><div class="sc-title">Автоматическая инициатива</div><div class="sc-sub">Персонажи: куб и бонус навыка «Бдительность». NPC: куб успеха + Концентрация. При ничьей связанные участники перебрасывают инициативу.</div><div class="sc-actions"><button class="btn btn-primary" onclick="scInitRoll('all')">Начать бой: все</button><button class="btn" onclick="scInitRoll('current')">Перебросить текущих</button><button class="btn" onclick="scInitAddAll('character')">+ все персонажи</button><button class="btn" onclick="scInitAddAll('npc')">+ все NPC</button><button class="btn btn-danger" onclick="scInitClear()">Очистить очередь</button></div><div class="sep"></div><div class="sc-title">Добавить вручную</div><div class="sc-form-grid"><label>Участник<select id="sc-init-ref">${[...(data.characters||[]).map(x=>`<option value="character:${x.id}">${esc(x.name)}</option>`),...(data.npcs||[]).map(x=>`<option value="npc:${x.id}">${esc(x.name)}</option>`)].join('')}</select></label><label>Результат<input id="sc-init-score" type="number" value="0"></label></div><div class="sc-actions"><button class="btn" onclick="scInitAdd()">Добавить</button><button class="btn" onclick="scInitAdvance('back')">← Предыдущий</button><button class="btn btn-primary" onclick="scInitAdvance('next')">Следующий ход →</button></div></div>` : '';
    return `<div class="sc-two"><div class="sc-card accent"><div class="sc-title">Раунд ${init.round} · ход ${(init.entries||[]).length?init.currentIndex+1:0}</div><table class="sc-table"><thead><tr><th></th><th>Участник</th><th>Тип</th><th>Инициатива</th><th></th></tr></thead><tbody>${rows||'<tr><td colspan="5">Инициатива пуста.</td></tr>'}</tbody></table></div>${controls}</div>`;
  }

  function rankOptions(rank) { return Object.entries(NPC_PRESETS).map(([id,p])=>`<option value="${id}" ${rank===id?'selected':''}>${p.label}</option>`).join(''); }
  function npcHitBonus(n) {
    const preset=NPC_PRESETS[n.rank]||NPC_PRESETS.regular,mode=n.weaponTrainingMode||((n.weapon?.bonusMode==='formula')?'detailed':(n.weapon?.bonusMode||'rank'));
    if(mode==='manual')return +n.manualCombatBonus||0;
    if(mode==='detailed')return null;
    return preset.combatBonus;
  }
  function npcTrainingSummary(n){const value=npcHitBonus(n),mode=n.weaponTrainingMode||'rank';if(mode==='detailed')return `Детальный режим: Владение категории + ½ Меткости (${Math.floor((+n.weaponAccuracy||0)/2)}) − Порог конкретного профиля.`;return `${mode==='manual'?'Ручной':'По рангу'}: ${value>=0?'+':''}${value} к попаданию.`;}
  function npcTrainingHtml(n){const prof=n.weaponProficiencies||{},mode=n.weaponTrainingMode||((n.weapon?.bonusMode==='formula')?'detailed':(n.weapon?.bonusMode||'rank'));return `<details open><summary>Попадание и владение оружием</summary><p class="sc-sub">По умолчанию NPC использует готовый боевой бонус по рангу. Детальный режим включает владение категориями и Порог каждого оружия; эти значения реально участвуют в атаках и доступности специальных режимов.</p><div class="sc-form-grid"><label>Режим попадания<select data-f="weaponTrainingMode"><option value="rank" ${mode==='rank'?'selected':''}>По рангу (правила NPC)</option><option value="detailed" ${mode==='detailed'?'selected':''}>Детальный — как у персонажа</option><option value="manual" ${mode==='manual'?'selected':''}>Ручной общий бонус</option></select></label><label>Меткость для детального режима<input data-f="weaponAccuracy" type="number" min="0" max="20" value="${n.weaponAccuracy??n.characteristics?.concentration??0}"></label><label>Ручной бонус<input data-f="manualCombatBonus" type="number" min="-20" max="30" value="${n.manualCombatBonus??0}"></label>${NPC_WEAPON_CATEGORIES.map(category=>`<label>${esc(category)}<input data-prof="${esc(category)}" type="number" min="0" max="6" value="${prof[category]??0}"></label>`).join('')}</div><div class="sc-npc-hit"><strong>${esc(npcTrainingSummary(n))}</strong></div></details>`;}
  function npcAbilitiesHtml(n){const selected=new Set(Array.isArray(n.abilityIds)?n.abilityIds:[]);return `<details open><summary>Автоматизированные способности</summary><p class="sc-sub">Выбранные способности появятся у NPC в панели «Особенности» на боевой карте и используют ту же автоматизацию, что у персонажей.</p><div class="sc-npc-ability-grid">${NPC_AUTOMATED_ABILITIES.map(a=>`<label class="sc-checkbox-label sc-npc-ability"><input type="checkbox" data-npc-ability="${a.id}" ${selected.has(a.id)?'checked':''}><span><strong>${esc(a.name)}</strong><small>${esc(a.note)}</small></span></label>`).join('')}</div></details>`;}
  function npcConditionText(n) {
    const w=n.wounds||{}, parts=[];
    if(n.outOfCombat) return 'Выведен из боя';
    if(w.critical) parts.push('Критическое: не действует');
    if((w.serious||0)>0) {
      const stabilizing=npcArmorProfileName(n.armor||{})==='Стабилизирующая тяжёлая броня';
      parts.push(n.rank==='regular'?'Серьёзное: перевести в Критическое':`Серьёзное: скорость вдвое, ${stabilizing?'−1 (стабилизирующая броня)':'−2'} ко всем проверкам`);
    }
    if((w.medium||0)>0) parts.push('Среднее: помеха на боевые действия');
    if((w.light||0)>0) parts.push('Лёгкое: без штрафа');
    if(n.bleeding) parts.push('Кровотечение');
    if(n.rank==='mob' && ((w.light||0)+(w.medium||0)+(w.serious||0)>0 || w.critical)) parts.unshift('Массовка: любое ранение выводит из боя');
    return parts.join(' · ') || 'Боеспособен';
  }
  function officialItemByName(name){return officialItems.find(item=>item.name===name)||null;}
  function armorProfileItems(){return officialItems.filter(item=>item?.armorClass&&/броня/i.test(item.type||''));}
  function npcArmorProfileName(armor={}){
    const direct=String(armor.profile||armor.armorProfile||'').trim();if(direct&&armorProfileItems().some(item=>item.name===direct))return direct;
    const name=String(armor.name||armor.model||'').trim();if(!name)return '';
    const byProfile=armorProfileItems().find(item=>item.name===name);if(byProfile)return byProfile.name;
    return armorProfileItems().find(item=>Array.isArray(item.models)&&item.models.includes(name))?.name||'';
  }
  function npcArmorProfileOptions(armor={}){
    const selected=npcArmorProfileName(armor);return `<option value="" ${!selected?'selected':''}>Пользовательская / без профиля</option>`+armorProfileItems().map(item=>`<option value="${esc(item.name)}" ${selected===item.name?'selected':''}>${esc(item.name)} · БЗ ${item.armorBz??0}</option>`).join('');
  }
  function npcArmorEffective(armor={}){
    const profile=npcArmorProfileName(armor),def=profile?officialItemByName(profile):null;
    const bzMax=Math.max(0,Number(def?.armorBz??armor.bzMax??0)||0);
    const rawCurrent=Math.max(0,Number(armor.bzCurrent??bzMax)||0);
    return {...armor,profile,class:def?.armorClass||armor.class||'none',bzMax,bzCurrent:def?Math.min(bzMax,rawCurrent):rawCurrent};
  }
  function npcCatalogOptions(){return officialItems.map(item=>`<option value="${esc(item.name)}">${esc(item.name)} · ${esc(item.type||'Предмет')}</option>`).join('');}
  function npcLoadoutHtml(n){
    const inventory=Array.isArray(n.inventory)?n.inventory:[],equipment=n.equipment||{};
    const rows=inventory.map(item=>{const official=officialItemByName(item.name),type=official?.type||'Предмет',equipped=[equipment.weapon1===item.uid?'Оружие 1':'',equipment.weapon2===item.uid?'Оружие 2':''].filter(Boolean).join(', ');return `<div class="sc-npc-item-row"><div><strong>${esc(item.name)}</strong><small>${esc(type)}${equipped?` · экипировано: ${esc(equipped)}`:''}</small></div><label>Кол-во<input type="number" min="0" max="999" value="${item.qty??1}" onchange="scNpcItemQty('${n.id}','${item.uid}',this.value)"></label><button class="btn btn-sm" onclick="scNpcEquipItem('${n.id}','${item.uid}','weapon1')">В руку 1</button><button class="btn btn-sm" onclick="scNpcEquipItem('${n.id}','${item.uid}','weapon2')">В руку 2</button><button class="btn btn-danger btn-sm" onclick="scNpcItemRemove('${n.id}','${item.uid}')">×</button></div>`;}).join('');
    return `<details open><summary>Официальное снаряжение и расходники</summary><div class="sc-sub">Оружие из этого списка использует характеристики и особенности официального листа. Гранаты и расходники становятся доступны NPC на боевой карте.</div><div class="sc-form-grid"><label>Предмет<select id="sc-npc-catalog-${n.id}">${npcCatalogOptions()}</select></label><label>Количество<input id="sc-npc-catalog-qty-${n.id}" type="number" min="1" max="999" value="1"></label></div><button class="btn" onclick="scNpcItemAdd('${n.id}')">+ Добавить предмет</button><div class="sc-npc-loadout">${rows||'<div class="sc-empty">Официальных предметов пока нет.</div>'}</div><div class="sc-actions"><button class="btn btn-ghost btn-sm" onclick="scNpcClearEquip('${n.id}')">Снять оружие</button></div></details>`;
  }

  function attackTargetEntries(){return [...(data?.npcs||[]).map(item=>({key:`npc:${item.id}`,label:`NPC · ${item.name}`,type:'npc',entity:item})),...(data?.characters||[]).map(item=>({key:`character:${item.id}`,label:`Персонаж · ${item.name}`,type:'character',entity:item}))];}
  function attackTargetEntry(key=attackBuilderTarget){return attackTargetEntries().find(item=>item.key===key)||attackTargetEntries()[0]||null;}
  function targetAttackProfiles(entry){if(!entry)return[];return entry.type==='npc'?(entry.entity.attacks||[]):(entry.entity.state?._lanCustomWeapons||[]);}
  function profileBadgeText(profile){const category=profile.category==='natural'?'естественная':profile.category==='ranged'?'дальнобойная':'ближний бой';return `${category} · ${profile.hitDie||profile.hitDieNormal||'1d6'} · урон ${profile.damage??0} · ${profile.odCost??2} ОД · ${profile.range??5} фт · звук: ${attackSoundName(profile.soundId)}`;}
  function attackProfilesHtml(entry){const list=targetAttackProfiles(entry);return `<div class="sc-custom-profile-list">${list.map(profile=>`<div class="sc-custom-profile-row"><div><strong>${esc(profile.name||'Профиль')}</strong><small>${esc(profileBadgeText(profile))}</small></div><button class="btn btn-sm" onclick="scAttackBuilderEdit('${entry.key}','${profile.id}')">Изменить</button><button class="btn btn-danger btn-sm" onclick="scAttackBuilderRemove('${entry.key}','${profile.id}')">Удалить</button></div>`).join('')||'<div class="sc-empty">Пользовательских профилей пока нет.</div>'}</div>`;}
  function attackAudioScopeLabel(scope){return scope==='core'?'встроенный':scope==='shared'?'общий':'кампания';}
  function attackSoundOptions(selected){
    const value=String(selected||'');
    const known=new Set(attackAudioLibrary.map(item=>item.id));
    const missing=value&&value!=='off'&&!known.has(value)?`<option value="${esc(value)}" selected>Недоступный звук (${esc(value)})</option>`:'';
    return `<option value="" ${!value?'selected':''}>Автоматически по типу оружия</option><option value="off" ${value==='off'?'selected':''}>Без звука</option>${missing}${attackAudioLibrary.map(item=>`<option value="${esc(item.id)}" ${value===item.id?'selected':''}>${esc(item.name)} · ${attackAudioScopeLabel(item.scope)}</option>`).join('')}`;
  }
  function attackSoundName(soundId){if(!soundId)return'автоматически';if(soundId==='off')return'без звука';return attackAudioLibrary.find(item=>item.id===soundId)?.name||'выбранный файл';}
  function attackBuilderHtml(){
    const entries=attackTargetEntries();if(!entries.length)return '<div class="sc-card"><div class="sc-empty">Сначала создайте NPC или персонажа.</div></div>';
    if(!attackBuilderTarget||!entries.some(item=>item.key===attackBuilderTarget))attackBuilderTarget=entries[0].key;
    const entry=attackTargetEntry(),draft=attackBuilderDraft?structuredClone(attackBuilderDraft):structuredClone(ATTACK_PRESETS.blank);
    const dieOptions=['','1d4','1d6','1d8','1d10','1d12'].map(value=>`<option value="${value}" ${String(draft.hitDieAimed||'')===value?'selected':''}>${value||'— нет —'}</option>`).join('');
    const normalDice=['1d4','1d6','1d8','1d10','1d12'].map(value=>`<option value="${value}" ${String(draft.hitDie||'1d6')===value?'selected':''}>${value}</option>`).join('');
    return `<div class="sc-card sc-attack-builder"><div class="sc-title">Конструктор оружия и атак</div><p class="sc-sub">Создаёт отдельный боевой профиль и выдаёт его выбранному NPC или персонажу. Профили можно изменять и удалять; старое официальное оружие продолжает работать.</p>
      <div class="sc-form-grid"><label>Кому выдать<select id="sc-attack-target" onchange="scAttackBuilderSetTarget(this.value)">${entries.map(item=>`<option value="${item.key}" ${item.key===entry.key?'selected':''}>${esc(item.label)}</option>`).join('')}</select></label><label>Шаблон<select id="sc-attack-preset" onchange="scAttackBuilderApplyPreset(this.value)">${Object.entries(ATTACK_PRESETS).map(([key,value])=>`<option value="${key}">${esc(value.label)}</option>`).join('')}</select></label></div>
      <input id="sc-attack-id" type="hidden" value="${esc(draft.id||'')}">
      <div class="sc-form-grid"><label>Название<input id="sc-attack-name" value="${esc(draft.name||'')}"></label><label>Профиль<input id="sc-attack-profile" value="${esc(draft.profile||draft.name||'')}"></label><label>Категория<select id="sc-attack-category"><option value="natural" ${draft.category==='natural'?'selected':''}>Естественное оружие</option><option value="melee" ${draft.category==='melee'?'selected':''}>Оружие ближнего боя</option><option value="ranged" ${draft.category==='ranged'?'selected':''}>Дальнобойное оружие</option></select></label><label>Куб попадания<select id="sc-attack-hit-die">${normalDice}</select></label><label>Куб прицела<select id="sc-attack-aimed-die">${dieOptions}</select></label><label>Урон<input id="sc-attack-damage" type="number" min="0" max="20" value="${draft.damage??2}"></label><label>Тег урона<select id="sc-attack-damage-tag"><option value="light" ${draft.damageTag==='light'?'selected':''}>Лёгкое</option><option value="medium" ${draft.damageTag==='medium'?'selected':''}>Среднее</option><option value="heavy" ${draft.damageTag==='heavy'?'selected':''}>Тяжёлое</option></select></label><label>Стоимость, ОД<input id="sc-attack-od" type="number" min="0" max="10" value="${draft.odCost??2}"></label><label>Прицел, ОД<input id="sc-attack-aimed-od" type="number" min="0" max="10" value="${draft.aimedOdCost??3}"></label><label>Стоимость, ОБ<input id="sc-attack-ob" type="number" min="0" max="10" value="${draft.obCost??0}"></label><label>Дальность, футы<input id="sc-attack-range" type="number" min="1" max="1000" value="${draft.range??5}"></label><label>Радиус, футы<input id="sc-attack-radius" type="number" min="0" max="500" value="${draft.radius??0}"></label><label>Игнорирование МЗ<input id="sc-attack-ignore-mz" type="number" min="0" max="20" value="${draft.ignoreMz??0}"></label></div>
      <details open><summary>Бонус попадания</summary><div class="sc-form-grid"><label>Расчёт<select id="sc-attack-bonus-mode"><option value="rank" ${draft.bonusMode==='rank'?'selected':''}>Боевой бонус по рангу NPC</option><option value="formula" ${draft.bonusMode==='formula'?'selected':''}>Владение + ½ Меткости − Порог</option><option value="manual" ${draft.bonusMode==='manual'?'selected':''}>Ручной бонус</option></select></label><label>Ручной бонус<input id="sc-attack-manual" type="number" value="${draft.manualBonus??0}"></label><label>Владение<input id="sc-attack-proficiency" type="number" value="${draft.proficiency??0}"></label><label>Меткость<input id="sc-attack-accuracy" type="number" value="${draft.accuracy??0}"></label><label>Порог<input id="sc-attack-threshold" type="number" value="${draft.threshold??0}"></label></div><p class="sc-sub">Для атаки ближнего боя персонажа система по-прежнему использует лучший подходящий бонус Физической силы или Акробатики. Ручной/формульный профиль особенно полезен для дальнобойного оружия и упрощённых NPC.</p></details>
      <details open><summary>Звук атаки</summary><div class="sc-form-grid"><label>Звуковой эффект<select id="sc-attack-sound">${attackSoundOptions(draft.soundId)}</select></label><label>Загрузить новый звук<input id="sc-attack-sound-file" type="file" accept="audio/mpeg,audio/ogg,audio/wav,audio/webm,audio/mp4,audio/aac,.mp3,.ogg,.wav,.webm,.m4a,.aac"></label></div><div class="sc-actions"><button class="btn" type="button" onclick="scAttackBuilderPreviewSound()">▶ Прослушать</button><button class="btn" type="button" onclick="scAttackBuilderUploadSound()">Загрузить и выбрать</button></div><p class="sc-sub">«Автоматически» использует общий звук типа оружия. Для Укуса и Когтей отдельные общие звуки назначаются в панели карты → Аудио.</p></details>
      <div class="sc-form-grid"><label>Свойства через запятую<input id="sc-attack-properties" value="${esc((draft.properties||[]).join(', '))}"></label><label class="sc-checkbox-label"><input id="sc-attack-counter" type="checkbox" ${draft.counterAllowed!==false?'checked':''}> Можно использовать для Встречного удара</label><label class="sc-checkbox-label"><input id="sc-attack-free" type="checkbox" ${draft.freeAttackAllowed!==false?'checked':''}> Можно использовать для свободной атаки</label></div><label>Описание<textarea id="sc-attack-description">${esc(draft.description||'')}</textarea></label>
      <div class="sc-actions"><button class="btn btn-primary" onclick="scAttackBuilderSave()">${draft.id?'Сохранить профиль':'Создать и выдать'}</button>${draft.id?'<button class="btn btn-ghost" onclick="scAttackBuilderCancelEdit()">Отменить редактирование</button>':''}</div>
      <details open><summary>Профили у выбранной цели</summary>${attackProfilesHtml(entry)}</details></div>`;
  }
  function attackBuilderField(id){return document.getElementById(id);}
  function attackBuilderPayload(){const aimed=attackBuilderField('sc-attack-aimed-die')?.value||'';return{id:attackBuilderField('sc-attack-id')?.value||undefined,name:attackBuilderField('sc-attack-name')?.value||'Новая атака',profile:attackBuilderField('sc-attack-profile')?.value||'',category:attackBuilderField('sc-attack-category')?.value||'melee',hitDie:attackBuilderField('sc-attack-hit-die')?.value||'1d6',hitDieAimed:aimed,damage:+attackBuilderField('sc-attack-damage')?.value||0,damageTag:attackBuilderField('sc-attack-damage-tag')?.value||'medium',odCost:+attackBuilderField('sc-attack-od')?.value||0,aimedOdCost:+attackBuilderField('sc-attack-aimed-od')?.value||0,obCost:+attackBuilderField('sc-attack-ob')?.value||0,range:+attackBuilderField('sc-attack-range')?.value||5,radius:+attackBuilderField('sc-attack-radius')?.value||0,ignoreMz:+attackBuilderField('sc-attack-ignore-mz')?.value||0,bonusMode:attackBuilderField('sc-attack-bonus-mode')?.value||'manual',manualBonus:+attackBuilderField('sc-attack-manual')?.value||0,proficiency:+attackBuilderField('sc-attack-proficiency')?.value||0,accuracy:+attackBuilderField('sc-attack-accuracy')?.value||0,threshold:+attackBuilderField('sc-attack-threshold')?.value||0,counterAllowed:Boolean(attackBuilderField('sc-attack-counter')?.checked),freeAttackAllowed:Boolean(attackBuilderField('sc-attack-free')?.checked),soundId:attackBuilderField('sc-attack-sound')?.value||null,properties:String(attackBuilderField('sc-attack-properties')?.value||'').split(',').map(x=>x.trim()).filter(Boolean),description:attackBuilderField('sc-attack-description')?.value||''};}
  function attackBuilderPreviewSound(){
    const soundId=attackBuilderField('sc-attack-sound')?.value||'';
    if(!soundId){lanToast('Выбран автоматический звук. Его можно проверить на боевой карте.');return;}
    if(soundId==='off'){lanToast('Для профиля звук отключён.');return;}
    const item=attackAudioLibrary.find(entry=>entry.id===soundId);if(!item?.url){lanToast('Звуковой файл недоступен.','error');return;}
    try{if(attackSoundPreview){attackSoundPreview.pause();attackSoundPreview.currentTime=0;}attackSoundPreview=new Audio(item.url);attackSoundPreview.volume=.8;attackSoundPreview.play().catch(error=>lanToast(error?.message||'Браузер заблокировал воспроизведение.','error'));}catch(error){lanToast(error?.message||String(error),'error');}
  }
  async function attackBuilderUploadSound(){
    const input=attackBuilderField('sc-attack-sound-file'),file=input?.files?.[0];if(!file){lanToast('Выберите аудиофайл.','error');return;}
    const query=new URLSearchParams({master:'1',clientId:FATUM_LAN_CLIENT_ID,name:file.name,kind:'effect',scope:'campaign'});
    const response=await fetch(`/api/battlemap/audio/upload?${query}`,{method:'POST',headers:{'Content-Type':file.type||'application/octet-stream'},body:file,credentials:'same-origin'});
    let result={};try{result=await response.json();}catch{}if(!response.ok)throw new Error(result.error||`HTTP ${response.status}`);
    attackAudioLibrary=(result.audio?.library||attackAudioLibrary).filter(item=>item.kind==='effect');
    const select=attackBuilderField('sc-attack-sound');if(select){select.innerHTML=attackSoundOptions(result.item?.id);select.value=result.item?.id||'';}
    input.value='';lanToast(`Звук «${result.item?.name||file.name}» загружен и выбран.`,'success');
  }
  function attackBuilderSetTarget(value){attackBuilderTarget=value;attackBuilderDraft=null;render();}
  function attackBuilderApplyPreset(key){attackBuilderDraft=structuredClone(ATTACK_PRESETS[key]||ATTACK_PRESETS.blank);render();}
  function attackBuilderEdit(targetKey,profileId){attackBuilderTarget=targetKey;const profile=targetAttackProfiles(attackTargetEntry(targetKey)).find(item=>item.id===profileId);if(!profile)return;attackBuilderDraft=structuredClone(profile);render();}
  function attackBuilderCancelEdit(){attackBuilderDraft=null;render();}
  async function attackBuilderSave(){const entry=attackTargetEntry();if(!entry)return;const attack=attackBuilderPayload();const result=await api('/api/custom-attacks',{method:'POST',body:body({targetType:entry.type,targetId:entry.entity.id,attack})});if(result.npc){const index=data.npcs.findIndex(item=>item.id===result.npc.id);if(index>=0)data.npcs[index]=result.npc;}if(result.character){const index=data.characters.findIndex(item=>item.id===result.character.id);if(index>=0)data.characters[index]=result.character;}attackBuilderDraft=null;lanToast(`Профиль «${result.attack?.name||attack.name}» сохранён.`,'success');render();}
  async function attackBuilderRemove(targetKey,profileId){const entry=attackTargetEntry(targetKey);if(!entry||!confirm('Удалить этот пользовательский профиль?'))return;const result=await api(`/api/custom-attacks/${entry.type}/${encodeURIComponent(entry.entity.id)}/${encodeURIComponent(profileId)}`,{method:'DELETE',body:body({})});if(result.npc){const index=data.npcs.findIndex(item=>item.id===result.npc.id);if(index>=0)data.npcs[index]=result.npc;}if(result.character){const index=data.characters.findIndex(item=>item.id===result.character.id);if(index>=0)data.characters[index]=result.character;}attackBuilderDraft=null;render();}
  function npcAttackSummaryHtml(n){const entry={key:`npc:${n.id}`,type:'npc',entity:n};return `<details open><summary>Естественные и пользовательские атаки</summary><p class="sc-sub">Эти профили появляются на боевой карте вместе с экипированным оружием.</p>${attackProfilesHtml(entry)}</details>`;}

  function renderNpcs() {
    if (!master) return '';
    ensureNpcCollapseState();
    const cards=(data.npcs||[]).map(n=>{
      const collapsed=npcCollapsedIds.has(String(n.id));
      const tone=n.kind==='enemy'?'accent':n.kind==='ally'?'green':'blue';
      if(collapsed)return `<div class="sc-card sc-npc-card collapsed ${tone}" data-npc="${n.id}"><button class="sc-npc-card-head sc-npc-card-toggle" onclick="scNpcToggleCollapse('${n.id}')" title="Развернуть лист NPC"><span class="sc-npc-chevron">▸</span><strong data-npc-name>${esc(n.name||'NPC')}</strong></button></div>`;
      const a=npcArmorEffective(n.armor||{}),w=n.wounds||{},ch=n.characteristics||{},od=n.od||{};
      return `<div class="sc-card sc-npc-card ${tone}" data-npc="${n.id}">
        <div class="sc-npc-card-head"><button class="sc-npc-collapse-btn" onclick="scNpcToggleCollapse('${n.id}')" title="Свернуть лист NPC">▾</button><strong data-npc-name>${esc(n.name||'NPC')}</strong><span class="sc-npc-save-state" data-npc-save="${n.id}">автосохранение</span></div>
        <div class="sc-npc-card-body">
        <div class="sc-form-grid"><label>Имя<input data-f="name" value="${esc(n.name)}"></label><label>Роль<select data-f="kind"><option value="enemy" ${n.kind==='enemy'?'selected':''}>Противник</option><option value="ally" ${n.kind==='ally'?'selected':''}>Союзник</option><option value="neutral" ${n.kind==='neutral'?'selected':''}>Нейтральный</option></select></label><label>Тип существа<select data-f="creatureType"><option value="human" ${n.creatureType!=='animal'&&n.creatureType!=='monster'?'selected':''}>Человек / гуманоид</option><option value="animal" ${n.creatureType==='animal'?'selected':''}>Животное</option><option value="monster" ${n.creatureType==='monster'?'selected':''}>Монстр / иное существо</option></select></label><label>Ранг<select data-f="rank" onchange="scNpcApplyRank('${n.id}',this.value)">${rankOptions(n.rank)}</select></label><label>Видимость<select data-f="visibility"><option value="public" ${n.visibility==='public'?'selected':''}>Игрокам</option><option value="master" ${n.visibility==='master'?'selected':''}>Только мастер</option></select></label><label>Состояние<select data-f="outOfCombat"><option value="0" ${!n.outOfCombat?'selected':''}>В бою</option><option value="1" ${n.outOfCombat?'selected':''}>Выведен из боя</option></select></label></div>
        <details open><summary>Базовые параметры</summary><div class="sc-form-grid"><label>Куб успеха<select data-f="successDie">${['1d4','1d6','1d8','1d10','1d12'].map(x=>`<option ${n.successDie===x?'selected':''}>${x}</option>`).join('')}</select></label><label>Базовая МЗ<input data-f="baseMz" type="number" min="0" max="99" value="${n.baseMz===null||n.baseMz===undefined?'':n.baseMz}" placeholder="Авто: ${4+Number(ch.dexterity||0)}"><small>Пусто — 4 + Ловкость</small></label><label>ОД сейчас<input data-f="odCurrent" type="number" value="${od.current??0}"></label><label>ОД максимум<input data-f="odMax" type="number" value="${od.max??0}"></label><label>Скорость<input data-f="speed" type="number" value="${n.speed??30}"></label></div><div class="sc-form-grid sc-six"><label>Сила<input data-f="strength" type="number" value="${ch.strength??0}"></label><label>Ловкость<input data-f="dexterity" type="number" value="${ch.dexterity??0}"></label><label>Выносливость<input data-f="endurance" type="number" value="${ch.endurance??0}"></label><label>Концентрация<input data-f="concentration" type="number" value="${ch.concentration??0}"></label><label>Интеллект<input data-f="intelligence" type="number" value="${ch.intelligence??0}"></label><label>Харизма<input data-f="charisma" type="number" value="${ch.charisma??0}"></label></div></details>
        <details open><summary>Ранения, мораль и броня</summary><div class="sc-form-grid"><label>Мораль<input data-f="moraleCurrent" type="number" value="${n.morale?.current??0}"></label><label>Макс. мораль<input data-f="moraleMax" type="number" value="${n.morale?.max??0}"></label><label>Лёгкие<input data-f="light" type="number" value="${w.light??0}"></label><label>Лимит лёгких<input data-f="lightMax" type="number" value="${w.lightMax??0}"></label><label>Средние<input data-f="medium" type="number" value="${w.medium??0}"></label><label>Лимит средних<input data-f="mediumMax" type="number" value="${w.mediumMax??0}"></label><label>Серьёзные<input data-f="serious" type="number" value="${w.serious??0}"></label><label>Лимит серьёзных<input data-f="seriousMax" type="number" value="${w.seriousMax??0}"></label><label>Критическое<select data-f="critical"><option value="0" ${!w.critical?'selected':''}>Нет</option><option value="1" ${w.critical?'selected':''}>Да</option></select></label><label>Кровотечение<select data-f="bleeding"><option value="0" ${!n.bleeding?'selected':''}>Нет</option><option value="1" ${n.bleeding?'selected':''}>Да</option></select></label><label>Профиль брони<select data-f="armorProfile" onchange="scNpcArmorProfileChanged('${n.id}',this.value)">${npcArmorProfileOptions(a)}</select><small>Профиль задаёт класс, БЗ и свойства.</small></label><label>Броня / модель<input data-f="armorName" value="${esc(a.name||'')}" placeholder="Напр. Berg M8"></label><label>Класс брони<select data-f="armorClass">${[['none','Нет'],['light','Лёгкая'],['medium','Средняя'],['heavy','Тяжёлая'],['special','Особая']].map(([v,l])=>`<option value="${v}" ${a.class===v?'selected':''}>${l}</option>`).join('')}</select></label><label>БЗ сейчас<input data-f="bzCurrent" type="number" min="0" value="${a.bzCurrent??0}"></label><label>БЗ максимум<input data-f="bzMax" type="number" min="0" value="${a.bzMax??0}"></label></div><div class="sc-npc-condition ${n.outOfCombat?'sc-danger':''}">${esc(npcConditionText(n))}</div></details>
        ${npcTrainingHtml(n)}
        ${npcLoadoutHtml(n)}
        ${npcAttackSummaryHtml(n)}
        ${npcAbilitiesHtml(n)}
        <details><summary>Дополнительные заметки и поведение</summary><label>Свободное описание способностей<textarea data-f="abilities">${esc(n.abilities||'')}</textarea></label><label>Ожидаемое поведение<textarea data-f="behavior">${esc(n.behavior||'')}</textarea></label><label>Заметки<textarea data-f="notes">${esc(n.notes||'')}</textarea></label></details>
        <div class="sc-actions"><button class="btn" onclick="scNpcToInit('${n.id}')">В инициативу</button><button class="btn btn-danger" onclick="scNpcDelete('${n.id}')">Удалить</button></div>
        </div>
      </div>`;
    }).join('');
    setTimeout(refreshNpcSaveIndicators,0);
    return `${attackBuilderHtml()}<div class="sc-actions sc-npc-create-actions" style="margin:12px 0"><button class="btn btn-primary" onclick="scNpcCreate('human')">+ NPC-человек</button><button class="btn" onclick="scNpcCreate('animal')">+ Животное</button><button class="btn" onclick="scNpcCreate('monster')">+ Монстр</button><span class="sc-sub">Все изменения, включая инвентарь, сохраняются автоматически. Атаки также сохраняются сразу.</span></div><div class="sc-grid sc-npc-grid">${cards||'<div class="sc-empty">NPC пока нет.</div>'}</div>`;
  }

  function npcToggleCollapse(id) {
    syncNpcDraftFromDom(id);
    const key=String(id);
    if(npcCollapsedIds.has(key))npcCollapsedIds.delete(key);else npcCollapsedIds.add(key);
    persistNpcCollapseState(); render();
  }

  function renderHistory() {
    if (!master) return '';
    return `<div class="sc-actions" style="margin:0 0 12px"><button class="btn btn-danger" onclick="scClearHistory()">Очистить журнал</button></div><div class="sc-log">${historyEntries.map(h=>`<div class="sc-log-entry ${h.undoneAt?'sc-muted':''}"><div class="sc-log-time">${esc(dateText(h.at))}<br>${esc(h.actor?.name||'Система')}</div><div><strong>${esc(h.summary)}</strong><div class="sc-sub">${esc(h.action)} · ${esc(h.entityType)}</div></div><div>${h.undoable&&!h.undoneAt?`<button class="btn btn-sm" onclick="scUndo('${h.id}')">Отменить</button>`:h.undoneAt?'отменено':''}</div></div>`).join('') || '<div class="sc-empty">Журнал пуст.</div>'}</div>`;
  }

  function renderCargo() {
    const editable = master || data.cargo?.playerCanEdit;
    const rows=(data.cargo?.items||[]).map((x,i)=>`<div class="sc-form-grid" data-cargo-row><label>Предмет<input data-f="name" value="${esc(x.name)}" ${editable?'':'disabled'}></label><label>Количество<input data-f="quantity" type="number" value="${x.quantity}" ${editable?'':'disabled'}></label><label>Вес<input data-f="weight" type="number" value="${x.weight}" ${editable?'':'disabled'}></label><label>Описание<input data-f="description" value="${esc(x.description)}" ${editable?'':'disabled'}></label>${editable?`<button class="btn btn-danger btn-sm" onclick="scCargoRemove(${i})">×</button>`:''}</div>`).join('');
    return `<div class="sc-card green"><div class="sc-title">Общий груз</div><div class="sc-form-grid"><label>Общие деньги<input id="sc-cargo-money" type="number" value="${data.cargo?.money||0}" ${editable?'':'disabled'}></label>${master?`<label>Редактирование игроками<select id="sc-cargo-edit"><option value="0" ${!data.cargo?.playerCanEdit?'selected':''}>Запрещено</option><option value="1" ${data.cargo?.playerCanEdit?'selected':''}>Разрешено</option></select></label>`:''}</div>${rows||'<div class="sc-empty">Предметов нет.</div>'}<label>Заметки<textarea id="sc-cargo-notes" ${editable?'':'disabled'}>${esc(data.cargo?.notes||'')}</textarea></label>${editable?'<div class="sc-actions"><button class="btn" onclick="scCargoAdd()">+ Предмет</button><button class="btn btn-primary" onclick="scCargoSave()">Сохранить груз</button></div>':''}</div>`;
  }

  function renderEffects() {
    const list=(data.globalEffects||[]).map(e=>`<div class="sc-card purple"><div class="sc-title">${esc(e.name)}</div><div>${esc(e.description)}</div><div class="sc-sub">${esc(e.duration||'без срока')} · ${esc(e.scope)}</div>${master?`<div class="sc-actions"><button class="btn btn-sm" onclick="scEffectToggle('${e.id}',${!e.active})">${e.active?'Отключить':'Включить'}</button><button class="btn btn-danger btn-sm" onclick="scEffectDelete('${e.id}')">Удалить</button></div>`:''}</div>`).join('');
    const form=master?`<div class="sc-card blue"><div class="sc-title">Новый глобальный эффект</div><div class="sc-form-grid"><label>Название<input id="sc-eff-name"></label><label>Длительность<input id="sc-eff-duration" placeholder="3 раунда / до конца сцены"></label><label>Область<select id="sc-eff-scope"><option value="all">Все</option><option value="players">Игроки</option><option value="npcs">NPC</option></select></label></div><label>Описание<textarea id="sc-eff-desc"></textarea></label><button class="btn btn-primary" onclick="scEffectAdd()">Добавить</button></div>`:'';
    return `<div class="sc-grid">${form}${list||'<div class="sc-empty">Нет глобальных эффектов.</div>'}</div>`;
  }

  function frameRollProfile(characterId) {
    try {
      const frame = document.querySelector(`iframe[data-party-frame="${CSS.escape(characterId)}"]`);
      if (frame?.contentWindow?.fatumGetRollProfile) return frame.contentWindow.fatumGetRollProfile();
    } catch (error) {}
    try {
      const selectedId = typeof window.lanGetSelectedCharacterId === 'function' ? window.lanGetSelectedCharacterId() : '';
      if (selectedId === characterId && typeof window.fatumGetRollProfile === 'function') {
        return window.fatumGetRollProfile();
      }
    } catch (error) {}
    const character = byId(characterId);
    return character?.state?._lanRollProfile || {skills:{}};
  }
  function fallbackSkill(character, skillName) {
    const p=frameRollProfile(character?.id)?.skills?.[skillName]; if(p) return {cube:String(p.cube).replace('к','d'),bonus:+p.bonus||0};
    const st=character?.state||{}, map={'Физическая сила':'Сильный','Взлом':'Ловкий','Акробатика':'Ловкий','Скрытность':'Ловкий','Выдержка':'Выносливый','Стойкость':'Выносливый','Иммунитет':'Выносливый','Бдительность':'Бдительный','Воля':'Бдительный','Меткость':'Бдительный','Выживание':'Бдительный','Анализ':'Умный','Эрудиция':'Умный','Память':'Умный','Медицина':'Умный','Механика':'Умный','Убеждение':'Обаятельный','Обман':'Обаятельный','Интуиция':'Обаятельный','Запугивание':'Обаятельный','Очарование':'Обаятельный'};
    const lvl=+st.traits?.main?.[map[skillName]]||0, orders=[4,6,8,10,12]; let i=lvl===0?0:lvl<=2?1:lvl<=4?2:3; if(st.skills?.[skillName]?.prof)i=Math.min(i+1,4);
    return {cube:String(st.skills?.[skillName]?.customCube||`1d${orders[i]}`).replace('к','d'),bonus:(+st.skills?.[skillName]?.bonus||0)+[2,4,5].filter(x=>lvl>=x).length};
  }
  function outcomeText(r) {
    return ({'success':'Успех','failure':'Провал','edge':'Успех на грани','critical-success':'Критический успех','critical-failure':'Критический провал'})[r.outcome] || '';
  }
  function upsertDiceRoll(roll) {
    if (!roll || !roll.id) return;
    const list = Array.isArray(data?.diceLog) ? data.diceLog : (data.diceLog = []);
    const index = list.findIndex(item => item.id === roll.id);
    if (index >= 0) list[index] = roll; else list.push(roll);
    if (list.length > 200) list.splice(0, list.length - 200);
  }
  function upsertGlobalEffect(effect) {
    if (!effect || !effect.id) return;
    const list = Array.isArray(data?.globalEffects) ? data.globalEffects : (data.globalEffects = []);
    const index = list.findIndex(item => item.id === effect.id);
    if (index >= 0) list[index] = effect; else list.push(effect);
  }

  function checkRollText(r){const extra=Array.isArray(r.extraRolls)?r.extraRolls:[],sum=extra.reduce((total,item)=>total+(Number(item.roll)||0),0),baseBonus=Number(r.baseSuccessBonus??((Number(r.successBonus)||0)-sum))||0,parts=[String(r.successRoll)];for(const item of extra)parts.push(`${String(item.die||'1d?').replace(/^1d/i,'1к')}=${Number(item.roll)||0} (${esc(item.name||'Особенность')})`);if(baseBonus)parts.push(`${baseBonus>0?'+':''}${baseBonus}`);return extra.length?`${parts.join(' + ').replace(/\+ \+/g,'+ ')} = <b>${r.successTotal}</b>`:`${r.successRoll} ${r.successBonus>=0?'+':''}${r.successBonus} = <b>${r.successTotal}</b>`;}
  function renderDiceEntry(r) {
    if(r.kind==='check') return `<div class="sc-log-entry"><div class="sc-log-time">${esc(dateText(r.at))}<br>${esc(r.actorName)}</div><div><strong>${esc(r.characterName||'')} · ${esc(r.skillName||r.label)}</strong><div>${esc(r.successDie)}: ${checkRollText(r)} против ${esc(r.difficultyDie)}: ${r.difficultyRoll} ${r.difficultyModifier>=0?'+':''}${r.difficultyModifier} = <b>${r.difficultyTotal}</b></div><div class="${r.outcome?.includes('failure')?'sc-danger':'sc-ok'}">${outcomeText(r)}${r.outcome==='edge'?` (не хватило ${Math.abs(r.margin)})`:''}</div></div><div class="sc-dice-total">${r.successTotal}</div></div>`;
    return `<div class="sc-log-entry"><div class="sc-log-time">${esc(dateText(r.at))}<br>${esc(r.actorName)}</div><div><strong>${esc(r.characterName||r.label||'Бросок')}</strong><div>${esc(r.formula)}: ${(r.rolls||[]).join(', ')} ${r.modifier?`${r.modifier>0?'+':''}${r.modifier}`:''}</div></div><div class="sc-dice-total">${r.total}</div></div>`;
  }
  function renderDice() {
    const chars=data.characters||[]; const selected=byId(diceUi.characterId)||chars[0]; if(selected&&!diceUi.characterId)diceUi.characterId=selected.id;
    const profile=selected?fallbackSkill(selected,diceUi.skillName):{cube:'1d6',bonus:0};
    const form=`<div class="sc-card accent"><div class="sc-title">Автоматическая проверка навыка</div><div class="sc-form-grid"><label>Персонаж<select onchange="scDiceSet('characterId',this.value)">${chars.map(c=>`<option value="${c.id}" ${c.id===diceUi.characterId?'selected':''}>${esc(c.name)}</option>`).join('')}</select></label><label>Навык<select onchange="scDiceSet('skillName',this.value)">${SKILLS.map(s=>`<option ${s===diceUi.skillName?'selected':''}>${s}</option>`).join('')}</select></label><label>Куб сложности<select onchange="scDiceSet('difficultyDie',this.value)">${['1d4','1d6','1d8','1d10','1d12'].map(x=>`<option ${x===diceUi.difficultyDie?'selected':''}>${x}</option>`).join('')}</select></label><label>Модификатор сложности<input type="number" value="${diceUi.difficultyModifier}" onchange="scDiceSet('difficultyModifier',this.value)"></label><label>Условия<select onchange="scDiceSet('condition',this.value)"><option value="normal" ${diceUi.condition==='normal'?'selected':''}>Обычно</option><option value="advantage" ${diceUi.condition==='advantage'?'selected':''}>Преимущество</option><option value="hindrance" ${diceUi.condition==='hindrance'?'selected':''}>Помеха</option></select></label><label>Видимость<select onchange="scDiceSet('visibility',this.value)"><option value="public" ${diceUi.visibility==='public'?'selected':''}>Публично</option><option value="master" ${diceUi.visibility==='master'?'selected':''}>Только мастеру</option></select></label></div><div class="sc-extra-dice"><strong>Произвольные кубы</strong><div class="sc-actions">${[4,6,8,10,12].map(s=>`<button class="btn btn-sm" onclick="scDiceExtra(${s},1)">+к${s}</button>`).join('')}<button class="btn btn-sm" onclick="scDiceExtra(0,0)">Очистить</button></div><div class="sc-sub">${diceUi.extraDice.length?diceUi.extraDice.map(s=>`к${s}`).join(' + '):'Нет дополнительных кубов'}</div></div><div class="sc-roll-preview">${esc(diceUi.skillName)}: <strong>${esc(profile.cube)} ${profile.bonus>=0?'+':''}${profile.bonus}</strong> против <strong>${esc(diceUi.difficultyDie)} ${diceUi.difficultyModifier>=0?'+':''}${diceUi.difficultyModifier}</strong></div><label>Подпись<input id="sc-check-label" value="${esc(diceUi.label)}" onchange="scDiceSet('label',this.value)"></label><button class="btn btn-primary" onclick="scRollSkill()">Бросить проверку</button></div>`;
    const generic=`<div class="sc-card blue"><div class="sc-title">Свободный бросок</div><div class="sc-form-grid"><label>Формула<input id="sc-dice-formula" value="1d10"></label><label>Подпись<input id="sc-dice-label"></label><label>Персонаж<select id="sc-dice-character"><option value="">Без персонажа</option>${chars.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></label><label>Видимость<select id="sc-dice-vis"><option value="public">Публично</option><option value="master">Только мастеру</option></select></label></div><button class="btn" onclick="scRoll()">Бросить</button></div>`;
    return `<div class="sc-two"><div>${form}${generic}</div><div class="sc-log">${[...(data.diceLog||[])].reverse().map(renderDiceEntry).join('')||'<div class="sc-empty">Бросков ещё нет.</div>'}</div></div>`;
  }

  function renderAccess() {
    if(!master)return'';
    return `<div class="sc-card"><div class="sc-title">Просмотр листов игроками</div><label class="sc-inline"><input type="checkbox" ${data.settings?.groupViewEnabled?'checked':''} onchange="scGroupView(this.checked)"> Раздел «Группа» доступен игрокам</label></div><div class="sc-grid">${(data.characters||[]).map(c=>`<div class="sc-card blue">${portrait(c)}<div class="sc-title">${esc(c.name)}</div><label>Видимость<select onchange="scVisibility('${c.id}',this.value)"><option value="private" ${c.visibility==='private'?'selected':''}>Скрыт</option><option value="summary" ${c.visibility==='summary'?'selected':''}>Краткая сводка</option><option value="full" ${c.visibility==='full'?'selected':''}>Полный лист, чтение</option></select></label></div>`).join('')}</div>`;
  }

  function backupKindLabel(backup){const kind=backup?.kind||'';return kind==='quicksave'?'Быстрое сохранение':kind==='autosave'?'Автосохранение':kind==='safety'?'Страховочный снимок':'Ручной снимок';}
  function renderSaves() {
    if(!master)return'';
    return `<div class="sc-card green"><div class="sc-title">Лёгкие снимки прогресса</div><div class="sc-sub">Автосохранение теперь использует один перезаписываемый файл. Быстрое сохранение со стола также обновляет один слот, поэтому папка AppData не разрастается от каждой автозаписи.</div><div class="sc-inline"><input id="sc-backup-reason" placeholder="Например: перед боем"><button class="btn btn-primary" onclick="scBackupCreate()">Создать ручной снимок</button></div></div><div class="sc-card accent"><div class="sc-title">Переносимая резервная копия</div><div class="sc-sub">Файл .fatum содержит листы, сцены и только используемые карты, токены, портреты и аудио. Одинаковые ресурсы хранятся один раз.</div><div class="sc-actions"><button class="btn btn-primary" onclick="scCampaignExport('full')">Скачать полную .fatum</button><button class="btn" onclick="scCampaignExport('compact')">Скачать компактную .fatum</button><button class="btn btn-danger" onclick="scAssetsCleanup()">Убрать неиспользуемые файлы</button></div></div><div class="sc-log">${backups.map(b=>`<div class="sc-log-entry"><div class="sc-log-time">${esc(dateText(b.modifiedAt))}</div><div class="sc-backup-name">${esc(backupKindLabel(b))}<div class="sc-sub">${esc(b.name)} · ${Math.round(b.size/1024)} КБ</div></div><div class="sc-actions"><a class="btn btn-sm" href="/api/backups/${encodeURIComponent(b.name)}" download>Скачать JSON</a><button class="btn btn-sm" onclick="scBackupRestore('${b.name}')">Восстановить</button><button class="btn btn-danger btn-sm" onclick="scBackupDelete('${b.name}')">Удалить</button></div></div>`).join('')||'<div class="sc-empty">Снимков нет.</div>'}</div>`;
  }

  function renderGroup() {
    const shared=data.sharedCharacters||[];
    return `<div class="sc-grid">${shared.map(c=>`<div class="sc-card blue">${portrait(c)}<div class="sc-title">${esc(c.name)}</div>${statSummary(c)}${c.accessMode==='read'?`<button class="btn" onclick="scOpenShared('${c.id}')">Открыть полный лист</button>`:''}</div>`).join('')||'<div class="sc-empty">Другие листы скрыты мастером.</div>'}</div>`;
  }

  async function quick(id,type,amount,woundType) { const r=await api(`/api/characters/${encodeURIComponent(id)}/quick-action`,{method:'POST',body:body({type,amount,woundType})}); upsert(r.character); render(); }
  async function quickValue(id,type,value) { const r=await api(`/api/characters/${encodeURIComponent(id)}/quick-action`,{method:'POST',body:body({type,value})}); upsert(r.character); render(); }
  async function quickEffect(id) { const name=await fatumPrompt('Название эффекта:','Эффект',{title:'Добавить эффект',maxLength:180}); if(!name)return; const description=(await fatumPrompt('Описание:','',{title:'Описание эффекта',multiline:true,select:false}))||''; const r=await api(`/api/characters/${encodeURIComponent(id)}/quick-action`,{method:'POST',body:body({type:'effect-add',name,description})}); upsert(r.character); render(); }
  async function quickRemoveEffect(id,effectId) { const r=await api(`/api/characters/${encodeURIComponent(id)}/quick-action`,{method:'POST',body:body({type:'effect-remove',effectId})}); upsert(r.character); render(); }
  function upsert(c){const i=data.characters.findIndex(x=>x.id===c.id);if(i>=0)data.characters[i]=c;else data.characters.push(c);}

  async function saveInit(init){const r=await api('/api/initiative',{method:'PUT',body:body({initiative:init})});data.initiative=r.initiative;render();}
  function initClone(){return JSON.parse(JSON.stringify(data.initiative||{round:1,currentIndex:0,entries:[]}));}
  async function initAdd(){const v=document.getElementById('sc-init-ref')?.value;if(!v)return;const [type,refId]=v.split(':');const init=initClone();if(!init.entries.some(e=>e.type===type&&e.refId===refId))init.entries.push({id:`init_${Date.now()}`,type,refId,score:+document.getElementById('sc-init-score').value||0,cube:'1d6',roll:0,bonus:0,tieBreaks:[]});init.entries.sort((a,b)=>b.score-a.score);await saveInit(init);}
  async function initAddAll(type){const init=initClone(),list=type==='npc'?(data.npcs||[]):(data.characters||[]);for(const x of list)if(!init.entries.some(e=>e.type===type&&e.refId===x.id))init.entries.push({id:`init_${Date.now()}_${x.id}`,type,refId:x.id,score:0,cube:type==='npc'?x.successDie:'1d6',roll:0,bonus:0,tieBreaks:[]});await saveInit(init);}
  function characterProfiles(){const out={};for(const c of data.characters||[])out[c.id]=fallbackSkill(c,'Бдительность');return out;}
  async function initRoll(mode){const r=await api('/api/initiative/roll',{method:'POST',body:body({mode,characterProfiles:characterProfiles()})});data.initiative=r.initiative;render();}
  async function initClear(){if(!confirm('Очистить очередь инициативы?'))return;await saveInit({round:1,currentIndex:0,entries:[]});}
  async function initMove(i,d){const init=initClone(),j=i+d;if(j<0||j>=init.entries.length)return;[init.entries[i],init.entries[j]]=[init.entries[j],init.entries[i]];if(init.currentIndex===i)init.currentIndex=j;else if(init.currentIndex===j)init.currentIndex=i;await saveInit(init);}
  async function initRemove(i){const init=initClone();init.entries.splice(i,1);init.currentIndex=Math.min(init.currentIndex,Math.max(0,init.entries.length-1));await saveInit(init);}
  async function initScore(i,v){const init=initClone();init.entries[i].score=+v||0;await saveInit(init);}
  async function initAdvance(direction){const r=await api('/api/initiative/advance',{method:'POST',body:body({direction})});data.initiative=r.initiative;render();}

  async function npcCreate(creatureType='human'){
    const names={human:'Новый противник',animal:'Новое животное',monster:'Новый монстр'};
    const r=await api('/api/npcs',{method:'POST',body:body({name:names[creatureType]||names.human,kind:'enemy',creatureType,rank:'regular',createDefaultAttacks:creatureType!=='human'})});
    const i=data.npcs.findIndex(x=>x.id===r.npc.id);if(i>=0)data.npcs[i]=r.npc;else data.npcs.push(r.npc);
    npcCollapsedIds.delete(String(r.npc.id));persistNpcCollapseState();render();
  }
  function getNpcField(el,name){return el?.querySelector(`[data-f="${name}"]`);}
  function npcPayload(id){
    const el=document.querySelector(`[data-npc="${CSS.escape(id)}"]`),g=n=>getNpcField(el,n);
    if(!el||!g('name'))return npcPayloadFromData(id);
    const baseMzValue=g('baseMz')?.value?.trim()??'';
    return {name:g('name').value,kind:g('kind').value,creatureType:g('creatureType')?.value||'human',rank:g('rank').value,visibility:g('visibility').value,outOfCombat:g('outOfCombat').value==='1',successDie:g('successDie').value,baseMz:baseMzValue===''?null:Number(baseMzValue),od:{current:+g('odCurrent').value||0,max:+g('odMax').value||0},speed:+g('speed').value||0,characteristics:{strength:+g('strength').value||0,dexterity:+g('dexterity').value||0,endurance:+g('endurance').value||0,concentration:+g('concentration').value||0,intelligence:+g('intelligence').value||0,charisma:+g('charisma').value||0},morale:{current:+g('moraleCurrent').value||0,max:+g('moraleMax').value||0},wounds:{light:+g('light').value||0,lightMax:+g('lightMax').value||0,medium:+g('medium').value||0,mediumMax:+g('mediumMax').value||0,serious:+g('serious').value||0,seriousMax:+g('seriousMax').value||0,critical:g('critical').value==='1'},bleeding:g('bleeding').value==='1',armor:{profile:g('armorProfile')?.value||'',name:g('armorName').value,class:g('armorClass').value,bzCurrent:+g('bzCurrent').value||0,bzMax:+g('bzMax').value||0},inventory:structuredClone(npcById(id)?.inventory||[]),equipment:{...(npcById(id)?.equipment||{})},attacks:structuredClone(npcById(id)?.attacks||[]),weapon:structuredClone(npcById(id)?.weapon||{}),weaponTrainingMode:g('weaponTrainingMode')?.value||'rank',weaponProficiencies:Object.fromEntries(NPC_WEAPON_CATEGORIES.map(category=>[category,Math.max(0,Math.min(6,+el.querySelector(`[data-prof="${CSS.escape(category)}"]`)?.value||0))])),weaponAccuracy:+g('weaponAccuracy')?.value||0,manualCombatBonus:+g('manualCombatBonus')?.value||0,abilityIds:[...el.querySelectorAll('[data-npc-ability]:checked')].map(input=>input.dataset.npcAbility),abilities:g('abilities').value,behavior:g('behavior').value,notes:g('notes').value};
  }
  function npcArmorProfileChanged(id,profile){
    const el=document.querySelector(`[data-npc="${CSS.escape(id)}"]`);if(!el)return;
    const def=officialItemByName(profile),g=name=>getNpcField(el,name);
    if(def?.armorClass){
      if(g('armorClass'))g('armorClass').value=def.armorClass;
      const max=Math.max(0,+def.armorBz||0);if(g('bzMax'))g('bzMax').value=max;if(g('bzCurrent'))g('bzCurrent').value=max;
      const models=Array.isArray(def.models)?def.models:[],current=String(g('armorName')?.value||'').trim();
      const belongs=!current||models.includes(current)||armorProfileItems().some(item=>item.name===current||(item.models||[]).includes(current));
      if(g('armorName')&&belongs)g('armorName').value=models[0]||'';
    }
    syncNpcDraftFromDom(id);queueNpcSave(id,120);
  }
  function npcItemAdd(id){
    syncNpcDraftFromDom(id);
    const n=npcById(id),select=document.getElementById(`sc-npc-catalog-${id}`),qty=document.getElementById(`sc-npc-catalog-qty-${id}`);if(!n||!select?.value)return;
    n.inventory ||= [];const found=n.inventory.find(item=>item.name===select.value);if(found)found.qty=(+found.qty||0)+Math.max(1,+qty?.value||1);else n.inventory.push({uid:`npcitem_${Date.now()}_${Math.random().toString(16).slice(2)}`,name:select.value,qty:Math.max(1,+qty?.value||1),usesRemaining:null});n.equipment ||= {weapon1:null,weapon2:null};const official=officialItemByName(select.value);if(official&&/Пистолет|Карабин|винтовка|Дробовик|Тяжёлое|Оружие ближнего боя|Луки|Арбалеты/i.test(official.type||'')&&!n.equipment.weapon1)n.equipment.weapon1=(found||n.inventory[n.inventory.length-1]).uid;
    queueNpcSave(id,120);render();
  }
  function npcItemQty(id,uid,value){syncNpcDraftFromDom(id);const n=npcById(id),item=n?.inventory?.find(x=>x.uid===uid);if(!item)return;item.qty=Math.max(0,+value||0);if(!item.qty){npcItemRemove(id,uid);return;}queueNpcSave(id,120);}
  function npcItemRemove(id,uid){syncNpcDraftFromDom(id);const n=npcById(id);if(!n)return;n.inventory=(n.inventory||[]).filter(item=>item.uid!==uid);n.equipment ||= {};if(n.equipment.weapon1===uid)n.equipment.weapon1=null;if(n.equipment.weapon2===uid)n.equipment.weapon2=null;queueNpcSave(id,120);render();}
  function npcEquipItem(id,uid,slot){syncNpcDraftFromDom(id);const n=npcById(id),item=n?.inventory?.find(x=>x.uid===uid),official=officialItemByName(item?.name);if(!n||!item)return;if(!/Пистолет|Карабин|винтовка|Дробовик|Тяжёлое|Оружие ближнего боя|Луки|Арбалеты/i.test(official?.type||'')){lanToast('Этот предмет не является оружием.','error');return;}n.equipment ||= {};n.equipment[slot]=uid;queueNpcSave(id,120);render();}
  function npcClearEquip(id){syncNpcDraftFromDom(id);const n=npcById(id);if(!n)return;n.equipment={weapon1:null,weapon2:null};queueNpcSave(id,120);render();}

  async function npcSave(id){syncNpcDraftFromDom(id);queueNpcSave(id,0);const state=npcState(id);if(state.timer){clearTimeout(state.timer);state.timer=null;}await flushNpcSave(id);}
  async function npcDelete(id){if(!confirm('Удалить NPC?'))return;const state=npcSaveStates.get(id);if(state?.timer)clearTimeout(state.timer);npcSaveStates.delete(id);await api(`/api/npcs/${encodeURIComponent(id)}`,{method:'DELETE',body:body({})});data.npcs=data.npcs.filter(x=>x.id!==id);data.initiative.entries=data.initiative.entries.filter(e=>!(e.type==='npc'&&e.refId===id));npcCollapsedIds.delete(String(id));persistNpcCollapseState();render();}
  async function npcToInit(id){syncNpcDraftFromDom(id);queueNpcSave(id,120);const init=initClone();if(!init.entries.some(e=>e.type==='npc'&&e.refId===id)){const n=npcById(id);init.entries.push({id:`init_${Date.now()}`,type:'npc',refId:id,score:n?.initiative||0,cube:n?.successDie||'1d6',roll:0,bonus:n?.characteristics?.concentration||0,tieBreaks:[]});}await saveInit(init);}
  function npcApplyRank(id,rank){syncNpcDraftFromDom(id);const n=npcById(id),p=NPC_PRESETS[rank];if(!n||!p)return;n.rank=rank;n.successDie=p.successDie;n.od={current:p.od,max:p.od};n.speed=p.speed;n.characteristics={strength:p.characteristic,dexterity:p.characteristic,endurance:p.characteristic,concentration:p.characteristic,intelligence:p.characteristic,charisma:p.characteristic};n.wounds={...n.wounds,lightMax:p.wounds.lightMax,mediumMax:p.wounds.mediumMax,seriousMax:p.wounds.seriousMax,light:0,medium:0,serious:0,critical:false};n.weaponTrainingMode='rank';n.manualCombatBonus=p.combatBonus;n.weapon={...n.weapon,bonusMode:'rank',manualBonus:p.combatBonus};n.outOfCombat=false;queueNpcSave(id,120);render();}

  async function undo(id){if(!confirm('Отменить это изменение? Текущее состояние соответствующего объекта будет заменено.'))return;await api(`/api/history/${encodeURIComponent(id)}/undo`,{method:'POST',body:body({})});await refresh();}
  async function clearHistory(){if(!confirm('Очистить журнал? Перед очисткой будет создан снимок кампании.'))return;await api('/api/history',{method:'DELETE',body:body({})});historyEntries=[];render();}

  function cargoAdd(){data.cargo.items.push({id:`cargo_${Date.now()}`,name:'Новый предмет',quantity:1,weight:0,description:''});render();}
  function cargoRemove(i){data.cargo.items.splice(i,1);render();}
  async function cargoSave(){const rows=[...document.querySelectorAll('[data-cargo-row]')];const items=rows.map((r,i)=>({id:data.cargo.items[i]?.id||`cargo_${Date.now()}_${i}`,name:r.querySelector('[data-f="name"]').value,quantity:+r.querySelector('[data-f="quantity"]').value||0,weight:+r.querySelector('[data-f="weight"]').value||0,description:r.querySelector('[data-f="description"]').value}));const cargo={money:+document.getElementById('sc-cargo-money').value||0,notes:document.getElementById('sc-cargo-notes').value,playerCanEdit:master?document.getElementById('sc-cargo-edit').value==='1':data.cargo.playerCanEdit,items};const r=await api('/api/cargo',{method:'PUT',body:body({cargo})});data.cargo=r.cargo;lanToast('Общий груз сохранён','success');render();}
  async function effectAdd(){
    if(pendingActions.effectAdd)return; pendingActions.effectAdd=true;
    try {
      const r=await api('/api/global-effects',{method:'POST',body:body({name:document.getElementById('sc-eff-name').value,description:document.getElementById('sc-eff-desc').value,duration:document.getElementById('sc-eff-duration').value,scope:document.getElementById('sc-eff-scope').value})});
      upsertGlobalEffect(r.effect); render(); updateBanner();
    } finally { pendingActions.effectAdd=false; }
  }
  async function effectToggle(id,active){const e=data.globalEffects.find(x=>x.id===id);const r=await api(`/api/global-effects/${encodeURIComponent(id)}`,{method:'PUT',body:body({...e,active})});data.globalEffects[data.globalEffects.findIndex(x=>x.id===id)]=r.effect;render();updateBanner();}
  async function effectDelete(id){await api(`/api/global-effects/${encodeURIComponent(id)}`,{method:'DELETE',body:body({})});data.globalEffects=data.globalEffects.filter(x=>x.id!==id);render();updateBanner();}
  async function roll(){
    if(pendingActions.roll)return; pendingActions.roll=true;
    try {
      const r=await api('/api/dice/roll',{method:'POST',body:body({formula:document.getElementById('sc-dice-formula').value,label:document.getElementById('sc-dice-label').value,characterId:document.getElementById('sc-dice-character').value||null,visibility:document.getElementById('sc-dice-vis').value})});
      upsertDiceRoll(r.roll); render();
    } finally { pendingActions.roll=false; }
  }
  function diceSet(key,value){diceUi[key]=key==='difficultyModifier'?+value||0:value;render();}
  function diceExtra(sides,delta=1){if(!sides){diceUi.extraDice=[];render();return;}sides=Number(sides);if(![4,6,8,10,12].includes(sides))return;if(delta>0&&diceUi.extraDice.length<20)diceUi.extraDice.push(sides);else if(delta<0){const i=diceUi.extraDice.lastIndexOf(sides);if(i>=0)diceUi.extraDice.splice(i,1);}render();}
  async function rollSkill(){
    if(pendingActions.rollSkill)return;
    const c=byId(diceUi.characterId);if(!c)return; pendingActions.rollSkill=true;
    try {
      const p=fallbackSkill(c,diceUi.skillName);
      const r=await api('/api/dice/check',{method:'POST',body:body({characterId:c.id,skillName:diceUi.skillName,successDie:p.cube,successBonus:p.bonus,difficultyDie:diceUi.difficultyDie,difficultyModifier:diceUi.difficultyModifier,condition:diceUi.condition,extraDice:diceUi.extraDice,visibility:diceUi.visibility,label:diceUi.label||diceUi.skillName})});
      upsertDiceRoll(r.roll); render();
    } finally { pendingActions.rollSkill=false; }
  }
  async function visibility(id,value){await api(`/api/characters/${encodeURIComponent(id)}/visibility`,{method:'PUT',body:body({visibility:value})});const c=byId(id);if(c)c.visibility=value;render();}
  async function groupView(enabled){const r=await api('/api/settings',{method:'PUT',body:body({groupViewEnabled:enabled})});data.settings=r.settings;render();}
  async function backupCreate(){await api('/api/backups',{method:'POST',body:body({reason:document.getElementById('sc-backup-reason').value||'manual'})});await refresh();}
  async function backupRestore(name){if(!confirm(`Восстановить снимок ${name}? Текущее состояние сначала будет сохранено в страховочный слот.`))return;await api(`/api/backups/${encodeURIComponent(name)}/restore`,{method:'POST',body:body({})});await refresh();}
  async function backupDelete(name){if(!confirm(`Удалить файл сохранения ${name}?`))return;await api(`/api/backups/${encodeURIComponent(name)}`,{method:'DELETE',body:body({})});lanToast('Файл сохранения удалён.','success');await refresh();}
  function downloadName(disposition,fallback){const utf=/filename\*=UTF-8''([^;]+)/i.exec(disposition||'');if(utf){try{return decodeURIComponent(utf[1]);}catch{}}return fallback;}
  async function campaignExport(mode){mode=mode==='compact'?'compact':'full';lanToast(mode==='compact'?'Создаётся компактный архив…':'Создаётся полный архив…');const response=await fetch(`/api/campaigns/export?mode=${mode}`,{credentials:'same-origin'});if(!response.ok){let payload={};try{payload=await response.json();}catch{}throw new Error(payload.error||`HTTP ${response.status}`);}const blob=await response.blob();const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=downloadName(response.headers.get('content-disposition'),`campaign-${mode}.fatum`);document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);const optimized=+response.headers.get('x-fatum-optimized-count')||0,dedup=+response.headers.get('x-fatum-deduplicated-count')||0,unused=+response.headers.get('x-fatum-omitted-unused')||0;lanToast(`Архив готов: ${formatBytes(blob.size)}${optimized?` · оптимизировано ${optimized}`:''}${dedup?` · дублей ${dedup}`:''}${unused?` · исключено лишних файлов ${unused}`:''}`,'success');}
  async function assetsCleanup(){if(!confirm('Переместить неиспользуемые карты, токены, портреты и аудио в папку assets-trash? Используемые ресурсы не затрагиваются.'))return;const result=await api('/api/campaigns/assets/cleanup',{method:'POST',body:body({})});lanToast(`Перемещено: ${result.moved} файлов · ${formatBytes(result.bytes)}. Папка: ${result.trash}`,'success');await refresh();}
  function openShared(id){viewerCharacter=(data.sharedCharacters||[]).find(x=>x.id===id);if(!viewerCharacter||viewerCharacter.accessMode!=='read')return;document.getElementById('sc-viewer-title').textContent=viewerCharacter.name;const frame=document.getElementById('sc-viewer-frame');frame.src=`/?mode=player&fatumEmbedded=1&fatumCharacter=${encodeURIComponent(id)}&fatumReadOnly=1`;document.getElementById('sc-viewer').classList.add('open');}
  function closeViewer(){document.getElementById('sc-viewer').classList.remove('open');document.getElementById('sc-viewer-frame').src='about:blank';viewerCharacter=null;}

  function connect(){
    if(eventSource)eventSource.close();
    const p=new URLSearchParams({clientId:FATUM_LAN_CLIENT_ID,playerName:lanPlayerName(),mode:FATUM_APP_MODE});
    const selected=(typeof lanGetSelectedCharacterId==='function')?lanGetSelectedCharacterId(data?.characters||[]):null;if(selected)p.set('characterId',selected);
    eventSource=new EventSource(`/api/events?${p}`);
    eventSource.addEventListener('campaign-replaced',e=>{const payload=JSON.parse(e.data);if(payload.sourceClientId===FATUM_LAN_CLIENT_ID&&payload.mode==='npc-updated')return;adoptCampaignData(payload.campaign);if(!diceUi.characterId)diceUi.characterId=data.characters?.[0]?.id||'';render();updateBanner();});
    eventSource.addEventListener('character-updated',e=>{const c=JSON.parse(e.data).character;upsert(c);render();});
    eventSource.addEventListener('shared-character-updated',e=>{const c=JSON.parse(e.data).character;const list=data?.sharedCharacters||[];const i=list.findIndex(x=>x.id===c.id);if(i>=0)list[i]=c;else list.push(c);render();});
    eventSource.addEventListener('dice-rolled',e=>{const r=JSON.parse(e.data).roll;upsertDiceRoll(r);if(activeTab==='dice')render();});
    eventSource.addEventListener('history-updated',e=>{if(!master)return;historyEntries=[JSON.parse(e.data).entry,...historyEntries].slice(0,160);if(activeTab==='history')render();});
  }
  window.addEventListener('message',event=>{if(event.data?.type==='fatum:embedded-ready'&&viewerCharacter&&event.source===document.getElementById('sc-viewer-frame')?.contentWindow){event.source.postMessage({type:'fatum:character-state',characterId:viewerCharacter.id,character:viewerCharacter},'*');}});
  window.addEventListener('resize', applyDockMode);

  Object.assign(window,{
    scOpen:open,scClose:close,scToggleDock:toggleDock,scOpenTab:openTab,scRefresh:()=>refresh().catch(showError),scRender:render,
    scQuick:(...a)=>quick(...a).catch(showError),scQuickValue:(...a)=>quickValue(...a).catch(showError),scQuickEffect:id=>quickEffect(id).catch(showError),scQuickRemoveEffect:(...a)=>quickRemoveEffect(...a).catch(showError),
    scInitAdd:()=>initAdd().catch(showError),scInitAddAll:t=>initAddAll(t).catch(showError),scInitRoll:m=>initRoll(m).catch(showError),scInitClear:()=>initClear().catch(showError),scInitMove:(...a)=>initMove(...a).catch(showError),scInitRemove:i=>initRemove(i).catch(showError),scInitScore:(...a)=>initScore(...a).catch(showError),scInitAdvance:d=>initAdvance(d).catch(showError),
    scNpcCreate:type=>npcCreate(type).catch(showError),scNpcArmorProfileChanged:npcArmorProfileChanged,scNpcItemAdd:npcItemAdd,scNpcItemQty:npcItemQty,scNpcItemRemove:npcItemRemove,scNpcEquipItem:npcEquipItem,scNpcClearEquip:npcClearEquip,scNpcSave:id=>npcSave(id).catch(showError),scNpcDelete:id=>npcDelete(id).catch(showError),scNpcToInit:id=>npcToInit(id).catch(showError),scNpcApplyRank:npcApplyRank,scNpcToggleCollapse:npcToggleCollapse,
    scAttackBuilderSetTarget:attackBuilderSetTarget,scAttackBuilderApplyPreset:attackBuilderApplyPreset,scAttackBuilderEdit:attackBuilderEdit,scAttackBuilderCancelEdit:attackBuilderCancelEdit,scAttackBuilderSave:()=>attackBuilderSave().catch(showError),scAttackBuilderRemove:(...args)=>attackBuilderRemove(...args).catch(showError),scAttackBuilderPreviewSound:attackBuilderPreviewSound,scAttackBuilderUploadSound:()=>attackBuilderUploadSound().catch(showError),
    scUndo:id=>undo(id).catch(showError),scClearHistory:()=>clearHistory().catch(showError),
    scCargoAdd:cargoAdd,scCargoRemove:cargoRemove,scCargoSave:()=>cargoSave().catch(showError),
    scEffectAdd:()=>effectAdd().catch(showError),scEffectToggle:(...a)=>effectToggle(...a).catch(showError),scEffectDelete:id=>effectDelete(id).catch(showError),
    scRoll:()=>roll().catch(showError),scDiceSet:diceSet,scDiceExtra:diceExtra,scRollSkill:()=>rollSkill().catch(showError),
    scVisibility:(...a)=>visibility(...a).catch(showError),scGroupView:e=>groupView(e).catch(showError),
    scBackupCreate:()=>backupCreate().catch(showError),scBackupRestore:n=>backupRestore(n).catch(showError),scBackupDelete:n=>backupDelete(n).catch(showError),scCampaignExport:m=>campaignExport(m).catch(showError),scAssetsCleanup:()=>assetsCleanup().catch(showError),scOpenShared:openShared,scCloseViewer:closeViewer,
    scCampaignCreate:()=>campaignCreate().catch(showError),scCampaignActivate:id=>campaignActivate(id).catch(showError),scCampaignRename:id=>campaignRename(id).catch(showError),scCampaignDelete:id=>campaignDelete(id).catch(showError),scCampaignImportFile:input=>campaignImportFile(input)
  });

  setTimeout(async()=>{
    try {
      await (window.FATUM_PLAYER_REGISTRATION_READY || Promise.resolve());
      inject();
      await refresh();
      connect();
    } catch(e) { console.error(e); }
  },500);
})();
