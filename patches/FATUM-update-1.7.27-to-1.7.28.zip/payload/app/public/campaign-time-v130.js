'use strict';

(() => {
  if (window.FatumCampaignPanelNative) return;
  const params = new URLSearchParams(location.search);
  const mode = params.get('mode') === 'master' ? 'master' : 'player';
  const master = mode === 'master';
  const clientId = localStorage.getItem('fatumLanClientId') || '';
  const playerName = master ? 'Мастер' : (localStorage.getItem('fatumLanPlayerName') || localStorage.getItem('fatumPlayerName') || params.get('playerName') || 'Игрок');
  const $ = id => document.getElementById(id);
  const state = { payload:null, restSelection:new Map(), foodSelection:new Map(), eventSource:null, busy:false };

  function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[ch])); }
  function notify(message, error = false) {
    const toast = $('toast');
    if (!toast) { if (error) console.error(message); else console.log(message); return; }
    toast.textContent = message;
    toast.className = `bm-toast show${error ? ' error' : ' success'}`;
    clearTimeout(notify.timer);
    notify.timer = setTimeout(() => { toast.className = 'bm-toast'; }, 2800);
  }
  async function api(url, options = {}) {
    const opts = { credentials:'same-origin', ...options };
    if (opts.body && typeof opts.body !== 'string') {
      opts.headers = { 'Content-Type':'application/json', ...(opts.headers || {}) };
      opts.body = JSON.stringify(opts.body);
    }
    const response = await fetch(url, opts);
    let payload = {}; try { payload = await response.json(); } catch {}
    if (!response.ok) throw new Error(payload.error || `HTTP ${response.status}`);
    return payload;
  }
  function common(extra = {}) { return { clientId, playerName, ...extra }; }
  function hhmm(minutes) {
    const safe = Math.max(0, Math.min(1439, Math.round(Number(minutes) || 0)));
    return `${String(Math.floor(safe / 60)).padStart(2,'0')}:${String(safe % 60).padStart(2,'0')}`;
  }
  function hungerLabel(stage) {
    return stage === 'exhausted' ? 'Истощённый' : stage === 'hungry' ? 'Голодный' : 'Сытый';
  }
  function statusClass(character) {
    if (character.hungerStage === 'exhausted' || Number(character.sleepDebtDays) >= 2) return 'bm-survival-danger';
    if (character.hungerStage === 'hungry' || Number(character.sleepDebtDays) === 1) return 'bm-survival-warn';
    return 'bm-survival-ok';
  }
  function sleepLabel(days) {
    const value = Math.max(0, Number(days) || 0);
    if (value >= 2) return `критическое недосыпание (${value} сут.)`;
    if (value === 1) return 'не выспался (1 сутки)';
    return 'сон в норме';
  }
  function initializeSelections(characters) {
    const ids = new Set(characters.map(item => item.characterId));
    for (const id of [...state.restSelection.keys()]) if (!ids.has(id)) state.restSelection.delete(id);
    for (const id of [...state.foodSelection.keys()]) if (!ids.has(id)) state.foodSelection.delete(id);
    for (const character of characters) {
      if (!state.restSelection.has(character.characterId)) state.restSelection.set(character.characterId, true);
      if (!state.foodSelection.has(character.characterId)) state.foodSelection.set(character.characterId, true);
    }
  }
  function render() {
    const payload = state.payload; if (!payload?.timeline) return;
    const timeline = payload.timeline, characters = Array.isArray(payload.characters) ? payload.characters : [];
    initializeSelections(characters);
    if ($('campaign-clock-display')) $('campaign-clock-display').textContent = `День ${timeline.day} · ${hhmm(timeline.minuteOfDay)}`;
    if ($('campaign-day-input')) $('campaign-day-input').value = String(timeline.day);
    if ($('campaign-time-input')) $('campaign-time-input').value = hhmm(timeline.minuteOfDay);
    const permanent = timeline.supplies?.mode !== 'expedition';
    if ($('campaign-supplies-display')) $('campaign-supplies-display').textContent = permanent ? 'Постоянные припасы · не расходуются' : `Походные припасы · ${Number(timeline.supplies?.current || 0)}`;
    if ($('campaign-supplies-mode')) $('campaign-supplies-mode').value = permanent ? 'permanent' : 'expedition';
    if ($('campaign-supplies-current')) { $('campaign-supplies-current').value = String(Number(timeline.supplies?.current || 0)); $('campaign-supplies-current').disabled = permanent; }
    if ($('campaign-survival-module')) $('campaign-survival-module').checked = Boolean(timeline.modules?.exhaustionSleep);
    const restHelp=$('campaign-rest-help');if(restHelp&&payload.ruleset==='tol')restHelp.textContent='ToL: короткий привал снимает Лёгкие ранения; длительный также снимает Средние и Серьёзные и завершает эффекты «до большого привала», включая провал «Великого запрещения». Время, припасы, питание и сон синхронизируются с листами ToL.';
    const list = $('campaign-rest-character-list'); if (!list) return;
    if (!characters.length) {
      list.innerHTML = `<p class="bm-muted">${master ? 'В кампании пока нет персонажей.' : 'Нет доступных персонажей для отображения.'}</p>`;
      return;
    }
    list.innerHTML = characters.map(character => {
      const id = escapeHtml(character.characterId), rest = state.restSelection.get(character.characterId) !== false, food = permanent ? rest : (state.foodSelection.get(character.characterId) !== false && rest);
      const survival = timeline.modules?.exhaustionSleep
        ? `<span class="bm-rest-status ${statusClass(character)}">${hungerLabel(character.hungerStage)} · ${sleepLabel(character.sleepDebtDays)}${Number(character.missedMeals||0)>0?` · без еды: ${Number(character.missedMeals||0)} прив.`:''}</span>`
        : '<span class="bm-rest-chip bm-rest-chip-muted">Сон/истощение: выкл.</span>';
      const hungerControl = master && timeline.modules?.exhaustionSleep
        ? `<label class="bm-rest-hunger"><span>Питание</span><select data-hunger-stage="${id}"><option value="satiated" ${character.hungerStage==='satiated'?'selected':''}>Сытый</option><option value="hungry" ${character.hungerStage==='hungry'?'selected':''}>Голодный</option><option value="exhausted" ${character.hungerStage==='exhausted'?'selected':''}>Истощённый</option></select></label>` : '';
      const foodControl = master
        ? (permanent
          ? '<span class="bm-rest-chip">🍲 Постоянные</span>'
          : `<label class="bm-check bm-rest-food"><input type="checkbox" data-rest-food="${id}" ${food?'checked':''} ${rest?'':'disabled'}><span>1 Припас</span></label>`)
        : '';
      return `<div class="bm-rest-character" data-rest-character="${id}">
        <div class="bm-rest-character-head"><span class="bm-rest-character-name" title="${escapeHtml(character.name)}">${escapeHtml(character.name)}</span>${master ? `<label class="bm-check bm-rest-toggle" title="Участвует в привале"><input type="checkbox" data-rest-participant="${id}" ${rest?'checked':''}><span>Отдых</span></label>` : ''}</div>
        <div class="bm-rest-character-controls"><div class="bm-rest-character-meta">${foodControl}${survival}</div>${hungerControl}</div>
      </div>`;
    }).join('');
    if (master) {
      list.querySelectorAll('[data-rest-participant]').forEach(input => input.addEventListener('change', () => {
        state.restSelection.set(input.dataset.restParticipant, input.checked);
        if (!input.checked) state.foodSelection.set(input.dataset.restParticipant, false);
        else if (!state.foodSelection.has(input.dataset.restParticipant) || state.foodSelection.get(input.dataset.restParticipant) === false) state.foodSelection.set(input.dataset.restParticipant, true);
        render();
      }));
      list.querySelectorAll('[data-rest-food]').forEach(input => input.addEventListener('change', () => state.foodSelection.set(input.dataset.restFood, input.checked)));
      list.querySelectorAll('[data-hunger-stage]').forEach(select => select.addEventListener('change', () => setHunger(select.dataset.hungerStage, select.value)));
    }
  }
  async function refresh(silent = true) {
    try {
      const query = new URLSearchParams({ mode, clientId });
      state.payload = await api(`/api/campaign/timeline?${query}`);
      render();
    } catch (error) { if (!silent) notify(error.message, true); }
  }
  async function run(label, work) {
    if (state.busy) return;
    state.busy = true;
    try { await work(); await refresh(); if (label) notify(label); }
    catch (error) { notify(error.message, true); }
    finally { state.busy = false; }
  }
  async function saveClock() {
    const day = Math.max(1, Math.round(Number($('campaign-day-input')?.value || 1)));
    const [hours, minutes] = String($('campaign-time-input')?.value || '08:00').split(':').map(Number);
    const minuteOfDay = Math.max(0, Math.min(1439, (hours || 0) * 60 + (minutes || 0)));
    await run('Время кампании обновлено.', () => api('/api/campaign/timeline', { method:'PUT', body:common({ day, minuteOfDay }) }));
  }
  async function advance(minutes) {
    await run(`Время продвинуто на ${minutes >= 1440 ? `${minutes/1440} д.` : `${minutes/60} ч.`}`, () => api('/api/campaign/time/advance', { method:'POST', body:common({ minutes }) }));
  }
  async function saveSupplies() {
    const suppliesMode = $('campaign-supplies-mode')?.value === 'expedition' ? 'expedition' : 'permanent';
    const suppliesCurrent = Math.max(0, Math.round(Number($('campaign-supplies-current')?.value || 0)));
    await run('Припасы обновлены.', () => api('/api/campaign/timeline', { method:'PUT', body:common({ suppliesMode, suppliesCurrent }) }));
  }
  async function toggleModule(enabled) {
    await run(enabled ? 'Модуль истощения и сна включён.' : 'Модуль истощения и сна выключен.', () => api('/api/campaign/timeline', { method:'PUT', body:common({ exhaustionSleep:Boolean(enabled) }) }));
  }
  async function setHunger(characterId, hungerStage) {
    await run('Стадия питания обновлена.', () => api('/api/campaign/survival', { method:'PUT', body:common({ characterId, hungerStage }) }));
  }
  async function rest(kind) {
    const timeline = state.payload?.timeline; if (!timeline) return;
    const participantIds = [...state.restSelection].filter(([, selected]) => selected).map(([id]) => id);
    if (!participantIds.length) return notify('Выберите хотя бы одного персонажа для привала.', true);
    const fedCharacterIds = timeline.supplies?.mode === 'permanent'
      ? [...participantIds]
      : participantIds.filter(id => state.foodSelection.get(id) !== false);
    if (timeline.supplies?.mode === 'expedition' && fedCharacterIds.length > Number(timeline.supplies?.current || 0)) {
      return notify(`Недостаточно припасов: нужно ${fedCharacterIds.length}, доступно ${timeline.supplies?.current || 0}. Снимите отметку «1 Припас» у части персонажей.`, true);
    }
    await run(kind === 'long' ? 'Длительный привал завершён.' : 'Короткий привал завершён.', async () => {
      const payload = await api('/api/campaign/rest', { method:'POST', body:common({ kind, participantIds, fedCharacterIds }) });
      const healed = (payload.result?.results || []).reduce((sum,item) => sum + Number(item.healing?.light||0) + Number(item.healing?.medium||0) + Number(item.healing?.serious||0), 0);
      const spent = timeline.supplies?.mode === 'expedition' ? fedCharacterIds.length : 0;
      const help = $('campaign-rest-help');
      if (help) help.textContent = state.payload?.ruleset==='tol' ? `${kind === 'long' ? 'Длительный' : 'Короткий'} привал ToL завершён: восстановлено ранений ${healed}${spent ? ` · потрачено припасов ${spent}` : ''}.${kind==='long'?' Эффекты «до большого привала» сняты, включая запрет Магии от «Великого запрещения».':''}` : `${kind === 'long' ? 'Длительный' : 'Короткий'} привал: восстановлено ранений ${healed}${spent ? ` · потрачено припасов ${spent}` : ''}. Кровотечение и травмы не изменялись.`;
    });
  }
  function bind() {
    if (!master) return;
    $('campaign-clock-save')?.addEventListener('click', saveClock);
    document.querySelectorAll('[data-campaign-advance]').forEach(button => button.addEventListener('click', () => advance(Number(button.dataset.campaignAdvance))));
    $('campaign-supplies-mode')?.addEventListener('change', () => { if ($('campaign-supplies-current')) $('campaign-supplies-current').disabled = $('campaign-supplies-mode').value !== 'expedition'; });
    $('campaign-supplies-save')?.addEventListener('click', saveSupplies);
    $('campaign-survival-module')?.addEventListener('change', event => toggleModule(event.target.checked));
    $('campaign-short-rest')?.addEventListener('click', () => rest('short'));
    $('campaign-long-rest')?.addEventListener('click', () => rest('long'));
  }
  function connect() {
    try {
      const query = new URLSearchParams({ mode, clientId, playerName, characterId:'' });
      const es = new EventSource(`/api/events?${query}`); state.eventSource = es;
      es.addEventListener('campaign-replaced', () => refresh());
      es.addEventListener('hello', () => refresh());
      es.onerror = () => {};
    } catch {}
  }
  bind(); refresh(false); connect();
})();
