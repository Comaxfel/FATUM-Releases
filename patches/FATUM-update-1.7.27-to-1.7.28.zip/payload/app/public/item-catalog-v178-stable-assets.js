/* FATUM v1.7.8 stable item artwork catalog. Replace files by stable names without code changes. */
(function(){
  const data = {
  "version": "1.7.8-stable-assets",
  "modelIcons": {
    "Poche-M2": "/assets/items/models-stable/pistols/poche-m2.webp",
    "Лань-M1": "/assets/items/models-stable/pistols/lan-m1.webp",
    "Kriegspistole": "/assets/items/models-stable/pistols/kriegspistole.webp",
    "Liberté-M1": "/assets/items/models-stable/pistols/liberte-m1.webp",
    "Фэй Лун": "/assets/items/models-stable/pistols/fey-lun.webp",
    "Тэппо": "/assets/items/models-stable/pistols/teppo.webp",
    "Kriegsfaust-11": "/assets/items/models-stable/pistols/kriegsfaust-11.webp",
    "Буря-П": "/assets/items/models-stable/pistols/burya-p.webp",
    "Cavaliere-38": "/assets/items/models-stable/pistols/cavaliere-38.webp",
    "Sûreté-R": "/assets/items/models-stable/pistols/surete-r.webp",
    "R-18 Revolver Vento": "/assets/items/models-stable/pistols/r-18-revolver-vento.webp",
    "Traur-U": "/assets/items/models-stable/pistols/traur-u.webp",
    "Тэндзо-Рэй": "/assets/items/models-stable/pistols/tendzo-rey.webp",
    "Égalité": "/assets/items/models-stable/carbines/egalite.webp",
    "Scauta-K2": "/assets/items/models-stable/carbines/scauta-k2.webp",
    "Банту Тип-31": "/assets/items/models-stable/carbines/bantu-tip-31.webp",
    "Ligne-M3": "/assets/items/models-stable/carbines/ligne-m3.webp",
    "Stahlkar-8": "/assets/items/models-stable/carbines/stahlkar-8.webp",
    "Adlerauge-S": "/assets/items/models-stable/carbines/adlerauge-s.webp",
    "Банту Тип-32": "/assets/items/models-stable/carbines/bantu-tip-32.webp",
    "Кагэцу Тип-7": "/assets/items/models-stable/carbines/kagetsu-tip-7.webp",
    "Blitzsturm-kurz": "/assets/items/models-stable/carbines/blitzsturm-kurz.webp",
    "Molot-B1": "/assets/items/models-stable/carbines/molot-b1.webp",
    "Фэнчэн-L1": "/assets/items/models-stable/carbines/fenchen-l1.webp",
    "SR-42 Cacciatore": "/assets/items/models-stable/carbines/sr-42-cacciatore.webp",
    "Fraternité": "/assets/items/models-stable/sniper/fraternite.webp",
    "Hirschlauf-3": "/assets/items/models-stable/sniper/hirschlauf-3.webp",
    "Ordonnance-5": "/assets/items/models-stable/sniper/ordonnance-5.webp",
    "Adlerauge-X": "/assets/items/models-stable/sniper/adlerauge-x.webp",
    "Шэньхуо": "/assets/items/models-stable/sniper/shenhuo.webp",
    "Palitsa-M2": "/assets/items/models-stable/sniper/palitsa-m2.webp",
    "Рюсан-C2": "/assets/items/models-stable/sniper/ryusan-c2.webp",
    "Bâtard-9": "/assets/items/models-stable/shotguns/batard-9.webp",
    "Лэймэнь-L2": "/assets/items/models-stable/shotguns/leymen-l2.webp",
    "M. Dural": "/assets/items/models-stable/shotguns/m-dural.webp",
    "Цзиньфэн": "/assets/items/models-stable/shotguns/tszinfen.webp",
    "Stahlhammer-11": "/assets/items/models-stable/shotguns/stahlhammer-11.webp",
    "DS-15 Tempesta": "/assets/items/models-stable/shotguns/ds-15-tempesta.webp",
    "Ками-Рэн": "/assets/items/models-stable/shotguns/kami-ren.webp",
    "Zarya-D1": "/assets/items/models-stable/shotguns/zarya-d1.webp",
    "Molot-R2": "/assets/items/models-stable/shotguns/molot-r2.webp",
    "Stahlhammer-11F": "/assets/items/models-stable/shotguns/stahlhammer-11f.webp",
    "Éruption": "/assets/items/models-stable/heavy/eruption.webp",
    "Feuersturm": "/assets/items/models-stable/heavy/feuersturm.webp",
    "Festungsbrecher-T4": "/assets/items/models-stable/heavy/festungsbrecher-t4.webp",
    "Гром-О2": "/assets/items/models-stable/heavy/grom-o2.webp",
    "Zvezda-T2": "/assets/items/models-stable/heavy/zvezda-t2.webp",
    "Stahlregen-11": "/assets/items/models-stable/heavy/stahlregen-11.webp",
    "Molot-MG2": "/assets/items/models-stable/heavy/molot-mg2.webp",
    "Они-Баку": "/assets/items/models-stable/heavy/oni-baku.webp",
    "Stahlmantel": "/assets/items/models-stable/armor/stahlmantel.webp",
    "Veste Défenseur": "/assets/items/models-stable/armor/veste-defenseur.webp",
    "Цинцзя": "/assets/items/models-stable/armor/tsintszya.webp",
    "Буря-М": "/assets/items/models-stable/armor/burya-m.webp",
    "Gilet Guerrier": "/assets/items/models-stable/armor/gilet-guerrier.webp",
    "Дуншань": "/assets/items/models-stable/armor/dunshan.webp",
    "Kriegskorps": "/assets/items/models-stable/armor/kriegskorps.webp",
    "Титан-М": "/assets/items/models-stable/armor/titan-m.webp",
    "Berg M8": "/assets/items/models-stable/armor/berg-m8.webp",
    "Armure Titanique": "/assets/items/models-stable/armor/armure-titanique.webp",
    "Экзоскелет Т-1": "/assets/items/models-stable/armor/ekzoskelet-t-1.webp",
    "Шаньхэй": "/assets/items/models-stable/armor/shanhey.webp",
    "Складной нож": "/assets/items/models-stable/melee/skladnoy-nozh.webp",
    "Кастет": "/assets/items/models-stable/melee/kastet.webp",
    "Сапожный нож": "/assets/items/models-stable/melee/sapozhnyy-nozh.webp",
    "Короткий стилет": "/assets/items/models-stable/melee/korotkiy-stilet.webp",
    "Траншейный нож": "/assets/items/models-stable/melee/transheynyy-nozh.webp",
    "Окопный штык": "/assets/items/models-stable/melee/okopnyy-shtyk.webp",
    "Короткая сабля": "/assets/items/models-stable/melee/korotkaya-sablya.webp",
    "Клинок инспектора": "/assets/items/models-stable/melee/klinok-inspektora.webp",
    "Мачете": "/assets/items/models-stable/melee/machete.webp",
    "Сапёрная лопатка": "/assets/items/models-stable/melee/sapernaya-lopatka.webp",
    "Короткое копьё": "/assets/items/models-stable/melee/korotkoe-kope.webp",
    "Боевой топорик": "/assets/items/models-stable/melee/boevoy-toporik.webp",
    "Кукри": "/assets/items/models-stable/melee/kukri.webp",
    "Офицерская сабля": "/assets/items/models-stable/melee/ofitserskaya-sablya.webp",
    "Тяжёлый тесак": "/assets/items/models-stable/melee/tyazhelyy-tesak.webp",
    "Боевой топор": "/assets/items/models-stable/melee/boevoy-topor.webp",
    "Дубинка": "/assets/items/models-stable/melee/dubinka.webp",
    "Молоток": "/assets/items/models-stable/melee/molotok.webp",
    "Булава": "/assets/items/models-stable/melee/bulava.webp",
    "Полицейская палка": "/assets/items/models-stable/melee/politseyskaya-palka.webp",
    "Копьё": "/assets/items/models-stable/melee/kope.webp",
    "Алебарда": "/assets/items/models-stable/melee/alebarda.webp",
    "Длинный багор": "/assets/items/models-stable/melee/dlinnyy-bagor.webp",
    "Кувалда": "/assets/items/models-stable/melee/kuvalda.webp",
    "Двуручный топор": "/assets/items/models-stable/melee/dvuruchnyy-topor.webp",
    "Тяжёлый меч": "/assets/items/models-stable/melee/tyazhelyy-mech.webp",
    "Промышленный лом": "/assets/items/models-stable/melee/promyshlennyy-lom.webp",
    "Шоковая дубинка": "/assets/items/models-stable/melee/shokovaya-dubinka.webp",
    "Разрядный кастет": "/assets/items/models-stable/melee/razryadnyy-kastet.webp"
  },
  "profileIcons": {
    "Карманный пистолет": "/assets/items/profiles-stable/pistols/karmannyy-pistolet.webp",
    "Средний пистолет": "/assets/items/profiles-stable/pistols/sredniy-pistolet.webp",
    "Тяжёлый пистолет": "/assets/items/profiles-stable/pistols/tyazhelyy-pistolet.webp",
    "Револьвер": "/assets/items/profiles-stable/pistols/revolver.webp",
    "Тяжёлый револьвер": "/assets/items/profiles-stable/pistols/tyazhelyy-revolver.webp",
    "Анаксионный пистолет": "/assets/items/profiles-stable/pistols/anaksionnyy-pistolet.webp",
    "Лёгкий карабин": "/assets/items/profiles-stable/carbines/legkiy-karabin.webp",
    "Армейский карабин": "/assets/items/profiles-stable/carbines/armeyskiy-karabin.webp",
    "Штурмовой карабин": "/assets/items/profiles-stable/carbines/shturmovoy-karabin.webp",
    "Автоматический карабин": "/assets/items/profiles-stable/carbines/avtomaticheskiy-karabin.webp",
    "Точный карабин": "/assets/items/profiles-stable/carbines/tochnyy-karabin.webp",
    "Охотничья винтовка": "/assets/items/profiles-stable/sniper/ohotnichya-vintovka.webp",
    "Служебная винтовка": "/assets/items/profiles-stable/sniper/sluzhebnaya-vintovka.webp",
    "Снайперская винтовка": "/assets/items/profiles-stable/sniper/snayperskaya-vintovka.webp",
    "Анаксионная винтовка": "/assets/items/profiles-stable/sniper/anaksionnaya-vintovka.webp",
    "Обрез": "/assets/items/profiles-stable/shotguns/obrez.webp",
    "Стандартный дробовик": "/assets/items/profiles-stable/shotguns/standartnyy-drobovik.webp",
    "Боевой дробовик": "/assets/items/profiles-stable/shotguns/boevoy-drobovik.webp",
    "Анаксионный дробовик": "/assets/items/profiles-stable/shotguns/anaksionnyy-drobovik.webp",
    "Огнемётный": "/assets/items/profiles-stable/shotguns/ognemetnyy.webp",
    "Лёгкий гранатомёт": "/assets/items/profiles-stable/heavy/legkiy-granatomet.webp",
    "Тяжёлый гранатомёт": "/assets/items/profiles-stable/heavy/tyazhelyy-granatomet.webp",
    "Тяжёлый пулемёт": "/assets/items/profiles-stable/heavy/tyazhelyy-pulemet.webp",
    "Анаксионный излучатель": "/assets/items/profiles-stable/heavy/anaksionnyy-izluchatel.webp",
    "Скрытая броня": "/assets/items/profiles-stable/armor/skrytaya-bronya.webp",
    "Полевой бронежилет": "/assets/items/profiles-stable/armor/polevoy-bronezhilet.webp",
    "Армейский бронежилет": "/assets/items/profiles-stable/armor/armeyskiy-bronezhilet.webp",
    "Противоосколочный бронекомплект": "/assets/items/profiles-stable/armor/protivooskolochnyy-bronekomplekt.webp",
    "Усиленный бронекомплект": "/assets/items/profiles-stable/armor/usilennyy-bronekomplekt.webp",
    "Стабилизирующая тяжёлая броня": "/assets/items/profiles-stable/armor/stabiliziruyuschaya-tyazhelaya-bronya.webp",
    "Анаксионно-изолированная броня": "/assets/items/profiles-stable/armor/anaksionno-izolirovannaya-bronya.webp",
    "Тяжёлый экзоскелет": "/assets/items/profiles-stable/armor/tyazhelyy-ekzoskelet.webp",
    "Адаптивный экзоскелет": "/assets/items/profiles-stable/armor/adaptivnyy-ekzoskelet.webp",
    "Fogmire-5": "/assets/items/profiles-stable/grenades/fogmire-5.webp",
    "Vaporize": "/assets/items/profiles-stable/grenades/vaporize.webp",
    "Sturmblitz": "/assets/items/profiles-stable/grenades/sturmblitz.webp",
    "Panzersturm": "/assets/items/profiles-stable/grenades/panzersturm.webp",
    "Vektron-12": "/assets/items/profiles-stable/grenades/vektron-12.webp",
    "ГПД": "/assets/items/profiles-stable/grenades/gpd.webp",
    "Экспансор-6": "/assets/items/profiles-stable/grenades/ekspansor-6.webp",
    "Энтропия-7": "/assets/items/profiles-stable/grenades/entropiya-7.webp",
    "Перевязочный комплект": "/assets/items/profiles-stable/consumables/perevyazochnyy-komplekt.webp",
    "Аптечка": "/assets/items/profiles-stable/consumables/aptechka.webp",
    "Антидот": "/assets/items/profiles-stable/consumables/antidot.webp",
    "Турбина": "/assets/items/profiles-stable/consumables/turbina.webp",
    "Энергетический напиток": "/assets/items/profiles-stable/consumables/energeticheskiy-napitok.webp",
    "Энергетический стимулятор": "/assets/items/profiles-stable/consumables/energeticheskiy-stimulyator.webp",
    "Медицинский набор": "/assets/items/profiles-stable/consumables/meditsinskiy-nabor.webp",
    "Хирургический набор": "/assets/items/profiles-stable/consumables/hirurgicheskiy-nabor.webp",
    "ПАСИ": "/assets/items/profiles-stable/consumables/pasi.webp",
    "Стрелы": "/assets/items/profiles-stable/consumables/strely.webp",
    "Болты": "/assets/items/profiles-stable/consumables/bolty.webp",
    "Дымовая шашка": "/assets/items/profiles-stable/consumables/dymovaya-shashka.webp",
    "Противогаз": "/assets/items/placeholders/consumables.webp",
    "Батарея": "/assets/items/profiles-stable/consumables/batareya.webp",
    "Светящийся маркер": "/assets/items/profiles-stable/consumables/svetyaschiysya-marker.webp",
    "Сигнальный маячок": "/assets/items/profiles-stable/consumables/signalnyy-mayachok.webp",
    "Химический нейтрализатор": "/assets/items/profiles-stable/consumables/himicheskiy-neytralizator.webp",
    "Скрипт-детонатор": "/assets/items/profiles-stable/consumables/skript-detonator.webp",
    "Подавитель радиочастот": "/assets/items/profiles-stable/consumables/podavitel-radiochastot.webp",
    "Микрофонный сигнализатор": "/assets/items/profiles-stable/consumables/mikrofonnyy-signalizator.webp",
    "Портативный генератор": "/assets/items/profiles-stable/consumables/portativnyy-generator.webp",
    "Малое оружие": "/assets/items/profiles-stable/melee/maloe-oruzhie.webp",
    "Лёгкое оружие": "/assets/items/profiles-stable/melee/legkoe-oruzhie.webp",
    "Среднее оружие": "/assets/items/profiles-stable/melee/srednee-oruzhie.webp",
    "Тяжёлое оружие": "/assets/items/profiles-stable/melee/tyazheloe-oruzhie.webp",
    "Дробящее оружие": "/assets/items/profiles-stable/melee/drobyaschee-oruzhie.webp",
    "Древковое оружие": "/assets/items/profiles-stable/melee/drevkovoe-oruzhie.webp",
    "Тяжёлое двуручное оружие": "/assets/items/profiles-stable/melee/tyazheloe-dvuruchnoe-oruzhie.webp",
    "Анаксионное оружие ближнего боя": "/assets/items/profiles-stable/melee/anaksionnoe-oruzhie-blizhnego-boya.webp",
    "Безоружный бой": "/assets/items/profiles-stable/melee/bezoruzhnyy-boy.webp",
    "Короткий лук": "/assets/items/profiles-stable/bows/korotkiy-luk.webp",
    "Длинный лук": "/assets/items/profiles-stable/bows/dlinnyy-luk.webp",
    "Охотничий лук": "/assets/items/profiles-stable/bows/ohotnichiy-luk.webp",
    "Лёгкий арбалет": "/assets/items/profiles-stable/crossbows/legkiy-arbalet.webp",
    "Тяжёлый арбалет": "/assets/items/profiles-stable/crossbows/tyazhelyy-arbalet.webp"
  },
  "profiles": {
    "Карманный пистолет": {
      "name": "Карманный пистолет",
      "type": "Пистолет",
      "price": 80,
      "damageTag": "light",
      "models": [
        "Poche-M2",
        "Лань-M1"
      ],
      "desc": "Профиль оружия. Попадание: 1к4 обычный выстрел / 1к6 прицельный выстрел. 50 фт, 1 ОД, порог 1, урон 1, тег: лёгкое; +2 к проверкам Скрытности, чтобы спрятать или пронести оружие. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/pistols/karmannyy-pistolet.webp"
    },
    "Средний пистолет": {
      "name": "Средний пистолет",
      "type": "Пистолет",
      "price": 150,
      "damageTag": "light",
      "models": [
        "Kriegspistole",
        "Liberté-M1",
        "Фэй Лун",
        "Тэппо"
      ],
      "desc": "Профиль оружия. Попадание: 1к4 обычный выстрел / 1к6 прицельный выстрел. 100 фт, 1 ОД, порог 1, урон 2, тег: лёгкое; простое и надёжное боковое оружие. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/pistols/sredniy-pistolet.webp"
    },
    "Тяжёлый пистолет": {
      "name": "Тяжёлый пистолет",
      "type": "Пистолет",
      "price": 250,
      "damageTag": "medium",
      "models": [
        "Kriegsfaust-11",
        "Буря-П"
      ],
      "desc": "Профиль оружия. Попадание: 1к4 обычный выстрел / 1к6 прицельный выстрел. 80 фт, 1 ОД, порог 2, урон 3, тег: среднее; на дальней дистанции -1 к попаданию. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/pistols/tyazhelyy-pistolet.webp"
    },
    "Револьвер": {
      "name": "Револьвер",
      "type": "Пистолет",
      "price": 180,
      "damageTag": "light",
      "models": [
        "Cavaliere-38",
        "Sûreté-R"
      ],
      "desc": "Профиль оружия. Попадание: 1к6 обычный выстрел / 1к8 прицельный выстрел. 80 фт, 1 ОД, порог 2, урон 2, тег: лёгкое; при атаке по цели без укрытия +1 к попаданию. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/pistols/revolver.webp"
    },
    "Тяжёлый револьвер": {
      "name": "Тяжёлый револьвер",
      "type": "Пистолет",
      "price": 320,
      "damageTag": "medium",
      "models": [
        "R-18 Revolver Vento"
      ],
      "desc": "Профиль оружия. Попадание: 1к6 обычный выстрел / 1к8 прицельный выстрел. 80 фт, 1 ОД, порог 3, урон 3, тег: среднее; при критическом успехе урон +1. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/pistols/tyazhelyy-revolver.webp"
    },
    "Анаксионный пистолет": {
      "name": "Анаксионный пистолет",
      "type": "Пистолет",
      "price": 450,
      "damageTag": "medium",
      "models": [
        "Traur-U",
        "Тэндзо-Рэй"
      ],
      "desc": "Профиль оружия. Попадание: 1к4 обычный выстрел / 1к6 прицельный выстрел. 100 фт, 1 ОД, порог 3, урон 2, тег: среднее; при попадании цель теряет 1к4 морали. Может использовать режим ОБ «Анаксионный режим». Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/pistols/anaksionnyy-pistolet.webp"
    },
    "Лёгкий карабин": {
      "name": "Лёгкий карабин",
      "type": "Карабин",
      "price": 300,
      "damageTag": "medium",
      "models": [
        "Égalité",
        "Scauta-K2"
      ],
      "desc": "Профиль оружия. 1к6, 150 фт, 2 ОД, порог 1, урон 2, тег: среднее; простое универсальное оружие без сильной специализации. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/carbines/legkiy-karabin.webp"
    },
    "Армейский карабин": {
      "name": "Армейский карабин",
      "type": "Карабин",
      "price": 450,
      "damageTag": "medium",
      "models": [
        "Банту Тип-31",
        "Ligne-M3",
        "Stahlkar-8",
        "Adlerauge-S"
      ],
      "desc": "Профиль оружия. 1к6, 200 фт, 2 ОД, порог 2, урон 3, тег: среднее; стандартное боевое оружие, может использовать режим ОБ «Подавление». Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/carbines/armeyskiy-karabin.webp"
    },
    "Штурмовой карабин": {
      "name": "Штурмовой карабин",
      "type": "Карабин",
      "price": 500,
      "damageTag": "medium",
      "models": [
        "Банту Тип-32",
        "Кагэцу Тип-7"
      ],
      "desc": "Профиль оружия. 1к6, 120 фт, 2 ОД, порог 2, урон 3, тег: среднее; на ближней дистанции +1 к попаданию, может использовать режимы ОБ «Подавление» и «Шквальный огонь». Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/carbines/shturmovoy-karabin.webp"
    },
    "Автоматический карабин": {
      "name": "Автоматический карабин",
      "type": "Карабин",
      "price": 550,
      "damageTag": "medium",
      "models": [
        "Blitzsturm-kurz",
        "Molot-B1"
      ],
      "desc": "Профиль оружия. 1к6, 150 фт, 2 ОД, порог 3, урон 2, тег: среднее; при действии «Подавление» выбранная цель дополнительно получает -1 к попаданию до начала своего следующего хода. Может использовать «Подавление» и «Шквальный огонь». Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/carbines/avtomaticheskiy-karabin.webp"
    },
    "Точный карабин": {
      "name": "Точный карабин",
      "type": "Карабин",
      "price": 650,
      "damageTag": "medium",
      "models": [
        "Фэнчэн-L1",
        "SR-42 Cacciatore"
      ],
      "desc": "Профиль оружия. 1к8, 250 фт, 2 ОД, порог 3, урон 3, тег: среднее; если стрелок не двигался в этот ход, +1 к попаданию. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/carbines/tochnyy-karabin.webp"
    },
    "Охотничья винтовка": {
      "name": "Охотничья винтовка",
      "type": "Снайперская винтовка",
      "price": 280,
      "damageTag": "medium",
      "models": [
        "Fraternité",
        "Hirschlauf-3"
      ],
      "desc": "Профиль оружия. 1к6, 250 фт, 2 ОД, порог 1, урон 2, тег: среднее; при «Выверенном выстреле» дополнительно +1 к попаданию. Повторные «Выверенные выстрелы» пристреливают огневую позицию: уровень 2 позволяет дальнобойным атакам против стрелка игнорировать 2 МЗ его укрытия, уровень 3 — полностью игнорировать МЗ этого укрытия. Поддерживает «Контрснайперское наблюдение» за 1 ОД; контрснайперская реакция блокируется дымом. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/sniper/ohotnichya-vintovka.webp"
    },
    "Служебная винтовка": {
      "name": "Служебная винтовка",
      "type": "Снайперская винтовка",
      "price": 500,
      "damageTag": "medium",
      "models": [
        "Ordonnance-5"
      ],
      "desc": "Профиль оружия. 1к6, 300 фт, 2 ОД, порог 2, урон 3, тег: среднее; при «Выверенном выстреле» дополнительно +1 к попаданию. Повторные «Выверенные выстрелы» пристреливают огневую позицию: уровень 2 позволяет дальнобойным атакам против стрелка игнорировать 2 МЗ его укрытия, уровень 3 — полностью игнорировать МЗ этого укрытия. Поддерживает «Контрснайперское наблюдение» за 1 ОД; контрснайперская реакция блокируется дымом. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/sniper/sluzhebnaya-vintovka.webp"
    },
    "Снайперская винтовка": {
      "name": "Снайперская винтовка",
      "type": "Снайперская винтовка",
      "price": 800,
      "damageTag": "medium",
      "models": [
        "Adlerauge-X",
        "Шэньхуо"
      ],
      "desc": "Профиль оружия. 1к8, 500 фт, 2 ОД, порог 3, урон 3, тег: среднее; на дальней дистанции +1 к попаданию, если стрелок не двигался в этот ход; при «Выверенном выстреле» дополнительно +1 к попаданию. Повторные «Выверенные выстрелы» пристреливают огневую позицию: уровень 2 позволяет дальнобойным атакам против стрелка игнорировать 2 МЗ его укрытия, уровень 3 — полностью игнорировать МЗ этого укрытия. Поддерживает «Контрснайперское наблюдение» за 1 ОД; контрснайперская реакция блокируется дымом. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/sniper/snayperskaya-vintovka.webp"
    },
    "Анаксионная винтовка": {
      "name": "Анаксионная винтовка",
      "type": "Снайперская винтовка",
      "price": 1200,
      "damageTag": "heavy",
      "models": [
        "Palitsa-M2",
        "Рюсан-C2"
      ],
      "desc": "Профиль оружия. 1к6, 400 фт, 3 ОД, порог 4, урон 4, тег: тяжёлое; лёгкая и средняя броня не помогают против атаки, тяжёлая броня снижает каждое ранение на 1 ступень; при «Выверенном выстреле» дополнительно +1 к попаданию. Повторные «Выверенные выстрелы» пристреливают огневую позицию: уровень 2 позволяет дальнобойным атакам против стрелка игнорировать 2 МЗ его укрытия, уровень 3 — полностью игнорировать МЗ этого укрытия. Поддерживает «Контрснайперское наблюдение» за 1 ОД; контрснайперская реакция блокируется дымом. Может использовать режим ОБ «Анаксионный режим». Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/sniper/anaksionnaya-vintovka.webp"
    },
    "Обрез": {
      "name": "Обрез",
      "type": "Дробовик",
      "price": 220,
      "damageTag": "medium",
      "models": [
        "Bâtard-9"
      ],
      "desc": "Профиль оружия. 1к6, дальность 30 фт, ширина конуса 10 фт, 2 ОД, порог 1, урон 2, тег: среднее; на ближней дистанции +1 к попаданию. Конусная атака имеет глубину не более 30 фт. Можно спрятать под одеждой с проверкой Скрытности. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/shotguns/obrez.webp"
    },
    "Стандартный дробовик": {
      "name": "Стандартный дробовик",
      "type": "Дробовик",
      "price": 420,
      "damageTag": "medium",
      "models": [
        "Лэймэнь-L2",
        "M. Dural",
        "Цзиньфэн"
      ],
      "desc": "Профиль оружия. 1к6, дальность 60 фт, ширина конуса 10 фт, 2 ОД, порог 2, урон 3, тег: среднее. Конусная атака имеет глубину не более 30 фт; с 31 фт доступна обычная одноцелевая атака. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/shotguns/standartnyy-drobovik.webp"
    },
    "Боевой дробовик": {
      "name": "Боевой дробовик",
      "type": "Дробовик",
      "price": 650,
      "damageTag": "medium",
      "models": [
        "Stahlhammer-11",
        "DS-15 Tempesta",
        "Ками-Рэн",
        "Zarya-D1",
        "Molot-R2"
      ],
      "desc": "Профиль оружия. Попадание: 1к8 на дистанции 0–10 фт, 1к6 на дистанции 11+ фт. Дальность 80 фт, ширина конуса 15 фт, 2 ОД, порог 3, урон 3, тег: среднее. Конусная атака имеет глубину не более 30 фт; с 31 фт доступна обычная одноцелевая атака. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/shotguns/boevoy-drobovik.webp"
    },
    "Анаксионный дробовик": {
      "name": "Анаксионный дробовик",
      "type": "Дробовик",
      "price": 700,
      "damageTag": "heavy",
      "models": [],
      "desc": "Профиль оружия. 1к8, 100 фт, 2 ОД, порог 3, урон 4, тег: тяжёлое; стреляет по одной цели, не использует конус, может применять режим ОБ «Анаксионный режим». Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/shotguns/anaksionnyy-drobovik.webp"
    },
    "Огнемётный": {
      "name": "Огнемётный",
      "type": "Дробовик",
      "price": 850,
      "damageTag": "heavy",
      "models": [
        "Stahlhammer-11F"
      ],
      "desc": "Профиль оружия. 1к8, 80 фт, 2 ОД, порог 4, урон 3, тег: тяжёлое; зона горения наносит 1 урон в начале следующего хода тем, кто остался внутри. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/shotguns/ognemetnyy.webp"
    },
    "Лёгкий гранатомёт": {
      "name": "Лёгкий гранатомёт",
      "type": "Тяжёлое",
      "price": 1000,
      "damageTag": "heavy",
      "models": [
        "Éruption",
        "Feuersturm"
      ],
      "desc": "Профиль оружия. 1к6, 20 фт радиус / 120 фт, 2 ОД, перезарядка 2 ОД, порог 3, урон 4, тег: тяжёлое; двойной урон укрытиям, каждая атака требует 1 ОБ как тяжёлый заряд. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/heavy/legkiy-granatomet.webp"
    },
    "Тяжёлый гранатомёт": {
      "name": "Тяжёлый гранатомёт",
      "type": "Тяжёлое",
      "price": 1600,
      "damageTag": "heavy",
      "models": [
        "Festungsbrecher-T4",
        "Гром-О2",
        "Zvezda-T2"
      ],
      "desc": "Профиль оружия. 1к8, 30 фт радиус / 200 фт, 3 ОД, перезарядка 2 ОД, порог 4, урон 5, тег: тяжёлое; минимальная безопасная дистанция 20 фт, каждая атака требует 1 ОБ как тяжёлый заряд. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/heavy/tyazhelyy-granatomet.webp"
    },
    "Тяжёлый пулемёт": {
      "name": "Тяжёлый пулемёт",
      "type": "Тяжёлое",
      "price": 1300,
      "damageTag": "heavy",
      "models": [
        "Stahlregen-11",
        "Molot-MG2"
      ],
      "desc": "Профиль оружия. 1к8, 250 фт, 3 ОД, перезарядка 2 ОД, порог 3, урон 3, тег: тяжёлое; может использовать режимы ОБ «Подавление» и «Шквальный огонь»; Подавление работает на 2 укрытия, прилегающих друг к другу; урон зоны шквального огня 2. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/heavy/tyazhelyy-pulemet.webp"
    },
    "Анаксионный излучатель": {
      "name": "Анаксионный излучатель",
      "type": "Тяжёлое",
      "price": 1800,
      "damageTag": "heavy",
      "models": [
        "Они-Баку"
      ],
      "desc": "Профиль оружия. 1к8, 20 фт радиус / 120 фт, 3 ОД, перезарядка 2 ОД, порог 4, урон 4, тег: тяжёлое; цели в зоне теряют 1к6 морали; может использовать режим ОБ «Анаксионный режим» для +1 входящего урона по целям в зоне. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/heavy/anaksionnyy-izluchatel.webp"
    },
    "Скрытая броня": {
      "name": "Скрытая броня",
      "type": "Лёгкая броня",
      "price": 120,
      "armorClass": "light",
      "armorBz": 2,
      "armorFeature": "hidden",
      "models": [
        "Stahlmantel",
        "Veste Défenseur",
        "Цинцзя"
      ],
      "desc": "Профиль брони. БЗ/прочность 2. Лёгкая броня. Скрытая: если броня закрыта обычной одеждой, беглый осмотр не позволяет автоматически определить, что персонаж бронирован; намеренный досмотр или внимательное наблюдение могут обнаружить её по решению Мастера. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/armor/skrytaya-bronya.webp"
    },
    "Полевой бронежилет": {
      "name": "Полевой бронежилет",
      "type": "Лёгкая броня",
      "price": 170,
      "armorClass": "light",
      "armorBz": 3,
      "armorFeature": "quick-release",
      "models": [
        "Буря-М"
      ],
      "desc": "Профиль брони. БЗ/прочность 3. Лёгкая броня. Быстросъёмный: можно полностью надеть или снять за 1 ОД даже в бою. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/armor/polevoy-bronezhilet.webp"
    },
    "Армейский бронежилет": {
      "name": "Армейский бронежилет",
      "type": "Средняя броня",
      "price": 300,
      "armorClass": "medium",
      "armorBz": 4,
      "armorFeature": "standard",
      "models": [
        "Gilet Guerrier",
        "Дуншань"
      ],
      "desc": "Профиль брони. БЗ/прочность 4. Средняя броня. Стандартный армейский бронежилет без дополнительных механических свойств. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/armor/armeyskiy-bronezhilet.webp"
    },
    "Противоосколочный бронекомплект": {
      "name": "Противоосколочный бронекомплект",
      "type": "Средняя броня",
      "price": 350,
      "armorClass": "medium",
      "armorBz": 4,
      "armorFeature": "blast-resistant",
      "models": [
        "Kriegskorps"
      ],
      "desc": "Профиль брони. БЗ/прочность 4. Средняя броня. Противоосколочный: числовой урон от взрывной атаки уменьшается на 1 до перевода урона в ранения, минимум до 0. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/armor/protivooskolochnyy-bronekomplekt.webp"
    },
    "Усиленный бронекомплект": {
      "name": "Усиленный бронекомплект",
      "type": "Средняя броня",
      "price": 400,
      "armorClass": "medium",
      "armorBz": 5,
      "armorFeature": "bulky",
      "models": [
        "Титан-М"
      ],
      "desc": "Профиль брони. БЗ/прочность 5. Средняя броня. Громоздкий: Скорость персонажа уменьшается на 5 футов. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/armor/usilennyy-bronekomplekt.webp"
    },
    "Стабилизирующая тяжёлая броня": {
      "name": "Стабилизирующая тяжёлая броня",
      "type": "Тяжёлая броня",
      "price": 800,
      "armorClass": "heavy",
      "armorBz": 8,
      "armorFeature": "stabilizing",
      "models": [
        "Berg M8"
      ],
      "desc": "Профиль брони. БЗ/прочность 8. Тяжёлая броня. Стабилизация: числовой штраф -2 от Серьёзного ранения становится -1; уменьшение Скорости, помеха от Среднего ранения и прочие эффекты ранений не изменяются. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/armor/stabiliziruyuschaya-tyazhelaya-bronya.webp"
    },
    "Анаксионно-изолированная броня": {
      "name": "Анаксионно-изолированная броня",
      "type": "Тяжёлая броня",
      "price": 850,
      "armorClass": "heavy",
      "armorBz": 8,
      "armorFeature": "anaxion-isolated",
      "anaxionSteps": 1,
      "models": [
        "Armure Titanique"
      ],
      "desc": "Профиль брони. БЗ/прочность 8. Тяжёлая броня. Изоляция: числовой урон от взрывной атаки уменьшается на 1; броня также применима против анаксионных атак и снижает созданные ими ранения на 1 ступень. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/armor/anaksionno-izolirovannaya-bronya.webp"
    },
    "Тяжёлый экзоскелет": {
      "name": "Тяжёлый экзоскелет",
      "type": "Тяжёлая броня",
      "price": 900,
      "armorClass": "heavy",
      "armorBz": 9,
      "armorFeature": "heavy-exoskeleton",
      "anaxionSteps": 1,
      "models": [
        "Экзоскелет Т-1"
      ],
      "desc": "Профиль брони. БЗ/прочность 9. Тяжёлая броня. Герметичный контур: полностью защищает от газовых и токсичных эффектов; БЗ/прочность при этом не расходуется. Анаксионная защита: против анаксионных атак снижает ранения на 1 ступень. Силовой каркас: +1 к проверкам Физической силы, связанным с переносом, подъёмом, удержанием или перемещением тяжестей; этот контекстный бонус не применяется к атакам. Громоздкий: -2 к проверкам навыков Ловкости и -5 футов Скорости. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/armor/tyazhelyy-ekzoskelet.webp"
    },
    "Адаптивный экзоскелет": {
      "name": "Адаптивный экзоскелет",
      "type": "Тяжёлая броня",
      "price": 1000,
      "armorClass": "heavy",
      "armorBz": 10,
      "armorFeature": "adaptive-exoskeleton",
      "models": [
        "Шаньхэй"
      ],
      "desc": "Профиль брони. БЗ/прочность 10. Тяжёлая броня. Компенсация нагрузки: персонаж не получает помеху на Прыжок из-за ношения тяжёлой брони. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/armor/adaptivnyy-ekzoskelet.webp"
    },
    "Fogmire-5": {
      "name": "Fogmire-5",
      "type": "Граната",
      "price": 50,
      "desc": "Газовая граната. Радиус 15 футов, длительность 2 раунда. В начале хода цель в облаке получает 1 урон (лёгкий тип); газ игнорирует обычную броню. Урон полностью отменяется, если надет Противогаз или Тяжёлый экзоскелет. Облако ограничивает зрение до 20 футов и не распространяется сквозь стены и закрытые двери.",
      "icon": "/assets/items/profiles-stable/grenades/fogmire-5.webp"
    },
    "Vaporize": {
      "name": "Vaporize",
      "type": "Граната",
      "price": 100,
      "desc": "Дымовая граната. Создаёт облако радиусом 20 футов на 3 раунда; область предоставляет +2 МЗ. Дым не распространяется сквозь стены и закрытые двери и ограничивает видимость: изнутри облака дальность зрения не более 20 футов, а через 20 футов непрерывного дыма видеть нельзя. Контрснайперский выстрел невозможен по цели внутри дыма и через линию огня, пересекающую дым.",
      "icon": "/assets/items/profiles-stable/grenades/vaporize.webp"
    },
    "Sturmblitz": {
      "name": "Sturmblitz",
      "type": "Граната",
      "price": 150,
      "desc": "Осколочная граната. Урон 4, радиус 20 футов. Разрушает лёгкие укрытия.",
      "icon": "/assets/items/profiles-stable/grenades/sturmblitz.webp"
    },
    "Panzersturm": {
      "name": "Panzersturm",
      "type": "Граната",
      "price": 200,
      "desc": "Осколочная бронебойная граната. Урон 4, радиус 15 футов. Может пробивать тяжёлую броню; атака считается бронебойной.",
      "icon": "/assets/items/profiles-stable/grenades/panzersturm.webp"
    },
    "Vektron-12": {
      "name": "Vektron-12",
      "type": "Граната",
      "price": 200,
      "desc": "Токсическая газовая граната. Радиус 15 футов. Через 1 раунд наносит 3 урона всем незащищённым целям в облаке; газ игнорирует обычную броню. Противогаз или Тяжёлый экзоскелет полностью отменяют газовый эффект без расхода БЗ. Газ не проходит сквозь стены и закрытые двери и ограничивает зрение до 20 футов.",
      "icon": "/assets/items/profiles-stable/grenades/vektron-12.webp"
    },
    "ГПД": {
      "name": "ГПД",
      "type": "Граната",
      "price": 250,
      "desc": "Паническая газовая граната. Урон 2 в радиусе 10 футов; газ игнорирует обычную броню. Незащищённые враждебные цели теряют ход из-за паники и получают помеху на атаки. Противогаз или Тяжёлый экзоскелет полностью отменяют газовый эффект. Газ не проходит сквозь стены и закрытые двери и ограничивает зрение до 20 футов.",
      "icon": "/assets/items/profiles-stable/grenades/gpd.webp"
    },
    "Экспансор-6": {
      "name": "Экспансор-6",
      "type": "Граната",
      "price": 400,
      "desc": "Анаксионная граната. Урон 4, радиус 30 футов. Пробивает большинство щитов и барьеров.",
      "icon": "/assets/items/profiles-stable/grenades/ekspansor-6.webp"
    },
    "Энтропия-7": {
      "name": "Энтропия-7",
      "type": "Граната",
      "price": 450,
      "desc": "Анаксионная граната. Урон 4, радиус 20 футов. Цели в области спонтанно атакуют ближайшую цель в течение 1 хода.",
      "icon": "/assets/items/profiles-stable/grenades/entropiya-7.webp"
    },
    "Перевязочный комплект": {
      "name": "Перевязочный комплект",
      "type": "Расходник",
      "price": 30,
      "desc": "За 1 ОД выберите один эффект: снять 1 лёгкое ранение или автоматически остановить Кровотечение. До 3 использований.",
      "icon": "/assets/items/profiles-stable/consumables/perevyazochnyy-komplekt.webp"
    },
    "Аптечка": {
      "name": "Аптечка",
      "type": "Расходник",
      "price": 50,
      "desc": "Лечит лёгкие и средние ранения вне боя. Можно использовать на себе или союзнике.",
      "icon": "/assets/items/profiles-stable/consumables/aptechka.webp"
    },
    "Антидот": {
      "name": "Антидот",
      "type": "Расходник",
      "price": 75,
      "desc": "Лечит отравление и нейтрализует токсины.",
      "icon": "/assets/items/profiles-stable/consumables/antidot.webp"
    },
    "Противогаз": {
      "name": "Противогаз",
      "type": "Расходник",
      "price": 150,
      "desc": "Многоразовый противогаз. Надевание в бою стоит 1 ОД. Пока надет, полностью защищает от газовых и токсичных эффектов; при защите не расходуется. Не защищает от огня или обычного дыма.",
      "icon": "/assets/items/placeholders/consumables.webp"
    },
    "Турбина": {
      "name": "Турбина",
      "type": "Расходник",
      "price": 75,
      "desc": "Восстанавливает 1к10 морали и временно снимает эффект одной травмы. Можно применять в бою.",
      "icon": "/assets/items/profiles-stable/consumables/turbina.webp"
    },
    "Энергетический напиток": {
      "name": "Энергетический напиток",
      "type": "Расходник",
      "price": 40,
      "desc": "Восстанавливает 1 ОД и даёт +1 к Физической силе на 3 хода.",
      "icon": "/assets/items/profiles-stable/consumables/energeticheskiy-napitok.webp"
    },
    "Энергетический стимулятор": {
      "name": "Энергетический стимулятор",
      "type": "Расходник",
      "price": 50,
      "desc": "Восстанавливает 1 ОД и даёт +5 футов к Скорости до конца боя. Вызывает привыкание.",
      "icon": "/assets/items/profiles-stable/consumables/energeticheskiy-stimulyator.webp"
    },
    "Медицинский набор": {
      "name": "Медицинский набор",
      "type": "Расходник",
      "price": 200,
      "desc": "Многоразовый набор для лечения травм.",
      "icon": "/assets/items/profiles-stable/consumables/meditsinskiy-nabor.webp"
    },
    "Хирургический набор": {
      "name": "Хирургический набор",
      "type": "Расходник",
      "price": 300,
      "desc": "Многоразовый набор для лечения травм, требующих хирургии.",
      "icon": "/assets/items/profiles-stable/consumables/hirurgicheskiy-nabor.webp"
    },
    "ПАСИ": {
      "name": "ПАСИ",
      "type": "Расходник",
      "price": 500,
      "desc": "Восстанавливает 2 лёгких ранения или 1 среднее, лечит яды. Вызывает привыкание после 3 использований.",
      "icon": "/assets/items/profiles-stable/consumables/pasi.webp"
    },
    "Стрелы": {
      "name": "Стрелы",
      "type": "Расходник",
      "price": 15,
      "desc": "Боезапас для луков",
      "icon": "/assets/items/profiles-stable/consumables/strely.webp"
    },
    "Болты": {
      "name": "Болты",
      "type": "Расходник",
      "price": 25,
      "desc": "Боезапас для арбалетов",
      "icon": "/assets/items/profiles-stable/consumables/bolty.webp"
    },
    "Дымовая шашка": {
      "name": "Дымовая шашка",
      "type": "Расходник",
      "price": 40,
      "desc": "Создаёт дымовой экран радиусом 10 футов на 1 раунд; область даёт +1 МЗ и позволяет скрыться. Дым не проходит сквозь стены и закрытые двери; изнутри облака зрение ограничено 20 футами, а через 20 футов непрерывного дыма видеть нельзя. Контрснайперский выстрел невозможен по цели внутри дыма и через линию огня, пересекающую дым.",
      "icon": "/assets/items/profiles-stable/consumables/dymovaya-shashka.webp"
    },
    "Батарея": {
      "name": "Батарея",
      "type": "Расходник",
      "price": 25,
      "desc": "Питает фонари, маячки и прочие малые приборы.",
      "icon": "/assets/items/profiles-stable/consumables/batareya.webp"
    },
    "Светящийся маркер": {
      "name": "Светящийся маркер",
      "type": "Расходник",
      "price": 20,
      "desc": "Позволяет оставлять яркие метки.",
      "icon": "/assets/items/profiles-stable/consumables/svetyaschiysya-marker.webp"
    },
    "Сигнальный маячок": {
      "name": "Сигнальный маячок",
      "type": "Расходник",
      "price": 60,
      "desc": "Отправляет светозвуковой сигнал на 150 футов. Может привлечь союзников или врагов.",
      "icon": "/assets/items/profiles-stable/consumables/signalnyy-mayachok.webp"
    },
    "Химический нейтрализатор": {
      "name": "Химический нейтрализатор",
      "type": "Расходник",
      "price": 100,
      "desc": "Снимает эффект токсичных веществ с одежды и экипировки.",
      "icon": "/assets/items/profiles-stable/consumables/himicheskiy-neytralizator.webp"
    },
    "Скрипт-детонатор": {
      "name": "Скрипт-детонатор",
      "type": "Расходник",
      "price": 80,
      "desc": "Активирует мины или гранаты на расстоянии до 50 футов.",
      "icon": "/assets/items/profiles-stable/consumables/skript-detonator.webp"
    },
    "Подавитель радиочастот": {
      "name": "Подавитель радиочастот",
      "type": "Расходник",
      "price": 100,
      "desc": "Блокирует рации, сигнальные маячки и микрофонные сигнализаторы в радиусе 30 футов.",
      "icon": "/assets/items/profiles-stable/consumables/podavitel-radiochastot.webp"
    },
    "Микрофонный сигнализатор": {
      "name": "Микрофонный сигнализатор",
      "type": "Расходник",
      "price": 120,
      "desc": "Позволяет слышать радиопередачи на расстоянии до 100 футов.",
      "icon": "/assets/items/profiles-stable/consumables/mikrofonnyy-signalizator.webp"
    },
    "Портативный генератор": {
      "name": "Портативный генератор",
      "type": "Расходник",
      "price": 150,
      "desc": "Запитывает устройства на 3 хода.",
      "icon": "/assets/items/profiles-stable/consumables/portativnyy-generator.webp"
    },
    "Малое оружие": {
      "name": "Малое оружие",
      "type": "Оружие ближнего боя",
      "price": 40,
      "damageTag": "light",
      "models": [
        "Складной нож",
        "Кастет",
        "Сапожный нож",
        "Короткий стилет"
      ],
      "desc": "Профиль оружия ближнего боя. Попадание 1к4, урон 1, атака 1 ОД, бонус: Акробатика или Физическая сила. Легко спрятать: +2 к проверкам Скрытности, чтобы скрыть или пронести оружие. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/melee/maloe-oruzhie.webp"
    },
    "Лёгкое оружие": {
      "name": "Лёгкое оружие",
      "type": "Оружие ближнего боя",
      "price": 80,
      "damageTag": "light",
      "models": [
        "Траншейный нож",
        "Окопный штык",
        "Короткая сабля",
        "Клинок инспектора"
      ],
      "desc": "Профиль оружия ближнего боя. Попадание 1к6, урон 2, атака 2 ОД, бонус: Акробатика. Быстрое: +1 к встречному броску, если персонаж защищается. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/melee/legkoe-oruzhie.webp"
    },
    "Среднее оружие": {
      "name": "Среднее оружие",
      "type": "Оружие ближнего боя",
      "price": 120,
      "damageTag": "medium",
      "models": [
        "Мачете",
        "Сапёрная лопатка",
        "Короткое копьё",
        "Боевой топорик"
      ],
      "desc": "Профиль оружия ближнего боя. Попадание 1к6, урон 2, атака 2 ОД, бонус: Акробатика или Физическая сила. Универсальное: без дополнительных свойств. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/melee/srednee-oruzhie.webp"
    },
    "Тяжёлое оружие": {
      "name": "Тяжёлое оружие",
      "type": "Оружие ближнего боя",
      "price": 180,
      "damageTag": "medium",
      "models": [
        "Кукри",
        "Офицерская сабля",
        "Тяжёлый тесак",
        "Боевой топор"
      ],
      "desc": "Профиль оружия ближнего боя. Попадание 1к8, урон 3, атака 2 ОД, бонус: Физическая сила. Мощный удар: за дополнительное 1 ОД +1 к урону. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/melee/tyazheloe-oruzhie.webp"
    },
    "Дробящее оружие": {
      "name": "Дробящее оружие",
      "type": "Оружие ближнего боя",
      "price": 140,
      "damageTag": "medium",
      "models": [
        "Дубинка",
        "Молоток",
        "Булава",
        "Полицейская палка"
      ],
      "desc": "Профиль оружия ближнего боя. Попадание 1к8, урон 2, атака 2 ОД, бонус: Физическая сила. Оглушение: при попадании можно потратить 1 ОД, чтобы цель получила -1 к следующему встречному броску ближнего боя. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/melee/drobyaschee-oruzhie.webp"
    },
    "Древковое оружие": {
      "name": "Древковое оружие",
      "type": "Оружие ближнего боя",
      "price": 150,
      "damageTag": "medium",
      "models": [
        "Копьё",
        "Алебарда",
        "Длинный багор"
      ],
      "desc": "Профиль оружия ближнего боя. Попадание 1к6, урон 2, атака 2 ОД, бонус: Акробатика или Физическая сила. Удержание дистанции: +1 к встречному броску против цели, которая в этот ход применяла Натиск. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/melee/drevkovoe-oruzhie.webp"
    },
    "Тяжёлое двуручное оружие": {
      "name": "Тяжёлое двуручное оружие",
      "type": "Оружие ближнего боя",
      "price": 260,
      "damageTag": "heavy",
      "models": [
        "Кувалда",
        "Двуручный топор",
        "Тяжёлый меч",
        "Промышленный лом"
      ],
      "desc": "Профиль оружия ближнего боя. Попадание 1к8, урон 4, атака 3 ОД, бонус: Физическая сила. Громоздкое: Встречный удар этим оружием стоит 2 ОД вместо 1 ОД. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/melee/tyazheloe-dvuruchnoe-oruzhie.webp"
    },
    "Анаксионное оружие ближнего боя": {
      "name": "Анаксионное оружие ближнего боя",
      "type": "Оружие ближнего боя",
      "price": 240,
      "damageTag": "heavy",
      "models": [
        "Шоковая дубинка",
        "Разрядный кастет"
      ],
      "desc": "Профиль оружия ближнего боя. Попадание 1к6, урон 2, атака 2 ОД, бонус: Акробатика или Физическая сила. Шок: при попадании можно вместо урона заставить цель пройти Стойкость против результата атаки. При провале цель теряет 1 ОД в следующий ход. Модель не меняет характеристики.",
      "icon": "/assets/items/profiles-stable/melee/anaksionnoe-oruzhie-blizhnego-boya.webp"
    },
    "Безоружный бой": {
      "name": "Безоружный бой",
      "type": "Оружие ближнего боя",
      "price": 0,
      "damageTag": "light",
      "models": [],
      "desc": "Профиль безоружной атаки. Попадание 1к4, урон 1, атака 2 ОД, бонус: Физическая сила. Не является предметом и не может быть выбит или потерян.",
      "icon": "/assets/items/profiles-stable/melee/bezoruzhnyy-boy.webp"
    },
    "Короткий лук": {
      "name": "Короткий лук",
      "type": "Луки",
      "price": 120,
      "desc": "Колющее оружие. Попадание 1к6, дальность 100 футов, урон 2. Натяжение 1 ОД + выстрел 1 ОД. Бесшумность: выстрел слышен в пределах 60 футов.",
      "icon": "/assets/items/profiles-stable/bows/korotkiy-luk.webp"
    },
    "Длинный лук": {
      "name": "Длинный лук",
      "type": "Луки",
      "price": 300,
      "desc": "Колющее оружие. Попадание 1к8, дальность 250 футов, урон 3. Натяжение 1 ОД + выстрел 1 ОД. +1 к попаданию, если стрелок не двигался в прошлом ходу. Бесшумность: выстрел слышен в пределах 60 футов.",
      "icon": "/assets/items/profiles-stable/bows/dlinnyy-luk.webp"
    },
    "Охотничий лук": {
      "name": "Охотничий лук",
      "type": "Луки",
      "price": 180,
      "desc": "Колющее оружие. Попадание 1к6, дальность 150 футов, урон 2. Натяжение 1 ОД + выстрел 1 ОД. +1 к проверкам Выживания; игнорирует 1 МЗ цели. Бесшумность: выстрел слышен в пределах 60 футов.",
      "icon": "/assets/items/profiles-stable/bows/ohotnichiy-luk.webp"
    },
    "Лёгкий арбалет": {
      "name": "Лёгкий арбалет",
      "type": "Арбалеты",
      "price": 180,
      "desc": "Колющее оружие. Попадание 1к8, дальность 120 футов, урон 3. Выстрел 2 ОД; можно использовать одной рукой; перезарядка 1 ОД. Бесшумность: выстрел слышен в пределах 60 футов.",
      "icon": "/assets/items/profiles-stable/crossbows/legkiy-arbalet.webp"
    },
    "Тяжёлый арбалет": {
      "name": "Тяжёлый арбалет",
      "type": "Арбалеты",
      "price": 550,
      "desc": "Колющее оружие. Попадание 1к10, дальность 200 футов, урон 4. Выстрел 2 ОД; игнорирует 1 МЗ лёгкого укрытия; перезарядка 2 ОД, во время перезарядки нельзя двигаться. Бесшумность: выстрел слышен в пределах 60 футов.",
      "icon": "/assets/items/profiles-stable/crossbows/tyazhelyy-arbalet.webp"
    }
  },
  "models": {
    "Poche-M2": {
      "profile": "Карманный пистолет",
      "type": "Пистолет",
      "icon": "/assets/items/models/pistols/poche-m2-8cf21eb6.webp",
      "description": "Модель профиля «Карманный пистолет». Внешний вид не меняет характеристики профиля."
    },
    "Лань-M1": {
      "profile": "Карманный пистолет",
      "type": "Пистолет",
      "icon": "/assets/items/models/pistols/m1-a65ebaa4.webp",
      "description": "Модель профиля «Карманный пистолет». Внешний вид не меняет характеристики профиля."
    },
    "Kriegspistole": {
      "profile": "Средний пистолет",
      "type": "Пистолет",
      "icon": "/assets/items/models/pistols/kriegspistole-4fe6b3d7.webp",
      "description": "Модель профиля «Средний пистолет». Внешний вид не меняет характеристики профиля."
    },
    "Liberté-M1": {
      "profile": "Средний пистолет",
      "type": "Пистолет",
      "icon": "/assets/items/models/pistols/liberte-m1-437c652c.webp",
      "description": "Модель профиля «Средний пистолет». Внешний вид не меняет характеристики профиля."
    },
    "Фэй Лун": {
      "profile": "Средний пистолет",
      "type": "Пистолет",
      "icon": "/assets/items/models/pistols/item-90dd2760.webp",
      "description": "Модель профиля «Средний пистолет». Внешний вид не меняет характеристики профиля."
    },
    "Тэппо": {
      "profile": "Средний пистолет",
      "type": "Пистолет",
      "icon": "/assets/items/models/pistols/item-06d7c4fb.webp",
      "description": "Модель профиля «Средний пистолет». Внешний вид не меняет характеристики профиля."
    },
    "Kriegsfaust-11": {
      "profile": "Тяжёлый пистолет",
      "type": "Пистолет",
      "icon": "/assets/items/models/pistols/kriegsfaust-11-5fd79a69.webp",
      "description": "Модель профиля «Тяжёлый пистолет». Внешний вид не меняет характеристики профиля."
    },
    "Буря-П": {
      "profile": "Тяжёлый пистолет",
      "type": "Пистолет",
      "icon": "/assets/items/models/pistols/item-84defd98.webp",
      "description": "Модель профиля «Тяжёлый пистолет». Внешний вид не меняет характеристики профиля."
    },
    "Cavaliere-38": {
      "profile": "Револьвер",
      "type": "Пистолет",
      "icon": "/assets/items/models/pistols/cavaliere-38-cc2a051d.webp",
      "description": "Модель профиля «Револьвер». Внешний вид не меняет характеристики профиля."
    },
    "Sûreté-R": {
      "profile": "Револьвер",
      "type": "Пистолет",
      "icon": "/assets/items/models/pistols/surete-r-570e522e.webp",
      "description": "Модель профиля «Револьвер». Внешний вид не меняет характеристики профиля."
    },
    "R-18 Revolver Vento": {
      "profile": "Тяжёлый револьвер",
      "type": "Пистолет",
      "icon": "/assets/items/models/pistols/r-18-revolver-vento-06614abd.webp",
      "description": "Модель профиля «Тяжёлый револьвер». Внешний вид не меняет характеристики профиля."
    },
    "Traur-U": {
      "profile": "Анаксионный пистолет",
      "type": "Пистолет",
      "icon": "/assets/items/models/pistols/traur-u-68a13975.webp",
      "description": "Модель профиля «Анаксионный пистолет». Внешний вид не меняет характеристики профиля."
    },
    "Тэндзо-Рэй": {
      "profile": "Анаксионный пистолет",
      "type": "Пистолет",
      "icon": "/assets/items/models/pistols/item-600f8090.webp",
      "description": "Модель профиля «Анаксионный пистолет». Внешний вид не меняет характеристики профиля."
    },
    "Égalité": {
      "profile": "Лёгкий карабин",
      "type": "Карабин",
      "icon": "/assets/items/models/carbines/egalite-24790660.webp",
      "description": "Модель профиля «Лёгкий карабин». Внешний вид не меняет характеристики профиля."
    },
    "Scauta-K2": {
      "profile": "Лёгкий карабин",
      "type": "Карабин",
      "icon": "/assets/items/models/carbines/scauta-k2-2c8facc3.webp",
      "description": "Модель профиля «Лёгкий карабин». Внешний вид не меняет характеристики профиля."
    },
    "Банту Тип-31": {
      "profile": "Армейский карабин",
      "type": "Карабин",
      "icon": "/assets/items/models/carbines/31-8ae591f8.webp",
      "description": "Модель профиля «Армейский карабин». Внешний вид не меняет характеристики профиля."
    },
    "Ligne-M3": {
      "profile": "Армейский карабин",
      "type": "Карабин",
      "icon": "/assets/items/models/carbines/ligne-m3-bcae2be7.webp",
      "description": "Модель профиля «Армейский карабин». Внешний вид не меняет характеристики профиля."
    },
    "Stahlkar-8": {
      "profile": "Армейский карабин",
      "type": "Карабин",
      "icon": "/assets/items/models/carbines/stahlkar-8-7adc5009.webp",
      "description": "Модель профиля «Армейский карабин». Внешний вид не меняет характеристики профиля."
    },
    "Adlerauge-S": {
      "profile": "Армейский карабин",
      "type": "Карабин",
      "icon": "/assets/items/models/carbines/adlerauge-s-7fac48df.webp",
      "description": "Модель профиля «Армейский карабин». Внешний вид не меняет характеристики профиля."
    },
    "Банту Тип-32": {
      "profile": "Штурмовой карабин",
      "type": "Карабин",
      "icon": "/assets/items/models/carbines/32-58b98b55.webp",
      "description": "Модель профиля «Штурмовой карабин». Внешний вид не меняет характеристики профиля."
    },
    "Кагэцу Тип-7": {
      "profile": "Штурмовой карабин",
      "type": "Карабин",
      "icon": "/assets/items/models/carbines/7-a750fff5.webp",
      "description": "Модель профиля «Штурмовой карабин». Внешний вид не меняет характеристики профиля."
    },
    "Blitzsturm-kurz": {
      "profile": "Автоматический карабин",
      "type": "Карабин",
      "icon": "/assets/items/models/carbines/blitzsturm-kurz-1aef06c9.webp",
      "description": "Модель профиля «Автоматический карабин». Внешний вид не меняет характеристики профиля."
    },
    "Molot-B1": {
      "profile": "Автоматический карабин",
      "type": "Карабин",
      "icon": "/assets/items/models/carbines/molot-b1-07afb0e4.webp",
      "description": "Модель профиля «Автоматический карабин». Внешний вид не меняет характеристики профиля."
    },
    "Фэнчэн-L1": {
      "profile": "Точный карабин",
      "type": "Карабин",
      "icon": "/assets/items/models/carbines/l1-9eb0371b.webp",
      "description": "Модель профиля «Точный карабин». Внешний вид не меняет характеристики профиля."
    },
    "SR-42 Cacciatore": {
      "profile": "Точный карабин",
      "type": "Карабин",
      "icon": "/assets/items/models/carbines/sr-42-cacciatore-361379ed.webp",
      "description": "Модель профиля «Точный карабин». Внешний вид не меняет характеристики профиля."
    },
    "Fraternité": {
      "profile": "Охотничья винтовка",
      "type": "Снайперская винтовка",
      "icon": "/assets/items/models/sniper/fraternite-c2125ed4.webp",
      "description": "Модель профиля «Охотничья винтовка». Внешний вид не меняет характеристики профиля."
    },
    "Hirschlauf-3": {
      "profile": "Охотничья винтовка",
      "type": "Снайперская винтовка",
      "icon": "/assets/items/models/sniper/hirschlauf-3-aa772345.webp",
      "description": "Модель профиля «Охотничья винтовка». Внешний вид не меняет характеристики профиля."
    },
    "Ordonnance-5": {
      "profile": "Служебная винтовка",
      "type": "Снайперская винтовка",
      "icon": "/assets/items/models/sniper/ordonnance-5-c7477898.webp",
      "description": "Модель профиля «Служебная винтовка». Внешний вид не меняет характеристики профиля."
    },
    "Adlerauge-X": {
      "profile": "Снайперская винтовка",
      "type": "Снайперская винтовка",
      "icon": "/assets/items/models/sniper/adlerauge-x-9f14c7e3.webp",
      "description": "Модель профиля «Снайперская винтовка». Внешний вид не меняет характеристики профиля."
    },
    "Шэньхуо": {
      "profile": "Снайперская винтовка",
      "type": "Снайперская винтовка",
      "icon": "/assets/items/models/sniper/item-1ebe1f94.webp",
      "description": "Модель профиля «Снайперская винтовка». Внешний вид не меняет характеристики профиля."
    },
    "Palitsa-M2": {
      "profile": "Анаксионная винтовка",
      "type": "Снайперская винтовка",
      "icon": "/assets/items/models/sniper/palitsa-m2-6d3e1428.webp",
      "description": "Модель профиля «Анаксионная винтовка». Внешний вид не меняет характеристики профиля."
    },
    "Рюсан-C2": {
      "profile": "Анаксионная винтовка",
      "type": "Снайперская винтовка",
      "icon": "/assets/items/models/sniper/c2-382ec0ae.webp",
      "description": "Модель профиля «Анаксионная винтовка». Внешний вид не меняет характеристики профиля."
    },
    "Bâtard-9": {
      "profile": "Обрез",
      "type": "Дробовик",
      "icon": "/assets/items/models/shotguns/batard-9-53d1d2e0.webp",
      "description": "Модель профиля «Обрез». Внешний вид не меняет характеристики профиля."
    },
    "Лэймэнь-L2": {
      "profile": "Стандартный дробовик",
      "type": "Дробовик",
      "icon": "/assets/items/models/shotguns/l2-979cb2fb.webp",
      "description": "Модель профиля «Стандартный дробовик». Внешний вид не меняет характеристики профиля."
    },
    "M. Dural": {
      "profile": "Стандартный дробовик",
      "type": "Дробовик",
      "icon": "/assets/items/models/shotguns/m-dural-54092d68.webp",
      "description": "Модель профиля «Стандартный дробовик». Внешний вид не меняет характеристики профиля."
    },
    "Цзиньфэн": {
      "profile": "Стандартный дробовик",
      "type": "Дробовик",
      "icon": "/assets/items/models/shotguns/item-9b320384.webp",
      "description": "Модель профиля «Стандартный дробовик». Внешний вид не меняет характеристики профиля."
    },
    "Stahlhammer-11": {
      "profile": "Боевой дробовик",
      "type": "Дробовик",
      "icon": "/assets/items/models/shotguns/stahlhammer-11-629e8cff.webp",
      "description": "Модель профиля «Боевой дробовик». Внешний вид не меняет характеристики профиля."
    },
    "DS-15 Tempesta": {
      "profile": "Боевой дробовик",
      "type": "Дробовик",
      "icon": "/assets/items/models/shotguns/ds-15-tempesta-4a18f292.webp",
      "description": "Модель профиля «Боевой дробовик». Внешний вид не меняет характеристики профиля."
    },
    "Ками-Рэн": {
      "profile": "Боевой дробовик",
      "type": "Дробовик",
      "icon": "/assets/items/models/shotguns/item-ffed3962.webp",
      "description": "Модель профиля «Боевой дробовик». Внешний вид не меняет характеристики профиля."
    },
    "Zarya-D1": {
      "profile": "Боевой дробовик",
      "type": "Дробовик",
      "icon": "/assets/items/models/shotguns/zarya-d1-a82cb6b5.webp",
      "description": "Модель профиля «Боевой дробовик». Внешний вид не меняет характеристики профиля."
    },
    "Molot-R2": {
      "profile": "Боевой дробовик",
      "type": "Дробовик",
      "icon": "/assets/items/models/shotguns/molot-r2-596220fe.webp",
      "description": "Модель профиля «Боевой дробовик». Внешний вид не меняет характеристики профиля."
    },
    "Stahlhammer-11F": {
      "profile": "Огнемётный",
      "type": "Дробовик",
      "icon": "/assets/items/models/shotguns/stahlhammer-11f-d60533a8.webp",
      "description": "Модель профиля «Огнемётный». Внешний вид не меняет характеристики профиля."
    },
    "Éruption": {
      "profile": "Лёгкий гранатомёт",
      "type": "Тяжёлое",
      "icon": "/assets/items/models/heavy/eruption-a32932be.webp",
      "description": "Модель профиля «Лёгкий гранатомёт». Внешний вид не меняет характеристики профиля."
    },
    "Feuersturm": {
      "profile": "Лёгкий гранатомёт",
      "type": "Тяжёлое",
      "icon": "/assets/items/models/heavy/feuersturm-e8cf7982.webp",
      "description": "Модель профиля «Лёгкий гранатомёт». Внешний вид не меняет характеристики профиля."
    },
    "Festungsbrecher-T4": {
      "profile": "Тяжёлый гранатомёт",
      "type": "Тяжёлое",
      "icon": "/assets/items/models/heavy/festungsbrecher-t4-dfc83831.webp",
      "description": "Модель профиля «Тяжёлый гранатомёт». Внешний вид не меняет характеристики профиля."
    },
    "Гром-О2": {
      "profile": "Тяжёлый гранатомёт",
      "type": "Тяжёлое",
      "icon": "/assets/items/models/heavy/2-c4358715.webp",
      "description": "Модель профиля «Тяжёлый гранатомёт». Внешний вид не меняет характеристики профиля."
    },
    "Zvezda-T2": {
      "profile": "Тяжёлый гранатомёт",
      "type": "Тяжёлое",
      "icon": "/assets/items/models/heavy/zvezda-t2-411f65c4.webp",
      "description": "Модель профиля «Тяжёлый гранатомёт». Внешний вид не меняет характеристики профиля."
    },
    "Stahlregen-11": {
      "profile": "Тяжёлый пулемёт",
      "type": "Тяжёлое",
      "icon": "/assets/items/models/heavy/stahlregen-11-dd08ac0a.webp",
      "description": "Модель профиля «Тяжёлый пулемёт». Внешний вид не меняет характеристики профиля."
    },
    "Molot-MG2": {
      "profile": "Тяжёлый пулемёт",
      "type": "Тяжёлое",
      "icon": "/assets/items/models/heavy/molot-mg2-2b5c0eca.webp",
      "description": "Модель профиля «Тяжёлый пулемёт». Внешний вид не меняет характеристики профиля."
    },
    "Они-Баку": {
      "profile": "Анаксионный излучатель",
      "type": "Тяжёлое",
      "icon": "/assets/items/models/heavy/item-ce5809d6.webp",
      "description": "Модель профиля «Анаксионный излучатель». Внешний вид не меняет характеристики профиля."
    },
    "Stahlmantel": {
      "profile": "Скрытая броня",
      "type": "Лёгкая броня",
      "icon": "/assets/items/models/armor/stahlmantel-6a775452.webp",
      "description": "Модель профиля «Скрытая броня». Внешний вид не меняет характеристики профиля."
    },
    "Veste Défenseur": {
      "profile": "Скрытая броня",
      "type": "Лёгкая броня",
      "icon": "/assets/items/models/armor/veste-defenseur-9fc0d3b2.webp",
      "description": "Модель профиля «Скрытая броня». Внешний вид не меняет характеристики профиля."
    },
    "Цинцзя": {
      "profile": "Скрытая броня",
      "type": "Лёгкая броня",
      "icon": "/assets/items/models/armor/item-14fec03c.webp",
      "description": "Модель профиля «Скрытая броня». Внешний вид не меняет характеристики профиля."
    },
    "Буря-М": {
      "profile": "Полевой бронежилет",
      "type": "Лёгкая броня",
      "icon": "/assets/items/models/armor/item-cc756514.webp",
      "description": "Модель профиля «Полевой бронежилет». Внешний вид не меняет характеристики профиля."
    },
    "Gilet Guerrier": {
      "profile": "Армейский бронежилет",
      "type": "Средняя броня",
      "icon": "/assets/items/models/armor/gilet-guerrier-f05c5d39.webp",
      "description": "Модель профиля «Армейский бронежилет». Внешний вид не меняет характеристики профиля."
    },
    "Дуншань": {
      "profile": "Армейский бронежилет",
      "type": "Средняя броня",
      "icon": "/assets/items/models/armor/item-fc89dbd2.webp",
      "description": "Модель профиля «Армейский бронежилет». Внешний вид не меняет характеристики профиля."
    },
    "Kriegskorps": {
      "profile": "Противоосколочный бронекомплект",
      "type": "Средняя броня",
      "icon": "/assets/items/models/armor/kriegskorps-5a0ffd01.webp",
      "description": "Модель профиля «Противоосколочный бронекомплект». Внешний вид не меняет характеристики профиля."
    },
    "Титан-М": {
      "profile": "Усиленный бронекомплект",
      "type": "Средняя броня",
      "icon": "/assets/items/models/armor/item-d7ec5996.webp",
      "description": "Модель профиля «Усиленный бронекомплект». Внешний вид не меняет характеристики профиля."
    },
    "Berg M8": {
      "profile": "Стабилизирующая тяжёлая броня",
      "type": "Тяжёлая броня",
      "icon": "/assets/items/models/armor/berg-m8-b28d987e.webp",
      "description": "Модель профиля «Стабилизирующая тяжёлая броня». Внешний вид не меняет характеристики профиля."
    },
    "Armure Titanique": {
      "profile": "Анаксионно-изолированная броня",
      "type": "Тяжёлая броня",
      "icon": "/assets/items/models/armor/armure-titanique-03150859.webp",
      "description": "Модель профиля «Анаксионно-изолированная броня». Внешний вид не меняет характеристики профиля."
    },
    "Экзоскелет Т-1": {
      "profile": "Тяжёлый экзоскелет",
      "type": "Тяжёлая броня",
      "icon": "/assets/items/models/armor/1-d1482eb7.webp",
      "description": "Модель профиля «Тяжёлый экзоскелет». Внешний вид не меняет характеристики профиля."
    },
    "Шаньхэй": {
      "profile": "Адаптивный экзоскелет",
      "type": "Тяжёлая броня",
      "icon": "/assets/items/models/armor/item-78b5e8b8.webp",
      "description": "Модель профиля «Адаптивный экзоскелет». Внешний вид не меняет характеристики профиля."
    },
    "Складной нож": {
      "profile": "Малое оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-529f6003.webp",
      "description": "Модель профиля «Малое оружие». Внешний вид не меняет характеристики профиля."
    },
    "Кастет": {
      "profile": "Малое оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-c26efa20.webp",
      "description": "Модель профиля «Малое оружие». Внешний вид не меняет характеристики профиля."
    },
    "Сапожный нож": {
      "profile": "Малое оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-810e0ac4.webp",
      "description": "Модель профиля «Малое оружие». Внешний вид не меняет характеристики профиля."
    },
    "Короткий стилет": {
      "profile": "Малое оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-ec5a582c.webp",
      "description": "Модель профиля «Малое оружие». Внешний вид не меняет характеристики профиля."
    },
    "Траншейный нож": {
      "profile": "Лёгкое оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-bd93a4cc.webp",
      "description": "Модель профиля «Лёгкое оружие». Внешний вид не меняет характеристики профиля."
    },
    "Окопный штык": {
      "profile": "Лёгкое оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-75ec6fed.webp",
      "description": "Модель профиля «Лёгкое оружие». Внешний вид не меняет характеристики профиля."
    },
    "Короткая сабля": {
      "profile": "Лёгкое оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-013ad975.webp",
      "description": "Модель профиля «Лёгкое оружие». Внешний вид не меняет характеристики профиля."
    },
    "Клинок инспектора": {
      "profile": "Лёгкое оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-66729750.webp",
      "description": "Модель профиля «Лёгкое оружие». Внешний вид не меняет характеристики профиля."
    },
    "Мачете": {
      "profile": "Среднее оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-14a96eaa.webp",
      "description": "Модель профиля «Среднее оружие». Внешний вид не меняет характеристики профиля."
    },
    "Сапёрная лопатка": {
      "profile": "Среднее оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-08e24b7f.webp",
      "description": "Модель профиля «Среднее оружие». Внешний вид не меняет характеристики профиля."
    },
    "Короткое копьё": {
      "profile": "Среднее оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-3b2a64c9.webp",
      "description": "Модель профиля «Среднее оружие». Внешний вид не меняет характеристики профиля."
    },
    "Боевой топорик": {
      "profile": "Среднее оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-b1111c91.webp",
      "description": "Модель профиля «Среднее оружие». Внешний вид не меняет характеристики профиля."
    },
    "Кукри": {
      "profile": "Тяжёлое оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-cffa389a.webp",
      "description": "Модель профиля «Тяжёлое оружие». Внешний вид не меняет характеристики профиля."
    },
    "Офицерская сабля": {
      "profile": "Тяжёлое оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-4ac3bc3a.webp",
      "description": "Модель профиля «Тяжёлое оружие». Внешний вид не меняет характеристики профиля."
    },
    "Тяжёлый тесак": {
      "profile": "Тяжёлое оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-c1ba4fd3.webp",
      "description": "Модель профиля «Тяжёлое оружие». Внешний вид не меняет характеристики профиля."
    },
    "Боевой топор": {
      "profile": "Тяжёлое оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-3701a903.webp",
      "description": "Модель профиля «Тяжёлое оружие». Внешний вид не меняет характеристики профиля."
    },
    "Дубинка": {
      "profile": "Дробящее оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-745ba23e.webp",
      "description": "Модель профиля «Дробящее оружие». Внешний вид не меняет характеристики профиля."
    },
    "Молоток": {
      "profile": "Дробящее оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-50a5b19a.webp",
      "description": "Модель профиля «Дробящее оружие». Внешний вид не меняет характеристики профиля."
    },
    "Булава": {
      "profile": "Дробящее оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-4ff0eae9.webp",
      "description": "Модель профиля «Дробящее оружие». Внешний вид не меняет характеристики профиля."
    },
    "Полицейская палка": {
      "profile": "Дробящее оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-bcbff290.webp",
      "description": "Модель профиля «Дробящее оружие». Внешний вид не меняет характеристики профиля."
    },
    "Копьё": {
      "profile": "Древковое оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-5ac69491.webp",
      "description": "Модель профиля «Древковое оружие». Внешний вид не меняет характеристики профиля."
    },
    "Алебарда": {
      "profile": "Древковое оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-8c292b76.webp",
      "description": "Модель профиля «Древковое оружие». Внешний вид не меняет характеристики профиля."
    },
    "Длинный багор": {
      "profile": "Древковое оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-d16dbb6c.webp",
      "description": "Модель профиля «Древковое оружие». Внешний вид не меняет характеристики профиля."
    },
    "Кувалда": {
      "profile": "Тяжёлое двуручное оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-a7c45589.webp",
      "description": "Модель профиля «Тяжёлое двуручное оружие». Внешний вид не меняет характеристики профиля."
    },
    "Двуручный топор": {
      "profile": "Тяжёлое двуручное оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-7dcad2a0.webp",
      "description": "Модель профиля «Тяжёлое двуручное оружие». Внешний вид не меняет характеристики профиля."
    },
    "Тяжёлый меч": {
      "profile": "Тяжёлое двуручное оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-13110da4.webp",
      "description": "Модель профиля «Тяжёлое двуручное оружие». Внешний вид не меняет характеристики профиля."
    },
    "Промышленный лом": {
      "profile": "Тяжёлое двуручное оружие",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-77aa0f0c.webp",
      "description": "Модель профиля «Тяжёлое двуручное оружие». Внешний вид не меняет характеристики профиля."
    },
    "Шоковая дубинка": {
      "profile": "Анаксионное оружие ближнего боя",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-3eba6385.webp",
      "description": "Модель профиля «Анаксионное оружие ближнего боя». Внешний вид не меняет характеристики профиля."
    },
    "Разрядный кастет": {
      "profile": "Анаксионное оружие ближнего боя",
      "type": "Оружие ближнего боя",
      "icon": "/assets/items/models/melee/item-6a878365.webp",
      "description": "Модель профиля «Анаксионное оружие ближнего боя». Внешний вид не меняет характеристики профиля."
    }
  },
  "categoryPlaceholders": {
    "armor": "/assets/items/placeholders/armor.webp",
    "bows": "/assets/items/placeholders/bows.webp",
    "carbines": "/assets/items/placeholders/carbines.webp",
    "consumables": "/assets/items/placeholders/consumables.webp",
    "crossbows": "/assets/items/placeholders/crossbows.webp",
    "grenades": "/assets/items/placeholders/grenades.webp",
    "heavy": "/assets/items/placeholders/heavy.webp",
    "melee": "/assets/items/placeholders/melee.webp",
    "other": "/assets/items/placeholders/other.webp",
    "pistols": "/assets/items/placeholders/pistols.webp",
    "shotguns": "/assets/items/placeholders/shotguns.webp",
    "sniper": "/assets/items/placeholders/sniper.webp",
    "generic": "/assets/items/placeholders/generic.webp"
  }
};
  window.FATUM_ITEM_ART = data;
})();
