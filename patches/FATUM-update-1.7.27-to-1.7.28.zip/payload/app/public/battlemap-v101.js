'use strict';

(() => {
  const params = new URLSearchParams(location.search);
  const mode = params.get('mode') === 'master' ? 'master' : 'player';
  const master = mode === 'master';
  const clientId = localStorage.getItem('fatumLanClientId') || (() => {
    const id = crypto.randomUUID ? crypto.randomUUID() : `client_${Date.now()}_${Math.random().toString(16).slice(2)}`;
    localStorage.setItem('fatumLanClientId', id);
    return id;
  })();
  const requestedPlayerName = (params.get('playerName') || '').trim();
  const playerName = master ? 'Мастер' : (
    localStorage.getItem('fatumLanPlayerName') ||
    localStorage.getItem('fatumPlayerName') ||
    requestedPlayerName ||
    ''
  ).trim();
  if (!master && playerName) {
    // Keep both keys for compatibility with builds before and after v0.6.6.
    localStorage.setItem('fatumLanPlayerName', playerName);
    localStorage.setItem('fatumPlayerName', playerName);
  }
  if (!master && !playerName) {
    location.replace('/?mode=player');
    return;
  }
  document.body.classList.toggle('bm-player', !master);

  const $ = id => document.getElementById(id);
  const canvas = $('battle-canvas');
  const ctx = canvas.getContext('2d');
  const stage = $('stage');
  const imageCache = new Map();
  const resolvedImages = new Map();
  const renderAfterImage = new Set();

  const app = {
    campaign: null,
    campaignWorkspaces: [],
    activeCampaignId: null,
    battlemap: null,
    scene: null,
    tool: 'select',
    view: { x: 60, y: 60, scale: 0.75 },
    selected: null,
    hover: null,
    drag: null,
    draft: null,
    spaceDown: false,
    uploadedTokenImage: null,
    eventSource: null,
    renderPending: false,
    mapImage: null,
    mapImageUrl: null,
    lastAttack: null,
    attackLine: null,
    exploreTimer: null,
    unsentExplored: new Set(),
    lastMouseWorld: { x: 0, y: 0 },
    dimensions: { width: 0, height: 0, dpr: 1 },
    pendingCounter: null,
    wasdMovementFeet: 0,
    rollVisuals: new Map(),
    seenRollVisualIds: new Set(),
    speciesTarget: null,
    pendingTargetPart: null,
    projectileAnimations: new Map(),
    seenProjectileIds: new Set()
  };

  function esc(value) {
    return String(value ?? '').replace(/[&<>"']/g, ch => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;' }[ch]));
  }
  function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
  function v080RotationForMovement(dx, dy) {
    if (Math.hypot(dx, dy) < 0.001) return null;
    // Rotation 0 keeps the lower edge of a top-down image pointing down.
    // Therefore atan2(-dx, dy) turns that lower edge toward the movement vector.
    return ((Math.atan2(-dx, dy) * 180 / Math.PI) % 360 + 360) % 360;
  }
  function v080ApplyAutoRotation(token, from, to) {
    if (!token?.display?.autoRotateOnMove) return false;
    const rotation = v080RotationForMovement(Number(to.x)-Number(from.x), Number(to.y)-Number(from.y));
    if (rotation === null) return false;
    token.rotation = rotation;
    return true;
  }
  function id() { return crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}_${Math.random().toString(16).slice(2)}`; }
  function toast(message, kind = '') {
    const el = $('toast');
    el.textContent = message;
    el.className = `bm-toast ${kind} visible`;
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => { el.className = `bm-toast ${kind}`; }, 4200);
  }
  function setStatus(text, kind = '') {
    const el = $('connection-status');
    el.textContent = text;
    el.className = `bm-status ${kind}`;
  }

  function rollOutcomeLabel(roll) {
    const attack = roll?.battlemapAttack;
    if (attack) {
      if (attack.kind === 'melee-counter') return 'ВСТРЕЧНЫЙ УДАР';
      if (attack.kind === 'melee') return attack.hit ? 'ПОПАДАНИЕ' : attack.tie ? 'НИЧЬЯ' : 'ЗАЩИТНИК ПОБЕДИЛ';
      return attack.hit ? 'ПОПАДАНИЕ' : 'ПРОМАХ';
    }
    return ({
      'critical-success':'КРИТИЧЕСКИЙ УСПЕХ',
      'critical-failure':'КРИТИЧЕСКИЙ ПРОВАЛ',
      'success':'УСПЕХ',
      'edge':'УСПЕХ НА ГРАНИ',
      'failure':'ПРОВАЛ'
    })[roll?.outcome] || 'БРОСОК';
  }

  function rollVisualTone(roll) {
    const outcome = String(roll?.outcome || '');
    const attack = roll?.battlemapAttack;
    if (outcome === 'critical-success') return { accent:'#ffd86a', glow:'rgba(255,216,106,.72)', text:'#fff4c7' };
    if (outcome === 'critical-failure') return { accent:'#ff554d', glow:'rgba(255,62,55,.68)', text:'#ffd3cf' };
    if (outcome === 'edge') return { accent:'#e8b65f', glow:'rgba(232,182,95,.58)', text:'#ffe8b9' };
    if (outcome === 'failure' || (attack && !attack.hit)) return { accent:'#e85e5a', glow:'rgba(232,94,90,.55)', text:'#ffd6d3' };
    return { accent:'#70d7a2', glow:'rgba(112,215,162,.55)', text:'#d7ffeb' };
  }

  function rollTokenFor(roll) {
    if (!app.scene || !roll) return null;
    const attack = roll.battlemapAttack;
    const explicitTokenId = attack?.attackerTokenId || roll.tokenId || roll.battlemapTokenId || null;
    if (roll.sceneId && roll.sceneId !== app.scene.id) return null;
    if (attack?.sceneId && attack.sceneId !== app.scene.id) return null;
    if (explicitTokenId) {
      const direct = tokenById(explicitTokenId);
      if (direct) return direct;
    }
    if (roll.characterId) {
      const linked = (app.scene.tokens || []).find(token => token.kind === 'character' && token.refId === roll.characterId);
      if (linked) return linked;
    }
    const name = String(roll.characterName || attack?.attackerName || '').trim();
    return name ? (app.scene.tokens || []).find(token => token.name === name) || null : null;
  }

  function dieMaximum(value, fallback = 12) {
    const match = /(?:\d+)?[dк](\d+)/i.exec(String(value || ''));
    return match ? Math.max(2, Number(match[1]) || fallback) : fallback;
  }

  function stableRollNumber(seed, step, maximum) {
    let hash = 2166136261;
    const source = `${seed}:${step}`;
    for (let i = 0; i < source.length; i += 1) { hash ^= source.charCodeAt(i); hash = Math.imul(hash, 16777619); }
    hash ^= hash >>> 16;
    return 1 + ((hash >>> 0) % Math.max(1, maximum));
  }

  function startRollVisual(roll) {
    if (!roll?.id || roll?.battlemapAttack?.kind === 'melee-counter' || app.seenRollVisualIds.has(roll.id)) return;
    app.seenRollVisualIds.add(roll.id);
    if (app.seenRollVisualIds.size > 500) app.seenRollVisualIds = new Set([...app.seenRollVisualIds].slice(-350));
    const token = rollTokenFor(roll);
    if (!token) return;
    const attack = roll.battlemapAttack;
    const finalValue = Number(roll.kind === 'check' ? roll.successTotal : attack ? (attack.attackerTotal ?? attack.total ?? roll.total) : roll.total);
    if (!Number.isFinite(finalValue)) return;
    const secondaryValue = roll.kind === 'check' ? Number(roll.difficultyTotal) : attack?.kind === 'melee' ? Number(attack.defenderTotal) : attack ? Number(attack.targetMz) : null;
    const primaryBonus = Number(roll.kind === 'check' ? roll.successBonus : attack ? (attack.attackerBonus ?? attack.hitBonus ?? roll.modifier) : roll.modifier) || 0;
    const maximum = Math.max(4, finalValue, dieMaximum(roll.successDie || attack?.weapon?.hitDieNormal || roll.formula) + Math.max(0, primaryBonus));
    const previous = app.rollVisuals.get(token.id);
    const now = performance.now();
    app.rollVisuals.set(token.id, {
      id: roll.id, tokenId: token.id, finalValue, secondaryValue: Number.isFinite(secondaryValue) ? secondaryValue : null,
      maximum, secondaryMaximum: roll.kind === 'check' ? Math.max(4, Number(roll.difficultyTotal||0), dieMaximum(roll.difficultyDie || '1d8') + Math.max(0, Number(roll.difficultyModifier||0))) : null,
      successDie: roll.successDie || null, difficultyDie: roll.difficultyDie || null,
      label: rollOutcomeLabel(roll), tone: rollVisualTone(roll),
      startedAt: previous && now - previous.startedAt < 450 ? now + 180 : now,
      spinMs: 920, holdMs: 1450, fadeMs: 420, critical: String(roll.outcome || '').startsWith('critical-'),
      kind: attack ? (attack.kind === 'melee' ? 'melee' : 'attack') : roll.kind === 'check' ? 'check' : 'roll'
    });
    requestRender();
  }

  function roundedRectPath(target, x, y, width, height, radius) {
    const r = Math.min(radius, width / 2, height / 2);
    target.beginPath(); target.moveTo(x + r, y); target.lineTo(x + width - r, y); target.quadraticCurveTo(x + width, y, x + width, y + r);
    target.lineTo(x + width, y + height - r); target.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
    target.lineTo(x + r, y + height); target.quadraticCurveTo(x, y + height, x, y + height - r);
    target.lineTo(x, y + r); target.quadraticCurveTo(x, y, x + r, y); target.closePath();
  }

  function drawRollVisuals() {
    if (!app.scene || !app.rollVisuals.size) return;
    const now = performance.now(); let animate = false;
    ctx.save(); ctx.setTransform(app.dimensions.dpr, 0, 0, app.dimensions.dpr, 0, 0);
    for (const [tokenId, visual] of app.rollVisuals) {
      const token = tokenById(tokenId); if (!token) { app.rollVisuals.delete(tokenId); continue; }
      const elapsed = now - visual.startedAt; if (elapsed < 0) { animate = true; continue; }
      const totalMs = visual.spinMs + visual.holdMs + visual.fadeMs; if (elapsed >= totalMs) { app.rollVisuals.delete(tokenId); continue; }
      animate = true;
      const spinning = elapsed < visual.spinMs, holdElapsed = elapsed - visual.spinMs;
      const fade = holdElapsed > visual.holdMs ? 1 - (holdElapsed - visual.holdMs) / visual.fadeMs : 1;
      const settle = spinning ? clamp(elapsed / visual.spinMs, 0, 1) : 1;
      const step = Math.floor(elapsed / Math.max(38, 74 - settle * 28));
      const shown = spinning ? stableRollNumber(visual.id + ':success', step, visual.maximum) : visual.finalValue;
      const difficultyShown = visual.kind === 'check' && visual.secondaryValue !== null ? (spinning ? stableRollNumber(visual.id + ':difficulty', step + 3, visual.secondaryMaximum || 12) : visual.secondaryValue) : null;
      const tokenScreen = worldToScreen(visualTokenState(token)), tokenScreenRadius = tokenRadius(token) * app.view.scale;
      const pop = spinning ? 1 : 1 + Math.sin(Math.min(1, holdElapsed / 180) * Math.PI) * .15;
      const dual = visual.kind === 'check' && difficultyShown !== null, boxW = dual ? 184 : 128, boxH = dual ? 88 : 78;
      const x = clamp(tokenScreen.x - boxW / 2, 8, app.dimensions.width - boxW - 8), y = clamp(tokenScreen.y - tokenScreenRadius - boxH - 18, 58, app.dimensions.height - boxH - 8);
      ctx.globalAlpha = clamp(fade, 0, 1); ctx.save(); ctx.translate(x + boxW / 2, y + boxH / 2); ctx.scale(pop, pop); ctx.translate(-(x + boxW / 2), -(y + boxH / 2));
      ctx.shadowBlur = spinning ? 16 : visual.critical ? 28 : 18; ctx.shadowColor = visual.tone.glow;
      roundedRectPath(ctx, x, y, boxW, boxH, 13); ctx.fillStyle = 'rgba(9,12,17,.94)'; ctx.fill(); ctx.shadowBlur = 0; ctx.lineWidth = visual.critical ? 3 : 2; ctx.strokeStyle = visual.tone.accent; ctx.stroke();
      ctx.fillStyle = visual.tone.accent; ctx.fillRect(x + 10, y + 9, 4, boxH - 18); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      if (dual) {
        ctx.font = '700 9px Segoe UI, sans-serif'; ctx.fillStyle = 'rgba(222,235,245,.72)'; ctx.fillText('КУБ УСПЕХА', x + 58, y + 14); ctx.fillText('КУБ СЛОЖНОСТИ', x + 135, y + 14);
        ctx.font = `800 ${spinning ? 31 : 35}px Segoe UI, sans-serif`; ctx.fillStyle = '#ffffff'; ctx.fillText(String(shown), x + 58, y + 40); ctx.fillStyle = '#ffd6d3'; ctx.fillText(String(difficultyShown), x + 135, y + 40);
        ctx.font = '800 12px Segoe UI, sans-serif'; ctx.fillStyle = visual.tone.accent; ctx.fillText('VS', x + 96, y + 40);
        ctx.font = '700 10px Segoe UI, sans-serif'; ctx.fillStyle = visual.tone.text; ctx.fillText(spinning ? 'ПРОВЕРКА…' : visual.label, x + boxW / 2 + 3, y + 68);
        if (!spinning) { ctx.font = '600 9px Segoe UI, sans-serif'; ctx.fillStyle = 'rgba(228,235,244,.68)'; ctx.fillText(`${visual.successDie||''} против ${visual.difficultyDie||''}`.trim(), x + boxW / 2 + 3, y + 81); }
      } else {
        ctx.font = `800 ${spinning ? 36 : 40}px Segoe UI, sans-serif`; ctx.fillStyle = '#ffffff'; ctx.fillText(String(shown), x + boxW / 2 + 3, y + 31);
        ctx.font = '700 10px Segoe UI, sans-serif'; ctx.fillStyle = visual.tone.text; ctx.fillText(spinning ? 'БРОСОК…' : visual.label, x + boxW / 2 + 3, y + 57);
        if (!spinning && visual.secondaryValue !== null) { const prefix = visual.kind === 'melee' ? 'защита' : 'МЗ'; ctx.font = '600 9px Segoe UI, sans-serif'; ctx.fillStyle = 'rgba(228,235,244,.72)'; ctx.fillText(`${prefix} ${visual.secondaryValue}`, x + boxW / 2 + 3, y + 70); }
      }
      if (!spinning && visual.critical) { const pulse = 8 + Math.sin(holdElapsed / 80) * 3; ctx.beginPath(); ctx.arc(x + boxW - 13, y + 13, pulse, 0, Math.PI * 2); ctx.fillStyle = visual.tone.accent; ctx.globalAlpha *= .75; ctx.fill(); ctx.globalAlpha = clamp(fade, 0, 1); }
      ctx.restore();
    }
    ctx.restore(); if (animate) requestRender();
  }

  async function api(url, options = {}) {
    const opts = { credentials: 'same-origin', ...options };
    const method = String(opts.method || 'GET').toUpperCase();
    if (method !== 'GET' && method !== 'HEAD') {
      const suppliedHeaders = opts.headers && typeof opts.headers === 'object' ? opts.headers : {};
      opts.headers = { 'Content-Type': 'application/json', ...suppliedHeaders };
      if (opts.body && typeof opts.body !== 'string') opts.body = JSON.stringify(opts.body);
    }
    const response = await fetch(url, opts);
    let payload = null;
    try { payload = await response.json(); } catch { payload = {}; }
    if (!response.ok) {
      const error = new Error(payload?.error || `HTTP ${response.status}`);
      error.status = response.status;
      error.payload = payload;
      throw error;
    }
    return payload;
  }
  function commonBody(extra = {}) { return { clientId, playerName, ...extra }; }


  app.transientEffects = new Map();
  function addTransientEffect(sceneId, effect, ttlMs = 8000) {
    if (!sceneId || !effect?.id) return;
    const safeTtl = clamp(Number(ttlMs) || 8000, 500, 30000);
    app.transientEffects.set(effect.id, {
      sceneId,
      effect: { ...effect, expiresAt: null, remainingRounds: Math.max(1, Number(effect.remainingRounds || 1)) },
      expiresLocalAt: performance.now() + safeTtl
    });
    requestRender();
    window.setTimeout(() => {
      const current = app.transientEffects.get(effect.id);
      if (current && current.expiresLocalAt <= performance.now() + 25) app.transientEffects.delete(effect.id);
      requestRender();
    }, safeTtl + 50);
  }

  async function fetchAll(preserveSelection = false) {
    const qs = new URLSearchParams({ mode, clientId });
    const requests=[api(`/api/campaign?${qs}`),api(`/api/battlemap?${qs}`)];
    if(master) requests.push(api('/api/campaigns'));
    const [campaignPayload,mapPayload,campaignsPayload]=await Promise.all(requests);
    app.campaign = campaignPayload;
    if(campaignsPayload){app.campaignWorkspaces=campaignsPayload.campaigns||[];app.activeCampaignId=campaignsPayload.activeId||null;}
    applyBattlemap(mapPayload.battlemap, preserveSelection);
    refreshAllUi();
  }

  function applyBattlemap(battlemap, preserveSelection = true) {
    const selected = preserveSelection ? app.selected : null;
    app.battlemap = battlemap || { scenes: [], activeSceneId: null };
    const selectedSceneId = $('scene-select')?.value;
    const requested = master && selectedSceneId && app.battlemap.scenes.some(scene => scene.id === selectedSceneId)
      ? selectedSceneId
      : app.battlemap.activeSceneId;
    app.scene = app.battlemap.scenes.find(scene => scene.id === requested) || app.battlemap.scenes[0] || null;
    if (selected && selectionExists(selected)) app.selected = selected;
    else app.selected = null;
    loadMapImage();
    requestRender();
  }

  function selectionExists(selection) {
    if (!app.scene || !selection) return false;
    if (selection.type === 'token') return app.scene.tokens.some(item => item.id === selection.id);
    if (selection.type === 'wall') return app.scene.walls.some(item => item.id === selection.id);
    if (selection.type === 'light') return app.scene.lights.some(item => item.id === selection.id);
    return false;
  }

  function connectEvents() {
    if (app.eventSource) app.eventSource.close();
    const qs = new URLSearchParams({ mode, clientId, playerName, characterId: '' });
    const es = new EventSource(`/api/events?${qs}`);
    app.eventSource = es;
    es.addEventListener('hello', () => setStatus('Синхронизация активна', 'connected'));
    es.addEventListener('battlemap-log-entry', event => { try { const payload=JSON.parse(event.data); if(payload.entry) appendTableLogClient(payload.entry); } catch(error) { console.warn(error); } });
    const onBattlemap = event => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.battlemap) {
          applyBattlemap(payload.battlemap, true);
          refreshAllUi();
        }
      } catch (error) { console.warn(error); }
    };
    es.addEventListener('battlemap-replaced', onBattlemap);
    es.addEventListener('battlemap-token-updated', onBattlemap);
    es.addEventListener('battlemap-transient-effect', event => {
      try {
        const payload = JSON.parse(event.data);
        if (payload?.sceneId && payload?.effect) addTransientEffect(payload.sceneId, payload.effect, payload.ttlMs);
      } catch (error) { console.warn(error); }
    });
    es.addEventListener('battlemap-ping', event => {
      try { const payload=JSON.parse(event.data); if(payload?.ping) addMapPing(payload.ping); } catch(error) { console.warn(error); }
    });
    es.addEventListener('campaign-replaced', event => {
      try { const payload = JSON.parse(event.data); if (payload.campaign) { app.campaign = payload.campaign; refreshAllUi(); requestRender(); } } catch {}
    });
    es.addEventListener('character-updated', event => {
      try {
        const payload = JSON.parse(event.data);
        const character = payload.character;
        if (!character || !app.campaign) return;
        const index = app.campaign.characters.findIndex(item => item.id === character.id);
        if (index >= 0) app.campaign.characters[index] = character;
        else app.campaign.characters.push(character);
        refreshCombatUi(); refreshActionDock(); const linkedToken=app.scene?.tokens?.find(token=>token.refId===character.id); if(linkedToken&&app.miniTokenId===linkedToken.id) showMiniSheet(linkedToken); requestRender();
      } catch {}
    });
    es.addEventListener('dice-rolled', event => {
      try {
        const payload = JSON.parse(event.data);
        const roll = payload.roll;
        if (roll) startRollVisual(roll);
        const attack = roll?.battlemapAttack;
        if (attack) showAttackResult(attack, false);
      } catch {}
    });
    es.onerror = () => setStatus('Переподключение…', 'error');
  }

  function resizeCanvas() {
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.max(1, Math.round(rect.width));
    const height = Math.max(1, Math.round(rect.height));
    if (canvas.width !== Math.round(width * dpr) || canvas.height !== Math.round(height * dpr)) {
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
    }
    app.dimensions = { width, height, dpr };
    requestRender();
  }

  function worldToScreen(point) {
    return { x: app.view.x + point.x * app.view.scale, y: app.view.y + point.y * app.view.scale };
  }
  function screenToWorld(point) {
    return { x: (point.x - app.view.x) / app.view.scale, y: (point.y - app.view.y) / app.view.scale };
  }
  function eventPoint(event) {
    const rect = canvas.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  }
  function feetToPixels(feet) {
    if (!app.scene) return feet;
    return Number(feet || 0) / Math.max(.001, app.scene.grid.feet) * app.scene.grid.size;
  }
  function pixelsToFeet(px) {
    if (!app.scene) return px;
    return px / Math.max(1, app.scene.grid.size) * app.scene.grid.feet;
  }

  function loadImage(url) {
    if (!url) return Promise.resolve(null);
    if (resolvedImages.has(url)) return Promise.resolve(resolvedImages.get(url));
    if (imageCache.has(url)) return imageCache.get(url);
    const promise = new Promise(resolve => {
      const image = new Image();
      image.onload = () => { resolvedImages.set(url, image); resolve(image); };
      image.onerror = () => resolve(null);
      image.src = url;
    });
    imageCache.set(url, promise);
    return promise;
  }

  function requestRenderWhenImageReady(url) {
    if (!url || resolvedImages.has(url) || renderAfterImage.has(url)) return;
    renderAfterImage.add(url);
    loadImage(url).finally(() => { renderAfterImage.delete(url); requestRender(); });
  }
  async function loadMapImage() {
    const url = app.scene?.mapUrl || null;
    if (app.mapImageUrl === url) return;
    app.mapImageUrl = url;
    app.mapImage = await loadImage(url);
    requestRender();
  }

  function requestRender() {
    if (app.renderPending) return;
    app.renderPending = true;
    requestAnimationFrame(() => { app.renderPending = false; render(); });
  }

  function v101ActiveCombatToken(){
    if(!combatActive())return null;const initiative=app.campaign?.initiative||{},entry=initiative.entries?.[initiative.currentIndex||0];return tokenForInitiative(entry);
  }
  function drawCombatMovementRange(target){
    const token=v101ActiveCombatToken();if(!token||(!master&&!canControlToken(token)))return;
    const movement=movementForToken(token);if(!movement)return;
    const visual=visualTokenState(token),remaining=Math.max(0,Number(movement.remaining||0)),radius=feetToPixels(remaining),tokenR=tokenRadius(token);
    target.save();
    if(radius>0.5){
      target.beginPath();target.arc(visual.x,visual.y,radius,0,Math.PI*2);target.fillStyle='rgba(83,174,220,.10)';target.fill();target.strokeStyle='rgba(111,205,244,.95)';target.lineWidth=3/app.view.scale;target.setLineDash([10/app.view.scale,7/app.view.scale]);target.stroke();target.setLineDash([]);
      const baseStep=Math.max(.25,Number(app.scene?.grid?.feet||5)),ringCount=Math.floor(remaining/baseStep),step=ringCount<=12?baseStep:remaining/4;
      for(let feet=step;feet<remaining-.01;feet+=step){const ring=feetToPixels(feet);target.beginPath();target.arc(visual.x,visual.y,ring,0,Math.PI*2);target.strokeStyle='rgba(111,205,244,.24)';target.lineWidth=1/app.view.scale;target.stroke();}
    }else{
      target.beginPath();target.arc(visual.x,visual.y,tokenR+7/app.view.scale,0,Math.PI*2);target.strokeStyle='rgba(239,96,96,.9)';target.lineWidth=3/app.view.scale;target.setLineDash([5/app.view.scale,4/app.view.scale]);target.stroke();target.setLineDash([]);
    }
    const label=`Движение: ${remaining.toFixed(1)} фт`+(Number(movement.spent||0)>0?` · пройдено ${Number(movement.spent).toFixed(1)}`:'');target.font=`700 ${12/app.view.scale}px Segoe UI`;const w=target.measureText(label).width+14/app.view.scale,labelY=visual.y-(radius>0.5?radius:tokenR)-24/app.view.scale;target.fillStyle='rgba(8,15,21,.88)';target.fillRect(visual.x-w/2,labelY-9/app.view.scale,w,19/app.view.scale);target.fillStyle=remaining>0?'#bdeeff':'#ffaaaa';target.textAlign='center';target.textBaseline='middle';target.fillText(label,visual.x,labelY+.5/app.view.scale);target.restore();
  }

  function render() {
    const { width, height, dpr } = app.dimensions;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = '#0b0e12';
    ctx.fillRect(0, 0, width, height);
    if (!app.scene) return;

    ctx.save();
    ctx.translate(app.view.x, app.view.y);
    ctx.scale(app.view.scale, app.view.scale);
    drawMap(ctx);
    drawGrid(ctx);
    drawSceneLightsMarkers(ctx);
    drawWalls(ctx);
    drawTokens(ctx);
    drawDraft(ctx);
    drawAttackLine(ctx);
    ctx.restore();

    drawLightingAndFog();
  }

  function drawMap(target) {
    const scene = app.scene;
    target.fillStyle = scene.background || '#20242b';
    target.fillRect(0, 0, scene.mapWidth, scene.mapHeight);
    if (app.mapImage) target.drawImage(app.mapImage, 0, 0, scene.mapWidth, scene.mapHeight);
    target.strokeStyle = 'rgba(205,214,225,.35)';
    target.lineWidth = 2 / app.view.scale;
    target.strokeRect(0, 0, scene.mapWidth, scene.mapHeight);
  }

  function drawGrid(target) {
    const scene = app.scene;
    if (!scene.grid.enabled || (!master && scene.settings.showGridToPlayers === false)) return;
    const size = scene.grid.size;
    if (size * app.view.scale < 8) return;
    target.save();
    target.beginPath();
    const startX = ((scene.grid.offsetX % size) + size) % size;
    const startY = ((scene.grid.offsetY % size) + size) % size;
    for (let x = startX; x <= scene.mapWidth; x += size) { target.moveTo(x, 0); target.lineTo(x, scene.mapHeight); }
    for (let y = startY; y <= scene.mapHeight; y += size) { target.moveTo(0, y); target.lineTo(scene.mapWidth, y); }
    target.strokeStyle = hexToRgba(scene.grid.color || '#8aa0b8', scene.grid.opacity ?? .28);
    target.lineWidth = 1 / app.view.scale;
    target.stroke();
    target.restore();
  }

  function hexToRgba(hex, alpha = 1) {
    const value = String(hex || '#ffffff').replace('#', '');
    const number = Number.parseInt(value, 16);
    const r = (number >> 16) & 255, g = (number >> 8) & 255, b = number & 255;
    return `rgba(${r},${g},${b},${alpha})`;
  }

  function tokenRadius(token) { return app.scene.grid.size * token.size / 2; }
  function tokenImageUrl(token) {
    if(token?.kind==='character'){
      const st=characterById(token.refId)?.state||{},runtime=token.speciesRuntime||{};
      const species=st.species||runtime.species,pallid=st.pallid||runtime.pallid||{},werewolf=st.werewolf||runtime.werewolf||{};
      if(species==='pallid'&&pallid.transformed&&token.formImages?.pallid)return token.formImages.pallid;
      if(species==='werewolf'&&werewolf.transformed&&token.formImages?.werewolf)return token.formImages.werewolf;
    }
    if (token.imageUrl) return token.imageUrl;
    if (token.kind === 'character') return characterById(token.refId)?.portrait || null;
    return null;
  }

  function drawTokens(target) {
    const tokens = [...(app.scene.tokens || [])].filter(Boolean).sort((a, b) => (a.elevation || 0) - (b.elevation || 0));
    for (const token of tokens) drawToken(target, token);
  }

  function activeInitiativeToken(token) {
    const initiative = app.campaign?.initiative;
    const entry = initiative?.entries?.[initiative.currentIndex || 0];
    if (!entry) return false;
    return (entry.type === 'character' && token.kind === 'character' && entry.refId === token.refId) ||
      (entry.type === 'npc' && token.kind === 'npc' && entry.refId === token.refId);
  }

  function drawToken(target, token) {
    const radius = tokenRadius(token);
    const selected = app.selected?.type === 'token' && app.selected.id === token.id;
    const owned = canControlToken(token);
    const activeTurn = activeInitiativeToken(token);
    const url = tokenImageUrl(token);
    target.save();
    target.translate(token.x, token.y);
    target.rotate((token.rotation || 0) * Math.PI / 180);
    target.beginPath();
    target.arc(0, 0, radius, 0, Math.PI * 2);
    target.closePath();
    target.save(); target.clip();
    if (url) {
      const image = resolvedImages.get(url);
      if (image) target.drawImage(image, -radius, -radius, radius * 2, radius * 2);
      else {
        requestRenderWhenImageReady(url);
        target.fillStyle = token.kind === 'npc' ? '#713d3d' : '#39556d';
        target.fillRect(-radius, -radius, radius * 2, radius * 2);
      }
    } else {
      target.fillStyle = token.kind === 'npc' ? '#713d3d' : token.kind === 'character' ? '#39556d' : '#4b4e58';
      target.fillRect(-radius, -radius, radius * 2, radius * 2);
    }
    target.restore();
    target.lineWidth = (selected ? 5 : activeTurn ? 5 : owned ? 3 : 2) / app.view.scale;
    target.strokeStyle = selected ? '#ffd36a' : activeTurn ? '#73e08c' : token.defeated ? '#7b2828' : owned ? '#83b7e4' : '#d7d7d7';
    target.stroke();
    if (activeTurn) {
      target.beginPath(); target.arc(0, 0, radius + 7 / app.view.scale, 0, Math.PI * 2);
      target.strokeStyle = 'rgba(115,224,140,.75)'; target.lineWidth = 3 / app.view.scale; target.stroke();
    }
    if (token.hidden && master) {
      target.setLineDash([8 / app.view.scale, 5 / app.view.scale]);
      target.strokeStyle = '#e7a2dd'; target.lineWidth = 2 / app.view.scale; target.stroke();
    }
    target.setLineDash([]);
    target.beginPath(); target.moveTo(0, 0); target.lineTo(0, -radius * .88);
    target.strokeStyle = '#f8e6bc'; target.lineWidth = 2 / app.view.scale; target.stroke();
    target.restore();

    target.save();
    target.font = `${Math.max(12, 13 / app.view.scale)}px Segoe UI`;
    target.textAlign = 'center'; target.textBaseline = 'top';
    const labelY = token.y + radius + 7 / app.view.scale;
    const textWidth = target.measureText(token.name).width;
    target.fillStyle = 'rgba(10,12,16,.82)';
    target.fillRect(token.x - textWidth / 2 - 5 / app.view.scale, labelY - 2 / app.view.scale, textWidth + 10 / app.view.scale, 18 / app.view.scale);
    target.fillStyle = token.defeated ? '#d58b85' : '#f2eadc';
    target.fillText(token.name, token.x, labelY);
    target.restore();
  }


  function drawWalls(target) {
    if (!master) return;
    for (const wall of app.scene.walls) {
      const selected = app.selected?.type === 'wall' && app.selected.id === wall.id;
      target.save();
      target.beginPath(); target.moveTo(wall.x1, wall.y1); target.lineTo(wall.x2, wall.y2);
      target.lineWidth = (selected ? 7 : wall.door ? 5 : 4) / app.view.scale;
      target.strokeStyle = wall.door ? (wall.open ? '#58a877' : '#d59b4c') : wall.coverMz ? '#65a1c9' : '#c7554f';
      if (wall.open) target.setLineDash([10 / app.view.scale, 8 / app.view.scale]);
      target.stroke(); target.setLineDash([]);
      if (wall.coverMz) {
        const midX = (wall.x1 + wall.x2) / 2, midY = (wall.y1 + wall.y2) / 2;
        target.fillStyle = '#d7e7f4'; target.font = `${12 / app.view.scale}px Segoe UI`; target.fillText(`МЗ ${wall.coverMz}`, midX + 4, midY - 4);
      }
      target.restore();
    }
  }

  function drawSceneLightsMarkers(target) {
    if (!master) return;
    for (const light of app.scene.lights) {
      const selected = app.selected?.type === 'light' && app.selected.id === light.id;
      target.save(); target.translate(light.x, light.y);
      target.fillStyle = light.enabled ? light.color : '#555';
      target.strokeStyle = selected ? '#fff' : '#372713';
      target.lineWidth = (selected ? 4 : 2) / app.view.scale;
      target.beginPath(); target.arc(0, 0, 10 / app.view.scale, 0, Math.PI * 2); target.fill(); target.stroke();
      for (let i = 0; i < 8; i++) {
        const a = i * Math.PI / 4;
        target.beginPath(); target.moveTo(Math.cos(a) * 14 / app.view.scale, Math.sin(a) * 14 / app.view.scale); target.lineTo(Math.cos(a) * 20 / app.view.scale, Math.sin(a) * 20 / app.view.scale); target.stroke();
      }
      target.restore();
    }
  }

  function drawDraft(target) {
    if (!app.draft) return;
    if (['wall','door','measure'].includes(app.draft.type)) {
      target.save(); target.beginPath(); target.moveTo(app.draft.start.x, app.draft.start.y); target.lineTo(app.draft.current.x, app.draft.current.y);
      target.lineWidth = 3 / app.view.scale; target.strokeStyle = app.draft.type === 'measure' ? '#f1d56d' : app.draft.type === 'door' ? '#d59b4c' : '#e85e58'; target.setLineDash([8 / app.view.scale,5 / app.view.scale]); target.stroke();
      if (app.draft.type === 'measure') {
        const feet = pixelsToFeet(Math.hypot(app.draft.current.x - app.draft.start.x, app.draft.current.y - app.draft.start.y));
        target.setLineDash([]); target.fillStyle = '#fff2bd'; target.font = `${14 / app.view.scale}px Segoe UI`; target.fillText(`${feet.toFixed(1)} фт`, (app.draft.start.x + app.draft.current.x)/2, (app.draft.start.y + app.draft.current.y)/2);
      }
      target.restore();
    }
    if (['fog-reveal','fog-hide'].includes(app.draft.type)) {
      target.save(); target.fillStyle = app.draft.type === 'fog-reveal' ? 'rgba(110,190,120,.28)' : 'rgba(210,75,70,.28)';
      for (const point of app.draft.points) { target.beginPath(); target.arc(point.x, point.y, app.draft.radius, 0, Math.PI*2); target.fill(); }
      target.restore();
    }
  }

  function drawAttackLine(target) {
    const line = app.attackLine;
    if (!line || Date.now() > line.until) { app.attackLine = null; return; }
    const attacker = tokenById(line.attackerTokenId), targetToken = tokenById(line.targetTokenId);
    if (!attacker || !targetToken) return;
    target.save(); target.beginPath(); target.moveTo(attacker.x, attacker.y); target.lineTo(targetToken.x, targetToken.y);
    target.strokeStyle = line.hit ? '#8cff9b' : '#ff837a'; target.lineWidth = 4 / app.view.scale; target.setLineDash(line.hit ? [] : [12 / app.view.scale,8 / app.view.scale]); target.stroke(); target.restore();
    requestRender();
  }

  function raySegment(origin, angle, range, wall) {
    const dx = Math.cos(angle), dy = Math.sin(angle);
    const sx = wall.x2 - wall.x1, sy = wall.y2 - wall.y1;
    const denominator = dx * sy - dy * sx;
    if (Math.abs(denominator) < 1e-9) return null;
    const qx = wall.x1 - origin.x, qy = wall.y1 - origin.y;
    const t = (qx * sy - qy * sx) / denominator;
    const u = (qx * dy - qy * dx) / denominator;
    if (t >= 0 && t <= range && u >= 0 && u <= 1) return t;
    return null;
  }

  function normalizeAngle(angle) {
    let a = angle % (Math.PI * 2); if (a < -Math.PI) a += Math.PI * 2; if (a > Math.PI) a -= Math.PI * 2; return a;
  }
  function angleInside(angle, center, half) { return Math.abs(normalizeAngle(angle - center)) <= half + 1e-7; }

  function visibilityPolygon(source, rangePx, angleDeg = 360, rotationDeg = 0) {
    if (!app.scene || rangePx <= 0) return [];
    const blockingWalls = app.scene.walls.filter(wall => wall.blocksVision && !(wall.door && wall.open));
    const center = (rotationDeg - 90) * Math.PI / 180;
    const full = angleDeg >= 359.9;
    const half = angleDeg * Math.PI / 360;
    const angles = [];
    const samples = full ? 96 : Math.max(24, Math.ceil(angleDeg / 3));
    for (let i = 0; i <= samples; i++) {
      const angle = full ? -Math.PI + i / samples * Math.PI * 2 : center - half + i / samples * half * 2;
      angles.push(angle);
    }
    for (const wall of blockingWalls) {
      for (const endpoint of [{x:wall.x1,y:wall.y1},{x:wall.x2,y:wall.y2}]) {
        const a = Math.atan2(endpoint.y - source.y, endpoint.x - source.x);
        if (full || angleInside(a, center, half)) angles.push(a - 0.0001, a, a + 0.0001);
      }
    }
    const unique = [...new Set(angles.map(a => Math.round(a * 1000000) / 1000000))].filter(a => full || angleInside(a, center, half));
    unique.sort((a,b) => a-b);
    return unique.map(angle => {
      let distance = rangePx;
      for (const wall of blockingWalls) {
        const hit = raySegment(source, angle, rangePx, wall);
        if (hit !== null && hit < distance) distance = hit;
      }
      return { x: source.x + Math.cos(angle) * distance, y: source.y + Math.sin(angle) * distance };
    });
  }

  function viewerTokens() {
    if (!app.scene) return [];
    if (master) {
      if (!$('preview-player-vision')?.checked) return [];
      const selected = selectedToken();
      return selected ? [selected] : app.scene.tokens.filter(token => token.kind === 'character' && !token.hidden && !token.defeated);
    }
    return app.scene.tokens.filter(token => canControlToken(token) && !token.defeated && token.vision?.enabled !== false);
  }

  function currentVisionPolygons() {
    if (!app.scene?.settings.visionEnabled) return [];
    return viewerTokens().map(token => ({ token, polygon: visibilityPolygon(token, feetToPixels(token.vision?.range || 60), token.vision?.angle || 360, token.rotation || 0) })).filter(item => item.polygon.length >= 3);
  }

  function drawPolygonScreen(target, polygon) {
    if (!polygon.length) return;
    const first = worldToScreen(polygon[0]); target.moveTo(first.x, first.y);
    for (let i=1;i<polygon.length;i++) { const p=worldToScreen(polygon[i]); target.lineTo(p.x,p.y); }
    target.closePath();
  }

  function newOverlay() {
    const overlay = document.createElement('canvas'); overlay.width = app.dimensions.width; overlay.height = app.dimensions.height; return overlay;
  }

  function drawLightingAndFog() {
    const scene = app.scene;
    if (!scene) return;
    const { width, height, dpr } = app.dimensions;
    const masterFull = master && !$('preview-player-vision')?.checked;

    if (scene.settings.dynamicLightEnabled && !masterFull) {
      const dark = newOverlay(); const dc = dark.getContext('2d');
      if (!scene.settings.globalIllumination) {
        dc.fillStyle = `rgba(0,0,0,${scene.settings.ambientDarkness ?? .82})`; dc.fillRect(0,0,width,height);
        dc.globalCompositeOperation = 'destination-out';
        const sources = [];
        for (const light of scene.lights) if (light.enabled) sources.push({ ...light, sourceType:'static' });
        for (const token of scene.tokens) if (token.light?.enabled && (!token.hidden || master || canControlToken(token))) sources.push({ x:token.x,y:token.y,rotation:token.rotation,...token.light, sourceType:'token' });
        for (const source of sources) drawLightCutout(dc, source);
        for (const token of viewerTokens()) {
          const darkRange = feetToPixels(token.vision?.darkvision || 0);
          if (darkRange > 0) drawLightCutout(dc, { x:token.x,y:token.y,rotation:token.rotation,bright:token.vision.darkvision,dim:token.vision.darkvision,angle:token.vision.angle,color:'#c6d7ff',intensity:.75 });
        }
        dc.globalCompositeOperation = 'source-over';
      }
      ctx.setTransform(dpr,0,0,dpr,0,0); ctx.drawImage(dark,0,0);
    }

    const fogMode = scene.settings.fogEnabled === false ? 'off' : scene.settings.fogMode;
    if (fogMode !== 'off' && !masterFull) {
      const fog = newOverlay(); const fc = fog.getContext('2d');
      // Ручной туман может начинаться как полностью скрытая или полностью открытая карта.
      const startsHidden = scene.fog?.baseHidden !== false || fogMode === 'vision' || fogMode === 'hybrid';
      if (startsHidden) { fc.fillStyle = 'rgba(0,0,0,.965)'; fc.fillRect(0,0,width,height); }
      const current = currentVisionPolygons();
      const explored = new Set(scene.fog.explored?.[clientId] || []);
      if (scene.settings.exploredMemory && explored.size && (fogMode === 'vision' || fogMode === 'hybrid')) {
        fc.globalCompositeOperation = 'destination-out';
        fc.globalAlpha = .42;
        const cell = scene.fog.cellSize || scene.grid.size;
        for (const key of explored) {
          const [gx,gy] = key.split(':').map(Number);
          const a = worldToScreen({x:gx*cell,y:gy*cell});
          fc.fillRect(a.x,a.y,cell*app.view.scale+1,cell*app.view.scale+1);
        }
        fc.globalAlpha = 1;
      }
      if (fogMode === 'manual' || fogMode === 'hybrid') applyManualFog(fc, scene.fog.ops || [], 'reveal');
      if (fogMode === 'vision' || fogMode === 'hybrid') {
        fc.globalCompositeOperation = 'destination-out';
        for (const item of current) { fc.beginPath(); drawPolygonScreen(fc,item.polygon); fc.fillStyle='#000'; fc.fill(); }
      }
      if (fogMode === 'manual' || fogMode === 'hybrid') applyManualFog(fc, scene.fog.ops || [], 'hide');
      fc.globalCompositeOperation = 'source-over';
      ctx.setTransform(dpr,0,0,dpr,0,0); ctx.drawImage(fog,0,0);
      scheduleExplored(current);
    }
  }

  function drawLightCutout(target, source) {
    const dimPx = feetToPixels(source.dim || source.bright || 0);
    const brightPx = feetToPixels(Math.min(source.bright || 0, source.dim || source.bright || 0));
    if (dimPx <= 0) return;
    const polygon = visibilityPolygon(source, dimPx, source.angle || 360, source.rotation || 0);
    if (polygon.length < 3) return;
    const screen = worldToScreen(source); const dimScreen = dimPx * app.view.scale; const brightScreen = brightPx * app.view.scale;
    target.save(); target.beginPath(); drawPolygonScreen(target, polygon); target.clip();
    const gradient = target.createRadialGradient(screen.x,screen.y,Math.max(0,brightScreen*.8),screen.x,screen.y,Math.max(1,dimScreen));
    const intensity = clamp(Number(source.intensity || 1), .05, 2);
    gradient.addColorStop(0,`rgba(0,0,0,${Math.min(1,intensity)})`);
    gradient.addColorStop(Math.min(.95, brightScreen/Math.max(1,dimScreen)),`rgba(0,0,0,${Math.min(1,intensity)})`);
    gradient.addColorStop(1,'rgba(0,0,0,0)');
    target.fillStyle=gradient; target.fillRect(screen.x-dimScreen,screen.y-dimScreen,dimScreen*2,dimScreen*2); target.restore();
  }

  function applyManualFog(target, ops, modeWanted) {
    target.globalCompositeOperation = modeWanted === 'reveal' ? 'destination-out' : 'source-over';
    target.fillStyle = modeWanted === 'reveal' ? '#000' : 'rgba(0,0,0,.98)';
    for (const op of ops) {
      if (op.mode !== modeWanted) continue;
      if (op.shape === 'rect') {
        const a=worldToScreen({x:op.x,y:op.y}); target.fillRect(a.x,a.y,op.width*app.view.scale,op.height*app.view.scale);
      } else if (op.shape === 'circle') {
        const a=worldToScreen({x:op.x,y:op.y}); target.beginPath(); target.arc(a.x,a.y,op.radius*app.view.scale,0,Math.PI*2); target.fill();
      } else {
        for (const point of op.points || []) { const a=worldToScreen(point); target.beginPath(); target.arc(a.x,a.y,op.radius*app.view.scale,0,Math.PI*2); target.fill(); }
      }
    }
  }

  function pointInPolygon(point, polygon) {
    let inside=false;
    for (let i=0,j=polygon.length-1;i<polygon.length;j=i++) {
      const xi=polygon[i].x, yi=polygon[i].y, xj=polygon[j].x, yj=polygon[j].y;
      const intersect=((yi>point.y)!=(yj>point.y)) && (point.x < (xj-xi)*(point.y-yi)/(yj-yi+1e-12)+xi);
      if (intersect) inside=!inside;
    }
    return inside;
  }

  function scheduleExplored(current) {
    if (master || !app.scene?.settings.exploredMemory || !current.length) return;
    const cell = app.scene.fog.cellSize || app.scene.grid.size;
    const existing = new Set(app.scene.fog.explored?.[clientId] || []);
    for (const item of current) {
      const xs=item.polygon.map(p=>p.x), ys=item.polygon.map(p=>p.y);
      const minX=Math.floor(Math.min(...xs)/cell), maxX=Math.ceil(Math.max(...xs)/cell);
      const minY=Math.floor(Math.min(...ys)/cell), maxY=Math.ceil(Math.max(...ys)/cell);
      for(let gx=minX;gx<=maxX;gx++) for(let gy=minY;gy<=maxY;gy++) {
        const key=`${gx}:${gy}`;
        if (!existing.has(key) && pointInPolygon({x:(gx+.5)*cell,y:(gy+.5)*cell},item.polygon)) app.unsentExplored.add(key);
      }
    }
    if (app.unsentExplored.size && !app.exploreTimer) app.exploreTimer=setTimeout(flushExplored,1000);
  }

  async function flushExplored() {
    app.exploreTimer=null;
    if (!app.scene || !app.unsentExplored.size) return;
    const cells=[...app.unsentExplored].slice(0,3000); cells.forEach(cell=>app.unsentExplored.delete(cell));
    try {
      await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/explored`, { method:'PUT', body:commonBody({cells}) });
      app.scene.fog.explored ||= {}; app.scene.fog.explored[clientId]=[...new Set([...(app.scene.fog.explored[clientId]||[]),...cells])];
    } catch (error) { console.warn(error); }
    if (app.unsentExplored.size) app.exploreTimer=setTimeout(flushExplored,1000);
  }

  function canControlToken(token) {
    // A player may not receive the current initiative token when it is hidden,
    // outside vision, or belongs to a scene-filtered entry. Treat that as an
    // uncontrollable token instead of crashing while reading token.kind.
    if (!token || typeof token !== 'object') return false;
    if (master) return true;
    const character = token.kind === 'character' ? characterById(token.refId) : null;
    return token.ownerId === clientId || character?.ownerId === clientId;
  }
  function tokenById(tokenId) { return app.scene?.tokens.find(item=>item.id===tokenId)||null; }
  function wallById(wallId) { return app.scene?.walls.find(item=>item.id===wallId)||null; }
  function lightById(lightId) { return app.scene?.lights.find(item=>item.id===lightId)||null; }
  function selectedToken() { return app.selected?.type==='token' ? tokenById(app.selected.id) : null; }
  function characterById(characterId) {
    return app.campaign?.characters?.find(item=>item.id===characterId) || app.campaign?.sharedCharacters?.find(item=>item.id===characterId) || null;
  }
  function npcById(npcId) { return app.campaign?.npcs?.find(item=>item.id===npcId)||null; }

  function hitTestToken(point) {
    const tokens=[...(app.scene?.tokens||[])].reverse();
    return tokens.find(token=>Math.hypot(point.x-token.x,point.y-token.y)<=tokenRadius(token))||null;
  }
  function pointSegmentDistance(p,a,b) {
    const dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy;
    if(!l2)return Math.hypot(p.x-a.x,p.y-a.y);
    let t=((p.x-a.x)*dx+(p.y-a.y)*dy)/l2;t=clamp(t,0,1);
    return Math.hypot(p.x-(a.x+t*dx),p.y-(a.y+t*dy));
  }
  function hitTestWall(point) {
    if(!master)return null;
    return (app.scene?.walls||[]).find(wall=>pointSegmentDistance(point,{x:wall.x1,y:wall.y1},{x:wall.x2,y:wall.y2})<=8/app.view.scale)||null;
  }
  function hitTestLight(point) {
    if(!master)return null;
    return (app.scene?.lights||[]).find(light=>Math.hypot(point.x-light.x,point.y-light.y)<=16/app.view.scale)||null;
  }

  function setTool(tool) {
    app.tool=tool; app.draft=null;
    document.querySelectorAll('.bm-tool').forEach(button=>button.classList.toggle('active',button.dataset.tool===tool));
    stage.className=`bm-stage tool-${tool}`;
    const help={select:'ЛКМ — выбрать или переместить токен · колесо — масштаб · пробел + ЛКМ — камера',pan:'Тяните карту ЛКМ',measure:'Протяните линию между двумя точками',wall:'Протяните новую стену',door:'Протяните новую закрытую дверь',light:'Щёлкните место нового источника света','fog-reveal':'Рисуйте области, которые должны стать видимыми','fog-hide':'Рисуйте области, которые снова нужно скрыть',attack:'Выберите атакующего, затем щёлкните цель'};
    $('tool-help').textContent=help[tool]||''; requestRender();
  }

  function selectObject(type, objectId) {
    app.selected=type&&objectId?{type,id:objectId}:null;
    refreshInspector(); refreshTokenList(); refreshCombatUi(); requestRender();
  }

  function snapPoint(point) {
    const grid=app.scene.grid;
    if(!grid.snap)return point;
    const size=grid.size;
    return {
      x: Math.round((point.x-grid.offsetX-size/2)/size)*size+grid.offsetX+size/2,
      y: Math.round((point.y-grid.offsetY-size/2)/size)*size+grid.offsetY+size/2
    };
  }

  function onPointerDown(event) {
    if(!app.scene||event.button!==0)return;
    canvas.setPointerCapture?.(event.pointerId);
    const screen=eventPoint(event),world=screenToWorld(screen); app.lastMouseWorld=world;
    const pan=app.tool==='pan'||app.spaceDown;
    if(pan){app.drag={type:'pan',start:screen,view:{...app.view}};stage.classList.add('is-panning');event.preventDefault();return;}
    if(app.tool==='select'){
      const token=hitTestToken(world);
      if(token){selectObject('token',token.id);if(canControlToken(token)&&!token.locked){app.drag={type:'token',tokenId:token.id,start:world,origin:{x:token.x,y:token.y},lastValid:{x:token.x,y:token.y}};}return;}
      const light=hitTestLight(world);if(light){selectObject('light',light.id);return;}
      const wall=hitTestWall(world);if(wall){selectObject('wall',wall.id);return;}
      selectObject(null,null);return;
    }
    if(['measure','wall','door'].includes(app.tool)){app.draft={type:app.tool,start:world,current:world};requestRender();return;}
    if(['fog-reveal','fog-hide'].includes(app.tool)){app.draft={type:app.tool,radius:Math.max(12,Number(promptRadius.value||80)),points:[world]};requestRender();return;}
    if(app.tool==='light'&&master){addLightAt(world);return;}
    if(app.tool==='attack'){
      const token=hitTestToken(world);if(!token)return;
      const attackerId=$('attack-attacker').value;
      if(!attackerId){if(canControlToken(token)){ $('attack-attacker').value=token.id; refreshAttackWeapons(); toast(`Атакующий: ${token.name}`); }else toast('Сначала выберите свой токен.','error');}
      else if(token.id!==attackerId){$('attack-target').value=token.id;refreshAttackPreview();openPanel('combat');}
    }
  }
  const promptRadius={value:80};

  function onPointerMove(event) {
    if(!app.scene)return;
    const screen=eventPoint(event),world=screenToWorld(screen);app.lastMouseWorld=world;
    $('coordinates').textContent=`x ${world.x.toFixed(0)} · y ${world.y.toFixed(0)} · ${pixelsToFeet(Math.hypot(world.x,world.y)).toFixed(1)} фт от начала`;
    if(app.drag?.type==='pan'){
      app.view.x=app.drag.view.x+(screen.x-app.drag.start.x);app.view.y=app.drag.view.y+(screen.y-app.drag.start.y);requestRender();return;
    }
    if(app.drag?.type==='token'){
      const token=tokenById(app.drag.tokenId);if(!token)return;
      let next={x:app.drag.origin.x+(world.x-app.drag.start.x),y:app.drag.origin.y+(world.y-app.drag.start.y)};
      next=snapPoint(next);token.x=clamp(next.x,0,app.scene.mapWidth);token.y=clamp(next.y,0,app.scene.mapHeight);requestRender();return;
    }
    if(app.draft&&['measure','wall','door'].includes(app.draft.type)){app.draft.current=world;requestRender();return;}
    if(app.draft&&['fog-reveal','fog-hide'].includes(app.draft.type)){
      const last=app.draft.points[app.draft.points.length-1];if(Math.hypot(world.x-last.x,world.y-last.y)>app.draft.radius*.3){app.draft.points.push(world);requestRender();}
    }
  }

  async function onPointerUp() {
    stage.classList.remove('is-panning');
    if(app.drag?.type==='token'){
      const token=tokenById(app.drag.tokenId);app.drag=null;
      if(token){try{await updateToken(token,{x:token.x,y:token.y,rotation:token.rotation});}catch(error){toast(error.message,'error');await refreshBattlemap();}}
      return;
    }
    app.drag=null;
    if(!app.draft)return;
    const draft=app.draft;app.draft=null;
    if(draft.type==='measure'){requestRender();return;}
    if(['wall','door'].includes(draft.type)&&master){
      if(Math.hypot(draft.current.x-draft.start.x,draft.current.y-draft.start.y)<4)return;
      const wall={id:`wall_${id()}`,x1:draft.start.x,y1:draft.start.y,x2:draft.current.x,y2:draft.current.y,blocksVision:$('new-wall-blocks-vision').checked,blocksMovement:$('new-wall-blocks-movement').checked,door:draft.type==='door',open:false,coverMz:Number($('new-wall-cover-mz').value||0),coverDurability:Number($('new-wall-durability').value||0),coverDamage:0,coverName:''};
      app.scene.walls.push(wall);requestRender();try{await saveWalls();selectObject('wall',wall.id);}catch(error){toast(error.message,'error');await refreshBattlemap();}return;
    }
    if(['fog-reveal','fog-hide'].includes(draft.type)&&master){
      const op={id:`fog_${id()}`,mode:draft.type==='fog-hide'?'hide':'reveal',shape:'brush',radius:draft.radius,points:draft.points};app.scene.fog.ops.push(op);requestRender();try{await saveFog();}catch(error){toast(error.message,'error');await refreshBattlemap();}
    }
  }

  function onWheel(event) {
    event.preventDefault();
    const point=eventPoint(event);const before=screenToWorld(point);const factor=Math.exp(-event.deltaY*.0012);app.view.scale=clamp(app.view.scale*factor,.08,4);app.view.x=point.x-before.x*app.view.scale;app.view.y=point.y-before.y*app.view.scale;$('scale-readout').textContent=`${Math.round(app.view.scale*100)}%`;requestRender();
  }

  async function updateToken(token, patch) {
    return api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/tokens/${encodeURIComponent(token.id)}`,{method:'PUT',body:commonBody(patch)});
  }
  async function saveWalls(){await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/walls`,{method:'PUT',body:commonBody({walls:app.scene.walls})});}
  async function saveLights(){await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/lights`,{method:'PUT',body:commonBody({lights:app.scene.lights})});}
  async function saveFog(){await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/fog`,{method:'PUT',body:commonBody({fog:{baseHidden:app.scene.fog.baseHidden,ops:app.scene.fog.ops,cellSize:app.scene.fog.cellSize}})});}

  async function addLightAt(point){
    const light={id:`light_${id()}`,name:'Источник света',x:point.x,y:point.y,rotation:0,enabled:true,bright:20,dim:40,angle:360,color:'#ffd88a',intensity:1,hidden:false};app.scene.lights.push(light);requestRender();try{await saveLights();selectObject('light',light.id);}catch(error){toast(error.message,'error');await refreshBattlemap();}
  }

  function centerView(){if(!app.scene)return;app.view.scale=1;app.view.x=app.dimensions.width/2-app.scene.mapWidth/2;app.view.y=app.dimensions.height/2-app.scene.mapHeight/2;$('scale-readout').textContent='100%';requestRender();}
  function fitView(){if(!app.scene)return;const margin=40;app.view.scale=clamp(Math.min((app.dimensions.width-margin*2)/app.scene.mapWidth,(app.dimensions.height-margin*2)/app.scene.mapHeight),.05,2);app.view.x=(app.dimensions.width-app.scene.mapWidth*app.view.scale)/2;app.view.y=(app.dimensions.height-app.scene.mapHeight*app.view.scale)/2;$('scale-readout').textContent=`${Math.round(app.view.scale*100)}%`;requestRender();}
  function focusToken(token){if(!token)return;app.view.x=app.dimensions.width/2-token.x*app.view.scale;app.view.y=app.dimensions.height/2-token.y*app.view.scale;requestRender();}

  async function uploadImage(file,kind){
    if(!file)throw new Error('Файл не выбран.');
    const dataUrl=await readFileDataUrl(file);return api('/api/battlemap/assets',{method:'POST',body:commonBody({kind,dataUrl,name:file.name})});
  }
  function readFileDataUrl(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(reader.error||new Error('Не удалось прочитать файл.'));reader.readAsDataURL(file);});}
  function imageDimensions(dataUrl){return new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>resolve({width:image.naturalWidth,height:image.naturalHeight});image.onerror=()=>reject(new Error('Не удалось открыть изображение.'));image.src=dataUrl;});}

  async function createScene(name,file){
    let mapUrl=null,width=1920,height=1080;
    if(file){const dataUrl=await readFileDataUrl(file);const dims=await imageDimensions(dataUrl);const uploaded=await api('/api/battlemap/assets',{method:'POST',body:commonBody({kind:'map',dataUrl,name:file.name})});mapUrl=uploaded.url;width=dims.width;height=dims.height;}
    const result=await api('/api/battlemap/scenes',{method:'POST',body:commonBody({name,mapUrl,mapWidth:width,mapHeight:height})});
    await api('/api/battlemap/active',{method:'PUT',body:commonBody({sceneId:result.scene.id})});
    app.forceSceneId=result.scene.id;
    await refreshBattlemap();fitView();toast('Сцена создана.','success');
  }

  async function refreshBattlemap(){const qs=new URLSearchParams({mode,clientId});const payload=await api(`/api/battlemap?${qs}`);applyBattlemap(payload.battlemap,true);refreshAllUi();}

  function refreshAllUi(){
    refreshSceneSelect();refreshSceneForm();refreshTokenSource();refreshTokenList();refreshInspector();refreshCombatUi();refreshEmpty();refreshPlayerVisionWarning();requestRender();
  }
  function refreshPlayerVisionWarning(){
    const box=$('player-vision-warning');
    if(!box)return;
    if(master||!app.scene){box.hidden=true;return;}
    const fogMode=app.scene.settings?.fogEnabled===false?'off':app.scene.settings?.fogMode;
    const needsViewer=(fogMode==='vision'||fogMode==='hybrid'||Boolean(app.scene.settings?.dynamicLightEnabled));
    box.hidden=!(needsViewer&&viewerTokens().length===0);
  }
  function refreshEmpty(){const empty=!app.scene;$('empty-state').hidden=!empty;if(empty)$('empty-text').textContent=master?'Создайте сцену и загрузите карту.':'Мастер ещё не открыл боевую карту.';}
  function refreshSceneSelect(){const select=$('scene-select');const previous=app.scene?.id||'';select.innerHTML=(app.battlemap?.scenes||[]).map(scene=>`<option value="${esc(scene.id)}" ${scene.id===previous?'selected':''}>${esc(scene.name)}${scene.id===app.battlemap.activeSceneId?' · активна':''}</option>`).join('');select.disabled=!master&&select.options.length<=1;}
  function refreshSceneForm(){const s=app.scene;if(!s)return;$('scene-name').value=s.name;$('scene-width').value=s.mapWidth;$('scene-height').value=s.mapHeight;$('grid-enabled').checked=s.grid.enabled;$('grid-snap').checked=s.grid.snap;$('grid-size').value=s.grid.size;$('grid-feet').value=s.grid.feet;$('grid-offset-x').value=s.grid.offsetX;$('grid-offset-y').value=s.grid.offsetY;$('fog-mode').value=s.settings.fogMode;$('vision-enabled').checked=s.settings.visionEnabled;$('dynamic-light-enabled').checked=s.settings.dynamicLightEnabled;$('global-illumination').checked=s.settings.globalIllumination;$('ambient-darkness').value=s.settings.ambientDarkness;if($('elevation-rules-enabled'))$('elevation-rules-enabled').checked=s.settings.elevationRulesEnabled!==false;}

  function refreshTokenSource(){
    const kind=$('token-source-kind').value;const ref=$('token-ref');$('token-ref-wrap').hidden=kind==='generic';$('generic-name-wrap').hidden=kind!=='generic';
    if(kind==='character')ref.innerHTML=(app.campaign?.characters||[]).map(c=>`<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('');
    else if(kind==='npc')ref.innerHTML=(app.campaign?.npcs||[]).map(n=>`<option value="${esc(n.id)}">${esc(n.name)}</option>`).join('');
  }
  function refreshTokenList(){const box=$('token-list');if(!app.scene){box.innerHTML='';return;}box.innerHTML=(app.scene.tokens||[]).filter(Boolean).map(token=>{const url=tokenImageUrl(token);return `<div class="bm-token-row ${app.selected?.type==='token'&&app.selected.id===token.id?'active':''}" data-token-id="${esc(token.id)}"><div class="bm-token-thumb">${url?`<img src="${esc(url)}" class="bm-token-thumb">`:esc(token.name.slice(0,2).toUpperCase())}</div><div>${esc(token.name)}<small>${token.kind==='character'?'Персонаж':token.kind==='npc'?'NPC':'Объект'}${token.hidden?' · скрыт':''}</small></div><button class="bm-btn" data-focus-token="${esc(token.id)}">◎</button></div>`;}).join('')||'<p class="bm-muted">На сцене пока нет токенов.</p>';}

  function refreshInspector(){
    ['no-selection-card','token-inspector','wall-inspector','light-inspector'].forEach(id=>$(id).hidden=true);
    if(!app.selected){$('no-selection-card').hidden=false;return;}
    if(app.selected.type==='token'){
      const t=selectedToken();if(!t){$('no-selection-card').hidden=false;return;}$('token-inspector').hidden=false;
      $('token-name').value=t.name;$('token-x').value=Math.round(t.x);$('token-y').value=Math.round(t.y);$('token-size').value=t.size;$('token-rotation').value=Math.round(t.rotation||0);$('token-mz').value=t.mzOverride??'';$('token-cover-bonus').value=t.coverBonus||0;$('token-hidden').checked=t.hidden;$('token-locked').checked=t.locked;$('token-defeated').checked=t.defeated;$('token-vision-enabled').checked=t.vision?.enabled!==false;$('token-vision-range').value=t.vision?.range||60;$('token-vision-angle').value=t.vision?.angle||360;$('token-light-enabled').checked=Boolean(t.light?.enabled);$('token-light-bright').value=t.light?.bright||20;$('token-light-dim').value=t.light?.dim||40;$('token-light-angle').value=t.light?.angle||360;$('token-light-color').value=t.light?.color||'#ffd88a';
      document.querySelector('.bm-player-token-actions').hidden=master||!canControlToken(t);return;
    }
    if(app.selected.type==='wall'){
      const w=wallById(app.selected.id);if(!w){$('no-selection-card').hidden=false;return;}$('wall-inspector').hidden=false;$('wall-inspector-title').textContent=w.door?'Дверь':'Стена / укрытие';$('wall-blocks-vision').checked=w.blocksVision;$('wall-blocks-movement').checked=w.blocksMovement;$('wall-is-door').checked=w.door;$('wall-open').checked=w.open;$('wall-cover-mz').value=w.coverMz||0;$('wall-durability').value=w.coverDurability||0;$('wall-damage').value=w.coverDamage||0;$('wall-cover-name').value=w.coverName||'';$('toggle-door-btn').disabled=!w.door;return;
    }
    if(app.selected.type==='light'){
      const l=lightById(app.selected.id);if(!l){$('no-selection-card').hidden=false;return;}$('light-inspector').hidden=false;$('static-light-name').value=l.name;$('static-light-enabled').checked=l.enabled;$('static-light-bright').value=l.bright;$('static-light-dim').value=l.dim;$('static-light-angle').value=l.angle;$('static-light-rotation').value=l.rotation;$('static-light-color').value=l.color;$('static-light-intensity').value=l.intensity;return;
    }
  }

  function openPanel(panel){document.querySelectorAll('.bm-sidebar-tabs button').forEach(b=>b.classList.toggle('active',b.dataset.panel===panel));document.querySelectorAll('.bm-panel').forEach(b=>b.classList.toggle('active',b.dataset.panelBody===panel));$('sidebar').classList.remove('collapsed');}

  function clientWeapons(token){
    if(!token)return[];
    if(Array.isArray(token.weapons)&&token.weapons.length)return token.weapons.map(weapon=>({...weapon}));
    if(token.kind==='character'){
      const c=characterById(token.refId);const st=c?.state||{};if(Array.isArray(st._lanBattleProfile?.weapons))return st._lanBattleProfile.weapons;
      return fallbackClientWeapons(st);
    }
    if(token.kind==='npc'){
      const npc=npcById(token.refId),w=npc?.weapon||{};let bonus=Number(w.manualBonus||0);if(w.bonusMode==='rank')bonus=Number(w.rankBonus||0);if(w.bonusMode==='formula')bonus=Number(w.proficiency||0)+Math.floor(Number(w.accuracy||0)/2)-Number(w.threshold||0);return[{id:'npc-weapon',name:w.name||'Оружие',profile:w.profile||w.name||'Оружие',type:w.melee?'Оружие ближнего боя':'NPC',melee:Boolean(w.melee),hitDieNormal:w.hitDie||'1d6',hitDieAimed:'',hitBonus:bonus,damage:Number(w.damage||2),damageTag:w.damageTag||'medium',odCost:Number(w.odCost||2),obCost:0,range:Number(w.range||100),ignoreMz:Number(w.ignoreMz||0),description:w.description||''}];
    }
    return[];
  }
  function fallbackClientWeapons(st){
    const inventory=Array.isArray(st.inventory)?st.inventory:[];const acc=Number(st._lanRollProfile?.skills?.['Меткость']?.bonus||st.skills?.['Меткость']?.bonus||0);return['weapon1','weapon2'].map(slot=>{const name=st.equipment?.[slot];if(!name)return null;const item=inventory.find(i=>i.name===name)||{name,type:'',desc:''};const desc=String(item.desc||item.description||'').replace(/к/g,'d');const pair=desc.match(/Попадание:\s*(1d(?:4|6|8|10|12))[^/]*\/\s*(1d(?:4|6|8|10|12))/i);const single=desc.match(/(?:Попадание[:\s]*)?(1d(?:4|6|8|10|12))/i);const hitDieNormal=pair?.[1]||single?.[1]||'1d6',hitDieAimed=pair?.[2]||'';const threshold=Number(desc.match(/порог\s*(\d+)/i)?.[1]||0);const type=item.type||'';const cat={'Пистолет':'Пистолеты','Карабин':'Карабины','Снайперская винтовка':'Винтовки','Дробовик':'Дробовики','Тяжёлое':'Тяжёлое'}[type];const prof=Number(st.weaponProficiencies?.[cat]||0);const melee=type==='Оружие ближнего боя';const hitBonus=melee?Math.max(Number(st._lanRollProfile?.skills?.['Акробатика']?.bonus||0),Number(st._lanRollProfile?.skills?.['Физическая сила']?.bonus||0)):prof+Math.floor(acc/2)-threshold;const ranges=[...desc.matchAll(/(\d+)\s*фт/gi)].map(m=>Number(m[1]));return{id:slot,slot,name:item.customModel||item.selectedModel||item.name,profile:item.profile||item.name,type,melee,hitDieNormal,hitDieAimed,hitBonus,damage:Number(desc.match(/урон\s*(\d+)/i)?.[1]||1),damageTag:item.damageTag||'medium',odCost:Number(desc.match(/(\d+)\s*ОД/i)?.[1]||2),obCost:/требует\s*1\s*ОБ/i.test(desc)?1:0,range:ranges.length?Math.max(...ranges):5,ignoreMz:0,description:item.desc||''};}).filter(Boolean);
  }

  function refreshCombatUi(){
    if(!app.scene)return;const controllable=app.scene.tokens.filter(canControlToken);const attacker=$('attack-attacker'),target=$('attack-target');const oldA=attacker.value,oldT=target.value;attacker.innerHTML='<option value="">— выберите —</option>'+controllable.map(t=>`<option value="${esc(t.id)}">${esc(t.name)}</option>`).join('');target.innerHTML='<option value="">— выберите —</option>'+app.scene.tokens.map(t=>`<option value="${esc(t.id)}">${esc(t.name)}</option>`).join('');if(controllable.some(t=>t.id===oldA))attacker.value=oldA;if(app.scene.tokens.some(t=>t.id===oldT))target.value=oldT;const selected=selectedToken();if(selected&&canControlToken(selected)&&!attacker.value)attacker.value=selected.id;refreshAttackWeapons();refreshAttackPreview();
  }
  function refreshAttackWeapons(){const token=tokenById($('attack-attacker').value);const weapons=clientWeapons(token);const select=$('attack-weapon'),old=select.value;select.innerHTML=weapons.map(w=>`<option value="${esc(w.id||w.slot||w.name)}">${esc(w.name)} · ${esc(w.hitDieNormal)} ${Number(w.hitBonus)>=0?'+':''}${Number(w.hitBonus||0)} · урон ${Number(w.damage||0)}</option>`).join('');if(weapons.some(w=>(w.id||w.slot||w.name)===old))select.value=old;$('attack-shot-mode').disabled=!weapons.find(w=>(w.id||w.slot||w.name)===select.value)?.hitDieAimed;refreshAttackPreview();}
  function tokenAutoMz(token){if(!token)return 0;if(token.mzOverride!==null&&token.mzOverride!==undefined)return token.mzOverride;const c=token.kind==='character'?characterById(token.refId):null,a=Number(c?.state?._lanRollProfile?.skills?.['Акробатика']?.bonus||c?.state?.skills?.['Акробатика']?.bonus||0);if(c?.state?.species==='werewolf'&&c.state.werewolf?.transformed)return 4+a+2;if(c?.state?.mz!==undefined)return Number(c.state.mz);if(c)return 4+a;const npc=token.kind==='npc'?npcById(token.refId):null;return npc?4+Number(npc.characteristics?.dexterity||0):4;}
  function refreshAttackPreview(){
    const a=tokenById($('attack-attacker').value),t=tokenById($('attack-target').value);if(!a||!t){$('attack-preview').textContent='Выберите атакующего и цель.';return;}const dist=pixelsToFeet(Math.hypot(a.x-t.x,a.y-t.y));const weapons=clientWeapons(a),w=weapons.find(x=>(x.id||x.slot||x.name)===$('attack-weapon').value)||weapons[0];const mz=$('attack-target-mz').value||tokenAutoMz(t);$('attack-preview').innerHTML=`<strong>${esc(a.name)} → ${esc(t.name)}</strong><br>Дистанция: ${dist.toFixed(1)} фт · МЗ: ${esc(mz)}${w?`<br>${esc(w.name)}: ${esc(w.hitDieNormal)} ${Number(w.hitBonus)>=0?'+':''}${Number(w.hitBonus||0)} · дальность ${Number(w.range||0)} фт · урон ${Number(w.damage||0)}`:''}`;
  }

  async function rollAttack(){
    const attackerTokenId=$('attack-attacker').value,targetTokenId=$('attack-target').value,weaponId=$('attack-weapon').value;if(!attackerTokenId||!targetTokenId||!weaponId){toast('Выберите атакующего, цель и оружие.','error');return;}const button=$('attack-roll-btn');button.disabled=true;
    try{const result=await api('/api/battlemap/attack',{method:'POST',body:commonBody({requestId:id(),sceneId:app.scene.id,attackerTokenId,targetTokenId,weaponId,shotMode:$('attack-shot-mode').value,situationalModifier:Number($('attack-modifier').value||0),targetMz:$('attack-target-mz').value===''?null:Number($('attack-target-mz').value),moved:$('attack-moved').checked,spendResources:$('attack-spend').checked,visibility:$('attack-private').checked?'master':'public'})});if(result.roll)startRollVisual(result.roll);showAttackResult(result.attack,true);}
    catch(error){toast(error.message,'error');}finally{button.disabled=false;}
  }
  function showAttackResult(attack,own){app.lastAttack=attack;app.attackLine={attackerTokenId:attack.attackerTokenId,targetTokenId:attack.targetTokenId,hit:attack.hit,until:Date.now()+1800};$('attack-result-card').hidden=false;$('attack-result').innerHTML=`<div class="${attack.hit?'bm-result-hit':'bm-result-miss'}">${attack.hit?'ПОПАДАНИЕ':attack.missRedirectTargetName?`ПРОМАХ ПО ЦЕЛИ · ПОПАДАНИЕ В ${esc(attack.missRedirectTargetName)}`:'ПРОМАХ'} · ${attack.total} против МЗ ${attack.targetMz}</div><div class="bm-result-grid"><div>Куб<br><strong>${esc(attack.hitDie)}: ${attack.roll}</strong></div><div>Бонус<br><strong>${Number(attack.hitBonus)>=0?'+':''}${attack.hitBonus}</strong></div><div>Дистанция<br><strong>${attack.distance} фт</strong></div><div>Урон<br><strong>${attack.damage} (${esc(attack.damageTag)})</strong></div><div>Базовая МЗ<br><strong>${attack.baseMz}</strong></div><div>Укрытие<br><strong>${attack.coverMz?`${attack.coverMz}${attack.coverSource?.name?` · ${esc(attack.coverSource.name)}`:''}`:'нет'}</strong></div></div>${attack.conditionalReasons?.length?`<p class="bm-muted">${attack.conditionalReasons.map(esc).join('<br>')}</p>`:''}`;const actions=$('attack-damage-actions');const hasDamageTarget=Boolean(attack.damageTargetTokenId||attack.hit);actions.innerHTML=hasDamageTarget?`<button class="bm-btn bm-primary" data-apply-damage="${attack.damage}">Применить урон ${attack.damage}${attack.missRedirectTargetName?` к ${esc(attack.missRedirectTargetName)}`:''}</button><button class="bm-btn" data-apply-damage="${attack.damage}" data-bleeding="1">Урон + кровотечение</button>`:'';if(own)toast(attack.hit?'Атака попала.':attack.missRedirectTargetName?`Промах по цели: попадание в ${attack.missRedirectTargetName}.`:'Атака промахнулась.',attack.hit||attack.missRedirectTargetName?'success':'error');requestRender();}
  async function applyLastDamage(damage,bleeding){if(!app.lastAttack)return;try{const flags=app.lastAttack.flags||{};const result=await api('/api/battlemap/apply-damage',{method:'POST',body:commonBody({sceneId:app.lastAttack.sceneId,targetTokenId:app.lastAttack.damageTargetTokenId||app.lastAttack.targetTokenId,damage:Number(damage),damageTag:app.lastAttack.damageTag,bleeding:Boolean(bleeding),...flags})});const armor=result.armor;if(result.blocked)toast('Блок полностью отменил урон ближнего боя.','success');else toast(`Ранения применены${armor?.used?` · БЗ ${armor.beforeBz}→${armor.afterBz}`:''}.`,'success');}catch(error){toast(error.message,'error');}}

  function bindUi(){
    window.addEventListener('resize',resizeCanvas);
    if('ResizeObserver' in window){app.stageResizeObserver=new ResizeObserver(()=>resizeCanvas());app.stageResizeObserver.observe(stage);}
    $('sidebar')?.addEventListener('transitionend',event=>{if(event.propertyName==='width'||event.propertyName==='flex-basis')resizeCanvas();});
    canvas.addEventListener('pointerdown',onPointerDown);canvas.addEventListener('pointermove',onPointerMove);canvas.addEventListener('pointerup',onPointerUp);canvas.addEventListener('pointercancel',onPointerUp);canvas.addEventListener('wheel',onWheel,{passive:false});canvas.addEventListener('contextmenu',e=>e.preventDefault());
    window.addEventListener('keydown',e=>{if(e.code==='Space'&&!isFormTarget(e.target)){app.spaceDown=true;e.preventDefault();}if(e.key==='Escape'){if(!$('scene-modal').hidden){$('scene-modal').hidden=true;$('new-scene-file').value='';}app.draft=null;setTool('select');}});window.addEventListener('keyup',e=>{if(e.code==='Space')app.spaceDown=false;});
    document.querySelectorAll('.bm-tool').forEach(b=>b.addEventListener('click',()=>setTool(b.dataset.tool)));
    document.querySelectorAll('.bm-sidebar-tabs button').forEach(b=>b.addEventListener('click',()=>openPanel(b.dataset.panel)));
    $('toggle-sidebar-btn').onclick=()=>{const sidebar=$('sidebar');sidebar.classList.toggle('collapsed');resizeCanvas();requestAnimationFrame(resizeCanvas);setTimeout(resizeCanvas,230);};$('sheets-btn').onclick=()=>location.href=`/?mode=${mode}`;$('fit-btn').onclick=fitView;$('center-btn').onclick=centerView;
    const openSceneModal=()=>{$('scene-modal').hidden=false;requestAnimationFrame(()=>$('new-scene-name').focus());};
    const closeSceneModal=()=>{$('scene-modal').hidden=true;$('new-scene-file').value='';};
    $('new-scene-btn').onclick=$('empty-create-btn').onclick=openSceneModal;
    $('cancel-scene-btn').onclick=closeSceneModal;
    $('scene-modal').addEventListener('pointerdown',e=>{if(e.target===$('scene-modal'))closeSceneModal();});
    $('scene-form').onsubmit=async e=>{e.preventDefault();const button=e.submitter||$('scene-form').querySelector('[type="submit"]');button.disabled=true;try{await createScene($('new-scene-name').value,$('new-scene-file').files[0]);closeSceneModal();}catch(error){toast(error.message,'error');}finally{button.disabled=false;}};
    $('scene-select').onchange=async()=>{const sceneId=$('scene-select').value;if(master){await api('/api/battlemap/active',{method:'PUT',body:commonBody({sceneId})});await refreshBattlemap();}else{app.scene=app.battlemap.scenes.find(s=>s.id===sceneId)||app.scene;refreshAllUi();}fitView();};
    $('upload-map-btn').onclick=()=>$('map-file-input').click();$('map-file-input').onchange=async e=>{const file=e.target.files[0];if(!file||!app.scene)return;try{const dataUrl=await readFileDataUrl(file),dims=await imageDimensions(dataUrl),up=await api('/api/battlemap/assets',{method:'POST',body:commonBody({kind:'map',dataUrl,name:file.name})});await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}`,{method:'PUT',body:commonBody({mapUrl:up.url,mapWidth:dims.width,mapHeight:dims.height})});await refreshBattlemap();fitView();toast('Карта загружена.','success');}catch(error){toast(error.message,'error');}finally{e.target.value='';}};
    $('save-scene-btn').onclick=async()=>{try{await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}`,{method:'PUT',body:commonBody({name:$('scene-name').value,mapWidth:Number($('scene-width').value),mapHeight:Number($('scene-height').value)})});toast('Сцена сохранена.','success');}catch(error){toast(error.message,'error');}};
    $('delete-scene-btn').onclick=async()=>{if(!app.scene||!confirm(`Удалить сцену «${app.scene.name}»?`))return;try{await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}`,{method:'DELETE',body:commonBody()});await refreshBattlemap();toast('Сцена удалена.','success');}catch(error){toast(error.message,'error');}};
    $('save-grid-btn').onclick=async()=>{try{await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}`,{method:'PUT',body:commonBody({grid:{enabled:$('grid-enabled').checked,snap:$('grid-snap').checked,size:Number($('grid-size').value),feet:Number($('grid-feet').value),offsetX:Number($('grid-offset-x').value),offsetY:Number($('grid-offset-y').value)}})});toast('Сетка сохранена.','success');}catch(error){toast(error.message,'error');}};
    $('save-vision-btn').onclick=async()=>{try{await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}`,{method:'PUT',body:commonBody({settings:{fogMode:$('fog-mode').value,fogEnabled:$('fog-mode').value!=='off',visionEnabled:$('vision-enabled').checked,dynamicLightEnabled:$('dynamic-light-enabled').checked,globalIllumination:$('global-illumination').checked,ambientDarkness:Number($('ambient-darkness').value)}})});toast('Настройки зрения сохранены.','success');}catch(error){toast(error.message,'error');}};
    $('preview-player-vision').onchange=requestRender;$('ambient-darkness').oninput=requestRender;
    $('clear-fog-btn').onclick=async()=>{if(!confirm('Удалить все ручные области тумана?'))return;app.scene.fog.ops=[];await saveFog();requestRender();};$('reveal-all-btn').onclick=async()=>{app.scene.fog.baseHidden=false;app.scene.fog.ops=[];await saveFog();requestRender();};$('hide-all-btn').onclick=async()=>{app.scene.fog.baseHidden=true;app.scene.fog.ops=[];await saveFog();requestRender();};
    $('token-source-kind').onchange=refreshTokenSource;$('upload-token-image-btn').onclick=()=>$('token-image-input').click();$('token-image-input').onchange=async e=>{const file=e.target.files[0];if(!file)return;try{const up=await uploadImage(file,'token');app.uploadedTokenImage=up.url;$('uploaded-token-image-label').textContent=`Загружено: ${file.name}`;toast('Изображение токена загружено.','success');}catch(error){toast(error.message,'error');}finally{e.target.value='';}};
    $('add-token-btn').onclick=addToken;
    $('token-list').onclick=e=>{const focus=e.target.closest('[data-focus-token]');if(focus){e.stopPropagation();focusToken(tokenById(focus.dataset.focusToken));return;}const row=e.target.closest('[data-token-id]');if(row){selectObject('token',row.dataset.tokenId);focusToken(tokenById(row.dataset.tokenId));}};
    $('save-token-btn').onclick=saveSelectedToken;$('delete-token-btn').onclick=deleteSelectedToken;$('center-token-btn').onclick=()=>focusToken(selectedToken());$('rotate-token-left').onclick=()=>rotateSelected(-45);$('rotate-token-right').onclick=()=>rotateSelected(45);
    $('save-wall-btn').onclick=saveSelectedWall;$('delete-wall-btn').onclick=deleteSelectedWall;$('toggle-door-btn').onclick=toggleSelectedDoor;
    $('save-light-btn').onclick=saveSelectedLight;$('delete-light-btn').onclick=deleteSelectedLight;
    ['attack-attacker','attack-target','attack-weapon','attack-shot-mode','attack-modifier','attack-target-mz','attack-moved'].forEach(id=>$(id).addEventListener('change',id==='attack-attacker'?refreshAttackWeapons:refreshAttackPreview));$('attack-roll-btn').onclick=rollAttack;$('attack-damage-actions').onclick=e=>{const b=e.target.closest('[data-apply-damage]');if(b)applyLastDamage(b.dataset.applyDamage,b.dataset.bleeding==='1');};
  }
  function isFormTarget(target){return target&&['INPUT','TEXTAREA','SELECT','BUTTON'].includes(target.tagName);}

  async function addToken(){if(!app.scene)return;const kind=$('token-source-kind').value,refId=kind==='generic'?null:$('token-ref').value;let name=kind==='generic'?($('generic-token-name').value||'Новый токен'):kind==='character'?characterById(refId)?.name:npcById(refId)?.name;const center=screenToWorld({x:app.dimensions.width/2,y:app.dimensions.height/2});try{const result=await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/tokens`,{method:'POST',body:commonBody({kind,refId,name,imageUrl:app.uploadedTokenImage,x:center.x,y:center.y,size:Number($('new-token-size').value||1),vision:{enabled:kind==='character',range:60,angle:360},light:{enabled:false,bright:20,dim:40,angle:360,color:'#ffd88a'}})});if(result.token&&!app.scene.tokens.some(token=>token.id===result.token.id))app.scene.tokens.push(result.token);app.uploadedTokenImage=null;$('uploaded-token-image-label').textContent='';selectObject('token',result.token.id);refreshTokenList();requestRender();toast(`Добавлен токен «${result.token.name}».`,'success');}catch(error){toast(error.message,'error');}}
  async function saveSelectedToken(){const t=selectedToken();if(!t)return;try{await updateToken(t,{name:$('token-name').value,x:Number($('token-x').value),y:Number($('token-y').value),size:Number($('token-size').value),rotation:Number($('token-rotation').value),mzOverride:$('token-mz').value===''?null:Number($('token-mz').value),coverBonus:Number($('token-cover-bonus').value||0),elevation:Number($('token-elevation')?.value||0),hidden:$('token-hidden').checked,locked:$('token-locked').checked,defeated:$('token-defeated').checked,vision:{enabled:$('token-vision-enabled').checked,range:Number($('token-vision-range').value),angle:Number($('token-vision-angle').value)},light:{enabled:$('token-light-enabled').checked,bright:Number($('token-light-bright').value),dim:Number($('token-light-dim').value),angle:Number($('token-light-angle').value),color:$('token-light-color').value}});toast('Токен сохранён.','success');}catch(error){toast(error.message,'error');}}
  async function deleteSelectedToken(){const t=selectedToken();if(!t||!confirm(`Удалить токен «${t.name}»?`))return;try{await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/tokens/${encodeURIComponent(t.id)}`,{method:'DELETE',body:commonBody()});selectObject(null,null);toast('Токен удалён.','success');}catch(error){toast(error.message,'error');}}
  async function rotateSelected(delta){const t=selectedToken();if(!t||!canControlToken(t))return;t.rotation=(Number(t.rotation||0)+delta+360)%360;requestRender();try{await updateToken(t,{rotation:t.rotation});}catch(error){toast(error.message,'error');}}
  async function saveSelectedWall(){const w=wallById(app.selected?.id);if(!w)return;Object.assign(w,{blocksVision:$('wall-blocks-vision').checked,blocksMovement:$('wall-blocks-movement').checked,door:$('wall-is-door').checked,open:$('wall-open').checked,coverMz:Number($('wall-cover-mz').value||0),coverDurability:Number($('wall-durability').value||0),coverDamage:Number($('wall-damage').value||0),coverName:$('wall-cover-name').value});try{await saveWalls();toast('Стена сохранена.','success');requestRender();}catch(error){toast(error.message,'error');}}
  async function deleteSelectedWall(){const w=wallById(app.selected?.id);if(!w||!confirm('Удалить выбранную стену?'))return;app.scene.walls=app.scene.walls.filter(x=>x.id!==w.id);selectObject(null,null);try{await saveWalls();toast('Стена удалена.','success');}catch(error){toast(error.message,'error');}}
  async function toggleSelectedDoor(){const w=wallById(app.selected?.id);if(!w?.door)return;try{const r=await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/walls/${encodeURIComponent(w.id)}/toggle`,{method:'POST',body:commonBody()});w.open=r.wall.open;refreshInspector();requestRender();}catch(error){toast(error.message,'error');}}
  async function saveSelectedLight(){const l=lightById(app.selected?.id);if(!l)return;Object.assign(l,{name:$('static-light-name').value,enabled:$('static-light-enabled').checked,bright:Number($('static-light-bright').value),dim:Number($('static-light-dim').value),angle:Number($('static-light-angle').value),rotation:Number($('static-light-rotation').value),color:$('static-light-color').value,intensity:Number($('static-light-intensity').value)});try{await saveLights();toast('Источник света сохранён.','success');requestRender();}catch(error){toast(error.message,'error');}}
  async function deleteSelectedLight(){const l=lightById(app.selected?.id);if(!l||!confirm('Удалить источник света?'))return;app.scene.lights=app.scene.lights.filter(x=>x.id!==l.id);selectObject(null,null);try{await saveLights();toast('Источник удалён.','success');}catch(error){toast(error.message,'error');}}


  /* ===== FATUM Battlemap v0.5.3 enhancements ===== */
  app.tokenMotions = new Map();
  app.quickAttack = null;
  app.seenAttackIds = new Set();
  app.attackPending = false;

  function easeOutCubic(value) { return 1 - Math.pow(1 - value, 3); }
  function angleLerp(from, to, t) {
    const delta = (((to - from) % 360) + 540) % 360 - 180;
    return from + delta * t;
  }
  function visualTokenState(token) {
    const motion = app.tokenMotions.get(token.id);
    if (!motion) return { x: token.x, y: token.y, rotation: token.rotation || 0 };
    const elapsed = performance.now() - motion.startedAt;
    const raw = clamp(elapsed / motion.duration, 0, 1);
    const t = easeOutCubic(raw);
    if (raw >= 1) app.tokenMotions.delete(token.id);
    else requestRender();
    return { x: motion.fromX + (motion.toX - motion.fromX) * t, y: motion.fromY + (motion.toY - motion.fromY) * t, rotation: angleLerp(motion.fromRotation, motion.toRotation, t) };
  }

  function applyBattlemap(battlemap, preserveSelection = true) {
    const selected = preserveSelection ? app.selected : null;
    const oldScene = app.scene;
    const oldSceneId = oldScene?.id;
    const oldVisual = new Map((oldScene?.tokens || []).map(token => [token.id, visualTokenState(token)]));
    app.battlemap = battlemap || { scenes: [], activeSceneId: null };
    const forcedSceneId = app.forceSceneId;
    app.forceSceneId = null;
    const selectedSceneId = $('scene-select')?.value;
    const forcedExists = forcedSceneId && app.battlemap.scenes.some(scene => scene.id === forcedSceneId);
    const selectedExists = selectedSceneId && app.battlemap.scenes.some(scene => scene.id === selectedSceneId);
    const requested = forcedExists
      ? forcedSceneId
      : (master && selectedExists ? selectedSceneId : app.battlemap.activeSceneId);
    app.scene = app.battlemap.scenes.find(scene => scene.id === requested) || app.battlemap.scenes[0] || null;
    if (app.scene && app.scene.id === oldSceneId) {
      const now = performance.now();
      for (const token of app.scene.tokens || []) {
        const previous = oldVisual.get(token.id);
        if (!previous || app.drag?.tokenId === token.id) continue;
        const distance = Math.hypot(token.x - previous.x, token.y - previous.y);
        const rotationDelta = Math.abs((((token.rotation || 0) - previous.rotation + 540) % 360) - 180);
        if (distance > 0.5 || rotationDelta > 0.5) {
          app.tokenMotions.set(token.id, { fromX: previous.x, fromY: previous.y, fromRotation: previous.rotation, toX: token.x, toY: token.y, toRotation: token.rotation || 0, startedAt: now, duration: clamp(170 + distance * 0.5, 170, 520) });
        }
      }
    } else app.tokenMotions.clear();
    if (selected && selectionExists(selected)) app.selected = selected; else app.selected = null;
    loadMapImage();
    requestRender();
  }

  function selectionExists(selection) {
    if (!app.scene || !selection) return false;
    if (selection.type === 'token') return app.scene.tokens.some(item => item.id === selection.id);
    if (selection.type === 'wall') return app.scene.walls.some(item => item.id === selection.id);
    if (selection.type === 'door') return (app.scene.doors || []).some(item => item.id === selection.id);
    if (selection.type === 'cover') return (app.scene.covers || []).some(item => item.id === selection.id);
    if (selection.type === 'light') return app.scene.lights.some(item => item.id === selection.id);
    return false;
  }

  function render() {
    const { width, height, dpr } = app.dimensions;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = '#0b0e12'; ctx.fillRect(0, 0, width, height);
    if (!app.scene) { refreshTokenActions(); return; }
    ctx.save(); ctx.translate(app.view.x, app.view.y); ctx.scale(app.view.scale, app.view.scale);
    drawMap(ctx); drawGrid(ctx);
    try { drawEffectZones(ctx); } catch (error) { console.error('[FATUM Battlemap] Ошибка слоя областей:', error); }
    drawCombatMovementRange(ctx); drawWalls(ctx); drawSceneLightsMarkers(ctx); drawThrowPreview(ctx); drawTokens(ctx); drawDraft(ctx); drawAttackLine(ctx); drawV061TargetPreview(ctx); ctx.restore();
    drawLightingAndFog();ctx.setTransform(app.dimensions.dpr,0,0,app.dimensions.dpr,0,0);ctx.save();ctx.translate(app.view.x,app.view.y);ctx.scale(app.view.scale,app.view.scale);try{drawEffectZones(ctx,true);}catch(error){console.error('[FATUM Battlemap] Ошибка подписей областей:',error);}ctx.restore();drawRollVisuals();refreshTokenActions();
  }

  function activeEffectZones(){
    const now=Date.now(), localNow=performance.now(), byId=new Map();
    for(const effect of (app.scene?.effects||[])) if(Number(effect.remainingRounds||0)>0&&(!effect.expiresAt||Date.parse(effect.expiresAt)>now)) byId.set(effect.id,effect);
    for(const [id,item] of app.transientEffects){
      if(item.expiresLocalAt<=localNow){app.transientEffects.delete(id);continue;}
      if(item.sceneId===app.scene?.id) byId.set(id,item.effect);
    }
    return [...byId.values()];
  }
  function drawEffectZones(target, overlay=false) {
    for(const effect of activeEffectZones()){
      target.save();
      try {
        const radius=feetToPixels(effect.shape==='cone'?(effect.coneFeet||effect.radius||0):(effect.radius||0));if(radius<=0)continue;
        const pulse=effect.pulse===false?1:(1+Math.sin(performance.now()/180+String(effect.id).length)*.035);if(effect.pulse!==false)requestRender();
        let labelX=effect.x,labelY=effect.y-radius;
        target.beginPath();
        if(effect.shape==='cone'){
          const ox=Number(effect.originX??effect.x),oy=Number(effect.originY??effect.y),ax=Number(effect.aimX??effect.x),ay=Number(effect.aimY??effect.y),angle=Math.atan2(ay-oy,ax-ox),half=(Number(effect.coneAngle||60)*Math.PI/180)/2,drawRadius=radius*pulse;
          target.moveTo(ox,oy);target.lineTo(ox+Math.cos(angle-half)*drawRadius,oy+Math.sin(angle-half)*drawRadius);target.arc(ox,oy,drawRadius,angle-half,angle+half);target.closePath();
          labelX=ox+Math.cos(angle)*drawRadius*.58;labelY=oy+Math.sin(angle)*drawRadius*.58;
        }else target.arc(effect.x,effect.y,radius*pulse,0,Math.PI*2);
        if(!overlay){target.fillStyle=hexToRgba(effect.color||'#aab4bd',effect.opacity??.28);target.fill();}
        target.strokeStyle=effect.type==='explosion'||effect.type==='fire'?'#ff9d3f':(effect.color||'#aab4bd');target.lineWidth=(overlay?4:2)/app.view.scale;target.setLineDash(effect.type==='smoke'?[12/app.view.scale,8/app.view.scale]:effect.type==='explosion'||effect.type==='fire'?[5/app.view.scale,5/app.view.scale]:[]);target.stroke();target.setLineDash([]);
        if(overlay){const measure=Number(effect.shape==='cone'?(effect.coneFeet||effect.radius||0):(effect.radius||0)),label=`${effect.name||'Область'} · ${measure} фт${effect.visualOnly?'':` · ${effect.remainingRounds} ход.`}`;target.font=`${12/app.view.scale}px Segoe UI`;const w=target.measureText(label).width+12/app.view.scale;target.fillStyle='rgba(10,13,17,.82)';target.fillRect(labelX-w/2,labelY-24/app.view.scale,w,18/app.view.scale);target.fillStyle='#fff1d1';target.textAlign='center';target.textBaseline='middle';target.fillText(label,labelX,labelY-15/app.view.scale);}
      } catch (error) {
        console.error('[FATUM Battlemap] Не удалось отрисовать область', effect?.id, error);
      } finally {
        target.restore();
      }
    }
  }


  function bmPointOnWall(wall, t) { return { x: wall.x1 + (wall.x2 - wall.x1) * t, y: wall.y1 + (wall.y2 - wall.y1) * t }; }
  function doorGeometry(door) {
    const wall = door.wallId ? app.scene?.walls.find(item => item.id === door.wallId) : null;
    if (!wall) { const x1=Number(door.x1||0),y1=Number(door.y1||0),x2=Number(door.x2||x1+door.width||70),y2=Number(door.y2||y1); return {x1,y1,x2,y2,center:{x:(x1+x2)/2,y:(y1+y2)/2},wall:null,t1:0,t2:1}; }
    const length=Math.max(1,Math.hypot(wall.x2-wall.x1,wall.y2-wall.y1)),half=Math.min(.49,Number(door.width||70)/length/2),t1=clamp(Number(door.t??.5)-half,0,1),t2=clamp(Number(door.t??.5)+half,0,1);
    const a=bmPointOnWall(wall,t1),b=bmPointOnWall(wall,t2); return {x1:a.x,y1:a.y,x2:b.x,y2:b.y,center:bmPointOnWall(wall,Number(door.t??.5)),wall,t1,t2};
  }
  function currentDoorPanel(door) {
    const g=doorGeometry(door); if(!door.open)return {a:{x:g.x1,y:g.y1},b:{x:g.x2,y:g.y2},geometry:g};
    const hinge=door.hinge==='end'?{x:g.x2,y:g.y2}:{x:g.x1,y:g.y1},other=door.hinge==='end'?{x:g.x1,y:g.y1}:{x:g.x2,y:g.y2};
    const angle=Number(door.openAngle||90)*Math.PI/180,dx=other.x-hinge.x,dy=other.y-hinge.y,c=Math.cos(angle),sn=Math.sin(angle);
    return {a:hinge,b:{x:hinge.x+dx*c-dy*sn,y:hinge.y+dx*sn+dy*c},geometry:g};
  }
  function wallDrawSegments(wall) {
    const gaps=(app.scene.doors||[]).filter(d=>d.wallId===wall.id).map(doorGeometry).sort((a,b)=>a.t1-b.t1);const segments=[];let cursor=0;
    for(const gap of gaps){if(gap.t1>cursor)segments.push({a:bmPointOnWall(wall,cursor),b:bmPointOnWall(wall,gap.t1)});cursor=Math.max(cursor,gap.t2);}if(cursor<1)segments.push({a:bmPointOnWall(wall,cursor),b:bmPointOnWall(wall,1)});return segments;
  }
  function effectiveVisionSegments() {
    const list=[];for(const wall of app.scene?.walls||[]){if(!wall.blocksVision)continue;for(const segment of wallDrawSegments(wall))list.push({x1:segment.a.x,y1:segment.a.y,x2:segment.b.x,y2:segment.b.y});}
    for(const door of app.scene?.doors||[]){if(door.open)continue;const g=doorGeometry(door);list.push({x1:g.x1,y1:g.y1,x2:g.x2,y2:g.y2});}return list;
  }
  function drawCover(target,cover){
    if(cover.hidden&&!master)return;const selected=app.selected?.type==='cover'&&app.selected.id===cover.id;target.save();target.beginPath();
    if(cover.shape==='circle')target.arc(cover.x,cover.y,cover.radius,0,Math.PI*2);else if(cover.shape==='polygon'&&cover.points?.length){target.moveTo(cover.points[0].x,cover.points[0].y);for(const p of cover.points.slice(1))target.lineTo(p.x,p.y);target.closePath();}else target.rect(cover.x,cover.y,cover.width,cover.height);
    target.fillStyle=hexToRgba(cover.color||'#65a1c9',.22);target.fill();target.strokeStyle=selected?'#ffd36a':cover.color||'#65a1c9';target.lineWidth=(selected?5:3)/app.view.scale;target.stroke();
    if(master){const center=cover.shape==='circle'?{x:cover.x,y:cover.y}:cover.shape==='polygon'&&cover.points?.length?cover.points.reduce((a,p)=>({x:a.x+p.x/cover.points.length,y:a.y+p.y/cover.points.length}),{x:0,y:0}):{x:cover.x+cover.width/2,y:cover.y+cover.height/2};target.fillStyle='#e8f3fb';target.font=`${12/app.view.scale}px Segoe UI`;target.textAlign='center';target.fillText(cover.destroyed?`${cover.name||'Укрытие'} · РАЗРУШЕНО`:`${cover.name||'Укрытие'} · МЗ ${cover.mz||0} · ${cover.damage||0}/${cover.durability||'—'}`,center.x,center.y);}
    target.restore();
  }
  function drawDoor(target,door){
    if(door.hidden&&!master)return;const selected=app.selected?.type==='door'&&app.selected.id===door.id,panel=currentDoorPanel(door),g=panel.geometry;target.save();
    target.beginPath();target.moveTo(panel.a.x,panel.a.y);target.lineTo(panel.b.x,panel.b.y);target.strokeStyle=door.locked?'#c65b58':door.open?'#58a877':'#d59b4c';target.lineWidth=(selected?9:7)/app.view.scale;target.stroke();
    target.beginPath();target.arc(panel.a.x,panel.a.y,4/app.view.scale,0,Math.PI*2);target.fillStyle='#f4d18d';target.fill();
    if(selected){target.setLineDash([6/app.view.scale,4/app.view.scale]);target.beginPath();target.moveTo(g.x1,g.y1);target.lineTo(g.x2,g.y2);target.strokeStyle='#fff';target.lineWidth=2/app.view.scale;target.stroke();target.setLineDash([]);}target.restore();
  }
  function drawWalls(target) {
    for(const cover of app.scene.covers||[])drawCover(target,cover);
    if(master){for(const wall of app.scene.walls||[]){const selected=app.selected?.type==='wall'&&app.selected.id===wall.id;target.save();for(const segment of wallDrawSegments(wall)){target.beginPath();target.moveTo(segment.a.x,segment.a.y);target.lineTo(segment.b.x,segment.b.y);target.lineWidth=(selected?7:4)/app.view.scale;target.strokeStyle='#c7554f';target.stroke();}target.restore();}}
    for(const door of app.scene.doors||[])drawDoor(target,door);
  }

  function flickerFactor(source) {
    const amount=clamp(Number(source.flicker||0),0,1);if(!amount)return 1;const speed=clamp(Number(source.flickerSpeed||1.5),.1,12),seed=String(source.id||source.name||'light').split('').reduce((a,c)=>a+c.charCodeAt(0),0);
    const time=performance.now()/1000, wave=(Math.sin(time*speed*5+seed)+Math.sin(time*speed*11.7+seed*.37)*.45)/1.45;requestRender();return 1-amount*.18+wave*amount*.16;
  }
  function drawSceneLightsMarkers(target) {
    if(!master)return;for(const light of app.scene.lights||[]){const selected=app.selected?.type==='light'&&app.selected.id===light.id;target.save();target.translate(light.x,light.y);target.fillStyle=light.enabled?light.color:'#555';target.strokeStyle=selected?'#fff':'#372713';target.lineWidth=(selected?4:2)/app.view.scale;target.beginPath();target.arc(0,0,11/app.view.scale,0,Math.PI*2);target.fill();target.stroke();for(let i=0;i<8;i++){const a=i*Math.PI/4;target.beginPath();target.moveTo(Math.cos(a)*14/app.view.scale,Math.sin(a)*14/app.view.scale);target.lineTo(Math.cos(a)*21/app.view.scale,Math.sin(a)*21/app.view.scale);target.stroke();}target.restore();}
  }

  function visibilityPolygon(source, rangePx, angleDeg = 360, rotationDeg = 0) {
    if(!app.scene||rangePx<=0)return[];const blockingWalls=effectiveVisionSegments(),center=(rotationDeg-90)*Math.PI/180,full=angleDeg>=359.9,half=angleDeg*Math.PI/360,angles=[],samples=full?128:Math.max(30,Math.ceil(angleDeg/2.5));
    for(let i=0;i<=samples;i++)angles.push(full?-Math.PI+i/samples*Math.PI*2:center-half+i/samples*half*2);
    for(const wall of blockingWalls)for(const endpoint of [{x:wall.x1,y:wall.y1},{x:wall.x2,y:wall.y2}]){const a=Math.atan2(endpoint.y-source.y,endpoint.x-source.x);if(full||angleInside(a,center,half))angles.push(a-.0001,a,a+.0001);}
    const unique=[...new Set(angles.map(a=>Math.round(a*1000000)/1000000))].filter(a=>full||angleInside(a,center,half)).sort((a,b)=>a-b);
    return unique.map(angle=>{let distance=rangePx;for(const wall of blockingWalls){const hit=raySegment(source,angle,rangePx,wall);if(hit!==null&&hit<distance)distance=hit;}return{x:source.x+Math.cos(angle)*distance,y:source.y+Math.sin(angle)*distance};});
  }

  function adjustedLightSource(source){const factor=flickerFactor(source);return{...source,bright:Number(source.bright||0)*factor,dim:Number(source.dim||source.bright||0)*factor,intensity:Number(source.intensity||1)*(.9+.1*factor)};}
  function drawColoredLightGlow(target,source){source=adjustedLightSource(source);const dimPx=feetToPixels(source.dim||source.bright||0);if(dimPx<=0)return;const polygon=visibilityPolygon(source,dimPx,source.angle||360,source.rotation||0);if(polygon.length<3)return;const screen=worldToScreen(source),radius=dimPx*app.view.scale;target.save();target.beginPath();drawPolygonScreen(target,polygon);target.clip();const color=String(source.color||'#ffd88a').replace('#','');const number=parseInt(color,16),r=(number>>16)&255,g=(number>>8)&255,b=number&255;const gradient=target.createRadialGradient(screen.x,screen.y,0,screen.x,screen.y,Math.max(1,radius));const alpha=Math.min(.5,.15*Number(source.intensity||1));gradient.addColorStop(0,`rgba(${r},${g},${b},${alpha})`);gradient.addColorStop(.55,`rgba(${r},${g},${b},${alpha*.55})`);gradient.addColorStop(1,`rgba(${r},${g},${b},0)`);target.fillStyle=gradient;target.fillRect(screen.x-radius,screen.y-radius,radius*2,radius*2);target.restore();}
  function drawLightCutout(target,source){source=adjustedLightSource(source);const dimPx=feetToPixels(source.dim||source.bright||0),brightPx=feetToPixels(Math.min(source.bright||0,source.dim||source.bright||0));if(dimPx<=0)return;const polygon=visibilityPolygon(source,dimPx,source.angle||360,source.rotation||0);if(polygon.length<3)return;const screen=worldToScreen(source),dimScreen=dimPx*app.view.scale,brightScreen=brightPx*app.view.scale;target.save();target.beginPath();drawPolygonScreen(target,polygon);target.clip();const gradient=target.createRadialGradient(screen.x,screen.y,Math.max(0,brightScreen*.8),screen.x,screen.y,Math.max(1,dimScreen)),intensity=clamp(Number(source.intensity||1),.05,2);gradient.addColorStop(0,`rgba(0,0,0,${Math.min(1,intensity)})`);gradient.addColorStop(Math.min(.95,brightScreen/Math.max(1,dimScreen)),`rgba(0,0,0,${Math.min(1,intensity)})`);gradient.addColorStop(1,'rgba(0,0,0,0)');target.fillStyle=gradient;target.fillRect(screen.x-dimScreen,screen.y-dimScreen,dimScreen*2,dimScreen*2);target.restore();}
  function drawLightingAndFog(){
    const scene=app.scene;if(!scene)return;const{width,height,dpr}=app.dimensions,preview=Boolean($('preview-player-vision')?.checked),masterFull=master&&!preview;
    const showLighting=scene.settings.dynamicLightEnabled&&(!masterFull||scene.settings.masterSeesLighting!==false);
    const sources=[];for(const light of scene.lights||[])if(light.enabled)sources.push({...light,sourceType:'static'});for(const token of scene.tokens||[])if(token.light?.enabled&&(!token.hidden||master||canControlToken(token)))sources.push({id:`token-${token.id}`,x:token.x,y:token.y,rotation:token.rotation,...token.light,sourceType:'token'});
    if(showLighting&&!scene.settings.globalIllumination){const dark=newOverlay(),dc=dark.getContext('2d');dc.fillStyle=`rgba(0,0,0,${scene.settings.ambientDarkness??.82})`;dc.fillRect(0,0,width,height);dc.globalCompositeOperation='destination-out';for(const source of sources)drawLightCutout(dc,source);for(const token of viewerTokens()){const darkRange=feetToPixels(token.vision?.darkvision||0);if(darkRange>0)drawLightCutout(dc,{id:`dark-${token.id}`,x:token.x,y:token.y,rotation:token.rotation,bright:token.vision.darkvision,dim:token.vision.darkvision,angle:token.vision.angle,color:'#c6d7ff',intensity:.75});}dc.globalCompositeOperation='source-over';ctx.setTransform(dpr,0,0,dpr,0,0);ctx.drawImage(dark,0,0);}
    if(showLighting){ctx.setTransform(dpr,0,0,dpr,0,0);for(const source of sources)drawColoredLightGlow(ctx,source);}
    const fogMode=scene.settings.fogEnabled===false?'off':scene.settings.fogMode;if(fogMode!=='off'&&!masterFull){const fog=newOverlay(),fc=fog.getContext('2d'),startsHidden=scene.fog?.baseHidden!==false||fogMode==='vision'||fogMode==='hybrid';if(startsHidden){fc.fillStyle='rgba(0,0,0,.965)';fc.fillRect(0,0,width,height);}const current=currentVisionPolygons(),explored=new Set(scene.fog.explored?.[clientId]||[]);if(scene.settings.exploredMemory&&explored.size&&(fogMode==='vision'||fogMode==='hybrid')){fc.globalCompositeOperation='destination-out';fc.globalAlpha=.42;const cell=scene.fog.cellSize||scene.grid.size;for(const key of explored){const[gx,gy]=key.split(':').map(Number),a=worldToScreen({x:gx*cell,y:gy*cell});fc.fillRect(a.x,a.y,cell*app.view.scale+1,cell*app.view.scale+1);}fc.globalAlpha=1;}if(fogMode==='manual'||fogMode==='hybrid')applyManualFog(fc,scene.fog.ops||[],'reveal');if(fogMode==='vision'||fogMode==='hybrid'){fc.globalCompositeOperation='destination-out';for(const item of current){fc.beginPath();drawPolygonScreen(fc,item.polygon);fc.fillStyle='#000';fc.fill();}}if(fogMode==='manual'||fogMode==='hybrid')applyManualFog(fc,scene.fog.ops||[],'hide');fc.globalCompositeOperation='source-over';ctx.setTransform(dpr,0,0,dpr,0,0);ctx.drawImage(fog,0,0);scheduleExplored(current);}
  }

  function drawDraft(target){if(!app.draft)return;const d=app.draft;if(['wall','measure'].includes(d.type)){target.save();target.beginPath();target.moveTo(d.start.x,d.start.y);target.lineTo(d.current.x,d.current.y);target.lineWidth=3/app.view.scale;target.strokeStyle=d.type==='measure'?'#f1d56d':'#e85e58';target.setLineDash([8/app.view.scale,5/app.view.scale]);target.stroke();if(d.type==='measure'){const feet=pixelsToFeet(Math.hypot(d.current.x-d.start.x,d.current.y-d.start.y));target.setLineDash([]);target.fillStyle='#fff2bd';target.font=`${14/app.view.scale}px Segoe UI`;target.fillText(`${feet.toFixed(1)} фт`,(d.start.x+d.current.x)/2,(d.start.y+d.current.y)/2);}target.restore();}
    if(d.type==='cover'){target.save();target.fillStyle='rgba(101,161,201,.24)';target.strokeStyle='#9bccec';target.lineWidth=3/app.view.scale;target.beginPath();if(d.shape==='circle')target.arc(d.start.x,d.start.y,Math.hypot(d.current.x-d.start.x,d.current.y-d.start.y),0,Math.PI*2);else{const x=Math.min(d.start.x,d.current.x),y=Math.min(d.start.y,d.current.y);target.rect(x,y,Math.abs(d.current.x-d.start.x),Math.abs(d.current.y-d.start.y));}target.fill();target.stroke();target.restore();}
    if(d.type==='cover-poly'){target.save();target.beginPath();if(d.points.length){target.moveTo(d.points[0].x,d.points[0].y);for(const p of d.points.slice(1))target.lineTo(p.x,p.y);target.lineTo(d.current.x,d.current.y);}target.fillStyle='rgba(101,161,201,.18)';target.strokeStyle='#9bccec';target.lineWidth=3/app.view.scale;target.fill();target.stroke();target.restore();}
    if(['fog-reveal','fog-hide'].includes(d.type)){target.save();target.fillStyle=d.type==='fog-reveal'?'rgba(110,190,120,.28)':'rgba(210,75,70,.28)';for(const point of d.points){target.beginPath();target.arc(point.x,point.y,d.radius,0,Math.PI*2);target.fill();}target.restore();}}

  function doorById(id){return(app.scene?.doors||[]).find(item=>item.id===id)||null;}function coverById(id){return(app.scene?.covers||[]).find(item=>item.id===id)||null;}
  function visibleInPossession(point){if(!master||!app.possessedTokenId)return true;const viewer=tokenById(app.possessedTokenId);if(!viewer)return false;if(Math.hypot(point.x-viewer.x,point.y-viewer.y)<tokenRadius(viewer)*1.2)return true;const polygon=visibilityPolygon(viewer,feetToPixels(viewer.vision?.range||60),viewer.vision?.angle||360,viewer.rotation||0);return polygon.length>=3&&bmPointInPolygon(point,polygon);}
  function hitTestToken(point){const tokens=[...(app.scene?.tokens||[])].reverse();return tokens.find(token=>{const p=visualTokenState(token);return visibleInPossession(p)&&Math.hypot(point.x-p.x,point.y-p.y)<=tokenRadius(token);})||null;}
  function rotationHandlePoint(token){const p=visualTokenState(token),r=tokenRadius(token)+24/app.view.scale,a=(p.rotation||0)*Math.PI/180;return{x:p.x+Math.sin(a)*r,y:p.y-Math.cos(a)*r};}
  function hitTestRotationHandle(point){const token=selectedToken();if(!token||!canControlToken(token))return null;const h=rotationHandlePoint(token);return Math.hypot(point.x-h.x,point.y-h.y)<=11/app.view.scale?token:null;}
  function hitTestDoor(point){return[...(app.scene?.doors||[])].reverse().find(door=>{if(door.hidden&&!master)return false;const p=currentDoorPanel(door);return visibleInPossession(p.geometry.center)&&pointSegmentDistance(point,p.a,p.b)<=22/app.view.scale;})||null;}
  function bmPointInPolygon(point,points){let inside=false;for(let i=0,j=points.length-1;i<points.length;j=i++){const a=points[i],b=points[j];if(((a.y>point.y)!=(b.y>point.y))&&point.x<(b.x-a.x)*(point.y-a.y)/((b.y-a.y)||1e-12)+a.x)inside=!inside;}return inside;}
  function hitTestCover(point){return[...(app.scene?.covers||[])].reverse().find(c=>{if(c.hidden&&!master)return false;return hitPointInCover(point,c);})||null;}
  function hitTestLight(point){if(!master)return null;return[...(app.scene?.lights||[])].reverse().find(light=>Math.hypot(point.x-light.x,point.y-light.y)<=18/app.view.scale)||null;}
  function nearestWallProjection(point,wallId=null){let best=null;for(const wall of app.scene?.walls||[]){if(wallId&&wall.id!==wallId)continue;const dx=wall.x2-wall.x1,dy=wall.y2-wall.y1,l2=dx*dx+dy*dy;if(!l2)continue;const t=clamp(((point.x-wall.x1)*dx+(point.y-wall.y1)*dy)/l2,0,1),p=bmPointOnWall(wall,t),distance=Math.hypot(point.x-p.x,point.y-p.y);if(!best||distance<best.distance)best={wall,t,point:p,distance};}return best;}

  function setTool(tool){app.tool=tool;app.draft=null;app.quickAttack=null;$('quick-attack').hidden=true;document.querySelectorAll('.bm-tool').forEach(button=>button.classList.toggle('active',button.dataset.tool===tool));for(const className of [...stage.classList])if(className.startsWith('tool-'))stage.classList.remove(className);stage.classList.add(`tool-${tool}`);stage.dataset.tool=tool;const help={select:'ЛКМ — выбрать и переместить · жёлтая ручка — поворот · двойной клик по двери — открыть',pan:'Тяните карту ЛКМ',measure:'Протяните линию между двумя точками',wall:'Протяните новую стену','wall-curve':'Рисуйте кривую стену удерживая ЛКМ',door:'Щёлкните по существующей стене, чтобы установить дверь',cover:'Создайте укрытие выбранной формы','cover-curve':'Рисуйте кривое укрытие удерживая ЛКМ',light:'Щёлкните место источника света; затем его можно перетаскивать','audio-source':'Щёлкните место локального источника звука','fog-reveal':'Рисуйте видимые области','fog-hide':'Рисуйте скрытые области',attack:'Выберите свой токен, затем токен цели'};$('tool-help').textContent=help[tool]||'';requestRender();}
  function selectObject(type,objectId){app.selected=type&&objectId?{type,id:objectId}:null;refreshInspector();refreshTokenList();refreshCombatUi();requestRender();}

  async function addDoorAt(point){const projection=nearestWallProjection(point);if(!projection||projection.distance>Math.max(35/app.view.scale,app.scene.grid.size*.45)){toast('Дверь нужно установить на существующую стену.','error');return;}const door={id:`door_${id()}`,name:'Дверь',wallId:projection.wall.id,t:projection.t,width:Number($('new-door-width').value||70),open:false,hinge:'start',openAngle:90,locked:false,allowPlayers:$('new-door-allow-players').checked,hidden:false};app.scene.doors.push(door);requestRender();try{await saveDoors();selectObject('door',door.id);toast('Дверь установлена.','success');}catch(error){toast(error.message,'error');await refreshBattlemap();}}
  function newCoverSettings(){return{name:$('new-cover-name').value||'Укрытие',mz:Number($('new-cover-mz').value||0),durability:Number($('new-cover-durability').value||0),damage:0,thickness:Number($('new-cover-thickness')?.value||18),blocksMovement:$('new-cover-blocks-movement').checked,hidden:false,showGeometryToPlayers:Boolean($('new-cover-show-players')?.checked),color:'#65a1c9',preset:$('new-cover-preset')?.value||'custom',coverage:$('new-cover-coverage')?.value||'half',material:$('new-cover-material')?.value||'light',elevation:Number($('new-cover-elevation')?.value||0),verticalHeight:Number($('new-cover-vertical-height')?.value||5)};}
  async function finishPolygonCover(){if(app.draft?.type!=='cover-poly'||app.draft.points.length<3){toast('Для многоугольника нужно минимум три точки.','error');return;}const cover={id:`cover_${id()}`,shape:'polygon',points:app.draft.points,...newCoverSettings()};app.draft=null;app.scene.covers.push(cover);try{await saveCovers();selectObject('cover',cover.id);toast('Укрытие создано.','success');}catch(error){toast(error.message,'error');await refreshBattlemap();}}

  function onPointerDown(event){if(!app.scene||event.button!==0)return;canvas.setPointerCapture?.(event.pointerId);const screen=eventPoint(event),world=screenToWorld(screen);app.lastMouseWorld=world;const pan=app.tool==='pan'||app.spaceDown;if(pan){app.drag={type:'pan',start:screen,view:{...app.view}};stage.classList.add('is-panning');event.preventDefault();return;}
    if(app.tool==='select'){
      const rotate=hitTestRotationHandle(world);if(rotate){app.tokenMotions.delete(rotate.id);app.drag={type:'rotate-token',tokenId:rotate.id};return;}
      const token=hitTestToken(world);if(token){selectObject('token',token.id);if(canControlToken(token)&&!token.locked){app.tokenMotions.delete(token.id);app.drag={type:'token',tokenId:token.id,start:world,origin:{x:token.x,y:token.y},lastValid:{x:token.x,y:token.y},movementStart:movementForToken(token)};}return;}
      const light=hitTestLight(world);if(light){selectObject('light',light.id);app.drag={type:'light',lightId:light.id,start:world,origin:{x:light.x,y:light.y}};return;}
      const door=hitTestDoor(world);if(door){selectObject('door',door.id);if(master&&door.wallId)app.drag={type:'door',doorId:door.id,start:world,originT:Number(door.t??.5),moved:false};return;}
      const cover=hitTestCover(world);if(cover){selectObject('cover',cover.id);if(master)app.drag={type:'cover',coverId:cover.id,start:world,origin:{x:cover.x,y:cover.y,points:(cover.points||[]).map(p=>({...p}))}};return;}
      const wall=hitTestWall(world);if(wall){selectObject('wall',wall.id);return;}selectObject(null,null);return;
    }
    if(['measure','wall'].includes(app.tool)){app.draft={type:app.tool,start:world,current:world};requestRender();return;}
    if(app.tool==='door'&&master){addDoorAt(world);return;}
    if(app.tool==='cover'&&master){const shape=$('new-cover-shape').value;if(shape==='polygon'){if(app.draft?.type!=='cover-poly')app.draft={type:'cover-poly',points:[world],current:world};else app.draft.points.push(world);requestRender();return;}app.draft={type:'cover',shape,start:world,current:world};requestRender();return;}
    if(['fog-reveal','fog-hide'].includes(app.tool)){app.draft={type:app.tool,radius:Math.max(12,Number(promptRadius.value||80)),points:[world]};requestRender();return;}
    if(app.tool==='light'&&master){addLightAt(world);return;}
    if(app.tool==='attack'){const token=hitTestToken(world);if(!token)return;const attackerId=$('attack-attacker').value;if(!attackerId){if(canControlToken(token)){beginAttackWithToken(token);}else toast('Сначала выберите свой токен.','error');}else if(token.id!==attackerId)showQuickAttackPicker(token);}
  }
  function onPointerMove(event){if(!app.scene)return;const screen=eventPoint(event),world=screenToWorld(screen);app.lastMouseWorld=world;$('coordinates').textContent=`x ${world.x.toFixed(0)} · y ${world.y.toFixed(0)} · ${pixelsToFeet(Math.hypot(world.x,world.y)).toFixed(1)} фт от начала`;
    if(app.drag?.type==='pan'){app.view.x=app.drag.view.x+(screen.x-app.drag.start.x);app.view.y=app.drag.view.y+(screen.y-app.drag.start.y);requestRender();return;}
    if(app.drag?.type==='token'){const token=tokenById(app.drag.tokenId);if(!token)return;let next={x:app.drag.origin.x+(world.x-app.drag.start.x),y:app.drag.origin.y+(world.y-app.drag.start.y)};next=snapPoint(next);next={x:clamp(next.x,0,app.scene.mapWidth),y:clamp(next.y,0,app.scene.mapHeight)};const from=app.drag.lastValid||{x:token.x,y:token.y},budget=app.drag.movementStart;next=clampMoveToBudget(app.drag.origin,next,budget?.remaining);if(!clientMovementBlocked(token,from,next)){v080ApplyAutoRotation(token,from,next);token.x=next.x;token.y=next.y;app.drag.lastValid={...next};}requestRender();return;}
    if(app.drag?.type==='rotate-token'){const token=tokenById(app.drag.tokenId);if(!token)return;const angle=Math.atan2(world.y-token.y,world.x-token.x)*180/Math.PI+90;token.rotation=((angle%360)+360)%360;stage.classList.add('is-rotating');requestRender();return;}
    if(app.drag?.type==='light'){const light=lightById(app.drag.lightId);if(!light)return;light.x=app.drag.origin.x+(world.x-app.drag.start.x);light.y=app.drag.origin.y+(world.y-app.drag.start.y);requestRender();return;}
    if(app.drag?.type==='door'){const door=doorById(app.drag.doorId);if(!door)return;if(!app.drag.moved&&Math.hypot(world.x-app.drag.start.x,world.y-app.drag.start.y)<7/app.view.scale)return;app.drag.moved=true;const projection=nearestWallProjection(world,door.wallId);if(projection){door.t=projection.t;requestRender();}return;}
    if(app.drag?.type==='cover'){const c=coverById(app.drag.coverId);if(!c)return;const dx=world.x-app.drag.start.x,dy=world.y-app.drag.start.y;if(c.shape==='polygon'||c.shape==='polyline')c.points=app.drag.origin.points.map(p=>({x:p.x+dx,y:p.y+dy}));else{c.x=app.drag.origin.x+dx;c.y=app.drag.origin.y+dy;}requestRender();return;}
    if(app.draft&&['measure','wall','cover'].includes(app.draft.type)){app.draft.current=world;requestRender();return;}if(app.draft?.type==='cover-poly'){app.draft.current=world;requestRender();return;}
    if(app.draft&&['fog-reveal','fog-hide'].includes(app.draft.type)){const last=app.draft.points[app.draft.points.length-1];if(Math.hypot(world.x-last.x,world.y-last.y)>app.draft.radius*.3){app.draft.points.push(world);requestRender();}}
  }
  async function onPointerUp(){stage.classList.remove('is-panning','is-rotating');const drag=app.drag;app.drag=null;if(drag?.type==='token'){const token=tokenById(drag.tokenId);if(token)try{await updateToken(token,{x:token.x,y:token.y,rotation:token.rotation});}catch(error){toast(error.message,'error');await refreshBattlemap();}return;}if(drag?.type==='rotate-token'){const token=tokenById(drag.tokenId);if(token)try{await updateToken(token,{rotation:token.rotation});}catch(error){toast(error.message,'error');}return;}if(drag?.type==='light'){try{await saveLights();}catch(error){toast(error.message,'error');await refreshBattlemap();}return;}if(drag?.type==='door'){if(!drag.moved)return;try{await saveDoors();}catch(error){toast(error.message,'error');await refreshBattlemap();}return;}if(drag?.type==='cover'){try{await saveCovers();}catch(error){toast(error.message,'error');await refreshBattlemap();}return;}if(!app.draft)return;const draft=app.draft;if(draft.type==='cover-poly')return;app.draft=null;if(draft.type==='measure'){requestRender();return;}if(draft.type==='wall'&&master){if(Math.hypot(draft.current.x-draft.start.x,draft.current.y-draft.start.y)<4)return;const wall={id:`wall_${id()}`,x1:draft.start.x,y1:draft.start.y,x2:draft.current.x,y2:draft.current.y,blocksVision:$('new-wall-blocks-vision').checked,blocksMovement:$('new-wall-blocks-movement').checked,coverMz:0,coverDurability:0,coverDamage:0,coverName:'',showGeometryToPlayers:Boolean($('new-wall-show-players')?.checked)};app.scene.walls.push(wall);requestRender();try{await saveWalls();selectObject('wall',wall.id);}catch(error){toast(error.message,'error');await refreshBattlemap();}return;}if(draft.type==='cover'&&master){const settings=newCoverSettings();let cover;if(draft.shape==='circle')cover={id:`cover_${id()}`,shape:'circle',x:draft.start.x,y:draft.start.y,radius:Math.max(5,Math.hypot(draft.current.x-draft.start.x,draft.current.y-draft.start.y)),width:10,height:10,points:[],...settings};else cover={id:`cover_${id()}`,shape:'rect',x:Math.min(draft.start.x,draft.current.x),y:Math.min(draft.start.y,draft.current.y),width:Math.max(5,Math.abs(draft.current.x-draft.start.x)),height:Math.max(5,Math.abs(draft.current.y-draft.start.y)),radius:5,points:[],...settings};app.scene.covers.push(cover);try{await saveCovers();selectObject('cover',cover.id);}catch(error){toast(error.message,'error');await refreshBattlemap();}return;}if(['fog-reveal','fog-hide'].includes(draft.type)&&master){const op={id:`fog_${id()}`,mode:draft.type==='fog-hide'?'hide':'reveal',shape:'brush',radius:draft.radius,points:draft.points};app.scene.fog.ops.push(op);requestRender();try{await saveFog();}catch(error){toast(error.message,'error');await refreshBattlemap();}}}
  function onWheel(event){event.preventDefault();if(event.altKey){const token=selectedToken();if(token&&canControlToken(token)){rotateSelected(event.deltaY>0?15:-15);return;}}const point=eventPoint(event),before=screenToWorld(point),factor=Math.exp(-event.deltaY*.0012);app.view.scale=clamp(app.view.scale*factor,.08,4);app.view.x=point.x-before.x*app.view.scale;app.view.y=point.y-before.y*app.view.scale;$('scale-readout').textContent=`${Math.round(app.view.scale*100)}%`;requestRender();}

  async function saveDoors(){await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/doors`,{method:'PUT',body:commonBody({doors:app.scene.doors})});}
  async function saveCovers(){await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/covers`,{method:'PUT',body:commonBody({covers:app.scene.covers})});}
  async function addLightAt(point){const light={id:`light_${id()}`,name:'Источник света',x:point.x,y:point.y,rotation:0,enabled:true,bright:20,dim:40,angle:360,color:'#ffd88a',intensity:1,flicker:0,flickerSpeed:1.5,hidden:false};app.scene.lights.push(light);requestRender();try{await saveLights();selectObject('light',light.id);}catch(error){toast(error.message,'error');await refreshBattlemap();}}

  function refreshSceneForm(){const s=app.scene;if(!s)return;$('scene-name').value=s.name;$('scene-width').value=s.mapWidth;$('scene-height').value=s.mapHeight;$('grid-enabled').checked=s.grid.enabled;$('grid-snap').checked=s.grid.snap;$('grid-size').value=s.grid.size;$('grid-feet').value=s.grid.feet;$('grid-offset-x').value=s.grid.offsetX;$('grid-offset-y').value=s.grid.offsetY;$('fog-mode').value=s.settings.fogMode;$('vision-enabled').checked=s.settings.visionEnabled;$('dynamic-light-enabled').checked=s.settings.dynamicLightEnabled;$('global-illumination').checked=s.settings.globalIllumination;$('master-sees-lighting').checked=s.settings.masterSeesLighting!==false;$('ambient-darkness').value=s.settings.ambientDarkness;}
  function refreshInspector(){['no-selection-card','token-inspector','wall-inspector','door-inspector','cover-inspector','light-inspector'].forEach(id=>$(id).hidden=true);if(!app.selected){$('no-selection-card').hidden=false;return;}
    if(app.selected.type==='token'){const t=selectedToken();if(!t){$('no-selection-card').hidden=false;return;}$('token-inspector').hidden=false;$('token-name').value=t.name;$('token-x').value=Math.round(t.x);$('token-y').value=Math.round(t.y);$('token-size').value=t.size;$('token-rotation').value=Math.round(t.rotation||0);$('token-mz').value=t.mzOverride??'';$('token-cover-bonus').value=t.coverBonus||0;if($('token-elevation'))$('token-elevation').value=Number(t.elevation||0);const d=t.display||{};$('token-display-shape').value=d.shape||'circle';$('token-display-fit').value=d.fit||'cover';$('token-image-scale').value=d.imageScale||1;$('token-opacity').value=d.opacity??1;$('token-image-offset-x').value=d.offsetX||0;$('token-image-offset-y').value=d.offsetY||0;$('token-border-color').value=d.borderColor||'#d7d7d7';$('token-border-enabled').checked=d.borderEnabled!==false;$('token-background-enabled').checked=d.backgroundEnabled!==false;$('token-group-marker-enabled').checked=d.showGroupMarker!==false;$('token-show-name').checked=d.showName!==false;$('token-rotate-image').checked=d.rotateImage!==false;$('token-auto-rotate-move').checked=Boolean(d.autoRotateOnMove);$('token-hidden').checked=t.hidden;$('token-locked').checked=t.locked;$('token-defeated').checked=t.defeated;$('token-vision-enabled').checked=t.vision?.enabled!==false;$('token-vision-range').value=t.vision?.range||60;$('token-vision-angle').value=t.vision?.angle||360;$('token-light-enabled').checked=Boolean(t.light?.enabled);$('token-light-bright').value=t.light?.bright||20;$('token-light-dim').value=t.light?.dim||40;$('token-light-angle').value=t.light?.angle||360;$('token-light-color').value=t.light?.color||'#ffd88a';$('token-light-flicker').value=t.light?.flicker||0;$('token-light-flicker-speed').value=t.light?.flickerSpeed||1.5;document.querySelector('.bm-player-token-actions').hidden=master||!canControlToken(t);return;}
    if(app.selected.type==='wall'){const w=wallById(app.selected.id);if(!w){$('no-selection-card').hidden=false;return;}$('wall-inspector').hidden=false;$('wall-inspector-title').textContent='Стена';$('wall-blocks-vision').checked=w.blocksVision;$('wall-blocks-movement').checked=w.blocksMovement;return;}
    if(app.selected.type==='door'){const d=doorById(app.selected.id);if(!d){$('no-selection-card').hidden=false;return;}$('door-inspector').hidden=false;$('door-name').value=d.name||'Дверь';$('door-width').value=d.width||70;$('door-open-angle').value=d.openAngle||90;$('door-open').checked=d.open;$('door-locked').checked=d.locked;$('door-allow-players').checked=d.allowPlayers!==false;$('door-hidden').checked=d.hidden;$('toggle-door-btn').disabled=!master&&(!d.allowPlayers||d.locked);document.querySelector('.bm-player-door-actions').hidden=master||!d.allowPlayers||d.locked;return;}
    if(app.selected.type==='cover'){const c=coverById(app.selected.id);if(!c){$('no-selection-card').hidden=false;return;}$('cover-inspector').hidden=false;$('cover-name').value=c.name||'Укрытие';$('cover-shape').value=c.shape||'rect';$('cover-x').value=Math.round(c.x||0);$('cover-y').value=Math.round(c.y||0);$('cover-width').value=c.width||10;$('cover-height').value=c.height||10;$('cover-radius').value=c.radius||10;$('cover-mz').value=c.mz||0;$('cover-durability').value=c.durability||0;$('cover-damage').value=c.damage||0;$('cover-color').value=c.color||'#65a1c9';$('cover-blocks-movement').checked=c.blocksMovement;$('cover-hidden').checked=c.hidden;if($('cover-elevation'))$('cover-elevation').value=Number(c.elevation||0);if($('cover-vertical-height'))$('cover-vertical-height').value=Number(c.verticalHeight||5);return;}
    if(app.selected.type==='light'){const l=lightById(app.selected.id);if(!l){$('no-selection-card').hidden=false;return;}$('light-inspector').hidden=false;$('static-light-name').value=l.name;$('static-light-enabled').checked=l.enabled;$('static-light-bright').value=l.bright;$('static-light-dim').value=l.dim;$('static-light-angle').value=l.angle;$('static-light-rotation').value=l.rotation;$('static-light-color').value=l.color;$('static-light-intensity').value=l.intensity;$('static-light-flicker').value=l.flicker||0;$('static-light-flicker-speed').value=l.flickerSpeed||1.5;}
  }

  function clientWeapons(token){if(!token)return[];if(Array.isArray(token.weapons)&&token.weapons.length)return token.weapons;if(token.kind==='character'){const c=characterById(token.refId),st=c?.state||{};if(Array.isArray(st._lanBattleProfile?.weapons)&&st._lanBattleProfile.weapons.length)return st._lanBattleProfile.weapons;return fallbackClientWeapons(st);}if(token.kind==='npc'){const npc=npcById(token.refId),w=npc?.weapon||{};let bonus=Number(w.manualBonus||0);if(w.bonusMode==='rank')bonus=Number(w.rankBonus||0);if(w.bonusMode==='formula')bonus=Number(w.proficiency||0)+Math.floor(Number(w.accuracy||0)/2)-Number(w.threshold||0);return[{id:'npc-weapon',name:w.name||'Оружие',profile:w.profile||w.name||'Оружие',type:w.melee?'Оружие ближнего боя':'NPC',melee:Boolean(w.melee),hitDieNormal:w.hitDie||'1d6',hitDieAimed:'',hitBonus:bonus,damage:Number(w.damage||2),damageTag:w.damageTag||'medium',odCost:Number(w.odCost||2),obCost:0,range:Number(w.range||100),ignoreMz:Number(w.ignoreMz||0),description:w.description||''}];}return[];}
  function fallbackClientWeapons(st){const inventory=Array.isArray(st.inventory)?st.inventory:[],acc=Number(st._lanRollProfile?.skills?.['Меткость']?.bonus||st.skills?.['Меткость']?.bonus||0);return['weapon1','weapon2'].map(slot=>{const key=st.equipment?.[slot];if(!key)return null;const item=inventory.find(i=>i.uid===key||i.name===key)||{name:String(key),type:'',desc:''},desc=String(item.desc||item.description||'').replace(/к/g,'d'),pair=desc.match(/Попадание:\s*(1d(?:4|6|8|10|12))[^/]*\/\s*(1d(?:4|6|8|10|12))/i),single=desc.match(/(?:Попадание[:\s]*)?(1d(?:4|6|8|10|12))/i),hitDieNormal=pair?.[1]||single?.[1]||'1d6',hitDieAimed=pair?.[2]||'',threshold=Number(desc.match(/порог\s*(\d+)/i)?.[1]||0),type=item.type||'',cat={'Пистолет':'Пистолеты','Карабин':'Карабины','Снайперская винтовка':'Винтовки','Дробовик':'Дробовики','Тяжёлое':'Тяжёлое'}[type],prof=Number(st.weaponProficiencies?.[cat]||0),melee=type==='Оружие ближнего боя',hitBonus=melee?Math.max(Number(st._lanRollProfile?.skills?.['Акробатика']?.bonus||0),Number(st._lanRollProfile?.skills?.['Физическая сила']?.bonus||0)):prof+Math.floor(acc/2)-threshold,ranges=[...desc.matchAll(/(\d+)\s*фт/gi)].map(m=>Number(m[1]));return{id:slot,slot,name:item.customModel||item.selectedModel||item.name,profile:item.profile||item.name,type,melee,hitDieNormal,hitDieAimed,hitBonus,damage:Number(desc.match(/урон\s*(\d+)/i)?.[1]||1),damageTag:item.damageTag||'medium',odCost:Number(desc.match(/(\d+)\s*ОД/i)?.[1]||2),obCost:/требует\s*1\s*ОБ/i.test(desc)?1:0,range:ranges.length?Math.max(...ranges):5,ignoreMz:0,description:item.desc||''};}).filter(Boolean);}

  async function saveSelectedToken(){const t=selectedToken();if(!t)return;try{await updateToken(t,{name:$('token-name').value,x:Number($('token-x').value),y:Number($('token-y').value),size:Number($('token-size').value),rotation:Number($('token-rotation').value),mzOverride:$('token-mz').value===''?null:Number($('token-mz').value),coverBonus:Number($('token-cover-bonus').value||0),elevation:Number($('token-elevation')?.value||0),hidden:$('token-hidden').checked,locked:$('token-locked').checked,defeated:$('token-defeated').checked,display:{shape:$('token-display-shape').value,fit:$('token-display-fit').value,imageScale:Number($('token-image-scale').value),opacity:Number($('token-opacity').value),offsetX:Number($('token-image-offset-x').value),offsetY:Number($('token-image-offset-y').value),borderColor:$('token-border-color').value,borderEnabled:$('token-border-enabled').checked,backgroundEnabled:$('token-background-enabled').checked,showGroupMarker:$('token-group-marker-enabled').checked,showName:$('token-show-name').checked,rotateImage:$('token-rotate-image').checked,autoRotateOnMove:$('token-auto-rotate-move').checked},vision:{enabled:$('token-vision-enabled').checked,range:Number($('token-vision-range').value),angle:Number($('token-vision-angle').value)},light:{enabled:$('token-light-enabled').checked,bright:Number($('token-light-bright').value),dim:Number($('token-light-dim').value),angle:Number($('token-light-angle').value),color:$('token-light-color').value,flicker:Number($('token-light-flicker').value),flickerSpeed:Number($('token-light-flicker-speed').value)}});toast('Токен сохранён.','success');}catch(error){toast(error.message,'error');}}
  async function saveSelectedWall(){const w=wallById(app.selected?.id);if(!w)return;Object.assign(w,{blocksVision:$('wall-blocks-vision').checked,blocksMovement:$('wall-blocks-movement').checked});try{await saveWalls();toast('Стена сохранена.','success');requestRender();}catch(error){toast(error.message,'error');}}
  async function saveSelectedDoor(){const d=doorById(app.selected?.id);if(!d)return;Object.assign(d,{name:$('door-name').value,width:Number($('door-width').value),openAngle:Number($('door-open-angle').value),open:$('door-open').checked,locked:$('door-locked').checked,allowPlayers:$('door-allow-players').checked,hidden:$('door-hidden').checked});try{await saveDoors();toast('Дверь сохранена.','success');requestRender();}catch(error){toast(error.message,'error');}}
  async function toggleSelectedDoor(){const d=doorById(app.selected?.id);if(!d)return;if(app.possessedTokenId&&(d.locked||d.allowPlayers===false)){toast(d.locked?'Дверь заперта.':'Этот объект доступен только мастеру.','error');return;}try{const r=await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/doors/${encodeURIComponent(d.id)}/toggle`,{method:'POST',body:commonBody()});Object.assign(d,r.door);refreshInspector();requestRender();}catch(error){toast(error.message,'error');}}
  async function deleteSelectedDoor(){const d=doorById(app.selected?.id);if(!d||!confirm('Удалить выбранную дверь?'))return;app.scene.doors=app.scene.doors.filter(x=>x.id!==d.id);selectObject(null,null);try{await saveDoors();toast('Дверь удалена.','success');}catch(error){toast(error.message,'error');}}
  async function saveSelectedCover(){const c=coverById(app.selected?.id);if(!c)return;Object.assign(c,{name:$('cover-name').value,shape:$('cover-shape').value,x:Number($('cover-x').value),y:Number($('cover-y').value),width:Number($('cover-width').value),height:Number($('cover-height').value),radius:Number($('cover-radius').value),mz:Number($('cover-mz').value),durability:Number($('cover-durability').value),damage:Number($('cover-damage').value),color:$('cover-color').value,elevation:Number($('cover-elevation')?.value||0),verticalHeight:Number($('cover-vertical-height')?.value||5),blocksMovement:$('cover-blocks-movement').checked,hidden:$('cover-hidden').checked});try{await saveCovers();toast('Укрытие сохранено.','success');requestRender();}catch(error){toast(error.message,'error');}}
  async function deleteSelectedCover(){const c=coverById(app.selected?.id);if(!c||!confirm('Удалить выбранное укрытие?'))return;app.scene.covers=app.scene.covers.filter(x=>x.id!==c.id);selectObject(null,null);try{await saveCovers();toast('Укрытие удалено.','success');}catch(error){toast(error.message,'error');}}
  async function saveSelectedLight(){const l=lightById(app.selected?.id);if(!l)return;Object.assign(l,{name:$('static-light-name').value,enabled:$('static-light-enabled').checked,bright:Number($('static-light-bright').value),dim:Number($('static-light-dim').value),angle:Number($('static-light-angle').value),rotation:Number($('static-light-rotation').value),color:$('static-light-color').value,intensity:Number($('static-light-intensity').value),flicker:Number($('static-light-flicker').value),flickerSpeed:Number($('static-light-flicker-speed').value)});try{await saveLights();toast('Источник света сохранён.','success');requestRender();}catch(error){toast(error.message,'error');}}

  function refreshTokenActions(){const box=$('token-actions'),token=selectedToken();if(!token||!canControlToken(token)||app.tool==='attack'){box.hidden=true;return;}const p=worldToScreen(visualTokenState(token));box.hidden=false;box.style.left=`${p.x}px`;box.style.top=`${p.y-tokenRadius(token)*app.view.scale-10}px`;$('quick-open-sheet').disabled=token.kind!=='character';}
  function beginAttackWithToken(token){if(!token||!canControlToken(token))return;$('attack-attacker').value=token.id;refreshAttackWeapons();setTool('attack');toast(`Атакующий: ${token.name}. Выберите цель.`);}
  function showQuickAttackPicker(target){const attacker=tokenById($('attack-attacker').value);if(!attacker||!target||attacker.id===target.id)return;const weapons=clientWeapons(attacker);if(!weapons.length){toast('У токена не найдено экипированное оружие. Сохраните лист персонажа.','error');return;}app.quickAttack={attackerId:attacker.id,targetId:target.id};$('attack-target').value=target.id;refreshAttackPreview();const p=worldToScreen(visualTokenState(target)),box=$('quick-attack');$('quick-attack-title').textContent=`${attacker.name} → ${target.name}`;$('quick-weapon-list').innerHTML=weapons.map(w=>`<div class="bm-quick-weapon"><div><strong>${esc(w.name)}</strong><small>${esc(w.hitDieNormal)} ${Number(w.hitBonus)>=0?'+':''}${Number(w.hitBonus||0)} · урон ${Number(w.damage||0)}</small></div><button class="bm-btn bm-primary" data-quick-weapon="${esc(w.id||w.slot||w.name)}" data-shot="normal">Огонь</button>${w.hitDieAimed?`<button class="bm-btn" data-quick-weapon="${esc(w.id||w.slot||w.name)}" data-shot="aimed">Прицел</button>`:'<span></span>'}</div>`).join('');box.hidden=false;box.style.left=`${clamp(p.x+18,10,app.dimensions.width-370)}px`;box.style.top=`${clamp(p.y+18,10,app.dimensions.height-250)}px`;}
  async function performAttack(weaponId,shotMode='normal',quick=false){const attackerTokenId=$('attack-attacker').value,targetTokenId=quick?app.quickAttack?.targetId:$('attack-target').value;if(!attackerTokenId||!targetTokenId||!weaponId){toast('Выберите атакующего, цель и оружие.','error');return;}if(app.attackPending)return;app.attackPending=true;const button=$('attack-roll-btn'),quickButtons=[...$('quick-weapon-list').querySelectorAll('button')];button.disabled=true;quickButtons.forEach(item=>item.disabled=true);try{const result=await api('/api/battlemap/attack',{method:'POST',body:commonBody({requestId:id(),sceneId:app.scene.id,attackerTokenId,targetTokenId,weaponId,shotMode,situationalModifier:quick?0:Number($('attack-modifier').value||0),targetMz:quick?null:($('attack-target-mz').value===''?null:Number($('attack-target-mz').value)),moved:quick?false:$('attack-moved').checked,spendResources:combatActive()&&(quick?true:$('attack-spend').checked),visibility:quick?'public':($('attack-private').checked?'master':'public')})});if(result.roll)startRollVisual(result.roll);showAttackResult(result.attack,true);}catch(error){toast(error.message,'error');}finally{app.attackPending=false;button.disabled=false;quickButtons.forEach(item=>item.disabled=false);}}
  async function rollAttack(){await performAttack($('attack-weapon').value,$('attack-shot-mode').value,false);}
  function showAttackResult(attack,own){if(!attack||app.seenAttackIds.has(attack.id))return;app.seenAttackIds.add(attack.id);if(app.seenAttackIds.size>300)app.seenAttackIds.delete(app.seenAttackIds.values().next().value);app.lastAttack=attack;app.attackLine={attackerTokenId:attack.attackerTokenId,targetTokenId:attack.targetTokenId,hit:attack.hit,until:Date.now()+1800};$('attack-result-card').hidden=false;$('attack-result').innerHTML=`<div class="${attack.hit?'bm-result-hit':'bm-result-miss'}">${attack.hit?'ПОПАДАНИЕ':attack.missRedirectTargetName?`ПРОМАХ ПО ЦЕЛИ · ПОПАДАНИЕ В ${esc(attack.missRedirectTargetName)}`:'ПРОМАХ'} · ${attack.total} против МЗ ${attack.targetMz}</div><div class="bm-result-grid"><div>Куб<br><strong>${esc(attack.hitDie)}: ${attack.roll}</strong></div><div>Бонус<br><strong>${Number(attack.hitBonus)>=0?'+':''}${attack.hitBonus}</strong></div><div>Дистанция<br><strong>${attack.distance} фт</strong></div><div>Урон<br><strong>${attack.damage} (${esc(attack.damageTag)})</strong></div><div>Базовая МЗ<br><strong>${attack.baseMz}</strong></div><div>Укрытие<br><strong>${attack.coverMz||'нет'}</strong></div></div>${attack.conditionalReasons?.length?`<p class="bm-muted">${attack.conditionalReasons.map(esc).join('<br>')}</p>`:''}`;$('attack-damage-actions').innerHTML=attack.hit?`<button class="bm-btn bm-primary" data-apply-damage="${attack.damage}">Применить урон ${attack.damage}</button><button class="bm-btn" data-apply-damage="${attack.damage}" data-bleeding="1">Урон + кровотечение</button>`:'';if(app.quickAttack&&attack.attackerTokenId===app.quickAttack.attackerId&&attack.targetTokenId===app.quickAttack.targetId){const box=$('quick-attack');$('quick-attack-title').textContent=attack.hit?`Попадание: ${attack.total} против МЗ ${attack.targetMz}`:`Промах: ${attack.total} против МЗ ${attack.targetMz}`;$('quick-weapon-list').innerHTML=master&&attack.hit?`<div class="bm-row"><button class="bm-btn bm-primary" data-quick-damage="${attack.damage}">Применить урон</button><button class="bm-btn" data-quick-damage="${attack.damage}" data-bleeding="1">+ Кровотечение</button></div>`:'<div class="bm-muted">Результат записан в журнал.</div>';box.hidden=false;}if(own)toast(attack.hit?'Атака попала.':attack.missRedirectTargetName?`Промах по цели: попадание в ${attack.missRedirectTargetName}.`:'Атака промахнулась.',attack.hit||attack.missRedirectTargetName?'success':'error');requestRender();}

  function bindV052Ui(){
    $('save-door-btn').onclick=saveSelectedDoor;$('delete-door-btn').onclick=deleteSelectedDoor;$('player-toggle-door-btn').onclick=toggleSelectedDoor;$('save-cover-btn').onclick=saveSelectedCover;$('delete-cover-btn').onclick=deleteSelectedCover;
    $('quick-attack-btn').onclick=()=>beginAttackWithToken(selectedToken());$('quick-rotate-left').onclick=()=>rotateSelected(-15);$('quick-rotate-right').onclick=()=>rotateSelected(15);$('quick-open-sheet').onclick=()=>{const t=selectedToken();if(t?.kind==='character')window.open(`/?mode=${mode}&characterId=${encodeURIComponent(t.refId)}`,'_blank');};$('quick-attack-cancel').onclick=()=>{app.quickAttack=null;$('quick-attack').hidden=true;setTool('select');};
    $('quick-weapon-list').onclick=async e=>{const weapon=e.target.closest('[data-quick-weapon]');if(weapon){await performAttack(weapon.dataset.quickWeapon,weapon.dataset.shot||'normal',true);return;}const damage=e.target.closest('[data-quick-damage]');if(damage){await applyLastDamage(damage.dataset.quickDamage,damage.dataset.bleeding==='1');$('quick-attack').hidden=true;app.quickAttack=null;setTool('select');}};
    canvas.addEventListener('dblclick',e=>{const world=screenToWorld(eventPoint(e)),door=hitTestDoor(world);if(door){e.preventDefault();e.stopPropagation();selectObject('door',door.id);toggleSelectedDoor();return;}if(app.draft?.type==='cover-poly')finishPolygonCover();});
    window.addEventListener('keydown',e=>{if(e.key==='Enter'&&app.draft?.type==='cover-poly'&&!isFormTarget(e.target)){e.preventDefault();finishPolygonCover();}});
    $('save-vision-btn').onclick=async()=>{try{await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}`,{method:'PUT',body:commonBody({settings:{fogMode:$('fog-mode').value,fogEnabled:$('fog-mode').value!=='off',visionEnabled:$('vision-enabled').checked,dynamicLightEnabled:$('dynamic-light-enabled').checked,globalIllumination:$('global-illumination').checked,masterSeesLighting:$('master-sees-lighting').checked,ambientDarkness:Number($('ambient-darkness').value)}})});toast('Настройки зрения сохранены.','success');}catch(error){toast(error.message,'error');}};
    ['master-sees-lighting','dynamic-light-enabled','global-illumination'].forEach(id=>$(id).addEventListener('change',requestRender));
  }


  /* ===== FATUM Battlemap v0.5.3: combat mode, possession, map checks and mini sheet ===== */
  app.possessedTokenId = null;
  app.skillTokenId = null;
  app.combatPending = false;

  const baseCanControlTokenV053 = canControlToken;
  canControlToken = function(token) {
    if (master && app.possessedTokenId) return token?.id === app.possessedTokenId;
    return baseCanControlTokenV053(token);
  };
  const baseViewerTokensV053 = viewerTokens;
  viewerTokens = function() {
    if (master && app.possessedTokenId) { const token=tokenById(app.possessedTokenId); return token && !token.defeated ? [token] : []; }
    return baseViewerTokensV053();
  };

  function combatActive(){return Boolean(app.battlemap?.combat?.active && app.battlemap.combat.sceneId===app.scene?.id);}
  function tokenForInitiative(entry){if(!entry||!app.scene)return null;return (app.scene.tokens||[]).filter(Boolean).find(token=>token.refId===entry.refId&&((entry.type==='npc'&&token.kind==='npc')||(entry.type==='character'&&token.kind==='character')))||null;}
  function tokenResources(token){if(!token)return{od:0,odMax:0,ob:0,obMax:0,morale:0,moraleMax:0};if(token.kind==='npc'){const n=npcById(token.refId)||{};return{od:n.od?.current||0,odMax:n.od?.max||0,ob:n.ob?.current||0,obMax:n.ob?.max||0,morale:n.morale?.current||0,moraleMax:n.morale?.max||0};}const st=characterById(token.refId)?.state||{},species=speciesStateClient(token),formBonus=species?.species==='pallid'&&species.pallid?.transformed?1:0,baseMax=Number(st.od??st.odMax??0),odMax=baseMax+formBonus;return{od:Number(st.odCurrent??odMax),odMax,ob:st.obCurrent??st.ob??0,obMax:st.ob??0,morale:st.morale?.current??0,moraleMax:st.morale?.max??0};}
  function combatParticipantImage(token){return tokenImageUrl(token)||'';}
  function refreshCombatModeUi(){
    const active=combatActive(),initiative=app.campaign?.initiative||{entries:[],currentIndex:0,round:1},strip=$('combat-strip');
    $('combat-toggle-btn').textContent=active?'■ Завершить бой':'⚔ Начать бой';
    strip.hidden=!active;
    if(active){strip.innerHTML=`<div class="bm-combat-round"><strong>Раунд ${initiative.round||1}</strong><small>Ход ${(initiative.currentIndex||0)+1}/${initiative.entries.length}</small></div>`+initiative.entries.map((entry,index)=>{const token=tokenForInitiative(entry);if(!token)return'';const r=tokenResources(token),img=combatParticipantImage(token);return`<div class="bm-init-card ${index===initiative.currentIndex?'active':''}" data-init-token="${esc(token.id)}">${img?`<img src="${esc(img)}">`:'<div></div>'}<div><strong>${esc(token.name)}</strong><small>Инициатива ${entry.score} · ОД ${r.od}/${r.odMax}${r.obMax?` · ОБ ${r.ob}/${r.obMax}`:''}</small></div></div>`;}).join('');}
    const current=initiative.entries?.[initiative.currentIndex||0],currentToken=tokenForInitiative(current),canEnd=Boolean(active&&(master||(currentToken&&canControlToken(currentToken))));$('end-turn-btn').hidden=!canEnd;$('attack-spend').checked=active;$('attack-spend').disabled=true;
  }
  const baseRefreshAllUiV053=refreshAllUi;refreshAllUi=function(){baseRefreshAllUiV053();refreshCombatModeUi();refreshPossessionUi();if(!$('mini-sheet').hidden&&selectedToken())showMiniSheet(selectedToken());};

  function openCombatModal(){const box=$('combat-participant-list');box.innerHTML=(app.scene?.tokens||[]).filter(t=>['character','npc'].includes(t.kind)&&t.refId&&!t.defeated).map(t=>{const img=tokenImageUrl(t);return`<label class="bm-combat-choice"> <input type="checkbox" value="${esc(t.id)}" checked>${img?`<img src="${esc(img)}">`:''}<span><strong>${esc(t.name)}</strong><small>${t.kind==='npc'?'NPC':'Персонаж'}</small></span></label>`;}).join('')||'<p class="bm-muted">На сцене нет персонажей или NPC.</p>';$('combat-modal').hidden=false;}
  async function startCombat(){if(app.combatPending)return;const tokenIds=[...$('combat-participant-list').querySelectorAll('input:checked')].map(x=>x.value);app.combatPending=true;$('combat-start-btn').disabled=true;try{await api('/api/battlemap/combat/start',{method:'POST',body:commonBody({sceneId:app.scene.id,tokenIds})});$('combat-modal').hidden=true;toast('Бой начался. Инициатива брошена.','success');}catch(e){toast(e.message,'error');}finally{app.combatPending=false;$('combat-start-btn').disabled=false;}}
  async function endCombat(){if(!confirm('Завершить бой и очистить инициативу?'))return;try{await api('/api/battlemap/combat/end',{method:'POST',body:commonBody()});toast('Бой завершён.','success');}catch(e){toast(e.message,'error');}}
  async function advanceCombat(){if(app.combatPending)return;app.combatPending=true;$('end-turn-btn').disabled=true;try{await api('/api/battlemap/combat/advance',{method:'POST',body:commonBody()});}catch(e){toast(e.message,'error');}finally{app.combatPending=false;$('end-turn-btn').disabled=false;}}

  function enterPossession(token){if(!master||!token)return;app.possessedTokenId=token.id;document.body.classList.add('bm-possessing');$('preview-player-vision').checked=true;selectObject('token',token.id);refreshPossessionUi();if(typeof refreshActionDock==='function')refreshActionDock();requestRender();toast(`Вы видите сцену глазами «${token.name}».`,'success');}
  function leavePossession(){app.possessedTokenId=null;document.body.classList.remove('bm-possessing');$('preview-player-vision').checked=false;refreshPossessionUi();if(typeof refreshActionDock==='function')refreshActionDock();requestRender();}
  function refreshPossessionUi(){const token=tokenById(app.possessedTokenId),banner=$('possess-banner');if(app.possessedTokenId&&!token){app.possessedTokenId=null;document.body.classList.remove('bm-possessing');$('preview-player-vision').checked=false;}banner.hidden=!token;if(token){$('possess-label').textContent=`Вы вселились в: ${token.name}`;if(app.selected?.id!==token.id)selectObject('token',token.id);}}

  function skillProfiles(token){
    if(token?.kind==='character'){const st=characterById(token.refId)?.state||{},skills=st._lanRollProfile?.skills||{};return Object.entries(skills).map(([name,p])=>({name,cube:p.cube||p.die||'1d6',bonus:Number(p.bonus||0)})).sort((a,b)=>a.name.localeCompare(b.name,'ru'));}
    if(token?.kind==='npc'){const npc=npcById(token.refId)||{},c=npc.characteristics||{},die=npc.successDie||'1d6';return[['Физическая сила','strength'],['Акробатика','dexterity'],['Скрытность','dexterity'],['Выдержка','endurance'],['Стойкость','endurance'],['Бдительность','concentration'],['Воля','concentration'],['Меткость','concentration'],['Анализ','intelligence'],['Медицина','intelligence'],['Убеждение','charisma'],['Запугивание','charisma']].map(([name,key])=>({name,cube:die,bonus:Number(c[key]||0)}));}
    return[];
  }
  function openSkillPopover(token){const profiles=skillProfiles(token);if(!profiles.length){toast('Для этого токена не найдены навыки.','error');return;}app.skillTokenId=token.id;const select=$('map-skill-select');select.innerHTML=profiles.map((p,i)=>`<option value="${i}">${esc(p.name)} · ${esc(p.cube)} ${p.bonus>=0?'+':''}${p.bonus}</option>`).join('');select._profiles=profiles;const p=worldToScreen(visualTokenState(token)),box=$('skill-popover');box.hidden=false;box.style.left=`${clamp(p.x+20,10,app.dimensions.width-320)}px`;box.style.top=`${clamp(p.y+20,70,app.dimensions.height-330)}px`;$('map-skill-result').textContent='';}
  async function rollMapSkill(){const token=tokenById(app.skillTokenId),profiles=$('map-skill-select')._profiles||[],profile=profiles[Number($('map-skill-select').value||0)];if(!token||!profile)return;try{const result=await api('/api/dice/check',{method:'POST',body:commonBody({characterId:token.kind==='character'?token.refId:null,skillName:profile.name,label:`${token.name}: ${profile.name}`,successDie:profile.cube,successBonus:profile.bonus,difficultyDie:$('map-difficulty-die').value,difficultyModifier:Number($('map-difficulty-mod').value||0),condition:$('map-skill-condition').value==='disadvantage'?'hindrance':$('map-skill-condition').value,visibility:'public'})});const r=result.roll;$('map-skill-result').innerHTML=`<strong>${esc(r.outcome)}</strong>: ${r.successTotal} против ${r.difficultyTotal}`;}catch(e){toast(e.message,'error');}}

  function woundText(w={}){return`Л ${w.light||0}/${w.lightMax||0} · С ${w.medium||0}/${w.mediumMax||0} · Т ${w.serious||0}/${w.seriousMax||0}${w.critical?' · КРИТ':''}`;}
  function showMiniSheet(token){if(!token)return;const body=$('mini-sheet-body');$('mini-sheet-title').textContent=token.name;if(token.kind==='character'){const st=characterById(token.refId)?.state||{},r=tokenResources(token),weapons=clientWeapons(token);body.innerHTML=`<div class="bm-mini-stat"><span>ОД</span><strong>${r.od}/${r.odMax}</strong></div><div class="bm-mini-stat"><span>ОБ</span><strong>${r.ob}/${r.obMax}</strong></div><div class="bm-mini-stat"><span>Мораль</span><strong>${r.morale}/${r.moraleMax}</strong></div><div class="bm-mini-stat"><span>Ранения</span><strong>${esc(woundText(st.wounds||{}))}</strong></div><h3>Оружие</h3>${weapons.map(w=>`<div class="bm-mini-stat"><span>${esc(w.name)}</span><strong>${esc(w.hitDieNormal)} ${Number(w.hitBonus)>=0?'+':''}${w.hitBonus}</strong></div>`).join('')||'<p class="bm-muted">Нет экипированного оружия.</p>'}`;}else{const n=npcById(token.refId)||{},r=tokenResources(token);body.innerHTML=`<div class="bm-mini-stat"><span>ОД</span><strong>${r.od}/${r.odMax}</strong></div><div class="bm-mini-stat"><span>Мораль</span><strong>${r.morale}/${r.moraleMax}</strong></div><div class="bm-mini-stat"><span>Ранения</span><strong>${esc(woundText(n.wounds||{}))}</strong></div><div class="bm-mini-stat"><span>Оружие</span><strong>${esc(n.weapon?.name||'—')}</strong></div><p class="bm-muted">${esc(n.notes||'')}</p>`;}$('mini-sheet').hidden=false;}

  async function replaceSelectedTokenImage(file){const token=selectedToken();if(!token||!file)return;try{const up=await uploadImage(file,'token');await updateToken(token,{imageUrl:up.url});token.imageUrl=up.url;toast('Изображение токена заменено.','success');requestRender();}catch(e){toast(e.message,'error');}}


  /* ===== FATUM Battlemap v0.5.4: action dock, wounds, melee, live editing and WASD ===== */
  app.actionTarget = null;
  app.liveTimers = new Map();
  app.wasdSaveTimer = null;

  function tokenCondition(token) {
    if (!token) return { wounds:{}, bleeding:false, critical:false, dead:false, defeated:false, injured:false };
    if (token.kind === 'character') {
      const st = characterById(token.refId)?.state || {}, wounds = st.wounds || {}, medical = st.medical || {};
      const critical = Boolean(wounds.critical), dead = Boolean(medical.dead), injured = dead || critical || Number(wounds.light||0)+Number(wounds.medium||0)+Number(wounds.serious||0)>0;
      return { wounds, bleeding:Boolean(medical.bleeding), critical, dead, defeated:dead, injured };
    }
    if (token.kind === 'npc') {
      const npc = npcById(token.refId) || {}, wounds = npc.wounds || {}, critical = Boolean(wounds.critical), dead = Boolean(npc.dead), defeated = dead || Boolean(npc.outOfCombat), injured = defeated || critical || Number(wounds.light||0)+Number(wounds.medium||0)+Number(wounds.serious||0)>0;
      return { wounds, bleeding:Boolean(npc.bleeding), critical, dead, defeated, injured };
    }
    return { wounds:{}, bleeding:false, critical:false, dead:false, defeated:Boolean(token.defeated), injured:Boolean(token.defeated) };
  }

  function tokenActionState(token) {
    if (!token) return {};
    if (token.kind === 'character') return characterById(token.refId)?.state?._battlemapActions || {};
    if (token.kind === 'npc') return npcById(token.refId)?._battlemapActions || {};
    return {};
  }

  function drawTopDownBrackets(target, radius, color, width) {
    const r=radius+5/app.view.scale,l=Math.max(radius*.38,12/app.view.scale);target.strokeStyle=color;target.lineWidth=width/app.view.scale;target.lineCap='square';
    for(const [sx,sy] of [[-1,-1],[1,-1],[1,1],[-1,1]]){target.beginPath();target.moveTo(sx*r,sy*(r-l));target.lineTo(sx*r,sy*r);target.lineTo(sx*(r-l),sy*r);target.stroke();}
  }

  function tokenShapePath(target, radius, shape) {
    target.beginPath();
    if (shape === 'square') target.rect(-radius, -radius, radius * 2, radius * 2);
    else if (shape === 'rounded') {
      const r = radius * .28, x = -radius, y = -radius, w = radius * 2, h = radius * 2;
      target.moveTo(x + r, y); target.lineTo(x + w - r, y); target.quadraticCurveTo(x + w, y, x + w, y + r);
      target.lineTo(x + w, y + h - r); target.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
      target.lineTo(x + r, y + h); target.quadraticCurveTo(x, y + h, x, y + h - r);
      target.lineTo(x, y + r); target.quadraticCurveTo(x, y, x + r, y);
    } else target.arc(0, 0, radius, 0, Math.PI * 2);
    target.closePath();
  }

  function drawWoundBadge(target, token, visual, radius, condition) {
    if (!condition.injured && !condition.bleeding) return;
    const w=condition.wounds||{}, parts=[['Л',w.light||0,'#d9c866'],['С',w.medium||0,'#e49a4d'],['Т',w.serious||0,'#dc5e59']].filter(x=>x[1]>0);
    target.save();target.translate(visual.x,visual.y-radius-11/app.view.scale);target.font=`${10/app.view.scale}px Segoe UI`;target.textAlign='center';target.textBaseline='middle';
    const labels=[];for(const [letter,count,color] of parts)labels.push({text:`${letter}${count}`,color});if(condition.bleeding)labels.push({text:'КР',color:'#d51f2c'});if(condition.critical)labels.push({text:'!',color:'#ff3131'});if(condition.dead)labels.push({text:'†',color:'#8f1515'});else if(condition.defeated)labels.push({text:'×',color:'#777'});
    const total=labels.length*22/app.view.scale;let x=-total/2+11/app.view.scale;for(const item of labels){target.fillStyle='rgba(10,12,16,.88)';target.fillRect(x-10/app.view.scale,-8/app.view.scale,20/app.view.scale,16/app.view.scale);target.fillStyle=item.color;target.fillText(item.text,x,0);x+=22/app.view.scale;}target.restore();
  }

  function drawToken(target, token) {
    const radius=tokenRadius(token),visual=visualTokenState(token),display=token.display||{},free=display.shape==='free',condition=tokenCondition(token);
    const selected=app.selected?.type==='token'&&app.selected.id===token.id,owned=canControlToken(token),activeTurn=activeInitiativeToken(token),url=tokenImageUrl(token);
    target.save();target.translate(visual.x,visual.y);target.rotate((visual.rotation||0)*Math.PI/180);target.globalAlpha=(condition.dead||condition.defeated)?.45:clamp(Number(display.opacity??1),.1,1);if(condition.dead||condition.defeated)target.filter='grayscale(1)';
    if(!free){tokenShapePath(target,radius,display.shape||'circle');target.save();target.clip();}else target.save();
    if(display.backgroundEnabled!==false){target.fillStyle=token.kind==='npc'?'#713d3d':token.kind==='character'?'#39556d':'#4b4e58';target.fillRect(-radius,-radius,radius*2,radius*2);}
    if(url){const image=resolvedImages.get(url);if(image){target.save();if(display.rotateImage===false)target.rotate(-(visual.rotation||0)*Math.PI/180);const fit=free?'contain':(display.fit||'cover'),aspect=image.naturalWidth/Math.max(1,image.naturalHeight),box=radius*2;let dw,dh;if((fit==='contain'&&aspect>1)||(fit==='cover'&&aspect<1)){dw=box;dh=box/aspect;}else{dh=box;dw=box*aspect;}const scale=clamp(Number(display.imageScale||1),.25,3);dw*=scale;dh*=scale;target.drawImage(image,-dw/2+Number(display.offsetX||0)*radius,-dh/2+Number(display.offsetY||0)*radius,dw,dh);target.restore();}else requestRenderWhenImageReady(url);}
    target.restore();target.filter='none';target.globalAlpha=1;
    const baseColor=condition.dead?'#6e2020':condition.defeated?'#686868':condition.critical?'#ff3b3b':activeTurn?'#73e08c':selected?'#ffd36a':owned?'#83b7e4':(display.borderColor||'#d7d7d7');
    if(free){if(display.borderEnabled!==false&&!selected)drawTopDownBrackets(target,radius,baseColor,2);if(selected||activeTurn||condition.critical||condition.dead)drawTopDownBrackets(target,radius+4/app.view.scale,baseColor,selected?4:3);}else if(display.borderEnabled!==false||selected||activeTurn||condition.critical||condition.dead){tokenShapePath(target,radius,display.shape||'circle');target.strokeStyle=baseColor;target.lineWidth=(selected||activeTurn||condition.critical?5:2)/app.view.scale;target.stroke();}
    if(condition.critical&&!condition.dead){target.shadowBlur=18/app.view.scale;target.shadowColor='#ff2020';if(free)drawTopDownBrackets(target,radius+9/app.view.scale,'rgba(255,35,35,.7)',3);else{tokenShapePath(target,radius+7/app.view.scale,display.shape||'circle');target.strokeStyle='rgba(255,35,35,.72)';target.lineWidth=3/app.view.scale;target.stroke();}target.shadowBlur=0;requestRender();}
    if(condition.dead||condition.defeated||token.defeated){target.strokeStyle='#cf3f3f';target.lineWidth=5/app.view.scale;target.beginPath();target.moveTo(-radius*.72,-radius*.72);target.lineTo(radius*.72,radius*.72);target.moveTo(radius*.72,-radius*.72);target.lineTo(-radius*.72,radius*.72);target.stroke();}
    if(selected&&canControlToken(token)){const handleY=-radius-24/app.view.scale;target.beginPath();target.arc(0,handleY,8/app.view.scale,0,Math.PI*2);target.fillStyle='#ffd36a';target.fill();target.strokeStyle='#4b3217';target.lineWidth=1.5/app.view.scale;target.stroke();}
    target.restore();drawWoundBadge(target,token,visual,radius,condition);
    if(display.showName!==false){target.save();target.font=`${Math.max(12,13/app.view.scale)}px Segoe UI`;target.textAlign='center';target.textBaseline='top';const labelY=visual.y+radius+8/app.view.scale,textWidth=target.measureText(token.name).width;target.fillStyle='rgba(10,12,16,.82)';target.fillRect(visual.x-textWidth/2-5/app.view.scale,labelY-2/app.view.scale,textWidth+10/app.view.scale,18/app.view.scale);target.fillStyle=condition.dead?'#b77070':condition.defeated?'#aaa':condition.critical?'#ff8a83':'#f2eadc';target.fillText(token.name,visual.x,labelY);target.restore();}
  }

  function weaponProperty(weapon){const text=String(weapon?.description||'');const labels=[];for(const [rx,label] of [[/Подавлен/i,'Подавление'],[/Шкваль/i,'Шквальный огонь'],[/Мощный удар/i,'Мощный удар'],[/Оглуш/i,'Оглушение'],[/Шок/i,'Шок'],[/Быстрое/i,'Быстрое'],[/Удержание дистанции/i,'Древковое'],[/Громоздк/i,'Громоздкое'],[/бронебойн/i,'Бронебойное'],[/взрыв/i,'Взрывное']])if(rx.test(text))labels.push(label);return labels.join(' · ');}
  function speciesNaturalWeaponsClient(token){
    const st=speciesStateClient(token);if(!st||!speciesFormActiveClient(st))return[];
    if(st.naturalWeapons?.length)return st.naturalWeapons.map(weapon=>({...weapon,melee:true,type:'Оружие ближнего боя',naturalWeapon:true}));
    const skills=skillProfiles(token),bonus=(names)=>Math.max(...names.map(name=>Number(skills.find(skill=>skill.name===name)?.bonus||0)),0),make=(id,name,die,damage,cost,range,names,description,extra={})=>({id,slot:id,name,profile:name,type:'Оружие ближнего боя',melee:true,naturalWeapon:true,hitDieNormal:die,hitDieAimed:'',hitBonus:bonus(names),damage,damageTag:extra.damageTag||'medium',odCost:cost,obCost:0,range,description,...extra});
    if(st.species==='pallid'&&st.pallid?.transformed)return[
      make('pallid-claws','Когти Вечного','1d10',3,2,5,['Физическая сила','Акробатика'],'Обычная атака, Встречный удар и свободная атака.'),
      make('pallid-rending','Разрывающий удар','1d8',4,3,5,['Физическая сила'],'Тяжёлый удар; недоступен для Встречного удара и свободной атаки.',{damageTag:'heavy',counterAllowed:false})
    ];
    if(st.species==='werewolf'&&st.werewolf?.transformed)return[
      make('werewolf-claws','Когти волколака','1d8',3,2,5,['Физическая сила','Акробатика'],'Обычная атака, Встречный удар и свободная атака.'),
      make('werewolf-bite','Укус','1d8',4,3,5,['Физическая сила'],'Не используется для Встречного удара или свободной атаки; может передать ликантропию.',{damageTag:'heavy',counterAllowed:false,lycanthropyRisk:true}),
      make('werewolf-takedown','Сбивающий бросок','1d6',2,2,5,['Физическая сила','Акробатика'],'После ранения можно дополнительно потратить 1 ОД и сбить цель с ног.',{damageTag:'light',counterAllowed:false,supportsTakedown:true})
    ];
    if(st.species==='rokurokubi'&&st.rokurokubi?.neckExtended&&!st.rokurokubi?.wrappedTargetTokenId)return[
      make('rokurokubi-lunge','Молниеносный выпад','1d8',3,2,10,['Физическая сила','Акробатика'],'Обычная атака, Встречный удар и свободная атака; дистанция 10 футов.'),
      make('rokurokubi-wrap','Обвивающий захват','1d6',1,2,10,['Физическая сила','Акробатика'],'Только обычная атака; после ранения цель можно Обвить.',{damageTag:'light',counterAllowed:false,wrapOnHit:true})
    ];
    return[];
  }
  function allClientWeapons(token){
    const st=speciesStateClient(token),base=clientWeapons(token).map(w=>({...w})),natural=speciesNaturalWeaponsClient(token),naturalIds=new Set(['pallid-claws','pallid-rending','claws','rending','werewolf-claws','werewolf-bite','werewolf-takedown','rokurokubi-lunge','rokurokubi-wrap']);
    const ordinary=base.filter(weapon=>!weapon.naturalWeapon&&!naturalIds.has(weapon.id));
    if(st?.species==='werewolf'&&st.werewolf?.transformed)return natural;
    if(st?.species==='rokurokubi'&&st.rokurokubi?.neckExtended)return natural;
    const list=st?.species==='pallid'&&st.pallid?.transformed?[...natural,...ordinary]:base;
    if(!speciesFormActiveClient(st)&&!list.some(w=>w.id==='unarmed'||w.name==='Безоружный бой')){const skills=skillProfiles(token),force=skills.find(s=>s.name==='Физическая сила');list.push({id:'unarmed',name:'Безоружный бой',melee:true,hitDieNormal:'1d4',hitBonus:Number(force?.bonus||0),damage:1,damageTag:'light',odCost:2,obCost:0,range:5,description:'Безоружная атака. Встречный бросок; бонус Физической силы.'});}
    return list;
  }

  const tacticalDefs={
    retreat:{label:'Отход',icon:'↩',cost:2,desc:'Безопасно выйти из ближнего боя, не провоцируя свободную атаку.'},
    sprint:{label:'Рывок',icon:'»',cost:2,desc:'Удвоить дистанцию перемещения в этом раунде.'},
    crossing:{label:'Перебежка',icon:'⇢',cost:1,desc:'Получить +2 МЗ до начала следующего хода и игнорировать Зону обстрела.'},
    charge:{label:'Натиск',icon:'➤',cost:1,desc:'Сблизиться с целью до ближнего боя без провоцирования Зоны обстрела.'},
    block:{label:'Блок',icon:'◈',cost:1,desc:'Полностью отменить одну следующую атаку ближнего боя.'},
    jump:{label:'Прыжок',icon:'⌃',cost:1,desc:'Проверка Выдержки; результат равен дальности прыжка в футах.'},
    peek:{label:'Выглянуть',icon:'◑',cost:0,desc:'Если токен находится на соседней клетке от укрытия или ближе, его собственное укрытие не применяется к цели этой стрельбы. Входящие атаки по-прежнему получают МЗ укрытия.'}
  };

  function combatCanAct(token){if(!combatActive())return false;const initiative=app.campaign?.initiative||{},entry=initiative.entries?.[initiative.currentIndex||0],active=tokenForInitiative(entry);return Boolean(active&&active.id===token.id&&(master||canControlToken(token)));}
  function setActionDescription(text){$('action-description').textContent=text||'Выберите действие.';}
  function actionButtonHtml(id,icon,label,cost,desc,extra=''){return `<button class="bm-action-button ${extra}" data-dock-action="${esc(id)}" title="${esc(desc||label)}"><span class="icon">${icon}</span><span class="label">${esc(label)}</span>${cost!==null&&cost!==undefined?`<span class="cost">${cost} ОД</span>`:''}</button>`;}
  function refreshActionDock(){const token=selectedToken(),dock=$('action-dock'),condition=tokenCondition(token);if(!token||!canControlToken(token)||token.defeated||condition.dead||condition.defeated){dock.hidden=true;return;}dock.hidden=false;$('action-token-name').textContent=token.name;const url=tokenImageUrl(token),portrait=$('action-portrait');portrait.style.backgroundImage=url?`url("${url.replace(/"/g,'%22')}")`:'';portrait.textContent=url?'':token.name.slice(0,2).toUpperCase();const r=tokenResources(token),w=condition.wounds||{};const movement=movementForToken(token);$('action-resource-line').textContent=`ОД ${r.od}/${r.odMax}${r.obMax?` · ОБ ${r.ob}/${r.obMax}`:''} · Мораль ${r.morale}/${r.moraleMax}${movement?` · Ход ${movement.remaining.toFixed(1)}/${movement.limit.toFixed(1)} фт`:''}`;
    $('action-wounds').innerHTML=`<span class="bm-wound-pill light">Л ${w.light||0}/${w.lightMax||0}</span><span class="bm-wound-pill medium">С ${w.medium||0}/${w.mediumMax||0}</span><span class="bm-wound-pill serious">Т ${w.serious||0}/${w.seriousMax||0}</span>${condition.bleeding?'<span class="bm-wound-pill critical">Кровотечение</span>':''}${condition.critical?'<span class="bm-wound-pill critical">КРИТИЧЕСКОЕ</span>':''}${condition.dead?'<span class="bm-wound-pill dead">МЁРТВ</span>':condition.defeated?'<span class="bm-wound-pill dead">ВЫВЕДЕН</span>':''}`;
    const weapons=allClientWeapons(token),canAct=combatCanAct(token),active=tokenActionState(token);let html='';
    for(const weapon of weapons){const melee=Boolean(weapon.melee||weapon.id==='unarmed'||/ближнего|безоруж/i.test(`${weapon.type||''} ${weapon.name||''}`)),prop=weaponProperty(weapon),icon=melee?(weapon.id==='unarmed'?'✊':'⚔'):'⌖',wid=weapon.id||weapon.slot||weapon.name;html+=actionButtonHtml(`${melee?'melee':'ranged'}:${wid}`,icon,weapon.name,weapon.odCost??2,`${weapon.hitDieNormal} ${Number(weapon.hitBonus)>=0?'+':''}${weapon.hitBonus||0} · урон ${weapon.damage||0}${prop?` · ${prop}`:''}`,'weapon');if(melee&&/Мощный удар/i.test(String(weapon.description||'')))html+=actionButtonHtml(`melee-power:${wid}`,'✦','Мощный удар',(weapon.odCost??2)+1,`Атака ${weapon.name}: +1 к урону за дополнительное ОД.`,'weapon');if(melee&&/Оглуш/i.test(String(weapon.description||'')))html+=actionButtonHtml(`melee-stun:${wid}`,'✹','Оглушение',(weapon.odCost??2)+1,`При попадании: урон и -1 к следующему встречному броску цели.`,'weapon');if(!melee&&weapon.hitDieAimed)html+=actionButtonHtml(`aimed:${wid}`,'◎',`Прицел: ${weapon.name}`,weapon.aimedOdCost??((weapon.odCost??1)+1),`Прицельная атака ${weapon.hitDieAimed}`,'weapon');}
    for(const [id,def] of Object.entries(tacticalDefs))html+=actionButtonHtml(`tactical:${id}`,def.icon,def.label,def.cost,def.desc,active[id]?'active':'');if(app.pendingCounter&&app.pendingCounter.defenderTokenId===token.id&&Date.now()<app.pendingCounter.expiresAt)html+=actionButtonHtml(`counter:${app.pendingCounter.attackId}`,'↯','Встречный удар',app.pendingCounter.cost||1,'Немедленно нанести урон без дополнительного броска. ОД вычитается из ближайшего хода.','active');html+=actionButtonHtml('items','🧰','Предметы',null,'Использовать расходник или гранату');html+=actionButtonHtml('skill','🎲','Навык',null,'Проверка навыка');html+=actionButtonHtml('sheet','▤','Мини-лист',null,'Открыть компактный лист');if(token.kind==='character'&&token.refId)html+=actionButtonHtml('full-sheet','▦','Полный лист',null,master?'Открыть полный лист персонажа в мастерском режиме':'Открыть полный лист своего персонажа');if(master)html+=app.possessedTokenId?actionButtonHtml('leave-possession','↩','Вернуться',null,'Вернуться в режим мастера'):actionButtonHtml('possess','👁','Вселиться',null,`Смотреть и действовать от лица «${token.name}»`);$('action-slots').innerHTML=html;
    $('action-slots').querySelectorAll('[data-dock-action]').forEach(btn=>{const key=btn.dataset.dockAction;if((key.startsWith('ranged:')||key.startsWith('aimed:')||key.startsWith('melee:')||key.startsWith('melee-power:')||key.startsWith('melee-stun:')||key.startsWith('tactical:'))&&!canAct)btn.disabled=true;btn.onmouseenter=()=>setActionDescription(btn.title);btn.onmouseleave=()=>setActionDescription(app.actionTarget?'Выберите токен цели.':'Выберите действие.');});
  }

  function beginDockTarget(type,weaponId,shotMode='normal',specialMode=null){const token=selectedToken();if(!token||!canControlToken(token))return;app.actionTarget={type,attackerId:token.id,weaponId,shotMode,specialMode};document.body.classList.add('bm-targeting');setTool('select');setActionDescription(type==='melee'?'Выберите соседний токен для встречного броска.':'Выберите токен цели на карте.');toast('Выберите цель.');}
  function cancelDockTarget(){app.actionTarget=null;app.pendingTargetPart=null;document.body.classList.remove('bm-targeting');setActionDescription('Выберите действие.');}

  async function performMelee(target){const mode=app.actionTarget,attacker=tokenById(mode?.attackerId);if(!mode||!attacker||!target||target.id===attacker.id||app.attackPending)return;app.attackPending=true;try{const result=await api('/api/battlemap/melee',{method:'POST',body:commonBody({requestId:id(),sceneId:app.scene.id,attackerTokenId:attacker.id,targetTokenId:target.id,weaponId:mode.weaponId,specialMode:mode.specialMode||null,targetPart:app.pendingTargetPart||null,spendResources:combatActive(),autoApplyDamage:true,visibility:'public'})});if(result.roll)startRollVisual(result.roll);showMeleeResult(result.attack,true);renderAutoDamageResult(result.damageResult);if(result.shockResult)toast(result.shockResult.success?'Цель выдержала Шок.':'Шок: цель потеряет 1 ОД в следующий ход.',result.shockResult.success?'success':'error');await fetchAll(true);}catch(e){toast(e.message,'error');}finally{app.attackPending=false;cancelDockTarget();}}
  function showMeleeResult(attack,own){if(!attack||app.seenAttackIds.has(attack.id))return;app.seenAttackIds.add(attack.id);app.lastAttack=attack;app.attackLine={attackerTokenId:attack.attackerTokenId,targetTokenId:attack.targetTokenId,hit:attack.hit,until:Date.now()+1800};$('attack-result-card').hidden=false;const isCounter=attack.kind==='melee-counter',isFree=attack.kind==='melee-free';const defender=tokenById(attack.targetTokenId),mayCounter=Boolean(attack.counterAvailable&&defender&&(master||canControlToken(defender)));if(mayCounter){app.pendingCounter={attackId:attack.id,defenderTokenId:defender.id,cost:Number(attack.counterCost||1),expiresAt:Number(attack.counterExpiresAt||Date.now()+120000)};toast(`Доступен Встречный удар за ${attack.counterCost||1} ОД.`,'success');setTimeout(()=>{if(app.pendingCounter?.attackId===attack.id){app.pendingCounter=null;refreshActionDock();}},121000);}if(isCounter&&app.pendingCounter?.attackId===attack.parentAttackId)app.pendingCounter=null;const outcome=isCounter?'ВСТРЕЧНЫЙ УДАР':isFree?(attack.hit?'СВОБОДНАЯ АТАКА · ПОПАДАНИЕ':attack.tie?'СВОБОДНАЯ АТАКА · НИЧЬЯ':'СВОБОДНАЯ АТАКА · ПРОМАХ'):attack.hit?'ПОПАДАНИЕ':attack.tie?'НИЧЬЯ':'ЗАЩИТНИК ПОБЕДИЛ';const details=isCounter?`<div class="bm-result-grid"><div>Защитник<br><strong>${esc(attack.actorName||'Защитник')}</strong></div><div>Цель<br><strong>${esc(tokenById(attack.targetTokenId)?.name||'Атакующий')}</strong></div><div>Оружие<br><strong>${esc(attack.weapon.name)}</strong></div><div>Урон<br><strong>${attack.damage}</strong></div></div>`:`<div class="bm-result-grid"><div>Атакующий<br><strong>${attack.attackerRoll} + ${attack.attackerBonus} = ${attack.attackerTotal}</strong></div><div>Защитник<br><strong>${attack.defenderRoll} + ${attack.defenderBonus} = ${attack.defenderTotal}</strong></div><div>Оружие<br><strong>${esc(attack.weapon.name)}</strong></div><div>Урон<br><strong>${attack.damage}</strong></div></div>`;$('attack-result').innerHTML=`<div class="${attack.hit?'bm-result-hit':'bm-result-miss'}">${outcome}</div>${details}${attack.counterAvailable?`<p class="bm-muted">Защитник может потратить ${attack.counterCost||1} ОД на Встречный удар без нового броска.</p>`:''}`;$('attack-damage-actions').innerHTML=attack.hit?`<button class="bm-btn bm-primary" data-apply-damage="${attack.damage}">Применить урон</button>`:mayCounter?`<button class="bm-btn bm-primary" data-melee-counter="${esc(attack.id)}">Встречный удар · ${attack.counterCost||1} ОД</button>`:'';refreshActionDock();if(own)toast(outcome,attack.hit?'success':'error');requestRender();}
  async function performCounter(attackId){try{const result=await api('/api/battlemap/melee-counter',{method:'POST',body:commonBody({requestId:id(),attackId,autoApplyDamage:true})});showMeleeResult(result.attack,true);app.pendingCounter=null;renderAutoDamageResult(result.damageResult);await fetchAll(true);}catch(e){toast(e.message,'error');}}

  async function useTacticalAction(actionId){const token=selectedToken(),def=tacticalDefs[actionId];if(!token||!def)return;try{const result=await api('/api/battlemap/tactical-action',{method:'POST',body:commonBody({requestId:id(),sceneId:app.scene.id,tokenId:token.id,actionId})});toast(`${def.label}: ${result.preview?'вне боя ОД не тратятся':result.toggledOff?'действие снято, ОД возвращены':'применено'}.`,'success');await fetchAll(true);}catch(e){toast(e.message,'error');}}

  const baseOnPointerDownV054=onPointerDown;
  onPointerDown=function(event){if(app.actionTarget&&event.button===0&&app.scene){const world=screenToWorld(eventPoint(event)),target=hitTestToken(world);if(target&&target.id!==app.actionTarget.attackerId){event.preventDefault();if(app.actionTarget.type==='melee')performMelee(target);else{const m=app.actionTarget,attacker=tokenById(m.attackerId);$('attack-attacker').value=attacker.id;$('attack-target').value=target.id;app.quickAttack={attackerId:attacker.id,targetId:target.id};performAttack(m.weaponId,m.shotMode,true).finally(cancelDockTarget);}return;}if(target?.id===app.actionTarget.attackerId)toast('Нужно выбрать другой токен.','error');return;}return baseOnPointerDownV054(event);};

  const baseShowAttackResultV054=showAttackResult;
  showAttackResult=function(attack,own){if(attack?.kind?.startsWith('melee'))return showMeleeResult(attack,own);return baseShowAttackResultV054(attack,own);};

  function collectTokenPatch(){return{name:$('token-name').value,x:Number($('token-x').value),y:Number($('token-y').value),size:Number($('token-size').value),rotation:Number($('token-rotation').value),mzOverride:$('token-mz').value===''?null:Number($('token-mz').value),coverBonus:Number($('token-cover-bonus').value||0),elevation:Number($('token-elevation')?.value||0),hidden:$('token-hidden').checked,locked:$('token-locked').checked,defeated:$('token-defeated').checked,display:{shape:$('token-display-shape').value,fit:$('token-display-fit').value,imageScale:Number($('token-image-scale').value),opacity:Number($('token-opacity').value),offsetX:Number($('token-image-offset-x').value),offsetY:Number($('token-image-offset-y').value),borderColor:$('token-border-color').value,borderEnabled:$('token-border-enabled').checked,backgroundEnabled:$('token-background-enabled').checked,showGroupMarker:$('token-group-marker-enabled').checked,showName:$('token-show-name').checked,rotateImage:$('token-rotate-image').checked,autoRotateOnMove:$('token-auto-rotate-move').checked},vision:{enabled:$('token-vision-enabled').checked,range:Number($('token-vision-range').value),angle:Number($('token-vision-angle').value)},light:{enabled:$('token-light-enabled').checked,bright:Number($('token-light-bright').value),dim:Number($('token-light-dim').value),angle:Number($('token-light-angle').value),color:$('token-light-color').value,flicker:Number($('token-light-flicker').value),flickerSpeed:Number($('token-light-flicker-speed').value)}};}
  function scheduleLive(key,fn,delay=220){clearTimeout(app.liveTimers.get(key));app.liveTimers.set(key,setTimeout(async()=>{try{await fn();}catch(e){toast(`Не удалось применить изменение: ${e.message}`,'error');}},delay));}
  function liveToken(){const t=selectedToken();if(!t||(!master&&!canControlToken(t)))return;const patch=collectTokenPatch();Object.assign(t,{...patch,display:{...t.display,...patch.display},vision:{...t.vision,...patch.vision},light:{...t.light,...patch.light}});requestRender();scheduleLive('token',()=>updateToken(t,patch));}
  function liveWall(){const w=wallById(app.selected?.id);if(!w||!master)return;Object.assign(w,{blocksVision:$('wall-blocks-vision').checked,blocksMovement:$('wall-blocks-movement').checked});requestRender();scheduleLive('wall',saveWalls);}
  function liveDoor(){const d=doorById(app.selected?.id);if(!d||!master)return;Object.assign(d,{name:$('door-name').value,width:Number($('door-width').value),openAngle:Number($('door-open-angle').value),open:$('door-open').checked,locked:$('door-locked').checked,allowPlayers:$('door-allow-players').checked,hidden:$('door-hidden').checked});requestRender();scheduleLive('door',saveDoors);}
  function liveCover(){const c=coverById(app.selected?.id);if(!c||!master)return;Object.assign(c,{name:$('cover-name').value,shape:$('cover-shape').value,x:Number($('cover-x').value),y:Number($('cover-y').value),width:Number($('cover-width').value),height:Number($('cover-height').value),radius:Number($('cover-radius').value),mz:Number($('cover-mz').value),durability:Number($('cover-durability').value),damage:Number($('cover-damage').value),color:$('cover-color').value,elevation:Number($('cover-elevation')?.value||0),verticalHeight:Number($('cover-vertical-height')?.value||5),blocksMovement:$('cover-blocks-movement').checked,hidden:$('cover-hidden').checked});requestRender();scheduleLive('cover',saveCovers);}
  function liveLight(){const l=lightById(app.selected?.id);if(!l||!master)return;Object.assign(l,{name:$('static-light-name').value,enabled:$('static-light-enabled').checked,bright:Number($('static-light-bright').value),dim:Number($('static-light-dim').value),angle:Number($('static-light-angle').value),rotation:Number($('static-light-rotation').value),color:$('static-light-color').value,intensity:Number($('static-light-intensity').value),flicker:Number($('static-light-flicker').value),flickerSpeed:Number($('static-light-flicker-speed').value)});requestRender();scheduleLive('light',saveLights);}

  function clientSegmentIntersection(a,b,c,d){const o=(p,q,r)=>(q.x-p.x)*(r.y-p.y)-(q.y-p.y)*(r.x-p.x),e=1e-7,o1=o(a,b,c),o2=o(a,b,d),o3=o(c,d,a),o4=o(c,d,b);return((o1>e&&o2<-e)||(o1<-e&&o2>e))&&((o3>e&&o4<-e)||(o3<-e&&o4>e));}
  function clientPointSegmentDistance(p,a,b){const dx=b.x-a.x,dy=b.y-a.y,l=dx*dx+dy*dy;if(l<1e-12)return Math.hypot(p.x-a.x,p.y-a.y);const t=clamp(((p.x-a.x)*dx+(p.y-a.y)*dy)/l,0,1);return Math.hypot(p.x-(a.x+dx*t),p.y-(a.y+dy*t));}
  function clientSegmentDistance(a,b,c,d){if(clientSegmentIntersection(a,b,c,d))return 0;return Math.min(clientPointSegmentDistance(a,c,d),clientPointSegmentDistance(b,c,d),clientPointSegmentDistance(c,a,b),clientPointSegmentDistance(d,a,b));}
  function clientMovementSegments(){const result=[];for(const wall of app.scene?.walls||[]){if(!wall.blocksMovement)continue;const doors=(app.scene.doors||[]).filter(d=>d.wallId===wall.id).map(doorGeometry).sort((a,b)=>a.t1-b.t1);let cursor=0;for(const gap of doors){if(gap.t1>cursor){const a=bmPointOnWall(wall,cursor),b=bmPointOnWall(wall,gap.t1);result.push({a,b});}cursor=Math.max(cursor,gap.t2);}if(cursor<1){const a=bmPointOnWall(wall,cursor),b=bmPointOnWall(wall,1);result.push({a,b});}}for(const door of app.scene?.doors||[]){if(door.open)continue;const g=doorGeometry(door);result.push({a:{x:g.x1,y:g.y1},b:{x:g.x2,y:g.y2}});}return result;}
  function clientMovementBlocked(token,from,to){if(!app.scene?.settings?.enforceWalls)return false;const radius=Math.max(5,(app.scene.grid?.size||70)*Math.max(.25,Number(token.size||1))*.28);for(const seg of clientMovementSegments()){const start=clientPointSegmentDistance(from,seg.a,seg.b),end=clientPointSegmentDistance(to,seg.a,seg.b),sweep=clientSegmentDistance(from,to,seg.a,seg.b);if(start<radius){const side=p=>(seg.b.x-seg.a.x)*(p.y-seg.a.y)-(seg.b.y-seg.a.y)*(p.x-seg.a.x);if(side(from)*side(to)<-1e-6||end<=start+.25)return true;}else if(sweep<radius-.25||end<radius-.25)return true;}for(const cover of app.scene.covers||[]){if(!cover.blocksMovement)continue;if(hitPointInCover(to,cover))return true;}return false;}
  function hitPointInCover(point,c){if(c.shape==='circle')return Math.hypot(point.x-c.x,point.y-c.y)<=c.radius;if(c.shape==='polygon')return c.points?.length>=3&&bmPointInPolygon(point,c.points);return point.x>=c.x&&point.x<=c.x+c.width&&point.y>=c.y&&point.y<=c.y+c.height;}
  function moveSelectedByKeyboard(dx,dy,fine=false){const t=selectedToken();if(!t||!canControlToken(t)||t.locked)return;const step=(fine?app.scene.grid.size/5:app.scene.grid.size),from={x:t.x,y:t.y};let next={x:clamp(t.x+dx*step,0,app.scene.mapWidth),y:clamp(t.y+dy*step,0,app.scene.mapHeight)};next=clampMoveToRemaining(t,from,next);if(Math.hypot(next.x-from.x,next.y-from.y)<.1){toast('Запас движения на этот ход исчерпан.','error');return;}if(clientMovementBlocked(t,from,next)){toast('Путь перекрыт стеной или закрытой дверью.','error');return;}const stepFeet=pixelsToFeet(Math.hypot(next.x-from.x,next.y-from.y));consumeLocalMovement(t,from,next);app.wasdMovementFeet=(app.wasdMovementTokenId===t.id?Number(app.wasdMovementFeet||0):0)+stepFeet;app.wasdMovementTokenId=t.id;v080ApplyAutoRotation(t,from,next);t.x=next.x;t.y=next.y;app.tokenMotions.delete(t.id);requestRender();refreshActionDock();clearTimeout(app.wasdSaveTimer);app.wasdSaveTimer=setTimeout(()=>{const movementDeltaFeet=app.wasdMovementTokenId===t.id?app.wasdMovementFeet:0;app.wasdMovementFeet=0;app.wasdMovementTokenId=null;updateToken(t,{x:t.x,y:t.y,rotation:t.rotation,movementDeltaFeet}).catch(async e=>{toast(e.message,'error');await refreshBattlemap();});},90);}

  const baseRefreshAllUiV054=refreshAllUi;
  refreshAllUi=function(){baseRefreshAllUiV054();refreshActionDock();};
  const baseSelectObjectV054=selectObject;
  selectObject=function(type,objectId){baseSelectObjectV054(type,objectId);refreshActionDock();};

  function openFullCharacterSheet(token){
    if(!token||token.kind!=='character'||!token.refId){toast('У выбранного токена нет полного листа персонажа.','error');return;}
    const url=new URL('/',window.location.origin);
    url.searchParams.set('mode',master?'master':'player');
    url.searchParams.set('characterId',token.refId);
    const opened=window.open(url.toString(),'_blank');
    if(!opened){toast('Браузер заблокировал открытие листа. Разрешите всплывающие окна для этого адреса.','error');return;}
    try{opened.opener=null;}catch(_error){}
  }

  function bindV054Ui(){
    $('action-slots').addEventListener('click',e=>{const btn=e.target.closest('[data-dock-action]');if(!btn||btn.disabled)return;const key=btn.dataset.dockAction;if(key==='items')return openItemPopover(selectedToken());if(key==='skill')return openSkillPopover(selectedToken());if(key==='sheet')return showMiniSheet(selectedToken());if(key==='full-sheet')return openFullCharacterSheet(selectedToken());if(key==='possess'){enterPossession(selectedToken());refreshActionDock();return;}if(key==='leave-possession'){leavePossession();refreshActionDock();return;}const [type,value]=key.split(':');if(type==='counter')return performCounter(value);if(type==='ranged')return beginDockTarget('ranged',value,'normal');if(type==='aimed')return beginDockTarget('ranged',value,'aimed');if(type==='melee')return beginDockTarget('melee',value,'normal');if(type==='melee-power')return beginDockTarget('melee',value,'normal','power');if(type==='melee-stun')return beginDockTarget('melee',value,'normal','stun');if(type==='tactical')return useTacticalAction(value);});
    $('attack-damage-actions').addEventListener('click',e=>{const counter=e.target.closest('[data-melee-counter]');if(counter)performCounter(counter.dataset.meleeCounter);});
    const tokenIds=['token-name','token-x','token-y','token-size','token-rotation','token-mz','token-cover-bonus','token-elevation','token-display-shape','token-display-fit','token-image-scale','token-opacity','token-image-offset-x','token-image-offset-y','token-border-color','token-border-enabled','token-background-enabled','token-group-marker-enabled','token-show-name','token-rotate-image','token-auto-rotate-move','token-hidden','token-locked','token-defeated','token-vision-enabled','token-vision-range','token-vision-angle','token-light-enabled','token-light-bright','token-light-dim','token-light-angle','token-light-color','token-light-flicker','token-light-flicker-speed'];
    for(const id of tokenIds){const el=$(id);if(el){el.addEventListener('input',liveToken);el.addEventListener('change',liveToken);}}
    for(const [ids,fn] of [[['wall-blocks-vision','wall-blocks-movement'],liveWall],[['door-name','door-width','door-open-angle','door-open','door-locked','door-allow-players','door-hidden'],liveDoor],[['cover-name','cover-shape','cover-x','cover-y','cover-width','cover-height','cover-radius','cover-mz','cover-durability','cover-damage','cover-color','cover-elevation','cover-vertical-height','cover-blocks-movement','cover-hidden'],liveCover],[['static-light-name','static-light-enabled','static-light-bright','static-light-dim','static-light-angle','static-light-rotation','static-light-color','static-light-intensity','static-light-flicker','static-light-flicker-speed'],liveLight]])for(const id of ids){const el=$(id);if(el){el.addEventListener('input',fn);el.addEventListener('change',fn);}}
    window.addEventListener('keydown',e=>{if(isTypingTarget(e.target))return;if(e.key==='Escape'&&app.actionTarget){e.preventDefault();cancelDockTarget();return;}const moves={KeyW:[0,-1],KeyA:[-1,0],KeyS:[0,1],KeyD:[1,0]};const move=moves[e.code];if(move){e.preventDefault();moveSelectedByKeyboard(move[0],move[1],e.shiftKey);}});
  }

  function bindV053Ui(){
    $('token-auto-rotate-move').addEventListener('change',()=>{if($('token-auto-rotate-move').checked&&!$('token-rotate-image').checked){$('token-rotate-image').checked=true;$('token-rotate-image').dispatchEvent(new Event('change',{bubbles:true}));}});
    $('token-display-shape').addEventListener('change',()=>{if($('token-display-shape').value==='free'){$('token-border-enabled').checked=false;$('token-background-enabled').checked=false;$('token-display-fit').value='contain';}});$('replace-token-image-btn').onclick=()=>$('replace-token-image-input').click();$('replace-token-image-input').onchange=e=>{const file=e.target.files[0];if(file)replaceSelectedTokenImage(file);e.target.value='';};$('clear-token-image-btn').onclick=async()=>{const t=selectedToken();if(t)try{await updateToken(t,{imageUrl:null});t.imageUrl=null;requestRender();}catch(e){toast(e.message,'error');}};
    $('combat-toggle-btn').onclick=()=>combatActive()?endCombat():openCombatModal();$('combat-cancel-btn').onclick=()=>$('combat-modal').hidden=true;$('combat-start-btn').onclick=startCombat;$('end-turn-btn').onclick=advanceCombat;$('combat-strip').onclick=e=>{const card=e.target.closest('[data-init-token]');if(card){const t=tokenById(card.dataset.initToken);selectObject('token',t.id);focusToken(t);}};
    $('quick-possess-btn').onclick=()=>enterPossession(selectedToken());$('leave-possession-btn').onclick=leavePossession;$('quick-skill-btn').onclick=()=>openSkillPopover(selectedToken());$('quick-mini-sheet').onclick=()=>showMiniSheet(selectedToken());$('mini-sheet-close').onclick=()=>$('mini-sheet').hidden=true;$('map-skill-cancel').onclick=()=>$('skill-popover').hidden=true;$('map-skill-roll').onclick=rollMapSkill;
    $('combat-modal').addEventListener('pointerdown',e=>{if(e.target===$('combat-modal'))$('combat-modal').hidden=true;});
  }


  /* ===== FATUM Battlemap v0.5.8: reliable actions, compact HUD, chat journal and full checks ===== */
  app.tableLogIds = new Set();
  app.skillProfilePayload = null;
  app.skillPending = false;
  app.chatPending = false;

  function isTypingTarget(target) {
    return Boolean(target && (['INPUT','TEXTAREA','SELECT'].includes(target.tagName) || target.isContentEditable));
  }

  function logTypeLabel(type) {
    return ({chat:'Сообщение',roll:'Бросок',action:'Действие',combat:'Бой',system:'Система'})[type] || 'Событие';
  }
  function logTime(at) {
    try { return new Date(at).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'}); } catch { return ''; }
  }
  function currentTableLog() { return Array.isArray(app.battlemap?.tableLog) ? app.battlemap.tableLog : []; }
  function appendTableLogClient(entry) {
    if (!entry?.id) return;
    app.battlemap ||= {};
    app.battlemap.tableLog ||= [];
    const index=app.battlemap.tableLog.findIndex(item=>item.id===entry.id);
    if(index>=0) app.battlemap.tableLog[index]=entry; else app.battlemap.tableLog.push(entry);
    if(app.battlemap.tableLog.length>500)app.battlemap.tableLog.splice(0,app.battlemap.tableLog.length-500);
    renderTableLog(true);
  }
  function renderTableLog(forceBottom=false) {
    const box=$('chat-log'); if(!box)return;
    const nearBottom=box.scrollHeight-box.scrollTop-box.clientHeight<70;
    const list=currentTableLog().slice(-300);
    box.innerHTML=list.map(entry=>{const canDelete=master||(entry.type==='chat'&&entry.actorId===clientId);return `<article class="bm-chat-entry type-${esc(entry.type||'system')}"><div><strong>${esc(entry.actorName||logTypeLabel(entry.type))}</strong><time>${esc(logTime(entry.at))}</time></div><p>${esc(entry.text||'')}</p>${canDelete?`<button class="bm-chat-delete" data-chat-delete="${esc(entry.id)}" title="Удалить">×</button>`:''}</article>`;}).join('')||'<p class="bm-muted">Событий пока нет.</p>';
    if(forceBottom||nearBottom)box.scrollTop=box.scrollHeight;
  }
  function toggleChat(force) {
    const panel=$('chat-panel'),show=force===undefined?panel.hidden:Boolean(force);
    panel.hidden=!show; if(show){renderTableLog(true);setTimeout(()=>$('chat-input')?.focus(),0);}
  }
  async function submitChat(event) {
    event?.preventDefault(); if(app.chatPending)return;
    const input=$('chat-input'),text=input.value.trim();if(!text)return;
    app.chatPending=true;const button=$('chat-form').querySelector('button');button.disabled=true;
    try{const result=await api('/api/battlemap/chat',{method:'POST',body:commonBody({sceneId:app.scene?.id,text,visibility:'public'})});input.value='';if(result.entry)appendTableLogClient(result.entry);}
    catch(error){toast(error.message,'error');}
    finally{app.chatPending=false;button.disabled=false;input.focus();}
  }

  function outcomeLabel(value){return({success:'Успех',failure:'Провал',edge:'Успех на грани','critical-success':'Критический успех','critical-failure':'Критический провал'})[value]||value;}
  function selectedSkillProfile(){return app.skillProfilePayload?.skills?.find(item=>item.name===$('map-skill-select').value)||null;}
  function selectedSkillOptions(){return app.skillProfilePayload?.optionsBySkill?.[$('map-skill-select').value]||[];}
  function renderSkillProfile() {
    const profile=selectedSkillProfile();if(!profile)return;
    const sign=n=>Number(n)>=0?`+${Number(n)}`:String(Number(n));
    const automatic=[...(profile.advantages||[]).map(x=>`Преимущество: ${x}`),...(profile.hindrances||[]).map(x=>`Помеха: ${x}`)];
    $('map-skill-summary').innerHTML=`<strong>${esc(profile.cube)} ${sign(profile.bonus)}</strong><span>${esc(profile.group||'')}</span>${automatic.length?`<small>${automatic.map(esc).join(' · ')}</small>`:''}`;
    $('map-skill-breakdown').innerHTML=(profile.breakdown||[]).map(item=>`<div class="bm-skill-part"><span>${esc(item.label)}</span><strong>${sign(item.value)}</strong></div>`).join('')||'<p class="bm-muted">Дополнительных модификаторов нет.</p>';
    const options=selectedSkillOptions();
    $('map-skill-options').innerHTML=options.map(option=>`<label class="bm-roll-option ${option.relevant?'relevant':''}"><input type="checkbox" value="${esc(option.id)}" data-option-kind="${esc(option.kind)}"><span><strong>${esc(option.name)}</strong><small>${esc(option.kind==='specialization'?'Специализация':option.kind==='doctrine'?'Доктрина':'Черта характера')}${option.frequency?` · ${esc(option.frequency)}`:''}</small><em>${esc(option.text||'')}</em></span></label>`).join('')||'<p class="bm-muted">Для персонажа нет выбираемых особенностей.</p>';
  }
  async function loadSkillProfile(token) {
    const qs=new URLSearchParams({sceneId:app.scene.id,tokenId:token.id,clientId,combatContext:$('map-skill-combat').checked?'1':'0'});
    return api(`/api/battlemap/skill-profile?${qs}`);
  }
  openSkillPopover=async function(token){
    if(!token)return;app.skillTokenId=token.id;$('skill-popover').hidden=false;$('map-skill-result').textContent='Загрузка полного профиля…';
    const p=worldToScreen(visualTokenState(token)),box=$('skill-popover');box.style.left=`${clamp(p.x+20,10,app.dimensions.width-390)}px`;box.style.top=`${clamp(p.y+20,58,app.dimensions.height-560)}px`;
    try{const payload=await loadSkillProfile(token);app.skillProfilePayload=payload;const select=$('map-skill-select');select.innerHTML=(payload.skills||[]).map(profile=>`<option value="${esc(profile.name)}">${esc(profile.name)}</option>`).join('');renderSkillProfile();$('map-skill-result').textContent='';}
    catch(error){$('skill-popover').hidden=true;toast(error.message,'error');}
  };
  rollMapSkill=async function(){
    if(app.skillPending)return;const token=tokenById(app.skillTokenId),profile=selectedSkillProfile();if(!token||!profile)return;
    app.skillPending=true;$('map-skill-roll').disabled=true;
    const optionIds=[...$('map-skill-options').querySelectorAll('input:checked')].map(input=>input.value);
    try{const result=await api('/api/battlemap/skill-check',{method:'POST',body:commonBody({sceneId:app.scene.id,tokenId:token.id,skillName:profile.name,label:`${token.name}: ${profile.name}`,difficultyDie:$('map-difficulty-die').value,difficultyModifier:Number($('map-difficulty-mod').value||0),condition:$('map-skill-condition').value,combatContext:$('map-skill-combat').checked,optionIds,visibility:'public'})});const r=result.roll;startRollVisual(r);$('map-skill-result').innerHTML=`<strong class="${String(r.outcome).includes('failure')?'bad':'good'}">${esc(outcomeLabel(r.outcome))}</strong><span>${r.successTotal} против ${r.difficultyTotal}</span><small>${esc(r.formula||'')}</small>`;if(result.entry)appendTableLogClient(result.entry);}
    catch(error){toast(error.message,'error');}
    finally{app.skillPending=false;$('map-skill-roll').disabled=false;}
  };

  function renderAutoDamageResult(result) {
    if(!result)return;
    const actions=$('attack-damage-actions');
    const wounds=(result.applied||[]).join(', ')||'без ранения';
    actions.innerHTML=`<div class="bm-muted">Урон применён автоматически: ${esc(wounds)}${result.blocked?' · заблокировано':''}${result.moraleLoss?` · мораль −${result.moraleLoss} (${(result.moraleRolls||[]).join(', ')})`:''}</div>`;
    toast(result.blocked?'Атака заблокирована.':`Урон применён${result.moraleLoss?`, мораль −${result.moraleLoss}`:''}.`,result.blocked?'':'success');
  }

  async function loadMapItems(token=selectedToken()){
    if(!token)return[];const qs=new URLSearchParams({sceneId:app.scene.id,tokenId:token.id,clientId});const payload=await api(`/api/battlemap/items?${qs}`);return payload.items||[];
  }
  function itemModeFor(item){
    if(/Перевязочный комплект/i.test(item.name)){const choice=prompt('Перевязочный комплект\n1 — остановить Кровотечение\n2 — снять одно Лёгкое ранение\nНажмите «Отмена», чтобы не использовать предмет.','1');if(choice===null)return '__cancel__';if(String(choice).trim()==='1')return 'bleeding';if(String(choice).trim()==='2')return 'light';toast('Введите 1 или 2. Предмет не использован.','error');return '__cancel__';}
    if(/ПАСИ/i.test(item.name))return confirm('ОК — лечить Среднее ранение. Отмена — снять до двух Лёгких.')?'medium':'light';
    return null;
  }
  async function useMapItem(item,targetToken,sourceToken=null){
    // Источник расходника фиксируется в момент начала выбора цели. Раньше
    // клик по цели мог выбрать её токен, после чего предмет искался уже в
    // инвентаре цели и применение уходило «в пустоту».
    const token=sourceToken||tokenById(app.actionTarget?.attackerId)||selectedToken();if(!token||app.itemPending)return;app.itemPending=true;
    try{const itemMode=itemModeFor(item);if(itemMode==='__cancel__')return;let injuryName=null;if(/Медицинский набор|Хирургический набор|Турбина/i.test(item.name))injuryName=prompt('Название травмы (можно оставить пустым для Турбины):','')||'';
      const result=await api('/api/battlemap/use-item',{method:'POST',body:commonBody({requestId:id(),sceneId:app.scene.id,tokenId:token.id,targetTokenId:(targetToken||token).id,itemId:item.id,itemMode,injuryName})});toast(result.resultText||'Предмет использован.','success');$('item-popover').hidden=true;await fetchAll(true);
    }catch(error){toast(error.message,'error');}finally{app.itemPending=false;}
  }
  async function openItemPopover(token=selectedToken()){
    if(!token)return;const panel=$('item-popover'),list=$('map-item-list');panel.hidden=false;list.innerHTML='<p class="bm-muted">Загрузка…</p>';
    try{const items=await loadMapItems(token);app.mapItems=items;list.innerHTML=items.map(item=>`<article class="bm-map-item"><div><strong>${esc(item.name)} ×${item.qty}${item.usesRemaining!==null?` (${item.usesRemaining} исп.)`:''}</strong><small>${esc(item.desc||'')}</small></div><div class="bm-map-item-actions">${item.grenade?`<button class="bm-btn bm-primary" data-map-grenade="${esc(item.id)}">Бросить</button>`:`<button class="bm-btn bm-primary" data-map-item-self="${esc(item.id)}">На себя</button><button class="bm-btn" data-map-item-target="${esc(item.id)}">На цель</button>`}</div></article>`).join('')||'<p class="bm-muted">Подходящих расходников и гранат нет.</p>';
    }catch(error){list.innerHTML=`<p class="bm-muted">${esc(error.message)}</p>`;}
  }
  function beginItemTarget(item){const token=selectedToken();if(!token)return;app.actionTarget={type:'item',attackerId:token.id,item};$('item-popover').hidden=true;document.body.classList.add('bm-targeting');setTool('select');setActionDescription('Выберите соседний токен для применения предмета.');}
  function beginGrenadeTarget(item){const token=selectedToken();if(!token)return;app.actionTarget={type:'grenade',attackerId:token.id,item};$('item-popover').hidden=true;document.body.classList.add('bm-targeting');setTool('select');setActionDescription('Укажите точку броска гранаты на карте.');toast('Выберите точку броска.');}
  async function performGrenade(point){const action=app.actionTarget,token=tokenById(action?.attackerId);if(!action||!token||app.attackPending)return;app.attackPending=true;try{const sceneId=app.scene.id;const result=await api('/api/battlemap/grenade',{method:'POST',body:commonBody({requestId:id(),sceneId,tokenId:token.id,itemId:action.item.id,x:point.x,y:point.y,skillName:'Меткость'})});toast(result.check&&!result.check.success?`Граната отклонилась на ${result.check.scatter} фт.`:'Граната применена.','success');if(result.entry)appendTableLogClient(result.entry);await fetchAll(true);if(result.visualZone)addTransientEffect(sceneId,result.visualZone,result.visualTtlMs||8000);}catch(error){toast(error.message,'error');}finally{app.attackPending=false;cancelDockTarget();}}

  async function performDockRanged(target) {
    const action=app.actionTarget,attacker=tokenById(action?.attackerId);if(!action||!attacker||!target||target.id===attacker.id||app.attackPending)return;
    app.attackPending=true;
    try{const result=await api('/api/battlemap/attack',{method:'POST',body:commonBody({requestId:id(),sceneId:app.scene.id,attackerTokenId:attacker.id,targetTokenId:target.id,weaponId:action.weaponId,shotMode:action.shotMode||'normal',situationalModifier:0,targetMz:null,moved:false,spendResources:combatActive(),autoApplyDamage:true,visibility:'public'})});if(result.roll)startRollVisual(result.roll);if(result.attack)showAttackResult(result.attack,true);renderAutoDamageResult(result.damageResult);await fetchAll(true);}
    catch(error){toast(error.message,'error');}
    finally{app.attackPending=false;cancelDockTarget();}
  }

  const baseOnPointerDownV055=onPointerDown;
  onPointerDown=function(event){
    canvas.focus({preventScroll:true});
    if(app.actionTarget&&event.button===0&&app.scene){const world=screenToWorld(eventPoint(event));if(app.actionTarget.type==='grenade'){event.preventDefault();performGrenade(world);return;}const target=hitTestToken(world);if(target&&target.id!==app.actionTarget.attackerId){event.preventDefault();if(app.actionTarget.type==='melee')performMelee(target);else if(app.actionTarget.type==='item')useMapItem(app.actionTarget.item,target).finally(cancelDockTarget);else performDockRanged(target);return;}if(target?.id===app.actionTarget.attackerId&&app.actionTarget.type==='item'){useMapItem(app.actionTarget.item,target).finally(cancelDockTarget);return;}if(target?.id===app.actionTarget.attackerId)toast('Нужно выбрать другой токен.','error');return;}
    return baseOnPointerDownV055(event);
  };

  const baseRefreshAllUiV055=refreshAllUi;
  refreshAllUi=function(){baseRefreshAllUiV055();renderTableLog(false);};

  function bindV055Ui(){
    canvas.addEventListener('pointerdown',()=>canvas.focus({preventScroll:true}),{capture:true});
    $('chat-toggle-btn').onclick=()=>toggleChat();$('chat-close-btn').onclick=()=>toggleChat(false);$('chat-form').addEventListener('submit',submitChat);$('chat-clear-btn').onclick=async()=>{if(!confirm('Очистить весь чат и журнал стола? Перед очисткой будет создан снимок.'))return;try{await api('/api/battlemap/chat',{method:'DELETE',body:commonBody()});await fetchAll(true);}catch(error){toast(error.message,'error');}};$('chat-log').addEventListener('click',async e=>{const button=e.target.closest('[data-chat-delete]');if(!button)return;try{await api(`/api/battlemap/chat/${encodeURIComponent(button.dataset.chatDelete)}`,{method:'DELETE',body:commonBody()});await fetchAll(true);}catch(error){toast(error.message,'error');}});$('item-popover-close').onclick=()=>$('item-popover').hidden=true;$('map-item-list').addEventListener('click',e=>{const g=e.target.closest('[data-map-grenade]'),self=e.target.closest('[data-map-item-self]'),target=e.target.closest('[data-map-item-target]'),button=g||self||target;if(!button)return;const item=(app.mapItems||[]).find(x=>x.id===(g?.dataset.mapGrenade||self?.dataset.mapItemSelf||target?.dataset.mapItemTarget));if(!item)return;if(g)return beginGrenadeTarget(item);if(target)return beginItemTarget(item);return useMapItem(item,selectedToken());});
    $('map-skill-select').addEventListener('change',renderSkillProfile);
    $('map-skill-options').addEventListener('change',event=>{const input=event.target.closest('input[data-option-kind]');if(input?.checked&&input.dataset.optionKind==='specialization')$('map-skill-options').querySelectorAll('input[data-option-kind="specialization"]:checked').forEach(other=>{if(other!==input)other.checked=false;});});
    $('map-skill-combat').addEventListener('change',async()=>{const token=tokenById(app.skillTokenId);if(!token)return;try{const payload=await loadSkillProfile(token);app.skillProfilePayload=payload;renderSkillProfile();}catch(error){toast(error.message,'error');}});
  }

  function refreshCampaignWorkspaceUi(){if(!master)return;const select=$('campaign-select');if(!select)return;const current=app.activeCampaignId||app.campaign?.campaignId;select.innerHTML=(app.campaignWorkspaces||[]).map(c=>`<option value="${esc(c.id)}">${esc(c.name)} · ${c.characters||0} лист. · ${c.scenes||0} сцен</option>`).join('');if(current)select.value=current;$('delete-campaign-btn').disabled=(app.campaignWorkspaces||[]).length<=1;}
  async function reloadAfterCampaignSwitch(){setStatus('Переключение кампании…');app.selected=null;app.possessedTokenId=null;await fetchAll(false);fitView();setStatus('Синхронизация активна','connected');}
  async function activateCampaign(idValue){if(!master||!idValue||idValue===app.activeCampaignId)return;try{await api(`/api/campaigns/${encodeURIComponent(idValue)}/activate`,{method:'POST',body:commonBody()});await reloadAfterCampaignSwitch();toast(`Открыта кампания «${app.campaign?.name||''}».`,'success');}catch(error){toast(error.message,'error');refreshCampaignWorkspaceUi();}}
  async function createCampaignWorkspace(){const name=(prompt('Название новой кампании:','Новая кампания')||'').trim();if(!name)return;try{await api('/api/campaigns',{method:'POST',body:commonBody({name,activate:true})});await reloadAfterCampaignSwitch();toast('Кампания создана.','success');}catch(error){toast(error.message,'error');}}
  async function renameCampaignWorkspace(){const current=(app.campaignWorkspaces||[]).find(c=>c.id===app.activeCampaignId);if(!current)return;const name=(prompt('Новое название кампании:',current.name)||'').trim();if(!name||name===current.name)return;try{await api(`/api/campaigns/${encodeURIComponent(current.id)}`,{method:'PUT',body:commonBody({name})});await fetchAll(true);toast('Кампания переименована.','success');}catch(error){toast(error.message,'error');}}
  async function deleteCampaignWorkspace(){const current=(app.campaignWorkspaces||[]).find(c=>c.id===app.activeCampaignId),alternate=(app.campaignWorkspaces||[]).find(c=>c.id!==app.activeCampaignId);if(!current||!alternate)return;if(!confirm(`Удалить кампанию «${current.name}» вместе с её листами, картами и снимками?`))return;try{await api(`/api/campaigns/${encodeURIComponent(alternate.id)}/activate`,{method:'POST',body:commonBody()});await api(`/api/campaigns/${encodeURIComponent(current.id)}`,{method:'DELETE',body:commonBody()});await reloadAfterCampaignSwitch();toast('Кампания удалена.','success');}catch(error){toast(error.message,'error');}}
  function chooseCampaignBackupFile(){if(!master)return;const input=$('import-campaign-backup-file');if(input){input.value='';input.click();}}
  async function importCampaignBackupFile(input){if(!master||!input?.files?.[0])return;const file=input.files[0];try{setStatus('Импорт backup…');const text=await file.text();let snapshot;try{snapshot=JSON.parse(text);}catch{throw new Error('Не удалось прочитать JSON-файл.');}const suggested=snapshot?.campaign?.name||snapshot?.name||file.name.replace(/\.json$/i,'');const name=(prompt('Название импортируемой кампании:',suggested)||'').trim();if(!name){setStatus('Синхронизация активна','connected');return;}const result=await api('/api/campaigns/import-backup',{method:'POST',body:commonBody({snapshot,name})});app.forceSceneId=null;await reloadAfterCampaignSwitch();toast(`Backup импортирован как кампания «${result.campaign?.name||name}».`,'success');}catch(error){toast(error.message,'error');setStatus('Ошибка импорта','error');}finally{input.value='';}}
  const baseRefreshAllUiV057=refreshAllUi;refreshAllUi=function(){baseRefreshAllUiV057();refreshCampaignWorkspaceUi();};
  function bindV057Ui(){if(master){$('campaign-select').addEventListener('change',e=>activateCampaign(e.target.value));$('new-campaign-btn').onclick=createCampaignWorkspace;$('rename-campaign-btn').onclick=renameCampaignWorkspace;$('delete-campaign-btn').onclick=deleteCampaignWorkspace;const importBtn=$('import-campaign-backup-btn'),emptyImport=$('empty-import-backup-btn'),input=$('import-campaign-backup-file');if(importBtn)importBtn.onclick=chooseCampaignBackupFile;if(emptyImport)emptyImport.onclick=chooseCampaignBackupFile;if(input)input.onchange=()=>importCampaignBackupFile(input);}}


  /* ===== FATUM Battlemap v0.6.0: final base polish ===== */
  app.grenadePreview = null;

  const baseClientWeaponsV0511=clientWeapons;
  clientWeapons=function(token){if(Array.isArray(token?.weapons)&&token.weapons.length)return token.weapons;return baseClientWeaponsV0511(token);};

  const baseUpdateTokenV0511=updateToken;
  updateToken=function(token,patch){const next={...patch};if(master&&(patch?.x!==undefined||patch?.y!==undefined))next.ignoreWalls=true;return baseUpdateTokenV0511(token,next);};
  const baseClientMovementBlockedV0511=clientMovementBlocked;
  clientMovementBlocked=function(token,from,to){return master?false:baseClientMovementBlockedV0511(token,from,to);};

  refreshTokenActions=function(){const box=$('token-actions');if(box)box.hidden=true;};

  const baseRefreshSceneSelectV0511=refreshSceneSelect;
  refreshSceneSelect=function(){baseRefreshSceneSelectV0511();const select=$('scene-select');if(select)select.disabled=!master;const label=$('player-scene-name');if(label)label.textContent=app.scene?.name||'Нет активной сцены';};

  const baseRefreshInspectorV0511=refreshInspector;
  refreshInspector=function(){baseRefreshInspectorV0511();const select=$('token-transfer-scene');if(select){select.innerHTML=(app.battlemap?.scenes||[]).filter(scene=>scene.id!==app.scene?.id).map(scene=>`<option value="${esc(scene.id)}">${esc(scene.name)}</option>`).join('');select.disabled=!select.options.length;const button=$('transfer-token-btn');if(button)button.disabled=!select.options.length||app.selected?.type!=='token';}};

  async function transferSelectedToken(){const token=selectedToken(),targetSceneId=$('token-transfer-scene')?.value;if(!master||!token||!targetSceneId)return;try{const result=await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/tokens/${encodeURIComponent(token.id)}/transfer`,{method:'POST',body:commonBody({targetSceneId})});app.forceSceneId=targetSceneId;await refreshBattlemap();selectObject('token',result.token.id);fitView();toast(`Токен «${result.token.name}» перенесён на другую сцену.`,'success');}catch(error){toast(error.message,'error');}}

  function grenadePreviewData(){const preview=app.grenadePreview;if(!preview||!app.scene||preview.sceneId!==app.scene.id)return null;const attacker=tokenById(preview.attackerId);if(!attacker)return null;const profile=preview.item?.profile||{},point=preview.point||app.lastMouseWorld,radius=feetToPixels(profile.radius||0),distance=pixelsToFeet(Math.hypot(point.x-attacker.x,point.y-attacker.y)),maxRange=Number(preview.item?.throwRange||0);return{preview,attacker,profile,point,radius,distance,maxRange,valid:!maxRange||distance<=maxRange+.01};}
  function tokenInGrenadePreview(token){const data=grenadePreviewData();if(!data||data.radius<=0)return false;return Math.hypot(token.x-data.point.x,token.y-data.point.y)<=data.radius+tokenRadius(token)*.25;}
  function drawThrowPreview(target){const data=grenadePreviewData();if(!data)return;const{attacker,profile,point,radius,distance,maxRange,valid}=data;const color=valid?(profile.type==='smoke'?'#c9d2d8':profile.type==='gas'||profile.type==='toxin'?'#7fce78':'#ffab4d'):'#ef5a5a';target.save();target.beginPath();target.moveTo(attacker.x,attacker.y);target.lineTo(point.x,point.y);target.strokeStyle=color;target.lineWidth=2/app.view.scale;target.setLineDash([8/app.view.scale,6/app.view.scale]);target.stroke();target.setLineDash([]);if(radius>0){target.beginPath();target.arc(point.x,point.y,radius,0,Math.PI*2);target.fillStyle=hexToRgba(color,.18);target.fill();target.strokeStyle=color;target.lineWidth=3/app.view.scale;target.stroke();if(profile.damage>0){target.beginPath();target.arc(point.x,point.y,radius/2,0,Math.PI*2);target.strokeStyle=hexToRgba(color,.8);target.lineWidth=1.5/app.view.scale;target.setLineDash([5/app.view.scale,4/app.view.scale]);target.stroke();target.setLineDash([]);}}target.beginPath();target.moveTo(point.x-10/app.view.scale,point.y);target.lineTo(point.x+10/app.view.scale,point.y);target.moveTo(point.x,point.y-10/app.view.scale);target.lineTo(point.x,point.y+10/app.view.scale);target.strokeStyle='#fff';target.lineWidth=2/app.view.scale;target.stroke();const label=`${profile.name||data.preview.item?.name||'Бросок'} · ${Number(profile.radius||0)} фт · ${distance.toFixed(1)}${maxRange?`/${maxRange}`:''} фт${valid?'':' · вне дальности'}`;target.font=`${12/app.view.scale}px Segoe UI`;const width=target.measureText(label).width+12/app.view.scale;target.fillStyle='rgba(8,11,15,.86)';target.fillRect(point.x-width/2,point.y-radius-27/app.view.scale,width,19/app.view.scale);target.fillStyle=valid?'#fff0cf':'#ff9c9c';target.textAlign='center';target.textBaseline='middle';target.fillText(label,point.x,point.y-radius-17/app.view.scale);target.restore();}

  const baseDrawTokenV0511=drawToken;
  drawToken=function(target,token){baseDrawTokenV0511(target,token);if(tokenInGrenadePreview(token)){const v=visualTokenState(token),r=tokenRadius(token)+8/app.view.scale;target.save();target.beginPath();target.arc(v.x,v.y,r,0,Math.PI*2);target.fillStyle='rgba(255,183,72,.18)';target.fill();target.strokeStyle='#ffc05c';target.lineWidth=4/app.view.scale;target.stroke();target.restore();}};

  const baseBeginGrenadeTargetV0511=beginGrenadeTarget;
  beginGrenadeTarget=function(item){baseBeginGrenadeTargetV0511(item);const token=selectedToken();if(token)app.grenadePreview={sceneId:app.scene.id,attackerId:token.id,item,point:{...app.lastMouseWorld}};requestRender();};
  const baseCancelDockTargetV0511=cancelDockTarget;
  cancelDockTarget=function(){app.grenadePreview=null;baseCancelDockTargetV0511();requestRender();};
  const baseOnPointerMoveV0511=onPointerMove;
  onPointerMove=function(event){if(app.grenadePreview&&app.scene){app.grenadePreview.point=screenToWorld(eventPoint(event));requestRender();}return baseOnPointerMoveV0511(event);};

  function bindV0511Ui(){if($('transfer-token-btn'))$('transfer-token-btn').onclick=transferSelectedToken;}

  /* ===== FATUM Battlemap v0.6.0: movement pool ===== */
  function movementForToken(token){
    if(!token||!combatActive())return null;
    if(token.movement)return {spent:Number(token.movement.spent||0),limit:Number(token.movement.limit||0),remaining:Number(token.movement.remaining||0)};
    const raw=app.battlemap?.combat?.movement?.[token.id];if(!raw)return null;
    const speed=token.kind==='npc'?Number(npcById(token.refId)?.speed||30):Number(characterById(token.refId)?.state?.speed||30);
    const multiplier=tokenActionState(token)?.sprint?2:1,limit=speed*multiplier+(tokenActionState(token)?.charge?10:0),spent=Number(raw.spent||0);
    return{spent,limit,remaining:Math.max(0,limit-spent)};
  }
  function clampMoveToBudget(from,to,remaining){if(remaining===null||remaining===undefined)return to;const px=Math.hypot(to.x-from.x,to.y-from.y),feet=pixelsToFeet(px);if(feet<=Number(remaining)+.001)return to;if(Number(remaining)<=0)return{x:from.x,y:from.y};const ratio=feet?Number(remaining)/feet:0;return{x:from.x+(to.x-from.x)*ratio,y:from.y+(to.y-from.y)*ratio};}
  function clampMoveToRemaining(token,from,to){const movement=movementForToken(token);return movement?clampMoveToBudget(from,to,movement.remaining):to;}
  function consumeLocalMovement(token,from,to){const movement=movementForToken(token);if(!movement)return;const feet=pixelsToFeet(Math.hypot(to.x-from.x,to.y-from.y));token.movement={spent:Math.round((movement.spent+feet)*10)/10,limit:movement.limit,remaining:Math.max(0,Math.round((movement.remaining-feet)*10)/10)};}
  const baseUpdateTokenV060=updateToken;
  updateToken=async function(token,patch){const result=await baseUpdateTokenV060(token,patch);if(result?.token){Object.assign(token,result.token);if(result.movement)token.movement=result.movement;}refreshActionDock();return result;};


  /* ===== FATUM Battlemap v0.6.6: stable audio transport, persistent SFX bindings and pistol fire modes ===== */
  const V061_EFFECT_LABELS = {
    'ui.click':'Интерфейс: нажатие','ui.turn':'Интерфейс: новый ход','ui.combatStart':'Интерфейс: начало боя','ui.combatEnd':'Интерфейс: конец боя',
    'door.open':'Дверь: открыть','door.close':'Дверь: закрыть','weapon.pistol':'Выстрел: пистолет','weapon.revolver':'Выстрел: револьвер',
    'weapon.carbine':'Выстрел: карабин','weapon.rifle':'Выстрел: винтовка','weapon.shotgun':'Выстрел: дробовик','weapon.machinegun':'Выстрел: пулемёт',
    'weapon.grenadeLauncher':'Выстрел: гранатомёт','weapon.anaxion':'Выстрел: анаксионное оружие','weapon.generic':'Выстрел: прочее',
    'grenade.throw':'Граната: бросок','grenade.explosion':'Граната: взрыв','grenade.smokeGas':'Граната: дым / газ','zone.suppression':'Зона: подавление','zone.barrage':'Зона: шквальный огонь','heavy.reload.machinegun':'Перезарядка тяжёлого пулемёта','heavy.reload.grenadeLauncher':'Перезарядка гранатомёта','melee.hit':'Ближний бой: удар','unarmed.hit':'Безоружный удар','item.use':'Использование предмета','token.damage':'Токен: получение урона'
  };
  const V061_DUAL_PROFILES = ['Карманный пистолет','Средний пистолет','Тяжёлый пистолет','Револьвер','Тяжёлый револьвер','Анаксионный пистолет'];
  const V061_SUPPRESSION_PROFILES = ['Армейский карабин','Штурмовой карабин','Автоматический карабин','Тяжёлый пулемёт'];
  const V061_BARRAGE_PROFILES = ['Штурмовой карабин','Автоматический карабин','Тяжёлый пулемёт'];
  const V061_ANAXION_PROFILES = ['Анаксионный пистолет','Анаксионная винтовка','Анаксионный дробовик','Анаксионный излучатель'];

  app.audioEngine = {
    unlocked:false,
    context:null,
    bufferCache:new Map(),
    bufferCacheBytes:0,
    bufferCacheMaxEntries:64,
    bufferCacheMaxBytes:64*1024*1024,
    htmlEffects:new Set(),
    channels:{music:new Audio(),ambient:new Audio()},
    channelTrackIds:{music:null,ambient:null},
    channelSyncKeys:{music:null,ambient:null},
    pendingBindings:new Map(),
    bindingRevision:0,
    blocked:false,
    lastFailureToast:0,
    local:{
      music:clamp(Number(localStorage.getItem('fatumAudioMusic') ?? .7),0,1),
      ambient:clamp(Number(localStorage.getItem('fatumAudioAmbient') ?? .7),0,1),
      effects:clamp(Number(localStorage.getItem('fatumAudioEffects') ?? .85),0,1),
      spatial:localStorage.getItem('fatumAudioSpatial')!=='0'
    }
  };
  app.audioEngine.channels.music.preload='auto';
  app.audioEngine.channels.ambient.preload='auto';
  for(const name of ['music','ambient'])app.audioEngine.channels[name].addEventListener('loadedmetadata',()=>v061ApplyChannel(name,{forceSeek:true}));

  function v061AudioState(){
    const base=app.battlemap?.audio||{library:[],channels:{music:{},ambient:{}},effectBindings:{}};
    if(!app.audioEngine.pendingBindings?.size)return base;
    const effectBindings={...(base.effectBindings||{})};
    for(const [key,pending] of app.audioEngine.pendingBindings.entries())effectBindings[key]=pending.value;
    return {...base,effectBindings};
  }
  function v061AudioItem(idValue){return (v061AudioState().library||[]).find(item=>item.id===idValue)||null;}
  function v087ResolvedEffectTrackId(soundKey){const state=v061AudioState(),value=state.effectBindings?.[soundKey];if(value==='off')return null;return value||state.defaultEffectBindings?.[soundKey]||null;}
  function v087ScopeLabel(scope){return scope==='core'?'Встроенные':scope==='shared'?'Общие':'Кампания';}
  function v087FormatBytes(value){const bytes=Math.max(0,Number(value||0));if(bytes<1024)return`${bytes} Б`;if(bytes<1024*1024)return`${(bytes/1024).toFixed(bytes<10240?1:0)} КБ`;return`${(bytes/1024/1024).toFixed(1)} МБ`;}
  function v087AudioOptions(kind=null,selected=null,{includeOff=false,includeStandard=false}={}){const state=v061AudioState(),items=(state.library||[]).filter(item=>!kind||item.kind===kind);let html='';if(includeStandard)html+=`<option value=""${selected===null||selected===undefined||selected===''?' selected':''}>— стандартный встроенный —</option>`;if(includeOff)html+=`<option value="off"${selected==='off'?' selected':''}>— без звука —</option>`;for(const scope of ['core','shared','campaign']){const group=items.filter(item=>(item.scope||'campaign')===scope);if(!group.length)continue;html+=`<optgroup label="${v087ScopeLabel(scope)}">${group.map(item=>`<option value="${esc(item.id)}"${selected===item.id?' selected':''}>${esc(item.name)}</option>`).join('')}</optgroup>`;}return html;}
  function v061ChannelPosition(channel){let value=Math.max(0,Number(channel?.position||0));if(channel?.playing&&channel?.startedAt){const started=Date.parse(channel.startedAt);if(Number.isFinite(started))value+=Math.max(0,(Date.now()-started)/1000);}return value;}
  function setV064AudioStatus(kind='idle',message=''){
    const button=$('audio-unlock-btn'),status=$('audio-player-status');
    if(button){button.classList.toggle('active',kind==='ready');button.classList.toggle('error',kind==='blocked');button.textContent=kind==='ready'?'🔊 Звук':kind==='blocked'?'⚠ Звук':'🔇 Звук';button.title=message||'Включить звук';}
    if(status){status.dataset.kind=kind;status.textContent=message||'';status.hidden=!message;}
  }
  function reportV064AudioFailure(error,context='аудио'){
    const text=String(error?.message||error||'воспроизведение заблокировано браузером');
    app.audioEngine.blocked=true;
    setV064AudioStatus('blocked',`Браузер не разрешил ${context}. Нажмите «Звук» ещё раз.`);
    const now=Date.now();
    if(now-Number(app.audioEngine.lastFailureToast||0)>3500){app.audioEngine.lastFailureToast=now;toast(`Не удалось запустить ${context}: ${text}`,'error');}
    console.warn('[FATUM audio]',context,error);
  }
  function v065PlayChannel(name){
    const element=app.audioEngine.channels[name];
    try{
      const promise=element.play();
      if(promise&&typeof promise.catch==='function')promise.catch(error=>reportV064AudioFailure(error,name==='music'?'музыку':'эмбиент'));
      return promise;
    }catch(error){reportV064AudioFailure(error,name==='music'?'музыку':'эмбиент');return null;}
  }
  function v061ApplyChannel(name,{forceSeek=false}={}){
    const state=v061AudioState(),channel=state.channels?.[name]||{},element=app.audioEngine.channels[name],item=v061AudioItem(channel.trackId);
    const localVolume=app.audioEngine.local[name]??1;element.volume=clamp(Number(channel.volume??.7)*localVolume,0,1);element.loop=channel.loop!==false;
    if(!item){if(element.src){element.pause();element.removeAttribute('src');element.load();}app.audioEngine.channelTrackIds[name]=null;app.audioEngine.channelSyncKeys[name]=null;return null;}
    const trackChanged=app.audioEngine.channelTrackIds[name]!==item.id;
    if(trackChanged){element.pause();element.src=item.url;app.audioEngine.channelTrackIds[name]=item.id;element.load();}
    const transportKey=[item.id,channel.playing?'1':'0',channel.startedAt||'',Number(channel.position||0).toFixed(3)].join('|');
    const transportChanged=app.audioEngine.channelSyncKeys[name]!==transportKey;
    if(trackChanged||transportChanged||forceSeek){
      const expected=v061ChannelPosition(channel);
      if(Number.isFinite(element.duration)&&expected>element.duration&&element.loop)element.currentTime=expected%Math.max(.1,element.duration);
      else if(trackChanged||forceSeek||Math.abs((element.currentTime||0)-expected)>.35){try{element.currentTime=Math.max(0,expected);}catch{}}
      app.audioEngine.channelSyncKeys[name]=transportKey;
    }
    if(channel.playing&&app.audioEngine.unlocked)return v065PlayChannel(name);
    if(!channel.playing&&!element.paused)element.pause();
    return null;
  }
  function syncV061Audio(options={}){v061ApplyChannel('music',options);v061ApplyChannel('ambient',options);refreshV061AudioUi();}
  function setV062LocalChannelVolume(name,value){app.audioEngine.local[name]=clamp(Number(value),0,1);localStorage.setItem(`fatumAudio${name[0].toUpperCase()+name.slice(1)}`,String(app.audioEngine.local[name]));const channel=v061AudioState().channels?.[name]||{};app.audioEngine.channels[name].volume=clamp(Number(channel.volume??.7)*app.audioEngine.local[name],0,1);}
  function primeV064WebAudio(){
    const AudioContextClass=window.AudioContext||window.webkitAudioContext;
    if(!AudioContextClass)return null;
    app.audioEngine.context ||= new AudioContextClass();
    const context=app.audioEngine.context;
    try{
      const resumePromise=context.state==='suspended'?context.resume():Promise.resolve();
      const buffer=context.createBuffer(1,1,Math.max(8000,context.sampleRate||44100));
      const source=context.createBufferSource(),gain=context.createGain();
      gain.gain.value=0;source.buffer=buffer;source.connect(gain);gain.connect(context.destination);source.start(0);
      if(resumePromise&&typeof resumePromise.catch==='function')resumePromise.catch(error=>reportV064AudioFailure(error,'звуковые эффекты'));
      return resumePromise;
    }catch(error){reportV064AudioFailure(error,'звуковые эффекты');return null;}
  }
  function unlockV061Audio({silent=false}={}){
    try{
      // IMPORTANT: mark the engine as unlocked and call HTMLMediaElement.play() synchronously
      // inside the user's click/pointer event. Waiting for AudioContext.resume() first loses
      // transient user activation on Chromium when players connect through a LAN/VPN address.
      app.audioEngine.unlocked=true;app.audioEngine.blocked=false;
      setV064AudioStatus('ready','Звук включён для этой вкладки.');
      primeV064WebAudio();
      syncV061Audio();
      if(typeof v070SyncAudioSources==='function')v070SyncAudioSources({forcePlay:true});
      if(!silent)toast('Звук включён.','success');
      return true;
    }catch(error){app.audioEngine.unlocked=false;reportV064AudioFailure(error,'звук');return false;}
  }
  function v087TrimEffectCache(protectId=null){const cache=app.audioEngine.bufferCache;while(cache.size>app.audioEngine.bufferCacheMaxEntries||app.audioEngine.bufferCacheBytes>app.audioEngine.bufferCacheMaxBytes){const candidates=[...cache.entries()].filter(([id,entry])=>id!==protectId&&entry.resolved).sort((a,b)=>a[1].lastUsed-b[1].lastUsed);if(!candidates.length)break;const[id,entry]=candidates[0];cache.delete(id);app.audioEngine.bufferCacheBytes=Math.max(0,app.audioEngine.bufferCacheBytes-Number(entry.bytes||0));}}
  async function v061EffectBuffer(item){
    if(!item)return null;const cached=app.audioEngine.bufferCache.get(item.id);if(cached){cached.lastUsed=Date.now();return cached.promise;}
    app.audioEngine.context ||= new (window.AudioContext||window.webkitAudioContext)();
    const entry={promise:null,lastUsed:Date.now(),bytes:0,resolved:false};
    entry.promise=fetch(item.url,{credentials:'same-origin'}).then(r=>{if(!r.ok)throw new Error(`HTTP ${r.status}`);return r.arrayBuffer();}).then(buf=>app.audioEngine.context.decodeAudioData(buf.slice(0))).then(buffer=>{entry.resolved=true;entry.bytes=Math.max(1,Math.round(buffer.length*buffer.numberOfChannels*4));app.audioEngine.bufferCacheBytes+=entry.bytes;v087TrimEffectCache(item.id);return buffer;}).catch(error=>{app.audioEngine.bufferCache.delete(item.id);app.audioEngine.bufferCacheBytes=Math.max(0,app.audioEngine.bufferCacheBytes-Number(entry.bytes||0));reportV064AudioFailure(error,`эффект «${item.name||'без названия'}»`);return null;});
    app.audioEngine.bufferCache.set(item.id,entry);v087TrimEffectCache(item.id);return entry.promise;
  }
  function playV064HtmlEffect(item,volume){
    try{
      const audio=new Audio(item.url);
      audio.preload='metadata';audio.volume=clamp(volume,0,1);
      app.audioEngine.htmlEffects.add(audio);
      const cleanup=()=>app.audioEngine.htmlEffects.delete(audio);
      audio.addEventListener('ended',cleanup,{once:true});audio.addEventListener('error',cleanup,{once:true});
      const promise=audio.play();
      if(promise&&typeof promise.catch==='function')promise.catch(error=>{cleanup();reportV064AudioFailure(error,`эффект «${item.name||'без названия'}»`);});
      return true;
    }catch(error){reportV064AudioFailure(error,`эффект «${item.name||'без названия'}»`);return false;}
  }
  function playV076BuiltinDamage(volume,panValue){
    try{
      const ac=app.audioEngine.context||(app.audioEngine.context=new (window.AudioContext||window.webkitAudioContext)());
      const duration=.18,length=Math.max(1,Math.floor(ac.sampleRate*duration)),buffer=ac.createBuffer(1,length,ac.sampleRate),data=buffer.getChannelData(0);
      for(let i=0;i<length;i++){const t=i/length,envelope=Math.pow(1-t,3.2);data[i]=(Math.random()*2-1)*envelope;}
      const noise=ac.createBufferSource(),filter=ac.createBiquadFilter(),gain=ac.createGain();noise.buffer=buffer;filter.type='lowpass';filter.frequency.value=260;filter.Q.value=.7;gain.gain.setValueAtTime(clamp(volume*.62,0,1),ac.currentTime);gain.gain.exponentialRampToValueAtTime(.0001,ac.currentTime+duration);
      noise.connect(filter);filter.connect(gain);
      if(typeof ac.createStereoPanner==='function'){const panner=ac.createStereoPanner();panner.pan.value=panValue;gain.connect(panner);panner.connect(ac.destination);}else gain.connect(ac.destination);
      const thump=ac.createOscillator(),thumpGain=ac.createGain();thump.type='sine';thump.frequency.setValueAtTime(105,ac.currentTime);thump.frequency.exponentialRampToValueAtTime(48,ac.currentTime+duration);thumpGain.gain.setValueAtTime(clamp(volume*.32,0,1),ac.currentTime);thumpGain.gain.exponentialRampToValueAtTime(.0001,ac.currentTime+duration);thump.connect(thumpGain);thumpGain.connect(ac.destination);
      noise.start();thump.start();noise.stop(ac.currentTime+duration);thump.stop(ac.currentTime+duration);return true;
    }catch(error){console.warn('[FATUM audio] Не удалось воспроизвести встроенный звук урона',error);return false;}
  }
  async function playV061Effect(soundKey,source={}){
    if(!app.audioEngine.unlocked||app.audioEngine.local.effects<=0)return;const item=v061AudioItem(v087ResolvedEffectTrackId(soundKey));
    let volume=app.audioEngine.local.effects,panValue=0;
    if(app.audioEngine.local.spatial&&Number.isFinite(Number(source.x))&&Number.isFinite(Number(source.y))&&app.scene){
      const listener=app.possessedTokenId?tokenById(app.possessedTokenId):selectedToken();
      const center=listener?{x:listener.x,y:listener.y}:screenToWorld({x:app.dimensions.width/2,y:app.dimensions.height/2});
      const distance=pixelsToFeet(Math.hypot(Number(source.x)-center.x,Number(source.y)-center.y));volume*=clamp(1-distance/450,.14,1);
      const halfWorld=Math.max(1,app.dimensions.width/app.view.scale/2);panValue=clamp((Number(source.x)-center.x)/halfWorld,-1,1);
    }
    if(!item){if(soundKey==='token.damage')playV076BuiltinDamage(volume,panValue);return;}
    const buffer=await v061EffectBuffer(item);
    const ac=app.audioEngine.context;
    if(!buffer||!ac)return playV064HtmlEffect(item,volume);
    if(ac.state==='suspended'){try{await ac.resume();}catch(error){console.warn('[FATUM audio] Web Audio fallback',error);return playV064HtmlEffect(item,volume);}}
    const node=ac.createBufferSource(),gain=ac.createGain();node.buffer=buffer;
    gain.gain.value=clamp(volume,0,1);node.connect(gain);if(typeof ac.createStereoPanner==='function'){const panner=ac.createStereoPanner();panner.pan.value=panValue;gain.connect(panner);panner.connect(ac.destination);}else gain.connect(ac.destination);node.start();
  }
  function refreshV061AudioUi(){
    const state=v061AudioState(),lib=state.library||[];
    if($('local-music-volume'))$('local-music-volume').value=app.audioEngine.local.music;if($('local-ambient-volume'))$('local-ambient-volume').value=app.audioEngine.local.ambient;if($('local-effects-volume'))$('local-effects-volume').value=app.audioEngine.local.effects;if($('spatial-audio-enabled'))$('spatial-audio-enabled').checked=app.audioEngine.local.spatial;
    if(!master)return;
    for(const name of ['music','ambient']){const select=$(`${name}-track-select`),channel=state.channels?.[name]||{};if(!select)continue;select.innerHTML='<option value="">— нет трека —</option>'+v087AudioOptions(name,channel.trackId);select.value=channel.trackId||'';$(`${name}-master-volume`).value=Number(channel.volume??.7);$(`${name}-loop`).checked=channel.loop!==false;}
    const stats=state.stats||{},summary=$('audio-library-summary');if(summary)summary.innerHTML=['core','shared','campaign'].map(scope=>`<span><strong>${v087ScopeLabel(scope)}</strong>: ${Number(stats[scope]?.count||0)} · ${v087FormatBytes(stats[scope]?.size||0)}</span>`).join('');
    const filter=$('audio-library-scope-filter')?.value||'all',visible=filter==='all'?lib:lib.filter(item=>(item.scope||'campaign')===filter),list=$('audio-library-list');
    if(list)list.innerHTML=visible.map(item=>`<article class="bm-audio-item" data-scope="${esc(item.scope||'campaign')}"><div><strong>${esc(item.name)}</strong><small>${v087ScopeLabel(item.scope||'campaign')} · ${esc(item.kind)} · ${v087FormatBytes(item.size)}</small></div>${item.scope==='core'?'<span class="bm-audio-core-badge">встроен</span>':`<button class="bm-btn bm-danger" data-audio-delete="${esc(item.id)}">Удалить</button>`}</article>`).join('')||'<p class="bm-muted">В этой библиотеке файлов нет.</p>';
    const bindings=$('audio-effect-bindings');if(bindings)bindings.innerHTML=Object.entries(V061_EFFECT_LABELS).map(([key,label])=>{const value=state.effectBindings?.[key]??'';return`<label class="bm-audio-binding"><span>${esc(label)}</span><select data-effect-key="${esc(key)}">${v087AudioOptions('effect',value,{includeOff:true,includeStandard:true})}</select></label>`;}).join('');
  }
  async function updateV061AudioChannel(channel,patch){try{const result=await api('/api/battlemap/audio/channel',{method:'PUT',body:commonBody({channel,...patch})});if(result.audio){app.battlemap.audio=result.audio;syncV061Audio();}}catch(error){toast(error.message,'error');}}
  async function uploadV061Audio(){
    const input=$('audio-upload-file'),files=[...(input?.files||[])];
    if(!files.length){toast('Выберите один или несколько аудиофайлов.','error');return;}
    const button=$('audio-upload-btn'),status=$('audio-upload-status'),originalText=button.textContent;
    const kind=$('audio-upload-kind').value,scope=$('audio-upload-scope')?.value==='shared'?'shared':'campaign',errors=[],warnings=[];let uploaded=0,latestAudio=null;
    button.disabled=true;
    try{
      for(let index=0;index<files.length;index++){
        const file=files[index];
        button.textContent=`Загрузка ${index+1}/${files.length}…`;
        if(status)status.textContent=`Загружается «${file.name}» (${index+1} из ${files.length})`;
        try{
          if(file.type==='audio/wav'||/\.wav$/i.test(file.name)||kind==='effect'&&file.size>5*1024*1024||kind!=='effect'&&file.size>25*1024*1024)warnings.push(file.name);
          const query=new URLSearchParams({kind,scope,name:file.name});
          const response=await fetch(`/api/battlemap/audio/upload?${query}`,{method:'POST',credentials:'same-origin',headers:{'Content-Type':file.type||'application/octet-stream'},body:file});
          const payload=await response.json().catch(()=>({}));
          if(!response.ok)throw new Error(payload.error||`HTTP ${response.status}`);
          latestAudio=payload.audio||latestAudio;uploaded+=1;if(payload.warning&&!warnings.includes(file.name))warnings.push(file.name);
        }catch(error){errors.push(`${file.name}: ${error.message}`);}
      }
      if(latestAudio)app.battlemap.audio=latestAudio;
      input.value='';refreshV061AudioUi();
      if(status)status.textContent=errors.length?`Загружено ${uploaded} из ${files.length}. Ошибок: ${errors.length}.`:`Загружено файлов: ${uploaded}.${warnings.length?' Крупные файлы: '+warnings.length+'.':''}`;
      if(errors.length){toast(uploaded?`Загружено ${uploaded} из ${files.length}. Не удалось: ${errors.map(item=>item.split(':')[0]).join(', ')}`:`Не удалось загрузить файлы: ${errors.join(' · ')}`,'error');}
      else toast(`Загружено аудиофайлов: ${uploaded}.`,'success');
    }finally{button.disabled=false;button.textContent=originalText;}
  }
  async function saveV062Binding(key,value){
    const revision=++app.audioEngine.bindingRevision;app.audioEngine.pendingBindings.set(key,{value:value||null,revision});refreshV061AudioUi();
    try{const payload=await api('/api/battlemap/audio/bindings',{method:'PUT',body:commonBody({bindings:{[key]:value||null}})});const pending=app.audioEngine.pendingBindings.get(key);if(pending?.revision===revision)app.audioEngine.pendingBindings.delete(key);if(payload.audio)app.battlemap.audio=payload.audio;refreshV061AudioUi();}
    catch(error){const pending=app.audioEngine.pendingBindings.get(key);if(pending?.revision===revision)app.audioEngine.pendingBindings.delete(key);refreshV061AudioUi();toast(`Не удалось сохранить звук: ${error.message}`,'error');}
  }
  async function saveV061Bindings(){const result={};$('audio-effect-bindings').querySelectorAll('[data-effect-key]').forEach(select=>result[select.dataset.effectKey]=select.value||null);try{for(const [key,value] of Object.entries(result))app.audioEngine.pendingBindings.set(key,{value,revision:++app.audioEngine.bindingRevision});const payload=await api('/api/battlemap/audio/bindings',{method:'PUT',body:commonBody({bindings:result})});app.audioEngine.pendingBindings.clear();app.battlemap.audio=payload.audio;refreshV061AudioUi();toast('Звуки действий сохранены.','success');}catch(error){app.audioEngine.pendingBindings.clear();refreshV061AudioUi();toast(error.message,'error');}}

  function v061FreshWeapons(token){
    if(!token)return[];
    if(token.kind!=='character')return Array.isArray(token.weapons)&&token.weapons.length?token.weapons:baseClientWeaponsV061(token);
    const character=characterById(token.refId),st=character?.state||{},inventory=Array.isArray(st.inventory)?st.inventory:[],equipment=st.equipment||{},stored=Array.isArray(st._lanBattleProfile?.weapons)?st._lanBattleProfile.weapons:[],serverWeapons=Array.isArray(token.weapons)?token.weapons:[];
    const accuracy=Number(st._lanRollProfile?.skills?.['Меткость']?.bonus??st.skills?.['Меткость']?.bonus??0);
    const categoryFor=type=>({'Пистолет':'Пистолеты','Карабин':'Карабины','Снайперская винтовка':'Винтовки','Дробовик':'Дробовики','Тяжёлое':'Тяжёлое'}[type]||null);
    return ['weapon1','weapon2'].map(slot=>{
      const key=equipment[slot];if(!key)return null;const server=serverWeapons.find(w=>w.slot===slot||w.id===slot)||{},saved=stored.find(w=>w.slot===slot||w.id===slot)||{},old={...saved,...server};const item=inventory.find(candidate=>candidate?.uid===key||candidate?.id===key||candidate?.name===key);if(!item)return Object.keys(old).length?old:null;
      const description=String(item.desc||item.description||old.description||''),type=String(item.type||old.type||''),profile=String(item.profile||old.profile||item.name||key);
      const text=description.replace(/к/g,'d'),pair=text.match(/Попадание:\s*(1d(?:4|6|8|10|12))[^/]*\/\s*(1d(?:4|6|8|10|12))/i),single=text.match(/(?:Попадание[:\s]*)?(1d(?:4|6|8|10|12))/i),ranges=[...text.matchAll(/(\d+)\s*фт/gi)].map(m=>Number(m[1]));
      const radius=Number(text.match(/(\d+)\s*фт\s*радиус/i)?.[1]||old.radius||0),range=ranges.length?Math.max(...ranges):Number(old.range||5),threshold=Number(text.match(/порог\s*(\d+)/i)?.[1]||0),category=categoryFor(type),proficiency=Number(st.weaponProficiencies?.[category]||0),melee=type==='Оружие ближнего боя';
      const meleeBonus=Math.max(Number(st._lanRollProfile?.skills?.['Акробатика']?.bonus||0),Number(st._lanRollProfile?.skills?.['Физическая сила']?.bonus||0));
      const hitDieNormal=pair?.[1]||single?.[1]||old.hitDieNormal||'1d6',hitDieAimed=pair?.[2]||old.hitDieAimed||(type==='Пистолет'?(hitDieNormal==='1d4'?'1d6':hitDieNormal==='1d6'?'1d8':hitDieNormal):'');
      const odMatch=text.match(/(\d+)\s*ОД/i),odCost=Number(odMatch?.[1]??old.odCost??(type==='Пистолет'?1:2));const aimedMatch=text.match(/прицельн\w*\s+(?:выстрел|атака)[^.;]*?(\d+)\s*ОД/i),aimedOdCost=hitDieAimed?Number(aimedMatch?.[1]??old.aimedOdCost??(type==='Пистолет'?2:odCost+1)):null;
      return {...old,id:slot,slot,name:item.customModel||item.selectedModel||item.name||profile,profile,type,melee,hitDieNormal,hitDieAimed,hitBonus:melee?meleeBonus:proficiency+Math.floor(accuracy/2)-threshold,damage:Number(text.match(/урон\s*(\d+)/i)?.[1]||old.damage||1),damageTag:item.damageTag||old.damageTag||'medium',odCost,aimedOdCost,obCost:/каждая атака требует\s*1\s*ОБ/i.test(description)?1:Number(old.obCost||0),range,radius,description,notes:Array.isArray(old.notes)?old.notes:[]};
    }).filter(Boolean);
  }
  const baseClientWeaponsV061=clientWeapons;
  clientWeapons=function(token){return v061FreshWeapons(token);};

  function v061WeaponId(weapon){return weapon?.id||weapon?.slot||weapon?.name;}
  function v061Profile(weapon){return String(weapon?.profile||weapon?.name||'');}
  function v061CanDual(token,weapons){const st=token?.kind==='character'?characterById(token.refId)?.state:null;return Number(st?.traits?.main?.['Ловкий']||0)>=3&&weapons.filter(w=>V061_DUAL_PROFILES.includes(v061Profile(w))).length>=2;}
  function v061TargetPoint(){const action=app.actionTarget;if(!action)return null;const hovered=hitTestToken(app.lastMouseWorld);if((action.type==='ranged'||action.type==='melee')&&hovered&&hovered.id!==action.attackerId)return{x:hovered.x,y:hovered.y,target:hovered};return{x:app.lastMouseWorld.x,y:app.lastMouseWorld.y,target:null};}
  function v061PreviewInfo(){
    const action=app.actionTarget,attacker=tokenById(action?.attackerId),point=v061TargetPoint();if(!action||!attacker||!point)return null;const weapon=allClientWeapons(attacker).find(w=>v061WeaponId(w)===action.weaponId)||null;
    let radiusFeet=0;if(action.type==='area-ranged')radiusFeet=Number(weapon?.radius||0);if(action.type==='weapon-zone')radiusFeet=action.zoneMode==='barrage'?(v061Profile(weapon)==='Тяжёлый пулемёт'?10.6:7.1):7.5;
    const distance=pixelsToFeet(Math.hypot(point.x-attacker.x,point.y-attacker.y)),maxRange=Number(weapon?.range||0),segments=effectiveVisionSegments(),blocked=segments.some(seg=>clientSegmentIntersection(attacker,point,{x:seg.x1,y:seg.y1},{x:seg.x2,y:seg.y2})),valid=(!maxRange||distance<=maxRange+.01)&&!blocked;
    return{action,attacker,point,weapon,distance,maxRange,radiusFeet,radiusPx:feetToPixels(radiusFeet),blocked,valid};
  }
  function v061TokenAffected(token){const info=v061PreviewInfo();if(!info||info.radiusPx<=0||token.id===info.attacker.id)return false;return Math.hypot(token.x-info.point.x,token.y-info.point.y)<=info.radiusPx+tokenRadius(token)*.2;}
  function drawV061TargetPreview(target){
    const info=v061PreviewInfo();if(!info)return;const color=info.valid?'#70d7ff':'#ff6b64';target.save();target.beginPath();target.moveTo(info.attacker.x,info.attacker.y);target.lineTo(info.point.x,info.point.y);target.strokeStyle=color;target.lineWidth=2.5/app.view.scale;target.setLineDash([10/app.view.scale,6/app.view.scale]);target.stroke();target.setLineDash([]);
    if(info.radiusPx>0){target.beginPath();target.arc(info.point.x,info.point.y,info.radiusPx,0,Math.PI*2);target.fillStyle=hexToRgba(color,.14);target.fill();target.strokeStyle=color;target.lineWidth=3/app.view.scale;target.stroke();if(info.action.type==='area-ranged'&&Number(info.weapon?.damage||0)>0){target.beginPath();target.arc(info.point.x,info.point.y,info.radiusPx/2,0,Math.PI*2);target.strokeStyle=hexToRgba(color,.75);target.setLineDash([5/app.view.scale,4/app.view.scale]);target.stroke();target.setLineDash([]);}}
    target.beginPath();target.arc(info.point.x,info.point.y,7/app.view.scale,0,Math.PI*2);target.fillStyle=color;target.fill();const label=`${info.weapon?.name||info.action.zoneMode||'Цель'} · ${info.distance.toFixed(1)}${info.maxRange?`/${info.maxRange}`:''} фт${info.blocked?' · линия перекрыта':!info.valid?' · вне дальности':''}`;target.font=`${12/app.view.scale}px Segoe UI`;const width=target.measureText(label).width+14/app.view.scale;target.fillStyle='rgba(7,10,14,.86)';target.fillRect(info.point.x-width/2,info.point.y-(info.radiusPx||0)-27/app.view.scale,width,19/app.view.scale);target.fillStyle=info.valid?'#dff8ff':'#ffd0cc';target.textAlign='center';target.textBaseline='middle';target.fillText(label,info.point.x,info.point.y-(info.radiusPx||0)-17/app.view.scale);
    for(const token of app.scene.tokens||[]){if(!v061TokenAffected(token))continue;const v=visualTokenState(token),r=tokenRadius(token)+8/app.view.scale;target.beginPath();target.arc(v.x,v.y,r,0,Math.PI*2);target.fillStyle='rgba(255,180,65,.18)';target.fill();target.strokeStyle='#ffc15c';target.lineWidth=4/app.view.scale;target.stroke();}
    target.restore();requestRender();
  }

  const baseBeginDockTargetV061=beginDockTarget;
  beginDockTarget=function(type,weaponId,shotMode='normal',specialMode=null){
    const token=selectedToken(),weapon=allClientWeapons(token).find(w=>v061WeaponId(w)===weaponId);if(type==='ranged'&&Number(weapon?.radius||0)>0){if(!token||!canControlToken(token))return;app.actionTarget={type:'area-ranged',attackerId:token.id,weaponId,shotMode,specialMode};document.body.classList.add('bm-targeting');setTool('select');setActionDescription('Укажите точку попадания гранатомётного выстрела.');toast('Выберите точку выстрела.');requestRender();return;}baseBeginDockTargetV061(type,weaponId,shotMode,specialMode);requestRender();
  };
  const baseCancelDockTargetV061=cancelDockTarget;
  cancelDockTarget=function(){baseCancelDockTargetV061();requestRender();};
  async function performV061AreaAttack(point){const action=app.actionTarget,attacker=tokenById(action?.attackerId);if(!action||!attacker||app.attackPending)return;app.attackPending=true;try{const result=await api('/api/battlemap/area-attack',{method:'POST',body:commonBody({requestId:id(),sceneId:app.scene.id,attackerTokenId:attacker.id,weaponId:action.weaponId,x:point.x,y:point.y,moved:Boolean(movementForToken(attacker)?.spent),spendResources:combatActive()})});toast(result.hit?'Гранатомётный выстрел попал в выбранную точку.':`Снаряд отклонился на ${result.scatter} фт.`,result.hit?'success':'error');if(result.entry)appendTableLogClient(result.entry);if(result.visualZone)addTransientEffect(app.scene.id,result.visualZone,result.visualTtlMs||9000);await fetchAll(true);}catch(error){toast(error.message,'error');}finally{app.attackPending=false;cancelDockTarget();}}
  async function performV061WeaponZone(point){const action=app.actionTarget,token=tokenById(action?.attackerId);if(!action||!token||app.attackPending)return;app.attackPending=true;try{const result=await api('/api/battlemap/weapon-zone',{method:'POST',body:commonBody({requestId:id(),sceneId:app.scene.id,tokenId:token.id,weaponId:action.weaponId,mode:action.zoneMode,x:point.x,y:point.y})});toast(`${result.effect?.name||'Режим огня'} создан.`, 'success');await fetchAll(true);}catch(error){toast(error.message,'error');}finally{app.attackPending=false;cancelDockTarget();}}
  performDockRanged=async function(target){
    const action=app.actionTarget,attacker=tokenById(action?.attackerId);if(!action||!attacker||!target||target.id===attacker.id||app.attackPending)return;app.attackPending=true;
    try{const result=await api('/api/battlemap/attack',{method:'POST',body:commonBody({requestId:id(),sceneId:app.scene.id,attackerTokenId:attacker.id,targetTokenId:target.id,weaponId:action.weaponId,shotMode:action.shotMode||'normal',specialMode:action.specialMode||null,targetPart:app.pendingTargetPart||null,situationalModifier:0,targetMz:null,moved:Boolean(movementForToken(attacker)?.spent),spendResources:combatActive(),autoApplyDamage:true,visibility:'public'})});if(result.roll)startRollVisual(result.roll);if(result.attack)showAttackResult(result.attack,true);renderAutoDamageResult(result.damageResult);await fetchAll(true);}catch(error){toast(error.message,'error');}finally{app.attackPending=false;cancelDockTarget();}
  };

  const baseRefreshActionDockV061=refreshActionDock;
  refreshActionDock=function(){
    baseRefreshActionDockV061();const token=selectedToken(),slots=$('action-slots');if(!token||!slots||$('action-dock').hidden)return;const weapons=allClientWeapons(token),canAct=combatCanAct(token);let extra='';
    for(const weapon of weapons){const profile=v061Profile(weapon),wid=v061WeaponId(weapon);if(V061_SUPPRESSION_PROFILES.includes(profile))extra+=actionButtonHtml(`zone-suppression:${wid}`,'≋',`Подавление: ${weapon.name}`,weapon.odCost??2,'Создать позицию подавления до следующего хода.','weapon');if(V061_BARRAGE_PROFILES.includes(profile))extra+=actionButtonHtml(`zone-barrage:${wid}`,'▦',`Шквальный огонь: ${weapon.name}`,weapon.odCost??2,'Создать опасную зону огня; дополнительно 1 ОБ.','weapon');if(V061_ANAXION_PROFILES.includes(profile))extra+=actionButtonHtml(`special-anaxion:${wid}`,'✧',`Анаксионный режим`,weapon.odCost??2,'Следующая атака получает +1 входящего урона; дополнительно 1 ОБ.','weapon');}
    if(v061CanDual(token,weapons)){const primary=weapons.find(w=>V061_DUAL_PROFILES.includes(v061Profile(w)));if(primary)extra+=actionButtonHtml(`special-dual:${v061WeaponId(primary)}`,'⚯','Стрельба с двух рук',primary.odCost??1,'Одна атака, два броска куба попадания, выбрать лучший; дополнительно 1 ОБ.','weapon');}
    if(extra){slots.insertAdjacentHTML('beforeend',extra);slots.querySelectorAll('[data-dock-action^="zone-"],[data-dock-action^="special-"]').forEach(btn=>{if(!canAct)btn.disabled=true;btn.onmouseenter=()=>setActionDescription(btn.title);btn.onmouseleave=()=>setActionDescription(app.actionTarget?'Выберите точку или цель.':'Выберите действие.');});}
  };

  const baseOnPointerDownV061=onPointerDown;
  onPointerDown=function(event){
    if(app.actionTarget&&event.button===0&&app.scene){const world=screenToWorld(eventPoint(event));if(app.actionTarget.type==='area-ranged'){event.preventDefault();performV061AreaAttack(world);return;}if(app.actionTarget.type==='weapon-zone'){event.preventDefault();performV061WeaponZone(world);return;}}
    return baseOnPointerDownV061(event);
  };
  const baseOnPointerMoveV061=onPointerMove;
  onPointerMove=function(event){if(app.actionTarget&&app.scene){app.lastMouseWorld=screenToWorld(eventPoint(event));requestRender();}return baseOnPointerMoveV061(event);};

  const baseApplyBattlemapV061=applyBattlemap;
  applyBattlemap=function(battlemap,preserveSelection=true){baseApplyBattlemapV061(battlemap,preserveSelection);queueMicrotask(syncV061Audio);};
  const baseRefreshAllUiV061=refreshAllUi;
  refreshAllUi=function(){baseRefreshAllUiV061();refreshV061AudioUi();syncV061Audio();};
  const baseConnectEventsV061=connectEvents;
  connectEvents=function(){baseConnectEventsV061();app.eventSource?.addEventListener('battlemap-audio-effect',event=>{try{const payload=JSON.parse(event.data);if(payload.sceneId===app.scene?.id)playV061Effect(payload.soundKey,payload.source||{});}catch(error){console.warn(error);}});};

  function bindV061Ui(){
    $('audio-unlock-btn').onclick=()=>unlockV061Audio();
    const autoUnlock=event=>{
      if(app.audioEngine.unlocked){window.removeEventListener('pointerdown',autoUnlock,true);window.removeEventListener('keydown',autoUnlock,true);return;}
      const tag=event.target?.tagName;
      if(event.target?.isContentEditable||tag==='INPUT'||tag==='TEXTAREA'||tag==='SELECT')return;
      if(unlockV061Audio({silent:true})){window.removeEventListener('pointerdown',autoUnlock,true);window.removeEventListener('keydown',autoUnlock,true);}
    };
    window.addEventListener('pointerdown',autoUnlock,true);
    window.addEventListener('keydown',autoUnlock,true);
    for(const name of ['music','ambient']){
      $(`local-${name}-volume`).oninput=e=>setV062LocalChannelVolume(name,e.target.value);
      if(master){$(`${name}-track-select`).onchange=e=>updateV061AudioChannel(name,{trackId:e.target.value||null});$(`${name}-master-volume`).oninput=e=>updateV061AudioChannel(name,{volume:Number(e.target.value)});$(`${name}-loop`).onchange=e=>updateV061AudioChannel(name,{loop:e.target.checked});$(`${name}-play-btn`).onclick=()=>updateV061AudioChannel(name,{action:'play'});$(`${name}-pause-btn`).onclick=()=>updateV061AudioChannel(name,{action:'pause'});$(`${name}-stop-btn`).onclick=()=>updateV061AudioChannel(name,{action:'stop'});}
    }
    $('local-effects-volume').oninput=e=>{app.audioEngine.local.effects=Number(e.target.value);localStorage.setItem('fatumAudioEffects',String(e.target.value));};$('spatial-audio-enabled').onchange=e=>{app.audioEngine.local.spatial=e.target.checked;localStorage.setItem('fatumAudioSpatial',e.target.checked?'1':'0');if(typeof v070SyncAudioSources==='function')v070SyncAudioSources();};
    if(master){$('audio-upload-btn').onclick=uploadV061Audio;$('save-audio-bindings-btn').onclick=saveV061Bindings;$('audio-effect-bindings').addEventListener('change',e=>{const select=e.target.closest('[data-effect-key]');if(select)saveV062Binding(select.dataset.effectKey,select.value||null);});$('audio-library-scope-filter')?.addEventListener('change',refreshV061AudioUi);$('rescan-core-audio-btn')?.addEventListener('click',async()=>{try{const payload=await api('/api/battlemap/audio/rescan-core',{method:'POST',body:commonBody()});app.battlemap.audio=payload.audio;refreshV061AudioUi();toast(`Найдено встроенных файлов: ${payload.found}.`,'success');}catch(error){toast(error.message,'error');}});$('cleanup-campaign-audio-btn')?.addEventListener('click',async()=>{if(!confirm('Удалить все неиспользуемые аудиофайлы этой кампании?'))return;try{const payload=await api('/api/battlemap/audio/cleanup-campaign',{method:'POST',body:commonBody()});app.battlemap.audio=payload.audio;refreshV061AudioUi();toast(`Удалено файлов: ${payload.removed}; освобождено ${v087FormatBytes(payload.freedBytes)}.`,'success');}catch(error){toast(error.message,'error');}});$('audio-library-list').addEventListener('click',async e=>{const button=e.target.closest('[data-audio-delete]');if(!button||!confirm('Удалить этот аудиофайл?'))return;try{const payload=await api(`/api/battlemap/audio/${encodeURIComponent(button.dataset.audioDelete)}`,{method:'DELETE',body:commonBody()});app.battlemap.audio=payload.audio;refreshV061AudioUi();}catch(error){toast(error.message,'error');}});}
    $('action-slots').addEventListener('click',event=>{const btn=event.target.closest('[data-dock-action]');if(!btn||btn.disabled)return;const key=btn.dataset.dockAction;if(key.startsWith('zone-suppression:')){const weaponId=key.slice('zone-suppression:'.length),token=selectedToken();app.actionTarget={type:'weapon-zone',zoneMode:'suppression',attackerId:token.id,weaponId};document.body.classList.add('bm-targeting');setTool('select');setActionDescription('Укажите позицию, которую подавляет оружие.');requestRender();}else if(key.startsWith('zone-barrage:')){const weaponId=key.slice('zone-barrage:'.length),token=selectedToken();app.actionTarget={type:'weapon-zone',zoneMode:'barrage',attackerId:token.id,weaponId};document.body.classList.add('bm-targeting');setTool('select');setActionDescription('Укажите область Шквального огня.');requestRender();}else if(key.startsWith('special-anaxion:'))beginDockTarget('ranged',key.slice('special-anaxion:'.length),'normal','anaxion');else if(key.startsWith('special-dual:'))beginDockTarget('ranged',key.slice('special-dual:'.length),'normal','dual');});
    document.addEventListener('click',event=>{if(event.target.closest('button,.bm-sidebar-tabs [data-panel]'))playV061Effect('ui.click',{});},{capture:false});
    window.addEventListener('keydown',event=>{if(event.code!=='Space'||isFormTarget(event.target)||event.repeat)return;app.spaceDown=true;stage.classList.add('space-pan');document.querySelectorAll('.bm-tool').forEach(button=>button.classList.toggle('active',button.dataset.tool==='pan'));event.preventDefault();},{capture:true});
    window.addEventListener('keyup',event=>{if(event.code!=='Space')return;app.spaceDown=false;stage.classList.remove('space-pan');app.tool='select';document.querySelectorAll('.bm-tool').forEach(button=>button.classList.toggle('active',button.dataset.tool==='select'));stage.className='bm-stage tool-select';requestRender();event.preventDefault();},{capture:true});
    refreshV061AudioUi();
    setV064AudioStatus(app.audioEngine.unlocked?'ready':'idle',app.audioEngine.unlocked?'Звук включён для этой вкладки.':'Нажмите «Звук» или один раз взаимодействуйте с картой.');
  }


  /* ===== FATUM Battlemap v0.7.0: hit feedback, curved geometry, audio objects, vehicles and daylight ===== */
  app.hitAnimations = new Map();
  app.audioSourcePlayers = new Map();
  app.vehicleProfiles = [];
  app.v070AudioSyncTimer = null;

  function v070WallPoints(wall) {
    const points=Array.isArray(wall?.points)?wall.points.filter(p=>Number.isFinite(Number(p?.x))&&Number.isFinite(Number(p?.y))).map(p=>({x:Number(p.x),y:Number(p.y)})):[];
    return points.length>=2?points:[{x:Number(wall?.x1||0),y:Number(wall?.y1||0)},{x:Number(wall?.x2||0),y:Number(wall?.y2||0)}];
  }
  function v070PolylineLength(points){let total=0;for(let i=1;i<points.length;i++)total+=Math.hypot(points[i].x-points[i-1].x,points[i].y-points[i-1].y);return total;}
  function v070PointAt(points,t){
    if(!points.length)return{x:0,y:0};if(points.length===1)return{...points[0]};
    const total=Math.max(.0001,v070PolylineLength(points)),wanted=clamp(Number(t||0),0,1)*total;let walked=0;
    for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],len=Math.hypot(b.x-a.x,b.y-a.y);if(walked+len>=wanted){const q=len?(wanted-walked)/len:0;return{x:a.x+(b.x-a.x)*q,y:a.y+(b.y-a.y)*q};}walked+=len;}
    return{...points[points.length-1]};
  }
  function v070IntervalSegments(points,t1=0,t2=1){
    const result=[],total=Math.max(.0001,v070PolylineLength(points)),start=clamp(t1,0,1)*total,end=clamp(t2,0,1)*total;if(end<=start)return result;let walked=0;
    for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],len=Math.hypot(b.x-a.x,b.y-a.y),segStart=walked,segEnd=walked+len;const from=Math.max(start,segStart),to=Math.min(end,segEnd);if(to>from+.0001){const q1=len?(from-segStart)/len:0,q2=len?(to-segStart)/len:1;result.push({a:{x:a.x+(b.x-a.x)*q1,y:a.y+(b.y-a.y)*q1},b:{x:a.x+(b.x-a.x)*q2,y:a.y+(b.y-a.y)*q2}});}walked=segEnd;}return result;
  }
  function v070Path(target,points,close=false){if(!points?.length)return;target.moveTo(points[0].x,points[0].y);for(const point of points.slice(1))target.lineTo(point.x,point.y);if(close)target.closePath();}
  function v070Center(points){if(!points?.length)return{x:0,y:0};const total=v070PolylineLength(points);return total?v070PointAt(points,.5):points[0];}

  bmPointOnWall=function(wall,t){return v070PointAt(v070WallPoints(wall),t);};
  doorGeometry=function(door){
    const wall=door.wallId?app.scene?.walls.find(item=>item.id===door.wallId):null;
    if(!wall){const x1=Number(door.x1||0),y1=Number(door.y1||0),x2=Number(door.x2||x1+door.width||70),y2=Number(door.y2||y1);return{x1,y1,x2,y2,center:{x:(x1+x2)/2,y:(y1+y2)/2},wall:null,t1:0,t2:1};}
    const points=v070WallPoints(wall),length=Math.max(1,v070PolylineLength(points)),half=Math.min(.49,Number(door.width||70)/length/2),t1=clamp(Number(door.t??.5)-half,0,1),t2=clamp(Number(door.t??.5)+half,0,1),a=v070PointAt(points,t1),b=v070PointAt(points,t2);
    return{x1:a.x,y1:a.y,x2:b.x,y2:b.y,center:v070PointAt(points,Number(door.t??.5)),wall,t1,t2};
  };
  wallDrawSegments=function(wall){
    const points=v070WallPoints(wall),gaps=(app.scene?.doors||[]).filter(d=>d.wallId===wall.id).map(doorGeometry).sort((a,b)=>a.t1-b.t1),segments=[];let cursor=0;
    for(const gap of gaps){if(gap.t1>cursor)segments.push(...v070IntervalSegments(points,cursor,gap.t1));cursor=Math.max(cursor,gap.t2);}if(cursor<1)segments.push(...v070IntervalSegments(points,cursor,1));return segments;
  };
  effectiveVisionSegments=function(){const list=[];for(const wall of app.scene?.walls||[]){if(!wall.blocksVision)continue;for(const segment of wallDrawSegments(wall))list.push({x1:segment.a.x,y1:segment.a.y,x2:segment.b.x,y2:segment.b.y});}for(const door of app.scene?.doors||[]){if(door.open)continue;const g=doorGeometry(door);list.push({x1:g.x1,y1:g.y1,x2:g.x2,y2:g.y2});}return list;};
  clientMovementSegments=function(){const result=[];for(const wall of app.scene?.walls||[]){if(!wall.blocksMovement)continue;result.push(...wallDrawSegments(wall));}for(const door of app.scene?.doors||[]){if(door.open)continue;const g=doorGeometry(door);result.push({a:{x:g.x1,y:g.y1},b:{x:g.x2,y:g.y2}});}return result;};
  hitTestWall=function(point){if(!master)return null;const threshold=10/app.view.scale;return[...(app.scene?.walls||[])].reverse().find(wall=>wallDrawSegments(wall).some(seg=>pointSegmentDistance(point,seg.a,seg.b)<=threshold))||null;};

  function v070CoverCenter(cover){if(cover.shape==='circle')return{x:cover.x,y:cover.y};if((cover.shape==='polygon'||cover.shape==='polyline')&&cover.points?.length)return v070Center(cover.points);return{x:Number(cover.x||0)+Number(cover.width||0)/2,y:Number(cover.y||0)+Number(cover.height||0)/2};}
  function v070DrawCover(target,cover){
    if(cover.hidden&&!master)return;const selected=app.selected?.type==='cover'&&app.selected.id===cover.id,showGeometry=master||cover.showGeometryToPlayers===true,color=cover.color||'#65a1c9';
    const buildPath=()=>{target.beginPath();if(cover.shape==='circle')target.arc(cover.x,cover.y,cover.radius,0,Math.PI*2);else if(cover.shape==='polygon'&&cover.points?.length)v070Path(target,cover.points,true);else if(cover.shape==='polyline'&&cover.points?.length)v070Path(target,cover.points,false);else target.rect(cover.x,cover.y,cover.width,cover.height);};
    target.save();
    if(showGeometry){
      buildPath();
      if(cover.shape!=='polyline'){target.fillStyle=hexToRgba(color,master ? .22 : .11);target.fill();}
      target.globalAlpha=master?1:.62;
      if(cover.shape==='polyline'&&selected){target.strokeStyle='#ffd36a';target.lineWidth=Math.max(2,Number(cover.thickness||18))+8/app.view.scale;target.shadowColor='rgba(255,211,106,.72)';target.shadowBlur=14/app.view.scale;target.stroke();target.shadowBlur=0;buildPath();target.strokeStyle=color;target.lineWidth=Math.max(2,Number(cover.thickness||18));target.stroke();}
      else{target.strokeStyle=selected?'#ffd36a':color;target.lineWidth=cover.shape==='polyline'?Math.max(2,Number(cover.thickness||18)):(selected?5:3)/app.view.scale;target.stroke();}
      target.globalAlpha=1;
    }
    if(Number(cover.mz||0)>0){const center=v070CoverCenter(cover),label=master?`${cover.name||'Укрытие'} · МЗ ${cover.mz}`:`МЗ ${cover.mz}`;target.font=`bold ${12/app.view.scale}px Segoe UI`;target.textAlign='center';target.textBaseline='middle';const width=target.measureText(label).width+12/app.view.scale;target.fillStyle='rgba(10,14,18,.82)';target.fillRect(center.x-width/2,center.y-10/app.view.scale,width,20/app.view.scale);target.fillStyle='#e8f3fb';target.fillText(label,center.x,center.y);}
    target.restore();
  }
  drawCover=v070DrawCover;
  drawWalls=function(target){
    for(const cover of app.scene?.covers||[])v070DrawCover(target,cover);
    for(const wall of app.scene?.walls||[]){const selected=app.selected?.type==='wall'&&app.selected.id===wall.id,showGeometry=master||wall.showGeometryToPlayers===true;target.save();if(showGeometry){for(const segment of wallDrawSegments(wall)){target.beginPath();target.moveTo(segment.a.x,segment.a.y);target.lineTo(segment.b.x,segment.b.y);target.lineWidth=(selected?7:4)/app.view.scale;target.strokeStyle=selected?'#ffd36a':'#c7554f';target.globalAlpha=master?1:.58;target.stroke();}target.globalAlpha=1;}if(Number(wall.coverMz||0)>0){const center=v070Center(v070WallPoints(wall)),label=master?`${wall.coverName||'Стена'} · МЗ ${wall.coverMz}`:`МЗ ${wall.coverMz}`;target.font=`bold ${12/app.view.scale}px Segoe UI`;target.textAlign='center';const width=target.measureText(label).width+10/app.view.scale;target.fillStyle='rgba(10,14,18,.82)';target.fillRect(center.x-width/2,center.y-16/app.view.scale,width,18/app.view.scale);target.fillStyle='#dcecf7';target.fillText(label,center.x,center.y-3/app.view.scale);}target.restore();}
    for(const door of app.scene?.doors||[])drawDoor(target,door);
  };

  const v070BaseDrawDraft=drawDraft;
  drawDraft=function(target){
    if(app.draft?.type==='wall-curve'||app.draft?.type==='cover-curve'){const d=app.draft,points=[...(d.points||[]),d.current].filter(Boolean);target.save();target.beginPath();v070Path(target,points,false);target.strokeStyle=d.type==='wall-curve'?'#e85e58':'#9bccec';target.lineWidth=d.type==='cover-curve'?Math.max(3,Number($('new-cover-thickness')?.value||18)):3/app.view.scale;target.setLineDash([8/app.view.scale,5/app.view.scale]);target.stroke();target.restore();return;}v070BaseDrawDraft(target);
  };

  function v070HitTestAudioSource(point){if(!master)return null;return[...(app.scene?.audioSources||[])].reverse().find(source=>Math.hypot(point.x-source.x,point.y-source.y)<=16/app.view.scale)||null;}
  function v070DrawAudioSources(target){for(const source of app.scene?.audioSources||[]){if(source.hidden&&!master)continue;if(!master&&source.hidden)continue;const selected=app.selected?.type==='audioSource'&&app.selected.id===source.id;target.save();target.translate(source.x,source.y);target.beginPath();target.arc(0,0,11/app.view.scale,0,Math.PI*2);target.fillStyle=source.enabled?'#89c7ef':'#606873';target.strokeStyle=selected?'#ffd36a':'#182838';target.lineWidth=(selected?4:2)/app.view.scale;target.fill();target.stroke();target.font=`${13/app.view.scale}px Segoe UI`;target.textAlign='center';target.textBaseline='middle';target.fillStyle='#10202c';target.fillText('♫',0,0);if(master){target.beginPath();target.arc(0,0,feetToPixels(source.radius||60),0,Math.PI*2);target.strokeStyle='rgba(117,190,236,.45)';target.lineWidth=2/app.view.scale;target.setLineDash([8/app.view.scale,6/app.view.scale]);target.stroke();target.setLineDash([]);}target.restore();}}

  function v070DayLabel(value){const v=clamp(Number(value||0),0,1);return v<.28?'День':v<.72?'Вечер':'Ночь';}
  function v070Smoothstep(a,b,x){const t=clamp((x-a)/(b-a),0,1);return t*t*(3-2*t);}
  function v071Lerp(a,b,t){return a+(b-a)*clamp(t,0,1);}
  function v071DayGrade(value,enabled=true){if(!enabled)return{exposure:1,saturation:1,contrast:1};const phase=clamp(Number(value||0),0,1);if(phase<=.55){const t=v070Smoothstep(.12,.55,phase);return{exposure:v071Lerp(1.07,.93,t),saturation:v071Lerp(1.08,1.02,t),contrast:v071Lerp(1.01,1.07,t)};}const t=v070Smoothstep(.55,1,phase);return{exposure:v071Lerp(.93,.80,t),saturation:v071Lerp(1.02,.66,t),contrast:v071Lerp(1.07,1.12,t)};}
  drawLightingAndFog=function(){
    const scene=app.scene;if(!scene)return;const{width,height,dpr}=app.dimensions,preview=Boolean($('preview-player-vision')?.checked),masterFull=master&&!preview;
    const localLights=scene.settings.dynamicLightEnabled&&(!masterFull||scene.settings.masterSeesLighting!==false),phase=clamp(Number(scene.settings.dayPhase??1),0,1),daylight=scene.settings.daylightEnabled!==false;
    const sources=[];for(const light of scene.lights||[])if(light.enabled)sources.push({...light,sourceType:'static'});for(const token of scene.tokens||[])if(token.light?.enabled&&(!token.hidden||master||canControlToken(token)))sources.push({id:`token-${token.id}`,x:token.x,y:token.y,rotation:token.rotation,...token.light,sourceType:'token'});
    const ambient=clamp(Number(scene.settings.ambientDarkness??.82),0,1),darkness=daylight?ambient*(.055+.945*v070Smoothstep(.18,1,phase)):(scene.settings.globalIllumination?0:ambient);
    if(darkness>.005){const dark=newOverlay(),dc=dark.getContext('2d');let tint='0,0,0';if(daylight&&phase>.25&&phase<.72)tint='38,20,6';else if(daylight&&phase>=.72)tint='5,14,36';dc.fillStyle=`rgba(${tint},${clamp(darkness,0,1)})`;dc.fillRect(0,0,width,height);if(localLights){dc.globalCompositeOperation='destination-out';for(const source of sources)drawLightCutout(dc,source);for(const token of viewerTokens()){const range=feetToPixels(token.vision?.darkvision||0);if(range>0)drawLightCutout(dc,{id:`dark-${token.id}`,x:token.x,y:token.y,rotation:token.rotation,bright:token.vision.darkvision,dim:token.vision.darkvision,angle:token.vision.angle,color:'#c6d7ff',intensity:.75});}dc.globalCompositeOperation='source-over';}ctx.setTransform(dpr,0,0,dpr,0,0);ctx.drawImage(dark,0,0);}
    if(daylight){ctx.setTransform(dpr,0,0,dpr,0,0);const sunset=v070Smoothstep(.18,.46,phase)*(1-v070Smoothstep(.62,.8,phase)),night=v070Smoothstep(.66,1,phase);ctx.save();ctx.globalCompositeOperation='soft-light';if(sunset>.001){ctx.fillStyle=`rgba(255,132,48,${.19*sunset})`;ctx.fillRect(0,0,width,height);}if(night>.001){ctx.fillStyle=`rgba(42,74,145,${.22*night})`;ctx.fillRect(0,0,width,height);}ctx.restore();}
    if(localLights){ctx.setTransform(dpr,0,0,dpr,0,0);for(const source of sources)drawColoredLightGlow(ctx,source);}
    const fogMode=scene.settings.fogEnabled===false?'off':scene.settings.fogMode;if(fogMode!=='off'&&!masterFull){const fog=newOverlay(),fc=fog.getContext('2d'),startsHidden=scene.fog?.baseHidden!==false||fogMode==='vision'||fogMode==='hybrid';if(startsHidden){fc.fillStyle='rgba(0,0,0,.965)';fc.fillRect(0,0,width,height);}const current=currentVisionPolygons(),explored=new Set(scene.fog.explored?.[clientId]||[]);if(scene.settings.exploredMemory&&explored.size&&(fogMode==='vision'||fogMode==='hybrid')){fc.globalCompositeOperation='destination-out';fc.globalAlpha=.42;const cell=scene.fog.cellSize||scene.grid.size;for(const key of explored){const[gx,gy]=key.split(':').map(Number),a=worldToScreen({x:gx*cell,y:gy*cell});fc.fillRect(a.x,a.y,cell*app.view.scale+1,cell*app.view.scale+1);}fc.globalAlpha=1;}if(fogMode==='manual'||fogMode==='hybrid')applyManualFog(fc,scene.fog.ops||[],'reveal');if(fogMode==='vision'||fogMode==='hybrid'){fc.globalCompositeOperation='destination-out';for(const item of current){fc.beginPath();drawPolygonScreen(fc,item.polygon);fc.fillStyle='#000';fc.fill();}}if(fogMode==='manual'||fogMode==='hybrid')applyManualFog(fc,scene.fog.ops||[],'hide');fc.globalCompositeOperation='source-over';ctx.setTransform(dpr,0,0,dpr,0,0);ctx.drawImage(fog,0,0);scheduleExplored(current);}
  };

  const v070BaseVisualTokenState=visualTokenState;
  visualTokenState=function(token){const base=v070BaseVisualTokenState(token),hit=app.hitAnimations.get(token.id);if(!hit)return base;const elapsed=performance.now()-hit.startedAt,raw=elapsed/hit.duration;if(raw>=1){app.hitAnimations.delete(token.id);return base;}const strength=(1-raw)*Math.min(1.8,.75+Number(hit.damage||1)*.12),shake=Math.sin(elapsed*.095)*5*strength;requestRender();return{...base,x:base.x+shake,y:base.y+Math.cos(elapsed*.13)*2.2*strength};};
  const v070BaseDrawToken=drawToken;
  drawToken=function(target,token){v070BaseDrawToken(target,token);const hit=app.hitAnimations.get(token.id);if(!hit)return;const raw=(performance.now()-hit.startedAt)/hit.duration;if(raw>=1)return;const visual=visualTokenState(token),radius=tokenRadius(token),alpha=(1-raw)*.9;target.save();target.beginPath();target.arc(visual.x,visual.y,radius+12/app.view.scale,0,Math.PI*2);target.strokeStyle=`rgba(255,70,55,${alpha})`;target.lineWidth=(5+3*(1-raw))/app.view.scale;target.shadowColor='#ff3f32';target.shadowBlur=22/app.view.scale;target.stroke();target.restore();requestRender();};
  function v070DrawVehicleOccupants(target,vehicle){const ids=vehicle.vehicle?.occupants||[];if(!ids.length)return;const visual=visualTokenState(vehicle),radius=tokenRadius(vehicle),size=Math.max(14,22/app.view.scale),gap=size*.78,start=visual.x-(ids.length-1)*gap/2;ids.forEach((tokenId,index)=>{const rider=tokenById(tokenId);if(!rider)return;const x=start+index*gap,y=visual.y-radius-17/app.view.scale,url=tokenImageUrl(rider);target.save();target.beginPath();target.arc(x,y,size/2,0,Math.PI*2);target.clip();if(url){const image=resolvedImages.get(url);if(image)target.drawImage(image,x-size/2,y-size/2,size,size);else requestRenderWhenImageReady(url);}else{target.fillStyle=rider.kind==='npc'?'#713d3d':'#39556d';target.fillRect(x-size/2,y-size/2,size,size);target.fillStyle='#fff';target.font=`${8/app.view.scale}px Segoe UI`;target.textAlign='center';target.textBaseline='middle';target.fillText((rider.name||'?').slice(0,2).toUpperCase(),x,y);}target.restore();target.beginPath();target.arc(x,y,size/2,0,Math.PI*2);target.strokeStyle=vehicle.vehicle.driverTokenId===rider.id?'#ffd36a':'#d8e1e8';target.lineWidth=2/app.view.scale;target.stroke();});}
  drawTokens=function(target){const tokens=[...(app.scene?.tokens||[])].filter(Boolean).sort((a,b)=>(a.elevation||0)-(b.elevation||0));for(const token of tokens)if(!token.boardedVehicleId)drawToken(target,token);for(const token of tokens)if(token.kind==='vehicle')v070DrawVehicleOccupants(target,token);};
  const v070BaseHitTestToken=hitTestToken;
  hitTestToken=function(point){const tokens=[...(app.scene?.tokens||[])].filter(token=>!token.boardedVehicleId).reverse();return tokens.find(token=>{const p=visualTokenState(token);return visibleInPossession(p)&&Math.hypot(point.x-p.x,point.y-p.y)<=tokenRadius(token);})||null;};

  const v070BaseRender=render;
  render=function(){
    const{width,height,dpr}=app.dimensions;ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,width,height);ctx.fillStyle='#0b0e12';ctx.fillRect(0,0,width,height);if(!app.scene){refreshTokenActions();return;}
    const phase=clamp(Number(app.scene.settings?.dayPhase??1),0,1),daylight=app.scene.settings?.daylightEnabled!==false,grade=v071DayGrade(phase,daylight);
    ctx.save();ctx.filter=`brightness(${grade.exposure.toFixed(3)}) saturate(${grade.saturation.toFixed(3)}) contrast(${grade.contrast.toFixed(3)})`;ctx.translate(app.view.x,app.view.y);ctx.scale(app.view.scale,app.view.scale);drawMap(ctx);drawGrid(ctx);try{drawEffectZones(ctx);}catch(error){console.error('[FATUM Battlemap] effect layer',error);}drawWalls(ctx);drawSceneLightsMarkers(ctx);v070DrawAudioSources(ctx);drawThrowPreview(ctx);drawTokens(ctx);drawDraft(ctx);drawAttackLine(ctx);drawV061TargetPreview(ctx);ctx.restore();ctx.filter='none';drawLightingAndFog();ctx.setTransform(dpr,0,0,dpr,0,0);ctx.save();ctx.translate(app.view.x,app.view.y);ctx.scale(app.view.scale,app.view.scale);try{drawEffectZones(ctx,true);}catch(error){console.error(error);}ctx.restore();drawRollVisuals();refreshTokenActions();v070SyncAudioSources();
  };

  function v070AudioSourceById(sourceId){return(app.scene?.audioSources||[]).find(item=>item.id===sourceId)||null;}
  app.audioListenerTokenId=null;
  app.audioPreviewSourceId=null;
  app.audioPreviewUntil=0;

  function v074AudioListenerInfo(){
    if(app.possessedTokenId){const token=tokenById(app.possessedTokenId);if(token)return{point:token,label:`токен «${token.name}»`,token};}
    const selected=selectedToken();
    if(selected&&canControlToken(selected)){app.audioListenerTokenId=selected.id;return{point:selected,label:`токен «${selected.name}»`,token:selected};}
    if(app.audioListenerTokenId){const token=tokenById(app.audioListenerTokenId);if(token&&canControlToken(token))return{point:token,label:`токен «${token.name}»`,token};app.audioListenerTokenId=null;}
    if(!master){const owned=(app.scene?.tokens||[]).find(token=>canControlToken(token)&&['character','npc'].includes(token.kind));if(owned){app.audioListenerTokenId=owned.id;return{point:owned,label:`токен «${owned.name}»`,token:owned};}}
    const point=screenToWorld({x:app.dimensions.width/2,y:app.dimensions.height/2});
    return{point,label:master?'центр камеры мастера':'центр камеры',token:null};
  }
  function v070AudioListener(){return v074AudioListenerInfo().point;}

  function v074CreateAudioEntry(sourceId){
    const audio=new Audio();audio.preload='none';
    const entry={audio,trackId:null,loaded:false,finished:false,lastEnabled:false,outsideSince:0,mediaNode:null,gainNode:null,panNode:null,graphFailed:false};
    audio.addEventListener('ended',()=>{entry.finished=true;});
    audio.addEventListener('error',()=>{if(audio.error)console.warn('[FATUM audio object] media error',sourceId,audio.error);});
    app.audioSourcePlayers.set(sourceId,entry);return entry;
  }
  function v074ConnectAudioGraph(entry){
    const ac=app.audioEngine.context;if(!ac||entry.graphFailed||entry.mediaNode)return Boolean(entry.mediaNode);
    try{
      entry.mediaNode=ac.createMediaElementSource(entry.audio);entry.gainNode=ac.createGain();entry.gainNode.gain.value=0;
      entry.mediaNode.connect(entry.gainNode);
      if(typeof ac.createStereoPanner==='function'){entry.panNode=ac.createStereoPanner();entry.gainNode.connect(entry.panNode);entry.panNode.connect(ac.destination);}else entry.gainNode.connect(ac.destination);
      entry.audio.volume=1;return true;
    }catch(error){entry.graphFailed=true;console.warn('[FATUM audio object] Web Audio graph unavailable',error);return false;}
  }
  function v074SetEntryMix(entry,volume,pan){
    const safeVolume=clamp(Number(volume)||0,0,1),safePan=clamp(Number(pan)||0,-1,1),ac=app.audioEngine.context;
    if(v074ConnectAudioGraph(entry)&&entry.gainNode&&ac){
      const now=ac.currentTime;try{entry.gainNode.gain.cancelScheduledValues(now);entry.gainNode.gain.setValueAtTime(entry.gainNode.gain.value,now);entry.gainNode.gain.linearRampToValueAtTime(safeVolume,now+.08);}catch{entry.gainNode.gain.value=safeVolume;}
      if(entry.panNode)entry.panNode.pan.value=safePan;entry.audio.volume=1;
    }else entry.audio.volume=safeVolume;
  }
  function v074SpatialMix(source,listenerInfo){
    const helper=window.FatumAudioSpatial;
    if(helper?.computeMix)return helper.computeMix({source,listener:listenerInfo.point,grid:app.scene?.grid||{},localVolume:app.audioEngine.local.ambient??.7,spatialEnabled:app.audioEngine.local.spatial!==false});
    const distance=pixelsToFeet(Math.hypot(Number(source.x)-Number(listenerInfo.point.x),Number(source.y)-Number(listenerInfo.point.y))),radius=Math.max(1,Number(source.radius||60)),inside=source.enabled!==false&&app.audioEngine.local.spatial!==false&&distance<=radius,fade=inside?Math.sqrt(clamp(1-distance/radius,0,1)):0;
    return{distance,radius,inside,fade,volume:clamp(Number(source.volume??.8)*Number(app.audioEngine.local.ambient??.7)*fade,0,1),pan:0};
  }
  function v074UpdateAudioSourceStatus(source,mix,listenerInfo){
    if(app.selected?.type!=='audioSource'||app.selected.id!==source.id)return;
    const box=$('audio-source-status');if(!box)return;
    const spatialOff=app.audioEngine.local.spatial===false,disabled=source.enabled===false,noTrack=!source.trackId;
    let kind='ready',text=`Слушатель: ${listenerInfo.label}. Дистанция ${mix.distance.toFixed(1)} фт из ${mix.radius.toFixed(1)} фт · итоговая громкость ${Math.round(mix.volume*100)}%.`;
    if(noTrack){kind='blocked';text='Для аудио-объекта не выбран звуковой файл.';}
    else if(disabled){kind='idle';text='Аудио-объект выключен.';}
    else if(spatialOff){kind='blocked';text='Пространственные звуки карты отключены в локальных настройках аудио.';}
    else if(!mix.inside){kind='idle';text=`Слушатель: ${listenerInfo.label}. Источник вне радиуса: ${mix.distance.toFixed(1)} / ${mix.radius.toFixed(1)} фт.`;}
    else if(!app.audioEngine.unlocked){kind='blocked';text='Источник находится в радиусе, но звук вкладки ещё не включён. Нажмите «Звук» сверху.';}
    box.dataset.kind=kind;box.textContent=text;
  }
  function v070SyncAudioSources({forcePlay=false}={}){
    if(!app.scene){for(const entry of app.audioSourcePlayers.values()){v074SetEntryMix(entry,0,0);entry.audio.pause();}return;}
    const activeIds=new Set(),listenerInfo=v074AudioListenerInfo(),library=v061AudioState().library||[],now=performance.now();
    for(const source of app.scene.audioSources||[]){
      activeIds.add(source.id);let entry=app.audioSourcePlayers.get(source.id);if(!entry)entry=v074CreateAudioEntry(source.id);
      const track=library.find(item=>item.id===source.trackId),audio=entry.audio,enabled=source.enabled!==false,mix=v074SpatialMix(source,listenerInfo),preview=app.audioPreviewSourceId===source.id&&now<app.audioPreviewUntil;
      if(preview){mix.inside=true;mix.fade=1;mix.volume=clamp(Number(source.volume??.8)*Number(app.audioEngine.local.ambient??.7),0,1);mix.pan=0;}
      const spatialOff=app.audioEngine.local.spatial===false,preloadDistance=Math.max(1,Number(mix.radius||source.radius||60))*1.25,shouldPrepare=Boolean(preview||spatialOff||Number(mix.distance||0)<=preloadDistance);
      if(!enabled||!track){v074SetEntryMix(entry,0,0);audio.pause();entry.lastEnabled=enabled;entry.outsideSince=now;v074UpdateAudioSourceStatus(source,mix,listenerInfo);continue;}
      const trackChanged=entry.trackId!==track.id;if(trackChanged){audio.pause();audio.removeAttribute('src');audio.load();entry.trackId=track.id;entry.loaded=false;entry.finished=false;entry.outsideSince=0;}
      if(shouldPrepare&&!entry.loaded){audio.src=track.url;audio.preload='auto';audio.load();entry.loaded=true;entry.finished=false;}
      if(!shouldPrepare){if(!entry.outsideSince)entry.outsideSince=now;v074SetEntryMix(entry,0,0);audio.pause();if(entry.loaded&&now-entry.outsideSince>30000){audio.removeAttribute('src');audio.load();entry.loaded=false;entry.finished=false;}v074UpdateAudioSourceStatus(source,mix,listenerInfo);continue;}else entry.outsideSince=0;
      if(enabled&&!entry.lastEnabled){entry.finished=false;if(audio.ended)try{audio.currentTime=0;}catch{}}entry.lastEnabled=enabled;audio.loop=source.loop!==false;if(audio.loop)entry.finished=false;
      v074SetEntryMix(entry,mix.volume,mix.pan);v074UpdateAudioSourceStatus(source,mix,listenerInfo);
      const shouldPlay=entry.loaded&&(preview||mix.inside)&&mix.volume>.002&&app.audioEngine.unlocked&&(!entry.finished||audio.loop||preview);
      if(shouldPlay&&audio.paused){if(preview)try{audio.currentTime=0;}catch{}try{const promise=audio.play();if(promise?.catch)promise.catch(error=>reportV064AudioFailure(error,`аудио-объект «${source.name||'без названия'}»`));}catch(error){reportV064AudioFailure(error,`аудио-объект «${source.name||'без названия'}»`);}}else if(!shouldPlay&&!audio.paused)audio.pause();
    }
    for(const[sourceId,entry]of app.audioSourcePlayers){if(activeIds.has(sourceId))continue;v074SetEntryMix(entry,0,0);entry.audio.pause();entry.audio.removeAttribute('src');entry.audio.load();app.audioSourcePlayers.delete(sourceId);}
    if(app.audioPreviewSourceId&&now>=app.audioPreviewUntil){app.audioPreviewSourceId=null;app.audioPreviewUntil=0;}
  }
  async function v070SaveAudioSources(){const result=await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/audio-sources`,{method:'PUT',body:commonBody({audioSources:app.scene.audioSources||[]})});if(result.audioSources)app.scene.audioSources=result.audioSources;v070SyncAudioSources();requestRender();}
  async function v070AddAudioSource(point){const effects=(v061AudioState().library||[]).filter(item=>item.kind==='ambient'||item.kind==='effect');if(!effects.length){toast('Сначала загрузите эмбиент или звуковой эффект во вкладке «Аудио».','error');return;}const source={id:`audio_${id()}`,name:'Локальный звук',trackId:effects[0].id,x:point.x,y:point.y,radius:60,volume:.8,falloff:'soft',loop:true,enabled:true,hidden:true};app.scene.audioSources||=[];app.scene.audioSources.push(source);try{await v070SaveAudioSources();selectObject('audioSource',source.id);openPanel('object');toast('Аудио-объект добавлен.','success');}catch(error){app.scene.audioSources=app.scene.audioSources.filter(item=>item.id!==source.id);toast(error.message,'error');}}
  function v074AudioSourcePatchFromForm(){return{name:$('audio-source-name').value||'Локальный звук',trackId:$('audio-source-track').value||null,radius:clamp(Number($('audio-source-radius').value||60),1,5000),volume:clamp(Number($('audio-source-volume').value??.8),0,1),falloff:['soft','linear','sharp'].includes($('audio-source-falloff').value)?$('audio-source-falloff').value:'soft',enabled:$('audio-source-enabled').checked,loop:$('audio-source-loop').checked,hidden:$('audio-source-hidden').checked};}
  function v074UpdateAudioVolumeLabel(){const output=$('audio-source-volume-value');if(output)output.textContent=`${Math.round(clamp(Number($('audio-source-volume')?.value??.8),0,1)*100)}%`;}
  function v074LiveAudioSource(){const source=v070AudioSourceById(app.selected?.id);if(!source||!master)return;Object.assign(source,v074AudioSourcePatchFromForm());v074UpdateAudioVolumeLabel();v070SyncAudioSources();requestRender();scheduleLive(`audio-source-${source.id}`,v070SaveAudioSources,180);}
  async function v070SaveSelectedAudioSource(){const source=v070AudioSourceById(app.selected?.id);if(!source)return;Object.assign(source,v074AudioSourcePatchFromForm());try{await v070SaveAudioSources();toast('Аудио-объект сохранён.','success');}catch(error){toast(error.message,'error');}}
  function v074PreviewSelectedAudioSource(){const source=v070AudioSourceById(app.selected?.id);if(!source)return;if(!source.trackId){toast('Сначала выберите звуковой файл.','error');return;}if(!app.audioEngine.unlocked&&!unlockV061Audio({silent:true})){return;}app.audioPreviewSourceId=source.id;app.audioPreviewUntil=performance.now()+2600;const entry=app.audioSourcePlayers.get(source.id);if(entry){entry.finished=false;try{entry.audio.currentTime=0;}catch{}}v070SyncAudioSources({forcePlay:true});toast('Тестовое воспроизведение аудио-объекта.','success');}
  async function v070DeleteSelectedAudioSource(){const source=v070AudioSourceById(app.selected?.id);if(!source||!confirm(`Удалить аудио-объект «${source.name}»?`))return;app.scene.audioSources=app.scene.audioSources.filter(item=>item.id!==source.id);selectObject(null,null);try{await v070SaveAudioSources();toast('Аудио-объект удалён.','success');}catch(error){toast(error.message,'error');}}

  function v070RefreshEffectZones(){const box=$('effect-zone-list');if(!box)return;const list=app.scene?.effects||[],locked=combatActive();box.innerHTML=list.map(effect=>`<div class="bm-effect-zone-row"><span><strong>${esc(effect.name||'Область')}</strong><small>${esc(effect.type||'effect')} · ${Number(effect.radius||0)} фт · ${Number(effect.remainingRounds||0)} ход.</small></span><button class="bm-btn bm-danger" data-delete-effect="${esc(effect.id)}" ${locked?'disabled':''}>Удалить</button></div>`).join('')||'<p class="bm-muted">Постоянных областей на сцене нет.</p>';$('clear-effect-zones-btn').disabled=locked||!list.length;}
  async function v070DeleteEffect(effectId=null){if(combatActive()){toast('Области из этой панели удаляются только вне боя.','error');return;}const url=`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/effects${effectId?`/${encodeURIComponent(effectId)}`:''}`;try{await api(url,{method:'DELETE',body:commonBody()});await refreshBattlemap();toast(effectId?'Область удалена.':'Все области удалены.','success');}catch(error){toast(error.message,'error');}}

  async function v070LoadVehicleProfiles(){try{const result=await api('/api/battlemap/vehicle-profiles');app.vehicleProfiles=result.profiles||[];const select=$('vehicle-profile-select');if(select)select.innerHTML=app.vehicleProfiles.map(profile=>`<option value="${esc(profile.id)}">${esc(profile.name)}</option>`).join('');}catch(error){console.warn(error);}}
  function v070VehiclePatch(){return{environment:$('vehicle-environment').value,speed:Number($('vehicle-speed').value||0),zoneFeet:Number($('vehicle-zone-feet').value||60),maneuver:Number($('vehicle-maneuver').value||0),mz:Number($('vehicle-mz').value||0),hullCurrent:Number($('vehicle-hull-current').value||0),hullMax:Number($('vehicle-hull-max').value||1),armor:$('vehicle-armor').value,bzCurrent:Number($('vehicle-bz-current').value||0),bzMax:Number($('vehicle-bz-max').value||0),crew:Number($('vehicle-crew').value||0),passengerCapacity:Number($('vehicle-passengers').value||0),cargo:Number($('vehicle-cargo').value||0),slots:Number($('vehicle-slots').value||0)};}
  function v070VehicleStateLabel(vehicle){const v=vehicle?.vehicle||{},h=Number(v.hullCurrent||0),max=Math.max(1,Number(v.hullMax||1));return h<=0?'Выведен из строя':h===1?'Критическое состояние':h<=max/2?'Повреждён':'Целый';}
  function v070VehicleOccupantsHtml(vehicle){const v=vehicle.vehicle||{},ids=v.occupants||[];return`<h4>Внутри: ${ids.length}/${Number(v.crew||0)+Number(v.passengerCapacity||0)}</h4>`+(ids.map(tokenId=>{const token=tokenById(tokenId);return`<div class="bm-vehicle-person ${v.driverTokenId===tokenId?'driver':''}"><span>${esc(token?.name||'Неизвестный')}</span><small>${v.driverTokenId===tokenId?'водитель':'пассажир'}</small></div>`;}).join('')||'<p class="bm-muted">Транспорт пуст.</p>');}
  function v070ControlledRiders(){return(app.scene?.tokens||[]).filter(token=>['character','npc'].includes(token.kind)&&canControlToken(token));}
  function v070ChooseToken(tokens,title){if(!tokens.length)return null;if(tokens.length===1)return tokens[0];const text=tokens.map((token,index)=>`${index+1}. ${token.name}`).join('\n'),answer=Number(prompt(`${title}\n${text}`,'1'));return tokens[answer-1]||null;}
  async function v070VehicleBoard(){const vehicle=selectedToken();if(vehicle?.kind!=='vehicle')return;const candidates=v070ControlledRiders().filter(token=>!token.boardedVehicleId&&pixelsToFeet(Math.hypot(token.x-vehicle.x,token.y-vehicle.y))<=Math.max(5,Number(app.scene.grid?.feet||5)*1.6));const rider=v070ChooseToken(candidates,'Кто садится в транспорт?');if(!rider){toast('Рядом нет доступного персонажа.','error');return;}try{await api('/api/battlemap/vehicle/board',{method:'POST',body:commonBody({sceneId:app.scene.id,vehicleTokenId:vehicle.id,tokenId:rider.id})});await fetchAll(true);toast(`${rider.name} сел в транспорт.`,'success');}catch(error){toast(error.message,'error');}}
  async function v070VehicleExit(){const vehicle=selectedToken();if(vehicle?.kind!=='vehicle')return;const riders=(vehicle.vehicle?.occupants||[]).map(tokenById).filter(token=>token&&canControlToken(token)),rider=v070ChooseToken(riders,'Кто выходит из транспорта?');if(!rider){toast('У вас нет пассажира, который может выйти.','error');return;}try{await api('/api/battlemap/vehicle/exit',{method:'POST',body:commonBody({sceneId:app.scene.id,vehicleTokenId:vehicle.id,tokenId:rider.id})});await fetchAll(true);toast(`${rider.name} вышел из транспорта.`,'success');}catch(error){toast(error.message,'error');}}
  async function v070VehicleAction(action){const vehicle=selectedToken();if(vehicle?.kind!=='vehicle')return;let cost;if(action==='emergency'){const answer=prompt('Стоимость экстренной остановки / посадки: 1 или 2 ОД','1');if(answer===null)return;cost=clamp(Math.round(Number(answer)||1),1,2);}try{await api('/api/battlemap/vehicle/action',{method:'POST',body:commonBody({sceneId:app.scene.id,vehicleTokenId:vehicle.id,action,cost})});await fetchAll(true);const labels={drive:'Транспорт готов к движению.',sharp:'Выполнен резкий манёвр.',stabilize:'Ход стабилизирован.',gas:'Выполнено действие «Газ в пол». Изменение дистанции в погоне определяет проверка управления.',ram:'Заявлен таран. Итоговый урон по массе и скорости определяет мастер.',emergency:'Выполнена экстренная остановка / посадка.'};toast(labels[action]||'Действие транспорта выполнено.','success');}catch(error){toast(error.message,'error');}}
  async function v070VehicleDamage(){const vehicle=selectedToken();if(vehicle?.kind!=='vehicle')return;const damage=Number(prompt('Урон транспорту','1'));if(!Number.isFinite(damage)||damage<0)return;const damageTag=prompt('Тег урона: light, medium или heavy','medium')||'medium';try{const result=await api('/api/battlemap/vehicle/damage',{method:'POST',body:commonBody({sceneId:app.scene.id,vehicleTokenId:vehicle.id,damage,damageTag})});await fetchAll(true);toast(`Корпус: ${result.afterHull}/${vehicle.vehicle?.hullMax||'?'}. ${result.status}`,'success');}catch(error){toast(error.message,'error');}}

  const v070BaseSelectionExists=selectionExists;
  selectionExists=function(selection){if(selection?.type==='audioSource')return Boolean(v070AudioSourceById(selection.id));return v070BaseSelectionExists(selection);};
  const v074BaseSelectObject=selectObject;
  selectObject=function(type,objectId){if(type==='token'){const token=tokenById(objectId);if(token&&canControlToken(token))app.audioListenerTokenId=token.id;}return v074BaseSelectObject(type,objectId);};
  const v070BaseRefreshSceneForm=refreshSceneForm;
  refreshSceneForm=function(){v070BaseRefreshSceneForm();if(!app.scene)return;const settings=app.scene.settings||{};$('daylight-enabled').checked=settings.daylightEnabled!==false;$('day-phase').value=Number(settings.dayPhase??1);$('day-phase-label').textContent=v070DayLabel(settings.dayPhase??1);};
  const v070BaseRefreshTokenSource=refreshTokenSource;
  refreshTokenSource=function(){v070BaseRefreshTokenSource();const kind=$('token-source-kind').value;$('vehicle-create-wrap').hidden=kind!=='vehicle';if(kind==='vehicle'){$('token-ref-wrap').hidden=true;$('generic-name-wrap').hidden=true;}};
  const v070BaseRefreshTokenList=refreshTokenList;
  refreshTokenList=function(){const box=$('token-list');if(!app.scene){box.innerHTML='';return;}box.innerHTML=(app.scene.tokens||[]).filter(Boolean).map(token=>{const url=tokenImageUrl(token),type=token.kind==='character'?'Персонаж':token.kind==='npc'?'NPC':token.kind==='vehicle'?'Транспорт':'Объект';return`<div class="bm-token-row ${app.selected?.type==='token'&&app.selected.id===token.id?'active':''}" data-token-id="${esc(token.id)}"><div class="bm-token-thumb">${url?`<img src="${esc(url)}" class="bm-token-thumb">`:esc((token.name||'?').slice(0,2).toUpperCase())}</div><div>${esc(token.name)}<small>${type}${token.boardedVehicleId?' · в транспорте':''}${token.hidden?' · скрыт':''}</small></div><button class="bm-btn" data-focus-token="${esc(token.id)}">◎</button></div>`;}).join('')||'<p class="bm-muted">На сцене пока нет токенов.</p>';};
  const v070BaseRefreshInspector=refreshInspector;
  refreshInspector=function(){v070BaseRefreshInspector();$('audio-source-inspector').hidden=true;const token=selectedToken(),vehicleBox=$('vehicle-inspector');if(vehicleBox)vehicleBox.hidden=token?.kind!=='vehicle';if(token?.kind==='vehicle'){const v=token.vehicle||{};$('vehicle-environment').value=v.environment||'ground';$('vehicle-speed').value=v.speed??1;$('vehicle-zone-feet').value=v.zoneFeet??60;$('vehicle-maneuver').value=v.maneuver??0;$('vehicle-mz').value=v.mz??4;$('vehicle-hull-current').value=v.hullCurrent??0;$('vehicle-hull-max').value=v.hullMax??1;$('vehicle-armor').value=v.armor||'none';$('vehicle-bz-current').value=v.bzCurrent??0;$('vehicle-bz-max').value=v.bzMax??0;$('vehicle-crew').value=v.crew??1;$('vehicle-passengers').value=v.passengerCapacity??0;$('vehicle-cargo').value=v.cargo??0;$('vehicle-slots').value=v.slots??0;$('vehicle-occupants').innerHTML=v070VehicleOccupantsHtml(token);}
    if(app.selected?.type==='wall'){const wall=wallById(app.selected.id);$('wall-show-players').checked=Boolean(wall?.showGeometryToPlayers);}
    if(app.selected?.type==='cover'){const cover=coverById(app.selected.id);$('cover-thickness').value=cover?.thickness??18;$('cover-show-players').checked=Boolean(cover?.showGeometryToPlayers);}
    if(app.selected?.type==='audioSource'){const source=v070AudioSourceById(app.selected.id);if(source){$('no-selection-card').hidden=true;$('audio-source-inspector').hidden=false;$('audio-source-name').value=source.name||'Локальный звук';const library=(v061AudioState().library||[]).filter(item=>item.kind==='ambient'||item.kind==='effect');$('audio-source-track').innerHTML='<option value="">— нет звука —</option>'+library.map(item=>`<option value="${esc(item.id)}">${esc(item.name)}</option>`).join('');$('audio-source-track').value=source.trackId||'';$('audio-source-radius').value=source.radius||60;$('audio-source-volume').value=source.volume??.8;$('audio-source-falloff').value=source.falloff||'soft';$('audio-source-enabled').checked=source.enabled!==false;$('audio-source-loop').checked=source.loop!==false;$('audio-source-hidden').checked=Boolean(source.hidden);v074UpdateAudioVolumeLabel();const listenerInfo=v074AudioListenerInfo(),mix=v074SpatialMix(source,listenerInfo);v074UpdateAudioSourceStatus(source,mix,listenerInfo);}}
  };
  const v070BaseRefreshAllUi=refreshAllUi;
  refreshAllUi=function(){v070BaseRefreshAllUi();v070RefreshEffectZones();v070SyncAudioSources();};
  const v070BaseConnectEvents=connectEvents;
  connectEvents=function(){v070BaseConnectEvents();app.eventSource?.addEventListener('battlemap-hit',event=>{try{const payload=JSON.parse(event.data);if(payload.sceneId!==app.scene?.id)return;app.hitAnimations.set(payload.tokenId,{startedAt:performance.now(),duration:950,damage:payload.damage||1});requestRender();}catch(error){console.warn(error);}});};

  const v070BaseAddToken=addToken;
  addToken=async function(){if($('token-source-kind').value!=='vehicle')return v070BaseAddToken();if(!app.scene)return;const profile=app.vehicleProfiles.find(item=>item.id===$('vehicle-profile-select').value);if(!profile){toast('Выберите профиль транспорта.','error');return;}const center=screenToWorld({x:app.dimensions.width/2,y:app.dimensions.height/2}),name=$('vehicle-token-name').value||profile.name;try{const result=await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/tokens`,{method:'POST',body:commonBody({kind:'vehicle',name,imageUrl:app.uploadedTokenImage,x:center.x,y:center.y,size:Number($('new-token-size').value||2),vision:{enabled:false,range:0,angle:360},vehicle:{profileId:profile.id,profileName:profile.name,...profile,zoneFeet:60}})});if(result.token&&!app.scene.tokens.some(token=>token.id===result.token.id))app.scene.tokens.push(result.token);app.uploadedTokenImage=null;$('uploaded-token-image-label').textContent='';selectObject('token',result.token.id);refreshAllUi();toast(`Добавлен транспорт «${result.token.name}».`,'success');}catch(error){toast(error.message,'error');}};
  const v070BaseSaveSelectedToken=saveSelectedToken;
  saveSelectedToken=async function(){const token=selectedToken();if(token?.kind!=='vehicle')return v070BaseSaveSelectedToken();try{const patch=collectTokenPatch();patch.vehicle=v070VehiclePatch();const result=await updateToken(token,patch);if(result.token)Object.assign(token,result.token);toast('Транспорт сохранён.','success');refreshInspector();requestRender();}catch(error){toast(error.message,'error');}};
  const v070BaseSaveSelectedWall=saveSelectedWall;
  saveSelectedWall=async function(){const wall=wallById(app.selected?.id);if(!wall)return;wall.blocksVision=$('wall-blocks-vision').checked;wall.blocksMovement=$('wall-blocks-movement').checked;wall.showGeometryToPlayers=$('wall-show-players').checked;try{await saveWalls();toast('Стена сохранена.','success');requestRender();}catch(error){toast(error.message,'error');}};
  const v070BaseSaveSelectedCover=saveSelectedCover;
  saveSelectedCover=async function(){const cover=coverById(app.selected?.id);if(!cover)return;Object.assign(cover,{name:$('cover-name').value,shape:$('cover-shape').value,x:Number($('cover-x').value),y:Number($('cover-y').value),width:Number($('cover-width').value),height:Number($('cover-height').value),radius:Number($('cover-radius').value),mz:Number($('cover-mz').value),durability:Number($('cover-durability').value),damage:Number($('cover-damage').value),color:$('cover-color').value,elevation:Number($('cover-elevation')?.value||0),verticalHeight:Number($('cover-vertical-height')?.value||5),thickness:Number($('cover-thickness').value||18),blocksMovement:$('cover-blocks-movement').checked,hidden:$('cover-hidden').checked,showGeometryToPlayers:$('cover-show-players').checked});try{await saveCovers();toast('Укрытие сохранено.','success');requestRender();}catch(error){toast(error.message,'error');}};

  const v070BaseOnPointerDown=onPointerDown;
  onPointerDown=function(event){if(!app.scene||event.button!==0)return v070BaseOnPointerDown(event);const world=screenToWorld(eventPoint(event));if(master&&app.tool==='wall-curve'){app.draft={type:'wall-curve',points:[world],current:world};event.preventDefault();requestRender();return;}if(master&&app.tool==='cover-curve'){app.draft={type:'cover-curve',points:[world],current:world};event.preventDefault();requestRender();return;}if(master&&app.tool==='audio-source'){v070AddAudioSource(world);event.preventDefault();return;}if(master&&app.tool==='select'&&!hitTestToken(world)){const source=v070HitTestAudioSource(world);if(source){selectObject('audioSource',source.id);openPanel('object');app.drag={type:'audio-source',sourceId:source.id,offsetX:source.x-world.x,offsetY:source.y-world.y,moved:false};stage.classList.add('is-panning');event.preventDefault();return;}}return v070BaseOnPointerDown(event);};
  const v070BaseOnPointerMove=onPointerMove;
  onPointerMove=function(event){if(app.drag?.type==='audio-source'){const source=v070AudioSourceById(app.drag.sourceId);if(source){const world=screenToWorld(eventPoint(event)),x=world.x+app.drag.offsetX,y=world.y+app.drag.offsetY;if(Math.hypot(source.x-x,source.y-y)>.25)app.drag.moved=true;source.x=x;source.y=y;v070SyncAudioSources();requestRender();}return;}if(app.draft&&['wall-curve','cover-curve'].includes(app.draft.type)){const world=screenToWorld(eventPoint(event)),last=app.draft.points[app.draft.points.length-1];app.draft.current=world;if(Math.hypot(world.x-last.x,world.y-last.y)>Math.max(4,8/app.view.scale))app.draft.points.push(world);requestRender();return;}return v070BaseOnPointerMove(event);};
  const v070BaseOnPointerUp=onPointerUp;
  onPointerUp=async function(event){if(app.drag?.type==='audio-source'){const drag=app.drag;app.drag=null;stage.classList.remove('is-panning');if(drag.moved)try{await v070SaveAudioSources();}catch(error){toast(error.message,'error');await refreshBattlemap();}return;}if(app.draft&&['wall-curve','cover-curve'].includes(app.draft.type)){const draft=app.draft;app.draft=null;const points=[...(draft.points||[])];if(draft.current&&(!points.length||Math.hypot(draft.current.x-points[points.length-1].x,draft.current.y-points[points.length-1].y)>2))points.push(draft.current);if(points.length<2)return;if(draft.type==='wall-curve'){const wall={id:`wall_${id()}`,x1:points[0].x,y1:points[0].y,x2:points[points.length-1].x,y2:points[points.length-1].y,points,curved:true,blocksVision:$('new-wall-blocks-vision').checked,blocksMovement:$('new-wall-blocks-movement').checked,showGeometryToPlayers:Boolean($('new-wall-show-players')?.checked),coverMz:0,coverDurability:0,coverDamage:0,coverName:''};app.scene.walls.push(wall);try{await saveWalls();selectObject('wall',wall.id);toast('Кривая стена создана.','success');}catch(error){toast(error.message,'error');await refreshBattlemap();}}else{const settings=newCoverSettings(),cover={id:`cover_${id()}`,shape:'polyline',x:points[0].x,y:points[0].y,width:10,height:10,radius:5,points,thickness:Number($('new-cover-thickness').value||18),showGeometryToPlayers:$('new-cover-show-players').checked,...settings};app.scene.covers.push(cover);try{await saveCovers();selectObject('cover',cover.id);toast('Кривое укрытие создано.','success');}catch(error){toast(error.message,'error');await refreshBattlemap();}}requestRender();return;}return v070BaseOnPointerUp(event);};

  const v070BaseClientMovementBlocked=clientMovementBlocked;
  clientMovementBlocked=function(token,from,to){if(master&&!app.possessedTokenId)return false;return v070BaseClientMovementBlocked(token,from,to);};
  const v070BaseUpdateToken=updateToken;
  updateToken=async function(token,patch){if(master&&!app.possessedTokenId)patch={...patch,ignoreWalls:true,forceMove:true};return v070BaseUpdateToken(token,patch);};

  const v070BaseRefreshActionDock=refreshActionDock;
  refreshActionDock=function(){v070BaseRefreshActionDock();const token=selectedToken();if(token?.kind!=='vehicle')return;const dock=$('action-dock');if(!canControlToken(token)&&!master){dock.hidden=true;return;}dock.hidden=false;$('action-token-name').textContent=token.name;const url=tokenImageUrl(token),portrait=$('action-portrait');portrait.style.backgroundImage=url?`url("${url.replace(/"/g,'%22')}")`:'';portrait.textContent=url?'':'🚙';const v=token.vehicle||{},movement=movementForToken(token);$('action-resource-line').textContent=`Корпус ${v.hullCurrent||0}/${v.hullMax||0} · БЗ ${v.bzCurrent||0}/${v.bzMax||0} · МЗ ${v.mz||0}${movement?` · Движение ${movement.remaining.toFixed(1)}/${movement.limit.toFixed(1)} фт`:''}`;$('action-wounds').innerHTML=`<span class="bm-wound-pill ${Number(v.hullCurrent||0)<=1?'critical':'light'}">${esc(v070VehicleStateLabel(token))}</span>`;let html=actionButtonHtml('vehicle-drive','➜','Вести',1,'Потратить 1 ОД водителя и получить движение Скорость × размер зоны.');html+=actionButtonHtml('vehicle-sharp','↯','Резкий манёвр',1,'+1 МЗ до следующего хода водителя; стрельба пассажиров получает помеху.');html+=actionButtonHtml('vehicle-stabilize','⌁','Стабилизировать',1,'Убрать штраф −1 к стрельбе пассажиров после движения.');html+=actionButtonHtml('vehicle-gas','»','Газ в пол',2,'В погоне попытаться увеличить или сократить дистанцию.');html+=actionButtonHtml('vehicle-ram','✦','Таран',2,'Столкновение; урон по массе и скорости определяет мастер.');html+=actionButtonHtml('vehicle-emergency','⏹','Экстренно',null,'Экстренная остановка или посадка за 1–2 ОД.');html+=actionButtonHtml('vehicle-board','⇥','Сесть',null,'Посадить соседний управляемый токен.');html+=actionButtonHtml('vehicle-exit','⇤','Выйти',null,'Высадить управляемого пассажира.');if(master)html+=actionButtonHtml('vehicle-damage','✹','Урон',null,'Применить урон корпусу транспорта.');$('action-slots').innerHTML=html;const hullNow=Number(v.hullCurrent||0),hullMax=Math.max(1,Number(v.hullMax||1)),baseManeuver=Number(v.maneuver||0),effectiveManeuver=baseManeuver-(hullNow>0&&hullNow<=hullMax/2?1:0);setActionDescription(`${v.profileName||'Транспорт'} · Скорость ${v.speed||0} зон · Манёвр ${effectiveManeuver>=0?'+':''}${effectiveManeuver}${effectiveManeuver!==baseManeuver?` (база ${baseManeuver>=0?'+':''}${baseManeuver})`:''}`);};

  function v070SaveDaylight({toastOnSave=false}={}){if(!app.scene||!master)return Promise.resolve();const settings={fogMode:$('fog-mode').value,fogEnabled:$('fog-mode').value!=='off',visionEnabled:$('vision-enabled').checked,dynamicLightEnabled:$('dynamic-light-enabled').checked,globalIllumination:$('global-illumination').checked,masterSeesLighting:$('master-sees-lighting').checked,ambientDarkness:Number($('ambient-darkness').value),daylightEnabled:$('daylight-enabled').checked,dayPhase:Number($('day-phase').value),playerCanPing:$('player-can-ping')?.checked!==false,playerCanDraw:$('player-can-draw')?.checked!==false,elevationRulesEnabled:$('elevation-rules-enabled')?.checked!==false,showZoneFireLinesMaster:$('zone-fire-lines-master')?.checked===true,showZoneFireLinesPlayers:$('zone-fire-lines-players')?.checked===true};return api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}`,{method:'PUT',body:commonBody({settings})}).then(()=>{if(toastOnSave)toast('Настройки освещения сохранены.','success');});}

  // v0.7.0: live editing and collision for curved cover/wall geometry.
  hitPointInCover=function(point,c){
    if(c.shape==='circle')return Math.hypot(point.x-c.x,point.y-c.y)<=c.radius;
    if(c.shape==='polygon')return c.points?.length>=3&&bmPointInPolygon(point,c.points);
    if(c.shape==='polyline'){const points=c.points||[],radius=Math.max(1,Number(c.thickness||18))/2;for(let i=1;i<points.length;i++)if(pointSegmentDistance(point,points[i-1],points[i])<=radius)return true;return false;}
    return point.x>=c.x&&point.x<=c.x+c.width&&point.y>=c.y&&point.y<=c.y+c.height;
  };
  hitTestCover=function(point){if(!master)return null;const extra=10/app.view.scale;return[...(app.scene?.covers||[])].reverse().find(c=>{if(c.hidden&&!master)return false;if(c.shape==='polyline'){const points=c.points||[],radius=Math.max(1,Number(c.thickness||18))/2+extra;for(let i=1;i<points.length;i++)if(pointSegmentDistance(point,points[i-1],points[i])<=radius)return true;return false;}return hitPointInCover(point,c);})||null;};
  liveWall=function(){const w=wallById(app.selected?.id);if(!w||!master)return;Object.assign(w,{blocksVision:$('wall-blocks-vision').checked,blocksMovement:$('wall-blocks-movement').checked,showGeometryToPlayers:$('wall-show-players').checked});requestRender();scheduleLive('wall',saveWalls);};
  liveCover=function(){const c=coverById(app.selected?.id);if(!c||!master)return;Object.assign(c,{name:$('cover-name').value,shape:$('cover-shape').value,x:Number($('cover-x').value),y:Number($('cover-y').value),width:Number($('cover-width').value),height:Number($('cover-height').value),radius:Number($('cover-radius').value),mz:Number($('cover-mz').value),durability:Number($('cover-durability').value),damage:Number($('cover-damage').value),color:$('cover-color').value,elevation:Number($('cover-elevation')?.value||0),verticalHeight:Number($('cover-vertical-height')?.value||5),thickness:Number($('cover-thickness').value||18),blocksMovement:$('cover-blocks-movement').checked,hidden:$('cover-hidden').checked,showGeometryToPlayers:$('cover-show-players').checked});requestRender();scheduleLive('cover',saveCovers);};

  function bindV070Ui(){
    $('save-wall-btn').onclick=saveSelectedWall;$('save-cover-btn').onclick=saveSelectedCover;$('save-token-btn').onclick=saveSelectedToken;$('save-audio-source-btn').onclick=v070SaveSelectedAudioSource;$('audio-source-preview-btn').onclick=v074PreviewSelectedAudioSource;$('delete-audio-source-btn').onclick=v070DeleteSelectedAudioSource;
    for(const el of [$('wall-show-players')]){el?.addEventListener('input',liveWall);el?.addEventListener('change',liveWall);}for(const el of [$('cover-thickness'),$('cover-show-players')]){el?.addEventListener('input',liveCover);el?.addEventListener('change',liveCover);}
    for(const el of [$('audio-source-name'),$('audio-source-track'),$('audio-source-radius'),$('audio-source-volume'),$('audio-source-falloff'),$('audio-source-enabled'),$('audio-source-loop'),$('audio-source-hidden')]){el?.addEventListener('input',v074LiveAudioSource);el?.addEventListener('change',v074LiveAudioSource);}
    $('effect-zone-list').addEventListener('click',event=>{const button=event.target.closest('[data-delete-effect]');if(button)v070DeleteEffect(button.dataset.deleteEffect);});$('clear-effect-zones-btn').onclick=()=>{if(confirm('Удалить все постоянные области этой сцены?'))v070DeleteEffect();};
    $('day-phase').addEventListener('input',event=>{if(!app.scene)return;app.scene.settings.dayPhase=Number(event.target.value);$('day-phase-label').textContent=v070DayLabel(event.target.value);requestRender();scheduleLive('daylight',()=>v070SaveDaylight(),130);});$('daylight-enabled').addEventListener('change',()=>{if(app.scene)app.scene.settings.daylightEnabled=$('daylight-enabled').checked;requestRender();v070SaveDaylight();});$('save-vision-btn').onclick=()=>v070SaveDaylight({toastOnSave:true}).catch(error=>toast(error.message,'error'));
    $('vehicle-board-btn').onclick=v070VehicleBoard;$('vehicle-exit-btn').onclick=v070VehicleExit;$('vehicle-drive-btn').onclick=()=>v070VehicleAction('drive');$('vehicle-sharp-btn').onclick=()=>v070VehicleAction('sharp');$('vehicle-stabilize-btn').onclick=()=>v070VehicleAction('stabilize');$('vehicle-gas-btn').onclick=()=>v070VehicleAction('gas');$('vehicle-ram-btn').onclick=()=>v070VehicleAction('ram');$('vehicle-emergency-btn').onclick=()=>v070VehicleAction('emergency');$('vehicle-damage-btn').onclick=v070VehicleDamage;
    $('action-slots').addEventListener('click',event=>{const button=event.target.closest('[data-dock-action]');if(!button)return;const key=button.dataset.dockAction;if(key==='vehicle-drive')v070VehicleAction('drive');else if(key==='vehicle-sharp')v070VehicleAction('sharp');else if(key==='vehicle-stabilize')v070VehicleAction('stabilize');else if(key==='vehicle-gas')v070VehicleAction('gas');else if(key==='vehicle-ram')v070VehicleAction('ram');else if(key==='vehicle-emergency')v070VehicleAction('emergency');else if(key==='vehicle-board')v070VehicleBoard();else if(key==='vehicle-exit')v070VehicleExit();else if(key==='vehicle-damage')v070VehicleDamage();});
    $('local-ambient-volume').addEventListener('input',()=>v070SyncAudioSources());$('audio-unlock-btn').addEventListener('click',()=>v070SyncAudioSources({forcePlay:true}));
    v070LoadVehicleProfiles();clearInterval(app.v070AudioSyncTimer);app.v070AudioSyncTimer=setInterval(v070SyncAudioSources,650);
  }



  /* ===== FATUM Battlemap v0.7.3: species runtime ===== */
  function speciesStateClient(token){
    if(!token||token.kind!=='character')return null;
    const st=characterById(token.refId)?.state||{},rt=token.speciesRuntime||{};
    return {raw:st,species:rt.species||st.species||'human',pallid:{...(st.pallid||{}),...(rt.pallid||{})},werewolf:{...(st.werewolf||{}),...(rt.werewolf||{})},rokurokubi:{...(st.rokurokubi||{}),...(rt.rokurokubi||{})},conditions:{...(st._speciesConditions||{}),...(rt.conditions||{})},naturalWeapons:Array.isArray(rt.naturalWeapons)?rt.naturalWeapons.map(weapon=>({...weapon})):[]};
  }
  function speciesFormActiveClient(st){return Boolean(st&&((st.species==='pallid'&&st.pallid?.transformed)||(st.species==='werewolf'&&st.werewolf?.transformed)||(st.species==='rokurokubi'&&st.rokurokubi?.neckExtended)));}
  function speciesNameClient(species){return species==='pallid'?'Паллид':species==='werewolf'?'Волколак':species==='rokurokubi'?'Рокурокуби':'Человек';}
  function speciesFormLabel(st){if(st?.species==='pallid'&&st.pallid?.transformed)return'Форма Вечного';if(st?.species==='werewolf'&&st.werewolf?.transformed)return'Звериная форма';if(st?.species==='rokurokubi'&&st.rokurokubi?.neckExtended)return'Расправленная шея';return'Обычное состояние';}
  function speciesButton(action,label,{primary=false,danger=false,disabled=false,active=false}={}){return`<button class="bm-btn ${primary?'bm-primary':''} ${danger?'bm-danger':''} ${active?'active':''}" data-species-action="${esc(action)}" ${disabled?'disabled':''}>${esc(label)}</button>`;}
  function renderSpeciesNaturalAttacks(token){
    const weapons=speciesNaturalWeaponsClient(token);if(!weapons.length)return'';
    const cards=weapons.map(weapon=>{const bonus=Number(weapon.hitBonus||0),special=weapon.id==='werewolf-takedown'?`<button class="bm-btn" data-species-melee="${esc(weapon.id)}" data-species-special="takedown">Атаковать и сбить · до ${Number(weapon.odCost||2)+1} ОД</button>`:'';return`<article class="bm-species-weapon-card"><div><strong>${esc(weapon.name)}</strong><small>${esc(weapon.hitDieNormal)} ${bonus>=0?'+':''}${bonus} · урон ${Number(weapon.damage||0)} · ${Number(weapon.odCost||2)} ОД${Number(weapon.range||5)>5?` · ${Number(weapon.range)} фт`:''}</small></div><p>${esc(weapon.description||'Естественное оружие.')}</p><div class="bm-species-actions"><button class="bm-btn bm-primary" data-species-melee="${esc(weapon.id)}">Атаковать</button>${special}</div></article>`;}).join('');
    return`<div class="bm-species-natural-attacks"><h4>Естественные атаки</h4><div class="bm-species-weapon-grid">${cards}</div></div>`;
  }
  function renderSpeciesPopover(token){
    const st=speciesStateClient(token),body=$('species-popover-body');if(!st||!body)return;
    $('species-popover-title').textContent=speciesNameClient(st.species);$('species-popover-subtitle').textContent=`${token.name} · ${speciesFormLabel(st)}`;
    let html='';
    if(st.species==='pallid'){
      const active=Boolean(st.pallid.transformed);html+=`<section class="bm-species-section ${active?'active':''}"><h3>${active?'Форма Вечного активна':'Паллидская природа'}</h3><div class="bm-species-stats"><span class="bm-species-stat">Кровь: <strong>${Number(st.pallid.bloodDoses||0)}</strong></span><span class="bm-species-stat">Память: <strong>${st.pallid.memoryUsed?'использована':'доступна'}</strong></span><span class="bm-species-stat">Скорость: <strong>${active?'+30 фт':'обычная'}</strong></span></div><p>${active?'+1 ОД в начале хода, вертикальное движение, Прыжок Вечного, Когти, Разрывающий удар и Плоть Вечного. Обычная броня действует только при адаптации.':'+1 слот Лёгкого ранения, преимущество Иммунитета против естественных болезней, ядов и токсинов, дополнительная Специализация и язык.'}</p><div class="bm-species-actions">${active?speciesButton('pallid-end','Прекратить форму',{danger:true}):speciesButton('pallid-transform','Форма Вечного · 2 ОД',{primary:true,disabled:Number(st.pallid.bloodDoses||0)<1})}${speciesButton('pallid-blood-plus','+ Доза крови')}${speciesButton('pallid-blood-minus','− Доза крови',{disabled:Number(st.pallid.bloodDoses||0)<1})}${speciesButton('pallid-memory','Память прошлого',{disabled:Boolean(st.pallid.memoryUsed)})}${active?speciesButton('pallid-jump','Прыжок Вечного · 1 ОД'):''}</div>${active?renderSpeciesNaturalAttacks(token):''}</section>`;
    }else if(st.species==='werewolf'){
      const active=Boolean(st.werewolf.transformed),beast=st.werewolf.beastState==='full'?'Полный срыв':st.werewolf.beastState==='breakdown'?'Звериный срыв':'Контроль';html+=`<section class="bm-species-section ${active?'active':''}"><h3>${active?'Звериная форма активна':'Волколачья природа'}</h3><div class="bm-species-stats"><span class="bm-species-stat">Зверь: <strong>${beast}</strong></span><span class="bm-species-stat">Провалы: <strong>${Number(st.werewolf.beastFailures||0)}/3</strong></span><span class="bm-species-stat">Шкура: <strong>${active&&!st.werewolf.hideUsed?'готова':'использована'}</strong></span><span class="bm-species-stat">Скорость: <strong>${active?'+40 фт':'обычная'}</strong></span></div><p>${active?'Рывок стоит 1 ОД, Натиск доступен до 30 футов, природный МЗ равен 4 + Акробатика + 2. Доступны Когти, Укус, Сбивающий бросок и Охота на раненого.':'В человеческой форме действуют Звериные чувства, сумеречное зрение, Запах крови и защита от естественных инфекций.'}</p>${st.werewolf.aftereffects?'<div class="bm-species-warning">Последствия трансформации: −1 к Физической силе, Акробатике и Выдержке до короткого привала.</div>':''}${st.werewolf.odDebt?`<div class="bm-species-warning">Долг непроизвольной трансформации: ${Number(st.werewolf.odDebt)} ОД в следующий ход.</div>`:''}<div class="bm-species-actions">${active?speciesButton('werewolf-end','Прекратить · 1 ОД',{danger:true,disabled:st.werewolf.beastState!=='calm'}):speciesButton('werewolf-transform','Звериная форма · 2 ОД',{primary:true,disabled:Boolean(st.werewolf.uncontrolled)})}${!active?speciesButton('werewolf-involuntary','Непроизвольная форма'):''}${!active?speciesButton('werewolf-lunar-check','Полнолуние: Воля 1к8'):''}${!active?speciesButton('werewolf-emotion-check','Сильная эмоция: Воля 1к6'):''}${active?speciesButton('werewolf-check','Проверка Зверя'):''}${active?speciesButton('werewolf-hunt','Охота на раненого'):''}${speciesButton('werewolf-rest','Короткий привал',{disabled:!st.werewolf.aftereffects})}</div>${active?renderSpeciesNaturalAttacks(token):''}</section>`;
    }else if(st.species==='rokurokubi'){
      const active=Boolean(st.rokurokubi.neckExtended),wrapped=st.rokurokubi.wrappedTarget||'',neckCost=1+(st.raw?.equipment?.armor&&!st.rokurokubi.neckGearReady?1:0);html+=`<section class="bm-species-section ${active?'active':''}"><h3>${active?'Шея расправлена':'Расслабленное состояние'}</h3><div class="bm-species-stats"><span class="bm-species-stat">Засада: <strong>${st.rokurokubi.ambushUsed?'использована':'доступна'}</strong></span><span class="bm-species-stat">Обвита цель: <strong>${wrapped||'нет'}</strong></span><span class="bm-species-stat">Скорость: <strong>${active?'+10 фт':'обычная'}</strong></span></div><p>${active?'Голова может находиться в пределах 10 футов от тела. Линия обзора и естественные атаки исходят от неё; руки заняты. Доступны Молниеносный выпад и Обвивающий захват.':'Доступны обычное оружие, инструменты и попытка маскировки. Молниеносная засада применяется из втянутого состояния.'}</p>${wrapped?`<div class="bm-species-warning">${esc(wrapped)}: Скорость 0, Рывок и Натиск недоступны, −1 к встречным броскам ближнего боя. Скорость рокурокуби снижена вдвое.</div>`:''}${neckCost>1?'<div class="bm-species-warning">Надетая броня ещё не подготовлена для шеи: расправление дополнительно тратит 1 ОД и автоматически помечает экипировку подготовленной.</div>':''}<div class="bm-species-actions">${active?speciesButton('roko-retract','Втянуть шею · 1 ОД',{danger:true,disabled:Boolean(wrapped)}):speciesButton('roko-extend',`Расправить шею · ${neckCost} ОД`,{primary:true})}${active?speciesButton('roko-head','Положение головы'):''}${active?speciesButton('roko-perception','Дистанционное восприятие'):''}${!active&&!st.rokurokubi.ambushUsed?speciesButton('roko-ambush-lunge','Засада: выпад · 2 ОД',{primary:true}):''}${!active&&!st.rokurokubi.ambushUsed?speciesButton('roko-ambush-wrap','Засада: захват · 2 ОД',{primary:true}):''}${wrapped?speciesButton('roko-pull','Подтянуть · 1 ОД'):''}${wrapped?speciesButton('roko-release','Отпустить'):''}</div>${active?renderSpeciesNaturalAttacks(token):''}</section>`;
    }else html='<section class="bm-species-section"><h3>Человек</h3><p>У персонажа нет активного функционала Иных.</p></section>';
    if(st.conditions?.prone)html+=`<section class="bm-species-section"><h3>Сбит с ног</h3><p>Скорость равна 0, Рывок и Натиск недоступны, защита в ближнем бою снижена.</p><div class="bm-species-actions">${speciesButton('stand','Подняться · 1 ОД',{primary:true})}</div></section>`;
    if(st.conditions?.wrappedByTokenId)html+=`<section class="bm-species-section"><h3>Обвит рокурокуби</h3><p>Можно потратить 1 ОД и совершить встречную проверку Физической силы или Акробатики.</p><div class="bm-species-actions">${speciesButton('escape-wrap','Попытаться освободиться · 1 ОД',{primary:true})}</div></section>`;
    if(st.conditions?.lycanthropyExposure)html+=`<section class="bm-species-section"><h3>Риск заражения ликантропией</h3><p>Укус нанёс не менее Среднего ранения. После окончания сцены требуется проверка Иммунитета против сложности 1к8.</p><div class="bm-species-actions">${speciesButton('resolve-lycanthropy','Проверка Иммунитета 1к8',{primary:true})}</div></section>`;
    if(st.conditions?.lycanthropyInfected)html+=`<section class="bm-species-section"><h3>Заражение ликантропией</h3><div class="bm-species-warning">Проверка Иммунитета провалена. Развитие болезни и получение вида волколака разрешаются Мастером по правилам кампании.</div></section>`;
    html+=`<div class="bm-species-note">Контекстные преимущества вида теперь доступны среди источников проверки навыка. Выбирайте их только тогда, когда описанное условие действительно выполняется.</div><div class="bm-species-actions">${speciesButton('species-scene-reset','Завершить сцену / восстановить способности')}</div>`;body.innerHTML=html;
  }
  function openSpeciesPopover(token=selectedToken()){if(!token||token.kind!=='character')return;renderSpeciesPopover(token);$('species-popover').hidden=false;$('skill-popover').hidden=true;$('item-popover').hidden=true;}
  async function speciesAction(action,extra={}){const token=selectedToken();if(!token)return;try{const result=await api('/api/battlemap/species-action',{method:'POST',body:commonBody({sceneId:app.scene.id,tokenId:token.id,action,...extra})});for(const roll of result.rolls||[])startRollVisual(roll);if(result.infectionCheck)toast(`Иммунитет: ${result.infectionCheck.success?'заражения нет':'заражение'} · ${result.infectionCheck.successTotal} против ${result.infectionCheck.difficultyRoll}`,result.infectionCheck.success?'success':'error');else if(result.beastCheck)toast(`Проверка Зверя: ${result.beastCheck.success?'успех':'провал'} · ${result.beastCheck.successTotal} против ${result.beastCheck.difficultyRoll}`,result.beastCheck.success?'success':'error');else if(result.preCheck)toast(`${result.preCheck.skillName}: ${result.preCheck.success?'успех':'провал'} · ${result.preCheck.successTotal} против ${result.preCheck.difficultyRoll}`,result.preCheck.success?'success':'error');else toast(result.entry?.text||'Действие вида применено.','success');await fetchAll(true);const fresh=selectedToken();if(fresh&&!$('species-popover').hidden)renderSpeciesPopover(fresh);}catch(error){toast(error.message,'error');}}
  function beginSpeciesPoint(action,label){const token=selectedToken();if(!token)return;app.speciesTarget={action,tokenId:token.id,type:'point'};$('species-popover').hidden=true;document.body.classList.add('bm-targeting');setTool('select');toast(label);setActionDescription(label);}
  function beginSpeciesToken(action,label){const token=selectedToken();if(!token)return;app.speciesTarget={action,tokenId:token.id,type:'token'};$('species-popover').hidden=true;document.body.classList.add('bm-targeting');setTool('select');toast(label);setActionDescription(label);}
  function cancelSpeciesTarget(){app.speciesTarget=null;document.body.classList.remove('bm-targeting');setActionDescription('Выберите действие.');}
  async function uploadSpeciesFormImage(kind,file){const token=selectedToken();if(!token||!file)return;try{const uploaded=await uploadImage(file,'token'),formImages={...(token.formImages||{}),[kind]:uploaded.url};const result=await updateToken(token,{formImages});token.formImages=result.token?.formImages||formImages;refreshSpeciesImageInspector(token);requestRender();toast('Изображение формы сохранено.','success');}catch(error){toast(error.message,'error');}}
  async function clearSpeciesFormImage(kind){const token=selectedToken();if(!token)return;try{const formImages={...(token.formImages||{}),[kind]:null};const result=await updateToken(token,{formImages});token.formImages=result.token?.formImages||formImages;refreshSpeciesImageInspector(token);requestRender();}catch(error){toast(error.message,'error');}}
  function refreshSpeciesImageInspector(token){const st=speciesStateClient(token),box=$('species-token-images');if(!box)return;const relevant=Boolean(st&&['pallid','werewolf'].includes(st.species));box.hidden=!relevant;$('pallid-form-image-row').hidden=st?.species!=='pallid';$('werewolf-form-image-row').hidden=st?.species!=='werewolf';$('pallid-form-image-status').textContent=token?.formImages?.pallid?'загружено':'не задано';$('werewolf-form-image-status').textContent=token?.formImages?.werewolf?'загружено':'не задано';}

  const v073BaseRefreshInspector=refreshInspector;
  refreshInspector=function(){v073BaseRefreshInspector();const token=selectedToken();refreshSpeciesImageInspector(token);};
  const v073BaseRefreshActionDock=refreshActionDock;
  refreshActionDock=function(){v073BaseRefreshActionDock();const token=selectedToken(),slots=$('action-slots');if(!token||!slots||$('action-dock').hidden||token.kind==='vehicle')return;const st=speciesStateClient(token),condition=st?.conditions||{},canAct=combatCanAct(token),hasSpeciesCondition=Boolean(condition.prone||condition.wrappedByTokenId||condition.lycanthropyExposure||condition.lycanthropyInfected);if(st&&(st.species!=='human'||hasSpeciesCondition))slots.insertAdjacentHTML('beforeend',actionButtonHtml('species','✦',st.species!=='human'?speciesNameClient(st.species):'Состояния',null,speciesFormLabel(st),'species'));if(condition.prone)slots.insertAdjacentHTML('beforeend',actionButtonHtml('species-stand','↥','Подняться',1,'Встать после сбивания.','condition'));if(condition.wrappedByTokenId)slots.insertAdjacentHTML('beforeend',actionButtonHtml('species-escape','⟲','Освободиться',1,'Встречная проверка против рокурокуби.','condition'));const ww=allClientWeapons(token).find(w=>w.id==='werewolf-takedown');if(ww)slots.insertAdjacentHTML('beforeend',actionButtonHtml('melee-takedown:werewolf-takedown','↧','Сбить с ног',Number(ww.odCost||2)+1,'Сбивающий бросок с дополнительным 1 ОД: при ранении цель падает.','weapon'));slots.querySelectorAll('[data-dock-action="species"],[data-dock-action^="species-"],[data-dock-action^="melee-takedown:"]').forEach(btn=>{const key=btn.dataset.dockAction;if((key==='species-stand'||key==='species-escape'||key.startsWith('melee-takedown:'))&&!canAct)btn.disabled=true;btn.onmouseenter=()=>setActionDescription(btn.title);btn.onmouseleave=()=>setActionDescription('Выберите действие.');});};

  const v073BaseDrawTokens=drawTokens;
  drawTokens=function(target){v073BaseDrawTokens(target);for(const token of app.scene?.tokens||[]){const st=speciesStateClient(token);if(st?.species!=='rokurokubi'||!st.rokurokubi?.neckExtended||!st.rokurokubi?.headPoint||token.boardedVehicleId)continue;const body=visualTokenState(token),head=st.rokurokubi.headPoint,r=Math.max(8,tokenRadius(token)*.32);target.save();target.setLineDash([8/app.view.scale,5/app.view.scale]);target.lineWidth=3/app.view.scale;target.strokeStyle='rgba(116,190,220,.82)';target.beginPath();target.moveTo(body.x,body.y);target.lineTo(head.x,head.y);target.stroke();target.setLineDash([]);target.beginPath();target.arc(head.x,head.y,r,0,Math.PI*2);target.fillStyle='rgba(31,72,91,.9)';target.fill();target.strokeStyle='#b9e4f3';target.lineWidth=2/app.view.scale;target.stroke();target.fillStyle='#e8f7ff';target.font=`${10/app.view.scale}px Segoe UI`;target.textAlign='center';target.textBaseline='middle';target.fillText('Г',head.x,head.y);target.restore();}}
  const v073BaseDrawToken=drawToken;
  drawToken=function(target,token){v073BaseDrawToken(target,token);const st=speciesStateClient(token),cond=st?.conditions||{};if(!st)return;const p=visualTokenState(token),r=tokenRadius(token),badges=[];if(st.species==='pallid'&&st.pallid?.transformed)badges.push(['ВЕЧНЫЙ','#d1b05d']);if(st.species==='werewolf'&&st.werewolf?.transformed)badges.push([st.werewolf.beastState==='calm'?'ЗВЕРЬ':'СРЫВ',st.werewolf.beastState==='calm'?'#b86d5c':'#e54f49']);if(st.species==='rokurokubi'&&st.rokurokubi?.neckExtended)badges.push(['ШЕЯ','#62a8c5']);if(cond.prone)badges.push(['ЛЕЖИТ','#d57261']);if(cond.wrappedByTokenId)badges.push(['ОБВИТ','#b45888']);if(cond.lycanthropyExposure)badges.push(['УКУС','#d19b55']);if(cond.lycanthropyInfected)badges.push(['ЗАРАЖЁН','#d44f4f']);if(!badges.length)return;target.save();target.font=`700 ${8/app.view.scale}px Segoe UI`;target.textAlign='center';target.textBaseline='middle';badges.forEach(([label,color],i)=>{const y=p.y+r+(8+i*11)/app.view.scale,w=Math.max(30,label.length*5)/app.view.scale;target.fillStyle='rgba(8,11,15,.88)';target.fillRect(p.x-w/2,y-5/app.view.scale,w,10/app.view.scale);target.strokeStyle=color;target.lineWidth=1/app.view.scale;target.strokeRect(p.x-w/2,y-5/app.view.scale,w,10/app.view.scale);target.fillStyle=color;target.fillText(label,p.x,y);});target.restore();};
  const v073BaseHitTestToken=hitTestToken;
  hitTestToken=function(point){app.pendingTargetPart=null;for(const token of [...(app.scene?.tokens||[])].reverse()){const st=speciesStateClient(token),head=st?.rokurokubi?.headPoint;if(st?.species==='rokurokubi'&&st.rokurokubi?.neckExtended&&head&&Math.hypot(point.x-head.x,point.y-head.y)<=Math.max(8,tokenRadius(token)*.4)){app.pendingTargetPart='head';return token;}}return v073BaseHitTestToken(point);};
  const v073BaseOnPointerDown=onPointerDown;
  onPointerDown=function(event){if(app.speciesTarget&&event.button===0&&app.scene){event.preventDefault();const world=screenToWorld(eventPoint(event)),mode=app.speciesTarget;if(mode.type==='point'){speciesAction(mode.action,{x:world.x,y:world.y}).finally(cancelSpeciesTarget);return;}const target=hitTestToken(world);if(target&&target.id!==mode.tokenId){speciesAction(mode.action,{targetTokenId:target.id}).finally(cancelSpeciesTarget);return;}toast('Выберите другой токен цели.','error');return;}return v073BaseOnPointerDown(event);};

  function bindV073Ui(){
    $('species-popover-close').onclick=()=>$('species-popover').hidden=true;
    $('species-popover-body').addEventListener('click',event=>{const meleeButton=event.target.closest('[data-species-melee]');if(meleeButton&&!meleeButton.disabled){$('species-popover').hidden=true;return beginDockTarget('melee',meleeButton.dataset.speciesMelee,'normal',meleeButton.dataset.speciesSpecial||null);}const button=event.target.closest('[data-species-action]');if(!button||button.disabled)return;const action=button.dataset.speciesAction;if(action==='pallid-blood-plus')return speciesAction('pallid-blood',{delta:1});if(action==='pallid-blood-minus')return speciesAction('pallid-blood',{delta:-1});if(action==='pallid-jump')return beginSpeciesPoint('pallid-jump','Выберите точку Прыжка Вечного в пределах 60 футов.');if(action==='werewolf-hunt')return beginSpeciesToken('werewolf-hunt','Выберите раненую живую цель в пределах 30 футов.');if(action==='roko-head')return beginSpeciesPoint('roko-head','Укажите положение головы в пределах 10 футов от тела.');if(action==='roko-ambush-lunge'){$('species-popover').hidden=true;return beginDockTarget('melee','rokurokubi-lunge','normal','ambush');}if(action==='roko-ambush-wrap'){$('species-popover').hidden=true;return beginDockTarget('melee','rokurokubi-wrap','normal','ambush');}return speciesAction(action);});
    $('action-slots').addEventListener('click',event=>{const button=event.target.closest('[data-dock-action]');if(!button||button.disabled)return;const key=button.dataset.dockAction;if(key==='species')return openSpeciesPopover();if(key==='species-stand')return speciesAction('stand');if(key==='species-escape')return speciesAction('escape-wrap');if(key.startsWith('melee-takedown:'))return beginDockTarget('melee',key.split(':')[1],'normal','takedown');});
    $('pallid-form-image-btn').onclick=()=>$('pallid-form-image-input').click();$('werewolf-form-image-btn').onclick=()=>$('werewolf-form-image-input').click();$('pallid-form-image-clear').onclick=()=>clearSpeciesFormImage('pallid');$('werewolf-form-image-clear').onclick=()=>clearSpeciesFormImage('werewolf');
    $('pallid-form-image-input').onchange=event=>{const file=event.target.files?.[0];if(file)uploadSpeciesFormImage('pallid',file);event.target.value='';};$('werewolf-form-image-input').onchange=event=>{const file=event.target.files?.[0];if(file)uploadSpeciesFormImage('werewolf',file);event.target.value='';};
    window.addEventListener('keydown',event=>{if(event.key==='Escape'&&app.speciesTarget){event.preventDefault();cancelSpeciesTarget();}});
  }


  /* ===== FATUM Battlemap v0.7.6: species OD audit, peeking, weather, pings and drawings ===== */
  app.mapPings = new Map();
  app.drawingDraft = null;
  app.weatherLayerId = null;

  function addMapPing(ping){
    if(!ping?.id||ping.sceneId!==app.scene?.id)return;
    app.mapPings.set(ping.id,{...ping,startedAt:performance.now(),duration:2200});
    requestRender();
  }
  async function sendMapPing(point){
    if(!app.scene)return;
    if(!master&&app.scene.settings?.playerCanPing===false){toast('Мастер отключил пинги игроков.','error');return;}
    try{await api('/api/battlemap/ping',{method:'POST',body:commonBody({sceneId:app.scene.id,x:point.x,y:point.y,color:$('draw-color')?.value||'#ffd36a'})});}catch(error){toast(error.message,'error');}
  }
  function drawMapPings(){
    if(!app.mapPings.size)return;const now=performance.now();let animate=false;ctx.save();ctx.setTransform(app.dimensions.dpr,0,0,app.dimensions.dpr,0,0);
    for(const [pingId,ping] of app.mapPings){const elapsed=now-ping.startedAt,t=elapsed/ping.duration;if(t>=1){app.mapPings.delete(pingId);continue;}animate=true;const p=worldToScreen(ping),pulse=(elapsed%700)/700,r=16+58*pulse,alpha=(1-t)*(1-pulse*.55);ctx.beginPath();ctx.arc(p.x,p.y,r,0,Math.PI*2);ctx.strokeStyle=ping.color||'#ffd36a';ctx.globalAlpha=alpha;ctx.lineWidth=4;ctx.stroke();ctx.beginPath();ctx.arc(p.x,p.y,7+5*Math.sin(elapsed*.02),0,Math.PI*2);ctx.fillStyle=ping.color||'#ffd36a';ctx.globalAlpha=Math.max(.25,1-t);ctx.fill();ctx.font='700 12px Segoe UI';ctx.textAlign='center';ctx.fillStyle='#fff';ctx.globalAlpha=1-t;ctx.fillText(ping.actorName||'Пинг',p.x,p.y-28);}
    ctx.restore();if(animate)requestRender();
  }

  function drawingDistance(point,drawing){let best=Infinity;const pts=drawing?.points||[];for(let i=1;i<pts.length;i++)best=Math.min(best,pointSegmentDistance(point,pts[i-1],pts[i]));return best;}
  function drawPersistentDrawings(){
    const drawings=app.scene?.drawings||[];if(!drawings.length&&!app.drawingDraft)return;ctx.save();ctx.setTransform(app.dimensions.dpr,0,0,app.dimensions.dpr,0,0);ctx.translate(app.view.x,app.view.y);ctx.scale(app.view.scale,app.view.scale);ctx.lineCap='round';ctx.lineJoin='round';
    const drawOne=d=>{const pts=d.points||[];if(pts.length<2)return;ctx.beginPath();ctx.moveTo(pts[0].x,pts[0].y);for(const p of pts.slice(1))ctx.lineTo(p.x,p.y);ctx.strokeStyle=d.color||'#ffd36a';ctx.globalAlpha=Number(d.opacity??.9);ctx.lineWidth=Math.max(1,Number(d.width||5))/app.view.scale;ctx.stroke();};
    for(const drawing of drawings)drawOne(drawing);if(app.drawingDraft)drawOne(app.drawingDraft);ctx.restore();
  }
  async function saveDrawing(drawing){
    if(!app.scene||drawing.points.length<2)return;
    try{await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/drawings`,{method:'POST',body:commonBody({drawing})});}catch(error){toast(error.message,'error');await refreshBattlemap();}
  }
  async function eraseDrawingAt(point){
    if(!app.scene)return;const candidates=[...(app.scene.drawings||[])].reverse();const drawing=candidates.find(item=>drawingDistance(point,item)<=(Number(item.width||5)+12)/Math.max(.08,app.view.scale));if(!drawing){toast('Рядом нет линии.');return;}
    try{await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/drawings/${encodeURIComponent(drawing.id)}`,{method:'DELETE',body:commonBody({})});}catch(error){toast(error.message,'error');}
  }
  async function clearDrawings(scope='own'){
    if(!app.scene)return;if(scope==='all'&&!confirm('Удалить все рисунки на этой сцене?'))return;
    try{await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/drawings`,{method:'DELETE',body:commonBody({scope})});toast(scope==='all'?'Все рисунки удалены.':'Ваши рисунки удалены.','success');}catch(error){toast(error.message,'error');}
  }

  function colorRgba(hex,alpha){const value=String(hex||'#ffffff').replace('#',''),n=parseInt(value,16)||0;return`rgba(${(n>>16)&255},${(n>>8)&255},${n&255},${alpha})`;}
  function weatherRand(seed,index){let x=2166136261;const text=`${seed}:${index}`;for(let i=0;i<text.length;i++){x^=text.charCodeAt(i);x=Math.imul(x,16777619);}x^=x>>>16;return(x>>>0)/4294967295;}
  function drawWeatherLayers(){
    const layers=(app.scene?.weatherLayers||[]).filter(layer=>layer.enabled!==false&&Number(layer.opacity)>0);if(!layers.length)return;const {width,height,dpr}=app.dimensions,now=performance.now()/1000,mapA=worldToScreen({x:0,y:0}),mapB=worldToScreen({x:app.scene.mapWidth,y:app.scene.mapHeight}),left=Math.max(0,Math.min(mapA.x,mapB.x)),top=Math.max(0,Math.min(mapA.y,mapB.y)),right=Math.min(width,Math.max(mapA.x,mapB.x)),bottom=Math.min(height,Math.max(mapA.y,mapB.y));if(right<=left||bottom<=top)return;
    ctx.save();ctx.setTransform(dpr,0,0,dpr,0,0);ctx.beginPath();ctx.rect(left,top,right-left,bottom-top);ctx.clip();let animate=false;
    for(const layer of layers){const opacity=clamp(Number(layer.opacity||0),0,.95),density=clamp(Number(layer.density||1),.1,2.5),speed=clamp(Number(layer.speed||0),0,4),scale=clamp(Number(layer.scale||1),.2,3),angle=Number(layer.direction||0)*Math.PI/180,dx=Math.cos(angle)*speed*90,dy=Math.sin(angle)*speed*90,color=layer.color||'#b8c0c8';if(speed>0)animate=true;
      if(layer.type==='fog'){ctx.fillStyle=colorRgba(color,opacity*.2);ctx.fillRect(left,top,right-left,bottom-top);const count=Math.round(18*density);for(let i=0;i<count;i++){const radius=(90+weatherRand(layer.id,i+80)*180)*scale,x=left+((weatherRand(layer.id,i)*((right-left)+radius*2)+now*dx)%((right-left)+radius*2)+((right-left)+radius*2))%((right-left)+radius*2)-radius,y=top+((weatherRand(layer.id,i+40)*((bottom-top)+radius*1.3)+now*dy)%((bottom-top)+radius*1.3)+((bottom-top)+radius*1.3))%((bottom-top)+radius*1.3)-radius*.65,g=ctx.createRadialGradient(x,y,0,x,y,radius);g.addColorStop(0,colorRgba(color,opacity*.18));g.addColorStop(1,colorRgba(color,0));ctx.fillStyle=g;ctx.fillRect(x-radius,y-radius,radius*2,radius*2);}}
      else if(layer.type==='dust'){ctx.fillStyle=colorRgba(color,opacity*.22);ctx.fillRect(left,top,right-left,bottom-top);const count=Math.round(150*density);for(let i=0;i<count;i++){const travel=(right-left)+90,x=left+((weatherRand(layer.id,i)*travel+now*dx*(.45+weatherRand(layer.id,i+130)))%travel+travel)%travel-45,y=top+((weatherRand(layer.id,i+20)*((bottom-top)+40)+now*dy*(.3+weatherRand(layer.id,i+170)))%((bottom-top)+40)+((bottom-top)+40))%((bottom-top)+40)-20,r=(.7+weatherRand(layer.id,i+90)*2.6)*scale;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fillStyle=colorRgba(color,opacity*(.28+.52*weatherRand(layer.id,i+210)));ctx.fill();}}
      else if(layer.type==='rain'){ctx.strokeStyle=colorRgba(color,opacity*.68);ctx.lineWidth=Math.max(1,1.4*scale);const count=Math.round(95*density);for(let i=0;i<count;i++){const len=(18+weatherRand(layer.id,i+120)*38)*scale,x=left+((weatherRand(layer.id,i)*((right-left)+60)+now*dx*1.8)%((right-left)+60)+((right-left)+60))%((right-left)+60)-30,y=top+((weatherRand(layer.id,i+30)*((bottom-top)+80)+now*Math.abs(dy||speed*130)*1.9)%((bottom-top)+80))-40;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+Math.cos(angle)*len,y+Math.sin(angle)*len);ctx.stroke();}}
      else {ctx.fillStyle=colorRgba(color,opacity*.75);const count=Math.round(70*density);for(let i=0;i<count;i++){const r=(1.4+weatherRand(layer.id,i+120)*3.8)*scale,x=left+((weatherRand(layer.id,i)*((right-left)+30)+now*dx*.45)%((right-left)+30)+((right-left)+30))%((right-left)+30)-15,y=top+((weatherRand(layer.id,i+30)*((bottom-top)+40)+now*(35+speed*55)*(0.7+weatherRand(layer.id,i+70)))%((bottom-top)+40))-20;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();}}
    }
    ctx.restore();if(animate)requestRender();
  }

  function weatherLayer(){return(app.scene?.weatherLayers||[]).find(layer=>layer.id===app.weatherLayerId)||null;}
  function weatherDefaults(type){return{id:`weather_${id()}`,name:({fog:'Туман',dust:'Пылевая буря',rain:'Дождь',snow:'Снег'})[type]||'Погода',type,enabled:true,opacity:type==='fog'?.42:.34,density:1,speed:type==='fog'?.35:1,direction:type==='rain'?105:15,scale:1,color:type==='dust'?'#b99162':type==='rain'?'#96b8d4':type==='snow'?'#e8f2fb':'#b8c0c8'};}
  function refreshWeatherUi(){
    if(!master)return;const list=$('weather-layer-list'),layers=app.scene?.weatherLayers||[];if(!list)return;if(app.weatherLayerId&&!layers.some(l=>l.id===app.weatherLayerId))app.weatherLayerId=null;list.innerHTML=layers.length?layers.map((layer,index)=>`<button class="bm-weather-item ${layer.id===app.weatherLayerId?'active':''}" data-weather-id="${esc(layer.id)}"><span>${layer.enabled===false?'○':'●'} ${esc(layer.name)}</span><small>${index+1} · ${esc(({fog:'туман',dust:'пыль',rain:'дождь',snow:'снег'})[layer.type]||layer.type)}</small></button>`).join(''):'<p class="bm-muted">Слоёв погоды пока нет.</p>';const layer=weatherLayer(),editor=$('weather-editor');editor.hidden=!layer;if(!layer)return;$('weather-name').value=layer.name;$('weather-type').value=layer.type;$('weather-enabled').checked=layer.enabled!==false;$('weather-opacity').value=layer.opacity;$('weather-density').value=layer.density;$('weather-speed').value=layer.speed;$('weather-direction').value=layer.direction;$('weather-scale').value=layer.scale;$('weather-color').value=layer.color;$('weather-opacity-value').textContent=`${Math.round(Number(layer.opacity)*100)}%`;$('weather-density-value').textContent=Number(layer.density).toFixed(1);$('weather-speed-value').textContent=Number(layer.speed).toFixed(1);
  }
  function readWeatherEditor(){const layer=weatherLayer();if(!layer)return null;Object.assign(layer,{name:$('weather-name').value.trim()||'Погода',type:$('weather-type').value,enabled:$('weather-enabled').checked,opacity:Number($('weather-opacity').value),density:Number($('weather-density').value),speed:Number($('weather-speed').value),direction:Number($('weather-direction').value),scale:Number($('weather-scale').value),color:$('weather-color').value});return layer;}
  async function saveWeatherLayers({quiet=false}={}){if(!master||!app.scene)return;readWeatherEditor();requestRender();const result=await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}`,{method:'PUT',body:commonBody({weatherLayers:app.scene.weatherLayers||[]})});if(result.scene?.weatherLayers)app.scene.weatherLayers=result.scene.weatherLayers;if(!quiet)toast('Слои погоды сохранены.','success');refreshWeatherUi();}
  function moveWeather(delta){const layers=app.scene?.weatherLayers||[],index=layers.findIndex(l=>l.id===app.weatherLayerId),next=index+delta;if(index<0||next<0||next>=layers.length)return;[layers[index],layers[next]]=[layers[next],layers[index]];saveWeatherLayers({quiet:true});}

  const v076BaseRefreshSceneForm=refreshSceneForm;
  refreshSceneForm=function(){v076BaseRefreshSceneForm();if(!app.scene)return;if($('player-can-ping'))$('player-can-ping').checked=app.scene.settings?.playerCanPing!==false;if($('player-can-draw'))$('player-can-draw').checked=app.scene.settings?.playerCanDraw!==false;refreshWeatherUi();};
  const v076BaseRefreshAllUi=refreshAllUi;
  refreshAllUi=function(){v076BaseRefreshAllUi();refreshWeatherUi();};

  const v076BaseRender=render;
  render=function(){v076BaseRender();drawPersistentDrawings();drawWeatherLayers();drawMapPings();};

  const v076BaseOnPointerDown=onPointerDown;
  onPointerDown=function(event){
    if(event.button===0&&app.scene&&['ping','draw','erase'].includes(app.tool)){event.preventDefault();const world=screenToWorld(eventPoint(event));
      if(app.tool==='ping'){sendMapPing(world);return;}
      if(app.tool==='erase'){eraseDrawingAt(world);return;}
      if(!master&&app.scene.settings?.playerCanDraw===false){toast('Мастер отключил рисование игроков.','error');return;}
      app.drawingDraft={id:`draft_${id()}`,points:[world],color:$('draw-color')?.value||'#ffd36a',width:Number($('draw-width')?.value||5),opacity:.9};canvas.setPointerCapture?.(event.pointerId);requestRender();return;
    }
    return v076BaseOnPointerDown(event);
  };
  const v076BaseOnPointerMove=onPointerMove;
  onPointerMove=function(event){if(app.drawingDraft){const world=screenToWorld(eventPoint(event)),points=app.drawingDraft.points,last=points[points.length-1];if(Math.hypot(world.x-last.x,world.y-last.y)>2/Math.max(.08,app.view.scale)){points.push(world);requestRender();}return;}return v076BaseOnPointerMove(event);};
  const v076BaseOnPointerUp=onPointerUp;
  onPointerUp=async function(event){if(app.drawingDraft){const drawing=app.drawingDraft;app.drawingDraft=null;canvas.releasePointerCapture?.(event?.pointerId);requestRender();if(drawing.points.length>=2)await saveDrawing(drawing);return;}return v076BaseOnPointerUp(event);};

  function bindV076Ui(){
    $('clear-own-drawings-btn').onclick=()=>clearDrawings('own');$('clear-all-drawings-btn').onclick=()=>clearDrawings('all');
    $('weather-add-btn').onclick=()=>{if(!app.scene)return;const layer=weatherDefaults($('weather-add-type').value);app.scene.weatherLayers||=[];app.scene.weatherLayers.push(layer);app.weatherLayerId=layer.id;refreshWeatherUi();saveWeatherLayers({quiet:true});};
    $('weather-layer-list').addEventListener('click',event=>{const button=event.target.closest('[data-weather-id]');if(!button)return;app.weatherLayerId=button.dataset.weatherId;refreshWeatherUi();});
    $('weather-save-btn').onclick=()=>saveWeatherLayers().catch(error=>toast(error.message,'error'));$('weather-delete-btn').onclick=()=>{const index=(app.scene?.weatherLayers||[]).findIndex(l=>l.id===app.weatherLayerId);if(index<0)return;app.scene.weatherLayers.splice(index,1);app.weatherLayerId=null;saveWeatherLayers({quiet:true});};$('weather-up-btn').onclick=()=>moveWeather(-1);$('weather-down-btn').onclick=()=>moveWeather(1);
    for(const el of [$('weather-name'),$('weather-type'),$('weather-enabled'),$('weather-opacity'),$('weather-density'),$('weather-speed'),$('weather-direction'),$('weather-scale'),$('weather-color')]){el?.addEventListener('input',()=>{readWeatherEditor();refreshWeatherUi();requestRender();scheduleLive('weather',()=>saveWeatherLayers({quiet:true}),180);});el?.addEventListener('change',()=>{readWeatherEditor();refreshWeatherUi();requestRender();scheduleLive('weather',()=>saveWeatherLayers({quiet:true}),100);});}
    $('player-can-ping')?.addEventListener('change',()=>v070SaveDaylight().catch(error=>toast(error.message,'error')));$('player-can-draw')?.addEventListener('change',()=>v070SaveDaylight().catch(error=>toast(error.message,'error')));
    window.addEventListener('keydown',event=>{if(event.key==='Escape'&&app.drawingDraft){app.drawingDraft=null;requestRender();}});
  }


  /* ===== FATUM Battlemap v0.7.7: scene cleanup, map removal and Delete key ===== */
  function v077SceneHasObjects(scene=app.scene){
    if(!scene)return false;
    return ['tokens','walls','doors','covers','effects','audioSources','weatherLayers','drawings','lights'].some(key=>(scene[key]||[]).length>0)
      || Boolean(scene.fog?.ops?.length)
      || Object.values(scene.fog?.explored||{}).some(cells=>Array.isArray(cells)&&cells.length>0);
  }
  function v077RefreshSceneManagementButtons(){
    const hasScene=Boolean(app.scene),hasMap=Boolean(app.scene?.mapUrl),hasObjects=v077SceneHasObjects();
    for(const id of ['delete-scene-btn','delete-scene-top-btn'])if($(id))$(id).disabled=!hasScene;
    if($('remove-map-btn'))$('remove-map-btn').disabled=!hasMap;
    if($('clear-scene-objects-btn'))$('clear-scene-objects-btn').disabled=!hasObjects;
  }
  async function v077DeleteCurrentScene(){
    const scene=app.scene;if(!scene)return;
    if(!confirm(`Удалить сцену «${scene.name}» целиком?\n\nБудут удалены её карта и все размещённые объекты. Перед удалением сервер создаст снимок.`))return;
    try{
      await api(`/api/battlemap/scenes/${encodeURIComponent(scene.id)}`,{method:'DELETE',body:commonBody()});
      app.selected=null;app.forceSceneId=null;await fetchAll(true);if(app.scene)fitView();
      toast('Сцена и связанная с ней карта удалены.','success');
    }catch(error){toast(error.message,'error');}
  }
  async function v077RemoveCurrentMap(){
    const scene=app.scene;if(!scene?.mapUrl)return;
    if(!confirm(`Удалить изображение карты из сцены «${scene.name}»?\n\nТокены и остальные объекты останутся на своих местах.`))return;
    try{
      await api(`/api/battlemap/scenes/${encodeURIComponent(scene.id)}/map`,{method:'DELETE',body:commonBody()});
      await refreshBattlemap();await loadMapImage();requestRender();v077RefreshSceneManagementButtons();
      toast('Карта удалена. Сцена и её объекты сохранены.','success');
    }catch(error){toast(error.message,'error');}
  }
  async function v077ClearCurrentSceneObjects(){
    const scene=app.scene;if(!scene||!v077SceneHasObjects(scene))return;
    if(!confirm(`Очистить сцену «${scene.name}» от всех объектов?\n\nБудут удалены токены, стены, двери, укрытия, свет, аудио-объекты, зоны эффектов, туман, рисунки и погодные слои. Само изображение карты и настройки сетки останутся.`))return;
    try{
      const result=await api(`/api/battlemap/scenes/${encodeURIComponent(scene.id)}/objects`,{method:'DELETE',body:commonBody()});
      app.selected=null;app.weatherLayerId=null;app.drawingDraft=null;app.transientEffects.clear();
      await fetchAll(true);requestRender();
      const total=Object.values(result.removed||{}).reduce((sum,value)=>sum+Number(value||0),0);
      toast(`Сцена очищена${total?` · удалено элементов: ${total}`:''}.`,'success');
    }catch(error){toast(error.message,'error');}
  }
  async function v077DeleteSelectedObject(){
    if(!master||!app.selected)return;
    const type=app.selected.type;
    if(type==='token')return deleteSelectedToken();
    if(type==='wall')return deleteSelectedWall();
    if(type==='door')return deleteSelectedDoor();
    if(type==='cover')return deleteSelectedCover();
    if(type==='light')return deleteSelectedLight();
    if(type==='audioSource')return v070DeleteSelectedAudioSource();
    toast('Этот элемент удаляется через свою панель управления.','error');
  }
  const v077BaseRefreshSceneForm=refreshSceneForm;
  refreshSceneForm=function(){v077BaseRefreshSceneForm();v077RefreshSceneManagementButtons();};
  const v077BaseRefreshAllUi=refreshAllUi;
  refreshAllUi=function(){v077BaseRefreshAllUi();v077RefreshSceneManagementButtons();};
  function bindV077Ui(){
    if($('delete-scene-btn'))$('delete-scene-btn').onclick=v077DeleteCurrentScene;
    if($('delete-scene-top-btn'))$('delete-scene-top-btn').onclick=v077DeleteCurrentScene;
    if($('remove-map-btn'))$('remove-map-btn').onclick=v077RemoveCurrentMap;
    if($('clear-scene-objects-btn'))$('clear-scene-objects-btn').onclick=v077ClearCurrentSceneObjects;
    window.addEventListener('keydown',event=>{
      if(event.key!=='Delete'||event.repeat||event.defaultPrevented||!master||!app.selected)return;
      if(isTypingTarget(event.target)||event.target?.isContentEditable||document.querySelector('.bm-modal:not([hidden])'))return;
      event.preventDefault();event.stopPropagation();v077DeleteSelectedObject();
    },{capture:true});
  }


  /* ===== FATUM Battlemap v0.7.9: NPC sheet cloning and adjacent-cell peeking ===== */
  const V078_COVERAGE_BONUS={quarter:1,half:2,full:5};
  const V078_MATERIAL_BONUS={light:1,strong:2,special:3};
  const V078_COVER_PRESETS={
    flimsy:{name:'Хлипкое укрытие',durability:2,durabilityLabel:'2'},
    light:{name:'Лёгкое укрытие',durability:4,durabilityLabel:'4'},
    strong:{name:'Крепкое укрытие',durability:6,durabilityLabel:'6'},
    fortified:{name:'Укреплённая позиция',durability:8,durabilityLabel:'8+'}
  };
  function v078CoverMz(){const coverage=$('new-cover-coverage')?.value||'half',material=$('new-cover-material')?.value||'light';return 5+(V078_COVERAGE_BONUS[coverage]||0)+(V078_MATERIAL_BONUS[material]||0);}
  function v078UpdateCoverRuleSummary({writeMz=true}={}){
    const coverage=$('new-cover-coverage')?.value||'half',material=$('new-cover-material')?.value||'light',sizeBonus=V078_COVERAGE_BONUS[coverage]||0,materialBonus=V078_MATERIAL_BONUS[material]||0,mz=5+sizeBonus+materialBonus;
    if(writeMz&&$('new-cover-mz'))$('new-cover-mz').value=String(mz);
    const preset=V078_COVER_PRESETS[$('new-cover-preset')?.value],durability=preset?.durabilityLabel||String(Number($('new-cover-durability')?.value||0));
    if($('new-cover-rule-summary'))$('new-cover-rule-summary').innerHTML=`МЗ = 5 + ${sizeBonus} + ${materialBonus} = <strong>${mz}</strong> · Прочность <strong>${esc(durability)}</strong>`;
  }
  function v078ApplyCoverPreset(){
    const key=$('new-cover-preset')?.value,preset=V078_COVER_PRESETS[key];
    if(!preset){v078UpdateCoverRuleSummary({writeMz:false});return;}
    $('new-cover-name').value=preset.name;$('new-cover-durability').value=String(preset.durability);
    v078UpdateCoverRuleSummary({writeMz:true});
  }
  function v078Clone(value){return value==null?value:JSON.parse(JSON.stringify(value));}
  function v078ClipboardStorageKey(){return'fatumBattlemapObjectClipboardV078';}
  function v078SelectedObjectSnapshot(){
    if(!app.selected)return null;const type=app.selected.type;let object=null;
    if(type==='token')object=tokenById(app.selected.id);else if(type==='wall')object=wallById(app.selected.id);else if(type==='door')object=doorById(app.selected.id);else if(type==='cover')object=coverById(app.selected.id);else if(type==='light')object=lightById(app.selected.id);else if(type==='audioSource')object=v070AudioSourceById(app.selected.id);
    if(!object)return null;const copy=v078Clone(object);
    if(type==='door'){const geometry=doorGeometry(object);Object.assign(copy,{wallId:null,x1:geometry.x1,y1:geometry.y1,x2:geometry.x2,y2:geometry.y2});}
    return{type,object:copy};
  }
  function v078ObjectLabel(type,object){return type==='token'?`токен «${object.name||'без названия'}»`:type==='wall'?'стена':type==='door'?`дверь «${object.name||'без названия'}»`:type==='cover'?`укрытие «${object.name||'без названия'}»`:type==='light'?`источник света «${object.name||'без названия'}»`:type==='audioSource'?`аудио-объект «${object.name||'без названия'}»`:'объект';}
  function v078CopySelectedObject(){
    if(!master)return;const snapshot=v078SelectedObjectSnapshot();if(!snapshot){toast('Сначала выберите объект, который нужно скопировать.','error');return;}
    app.objectClipboard={...snapshot,sourceSceneId:app.scene?.id||null,pasteCount:0,copiedAt:Date.now()};
    try{localStorage.setItem(v078ClipboardStorageKey(),JSON.stringify(app.objectClipboard));}catch{}
    toast(`Скопировано: ${v078ObjectLabel(snapshot.type,snapshot.object)}.`,'success');
  }
  function v078ReadClipboard(){
    if(app.objectClipboard?.object)return app.objectClipboard;
    try{const value=JSON.parse(localStorage.getItem(v078ClipboardStorageKey())||'null');if(value&&['token','wall','door','cover','light','audioSource'].includes(value.type)&&value.object){app.objectClipboard=value;return value;}}catch{}
    return null;
  }
  function v078Anchor(type,object){
    if(['token','light','audioSource'].includes(type))return{x:Number(object.x||0),y:Number(object.y||0)};
    if(type==='wall'){const points=object.points?.length?object.points:[{x:object.x1,y:object.y1},{x:object.x2,y:object.y2}];return points.reduce((sum,point)=>({x:sum.x+Number(point.x||0)/points.length,y:sum.y+Number(point.y||0)/points.length}),{x:0,y:0});}
    if(type==='door')return{x:(Number(object.x1||0)+Number(object.x2||0))/2,y:(Number(object.y1||0)+Number(object.y2||0))/2};
    if(type==='cover'){if(object.points?.length)return object.points.reduce((sum,point)=>({x:sum.x+Number(point.x||0)/object.points.length,y:sum.y+Number(point.y||0)/object.points.length}),{x:0,y:0});if(object.shape==='circle')return{x:Number(object.x||0),y:Number(object.y||0)};return{x:Number(object.x||0)+Number(object.width||0)/2,y:Number(object.y||0)+Number(object.height||0)/2};}
    return{x:0,y:0};
  }
  function v078TranslateObject(type,source,dx,dy){
    const object=v078Clone(source),movePoint=point=>({x:Number(point.x||0)+dx,y:Number(point.y||0)+dy});
    if(['token','light','audioSource'].includes(type)){object.x=Number(object.x||0)+dx;object.y=Number(object.y||0)+dy;}
    else if(type==='wall'){object.x1=Number(object.x1||0)+dx;object.y1=Number(object.y1||0)+dy;object.x2=Number(object.x2||0)+dx;object.y2=Number(object.y2||0)+dy;if(object.points?.length)object.points=object.points.map(movePoint);}
    else if(type==='door'){object.wallId=null;object.x1=Number(object.x1||0)+dx;object.y1=Number(object.y1||0)+dy;object.x2=Number(object.x2||0)+dx;object.y2=Number(object.y2||0)+dy;}
    else if(type==='cover'){object.x=Number(object.x||0)+dx;object.y=Number(object.y||0)+dy;if(object.points?.length)object.points=object.points.map(movePoint);}
    delete object.id;delete object.updatedAt;
    if(object.name&&!/\(копия\)$/i.test(object.name))object.name=`${object.name} (копия)`;
    if(type==='wall'&&object.coverName&&!/\(копия\)$/i.test(object.coverName))object.coverName=`${object.coverName} (копия)`;
    return object;
  }
  function v079NpcCopyName(sourceName){
    const raw=String(sourceName||'NPC').trim()||'NPC',base=raw.replace(/\s+\(копия(?:\s+\d+)?\)$/i,'').trim()||'NPC';
    const existing=new Set((app.campaign?.npcs||[]).map(npc=>String(npc.name||'').trim().toLocaleLowerCase('ru-RU')));
    let index=1,candidate=`${base} (копия)`;
    while(existing.has(candidate.toLocaleLowerCase('ru-RU'))){index+=1;candidate=`${base} (копия ${index})`;}
    return candidate;
  }
  async function v079CloneNpcSheetForToken(tokenObject){
    if(tokenObject?.kind!=='npc'||!tokenObject.refId)return null;
    const sourceNpc=npcById(tokenObject.refId);
    if(!sourceNpc)throw new Error('Связанный лист NPC не найден. Возможно, буфер относится к другой кампании.');
    const npcCopy=v078Clone(sourceNpc);delete npcCopy.id;delete npcCopy.updatedAt;
    npcCopy.name=v079NpcCopyName(sourceNpc.name);npcCopy.initiative=0;
    npcCopy._battlemapActions={};npcCopy._battlemapCounterDebt=0;npcCopy._battlemapMeleeDefensePenalty=0;
    const result=await api('/api/npcs',{method:'POST',body:commonBody(npcCopy)});
    if(!result?.npc?.id)throw new Error('Не удалось создать отдельный лист для копии NPC.');
    app.campaign ||= {npcs:[]};app.campaign.npcs ||= [];
    if(!app.campaign.npcs.some(npc=>npc.id===result.npc.id))app.campaign.npcs.push(result.npc);
    tokenObject.refId=result.npc.id;tokenObject.name=result.npc.name;
    return result.npc;
  }
  async function v078PasteObject(){
    if(!master||!app.scene)return;const clipboard=v078ReadClipboard();if(!clipboard){toast('Буфер объектов пуст. Скопируйте объект сочетанием Ctrl+C.','error');return;}
    clipboard.pasteCount=Math.max(0,Number(clipboard.pasteCount||0))+1;const sourceAnchor=v078Anchor(clipboard.type,clipboard.object),sameScene=clipboard.sourceSceneId===app.scene.id,step=Math.max(18,Number(app.scene.grid?.size||70)*.35);let dx,dy;
    if(sameScene){dx=step*clipboard.pasteCount;dy=step*clipboard.pasteCount;}else{const center=screenToWorld({x:app.dimensions.width/2,y:app.dimensions.height/2}),repeatOffset=step*Math.max(0,clipboard.pasteCount-1);dx=center.x-sourceAnchor.x+repeatOffset;dy=center.y-sourceAnchor.y+repeatOffset;}
    const object=v078TranslateObject(clipboard.type,clipboard.object,dx,dy);let newId=null;
    try{
      if(clipboard.type==='token'){
        object.boardedVehicleId=null;if(object.vehicle){object.vehicle.occupants=[];object.vehicle.driverTokenId=null;}
        let clonedNpc=null;
        try{
          if(object.kind==='npc'&&object.refId)clonedNpc=await v079CloneNpcSheetForToken(object);
          const result=await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/tokens`,{method:'POST',body:commonBody(object)});if(result.token&&!app.scene.tokens.some(token=>token.id===result.token.id))app.scene.tokens.push(result.token);newId=result.token?.id||null;
        }catch(error){
          if(clonedNpc?.id){try{await api(`/api/npcs/${encodeURIComponent(clonedNpc.id)}`,{method:'DELETE',body:commonBody()});}catch{}app.campaign.npcs=(app.campaign?.npcs||[]).filter(npc=>npc.id!==clonedNpc.id);}
          throw error;
        }
      }else if(clipboard.type==='wall'){object.id=`wall_${id()}`;app.scene.walls.push(object);newId=object.id;await saveWalls();}
      else if(clipboard.type==='door'){object.id=`door_${id()}`;app.scene.doors.push(object);newId=object.id;await saveDoors();}
      else if(clipboard.type==='cover'){object.id=`cover_${id()}`;app.scene.covers.push(object);newId=object.id;await saveCovers();}
      else if(clipboard.type==='light'){object.id=`light_${id()}`;app.scene.lights.push(object);newId=object.id;await saveLights();}
      else if(clipboard.type==='audioSource'){object.id=`audio_${id()}`;app.scene.audioSources||=[];app.scene.audioSources.push(object);newId=object.id;await v070SaveAudioSources();}
      app.objectClipboard=clipboard;try{localStorage.setItem(v078ClipboardStorageKey(),JSON.stringify(clipboard));}catch{}
      if(newId)selectObject(clipboard.type,newId);toast(`Вставлено: ${v078ObjectLabel(clipboard.type,object)}.`,'success');requestRender();
    }catch(error){toast(error.message,'error');await refreshBattlemap();}
  }
  function bindV078Ui(){
    if($('new-cover-preset'))$('new-cover-preset').addEventListener('change',v078ApplyCoverPreset);
    for(const controlId of ['new-cover-coverage','new-cover-material'])if($(controlId))$(controlId).addEventListener('change',()=>v078UpdateCoverRuleSummary({writeMz:true}));
    if($('new-cover-mz'))$('new-cover-mz').addEventListener('input',()=>v078UpdateCoverRuleSummary({writeMz:false}));
    if($('new-cover-durability'))$('new-cover-durability').addEventListener('input',()=>v078UpdateCoverRuleSummary({writeMz:false}));
    window.addEventListener('keydown',event=>{
      if(!master||event.repeat||event.defaultPrevented||!(event.ctrlKey||event.metaKey)||event.altKey)return;
      if(isTypingTarget(event.target)||event.target?.isContentEditable||document.querySelector('.bm-modal:not([hidden])'))return;
      const key=String(event.key||'').toLowerCase();if(key!=='c'&&key!=='v')return;
      if(key==='c'&&!app.selected)return;
      event.preventDefault();event.stopPropagation();if(key==='c')v078CopySelectedObject();else v078PasteObject();
    },{capture:true});
    v078UpdateCoverRuleSummary({writeMz:false});
  }


  /* ===== FATUM Battlemap v0.8.2: progressive maps and preload ===== */
  app.progressiveImageCache = new Map();
  app.progressiveImageOrder = [];
  app.mapPreviewImage = null;
  app.mapFullImage = null;
  app.mapFullFadeStartedAt = 0;
  app.mapLoadGeneration = 0;
  app.mapRetry = null;

  function v081FormatBytes(bytes){
    const value=Math.max(0,Number(bytes)||0);if(value<1024)return`${Math.round(value)} Б`;if(value<1024*1024)return`${(value/1024).toFixed(value<10240?1:0)} КБ`;return`${(value/1024/1024).toFixed(value<10*1024*1024?1:0)} МБ`;
  }
  function v081SetTransfer({title='Загрузка карты',detail='',percent=0,retry=false,hidden=false}={}){
    const box=$('map-transfer');if(!box)return;if(!hidden)window.clearTimeout(app.mapTransferHideTimer);box.hidden=Boolean(hidden);if(hidden)return;
    $('map-transfer-title').textContent=title;$('map-transfer-detail').textContent=detail;$('map-transfer-percent').textContent=`${Math.round(clamp(Number(percent)||0,0,100))}%`;$('map-transfer-bar').style.width=`${clamp(Number(percent)||0,0,100)}%`;$('map-transfer-retry').hidden=!retry;
  }
  function v081HideTransfer(delay=350){window.clearTimeout(app.mapTransferHideTimer);app.mapTransferHideTimer=window.setTimeout(()=>v081SetTransfer({hidden:true}),delay);}
  function v081ImageSource(file){
    if('createImageBitmap'in window)return createImageBitmap(file).then(bitmap=>({image:bitmap,width:bitmap.width,height:bitmap.height,close:()=>bitmap.close?.()}));
    return new Promise((resolve,reject)=>{const url=URL.createObjectURL(file),image=new Image();image.onload=()=>resolve({image,width:image.naturalWidth,height:image.naturalHeight,close:()=>URL.revokeObjectURL(url)});image.onerror=()=>{URL.revokeObjectURL(url);reject(new Error('Не удалось открыть изображение карты.'));};image.src=url;});
  }
  function v081CanvasBlob(source,width,height,maxSide,quality){
    const scale=Math.min(1,Math.max(1,Number(maxSide)||1)/Math.max(width,height)),targetWidth=Math.max(1,Math.round(width*scale)),targetHeight=Math.max(1,Math.round(height*scale));
    if(targetWidth>30000||targetHeight>30000)throw new Error('Разрешение карты превышает поддерживаемый предел 30000 пикселей.');
    const canvas=document.createElement('canvas');canvas.width=targetWidth;canvas.height=targetHeight;const context=canvas.getContext('2d',{alpha:true});context.imageSmoothingEnabled=true;context.imageSmoothingQuality='high';context.drawImage(source,0,0,targetWidth,targetHeight);
    return new Promise((resolve,reject)=>canvas.toBlob(blob=>{if(blob)return resolve({blob,width:targetWidth,height:targetHeight});canvas.toBlob(fallback=>fallback?resolve({blob:fallback,width:targetWidth,height:targetHeight}):reject(new Error('Браузер не смог обработать карту.')),'image/jpeg',quality);},'image/webp',quality));
  }
  function v081UploadBlob(blob,name,onProgress){
    return new Promise((resolve,reject)=>{const query=new URLSearchParams({kind:'map',name,clientId}),xhr=new XMLHttpRequest();xhr.open('POST',`/api/battlemap/assets/upload?${query}`);xhr.withCredentials=true;xhr.setRequestHeader('Content-Type',blob.type||'application/octet-stream');xhr.upload.onprogress=event=>{if(event.lengthComputable)onProgress?.(event.loaded,event.total);};xhr.onerror=()=>reject(new Error('Соединение прервано при загрузке карты.'));xhr.onload=()=>{let payload={};try{payload=JSON.parse(xhr.responseText||'{}');}catch{}if(xhr.status>=200&&xhr.status<300&&payload.url)resolve(payload);else reject(new Error(payload.error||`HTTP ${xhr.status}`));};xhr.send(blob);});
  }
  async function v081CleanupMapUrls(urls){const list=[...new Set((urls||[]).filter(Boolean))];if(!list.length)return;try{await api('/api/battlemap/assets/cleanup',{method:'POST',body:commonBody({urls:list})});}catch(error){console.warn('Не удалось удалить временные варианты карты:',error);}}
  function v081MapBaseName(file){return(String(file?.name||'map').replace(/\.[^.]+$/,'').replace(/[^A-Za-z0-9А-Яа-яЁё_.-]+/g,'_').slice(0,70)||'map');}
  async function v081PrepareMapVariants(file,mode='optimal',keepOriginal=false){
    if(!file)throw new Error('Файл карты не выбран.');if(!/^image\/(?:png|jpeg|webp|gif)$/i.test(file.type||''))throw new Error('Поддерживаются PNG, JPEG, WEBP и GIF.');
    if(file.size>120*1024*1024)throw new Error('Исходный файл слишком большой для обработки в браузере. Лимит 120 МБ.');
    if(keepOriginal&&mode!=='original'&&file.size>36*1024*1024)throw new Error('Исходник больше 36 МБ и не может быть сохранён отдельно. Отключите сохранение исходника или уменьшите файл.');
    v081SetTransfer({title:'Подготовка карты',detail:'Декодирование изображения…',percent:3});const source=await v081ImageSource(file);const width=source.width,height=source.height;
    if(!width||!height||width>30000||height>30000||width*height>120000000){source.close();throw new Error('Карта слишком велика для безопасной обработки в браузере. Предел: 30000 px по стороне и около 120 мегапикселей.');}
    try{
      v081SetTransfer({title:'Подготовка карты',detail:'Создание быстрого предпросмотра…',percent:8});const preview=await v081CanvasBlob(source.image,width,height,1280,.72);
      v081SetTransfer({title:'Подготовка карты',detail:'Создание миниатюры…',percent:14});const thumbnail=await v081CanvasBlob(source.image,width,height,360,.64);
      let full;if(mode==='original')full={blob:file,width,height};else{const maxSide=mode==='high'?7000:5000,quality=mode==='high'?.91:.84;v081SetTransfer({title:'Подготовка карты',detail:mode==='high'?'Оптимизация в высоком качестве…':'Оптимизация полной карты…',percent:20});full=await v081CanvasBlob(source.image,width,height,maxSide,quality);}
      return{width,height,full,preview,thumbnail,original:keepOriginal&&mode!=='original'?file:null,mode};
    }finally{source.close();}
  }
  async function v081ProcessAndUploadMap(file,mode='optimal',keepOriginal=false){
    const prepared=await v081PrepareMapVariants(file,mode,keepOriginal),base=v081MapBaseName(file),items=[
      {key:'mapThumbnailUrl',blob:prepared.thumbnail.blob,name:`${base}-thumb.webp`,label:'миниатюра'},
      {key:'mapPreviewUrl',blob:prepared.preview.blob,name:`${base}-preview.webp`,label:'предпросмотр'},
      {key:'mapUrl',blob:prepared.full.blob,name:`${base}-full.${prepared.full.blob.type==='image/webp'?'webp':(file.name.split('.').pop()||'img')}`,label:'полная карта'}
    ];
    if(prepared.original)items.push({key:'mapOriginalUrl',blob:prepared.original,name:file.name,label:'исходник'});
    const total=items.reduce((sum,item)=>sum+item.blob.size,0),uploaded=[],result={mapOriginalUrl:null};let completed=0;
    try{
      for(const item of items){const response=await v081UploadBlob(item.blob,item.name,(loaded)=>{const progress=26+72*((completed+loaded)/Math.max(1,total));v081SetTransfer({title:'Загрузка карты',detail:`Передаётся ${item.label}: ${v081FormatBytes(loaded)} из ${v081FormatBytes(item.blob.size)}`,percent:progress});});result[item.key]=response.url;uploaded.push(response.url);completed+=item.blob.size;}
      result.mapWidth=prepared.width;result.mapHeight=prepared.height;result.mapOptimization={mode:prepared.mode,sourceName:file.name,sourceBytes:file.size,fullBytes:prepared.full.blob.size,previewBytes:prepared.preview.blob.size,thumbnailBytes:prepared.thumbnail.blob.size,sourceStored:prepared.mode==='original'||Boolean(prepared.original),uploadedAt:new Date().toISOString()};result._uploadedUrls=uploaded;
      v081SetTransfer({title:'Карта готова',detail:`Полная версия: ${v081FormatBytes(prepared.full.blob.size)} · предпросмотр: ${v081FormatBytes(prepared.preview.blob.size)}`,percent:100});return result;
    }catch(error){await v081CleanupMapUrls(uploaded);throw error;}
  }
  function v081DecodeBlob(blob){
    if('createImageBitmap'in window)return createImageBitmap(blob);
    return new Promise((resolve,reject)=>{const url=URL.createObjectURL(blob),image=new Image();image.onload=()=>{image._fatumObjectUrl=url;resolve(image);};image.onerror=()=>{URL.revokeObjectURL(url);reject(new Error('Не удалось декодировать изображение карты.'));};image.src=url;});
  }
  function v081ProgressiveImage(url,onProgress,{force=false}={}){
    if(!url)return Promise.resolve(null);if(force)app.progressiveImageCache.delete(url);if(app.progressiveImageCache.has(url))return app.progressiveImageCache.get(url);
    const promise=(async()=>{const response=await fetch(url,{credentials:'same-origin',cache:'force-cache'});if(!response.ok)throw new Error(`HTTP ${response.status}`);const total=Math.max(0,Number(response.headers.get('content-length'))||0);let blob;
      if(response.body?.getReader){const reader=response.body.getReader(),chunks=[];let loaded=0;while(true){const{done,value}=await reader.read();if(done)break;chunks.push(value);loaded+=value.byteLength;onProgress?.(loaded,total);}blob=new Blob(chunks,{type:response.headers.get('content-type')||'image/webp'});}else{blob=await response.blob();onProgress?.(blob.size,blob.size);}
      return v081DecodeBlob(blob);
    })();app.progressiveImageCache.set(url,promise);promise.then(image=>{app.progressiveImageOrder=app.progressiveImageOrder.filter(item=>item!==url);app.progressiveImageOrder.push(url);let guard=10;while(app.progressiveImageOrder.length>3&&guard-->0){const candidate=app.progressiveImageOrder.shift();if(candidate===app.scene?.mapUrl){app.progressiveImageOrder.push(candidate);continue;}const cached=app.progressiveImageCache.get(candidate);app.progressiveImageCache.delete(candidate);Promise.resolve(cached).then(oldImage=>{try{oldImage?.close?.();if(oldImage?._fatumObjectUrl)URL.revokeObjectURL(oldImage._fatumObjectUrl);}catch{}});}}).catch(()=>{app.progressiveImageCache.delete(url);app.progressiveImageOrder=app.progressiveImageOrder.filter(item=>item!==url);});return promise;
  }
  loadMapImage=async function(force=false){
    const scene=app.scene,fullUrl=scene?.mapUrl||null,previewUrl=scene?.mapPreviewUrl||scene?.mapThumbnailUrl||null,signature=scene?`${scene.id}|${fullUrl||''}|${previewUrl||''}`:null;
    if(!force&&app.mapImageUrl===signature)return;const generation=++app.mapLoadGeneration;app.mapImageUrl=signature;app.mapPreviewImage=null;app.mapFullImage=null;app.mapImage=null;app.mapFullFadeStartedAt=0;app.mapRetry=null;requestRender();if(!scene||(!fullUrl&&!previewUrl)){v081SetTransfer({hidden:true});return;}
    if(previewUrl&&previewUrl!==fullUrl){try{const preview=await loadImage(previewUrl);if(generation!==app.mapLoadGeneration)return;app.mapPreviewImage=preview;app.mapImage=preview;requestRender();}catch{} }
    if(!fullUrl){v081SetTransfer({hidden:true});return;}
    v081SetTransfer({title:'Загрузка полной карты',detail:app.mapPreviewImage?'Предпросмотр уже доступен — можно работать.':'Получение изображения…',percent:app.mapPreviewImage?4:0});
    try{const full=await v081ProgressiveImage(fullUrl,(loaded,total)=>{if(generation!==app.mapLoadGeneration)return;const percent=total?loaded/total*100:Math.min(92,10+loaded/262144);v081SetTransfer({title:'Загрузка полной карты',detail:`${v081FormatBytes(loaded)}${total?` из ${v081FormatBytes(total)}`:''}`,percent});},{force});if(generation!==app.mapLoadGeneration)return;app.mapFullImage=full;app.mapImage=full;app.mapFullFadeStartedAt=performance.now();requestRender();v081SetTransfer({title:'Карта загружена',detail:'Полная версия готова.',percent:100});v081HideTransfer(550);}catch(error){if(generation!==app.mapLoadGeneration)return;app.mapRetry=()=>loadMapImage(true);v081SetTransfer({title:'Полная карта не загрузилась',detail:app.mapPreviewImage?'Игра продолжится с предпросмотром. Можно повторить загрузку.':error.message,percent:0,retry:true});}
  };
  drawMap=function(target){
    const scene=app.scene;target.fillStyle=scene.background||'#20242b';target.fillRect(0,0,scene.mapWidth,scene.mapHeight);const preview=app.mapPreviewImage,full=app.mapFullImage;
    if(preview)target.drawImage(preview,0,0,scene.mapWidth,scene.mapHeight);
    if(full){const fade=preview&&app.mapFullFadeStartedAt?clamp((performance.now()-app.mapFullFadeStartedAt)/260,0,1):1;target.save();target.globalAlpha=fade;target.drawImage(full,0,0,scene.mapWidth,scene.mapHeight);target.restore();if(fade<1)requestRender();}
    else if(!preview&&app.mapImage)target.drawImage(app.mapImage,0,0,scene.mapWidth,scene.mapHeight);
    target.strokeStyle='rgba(205,214,225,.35)';target.lineWidth=2/app.view.scale;target.strokeRect(0,0,scene.mapWidth,scene.mapHeight);
  };
  async function v081PreloadPayload(preload){
    const urls=[preload?.mapThumbnailUrl,preload?.mapPreviewUrl,preload?.mapUrl].filter(Boolean);for(const url of [...new Set(urls)])try{const response=await fetch(url,{credentials:'same-origin',cache:'force-cache'});if(!response.ok)throw new Error(`HTTP ${response.status}`);await response.arrayBuffer();}catch(error){console.warn('Предзагрузка карты не удалась:',error);}
  }
  const v081BaseConnectEvents=connectEvents;
  connectEvents=function(){v081BaseConnectEvents();app.eventSource?.addEventListener('battlemap-map-preload',event=>{try{const payload=JSON.parse(event.data);if(payload?.preload)v081PreloadPayload(payload.preload);}catch(error){console.warn(error);}});};

  const v081BaseRefreshSceneSelect=refreshSceneSelect;
  refreshSceneSelect=function(){v081BaseRefreshSceneSelect();if(!master)return;const scenes=app.battlemap?.scenes||[],preload=$('preload-scene-select'),previous=preload?.value||'';if(preload){preload.innerHTML=scenes.map(scene=>`<option value="${esc(scene.id)}">${esc(scene.name)}${scene.id===app.battlemap.activeSceneId?' · активна':''}</option>`).join('');if(scenes.some(scene=>scene.id===previous))preload.value=previous;else if(app.scene)preload.value=app.scene.id;preload.disabled=!scenes.some(scene=>scene.mapUrl||scene.mapPreviewUrl);}const list=$('scene-thumbnail-list');if(list)list.innerHTML=scenes.map(scene=>`<button class="bm-scene-thumb ${scene.id===app.scene?.id?'active':''}" data-scene-thumb-id="${esc(scene.id)}" title="Открыть сцену «${esc(scene.name)}»">${scene.mapThumbnailUrl?`<img class="bm-scene-thumb-image" src="${esc(scene.mapThumbnailUrl)}" loading="lazy">`:'<span class="bm-scene-thumb-placeholder">▧</span>'}<span>${esc(scene.name)}</span>${scene.id===app.battlemap.activeSceneId?'<small>активна</small>':''}</button>`).join('')||'<p class="bm-muted">Сцен пока нет.</p>';};
  const v081BaseRefreshSceneForm=refreshSceneForm;
  refreshSceneForm=function(){v081BaseRefreshSceneForm();const info=$('current-map-info');if(!info)return;const scene=app.scene,meta=scene?.mapOptimization;if(!scene?.mapUrl&&!scene?.mapPreviewUrl){info.textContent='Карта не загружена.';return;}if(!meta){info.textContent='Старая карта без прогрессивных вариантов. При следующей загрузке оптимизация применится автоматически.';return;}const mode={optimal:'Оптимальный',high:'Высокое качество',original:'Без обработки'}[meta.mode]||meta.mode;info.innerHTML=`<strong>${esc(mode)}</strong><br>Исходник: ${esc(meta.sourceName||'—')} · ${v081FormatBytes(meta.sourceBytes)}<br>Полная: ${v081FormatBytes(meta.fullBytes)} · предпросмотр: ${v081FormatBytes(meta.previewBytes)} · миниатюра: ${v081FormatBytes(meta.thumbnailBytes)}${meta.sourceStored?'<br>Исходный файл сохранён.':''}`;};
  const v081BaseRefreshAllUi=refreshAllUi;
  refreshAllUi=function(){v081BaseRefreshAllUi();};

  createScene=async function(name,file){
    let fields={mapUrl:null,mapPreviewUrl:null,mapThumbnailUrl:null,mapOriginalUrl:null,mapOptimization:null,mapWidth:1920,mapHeight:1080},uploaded=[];
    try{if(file){const mode=$('new-scene-map-mode')?.value||'optimal',keep=Boolean($('new-scene-keep-original')?.checked);const maps=await v081ProcessAndUploadMap(file,mode,keep);uploaded=maps._uploadedUrls||[];fields={...fields,...maps};delete fields._uploadedUrls;}
      const result=await api('/api/battlemap/scenes',{method:'POST',body:commonBody({name,...fields})});await api('/api/battlemap/active',{method:'PUT',body:commonBody({sceneId:result.scene.id})});app.forceSceneId=result.scene.id;await refreshBattlemap();fitView();toast('Сцена создана.','success');
    }catch(error){await v081CleanupMapUrls(uploaded);throw error;}
  };
  async function v081ReplaceSceneMap(file){
    if(!file||!app.scene)return;const mode=$('map-upload-mode')?.value||'optimal',keep=Boolean($('map-keep-original')?.checked);let maps=null;
    try{maps=await v081ProcessAndUploadMap(file,mode,keep);const patch={...maps};delete patch._uploadedUrls;await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}`,{method:'PUT',body:commonBody(patch)});await refreshBattlemap();fitView();toast('Карта оптимизирована и загружена.','success');}catch(error){if(maps?._uploadedUrls)await v081CleanupMapUrls(maps._uploadedUrls);throw error;}
  }
  function bindV081Ui(){
    const savedMode=localStorage.getItem('fatumMapUploadModeV081');if(savedMode&&['optimal','high','original'].includes(savedMode))$('map-upload-mode').value=savedMode;
    $('map-upload-mode').onchange=()=>{localStorage.setItem('fatumMapUploadModeV081',$('map-upload-mode').value);$('new-scene-map-mode').value=$('map-upload-mode').value;};$('new-scene-map-mode').value=$('map-upload-mode').value;
    $('upload-map-btn').onclick=()=>$('map-file-input').click();$('map-file-input').onchange=async event=>{const file=event.target.files?.[0];if(!file||!app.scene)return;try{await v081ReplaceSceneMap(file);}catch(error){toast(error.message,'error');v081SetTransfer({title:'Не удалось загрузить карту',detail:error.message,percent:0});}finally{event.target.value='';}};
    $('preload-map-btn').onclick=async()=>{const sceneId=$('preload-scene-select').value,scene=(app.battlemap?.scenes||[]).find(item=>item.id===sceneId);if(!scene)return;try{await api(`/api/battlemap/scenes/${encodeURIComponent(sceneId)}/preload`,{method:'POST',body:commonBody()});toast(`Предзагрузка сцены «${scene.name}» отправлена игрокам.`,'success');}catch(error){toast(error.message,'error');}};
    $('scene-thumbnail-list').addEventListener('click',async event=>{const button=event.target.closest('[data-scene-thumb-id]');if(!button)return;const sceneId=button.dataset.sceneThumbId;try{await api('/api/battlemap/active',{method:'PUT',body:commonBody({sceneId})});app.forceSceneId=sceneId;await refreshBattlemap();fitView();}catch(error){toast(error.message,'error');}});
    $('map-transfer-retry').onclick=()=>app.mapRetry?.();refreshSceneSelect();refreshSceneForm();
  }


  // v0.8.2: melee engagement, opportunity attacks and zone-of-fire feedback.
  function v082Faction(token){if(!token)return'neutral';if(token.kind==='character')return'party';if(token.kind==='npc'){const kind=(app.campaign?.npcs||[]).find(item=>item.id===token.refId)?.kind;if(kind==='enemy')return'enemy';if(kind==='ally')return'party';}return'neutral';}
  function v082Hostile(a,b){const x=v082Faction(a),y=v082Faction(b);return(x==='party'&&y==='enemy')||(x==='enemy'&&y==='party');}
  function v082DistanceFeet(a,b){const scene=app.scene;if(!scene||!a||!b)return Infinity;return Math.hypot(Number(a.x||0)-Number(b.x||0),Number(a.y||0)-Number(b.y||0))/Math.max(1,Number(scene.grid?.size||70))*Number(scene.grid?.feet||5);}
  function v082Engaged(token){return Boolean(token&&(app.scene?.tokens||[]).some(other=>other.id!==token.id&&['character','npc'].includes(other.kind)&&!other.defeated&&v082Hostile(token,other)&&v082DistanceFeet(token,other)<=10.01));}
  function v082RangedWeapon(weapon){return Boolean(weapon&&!weapon.melee&&weapon.type!=='Оружие ближнего боя'&&weapon.id!=='unarmed'&&Number(weapon.range||0)>0&&Number(weapon.radius||0)<=0);}
  const v082BaseRefreshAttackWeapons=refreshAttackWeapons;
  refreshAttackWeapons=function(){v082BaseRefreshAttackWeapons();const token=tokenById($('attack-attacker').value),select=$('attack-weapon');[...select.options].forEach(option=>{const weapon=clientWeapons(token).find(item=>(item.id||item.slot||item.name)===option.value);if(weapon&&!v082RangedWeapon(weapon))option.remove();});if(v082Engaged(token)){select.innerHTML='<option value="">Стрельба недоступна: ближний бой</option>';select.disabled=true;$('attack-roll-btn').disabled=true;}else{select.disabled=false;$('attack-roll-btn').disabled=false;}refreshAttackPreview();};
  const v082BaseShowQuickAttackPicker=showQuickAttackPicker;
  showQuickAttackPicker=function(target){return v082BaseShowQuickAttackPicker(target);};
  const v082BasePerformAttack=performAttack;
  performAttack=async function(...args){const attacker=tokenById($('attack-attacker').value);if(v082Engaged(attacker)){toast('Нельзя стрелять, пока персонаж связан ближним боем.','error');return;}return v082BasePerformAttack(...args);};
  const v082BaseRefreshActionDock=refreshActionDock;
  refreshActionDock=function(){v082BaseRefreshActionDock();const token=selectedToken();if(!token||!v082Engaged(token))return;const dock=$('action-dock');dock?.querySelectorAll('[data-dock-action^="ranged:"],[data-dock-action^="aimed:"],[data-dock-action^="zone-"]').forEach(button=>{button.disabled=true;button.title='Недоступно, пока токен связан ближним боем';});const line=$('action-resource-line');if(line&&!line.textContent.includes('Связан боем'))line.textContent+=' · Связан боем';};
  const v082BaseUpdateToken=updateToken;
  updateToken=async function(tokenId,patch,options={}){const result=await v082BaseUpdateToken(tokenId,patch,options);if(result?.reactions?.length){for(const reaction of result.reactions){if(reaction.type==='opportunity')toast(`${reaction.attackerName}: свободная атака по ${reaction.targetName}.`,reaction.attack?.hit?'error':'success');else if(reaction.type==='zone-fire')toast(`${reaction.attackerName}: выстрел из Зоны обстрела по ${reaction.targetName}.`,reaction.attack?.hit||reaction.attack?.missRedirectTargetName?'error':'success');if(reaction.damageResult)renderAutoDamageResult?.(reaction.damageResult,reaction.attack?.damageTargetName||reaction.targetName);}}return result;};


  /* ===== FATUM Battlemap v0.8.3: full melee UI, projectile visuals and elevation ===== */
  function v083IsMeleeWeapon(weapon){return Boolean(weapon&&(weapon.melee||weapon.type==='Оружие ближнего боя'||weapon.id==='unarmed'||/ближнего|безоруж/i.test(`${weapon.profile||''} ${weapon.name||''} ${weapon.description||''}`)));}
  function v083WeaponKind(weapon){const text=`${weapon?.profile||''} ${weapon?.name||''} ${weapon?.description||''}`;if(/дробовик/i.test(text))return'shotgun';if(/анаксион/i.test(text))return'anaxion';if(/гранатом[её]т|радиус/i.test(text))return'launcher';return'bullet';}
  function v083WeaponSummary(weapon){const bonus=Number(weapon.hitBonus||0);return `${weapon.hitDieNormal||'1d4'} ${bonus>=0?'+':''}${bonus} · урон ${Number(weapon.damage||0)} · ${Number(weapon.odCost??2)} ОД`;}

  showQuickAttackPicker=function(target){
    const attacker=tokenById($('attack-attacker').value);if(!attacker||!target||attacker.id===target.id)return;
    let weapons=allClientWeapons(attacker);const engaged=v082Engaged(attacker);if(engaged)weapons=weapons.filter(v083IsMeleeWeapon);
    if(!weapons.length){toast(engaged?'Нет доступного оружия ближнего боя.':'У токена не найдено оружие. Сохраните лист персонажа.','error');return;}
    app.quickAttack={attackerId:attacker.id,targetId:target.id};$('attack-target').value=target.id;refreshAttackPreview();
    const p=worldToScreen(visualTokenState(target)),box=$('quick-attack');$('quick-attack-title').textContent=`${attacker.name} → ${target.name}`;
    $('quick-weapon-list').innerHTML=weapons.map(w=>{const wid=esc(w.id||w.slot||w.name),melee=v083IsMeleeWeapon(w),desc=String(w.description||'');if(melee){let extra='';if(/Мощный удар/i.test(desc))extra+=`<button class="bm-btn" data-quick-melee="${wid}" data-special="power">Мощный</button>`;if(/Оглуш/i.test(desc))extra+=`<button class="bm-btn" data-quick-melee="${wid}" data-special="stun">Оглушить</button>`;if(/Шок/i.test(desc))extra+=`<button class="bm-btn" data-quick-melee="${wid}" data-special="shock">Шок</button>`;return `<div class="bm-quick-weapon"><div><strong>${esc(w.name)}</strong><small>${esc(v083WeaponSummary(w))}</small></div><button class="bm-btn bm-primary" data-quick-melee="${wid}">Удар</button>${extra||'<span></span>'}</div>`;}return `<div class="bm-quick-weapon"><div><strong>${esc(w.name)}</strong><small>${esc(v083WeaponSummary(w))}</small></div><button class="bm-btn bm-primary" data-quick-weapon="${wid}" data-shot="normal">Огонь</button>${w.hitDieAimed?`<button class="bm-btn" data-quick-weapon="${wid}" data-shot="aimed">Прицел</button>`:'<span></span>'}</div>`;}).join('');
    box.hidden=false;box.style.left=`${clamp(p.x+18,10,app.dimensions.width-390)}px`;box.style.top=`${clamp(p.y+18,10,app.dimensions.height-290)}px`;
  };

  async function v083QuickMelee(weaponId,specialMode=null){
    const attacker=tokenById(app.quickAttack?.attackerId),target=tokenById(app.quickAttack?.targetId);if(!attacker||!target||app.attackPending)return;
    app.attackPending=true;[...$('quick-weapon-list').querySelectorAll('button')].forEach(button=>button.disabled=true);
    try{const result=await api('/api/battlemap/melee',{method:'POST',body:commonBody({requestId:id(),sceneId:app.scene.id,attackerTokenId:attacker.id,targetTokenId:target.id,weaponId,specialMode,spendResources:combatActive(),autoApplyDamage:true,visibility:'public'})});if(result.roll)startRollVisual(result.roll);showMeleeResult(result.attack,true);renderAutoDamageResult(result.damageResult);if(result.shockResult){toast(result.shockResult.success?'Цель выдержала Шок.':'Шок: цель потеряет 1 ОД в следующий ход.',result.shockResult.success?'success':'error');}await fetchAll(true);}catch(error){toast(error.message,'error');}finally{app.attackPending=false;$('quick-attack').hidden=true;app.quickAttack=null;setTool('select');}
  }

  const v083BaseRefreshActionDock=refreshActionDock;
  refreshActionDock=function(){v083BaseRefreshActionDock();const box=$('action-slots');if(!box)return;const token=selectedToken(),weapons=allClientWeapons(token);for(const weapon of weapons){if(!v083IsMeleeWeapon(weapon)||!/Шок/i.test(String(weapon.description||'')))continue;const wid=weapon.id||weapon.slot||weapon.name;if(box.querySelector(`[data-dock-action="melee-shock:${CSS.escape(String(wid))}"]`))continue;box.insertAdjacentHTML('beforeend',actionButtonHtml(`melee-shock:${wid}`,'ϟ','Шок',weapon.odCost??2,`Вместо урона: Стойкость против результата атаки; провал — −1 ОД в следующий ход.`,'weapon'));}
    box.querySelectorAll('[data-dock-action^="melee-shock:"]').forEach(button=>{if(combatActive()&&!combatCanAct(token))button.disabled=true;button.onmouseenter=()=>setActionDescription(button.title);button.onmouseleave=()=>setActionDescription(app.actionTarget?'Выберите токен цели.':'Выберите действие.');});
  };

  const v083BaseShowMeleeResult=showMeleeResult;
  showMeleeResult=function(attack,own){v083BaseShowMeleeResult(attack,own);if(!attack)return;const shock=attack.flags?.shock;if(shock){const note=document.createElement('p');note.className='bm-muted';note.textContent='Шок применяется вместо урона: цель проходит Стойкость против результата атаки.';$('attack-result').appendChild(note);$('attack-damage-actions').innerHTML='';}}

  function v083StartProjectile(payload){if(!payload||payload.sceneId!==app.scene?.id)return;const key=String(payload.id||`${payload.at||Date.now()}_${payload.kind}_${payload.from?.x}_${payload.to?.x}`);if(app.seenProjectileIds.has(key))return;app.seenProjectileIds.add(key);if(app.seenProjectileIds.size>500)app.seenProjectileIds.delete(app.seenProjectileIds.values().next().value);app.projectileAnimations.set(key,{...payload,id:key,startedAt:performance.now(),durationMs:Math.max(120,Number(payload.durationMs||420))});requestRender();}
  function v083ProjectilePoint(item,t){const from=item.from||{},to=item.to||{},x=Number(from.x||0)+(Number(to.x||0)-Number(from.x||0))*t,y=Number(from.y||0)+(Number(to.y||0)-Number(from.y||0))*t;const arc=['grenade','launcher'].includes(item.kind)?Math.sin(Math.PI*t)*Math.min(130,35+Math.hypot(Number(to.x||0)-Number(from.x||0),Number(to.y||0)-Number(from.y||0))*.12):0;return{x,y:y-arc/app.view.scale};}
  function v083DrawExplosion(target,item,age){const to=item.to||{},start=item.durationMs,phase=clamp((age-start)/520,0,1);if(age<start||phase>=1)return;const radius=Math.max(18,feetToPixels(Number(item.radius||10))*.55),r=radius*(.18+.82*phase),soft=item.explosive===false||['smoke','gas','tear-gas'].includes(item.effectType),stroke=soft?(item.effectType==='gas'?'115,205,132':item.effectType==='tear-gas'?'220,215,156':'188,198,207'):'255,178,72',fill=soft?(item.effectType==='gas'?'74,140,84':'132,142,150'):'255,92,36';target.save();target.globalCompositeOperation=soft?'source-over':'lighter';target.beginPath();target.arc(Number(to.x||0),Number(to.y||0),r,0,Math.PI*2);target.strokeStyle=`rgba(${stroke},${soft ? .72 : 1-phase})`;target.lineWidth=(8*(1-phase)+2)/app.view.scale;target.stroke();target.beginPath();target.arc(Number(to.x||0),Number(to.y||0),r*.55,0,Math.PI*2);target.fillStyle=`rgba(${fill},${soft ? .22 : .38*(1-phase)})`;target.fill();if(!soft)for(let i=0;i<10;i++){const a=i/10*Math.PI*2+Number(item.id.length||0),d=r*(.35+.6*((i*37)%10)/10);target.beginPath();target.arc(Number(to.x||0)+Math.cos(a)*d,Number(to.y||0)+Math.sin(a)*d,Math.max(1,4*(1-phase))/app.view.scale,0,Math.PI*2);target.fillStyle=`rgba(255,221,128,${1-phase})`;target.fill();}target.restore();}
  function v083DrawImpact(target,item,age){if(['grenade','launcher'].includes(item.kind)||age<item.durationMs)return;const phase=clamp((age-item.durationMs)/260,0,1);if(phase>=1)return;const p=item.to||{},radius=(5+phase*13)/app.view.scale;target.save();target.globalCompositeOperation='lighter';for(let i=0;i<6;i++){const a=i/6*Math.PI*2+(String(item.id).length*.37),length=radius*(.55+((i*19)%5)/5);target.beginPath();target.moveTo(Number(p.x||0)+Math.cos(a)*radius*.15,Number(p.y||0)+Math.sin(a)*radius*.15);target.lineTo(Number(p.x||0)+Math.cos(a)*length,Number(p.y||0)+Math.sin(a)*length);target.strokeStyle=item.kind==='anaxion'?`rgba(190,135,255,${1-phase})`:`rgba(255,225,154,${1-phase})`;target.lineWidth=(2.5*(1-phase)+.5)/app.view.scale;target.stroke();}target.restore();}
  function v083DrawProjectiles(target){const now=performance.now();for(const [key,item] of app.projectileAnimations){const age=now-item.startedAt,duration=item.durationMs,t=clamp(age/duration,0,1);if(age>duration+620){app.projectileAnimations.delete(key);continue;}if(t<1){const p=v083ProjectilePoint(item,t),prev=v083ProjectilePoint(item,Math.max(0,t-.12));target.save();target.globalCompositeOperation='lighter';if(item.kind==='shotgun'){const from=item.from||{},to=item.to||{},dx=Number(to.x||0)-Number(from.x||0),dy=Number(to.y||0)-Number(from.y||0),len=Math.max(1,Math.hypot(dx,dy)),nx=-dy/len,ny=dx/len;for(let i=-4;i<=4;i++){const pellet=i/4,curve=pellet*len*.42,spreadNow=curve*t,spreadPrev=curve*Math.max(0,t-.12),jitter=Math.sin((String(item.id).length+i*17)*1.37)*len*.012;target.beginPath();target.moveTo(prev.x+nx*(spreadPrev+jitter*Math.max(0,t-.12)),prev.y+ny*(spreadPrev+jitter*Math.max(0,t-.12)));target.lineTo(p.x+nx*(spreadNow+jitter*t),p.y+ny*(spreadNow+jitter*t));target.strokeStyle=`rgba(255,220,150,${.64+(.35*Math.abs(pellet))})`;target.lineWidth=(1.1+(1-Math.abs(pellet))*.9)/app.view.scale;target.stroke();}}else{target.beginPath();target.moveTo(prev.x,prev.y);target.lineTo(p.x,p.y);target.strokeStyle=item.kind==='anaxion'?'rgba(170,112,255,.95)':item.kind==='grenade'||item.kind==='launcher'?'rgba(255,174,74,.78)':'rgba(255,235,178,.95)';target.lineWidth=(item.kind==='anaxion'?5:item.kind==='grenade'||item.kind==='launcher'?3:2.4)/app.view.scale;target.stroke();target.beginPath();target.arc(p.x,p.y,(item.kind==='grenade'||item.kind==='launcher'?5:3.2)/app.view.scale,0,Math.PI*2);target.fillStyle=item.kind==='anaxion'?'#d5b6ff':item.kind==='grenade'||item.kind==='launcher'?'#3a3027':'#fff2bd';target.fill();}target.restore();}if(['grenade','launcher'].includes(item.kind))v083DrawExplosion(target,item,age);else v083DrawImpact(target,item,age);requestRender();}}
  const v083BaseRender=render;
  render=function(){v083BaseRender();if(!app.scene||!app.projectileAnimations.size)return;ctx.setTransform(app.dimensions.dpr,0,0,app.dimensions.dpr,0,0);ctx.save();ctx.translate(app.view.x,app.view.y);ctx.scale(app.view.scale,app.view.scale);v083DrawProjectiles(ctx);ctx.restore();};

  const v083BaseDrawToken=drawToken;
  drawToken=function(target,token){v083BaseDrawToken(target,token);};

  const v083BaseConnectEvents=connectEvents;
  connectEvents=function(){v083BaseConnectEvents();app.eventSource?.addEventListener('battlemap-projectile',event=>{try{v083StartProjectile(JSON.parse(event.data));}catch(error){console.warn(error);}});};

  const v083BaseRefreshSceneForm=refreshSceneForm;
  refreshSceneForm=function(){v083BaseRefreshSceneForm();if($('elevation-rules-enabled')&&app.scene)$('elevation-rules-enabled').checked=app.scene.settings?.elevationRulesEnabled!==false;};
  const v083BaseRefreshInspector=refreshInspector;
  refreshInspector=function(){v083BaseRefreshInspector();const token=selectedToken();if(token&&$('token-elevation'))$('token-elevation').value=Number(token.elevation||0);const cover=app.selected?.type==='cover'?coverById(app.selected.id):null;if(cover){$('cover-elevation').value=Number(cover.elevation||0);$('cover-vertical-height').value=Number(cover.verticalHeight||5);}};

  function bindV083Ui(){
    $('quick-weapon-list').addEventListener('click',event=>{const button=event.target.closest('[data-quick-melee]');if(!button)return;event.preventDefault();event.stopImmediatePropagation();v083QuickMelee(button.dataset.quickMelee,button.dataset.special||null);},true);
    $('action-slots').addEventListener('click',event=>{const button=event.target.closest('[data-dock-action^="melee-shock:"]');if(!button||button.disabled)return;event.preventDefault();event.stopImmediatePropagation();beginDockTarget('melee',button.dataset.dockAction.slice('melee-shock:'.length),'normal','shock');},true);
    $('elevation-rules-enabled')?.addEventListener('change',()=>{if(app.scene)app.scene.settings.elevationRulesEnabled=$('elevation-rules-enabled').checked;v070SaveDaylight().catch(error=>toast(error.message,'error'));});
    $('token-elevation')?.addEventListener('input',()=>{const token=selectedToken();if(!token)return;token.elevation=Number($('token-elevation').value||0);requestRender();scheduleLive('token-elevation',()=>updateToken(token,{elevation:token.elevation}));});
    const saveCoverElevation=()=>{const cover=app.selected?.type==='cover'?coverById(app.selected.id):null;if(!cover)return;cover.elevation=Number($('cover-elevation').value||0);cover.verticalHeight=Number($('cover-vertical-height').value||5);requestRender();scheduleLive('cover-elevation',saveCovers);};
    $('cover-elevation')?.addEventListener('input',saveCoverElevation);$('cover-vertical-height')?.addEventListener('input',saveCoverElevation);
    const syncNewCoverHeight=()=>{const coverage=$('new-cover-coverage')?.value;if(document.activeElement!==$('new-cover-vertical-height'))$('new-cover-vertical-height').value=coverage==='quarter'?3:coverage==='full'?8:5;};$('new-cover-coverage')?.addEventListener('change',syncNewCoverHeight);
  }


  /* ===== FATUM Battlemap v0.8.5: NPC melee, simple height zones, aberrations, loop audio, pause and trigger zones ===== */
  const V084_SKILLS = ['Физическая сила','Взлом','Акробатика','Скрытность','Выдержка','Стойкость','Иммунитет','Бдительность','Воля','Меткость','Выживание','Анализ','Эрудиция','Память','Медицина','Механика','Убеждение','Обман','Интуиция','Запугивание','Очарование'];
  const V084_GIFT_ICONS = {'Сверхинтеллект':'⌘','Телекинез':'✥','Краткосрочная невидимость':'◌','Предвидение':'◉','Манипуляция сознанием':'◇','Гипноз':'◐','Невероятная сила':'✦','Невероятная ловкость':'»','Парение':'△'};
  const V084_GIFT_HELP = {
    'Сверхинтеллект':'Логический вывод, план с бонусом или запрос отката последнего действия.',
    'Телекинез':'Атака, сбивание, разоружение, отбрасывание, импульс по зоне или блокирование выстрела.',
    'Краткосрочная невидимость':'Скрывает персонажа от дальнобойных атак на срок, зависящий от ранга.',
    'Предвидение':'Готовность, обязательный переброс, отмена попадания или вопрос о ближайших последствиях.',
    'Манипуляция сознанием':'Определение мотива, простой импульс или краткое подавление решения цели.',
    'Гипноз':'Честный ответ, фиксация внимания или внушённый приказ.',
    'Невероятная сила':'Усиливает следующую атаку ближнего боя, отбрасывает или поражает область.',
    'Невероятная ловкость':'Безопасное перемещение, МЗ, уклонение и дополнительное быстрое действие.',
    'Парение':'Подъём, полёт или воздушный рывок.'
  };
  app.v084HeightZoneId = null;
  app.v084TriggerZoneId = null;
  app.v084ZoneDraft = null;
  app.v084LoopPlayers = new Map();
  app.v084LoopSyncAt = 0;
  app.v084Aberration = null;

  function v084Paused(){return Boolean(app.battlemap?.masterPause?.active);}
  function v084PauseReason(){return String(app.battlemap?.masterPause?.reason||'Действия игроков временно остановлены.');}
  function v084RefreshPauseUi(){
    const active=v084Paused(),banner=$('master-pause-banner'),button=$('master-pause-btn');
    document.body.classList.toggle('bm-master-paused',active);
    if(banner){banner.hidden=!active;$('master-pause-reason').textContent=v084PauseReason();}
    if(button){button.classList.toggle('active',active);button.textContent=active?'▶ Снять паузу':'⏸ Пауза';button.title=active?'Разрешить действия игроков':'Остановить движения и действия игроков';}
  }
  async function v084TogglePause(){
    if(!master)return;const active=!v084Paused();let reason='';
    if(active)reason=prompt('Причина паузы (необязательно):','Мастер уточняет ситуацию')||'';
    try{const payload=await api('/api/battlemap/pause',{method:'PUT',body:commonBody({active,reason})});app.battlemap.masterPause=payload.masterPause;v084RefreshPauseUi();refreshActionDock();toast(active?'Игра поставлена на мастерскую паузу.':'Мастерская пауза снята.','success');}
    catch(error){toast(error.message,'error');}
  }

  const v084BaseApi=api;
  api=async function(url,options={}){
    const method=String(options.method||'GET').toUpperCase();
    if(!master&&v084Paused()&&!['GET','HEAD'].includes(method)&&String(url).startsWith('/api/battlemap')&&!String(url).startsWith('/api/battlemap/chat'))throw new Error('Игра поставлена на мастерскую паузу. Действия игроков временно заблокированы.');
    return v084BaseApi(url,options);
  };
  const v084BaseCanControlToken=canControlToken;
  canControlToken=function(token){if(!master&&v084Paused())return false;return v084BaseCanControlToken(token);};

  function v084InferNpcMelee(item,index=0){
    if(!item||typeof item!=='object')return null;const text=`${item.type||''} ${item.profile||''} ${item.name||''} ${item.desc||item.description||''}`;
    if(!/Оружие ближнего боя|ближн|рукопаш|нож|клинок|меч|топор|дубин|молот|копь|шты|кастет/i.test(text))return null;
    const normalized=String(item.desc||item.description||'').replace(/к/g,'d'),die=normalized.match(/(?:Попадание[:\s]*)?(1d(?:4|6|8|10|12))/i)?.[1]||item.hitDieNormal||item.hitDie||'1d6';
    return{id:String(item.uid||item.id||item.slot||item.name||`npc-melee-${index}`),slot:item.slot||null,name:item.customModel||item.selectedModel||item.name||item.profile||'Оружие ближнего боя',profile:item.profile||item.name||'Оружие ближнего боя',type:'Оружие ближнего боя',melee:true,hitDieNormal:die,hitDieAimed:'',hitBonus:Number(item.hitBonus||item.manualBonus||0),damage:Number(normalized.match(/урон\s*(\d+)/i)?.[1]||item.damage||2),damageTag:item.damageTag||'medium',odCost:Number(normalized.match(/(\d+)\s*ОД/i)?.[1]||item.odCost||2),obCost:0,range:Number(item.range||5),radius:0,description:item.desc||item.description||''};
  }
  const v084BaseClientWeapons=clientWeapons;
  clientWeapons=function(token){
    const resolved=v084BaseClientWeapons(token)||[];if(token?.kind!=='npc'||resolved.some(v083IsMeleeWeapon))return resolved;
    const npc=npcById(token.refId)||{},inventory=Array.isArray(npc.inventory)?npc.inventory:[],equipment=npc.equipment||{};
    const equipped=['weapon1','weapon2'].map(slot=>{const key=equipment[slot];const found=inventory.find(item=>String(item?.uid||item?.id||item?.name||'')===String(key||''));return found?{...found,slot}:null;}).filter(Boolean);
    const source=equipped.length?equipped:inventory;const melee=source.map(v084InferNpcMelee).filter(Boolean);
    return melee.length?[...resolved,...melee]:resolved;
  };

  function v084HeightZones(){if(!app.scene)return[];app.scene.elevationZones=Array.isArray(app.scene.elevationZones)?app.scene.elevationZones:[];return app.scene.elevationZones;}
  function v084TriggerZones(){if(!app.scene)return[];app.scene.triggerZones=Array.isArray(app.scene.triggerZones)?app.scene.triggerZones:[];return app.scene.triggerZones;}
  function v084HeightZone(){return v084HeightZones().find(zone=>zone.id===app.v084HeightZoneId)||null;}
  function v084TriggerZone(){return v084TriggerZones().find(zone=>zone.id===app.v084TriggerZoneId)||null;}
  function v084RectFromPoints(start,current){return{x:Math.min(start.x,current.x),y:Math.min(start.y,current.y),width:Math.max(5,Math.abs(current.x-start.x)),height:Math.max(5,Math.abs(current.y-start.y))};}
  function v084NewHeightFields(){const level=$('height-zone-level').value;return{name:$('height-zone-name').value.trim()||(level==='very-high'?'Очень высоко':'Высоко'),level,color:$('height-zone-color').value,opacity:Number($('height-zone-opacity').value),showToPlayers:$('height-zone-show').checked};}
  function v101TriggerCombatTokenIds(){return[...document.querySelectorAll('#trigger-zone-combat-participants input[type="checkbox"]:checked')].map(input=>input.value);}
  function v101TriggerEffectLabel(type){return({none:'Без эффекта',wound:'Ранение','morale-loss':'Потеря морали','morale-gain':'Восстановление морали',heal:'Лечение',trauma:'Травма','start-combat':'Начало боя'})[type]||type;}
  function v101RefreshTriggerCombatUi(zone=null){
    const effect=$('trigger-zone-effect')?.value,card=$('trigger-zone-combat-card'),list=$('trigger-zone-combat-participants'),when=$('trigger-zone-when');if(!card||!list)return;
    const active=effect==='start-combat';card.hidden=!active;if(when){if(active)when.value='always';when.disabled=active;}
    if(!active)return;
    const current=new Set(zone?zone.combatTokenIds||[]:v101TriggerCombatTokenIds());
    const tokens=(app.scene?.tokens||[]).filter(token=>['character','npc'].includes(token.kind));
    list.innerHTML=tokens.length?tokens.map(token=>`<label class="bm-check"><input type="checkbox" value="${esc(token.id)}" ${current.has(token.id)?'checked':''}> ${esc(token.name)} <small>${token.kind==='npc'?'NPC':'персонаж'}</small></label>`).join(''):'<p class="bm-muted">На сцене нет персонажей или NPC.</p>';
  }
  function v084NewTriggerFields(){const effectType=$('trigger-zone-effect').value;return{name:$('trigger-zone-name').value.trim()||'Зона проверки',skillName:$('trigger-zone-skill').value,difficultySides:Number($('trigger-zone-die').value),difficultyModifier:Number($('trigger-zone-mod').value||0),effectType,applyWhen:effectType==='start-combat'?'always':$('trigger-zone-when').value,effectValue:Number($('trigger-zone-value').value||0),woundType:$('trigger-zone-wound').value,traumaText:$('trigger-zone-trauma').value.trim()||'Травма зоны',combatTokenIds:effectType==='start-combat'?v101TriggerCombatTokenIds():[],pauseOnTrigger:$('trigger-zone-pause').checked,oneShot:$('trigger-zone-one-shot')?.checked===true,showToPlayers:$('trigger-zone-show').checked,color:$('trigger-zone-color').value,opacity:.16};}
  async function v084SaveHeightZones({quiet=false}={}){if(!master||!app.scene)return;const payload=await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/elevation-zones`,{method:'PUT',body:commonBody({zones:v084HeightZones()})});app.scene.elevationZones=payload.zones||[];v084RefreshZoneUi();requestRender();if(!quiet)toast('Зоны высоты сохранены.','success');}
  async function v084SaveTriggerZones({quiet=false}={}){if(!master||!app.scene)return;const payload=await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/trigger-zones`,{method:'PUT',body:commonBody({zones:v084TriggerZones()})});app.scene.triggerZones=payload.zones||[];v084RefreshZoneUi();requestRender();if(!quiet)toast('Зоны проверок сохранены.','success');}
  function v084RefreshZoneUi(){
    if(!master||!app.scene)return;const heights=v084HeightZones(),triggers=v084TriggerZones();
    if(app.v084HeightZoneId&&!heights.some(z=>z.id===app.v084HeightZoneId))app.v084HeightZoneId=null;if(app.v084TriggerZoneId&&!triggers.some(z=>z.id===app.v084TriggerZoneId))app.v084TriggerZoneId=null;
    $('height-zone-list').innerHTML=heights.length?heights.map(z=>`<button class="bm-zone-item ${z.id===app.v084HeightZoneId?'active':''}" data-height-zone-id="${esc(z.id)}"><span><i class="bm-zone-chip" style="background:${esc(z.color)}"></i>${esc(z.name)}<small>${z.level==='very-high'?'Очень высоко · игнорирует внешние укрытия':'Высоко · преимущество на стрельбу'}</small></span><b>${Math.round(z.width)}×${Math.round(z.height)}</b></button>`).join(''):'<p class="bm-muted">Зон высоты нет.</p>';
    $('trigger-zone-list').innerHTML=triggers.length?triggers.map(z=>`<button class="bm-zone-item ${z.id===app.v084TriggerZoneId?'active':''}" data-trigger-zone-id="${esc(z.id)}"><span><i class="bm-zone-chip" style="background:${esc(z.color)}"></i>${esc(z.name)}<small>${esc(z.skillName)} против 1к${z.difficultySides}${z.difficultyModifier?`${z.difficultyModifier>0?'+':''}${z.difficultyModifier}`:''} · ${esc(v101TriggerEffectLabel(z.effectType))}</small></span><b>${z.pauseOnTrigger?'⏸':''}</b></button>`).join(''):'<p class="bm-muted">Зон проверок нет.</p>';
    const hz=v084HeightZone();if(hz){$('height-zone-level').value=hz.level;$('height-zone-name').value=hz.name;$('height-zone-color').value=hz.color;$('height-zone-opacity').value=hz.opacity;$('height-zone-show').checked=hz.showToPlayers!==false;}
    const tz=v084TriggerZone();if(tz){$('trigger-zone-name').value=tz.name;$('trigger-zone-skill').value=tz.skillName;$('trigger-zone-die').value=String(tz.difficultySides);$('trigger-zone-mod').value=tz.difficultyModifier;$('trigger-zone-when').value=tz.applyWhen;$('trigger-zone-effect').value=tz.effectType;$('trigger-zone-value').value=tz.effectValue;$('trigger-zone-wound').value=tz.woundType;$('trigger-zone-trauma').value=tz.traumaText;$('trigger-zone-pause').checked=Boolean(tz.pauseOnTrigger);if($('trigger-zone-one-shot'))$('trigger-zone-one-shot').checked=Boolean(tz.oneShot);$('trigger-zone-show').checked=Boolean(tz.showToPlayers);$('trigger-zone-color').value=tz.color;}
    v101RefreshTriggerCombatUi(tz);
  }
  function v084DrawRectZone(target,zone,kind){
    const color=zone.color||(kind==='height'?'#62b8e8':'#d99754'),opacity=clamp(Number(zone.opacity||.16),.03,.65),selected=master&&((kind==='height'&&zone.id===app.v084HeightZoneId)||(kind==='trigger'&&zone.id===app.v084TriggerZoneId));
    target.save();target.fillStyle=hexToRgba(color,opacity);target.fillRect(zone.x,zone.y,zone.width,zone.height);target.strokeStyle=color;target.lineWidth=(selected?4:2)/app.view.scale;target.setLineDash(kind==='trigger'?[9/app.view.scale,6/app.view.scale]:[]);target.strokeRect(zone.x,zone.y,zone.width,zone.height);target.setLineDash([]);target.font=`700 ${11/app.view.scale}px Segoe UI`;target.textAlign='left';target.textBaseline='bottom';target.fillStyle=color;target.strokeStyle='rgba(5,8,12,.9)';target.lineWidth=3/app.view.scale;const label=kind==='height'?`${zone.level==='very-high'?'▲▲':'▲'} ${zone.name}`:`⚠ ${zone.name}`;target.strokeText(label,zone.x+6/app.view.scale,zone.y-4/app.view.scale);target.fillText(label,zone.x+6/app.view.scale,zone.y-4/app.view.scale);target.restore();
  }
  function v084DrawZones(){
    if(!app.scene)return;ctx.setTransform(app.dimensions.dpr,0,0,app.dimensions.dpr,0,0);ctx.save();ctx.translate(app.view.x,app.view.y);ctx.scale(app.view.scale,app.view.scale);
    if(app.scene.settings?.elevationRulesEnabled!==false)for(const zone of app.scene.elevationZones||[])v084DrawRectZone(ctx,zone,'height');for(const zone of app.scene.triggerZones||[])v084DrawRectZone(ctx,zone,'trigger');
    if(app.v084ZoneDraft){const rect=v084RectFromPoints(app.v084ZoneDraft.start,app.v084ZoneDraft.current),kind=app.v084ZoneDraft.kind,color=kind==='height'?$('height-zone-color').value:$('trigger-zone-color').value;v084DrawRectZone(ctx,{...rect,name:kind==='height'?'Новая зона высоты':'Новая зона проверки',level:$('height-zone-level').value,color,opacity:.2},kind);}
    ctx.restore();
  }

  function v084Hash(seed){let h=2166136261;for(const ch of String(seed)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619);}return(h>>>0)/4294967295;}
  function v084DrawZoneFire(){
    const effects=(app.scene?.effects||[]).filter(e=>['suppression','barrage'].includes(e.type)&&Number(e.remainingRounds||0)>0);if(!effects.length)return false;const now=performance.now(),bucket=Math.floor(now/110);
    ctx.setTransform(app.dimensions.dpr,0,0,app.dimensions.dpr,0,0);ctx.save();ctx.translate(app.view.x,app.view.y);ctx.scale(app.view.scale,app.view.scale);ctx.globalCompositeOperation='lighter';
    for(const effect of effects){const shooter=tokenById(effect.ownerTokenId),from=shooter?visualTokenState(shooter):{x:effect.x-feetToPixels(20),y:effect.y},radius=feetToPixels(Number(effect.radius||7.5)),count=effect.type==='barrage'?7:4;for(let i=0;i<count;i++){const seed=`${effect.id}:${bucket}:${i}`,angle=v084Hash(seed+'a')*Math.PI*2,dist=Math.sqrt(v084Hash(seed+'d'))*radius,to={x:effect.x+Math.cos(angle)*dist,y:effect.y+Math.sin(angle)*dist},phase=(v084Hash(seed+'p')+now/(effect.type==='barrage'?360:520))%1,head={x:from.x+(to.x-from.x)*phase,y:from.y+(to.y-from.y)*phase},tailPhase=Math.max(0,phase-.12),tail={x:from.x+(to.x-from.x)*tailPhase,y:from.y+(to.y-from.y)*tailPhase};ctx.beginPath();ctx.moveTo(tail.x,tail.y);ctx.lineTo(head.x,head.y);ctx.strokeStyle=effect.type==='barrage'?'rgba(255,145,92,.9)':'rgba(255,222,132,.75)';ctx.lineWidth=(effect.type==='barrage'?2.8:2)/app.view.scale;ctx.stroke();}ctx.beginPath();ctx.arc(effect.x,effect.y,radius,0,Math.PI*2);ctx.strokeStyle=effect.type==='barrage'?'rgba(255,90,55,.28)':'rgba(240,204,91,.22)';ctx.lineWidth=2/app.view.scale;ctx.stroke();}
    ctx.restore();requestRender();return true;
  }

  function v084AudioListener(){const token=app.possessedTokenId?tokenById(app.possessedTokenId):selectedToken();return token?{x:token.x,y:token.y}:screenToWorld({x:app.dimensions.width/2,y:app.dimensions.height/2});}
  function v084LoopSpec(){
    if(!app.scene||!app.battlemap?.audio)return[];const result=[],bindings=app.battlemap.audio.effectBindings||{};
    for(const layer of app.scene.weatherLayers||[]){if(layer.enabled===false||!layer.soundEnabled||!layer.soundTrackId)continue;result.push({key:`weather:${layer.id}`,trackId:layer.soundTrackId,kind:'weather',volume:Number(layer.soundVolume??.55)});}
    return result;
  }
  function v084StopLoop(key){const entry=app.v084LoopPlayers.get(key);if(!entry)return;entry.audio.pause();entry.audio.removeAttribute('src');entry.audio.load();app.v084LoopPlayers.delete(key);}
  function v084SyncLoopAudio({force=false}={}){
    const now=performance.now();if(!force&&now-app.v084LoopSyncAt<220)return;app.v084LoopSyncAt=now;const desired=new Set(),listener=v084AudioListener();
    for(const spec of v084LoopSpec()){const item=v061AudioItem(spec.trackId);if(!item)continue;desired.add(spec.key);let entry=app.v084LoopPlayers.get(spec.key);if(!entry||entry.trackId!==item.id){if(entry)v084StopLoop(spec.key);const audio=new Audio(item.url);audio.loop=true;audio.preload='metadata';entry={audio,trackId:item.id};app.v084LoopPlayers.set(spec.key,entry);}
      let volume;if(spec.kind==='weather')volume=Number(app.audioEngine.local.ambient??.7)*spec.volume;else{const distance=pixelsToFeet(Math.hypot(Number(spec.x)-listener.x,Number(spec.y)-listener.y)),fade=app.audioEngine.local.spatial===false?1:clamp(1-distance/260,.08,1);volume=Number(app.audioEngine.local.effects??.85)*spec.volume*fade;}entry.audio.volume=clamp(volume,0,1);if(app.audioEngine.unlocked&&entry.audio.paused&&entry.audio.volume>.002)entry.audio.play().catch(()=>{});}
    for(const key of [...app.v084LoopPlayers.keys()])if(!desired.has(key))v084StopLoop(key);
  }

  const v084BaseWeatherDefaults=weatherDefaults;
  weatherDefaults=function(type){return{...v084BaseWeatherDefaults(type),soundTrackId:null,soundVolume:.55,soundEnabled:false};};
  const v084BaseRefreshWeatherUi=refreshWeatherUi;
  refreshWeatherUi=function(){v084BaseRefreshWeatherUi();if(!master)return;const layer=weatherLayer(),select=$('weather-sound-track');if(select)select.innerHTML='<option value="">— без звука —</option>'+v087AudioOptions(null,layer?.soundTrackId||null);if(!layer)return;$('weather-sound-enabled').checked=Boolean(layer.soundEnabled);$('weather-sound-track').value=layer.soundTrackId||'';$('weather-sound-volume').value=Number(layer.soundVolume??.55);$('weather-sound-volume-value').textContent=`${Math.round(Number(layer.soundVolume??.55)*100)}%`;};
  const v084BaseReadWeatherEditor=readWeatherEditor;
  readWeatherEditor=function(){const layer=v084BaseReadWeatherEditor();if(!layer)return null;Object.assign(layer,{soundEnabled:$('weather-sound-enabled').checked,soundTrackId:$('weather-sound-track').value||null,soundVolume:Number($('weather-sound-volume').value)});return layer;};

  function v084AberrationState(token){return token?.aberrationRuntime||null;}
  function v084GiftRank(token,gift){const state=v084AberrationState(token);return Math.max(0,Math.min(3,Number(state?.ranks?.[gift]||1)));}
  function v084ModeOptions(gift,rank){
    if(gift==='Телекинез')return rank===3?[['area','Импульс по зоне'],['block','Заблокировать следующий выстрел']]:[['damage','Нанести урон'],['prone','Сбить с ног'],['push','Отбросить'],['disarm','Выбить предмет']];
    if(gift==='Предвидение')return rank===3?[['question','Задать вопрос мастеру'],['cancel-hit','Отменить следующее попадание']]:[['default','Активировать']];
    if(gift==='Манипуляция сознанием')return rank===1?[['default','Определить мотив']]:rank===2?[['command','Простой импульс']]:[['lose-turn','Лишить хода'],['command','Изменить действие']];
    if(gift==='Гипноз')return rank===1?[['default','Честный ответ']]:rank===2?[['lose-ap','Лишить 1 ОД'],['command','Безопасная команда']]:[['lose-turn','Лишить хода'],['command','Внушённый приказ']];
    if(gift==='Невероятная сила')return rank===3?[['damage','Дополнительный урон'],['push','Отбросить'],['area','Удар по зоне']]:[['damage','Дополнительный урон'],['push','Отбросить']];
    return[['default','Активировать']];
  }
  function v084RefreshAberrationDialog(){
    const choice=app.v084Aberration,token=tokenById(choice?.tokenId);if(!choice||!token)return;const state=v084AberrationState(token),gift=choice.gift,max=v084GiftRank(token,gift),rank=Math.min(max,Number($('aberration-rank').value||max)||1);$('aberration-title').textContent=gift;$('aberration-subtitle').textContent=`${token.name} · доступен ранг I–${['I','II','III'][max-1]}`;$('aberration-rank').innerHTML=[1,2,3].filter(v=>v<=max).map(v=>`<option value="${v}">${['I','II','III'][v-1]}</option>`).join('');$('aberration-rank').value=String(rank);const options=v084ModeOptions(gift,rank);$('aberration-mode').innerHTML=options.map(([value,label])=>`<option value="${value}">${label}</option>`).join('');if(choice.mode&&options.some(o=>o[0]===choice.mode))$('aberration-mode').value=choice.mode;choice.mode=$('aberration-mode').value;$('aberration-target').innerHTML='<option value="">— без цели / себя —</option>'+(app.scene?.tokens||[]).filter(t=>['character','npc'].includes(t.kind)).map(t=>`<option value="${esc(t.id)}">${esc(t.name)}</option>`).join('');$('aberration-target').value=choice.targetTokenId||'';$('aberration-help').textContent=V084_GIFT_HELP[gift]||'';$('aberration-status').innerHTML=`<span>Напряжение: ${Number(state?.tension||0)}</span><span>Ранг: ${['I','II','III'][max-1]}</span>${state?.runtime?.lockedUntilDay?'<span>ЗАБЛОКИРОВАН ДО КОНЦА ДНЯ</span>':''}`;const pointNeeded=gift==='Телекинез'&&rank===3&&$('aberration-mode').value==='area';$('aberration-use-point').hidden=!pointNeeded;$('aberration-use').hidden=pointNeeded;$('aberration-target-label').hidden=pointNeeded||['Краткосрочная невидимость','Невероятная ловкость','Парение'].includes(gift);$('aberration-text-label').hidden=!(['Сверхинтеллект','Предвидение','Манипуляция сознанием','Гипноз'].includes(gift));
  }
  function v084OpenAberration(gift){const token=selectedToken(),max=v084GiftRank(token,gift);if(!token||!max)return;app.v084Aberration={tokenId:token.id,gift,mode:null,targetTokenId:null};$('aberration-result').textContent='';$('aberration-rank').value=String(max);$('aberration-popover').hidden=false;v084RefreshAberrationDialog();}
  async function v084UseAberration(usePoint=false){
    const choice=app.v084Aberration,token=tokenById(choice?.tokenId);if(!choice||!token)return;const rank=Number($('aberration-rank').value),mode=$('aberration-mode').value,targetTokenId=$('aberration-target').value||null,text=$('aberration-text').value.trim(),point=usePoint?{...app.lastMouseWorld}:null;const button=$('aberration-use');button.disabled=true;
    try{const result=await api('/api/battlemap/aberration-action',{method:'POST',body:commonBody({sceneId:app.scene.id,tokenId:token.id,gift:choice.gift,rank,mode,targetTokenId,text,point})});if(result.result?.willRoll)startRollVisual(result.result.willRoll);const tension=result.result?.tension;$('aberration-result').textContent=`Дар применён. Напряжение: ${tension?.tension??token.aberrationRuntime?.tension??0}${tension?.breakdown?` · Срыв: ${tension.breakdown.roll} на 1к6`:''}.`;if(result.masterPause)app.battlemap.masterPause=result.masterPause;await refreshBattlemap();v084RefreshPauseUi();v084RefreshAberrationDialog();toast(`${choice.gift} применён.`,tension?.breakdown?'error':'success');}
    catch(error){$('aberration-result').textContent=error.message;toast(error.message,'error');}finally{button.disabled=false;}
  }
  const v084BaseRefreshActionDock=refreshActionDock;
  refreshActionDock=function(){v084BaseRefreshActionDock();const token=selectedToken(),slots=$('action-slots'),state=v084AberrationState(token);if(!token||!slots||$('action-dock').hidden||!state?.gifts?.length)return;for(const gift of state.gifts){const key=`aberration:${gift}`;if(slots.querySelector(`[data-dock-action="${CSS.escape(key)}"]`))continue;const rank=v084GiftRank(token,gift);slots.insertAdjacentHTML('beforeend',actionButtonHtml(key,V084_GIFT_ICONS[gift]||'✧',gift,null,`${V084_GIFT_HELP[gift]||''} · ранг ${['I','II','III'][rank-1]}`,'aberration'));}slots.querySelectorAll('[data-dock-action^="aberration:"]').forEach(button=>{button.disabled=!canControlToken(token);button.onmouseenter=()=>setActionDescription(button.title);button.onmouseleave=()=>setActionDescription('Выберите действие.');});const line=$('action-resource-line');if(line&&!line.textContent.includes('Напряжение'))line.textContent+=` · Напряжение ${Number(state.tension||0)}`;};

  function v084ShowForcedChecks(result){
    let combatStarted=false;
    for(const item of result?.forcedChecks||[]){if(item.roll)startRollVisual(item.roll);const outcome=item.check?.success?'успех':'провал',started=item.effect?.type==='start-combat'&&item.effect?.combat?.started,effect=item.effect?` · ${started?'бой начат':v101TriggerEffectLabel(item.effect.type)}`:'';toast(`${item.zoneName}: ${outcome}${effect}`,started||item.check?.success?'success':'error');if(started)combatStarted=true;}
    if(combatStarted)fetchAll(true).catch(error=>toast(error.message,'error'));
    if(result?.masterPause){app.battlemap.masterPause=result.masterPause;v084RefreshPauseUi();refreshActionDock();}
  }
  const v084BaseUpdateToken=updateToken;
  updateToken=async function(...args){const result=await v084BaseUpdateToken(...args);v084ShowForcedChecks(result);return result;};

  const v084BaseApplyBattlemap=applyBattlemap;
  applyBattlemap=function(battlemap,preserveSelection=true){v084BaseApplyBattlemap(battlemap,preserveSelection);v084RefreshPauseUi();queueMicrotask(()=>{v084RefreshZoneUi();v084SyncLoopAudio({force:true});});};
  const v084BaseRefreshAllUi=refreshAllUi;
  refreshAllUi=function(){v084BaseRefreshAllUi();v084RefreshPauseUi();v084RefreshZoneUi();v084SyncLoopAudio();};

  const v084BaseOnPointerDown=onPointerDown;
  onPointerDown=function(event){
    if(!master&&v084Paused()&&event.button===0&&!['pan','measure'].includes(app.tool)&&!app.spaceDown){toast('Мастер поставил игру на паузу.','error');event.preventDefault();return;}
    if(master&&event.button===0&&app.scene&&['height-zone','trigger-zone'].includes(app.tool)){const world=snapPoint(screenToWorld(eventPoint(event)));app.v084ZoneDraft={kind:app.tool==='height-zone'?'height':'trigger',start:world,current:world};canvas.setPointerCapture?.(event.pointerId);requestRender();event.preventDefault();return;}
    return v084BaseOnPointerDown(event);
  };
  const v084BaseOnPointerMove=onPointerMove;
  onPointerMove=function(event){if(app.v084ZoneDraft){app.v084ZoneDraft.current=snapPoint(screenToWorld(eventPoint(event)));app.lastMouseWorld=app.v084ZoneDraft.current;requestRender();return;}return v084BaseOnPointerMove(event);};
  const v084BaseOnPointerUp=onPointerUp;
  onPointerUp=async function(event){if(app.v084ZoneDraft){const draft=app.v084ZoneDraft;app.v084ZoneDraft=null;canvas.releasePointerCapture?.(event?.pointerId);const rect=v084RectFromPoints(draft.start,draft.current);if(rect.width<6||rect.height<6){requestRender();return;}try{if(draft.kind==='height'){const fields=v084NewHeightFields(),zone={id:`height_${id()}`,...rect,...fields};v084HeightZones().push(zone);app.v084HeightZoneId=zone.id;await v084SaveHeightZones({quiet:true});}else{const fields=v084NewTriggerFields(),zone={id:`trigger_${id()}`,...rect,...fields,insideTokenIds:[]};v084TriggerZones().push(zone);app.v084TriggerZoneId=zone.id;await v084SaveTriggerZones({quiet:true});}toast('Зона создана.','success');}catch(error){toast(error.message,'error');await refreshBattlemap();}return;}return v084BaseOnPointerUp(event);};

  const v084BaseDrawToken=drawToken;
  drawToken=function(target,token){v084BaseDrawToken(target,token);const state=v084AberrationState(token);if(!state)return;const runtime=state.runtime||{},labels=[];if(runtime.invisibleRounds||runtime.invisibleUntargetable)labels.push(['НЕВИДИМ','#b997ee']);if(runtime.hoverRounds)labels.push(['ПАРИТ','#8bd1ed']);if(!labels.length)return;const p=visualTokenState(token),r=tokenRadius(token);target.save();target.font=`700 ${8/app.view.scale}px Segoe UI`;target.textAlign='center';target.textBaseline='middle';labels.forEach(([label,color],index)=>{const y=p.y-r-(13+index*11)/app.view.scale,w=Math.max(31,label.length*5)/app.view.scale;target.fillStyle='rgba(12,9,18,.88)';target.fillRect(p.x-w/2,y-5/app.view.scale,w,10/app.view.scale);target.strokeStyle=color;target.lineWidth=1/app.view.scale;target.strokeRect(p.x-w/2,y-5/app.view.scale,w,10/app.view.scale);target.fillStyle=color;target.fillText(label,p.x,y);});target.restore();};

  const v084BaseRender=render;
  render=function(){v084BaseRender();if(!app.scene)return;v084DrawZones();v084DrawZoneFire();v084SyncLoopAudio();};

  function bindV084Ui(){
    $('master-pause-btn')?.addEventListener('click',v084TogglePause);
    $('height-zone-start').onclick=()=>setTool('height-zone');$('trigger-zone-start').onclick=()=>setTool('trigger-zone');
    $('height-zone-list').addEventListener('click',event=>{const button=event.target.closest('[data-height-zone-id]');if(!button)return;app.v084HeightZoneId=button.dataset.heightZoneId;v084RefreshZoneUi();requestRender();});
    $('trigger-zone-list').addEventListener('click',event=>{const button=event.target.closest('[data-trigger-zone-id]');if(!button)return;app.v084TriggerZoneId=button.dataset.triggerZoneId;v084RefreshZoneUi();requestRender();});
    $('height-zone-save').onclick=()=>{const zone=v084HeightZone();if(!zone)return toast('Выберите зону высоты.','error');Object.assign(zone,v084NewHeightFields());v084SaveHeightZones().catch(error=>toast(error.message,'error'));};
    $('height-zone-delete').onclick=()=>{const zone=v084HeightZone();if(!zone||!confirm(`Удалить зону «${zone.name}»?`))return;app.scene.elevationZones=v084HeightZones().filter(z=>z.id!==zone.id);app.v084HeightZoneId=null;v084SaveHeightZones({quiet:true}).catch(error=>toast(error.message,'error'));};
    $('trigger-zone-save').onclick=()=>{const zone=v084TriggerZone();if(!zone)return toast('Выберите зону проверки.','error');Object.assign(zone,v084NewTriggerFields());v084SaveTriggerZones().catch(error=>toast(error.message,'error'));};
    $('trigger-zone-delete').onclick=()=>{const zone=v084TriggerZone();if(!zone||!confirm(`Удалить зону «${zone.name}»?`))return;app.scene.triggerZones=v084TriggerZones().filter(z=>z.id!==zone.id);app.v084TriggerZoneId=null;v084SaveTriggerZones({quiet:true}).catch(error=>toast(error.message,'error'));};
    $('trigger-zone-skill').innerHTML=V084_SKILLS.map(skill=>`<option value="${esc(skill)}">${esc(skill)}</option>`).join('');$('trigger-zone-skill').value='Бдительность';$('trigger-zone-effect')?.addEventListener('change',()=>v101RefreshTriggerCombatUi(v084TriggerZone()));
    $('height-zone-level').addEventListener('change',()=>{$('height-zone-color').value=$('height-zone-level').value==='very-high'?'#b88cff':'#62b8e8';});
    for(const id of ['weather-sound-enabled','weather-sound-track','weather-sound-volume']){$(id)?.addEventListener('input',()=>{readWeatherEditor();$('weather-sound-volume-value').textContent=`${Math.round(Number($('weather-sound-volume').value)*100)}%`;scheduleLive('weather-sound',()=>saveWeatherLayers({quiet:true}),160);v084SyncLoopAudio({force:true});});$(id)?.addEventListener('change',()=>{readWeatherEditor();scheduleLive('weather-sound',()=>saveWeatherLayers({quiet:true}),80);v084SyncLoopAudio({force:true});});}
    $('audio-unlock-btn')?.addEventListener('click',()=>setTimeout(()=>v084SyncLoopAudio({force:true}),80));
    $('aberration-close').onclick=()=>{$('aberration-popover').hidden=true;app.v084Aberration=null;};$('aberration-rank').onchange=()=>{if(app.v084Aberration){app.v084Aberration.mode=null;v084RefreshAberrationDialog();}};$('aberration-mode').onchange=()=>{if(app.v084Aberration){app.v084Aberration.mode=$('aberration-mode').value;v084RefreshAberrationDialog();}};$('aberration-target').onchange=()=>{if(app.v084Aberration)app.v084Aberration.targetTokenId=$('aberration-target').value||null;};$('aberration-use').onclick=()=>v084UseAberration(false);$('aberration-use-point').onclick=()=>v084UseAberration(true);
    $('action-slots').addEventListener('click',event=>{const button=event.target.closest('[data-dock-action^="aberration:"]');if(!button||button.disabled)return;event.preventDefault();event.stopImmediatePropagation();v084OpenAberration(button.dataset.dockAction.slice('aberration:'.length));},true);
    window.addEventListener('keydown',event=>{if(event.key==='Escape'&&app.v084ZoneDraft){app.v084ZoneDraft=null;setTool('select');requestRender();}});
    v084RefreshPauseUi();v084RefreshZoneUi();refreshWeatherUi();
  }


  /* ===== FATUM Battlemap v0.8.5: heavy reload, cover destruction, fire-lane visibility ===== */
  function v085RangedWeapons(token){return allClientWeapons(token).filter(w=>!v083IsMeleeWeapon(w)&&Number(w.range||0)>0);}
  function v085HeavyWeapons(token){return v085RangedWeapons(token).filter(w=>w.heavy||w.type==='Тяжёлое'||/гранатом[её]т|тяж[её]лый пулем[её]т|анаксионный излучатель/i.test(`${w.name||''} ${w.profile||''} ${w.description||''}`));}
  function v085HitCover(point){const extra=10/app.view.scale;return[...(app.scene?.covers||[])].reverse().find(c=>{if(c.destroyed||c.hidden&&!master)return false;if(c.shape==='polyline'){const pts=c.points||[],radius=Math.max(1,Number(c.thickness||18))/2+extra;for(let i=1;i<pts.length;i++)if(pointSegmentDistance(point,pts[i-1],pts[i])<=radius)return true;return false;}return hitPointInCover(point,c);})||null;}
  function v085HitWall(point){const extra=10/app.view.scale;return[...(app.scene?.walls||[])].reverse().find(w=>{if(w.destroyed||Number(w.coverDurability||0)<=0)return false;return wallDrawSegments(w).some(seg=>pointSegmentDistance(point,seg.a,seg.b)<=Math.max(5,Number(w.thickness||4))/2+extra);})||null;}
  const v085BaseRefreshActionDock=refreshActionDock;
  refreshActionDock=function(){v085BaseRefreshActionDock();const token=selectedToken(),slots=$('action-slots');if(!token||!slots||$('action-dock').hidden)return;for(const weapon of v085HeavyWeapons(token)){const wid=String(weapon.id||weapon.slot||weapon.name);if(weapon.loaded===false&&!slots.querySelector(`[data-dock-action="heavy-reload:${CSS.escape(wid)}"]`))slots.insertAdjacentHTML('beforeend',actionButtonHtml(`heavy-reload:${wid}`,'↻',`Перезарядить: ${weapon.name}`,weapon.reloadCost??2,'Тяжёлое оружие после выстрела должно быть перезаряжено.','weapon'));}
    if(v085RangedWeapons(token).length&&!slots.querySelector('[data-dock-action="cover-attack"]'))slots.insertAdjacentHTML('beforeend',actionButtonHtml('cover-attack','▰','Атака по укрытию',null,'Выберите оружие, затем укажите укрытие на карте.','weapon'));
  };
  function v085ChooseCoverWeapon(token){const weapons=v085RangedWeapons(token);if(!weapons.length)return null;if(weapons.length===1)return weapons[0];const list=weapons.map((w,i)=>`${i+1} — ${w.name}${w.loaded===false?' (разряжено)':''}`).join('\n'),answer=prompt(`Выберите оружие для атаки по укрытию:\n${list}`,'1');if(answer===null)return null;return weapons[Number(answer)-1]||null;}
  async function v085Reload(weaponId){const token=selectedToken();if(!token)return;try{const result=await api('/api/battlemap/heavy-reload',{method:'POST',body:commonBody({sceneId:app.scene.id,tokenId:token.id,weaponId})});toast(`Оружие перезаряжено${result.cost?` за ${result.cost} ОД`:''}.`,'success');await fetchAll(true);}catch(error){toast(error.message,'error');}}
  async function v085AttackCover(kind,obj){const action=app.actionTarget,attacker=tokenById(action?.attackerId);if(!action||!attacker||!obj)return;try{const result=await api('/api/battlemap/cover-attack',{method:'POST',body:commonBody({sceneId:app.scene.id,attackerTokenId:attacker.id,weaponId:action.weaponId,coverKind:kind,coverId:obj.id,moved:Boolean(movementForToken(attacker)?.spent),spendResources:combatActive()})});if(result.attack)startRollVisual({id:result.attack.id,sceneId:app.scene.id,tokenId:attacker.id,label:result.attack.label,rolls:result.attack.rolls,total:result.attack.total,formula:result.attack.formula,battlemapAttack:result.attack});toast(result.coverResult?.destroyed?'Укрытие разрушено.':result.attack.hit?`Укрытию нанесено ${result.coverResult?.damage||0} повреждений.`:'Промах по укрытию.',result.attack.hit?'success':'error');await fetchAll(true);}catch(error){toast(error.message,'error');}finally{app.actionTarget=null;document.body.classList.remove('bm-targeting');setTool('select');}}
  function v085ZoneFireVisible(){const settings=app.scene?.settings||{};return master?settings.showZoneFireLinesMaster===true:settings.showZoneFireLinesPlayers===true;}
  function v085DrawFireLanes(){if(!v085ZoneFireVisible()||!combatActive()||!app.scene)return;const ids=new Set(app.battlemap?.combat?.participantTokenIds||[]),tokens=(app.scene.tokens||[]).filter(t=>ids.has(t.id)&&['character','npc'].includes(t.kind)&&!t.defeated);ctx.save();ctx.globalAlpha=.92;ctx.shadowColor='rgba(255,0,0,.9)';ctx.shadowBlur=7/app.view.scale;ctx.setLineDash([12/app.view.scale,6/app.view.scale]);ctx.lineWidth=2.6/app.view.scale;for(const shooter of tokens){const weapons=v085RangedWeapons(shooter).filter(w=>w.loaded!==false),derivedRange=Math.max(Number(shooter.zoneFireRange||0),...weapons.map(w=>Number(w.range||0)),0);if(derivedRange<=0)continue;for(const target of tokens){if(target.id===shooter.id||!v082Hostile(shooter,target))continue;if(pixelsToFeet(Math.hypot(target.x-shooter.x,target.y-shooter.y))>derivedRange)continue;const blocked=effectiveVisionSegments().some(seg=>clientSegmentIntersection(shooter,target,{x:seg.x1,y:seg.y1},{x:seg.x2,y:seg.y2}));if(blocked)continue;ctx.beginPath();ctx.moveTo(shooter.x,shooter.y);ctx.lineTo(target.x,target.y);ctx.strokeStyle='#ff1717';ctx.stroke();}}ctx.restore();}
  const v085BaseRender=render;render=function(){v085BaseRender();if(!app.scene)return;ctx.setTransform(app.dimensions.dpr,0,0,app.dimensions.dpr,0,0);ctx.save();ctx.translate(app.view.x,app.view.y);ctx.scale(app.view.scale,app.view.scale);v085DrawFireLanes();ctx.restore();};
  const v085BaseRefreshSceneForm=refreshSceneForm;refreshSceneForm=function(){v085BaseRefreshSceneForm();if(!app.scene)return;if($('zone-fire-lines-master'))$('zone-fire-lines-master').checked=app.scene.settings?.showZoneFireLinesMaster===true;if($('zone-fire-lines-players'))$('zone-fire-lines-players').checked=app.scene.settings?.showZoneFireLinesPlayers===true;};
  const v085BaseOnPointerDown=onPointerDown;onPointerDown=function(event){if(app.actionTarget?.type==='cover-attack'&&event.button===0&&app.scene){const world=screenToWorld(eventPoint(event)),cover=v085HitCover(world),wall=cover?null:v085HitWall(world);event.preventDefault();if(cover||wall){v085AttackCover(cover?'cover':'wall',cover||wall);return;}toast('Щёлкните по укрытию или стене с заданной Прочностью.','error');return;}return v085BaseOnPointerDown(event);};
  function bindV085Ui(){
    $('action-slots').addEventListener('click',event=>{const button=event.target.closest('[data-dock-action]');if(!button||button.disabled)return;const key=button.dataset.dockAction;if(key.startsWith('heavy-reload:')){event.preventDefault();event.stopImmediatePropagation();v085Reload(key.slice('heavy-reload:'.length));}else if(key==='cover-attack'){event.preventDefault();event.stopImmediatePropagation();const token=selectedToken(),weapon=v085ChooseCoverWeapon(token);if(!weapon)return;if(weapon.loaded===false)return toast('Выбранное тяжёлое оружие разряжено.','error');app.actionTarget={type:'cover-attack',attackerId:token.id,weaponId:weapon.id||weapon.slot||weapon.name};document.body.classList.add('bm-targeting');setTool('select');setActionDescription('Щёлкните по укрытию, которое нужно разрушить.');}},true);
    for(const eid of ['zone-fire-lines-master','zone-fire-lines-players'])$(eid)?.addEventListener('change',()=>{if(!app.scene)return;app.scene.settings[eid==='zone-fire-lines-master'?'showZoneFireLinesMaster':'showZoneFireLinesPlayers']=$(eid).checked;requestRender();v070SaveDaylight().catch(error=>toast(error.message,'error'));});
    $('trigger-zone-trauma-preset')?.addEventListener('change',()=>{if($('trigger-zone-trauma-preset').value)$('trigger-zone-trauma').value=$('trigger-zone-trauma-preset').value;});
  }


  /* ===== FATUM Battlemap v0.8.6: shotgun cones, canonical traumas, placed tokens ===== */
  const V086_TRAUMAS={
    'Перелом черепа':'−2 к инициативе, −4 к проверкам Концентрации, −5 к базовой морали.',
    'Повреждённое колено':'Скорость −10 футов; Прыжки и Рывки недоступны.',
    'Трещина в ребре':'−1 ОД, −3 к Выносливости; Прыжок или Рывок наносит 1 Лёгкое ранение.',
    'Выбитое плечо':'−2 к попаданию и −2 к проверкам Силы.',
    'Сломанная рука':'Нельзя использовать двуручное оружие; −2 к связанным с руками проверкам Силы и Ловкости.',
    'Рваная рана':'−2 ко всем проверкам.',
    'Повреждённый глаз':'−3 к Меткости и попаданию; дальность стрельбы −30 футов.',
    'Разрыв сухожилия':'−3 к Ловкости; Скорость −5 футов.',
    'Кровоизлияние в лёгкие':'−3 к Выносливости; −2 к морали.',
    'Потеря конечности':'Эффект зависит от выбранного варианта: рука, нога или пальцы.'
  };
  function v086TraumaFields(){
    const traumaName=$('trigger-zone-trauma-preset')?.value||'Перелом черепа',traumaVariant=$('trigger-zone-trauma-variant')?.value||'arm';
    if($('trigger-zone-trauma'))$('trigger-zone-trauma').value=traumaName;
    return{traumaName,traumaVariant,traumaText:traumaName};
  }
  const v086BaseNewTriggerFields=v084NewTriggerFields;
  v084NewTriggerFields=function(){return{...v086BaseNewTriggerFields(),...v086TraumaFields()};};
  const v086BaseRefreshZoneUi=v084RefreshZoneUi;
  v084RefreshZoneUi=function(){
    if(!master||!app.scene){v086RefreshTraumaDescription();return;}
    v086BaseRefreshZoneUi();
    const zone=v084TriggerZone(),name=zone?.traumaName||zone?.traumaText||$('trigger-zone-trauma-preset')?.value||'Перелом черепа';
    if($('trigger-zone-trauma-preset'))$('trigger-zone-trauma-preset').value=V086_TRAUMAS[name]?name:'Перелом черепа';
    if($('trigger-zone-trauma-variant'))$('trigger-zone-trauma-variant').value=zone?.traumaVariant||'arm';
    v086RefreshTraumaDescription();
  };
  function v086RefreshTraumaDescription(){
    const name=$('trigger-zone-trauma-preset')?.value||'Перелом черепа',variant=$('trigger-zone-trauma-variant')?.value||'arm',row=$('trigger-zone-trauma-variant-row');
    if(row)row.hidden=name!=='Потеря конечности';
    const suffix=name==='Потеря конечности'?` Выбран вариант: ${{arm:'рука',leg:'нога',fingers:'пальцы'}[variant]||'рука'}.`:'';
    if($('trigger-zone-trauma-description'))$('trigger-zone-trauma-description').textContent=`${V086_TRAUMAS[name]||''}${suffix} Эффект применяется немедленно при срабатывании зоны — и в бою, и вне боя.`;
  }

  function v086ShotgunWeapons(token){return allClientWeapons(token).filter(w=>Boolean(w.coneAttack)&&Number(w.coneFeet||0)>0&&!w.melee);}
  // v0.9.10: insertAdjacentHTML('beforebegin') нельзя вызывать у уже удалённой
  // кнопки. У дробовика прежний код сначала удалял одиночную кнопку, а затем
  // пытался вставить конус перед тем же отсоединённым DOM-элементом. Это
  // выбрасывало NotFoundError и обрывало pointermove именно у токена с дробовиком.
  function v0910InsertDockHtml(slots,anchor,html){
    if(anchor&&anchor.parentElement===slots)anchor.insertAdjacentHTML('beforebegin',html);
    else slots.insertAdjacentHTML('afterbegin',html);
  }
  const v086BaseRefreshActionDock=refreshActionDock;
  refreshActionDock=function(){
    v086BaseRefreshActionDock();
    const token=selectedToken(),slots=$('action-slots');if(!token||!slots||$('action-dock').hidden)return;
    for(const weapon of v086ShotgunWeapons(token)){
      const wid=String(weapon.id||weapon.slot||weapon.name),single=slots.querySelector(`[data-dock-action="ranged:${CSS.escape(wid)}"]`),aimed=slots.querySelector(`[data-dock-action="aimed:${CSS.escape(wid)}"]`),anchor=single?.parentElement===slots?single:aimed?.parentElement===slots?aimed:null;
      if(!slots.querySelector(`[data-dock-action="shotgun-cone:${CSS.escape(wid)}"]`)){
        const die=/Боевой дробовик/i.test(String(weapon.profile||weapon.name))?'1к8 до 10 фт / 1к6 дальше':String(weapon.hitDieNormal||'1к6').replace(/d/i,'к'),bonus=Number(weapon.hitBonus||0),help=`${die} ${bonus>=0?'+':''}${bonus} · урон ${Number(weapon.damage||0)} · конус ${weapon.coneFeet} фт. Для каждой цели внутри выполняется отдельная проверка попадания. Базовый выстрел не расходует ОБ.`;
        const html=actionButtonHtml(`shotgun-cone:${wid}`,'◁',`Конус: ${weapon.name}`,weapon.odCost??2,help,'weapon');
        v0910InsertDockHtml(slots,anchor,html);
      }
      if(!weapon.singleTargetOnly){single?.remove();aimed?.remove();}
    }
    const canAct=combatCanAct(token);
    slots.querySelectorAll('[data-dock-action^="shotgun-cone:"]').forEach(button=>{button.disabled=!canAct;button.onmouseenter=()=>setActionDescription(button.title);button.onmouseleave=()=>setActionDescription(app.actionTarget?'Укажите направление конуса.':'Выберите действие.');});
  };
  async function v086PerformShotgunCone(point){
    const action=app.actionTarget,attacker=tokenById(action?.attackerId);if(!action||!attacker||app.attackPending)return;
    app.attackPending=true;
    try{
      const result=await api('/api/battlemap/shotgun-cone',{method:'POST',body:commonBody({requestId:id(),sceneId:app.scene.id,attackerTokenId:attacker.id,weaponId:action.weaponId,x:point.x,y:point.y,moved:Boolean(movementForToken(attacker)?.spent),spendResources:combatActive(),visibility:'public'})});
      for(const item of result.results||[]){if(item.roll)startRollVisual(item.roll);if(item.attack)showAttackResult(item.attack,false);if(item.damageResult)renderAutoDamageResult(item.damageResult,item.attack?.damageTargetName||item.attack?.targetName);}
      const hits=(result.results||[]).filter(item=>item.attack?.hit).length;
      toast(`Конус дробовика: целей ${(result.results||[]).length}, попаданий ${hits}.`,hits?'success':'error');
      await fetchAll(true);
    }catch(error){toast(error.message,'error');}
    finally{app.attackPending=false;cancelDockTarget();}
  }
  function v086DrawConePreview(){
    const action=app.actionTarget;if(action?.type!=='shotgun-cone'||!app.scene)return;
    const attacker=tokenById(action.attackerId),weapon=allClientWeapons(attacker).find(w=>String(w.id||w.slot||w.name)===String(action.weaponId));if(!attacker||!weapon)return;
    const from=visualTokenState(attacker),aim=app.lastMouseWorld||from,dx=aim.x-from.x,dy=aim.y-from.y,len=Math.hypot(dx,dy);if(len<1)return;
    const depth=feetToPixels(Number(weapon.coneFeet||10)),half=(Number(weapon.coneAngle||60)*Math.PI/180)/2,angle=Math.atan2(dy,dx),left={x:from.x+Math.cos(angle-half)*depth,y:from.y+Math.sin(angle-half)*depth},right={x:from.x+Math.cos(angle+half)*depth,y:from.y+Math.sin(angle+half)*depth};
    ctx.save();ctx.beginPath();ctx.moveTo(from.x,from.y);ctx.lineTo(left.x,left.y);ctx.arc(from.x,from.y,depth,angle-half,angle+half);ctx.closePath();ctx.fillStyle='rgba(255,151,68,.18)';ctx.fill();ctx.strokeStyle='rgba(255,192,105,.95)';ctx.lineWidth=2.2/app.view.scale;ctx.setLineDash([8/app.view.scale,5/app.view.scale]);ctx.stroke();ctx.restore();
  }

  app.pendingTokenPlacement=null;
  function v086PrepareTokenPayload(){
    if(!app.scene)return null;
    const kind=$('token-source-kind').value;
    if(kind==='vehicle'){
      const profile=app.vehicleProfiles.find(item=>item.id===$('vehicle-profile-select').value);if(!profile){toast('Выберите профиль транспорта.','error');return null;}
      return{kind:'vehicle',name:$('vehicle-token-name').value||profile.name,imageUrl:app.uploadedTokenImage,size:Number($('new-token-size').value||2),vision:{enabled:false,range:0,angle:360},vehicle:{profileId:profile.id,profileName:profile.name,...profile,zoneFeet:60}};
    }
    const refId=kind==='generic'?null:$('token-ref').value;
    const name=kind==='generic'?($('generic-token-name').value||'Новый токен'):kind==='character'?characterById(refId)?.name:npcById(refId)?.name;
    if(kind!=='generic'&&!refId){toast('Выберите лист для токена.','error');return null;}
    return{kind,refId,name,imageUrl:app.uploadedTokenImage,size:Number($('new-token-size').value||1),vision:{enabled:kind==='character',range:60,angle:360},light:{enabled:false,bright:20,dim:40,angle:360,color:'#ffd88a'}};
  }
  addToken=async function(){
    const payload=v086PrepareTokenPayload();if(!payload)return;
    app.pendingTokenPlacement={payload};document.body.classList.add('bm-targeting');setTool('select');
    setActionDescription(`Щёлкните по карте, чтобы разместить «${payload.name}». Escape — отмена.`);
    toast('Выберите место размещения токена на карте.');
    if($('add-token-btn'))$('add-token-btn').textContent='Ожидание точки…';
    requestRender();
  };
  async function v086CommitTokenPlacement(point){
    const pending=app.pendingTokenPlacement;if(!pending||!app.scene)return;
    const p=snapPoint(point),payload={...pending.payload,x:p.x,y:p.y};
    app.pendingTokenPlacement=null;document.body.classList.remove('bm-targeting');if($('add-token-btn'))$('add-token-btn').textContent='Выбрать место на карте';
    try{
      const result=await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/tokens`,{method:'POST',body:commonBody(payload)});
      if(result.token&&!app.scene.tokens.some(token=>token.id===result.token.id))app.scene.tokens.push(result.token);
      app.uploadedTokenImage=null;$('uploaded-token-image-label').textContent='';selectObject('token',result.token.id);refreshAllUi();toast(`Размещён токен «${result.token.name}».`,'success');
    }catch(error){toast(error.message,'error');}
    finally{setActionDescription('Выберите действие.');requestRender();}
  }
  function v086CancelTokenPlacement(){
    if(!app.pendingTokenPlacement)return false;app.pendingTokenPlacement=null;document.body.classList.remove('bm-targeting');if($('add-token-btn'))$('add-token-btn').textContent='Выбрать место на карте';setActionDescription('Размещение отменено.');requestRender();return true;
  }
  function v086DrawTokenPlacement(){
    if(!app.pendingTokenPlacement||!app.lastMouseWorld)return;const p=snapPoint(app.lastMouseWorld),radius=feetToPixels(Number(app.pendingTokenPlacement.payload.size||1)*Number(app.scene.grid?.feet||5))/2;
    ctx.save();ctx.beginPath();ctx.arc(p.x,p.y,Math.max(12/app.view.scale,radius),0,Math.PI*2);ctx.fillStyle='rgba(105,211,255,.18)';ctx.fill();ctx.strokeStyle='#69d3ff';ctx.lineWidth=2/app.view.scale;ctx.setLineDash([6/app.view.scale,4/app.view.scale]);ctx.stroke();ctx.setLineDash([]);ctx.beginPath();ctx.moveTo(p.x-10/app.view.scale,p.y);ctx.lineTo(p.x+10/app.view.scale,p.y);ctx.moveTo(p.x,p.y-10/app.view.scale);ctx.lineTo(p.x,p.y+10/app.view.scale);ctx.stroke();ctx.restore();
  }

  const v086BaseOnPointerDown=onPointerDown;
  onPointerDown=function(event){
    if(master&&app.pendingTokenPlacement&&event.button===0&&app.scene){event.preventDefault();v086CommitTokenPlacement(screenToWorld(eventPoint(event)));return;}
    if(app.actionTarget?.type==='shotgun-cone'&&event.button===0&&app.scene){event.preventDefault();v086PerformShotgunCone(screenToWorld(eventPoint(event)));return;}
    return v086BaseOnPointerDown(event);
  };
  const v086BaseOnPointerMove=onPointerMove;
  onPointerMove=function(event){if(app.pendingTokenPlacement||app.actionTarget?.type==='shotgun-cone'){app.lastMouseWorld=screenToWorld(eventPoint(event));requestRender();}return v086BaseOnPointerMove(event);};
  const v086BaseRender=render;
  render=function(){v086BaseRender();if(!app.scene)return;ctx.setTransform(app.dimensions.dpr,0,0,app.dimensions.dpr,0,0);ctx.save();ctx.translate(app.view.x,app.view.y);ctx.scale(app.view.scale,app.view.scale);v086DrawConePreview();v086DrawTokenPlacement();ctx.restore();};

  function bindV086Ui(){
    $('trigger-zone-trauma-preset')?.addEventListener('change',()=>{v086TraumaFields();v086RefreshTraumaDescription();});
    $('trigger-zone-trauma-variant')?.addEventListener('change',v086RefreshTraumaDescription);
    $('action-slots').addEventListener('click',event=>{const button=event.target.closest('[data-dock-action^="shotgun-cone:"]');if(!button||button.disabled)return;event.preventDefault();event.stopImmediatePropagation();const token=selectedToken();app.actionTarget={type:'shotgun-cone',attackerId:token.id,weaponId:button.dataset.dockAction.slice('shotgun-cone:'.length)};document.body.classList.add('bm-targeting');setTool('select');setActionDescription('Укажите направление конуса дробовика.');toast('Щёлкните в направлении выстрела.');requestRender();},true);
    window.addEventListener('keydown',event=>{if(event.key==='Escape'&&v086CancelTokenPlacement()){event.preventDefault();event.stopImmediatePropagation();}},true);
    v086RefreshTraumaDescription();
  }


  // v0.8.9 — hotfix: безопасная инициализация карты до получения первой сцены.
  // v0.8.8 — мастерский нарративный контроль, динамический состав боя,
  // критические ранения и группы токенов.
  function v088Groups(){return app.scene?.tokenGroups||[];}
  function v088Group(groupId){return v088Groups().find(group=>group.id===groupId)||null;}
  function v088Critical(token){return token?.criticalRuntime||{critical:false,dead:false,stabilized:false,elapsed:0,limit:3,remaining:0,canAttack:false};}
  async function v088SaveGroups(groups=v088Groups()){
    if(!master||!app.scene)return;
    const result=await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/token-groups`,{method:'PUT',body:commonBody({groups})});
    app.scene.tokenGroups=result.groups||[];v088RenderGroups();refreshInspector();requestRender();
  }
  function v088RenderGroups(){
    const list=$('token-group-list'),transfer=$('token-group-transfer-select'),target=$('token-group-transfer-scene');if(!list||!transfer||!target)return;
    const groups=v088Groups(),counts=new Map(groups.map(group=>[group.id,(app.scene?.tokens||[]).filter(token=>token.groupId===group.id).length]));
    list.innerHTML=groups.length?groups.map(group=>`<div class="bm-token-group-row" data-group-id="${esc(group.id)}"><span class="bm-token-group-dot" style="background:${esc(group.color)}"></span><button class="bm-link-button" data-group-rename="${esc(group.id)}"><strong>${esc(group.name)}</strong></button><small>${counts.get(group.id)||0} ток.</small><label class="bm-check"><input type="checkbox" data-group-morale="${esc(group.id)}" ${group.moraleOnDeath!==false?'checked':''}> −10 морали при гибели</label><button class="bm-btn bm-danger bm-group-delete-btn" data-group-delete="${esc(group.id)}">Удалить</button></div>`).join(''):'<p class="bm-muted">Группы ещё не созданы.</p>';
    transfer.innerHTML=groups.map(group=>`<option value="${esc(group.id)}">${esc(group.name)} (${counts.get(group.id)||0})</option>`).join('');
    target.innerHTML=(app.battlemap?.scenes||[]).filter(scene=>scene.id!==app.scene?.id).map(scene=>`<option value="${esc(scene.id)}">${esc(scene.name)}</option>`).join('');
    $('token-group-transfer-btn').disabled=!groups.length||!target.options.length;
    const relA=$('token-group-relation-a'),relB=$('token-group-relation-b'),relSummary=$('token-group-relation-summary');
    if(relA&&relB){const oldA=relA.value,oldB=relB.value,options=groups.map(group=>`<option value="${esc(group.id)}">${esc(group.name)}</option>`).join('');relA.innerHTML=options;relB.innerHTML=options;if(groups.some(g=>g.id===oldA))relA.value=oldA;if(groups.some(g=>g.id===oldB))relB.value=oldB;if(relA.value===relB.value&&groups.length>1)relB.value=groups[1].id;const lines=[];for(let i=0;i<groups.length;i++)for(let j=i+1;j<groups.length;j++){const relation=groups[i].relations?.[groups[j].id]||groups[j].relations?.[groups[i].id]||'neutral';lines.push(`${esc(groups[i].name)} ↔ ${esc(groups[j].name)}: ${{enemy:'враги',ally:'союзники',neutral:'нейтральны'}[relation]}`);}if(relSummary)relSummary.innerHTML=lines.length?lines.join('<br>'):'Создайте хотя бы две группы.';$('token-group-relation-save').disabled=groups.length<2;}
  }
  function v088RefreshInspector(){
    const token=selectedToken(),groupSelect=$('token-group');if(groupSelect){groupSelect.innerHTML=`<option value="">Без группы</option>${v088Groups().map(group=>`<option value="${esc(group.id)}">${esc(group.name)}</option>`).join('')}`;groupSelect.value=token?.groupId||'';}
    const critical=v088Critical(token),card=$('critical-status-card');if(card){card.hidden=!token||!critical.critical;const text=$('critical-status-text');if(text&&critical.critical)text.innerHTML=critical.dead?'<strong class="bm-danger-text">Мёртв</strong>':critical.stabilized?'<strong>Стабилизирован</strong>':`До смерти: <strong>${critical.remaining}</strong> ${critical.remaining===1?'ход':'хода'} из ${critical.limit}.${critical.canAttack?' Можно атаковать со штрафом −5; двигаться нельзя.':' Движение и действия недоступны.'}`;}
    const combat=app.battlemap?.combat,active=Boolean(combat?.active&&combat.sceneId===app.scene?.id),included=Boolean(token&&combat?.participantTokenIds?.includes(token.id));
    if($('combat-membership-status'))$('combat-membership-status').textContent=!active?'На этой сцене бой не активен.':included?'Токен участвует в инициативе.':'Токен сейчас вне инициативы.';
    if($('combat-membership-toggle')){$('combat-membership-toggle').disabled=!token||!active||!['character','npc'].includes(token.kind);$('combat-membership-toggle').textContent=included?'Вывести из боя':'Ввести в бой';$('combat-membership-toggle').dataset.action=included?'remove':'add';}
    const n=token?.gmNarrative||{};
    if($('narrative-attack-condition'))$('narrative-attack-condition').value=n.attackCondition||'normal';
    if($('narrative-attack-bonus'))$('narrative-attack-bonus').value=Number(n.attackBonus||0);
    if($('narrative-damage-bonus'))$('narrative-damage-bonus').value=Number(n.damageBonus||0);
    if($('narrative-defense-condition'))$('narrative-defense-condition').value=n.defenseCondition||'normal';
    if($('narrative-defense-bonus'))$('narrative-defense-bonus').value=Number(n.defenseBonus||0);
    if($('narrative-check-condition'))$('narrative-check-condition').value=n.checkCondition||'normal';
    if($('narrative-check-bonus'))$('narrative-check-bonus').value=Number(n.checkBonus||0);
    if($('narrative-note'))$('narrative-note').value=n.note||'';
    const aiCard=$('npc-ai-card'),ai=token?.ai||{};if(aiCard){aiCard.hidden=!master||token?.kind!=='npc';if(token?.kind==='npc'){$('npc-ai-enabled').checked=Boolean(ai.enabled);$('npc-ai-autorun').checked=ai.autoRun!==false;$('npc-ai-profile').value=ai.profile||'balanced';$('npc-ai-cover').checked=ai.preferCover!==false;$('npc-ai-grenades').checked=ai.useGrenades!==false;$('npc-ai-specials').checked=ai.useSpecials!==false;$('npc-ai-status').textContent=ai.enabled?`ИИ включён · ${ai.autoRun!==false?'автоматический ход':'только ручной запуск'}.`:'ИИ отключён.';$('npc-ai-run').disabled=!ai.enabled||!combatCanAct(token);}}
  }
  async function v088SaveNarrative(clear=false){
    const token=selectedToken();if(!master||!token)return;
    const narrative=clear?{}:{attackCondition:$('narrative-attack-condition').value,attackBonus:Number($('narrative-attack-bonus').value||0),damageBonus:Number($('narrative-damage-bonus').value||0),defenseCondition:$('narrative-defense-condition').value,defenseBonus:Number($('narrative-defense-bonus').value||0),checkCondition:$('narrative-check-condition').value,checkBonus:Number($('narrative-check-bonus').value||0),note:$('narrative-note').value};
    try{const result=await api('/api/battlemap/token-narrative',{method:'PUT',body:commonBody({sceneId:app.scene.id,tokenId:token.id,narrative})});token.gmNarrative=result.narrative;v088RefreshInspector();toast(clear?'Нарративные модификаторы сброшены.':'Модификаторы назначены на следующие подходящие броски.','success');}catch(error){toast(error.message,'error');}
  }
  async function v088ToggleCombatMembership(){
    const token=selectedToken();if(!master||!token)return;
    const action=$('combat-membership-toggle').dataset.action;try{await api('/api/battlemap/combat/participant',{method:'POST',body:commonBody({sceneId:app.scene.id,tokenId:token.id,action})});await fetchAll(true);toast(action==='remove'?'Токен выведен из боя.':'Токен введён в бой.','success');}catch(error){toast(error.message,'error');}
  }
  async function v088TransferGroup(){
    const groupId=$('token-group-transfer-select').value,targetSceneId=$('token-group-transfer-scene').value;if(!groupId||!targetSceneId)return;
    const group=v088Group(groupId);if(!confirm(`Перенести всю группу «${group?.name||'Группа'}» на другую сцену?`))return;
    try{await api(`/api/battlemap/scenes/${encodeURIComponent(app.scene.id)}/groups/${encodeURIComponent(groupId)}/transfer`,{method:'POST',body:commonBody({targetSceneId})});await fetchAll(true);toast('Группа перенесена между сценами.','success');}catch(error){toast(error.message,'error');}
  }

  const v088BaseRefreshInspector=refreshInspector;
  refreshInspector=function(){v088BaseRefreshInspector();v088RefreshInspector();};
  const v088BaseRefreshAllUi=refreshAllUi;
  refreshAllUi=function(){v088BaseRefreshAllUi();v088RenderGroups();v088RefreshInspector();};
  const v088BaseRefreshActionDock=refreshActionDock;
  refreshActionDock=function(){
    v088BaseRefreshActionDock();const token=selectedToken(),critical=v088Critical(token);if(!token||!critical.critical||critical.dead||critical.stabilized)return;
    const slots=$('action-slots');if(!slots)return;
    slots.querySelectorAll('button[data-dock-action]').forEach(button=>{const key=button.dataset.dockAction||'',isAttack=/^(ranged:|aimed:|melee|shotgun-cone:|melee-|special-|zone-|cover-attack)/.test(key);if(!critical.canAttack||!isAttack)button.disabled=true;});
    const resource=$('action-resource-line');if(resource)resource.textContent+=` · КРИТ ${critical.remaining}/${critical.limit}${critical.canAttack?' · атаки −5':''}`;
    setActionDescription(critical.canAttack?'Критическое ранение: разрешены только атаки со штрафом −5.':'Критическое ранение: токен не может двигаться или действовать.');
  };
  const v088BaseMoveKeyboard=moveSelectedByKeyboard;
  moveSelectedByKeyboard=function(dx,dy,fine=false){const token=selectedToken(),critical=v088Critical(token);if(critical.critical&&!critical.dead){toast('Критическое ранение обездвиживает персонажа.','error');return;}return v088BaseMoveKeyboard(dx,dy,fine);};
  const v088BasePointerDown=onPointerDown;
  onPointerDown=function(event){
    if(app.tool==='select'&&event.button===0&&app.scene){const token=hitTestToken(screenToWorld(eventPoint(event))),critical=v088Critical(token);if(token&&canControlToken(token)&&critical.critical&&!critical.dead){selectObject('token',token.id);toast('Критическое ранение: перемещение невозможно.','error');return;}}
    return v088BasePointerDown(event);
  };
  const v088BaseDrawToken=drawToken;
  drawToken=function(target,token){
    const group=v088Group(token.groupId),radius=tokenRadius(token);if(group&&token.display?.showGroupMarker!==false){target.save();target.beginPath();target.arc(token.x,token.y,radius+4/app.view.scale,0,Math.PI*2);target.strokeStyle=group.color;target.globalAlpha=.9;target.lineWidth=4/app.view.scale;target.stroke();target.restore();}
    v088BaseDrawToken(target,token);
    const critical=v088Critical(token);if(critical.critical&&!critical.stabilized){target.save();const x=token.x+radius*.72,y=token.y-radius*.72,r=15/app.view.scale;target.beginPath();target.arc(x,y,r,0,Math.PI*2);target.fillStyle=critical.dead?'#2a0909':'#c71f2c';target.fill();target.strokeStyle='#fff1f1';target.lineWidth=2/app.view.scale;target.stroke();target.fillStyle='#fff';target.font=`bold ${(critical.dead?10:13)/app.view.scale}px Segoe UI`;target.textAlign='center';target.textBaseline='middle';target.fillText(critical.dead?'☠':String(critical.remaining),x,y);target.restore();}
  };

  app.v090AiRunning=false;
  app.v090AiSignature=null;
  function v090CurrentCombatToken(){const initiative=app.campaign?.initiative||{},entry=initiative.entries?.[initiative.currentIndex||0];return tokenForInitiative(entry);}
  async function v090SaveRelation(){const a=$('token-group-relation-a')?.value,b=$('token-group-relation-b')?.value,value=$('token-group-relation-value')?.value;if(!a||!b||a===b)return toast('Выберите две разные группы.','error');const groups=v088Groups(),ga=groups.find(g=>g.id===a),gb=groups.find(g=>g.id===b);if(!ga||!gb)return;ga.relations={...(ga.relations||{}),[b]:value};gb.relations={...(gb.relations||{}),[a]:value};try{await v088SaveGroups(groups);toast('Отношение групп сохранено.','success');}catch(error){toast(error.message,'error');}}
  async function v090SaveAi(){const token=selectedToken();if(!master||token?.kind!=='npc')return;const ai={enabled:$('npc-ai-enabled').checked,autoRun:$('npc-ai-autorun').checked,profile:$('npc-ai-profile').value,preferCover:$('npc-ai-cover').checked,useGrenades:$('npc-ai-grenades').checked,useSpecials:$('npc-ai-specials').checked};try{const result=await updateToken(token,{ai});if(result.token)Object.assign(token,result.token);v088RefreshInspector();toast(ai.enabled?'Тактический ИИ включён для NPC.':'Тактический ИИ отключён.','success');v090ScheduleAi();}catch(error){toast(error.message,'error');}}
  async function v090RunAi({manual=false}={}){const token=manual?selectedToken():v090CurrentCombatToken();if(!master||!combatActive()||token?.kind!=='npc'||!token.ai?.enabled||app.v090AiRunning)return;if(!manual&&token.ai.autoRun===false)return;if(app.battlemap?.masterPause?.active)return;const initiative=app.campaign?.initiative||{},signature=`${initiative.round||0}:${initiative.currentIndex||0}:${token.id}`;if(!manual&&app.v090AiSignature===signature)return;app.v090AiSignature=signature;app.v090AiRunning=true;if($('npc-ai-status'))$('npc-ai-status').textContent=`ИИ думает: ${token.name}…`;try{const result=await api('/api/battlemap/ai/turn',{method:'POST',body:commonBody({sceneId:app.scene.id,tokenId:token.id})});toast(`ИИ ${token.name}: выполнено действий ${result.steps?.length||0}.`,'success');await fetchAll(true);if(!manual&&combatActive()&&v090CurrentCombatToken()?.id===token.id){await new Promise(resolve=>setTimeout(resolve,420));await api('/api/battlemap/combat/advance',{method:'POST',body:commonBody()});await fetchAll(true);}}catch(error){app.v090AiSignature=null;toast(`ИИ: ${error.message}`,'error');}finally{app.v090AiRunning=false;v088RefreshInspector();setTimeout(v090ScheduleAi,160);}}
  function v090ScheduleAi(){if(!master||app.v090AiRunning||app.battlemap?.masterPause?.active||!combatActive())return;const token=v090CurrentCombatToken();if(token?.kind==='npc'&&token.ai?.enabled&&token.ai.autoRun!==false)setTimeout(()=>v090RunAi(),260);}

  const v090BaseRefreshAttackWeapons=refreshAttackWeapons;
  refreshAttackWeapons=function(){v090BaseRefreshAttackWeapons();const token=tokenById($('attack-attacker').value),weapons=clientWeapons(token),select=$('attack-weapon');for(const option of [...select.options]){const weapon=weapons.find(w=>String(w.id||w.slot||w.name)===option.value);if(weapon?.coneAttack&&!weapon.singleTargetOnly)option.remove();}refreshAttackPreview();};
  const v090BaseShowQuickAttackPicker=showQuickAttackPicker;
  showQuickAttackPicker=function(target){v090BaseShowQuickAttackPicker(target);const attacker=tokenById($('attack-attacker').value),weapons=clientWeapons(attacker),rows=[...$('quick-weapon-list').querySelectorAll('.bm-quick-weapon')];for(const row of rows){const button=row.querySelector('[data-quick-weapon]'),weapon=weapons.find(w=>String(w.id||w.slot||w.name)===button?.dataset.quickWeapon);if(weapon?.coneAttack&&!weapon.singleTargetOnly)row.remove();}if(!$('quick-weapon-list').children.length)$('quick-weapon-list').innerHTML='<div class="bm-muted">У этого оружия нет одиночного выстрела. Используйте действие «Конус» в нижней панели.</div>';};
  const v090BaseRefreshAllUi=refreshAllUi;
  refreshAllUi=function(){v090BaseRefreshAllUi();v090ScheduleAi();};

  // v0.9.1 — hotfix: надёжное распознавание дробовиков в клиентском профиле.
  // Старые листы могли отдавать только type/profile/description без server-side coneAttack,
  // из-за чего кнопка «Конус» исчезала именно у персонажей.
  function v091ShotgunDescriptor(weapon){
    if(!weapon)return null;
    const notes=Array.isArray(weapon.notes)?weapon.notes.join(' '):'';
    const mods=Array.isArray(weapon.mods)?weapon.mods.join(' '):'';
    const text=`${weapon.type||''} ${weapon.profile||''} ${weapon.name||''} ${weapon.description||''} ${notes} ${mods}`.toLowerCase();
    // v0.9.3: old inventories may contain only the decorative model name.
    // Recognise those models directly instead of relying on a missing type/description.
    const combatModel=/stahlhammer-11(?!f)|ds-15\s+tempesta|ками-рэн/.test(text);
    const standardModel=/лэймэнь-l2|m\.\s*dural|цзиньфэн/.test(text);
    const sawnModel=/bâtard-9|batard-9/.test(text);
    const anaxionModel=/zarya-d1|molot-r2/.test(text);
    const flameModel=/stahlhammer-11f/.test(text);
    if(!/дробовик|огнем[её]тн/.test(text)&&!combatModel&&!standardModel&&!sawnModel&&!anaxionModel&&!flameModel)return null;
    const singleTarget=anaxionModel||/анаксионн\w*\s+дробовик|пулевой\s+ствол|shotgun_slug_barrel|без\s+конуса/.test(text);
    let cone=Number(weapon.coneFeet||0);
    const explicit=text.match(/конус(?:\s+атаки)?\s*[:—-]?\s*(\d+)\s*(?:фт|фут)/i);
    if(!cone&&explicit)cone=Number(explicit[1]);
    if(!cone)cone=(combatModel||/боев\w*\s+дробовик/.test(text))?15:10;
    if(/сужение\s+ствола|shotgun_choke|конус\s+атаки\s*-\s*5/.test(text)&&!explicit)cone-=5;
    if(/расширенн\w*\s+раструб|shotgun_spreader|конус\s+атаки\s*\+\s*5/.test(text)&&!explicit)cone+=5;
    return{coneFeet:singleTarget?0:Math.max(0,cone),coneAngle:Number(weapon.coneAngle||60),singleTargetOnly:singleTarget};
  }
  function v091DecorateClientWeapon(weapon){
    const profile=v091ShotgunDescriptor(weapon);if(!profile)return weapon;
    const result={...weapon,shotgun:true,coneFeet:profile.coneFeet,coneAngle:profile.coneAngle,coneAttack:profile.coneFeet>0,singleTargetOnly:profile.singleTargetOnly};
    if(/боев\w*\s+дробовик/i.test(`${result.profile||''} ${result.name||''}`)){result.hitDieAimed='';result.aimedOdCost=null;}
    return result;
  }
  const v091BaseClientWeapons=clientWeapons;
  clientWeapons=function(token){return v091BaseClientWeapons(token).map(v091DecorateClientWeapon);};
  const v091BaseAllClientWeapons=allClientWeapons;
  allClientWeapons=function(token){return v091BaseAllClientWeapons(token).map(v091DecorateClientWeapon);};


  // v0.9.3 — профиль токена, профиль листа и инвентарь объединяются, а не
  // взаимоисключают друг друга. Это исправляет старые токены, у которых
  // public token.weapons содержал только второй слот (например пистолет),
  // хотя в weapon1 был экипирован модифицированный дробовик.
  function v092WeaponMergeKey(weapon){
    const slot=String(weapon?.slot||weapon?.id||'');
    if(slot==='weapon1'||slot==='weapon2'||slot==='unarmed')return slot;
    return String(weapon?.id||weapon?.slot||weapon?.name||weapon?.profile||'').toLocaleLowerCase('ru-RU');
  }
  function v092MergeWeaponLists(lists,st={}){
    const merged=new Map(),equipment=st?.equipment||{};
    const explicitSlots=new Set(['weapon1','weapon2'].filter(slot=>Object.prototype.hasOwnProperty.call(equipment,slot)));
    for(const list of lists){
      for(const raw of Array.isArray(list)?list:[]){
        if(!raw)continue;
        const slot=String(raw.slot||raw.id||'');
        if((slot==='weapon1'||slot==='weapon2')&&explicitSlots.has(slot)&&!equipment[slot])continue;
        const key=v092WeaponMergeKey(raw);if(!key)continue;
        const previous=merged.get(key)||{};
        // Последующий источник считается более свежим, но пустые поля не должны
        // стирать рабочие значения из предыдущего источника.
        const next={...previous};
        for(const [field,value] of Object.entries(raw))if(value!==undefined&&value!==null&&value!=='')next[field]=value;
        merged.set(key,next);
      }
    }
    return [...merged.values()].map(weapon=>{
      const mods=Array.isArray(weapon.mods)?weapon.mods:[];
      const notes=[...(Array.isArray(weapon.notes)?weapon.notes:[]),...mods];
      return v091DecorateClientWeapon({...weapon,notes:[...new Set(notes)]});
    });
  }
  const v092BaseClientWeapons=clientWeapons;
  clientWeapons=function(token){
    if(!token)return[];
    if(token.kind!=='character')return v092BaseClientWeapons(token).map(v091DecorateClientWeapon);
    const st=characterById(token.refId)?.state||{};
    // fallbackClientWeapons читает фактически экипированные слоты и поэтому
    // служит последней страховкой, если сетевой профиль токена оказался неполным.
    const fallback=fallbackClientWeapons(st);
    const sheet=Array.isArray(st._lanBattleProfile?.weapons)?st._lanBattleProfile.weapons:[];
    const publicWeapons=Array.isArray(token.weapons)?token.weapons:[];
    return v092MergeWeaponLists([fallback,sheet,publicWeapons],st);
  };

  // v0.9.3 — aliases for legacy model-only inventory records.
  // The server now sends the canonical profile, but this client-side layer also
  // protects an already-open page until the next full state refresh.
  const V093_MODEL_PROFILES={
    'stahlhammer-11':{profile:'Боевой дробовик',type:'Дробовик',coneFeet:15,range:80,damage:3,odCost:2,hitDieNormal:'1d6'},
    'ds-15 tempesta':{profile:'Боевой дробовик',type:'Дробовик',coneFeet:15,range:80,damage:3,odCost:2,hitDieNormal:'1d6'},
    'ками-рэн':{profile:'Боевой дробовик',type:'Дробовик',coneFeet:15,range:80,damage:3,odCost:2,hitDieNormal:'1d6'},
    'лэймэнь-l2':{profile:'Стандартный дробовик',type:'Дробовик',coneFeet:10,range:60,damage:3,odCost:2,hitDieNormal:'1d6'},
    'm. dural':{profile:'Стандартный дробовик',type:'Дробовик',coneFeet:10,range:60,damage:3,odCost:2,hitDieNormal:'1d6'},
    'цзиньфэн':{profile:'Стандартный дробовик',type:'Дробовик',coneFeet:10,range:60,damage:3,odCost:2,hitDieNormal:'1d6'},
    'bâtard-9':{profile:'Обрез',type:'Дробовик',coneFeet:10,range:30,damage:2,odCost:2,hitDieNormal:'1d6'},
    'batard-9':{profile:'Обрез',type:'Дробовик',coneFeet:10,range:30,damage:2,odCost:2,hitDieNormal:'1d6'},
    'zarya-d1':{profile:'Анаксионный дробовик',type:'Дробовик',coneFeet:0,range:100,damage:4,odCost:2,hitDieNormal:'1d8',singleTargetOnly:true},
    'molot-r2':{profile:'Анаксионный дробовик',type:'Дробовик',coneFeet:0,range:100,damage:4,odCost:2,hitDieNormal:'1d8',singleTargetOnly:true},
    'stahlhammer-11f':{profile:'Огнемётный',type:'Дробовик',coneFeet:10,range:80,damage:3,odCost:2,hitDieNormal:'1d8',flameCone:true}
  };
  function v093HydrateModelWeapon(weapon){
    if(!weapon)return weapon;const key=String(weapon.name||weapon.profile||'').trim().toLocaleLowerCase('ru-RU'),def=V093_MODEL_PROFILES[key];if(!def)return v091DecorateClientWeapon(weapon);
    const hydrated={...def,...weapon,profile:(!weapon.profile||weapon.profile===weapon.name)?def.profile:weapon.profile,type:weapon.type||def.type};
    if(!hydrated.coneFeet&&def.coneFeet)hydrated.coneFeet=def.coneFeet;
    if(!hydrated.range)hydrated.range=def.range;if(!hydrated.damage)hydrated.damage=def.damage;if(!hydrated.odCost)hydrated.odCost=def.odCost;if(!hydrated.hitDieNormal)hydrated.hitDieNormal=def.hitDieNormal;
    return v091DecorateClientWeapon(hydrated);
  }
  const v093BaseClientWeapons=clientWeapons;
  clientWeapons=function(token){return v093BaseClientWeapons(token).map(v093HydrateModelWeapon);};

  const v091BaseRefreshActionDock=refreshActionDock;
  refreshActionDock=function(){
    v091BaseRefreshActionDock();
    const token=selectedToken(),slots=$('action-slots');if(!token||!slots||$('action-dock').hidden)return;
    const coneWeapons=allClientWeapons(token).filter(w=>w.coneAttack&&Number(w.coneFeet||0)>0&&!w.singleTargetOnly&&!w.melee);
    for(const weapon of coneWeapons){
      const wid=String(weapon.id||weapon.slot||weapon.name),die=/боев\w*\s+дробовик/i.test(`${weapon.profile||''} ${weapon.name||''}`)?'1к8 до 10 фт / 1к6 дальше':String(weapon.hitDieNormal||'1d6').replace(/d/i,'к'),bonus=Number(weapon.hitBonus||0);
      // У обычного дробовика не должно оставаться ложной одноцелевой кнопки.
      for(const button of [...slots.querySelectorAll('button[data-dock-action]')]){
        const key=button.dataset.dockAction||'';
        if(key===`ranged:${wid}`||key===`aimed:${wid}`)button.remove();
      }
      if(![...slots.querySelectorAll('[data-dock-action^="shotgun-cone:"]')].some(button=>button.dataset.dockAction===`shotgun-cone:${wid}`)){
        const help=`${die} ${bonus>=0?'+':''}${bonus} · урон ${Number(weapon.damage||0)} · конус ${weapon.coneFeet} фт. Для каждой цели внутри выполняется отдельная проверка попадания.`;
        slots.insertAdjacentHTML('afterbegin',actionButtonHtml(`shotgun-cone:${wid}`,'◁',`Конус: ${weapon.name}`,weapon.odCost??2,help,'weapon'));
      }
    }
    const canAct=combatCanAct(token);
    slots.querySelectorAll('[data-dock-action^="shotgun-cone:"]').forEach(button=>{button.disabled=!canAct;button.onmouseenter=()=>setActionDescription(button.title);button.onmouseleave=()=>setActionDescription(app.actionTarget?'Укажите направление конуса.':'Выберите действие.');});
  };

  const v091BaseShowQuickAttackPicker=showQuickAttackPicker;
  showQuickAttackPicker=function(target){
    v091BaseShowQuickAttackPicker(target);
    const attacker=tokenById($('attack-attacker').value),list=$('quick-weapon-list');if(!attacker||!target||!list)return;
    const coneWeapons=allClientWeapons(attacker).filter(w=>w.coneAttack&&Number(w.coneFeet||0)>0&&!w.singleTargetOnly&&!w.melee);
    for(const weapon of coneWeapons){
      const wid=String(weapon.id||weapon.slot||weapon.name),die=/боев\w*\s+дробовик/i.test(`${weapon.profile||''} ${weapon.name||''}`)?'1к8 до 10 фт / 1к6 дальше':String(weapon.hitDieNormal||'1d6').replace(/d/i,'к'),bonus=Number(weapon.hitBonus||0);
      if([...list.querySelectorAll('[data-quick-shotgun-cone]')].some(button=>button.dataset.quickShotgunCone===wid))continue;
      list.insertAdjacentHTML('beforeend',`<div class="bm-quick-weapon"><div><strong>${esc(weapon.name)}</strong><small>${esc(die)} ${bonus>=0?'+':''}${bonus} · урон ${Number(weapon.damage||0)} · конус ${Number(weapon.coneFeet||0)} фт</small></div><button class="bm-btn bm-primary" data-quick-shotgun-cone="${esc(wid)}" data-quick-target="${esc(target.id)}">Конус</button><span></span></div>`);
    }
    if(coneWeapons.length&&list.textContent.includes('Используйте действие «Конус»')){
      const note=[...list.children].find(node=>node.classList?.contains('bm-muted'));note?.remove();
    }
  };
  function bindV091Ui(){
    $('quick-weapon-list')?.addEventListener('click',event=>{
      const button=event.target.closest('[data-quick-shotgun-cone]');if(!button)return;
      event.preventDefault();event.stopImmediatePropagation();
      const attacker=tokenById($('attack-attacker').value),target=tokenById(button.dataset.quickTarget);if(!attacker||!target)return;
      $('quick-attack').hidden=true;app.actionTarget={type:'shotgun-cone',attackerId:attacker.id,weaponId:button.dataset.quickShotgunCone};
      document.body.classList.add('bm-targeting');setTool('select');setActionDescription('Конус направлен на выбранную цель.');
      v086PerformShotgunCone(visualTokenState(target));
    },true);
  }

  // v0.9.5 — описание конусной атаки показывает фактический профиль
  // с установленными модификациями. В частности, «Длинный ствол»
  // меняет куб на средней дистанции и даёт штраф вблизи.
  function v095ShotgunHasLongBarrel(weapon){
    if(weapon?.modificationsActive===false)return false;
    const text=[weapon?.name,weapon?.profile,weapon?.description,...(Array.isArray(weapon?.mods)?weapon.mods:[]),...(Array.isArray(weapon?.notes)?weapon.notes:[])].join(' ');
    return /длинный ствол|shotgun_long_barrel/i.test(text);
  }
  function v095Signed(value){const number=Number(value||0);return `${number>=0?'+':''}${number}`;}
  function v095ShotgunHelp(weapon){
    const text=`${weapon?.profile||''} ${weapon?.name||''}`,combat=/боев\w*\s+дробовик/i.test(text),longBarrel=v095ShotgunHasLongBarrel(weapon);
    const bonus=Number(weapon?.hitBonus||0),cone=Math.max(0,Number(weapon?.coneFeet||0)),damage=Number(weapon?.damage||0);
    const baseDie=String(weapon?.hitDieNormal||'1d6').replace(/d/i,'к');
    const closeDie=combat?'1к8':baseDie,farDie=combat?'1к6':baseDie;
    const bands=[];
    if(cone>0)bands.push(`0–${Math.min(10,cone)} фт: ${closeDie} ${v095Signed(bonus+(longBarrel?-1:0))}${longBarrel?' (Длинный ствол: −1)':''}`);
    if(cone>10)bands.push(`11–${Math.min(30,cone)} фт: ${longBarrel?'1к8':farDie} ${v095Signed(bonus)}${longBarrel?' (Длинный ствол)':''}`);
    if(cone>30)bands.push(`31–${cone} фт: ${farDie} ${v095Signed(bonus)}`);
    return `${bands.join(' · ')} · урон ${damage} · конус ${cone} фт. Для каждой цели внутри выполняется отдельная проверка попадания.`;
  }

  // v0.9.4 — нижняя панель действий теперь сверяется с тем же полным
  // списком оружия, который использует режим «Атака». Ранее режим атаки
  // уже видел дробовик, но action dock мог остаться собранным из старого
  // публичного профиля токена и показывал только второе оружие.
  function v094DockShotgunWeapons(token){
    if(!token)return[];
    const merged=new Map();
    for(const source of [clientWeapons(token),allClientWeapons(token)]){
      for(const raw of Array.isArray(source)?source:[]){
        if(!raw)continue;
        const weapon=v093HydrateModelWeapon(v091DecorateClientWeapon({...raw}));
        const descriptor=v091ShotgunDescriptor(weapon);
        if(!descriptor||descriptor.singleTargetOnly||Number(descriptor.coneFeet||0)<=0||weapon.melee)continue;
        const normalized={...weapon,shotgun:true,coneAttack:true,coneFeet:Number(descriptor.coneFeet),coneAngle:Number(descriptor.coneAngle||60),singleTargetOnly:false};
        const wid=String(normalized.id||normalized.slot||normalized.name||normalized.profile||'');
        if(!wid)continue;
        merged.set(wid,{...(merged.get(wid)||{}),...normalized,id:normalized.id||normalized.slot||wid});
      }
    }
    return [...merged.values()];
  }
  function v094EnsureShotgunDock(){
    const token=selectedToken(),slots=$('action-slots'),dock=$('action-dock');
    if(!token||!slots||dock?.hidden)return;
    const weapons=v094DockShotgunWeapons(token),wanted=new Set();
    for(const weapon of weapons){
      const wid=String(weapon.id||weapon.slot||weapon.name),actionKey=`shotgun-cone:${wid}`;wanted.add(actionKey);
      // У конусного дробовика в панели не остаётся одиночной или прицельной атаки.
      for(const button of [...slots.querySelectorAll('button[data-dock-action]')]){
        const key=button.dataset.dockAction||'';
        if(key===`ranged:${wid}`||key===`aimed:${wid}`)button.remove();
      }
      let button=[...slots.querySelectorAll('[data-dock-action^="shotgun-cone:"]')].find(item=>item.dataset.dockAction===actionKey);
      const help=v095ShotgunHelp(weapon);
      if(!button){
        slots.insertAdjacentHTML('afterbegin',actionButtonHtml(actionKey,'◁',`Конус: ${weapon.name}`,weapon.odCost??2,help,'weapon'));
        button=[...slots.querySelectorAll('[data-dock-action^="shotgun-cone:"]')].find(item=>item.dataset.dockAction===actionKey);
      }
      if(button)button.title=help;
    }
    // Убираем только устаревшие конусные кнопки выбранного токена. Базовый
    // refreshActionDock всё равно полностью пересобирает панель при смене токена.
    for(const button of [...slots.querySelectorAll('[data-dock-action^="shotgun-cone:"]')]){
      if(wanted.size&& !wanted.has(button.dataset.dockAction))button.remove();
    }
    const canAct=combatCanAct(token);
    slots.querySelectorAll('[data-dock-action^="shotgun-cone:"]').forEach(button=>{
      button.disabled=!canAct;
      button.onmouseenter=()=>setActionDescription(button.title);
      button.onmouseleave=()=>setActionDescription(app.actionTarget?'Укажите направление конуса.':'Выберите действие.');
    });
  }
  const v094BaseRefreshActionDock=refreshActionDock;
  refreshActionDock=function(){
    v094BaseRefreshActionDock();
    v094EnsureShotgunDock();
    // Некоторые обновления листа и токена приходят разными событиями. Повторная
    // сверка после отрисовки закрывает этот короткий промежуток без перезагрузки.
    requestAnimationFrame(v094EnsureShotgunDock);
  };
  const v094BaseShowQuickAttackPicker=showQuickAttackPicker;
  showQuickAttackPicker=function(target){
    v094BaseShowQuickAttackPicker(target);
    v094EnsureShotgunDock();
  };
  function v095RefreshQuickShotgunDetails(){
    const attacker=tokenById($('attack-attacker')?.value),list=$('quick-weapon-list');if(!attacker||!list)return;
    const byId=new Map(v094DockShotgunWeapons(attacker).map(weapon=>[String(weapon.id||weapon.slot||weapon.name),weapon]));
    for(const button of list.querySelectorAll('[data-quick-shotgun-cone]')){
      const weapon=byId.get(String(button.dataset.quickShotgunCone||''));if(!weapon)continue;
      const small=button.closest('.bm-quick-weapon')?.querySelector('small');if(small)small.textContent=v095ShotgunHelp(weapon);
    }
  }
  const v095BaseShowQuickAttackPicker=showQuickAttackPicker;
  showQuickAttackPicker=function(target){v095BaseShowQuickAttackPicker(target);v095RefreshQuickShotgunDetails();};

  function bindV094Ui(){
    const slots=$('action-slots');if(!slots)return;
    const observer=new MutationObserver(()=>v094EnsureShotgunDock());
    observer.observe(slots,{childList:true,subtree:false});
    app.v094ShotgunDockObserver=observer;
    // Небольшая периодическая сверка нужна только для старых кампаний, где
    // актуальный equipment может появиться позже публичного профиля токена.
    window.setInterval(()=>{if(!$('action-dock')?.hidden)v094EnsureShotgunDock();},750);
  }


  /* ===== FATUM Battlemap v0.9.6: reliable shotgun cone preview and movement sync ===== */
  app.v096PendingTokenUpdates=new Map();
  app.v096ConeStarting=false;

  // Любая атака должна дождаться завершения последнего перемещения токена.
  // Иначе быстрый клик по атаке сразу после отпускания токена мог отправить
  // выстрел со старой серверной позиции, а последующая синхронизация визуально
  // возвращала токен к точке начала движения.
  const v096BaseUpdateToken=updateToken;
  updateToken=function(token,patch,...rest){
    const tokenId=String(typeof token==='string'?token:(token?.id||''));
    if(!tokenId)return v096BaseUpdateToken(token,patch,...rest);
    const previous=app.v096PendingTokenUpdates.get(tokenId)||Promise.resolve();
    const task=(async()=>{await previous.catch(()=>{});return v096BaseUpdateToken(token,patch,...rest);})();
    app.v096PendingTokenUpdates.set(tokenId,task);
    task.then(()=>{if(app.v096PendingTokenUpdates.get(tokenId)===task)app.v096PendingTokenUpdates.delete(tokenId);},()=>{if(app.v096PendingTokenUpdates.get(tokenId)===task)app.v096PendingTokenUpdates.delete(tokenId);});
    return task;
  };
  async function v096AwaitTokenUpdate(token){
    const tokenId=String(token?.id||'');
    while(tokenId&&app.v096PendingTokenUpdates.has(tokenId))await app.v096PendingTokenUpdates.get(tokenId);
  }

  function v096CircleIntersectsCone(origin,aim,point,depth,angleDeg=60,radius=0){
    const dx=aim.x-origin.x,dy=aim.y-origin.y,len=Math.hypot(dx,dy);if(len<.001)return false;
    const ux=dx/len,uy=dy/len,px=point.x-origin.x,py=point.y-origin.y,r=Math.max(0,Number(radius||0));
    const distance=Math.hypot(px,py);if(distance>depth+r)return false;
    const forward=px*ux+py*uy;if(forward < -r || forward > depth+r)return false;
    const lateral=Math.abs(px*uy-py*ux),half=Math.max(.01,Math.min(89,Number(angleDeg||60)/2))*Math.PI/180;
    const width=Math.tan(half)*Math.max(0,Math.min(depth,forward));
    return lateral<=width+r;
  }
  function v096ConeLineBlocked(from,to){
    return effectiveVisionSegments().some(segment=>clientSegmentIntersection(from,to,{x:segment.x1,y:segment.y1},{x:segment.x2,y:segment.y2}));
  }
  function v096ConePreviewInfo(){
    const action=app.actionTarget;if(action?.type!=='shotgun-cone'||!app.scene)return null;
    const attacker=tokenById(action.attackerId);if(!attacker)return null;
    const weapons=[...v094DockShotgunWeapons(attacker),...allClientWeapons(attacker)];
    const weapon=weapons.find(item=>String(item.id||item.slot||item.name)===String(action.weaponId));if(!weapon)return null;
    const origin=visualTokenState(attacker),aim=app.lastMouseWorld||origin,depth=feetToPixels(Number(weapon.coneFeet||10)),angle=Number(weapon.coneAngle||60);
    const targets=(app.scene.tokens||[]).filter(token=>{
      if(token.id===attacker.id||!['character','npc','vehicle'].includes(token.kind)||token.hidden||token.defeated)return false;
      const point=visualTokenState(token),radius=tokenRadius(token);
      return v096CircleIntersectsCone(origin,aim,point,depth,angle,radius)&&!v096ConeLineBlocked(origin,point);
    });
    return{action,attacker,weapon,origin,aim,depth,angle,targets};
  }
  function v096DrawConeTargets(){
    const info=v096ConePreviewInfo();if(!info)return;
    ctx.save();
    for(const token of info.targets){
      const point=visualTokenState(token),radius=tokenRadius(token)+9/app.view.scale;
      ctx.beginPath();ctx.arc(point.x,point.y,radius,0,Math.PI*2);
      ctx.fillStyle='rgba(255,72,52,.22)';ctx.fill();ctx.strokeStyle='#ff4938';ctx.lineWidth=4/app.view.scale;ctx.setLineDash([]);ctx.stroke();
    }
    const dx=info.aim.x-info.origin.x,dy=info.aim.y-info.origin.y,len=Math.max(1,Math.hypot(dx,dy));
    const end={x:info.origin.x+dx/len*info.depth,y:info.origin.y+dy/len*info.depth},label=`В конусе: ${info.targets.length}`;
    ctx.font=`bold ${12/app.view.scale}px Segoe UI`;const width=ctx.measureText(label).width+14/app.view.scale;
    ctx.fillStyle='rgba(8,11,15,.88)';ctx.fillRect(end.x-width/2,end.y-29/app.view.scale,width,20/app.view.scale);
    ctx.fillStyle=info.targets.length?'#ffb09f':'#e5e8eb';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(label,end.x,end.y-19/app.view.scale);
    ctx.restore();
  }

  const v096BaseRender=render;
  render=function(){
    v096BaseRender();if(!app.scene||app.actionTarget?.type!=='shotgun-cone')return;
    ctx.setTransform(app.dimensions.dpr,0,0,app.dimensions.dpr,0,0);ctx.save();ctx.translate(app.view.x,app.view.y);ctx.scale(app.view.scale,app.view.scale);v096DrawConeTargets();ctx.restore();
  };
  const v096BaseOnPointerMove=onPointerMove;
  onPointerMove=function(event){
    const result=v096BaseOnPointerMove(event);
    if(app.actionTarget?.type==='shotgun-cone'){
      const info=v096ConePreviewInfo();if(info)setActionDescription(`Конус ${Number(info.weapon.coneFeet||0)} фт · в области ${info.targets.length} ${info.targets.length===1?'цель':'целей'}. Щёлкните для выстрела.`);
    }
    return result;
  };

  const v096BasePerformShotgunCone=v086PerformShotgunCone;
  v086PerformShotgunCone=async function(point){
    const action=app.actionTarget,attacker=tokenById(action?.attackerId);if(!action||!attacker||app.v096ConeStarting)return;
    app.v096ConeStarting=true;
    try{
      if(app.v096PendingTokenUpdates.has(attacker.id))setActionDescription('Сохраняется новая позиция токена…');
      await v096AwaitTokenUpdate(attacker);
      const preview=v096ConePreviewInfo();
      if(preview&&!preview.targets.length)toast('В выбранном конусе нет токенов. Выстрел всё равно будет произведён.','error');
      return await v096BasePerformShotgunCone(point);
    }finally{app.v096ConeStarting=false;}
  };

  function bindV088Ui(){
    $('token-group-create-btn')?.addEventListener('click',async()=>{const name=$('token-group-new-name').value.trim()||'Новая группа',color=$('token-group-new-color').value;try{await v088SaveGroups([...v088Groups(),{id:`group_${id()}`,name,color,moraleOnDeath:true}]);toast(`Создана группа «${name}».`,'success');}catch(error){toast(error.message,'error');}});
    $('token-group-list')?.addEventListener('click',async event=>{const rename=event.target.closest('[data-group-rename]'),del=event.target.closest('[data-group-delete]');if(rename){const group=v088Group(rename.dataset.groupRename),name=prompt('Новое название группы:',group?.name||'');if(name?.trim()){group.name=name.trim();await v088SaveGroups();}}else if(del){const group=v088Group(del.dataset.groupDelete);if(group&&confirm(`Удалить группу «${group.name}»? Токены останутся на сцене без группы.`))await v088SaveGroups(v088Groups().filter(item=>item.id!==group.id));}});
    $('token-group-list')?.addEventListener('change',async event=>{const check=event.target.closest('[data-group-morale]');if(!check)return;const group=v088Group(check.dataset.groupMorale);if(group){group.moraleOnDeath=check.checked;await v088SaveGroups();}});
    $('token-group-transfer-btn')?.addEventListener('click',v088TransferGroup);
    $('token-group')?.addEventListener('change',async()=>{const token=selectedToken();if(!master||!token)return;try{const result=await updateToken(token,{groupId:$('token-group').value||null});if(result.token)Object.assign(token,result.token);v088RenderGroups();requestRender();}catch(error){toast(error.message,'error');}});
    $('narrative-save-btn')?.addEventListener('click',()=>v088SaveNarrative(false));$('narrative-clear-btn')?.addEventListener('click',()=>v088SaveNarrative(true));$('combat-membership-toggle')?.addEventListener('click',v088ToggleCombatMembership);
    $('token-group-relation-save')?.addEventListener('click',v090SaveRelation);$('npc-ai-save')?.addEventListener('click',v090SaveAi);$('npc-ai-run')?.addEventListener('click',()=>v090RunAi({manual:true}));
  }



  /* ===== FATUM Battlemap v0.9.9: restore legacy mouse drag after attack modes ===== */
  app.v097LocalPositions=new Map();
  app.v097MouseDrag=null;
  app.v097ApiFlushDepth=0;

  function v097PositionState(token,create=false){
    if(!token?.id)return null;
    let state=app.v097LocalPositions.get(String(token.id));
    if(!state&&create){state={tokenId:String(token.id),sceneId:app.scene?.id||null,x:Number(token.x||0),y:Number(token.y||0),rotation:Number(token.rotation||0),pendingMovementFeet:0,version:0,dirty:false,savingPromise:null,timer:null};app.v097LocalPositions.set(String(token.id),state);}
    return state||null;
  }
  function v097RememberLocalPosition(token,movementFeet=0){
    const state=v097PositionState(token,true);if(!state)return null;
    state.sceneId=app.scene?.id||state.sceneId;state.x=Number(token.x||0);state.y=Number(token.y||0);state.rotation=Number(token.rotation||0);state.pendingMovementFeet+=Math.max(0,Number(movementFeet||0));state.version++;state.dirty=true;
    if(state.timer)clearTimeout(state.timer);
    state.timer=setTimeout(()=>{state.timer=null;v097FlushTokenPosition(state.tokenId).catch(async error=>{toast(error.message,'error');await refreshBattlemap();});},75);
    return state;
  }
  async function v097FlushTokenPosition(tokenOrId){
    const tokenId=String(typeof tokenOrId==='string'?tokenOrId:(tokenOrId?.id||''));if(!tokenId)return;
    const initial=app.v097LocalPositions.get(tokenId);if(!initial)return;
    if(initial.timer){clearTimeout(initial.timer);initial.timer=null;}
    if(initial.savingPromise)return initial.savingPromise;
    initial.savingPromise=(async()=>{
      while(true){
        const state=app.v097LocalPositions.get(tokenId);if(!state||!state.dirty)break;
        state.dirty=false;const version=state.version,delta=state.pendingMovementFeet;state.pendingMovementFeet=0;
        const token=tokenById(tokenId);if(!token||state.sceneId!==app.scene?.id){app.v097LocalPositions.delete(tokenId);break;}
        const desired={x:state.x,y:state.y,rotation:state.rotation};
        try{
          const result=await updateToken(token,{...desired,movementDeltaFeet:delta});
          const current=app.v097LocalPositions.get(tokenId);
          if(current&&current.version!==version){const live=tokenById(tokenId);if(live){live.x=current.x;live.y=current.y;live.rotation=current.rotation;app.tokenMotions?.delete(tokenId);requestRender();}}
          else if(current&&!current.dirty){app.v097LocalPositions.delete(tokenId);}
          if(result?.token&&app.v097LocalPositions.has(tokenId)){const keep=app.v097LocalPositions.get(tokenId),live=tokenById(tokenId);if(live){live.x=keep.x;live.y=keep.y;live.rotation=keep.rotation;}}
        }catch(error){const current=app.v097LocalPositions.get(tokenId);if(error?.status>=400&&error?.status<500){if(current?.timer)clearTimeout(current.timer);app.v097LocalPositions.delete(tokenId);}else if(current){current.dirty=true;current.pendingMovementFeet+=delta;current.timer=setTimeout(()=>{current.timer=null;v097FlushTokenPosition(tokenId).catch(()=>{});},500);}throw error;}
      }
    })();
    try{return await initial.savingPromise;}finally{const state=app.v097LocalPositions.get(tokenId);if(state)state.savingPromise=null;}
  }
  async function v097FlushAllPositions(){
    const ids=[...app.v097LocalPositions.keys()];for(const tokenId of ids)await v097FlushTokenPosition(tokenId);
    if(app.v096PendingTokenUpdates?.size){for(const promise of [...app.v096PendingTokenUpdates.values()])await promise.catch(()=>{});}
  }
  function v097IsTokenUpdateRequest(url,method){return method==='PUT'&&/^\/api\/battlemap\/scenes\/[^/]+\/tokens\/[^/?]+(?:\?|$)/.test(String(url||''));}
  const v097BaseApi=api;
  api=async function(url,options={}){
    const method=String(options?.method||'GET').toUpperCase();
    if(app.v097ApiFlushDepth===0&&!['GET','HEAD'].includes(method)&&!v097IsTokenUpdateRequest(url,method)){
      app.v097ApiFlushDepth++;
      try{await v097FlushAllPositions();}finally{app.v097ApiFlushDepth--;}
    }
    return v097BaseApi(url,options);
  };

  const v097BaseApplyBattlemap=applyBattlemap;
  applyBattlemap=function(battlemap,preserveSelection=true){
    const local=[...app.v097LocalPositions.values()].map(state=>({...state}));
    v097BaseApplyBattlemap(battlemap,preserveSelection);
    for(const state of local){if(state.sceneId!==app.scene?.id)continue;const token=tokenById(state.tokenId);if(!token)continue;token.x=state.x;token.y=state.y;token.rotation=state.rotation;app.tokenMotions?.delete(token.id);}
    requestRender();
  };

  // v0.9.8: для начала перетаскивания выбранный токен имеет приоритет
  // над другими токенами, которые могут случайно находиться в той же точке.
  // Это особенно важно для старых сцен, где после копирования или обновления
  // листа могли остаться совпадающие невидимые/служебные токены.
  function v098PointHitsToken(point,token){
    if(!point||!token||token.boardedVehicleId)return false;
    const visual=visualTokenState(token),radius=Math.max(1,Number(tokenRadius(token)||0));
    return Number.isFinite(visual?.x)&&Number.isFinite(visual?.y)&&Math.hypot(point.x-visual.x,point.y-visual.y)<=radius;
  }
  function v098TokenForMouseDrag(point){
    const selected=selectedToken();
    if(selected&&v098PointHitsToken(point,selected))return selected;
    return hitTestToken(point);
  }
  function v099RecoverMouseDragMode(token){
    if(!token)return;
    // В v0.9.0 перетаскивание обслуживал один обработчик. Начиная с v0.9.7
    // появился приоритетный обработчик, который ошибочно отказывался работать,
    // пока карта оставалась в скрытом режиме «Атака». Это состояние особенно
    // часто сохранялось после открытия быстрого окна дробовика.
    const selected=selectedToken();
    const draggingSelected=String(selected?.id||'')===String(token.id);
    if(app.actionTarget&&draggingSelected){
      if(typeof cancelDockTarget==='function')cancelDockTarget();
      else{app.actionTarget=null;app.pendingTargetPart=null;document.body.classList.remove('bm-targeting');}
    }
    if(draggingSelected&&app.tool==='attack')setTool('select');
    if(draggingSelected){
      app.quickAttack=null;
      if($('quick-attack'))$('quick-attack').hidden=true;
      document.body.classList.remove('bm-targeting');
    }
  }
  function v0911PointerReservedForTargeting(){
    // Нижняя панель намеренно оставляет инструмент `select`, а выбранное
    // действие хранит в app.actionTarget. Поэтому при выборе цели обработчик
    // перетаскивания обязан полностью уступить событие боевому обработчику.
    // Иначе мастер, который может управлять любым токеном, начинает тащить
    // цель, а игрок не может выбрать союзные/свои управляемые токены.
    return Boolean(app.actionTarget);
  }
  function v097CanStartMouseDrag(event){
    if(!app.scene||event.button!==0||app.spaceDown||app.pendingTokenPlacement||app.drawingDraft||app.v084ZoneDraft||v0911PointerReservedForTargeting())return null;
    const world=screenToWorld(eventPoint(event));
    // Ручка поворота остаётся отдельным элементом и не запускает перенос.
    if(typeof hitTestRotationHandle==='function'&&hitTestRotationHandle(world))return null;
    const token=v098TokenForMouseDrag(world);
    if(!token)return null;
    const selected=selectedToken(),draggingSelected=String(selected?.id||'')===String(token.id);
    // Инструменты рисования не должны превращаться в перенос. Но «Атака» —
    // восстанавливаемое состояние: клик-перетаскивание выбранного токена явно
    // означает, что пользователь хочет снова двигать его.
    if(app.tool!=='select'&&!(app.tool==='attack'&&draggingSelected))return null;
    if(app.speciesTarget&&!draggingSelected)return null;
    v099RecoverMouseDragMode(token);
    if(app.speciesTarget&&draggingSelected)app.speciesTarget=null;
    if(!canControlToken(token)||token.locked)return null;
    const critical=typeof v088Critical==='function'?v088Critical(token):null;if(critical?.critical&&!critical.dead){selectObject('token',token.id);toast('Критическое ранение: перемещение невозможно.','error');return null;}
    if(!master&&app.battlemap?.masterPause?.active){toast('Мастерская пауза: перемещение временно запрещено.','error');return null;}
    return{token,world};
  }
  function v097MousePointerDown(event){
    const start=v097CanStartMouseDrag(event);if(!start)return;
    const token=start.token,movement=movementForToken(token);
    app.tokenMotions?.delete(token.id);selectObject('token',token.id);
    app.v097MouseDrag={pointerId:event.pointerId,tokenId:token.id,start:start.world,origin:{x:token.x,y:token.y},last:{x:token.x,y:token.y},pathFeet:0,movementStart:movement?{spent:Number(movement.spent||0),limit:Number(movement.limit||0),remaining:Number(movement.remaining||0)}:null,moved:false};
    canvas.setPointerCapture?.(event.pointerId);event.preventDefault();event.stopImmediatePropagation();
  }
  function v097MousePointerMove(event){
    const drag=app.v097MouseDrag;if(!drag||drag.pointerId!==event.pointerId)return;
    const token=tokenById(drag.tokenId);if(!token){app.v097MouseDrag=null;return;}
    const world=screenToWorld(eventPoint(event));let next={x:drag.origin.x+(world.x-drag.start.x),y:drag.origin.y+(world.y-drag.start.y)};next=snapPoint(next);next={x:clamp(next.x,0,app.scene.mapWidth),y:clamp(next.y,0,app.scene.mapHeight)};
    const remaining=drag.movementStart?Math.max(0,drag.movementStart.remaining-drag.pathFeet):null;next=clampMoveToBudget(drag.last,next,remaining);
    if(clientMovementBlocked(token,drag.last,next)){event.preventDefault();event.stopImmediatePropagation();return;}
    const segmentFeet=pixelsToFeet(Math.hypot(next.x-drag.last.x,next.y-drag.last.y));if(segmentFeet>.001){v080ApplyAutoRotation(token,drag.last,next);drag.pathFeet+=segmentFeet;drag.last={...next};drag.moved=true;token.x=next.x;token.y=next.y;if(drag.movementStart)token.movement={spent:Math.round((drag.movementStart.spent+drag.pathFeet)*10)/10,limit:drag.movementStart.limit,remaining:Math.max(0,Math.round((drag.movementStart.remaining-drag.pathFeet)*10)/10)};refreshActionDock();requestRender();}
    event.preventDefault();event.stopImmediatePropagation();
  }
  async function v097MousePointerUp(event){
    const drag=app.v097MouseDrag;if(!drag||drag.pointerId!==event.pointerId)return;
    app.v097MouseDrag=null;try{canvas.releasePointerCapture?.(event.pointerId);}catch{}
    event.preventDefault();event.stopImmediatePropagation();
    const token=tokenById(drag.tokenId);if(!token||!drag.moved)return;
    v097RememberLocalPosition(token,drag.pathFeet);
    try{await v097FlushTokenPosition(token.id);}catch(error){toast(error.message,'error');await refreshBattlemap();}
  }

  moveSelectedByKeyboard=function(dx,dy,fine=false){
    const token=selectedToken();if(!token||!canControlToken(token)||token.locked||!app.scene)return;
    const critical=typeof v088Critical==='function'?v088Critical(token):null;if(critical?.critical&&!critical.dead){toast('Критическое ранение обездвиживает персонажа.','error');return;}
    if(!master&&app.battlemap?.masterPause?.active){toast('Мастерская пауза: перемещение временно запрещено.','error');return;}
    const step=fine?app.scene.grid.size/5:app.scene.grid.size,from={x:token.x,y:token.y};let next={x:clamp(token.x+dx*step,0,app.scene.mapWidth),y:clamp(token.y+dy*step,0,app.scene.mapHeight)};next=clampMoveToRemaining(token,from,next);
    if(Math.hypot(next.x-from.x,next.y-from.y)<.1){toast('Запас движения на этот ход исчерпан.','error');return;}
    if(clientMovementBlocked(token,from,next)){toast('Путь перекрыт стеной или закрытой дверью.','error');return;}
    const movementFeet=pixelsToFeet(Math.hypot(next.x-from.x,next.y-from.y));consumeLocalMovement(token,from,next);v080ApplyAutoRotation(token,from,next);token.x=next.x;token.y=next.y;app.tokenMotions?.delete(token.id);v097RememberLocalPosition(token,movementFeet);requestRender();refreshActionDock();
  };

  function bindV097Ui(){
    canvas.addEventListener('pointerdown',v097MousePointerDown,true);
    canvas.addEventListener('pointermove',v097MousePointerMove,true);
    canvas.addEventListener('pointerup',v097MousePointerUp,true);
    canvas.addEventListener('pointercancel',v097MousePointerUp,true);
    window.addEventListener('beforeunload',()=>{for(const state of app.v097LocalPositions.values())if(state.timer)clearTimeout(state.timer);});
  }

  // v1.0.0 — медицинские действия, корректная фиксация источника расходника
  // и приоритет выбора критически раненой цели над обычным выделением токена.
  app.medicalPending=false;
  function beginStabilizationTarget(){
    const token=selectedToken();if(!token||!canControlToken(token))return;
    app.actionTarget={type:'stabilize',attackerId:token.id};
    document.body.classList.add('bm-targeting');setTool('select');
    setActionDescription('Выберите соседнего персонажа или NPC в Критическом ранении.');
    toast('Выберите критически раненую цель для Стабилизации.');requestRender();
  }
  async function performStabilization(target){
    const action=app.actionTarget,source=tokenById(action?.attackerId);if(!action||!source||!target||app.medicalPending)return;
    app.medicalPending=true;
    try{
      const result=await api('/api/battlemap/medical-action',{method:'POST',body:commonBody({requestId:id(),sceneId:app.scene.id,tokenId:source.id,targetTokenId:target.id,action:'stabilize'})});
      if(result.roll)startRollVisual(result.roll);if(result.entry)appendTableLogClient(result.entry);
      const success=result.success,criticalFailure=result.outcome==='critical-failure';
      toast(result.resultText||'Проверка Стабилизации завершена.',success?'success':criticalFailure?'error':'error');
      await fetchAll(true);
    }catch(error){toast(error.message,'error');}
    finally{app.medicalPending=false;cancelDockTarget();}
  }

  const v100BaseRefreshActionDock=refreshActionDock;
  refreshActionDock=function(){
    v100BaseRefreshActionDock();
    const token=selectedToken(),slots=$('action-slots');if(!token||!slots||$('action-dock').hidden||!['character','npc'].includes(token.kind)||!canControlToken(token))return;
    const critical=typeof v088Critical==='function'?v088Critical(token):null;if(critical?.critical||critical?.dead)return;
    if(!slots.querySelector('[data-dock-action="medical-stabilize"]'))slots.insertAdjacentHTML('beforeend',actionButtonHtml('medical-stabilize','✚','Стабилизировать',2,'Проверка Медицины против 1к6 по соседней цели в Критическом ранении. Успех снимает Критическое ранение и Кровотечение.','medical'));
    const button=slots.querySelector('[data-dock-action="medical-stabilize"]');if(button){button.disabled=combatActive()&&!combatCanAct(token);button.onmouseenter=()=>setActionDescription(button.title);button.onmouseleave=()=>setActionDescription(app.actionTarget?'Выберите критически раненую цель.':'Выберите действие.');}
  };

  const v100BaseOnPointerDown=onPointerDown;
  onPointerDown=function(event){
    const action=app.actionTarget;
    if(action&&event.button===0&&app.scene&&(action.type==='item'||action.type==='stabilize')){
      const source=tokenById(action.attackerId),target=hitTestToken(screenToWorld(eventPoint(event)));
      event.preventDefault();
      if(!target||!['character','npc'].includes(target.kind)){toast('Щёлкните по токену персонажа или NPC.','error');return;}
      if(action.type==='item'){useMapItem(action.item,target,source).finally(cancelDockTarget);return;}
      if(!source||target.id===source.id||(source.kind===target.kind&&source.refId&&source.refId===target.refId)){toast('Стабилизацию должен проводить другой персонаж.','error');return;}
      const critical=typeof v088Critical==='function'?v088Critical(target):null;
      if(!critical?.critical||critical.dead){toast('Цель должна быть жива и находиться в Критическом ранении.','error');return;}
      performStabilization(target);return;
    }
    return v100BaseOnPointerDown(event);
  };

  function bindV100Ui(){
    $('action-slots').addEventListener('click',event=>{const button=event.target.closest('[data-dock-action="medical-stabilize"]');if(!button||button.disabled)return;event.preventDefault();event.stopImmediatePropagation();beginStabilizationTarget();},true);
  }
  function bindV101Ui(){
    if(!master)openPanel('combat');
  }

  async function init(){bindUi();bindV052Ui();bindV053Ui();bindV054Ui();bindV055Ui();bindV057Ui();bindV0511Ui();bindV061Ui();bindV070Ui();bindV073Ui();bindV076Ui();bindV077Ui();bindV078Ui();bindV081Ui();bindV083Ui();bindV084Ui();bindV085Ui();bindV086Ui();bindV088Ui();bindV091Ui();bindV094Ui();bindV097Ui();bindV100Ui();bindV101Ui();resizeCanvas();setTool('select');try{setStatus('Загрузка…');await fetchAll();if(params.get('noSse')!=='1')connectEvents();setStatus('Синхронизация активна','connected');if(app.scene)fitView();}catch(error){console.error(error);setStatus('Ошибка подключения','error');toast(error.message,'error');}}

  init();
})();
