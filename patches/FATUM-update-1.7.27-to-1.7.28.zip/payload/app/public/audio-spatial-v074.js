'use strict';

(function initFatumAudioSpatial(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.FatumAudioSpatial = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function createFatumAudioSpatial() {
  function clamp(value, min, max) {
    const number = Number(value);
    if (!Number.isFinite(number)) return min;
    return Math.max(min, Math.min(max, number));
  }

  function distanceFeet(source, listener, grid) {
    const gridSize = Math.max(1, Number(grid?.size) || 50);
    const gridFeet = Math.max(0.001, Number(grid?.feet) || 5);
    const dx = (Number(source?.x) || 0) - (Number(listener?.x) || 0);
    const dy = (Number(source?.y) || 0) - (Number(listener?.y) || 0);
    return Math.hypot(dx, dy) / gridSize * gridFeet;
  }

  function attenuation(distance, radius, curve = 'soft') {
    const safeRadius = Math.max(0.001, Number(radius) || 0.001);
    const normalized = clamp(1 - Math.max(0, Number(distance) || 0) / safeRadius, 0, 1);
    if (curve === 'linear') return normalized;
    if (curve === 'sharp') return normalized * normalized;
    return Math.sqrt(normalized);
  }

  function computeMix(options = {}) {
    const source = options.source || {};
    const listener = options.listener || { x: 0, y: 0 };
    const radius = Math.max(1, Number(source.radius) || 60);
    const distance = distanceFeet(source, listener, options.grid || {});
    const enabled = source.enabled !== false;
    const spatialEnabled = options.spatialEnabled !== false;
    const inside = enabled && spatialEnabled && distance <= radius;
    const fade = inside ? attenuation(distance, radius, source.falloff || 'soft') : 0;
    const sourceVolume = clamp(source.volume ?? 0.8, 0, 1);
    const localVolume = clamp(options.localVolume ?? 1, 0, 1);
    const volume = clamp(sourceVolume * localVolume * fade, 0, 1);
    const radiusPixels = radius / Math.max(0.001, Number(options.grid?.feet) || 5) * Math.max(1, Number(options.grid?.size) || 50);
    const dx = (Number(source.x) || 0) - (Number(listener.x) || 0);
    const pan = inside ? clamp(dx / Math.max(1, radiusPixels), -1, 1) : 0;
    return { distance, radius, inside, fade, volume, pan, enabled, spatialEnabled };
  }

  return { clamp, distanceFeet, attenuation, computeMix };
});
