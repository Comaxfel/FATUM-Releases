/* FATUM: ToL map adapter.
 * ToL changes rules, not the Battlemap UX: this file deliberately reuses
 * Classic's action dock, quick picker and non-blocking roll-reaction layer.
 */
(function(){
'use strict';

const $=id=>document.getElementById(id);
const esc=value=>String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const uuid=()=>crypto.randomUUID?.()||`tol_${Date.now()}_${Math.random().toString(36).slice(2)}`;

let data=null;
let catalog=null;
let bridge=null;
let selected=null;
let loading=null;
let pick=null;
let campaignId=null;
let installed=false;
let quickContext=null;
let reactionBusy=false;
let selectedSuperiority=new Map();

const icons={
 attack:'⌖',aim:'◎',stance:'◈',dash:'»',withdraw:'↩',charge:'➤',intercept:'⟂',grapple:'✊',escape:'↗',jump:'⌃',climb:'⇡',stand:'↥',mount:'♞',dismount:'⇣',counter:'↯',
 reload:'↻',items:'🧰',skills:'🎲',features:'✦',mastery:'✥',character:'♟',beliefs:'◈',magic:'✧',heal:'✚',sheet:'▤',fullSheet:'▦',next:'↪',coin:'◆',fortune:'✤',edge:'≈',move:'⇢'
};

function actionButton(label,action,args={},cost=null,description='',disabled=false,icon='•',extra=''){
 if(!bridge?.dockButton)throw new Error('Classic action dock renderer is unavailable.');
 return bridge.dockButton({label,action,args,cost,description:description||label,disabled,icon,extra});
}
function rootOptions(){return window.TolOptions;}
function recordByActorId(actorId){return data?.campaign?.characters?.find(row=>row.id===actorId)||null;}
function actorById(actorId){return recordByActorId(actorId)?.state||null;}
function tokenByActorId(actorId){return bridge?.scene()?.tokens?.find(token=>token.refId===actorId)||null;}
function actorFaction(actor){const explicit=String(actor?.faction||'');if(['party','enemy','neutral'].includes(explicit))return explicit;return actor?.isCreature&&!actor?.isMount&&!actor?.isVehicle?'enemy':'party';}
function actorsHostile(a,b){const x=actorFaction(a),y=actorFaction(b);return (x==='party'&&y==='enemy')||(x==='enemy'&&y==='party');}
function actorEngaged(actor){return !!actor&&data?.campaign?.characters?.some(row=>row.state?.id!==actor.id&&actorsHostile(actor,row.state)&&bridge.distance?.(actor.id,row.state.id)<=5.01);}
function otherEnemiesNearby(actor,exceptId){return !!actor&&data?.campaign?.characters?.some(row=>row.state?.id!==actor.id&&row.state?.id!==exceptId&&actorsHostile(actor,row.state)&&bridge.distance?.(actor.id,row.state.id)<=5.01);}
function spellConfig(spell){return data?.tol?.settings?.spells?.[spell?.id]||{};}
function configuredSpellRange(spell){const value=Number(spellConfig(spell).range);return Number.isFinite(value)&&value>0?value:0;}
function woundSeverityLabel(severity){return ({1:'Лёгкое',2:'Среднее',3:'Серьёзное',4:'Критическое'})[Number(severity)]||`Тяжесть ${severity}`;}
function ownedActor(){return actorById(selected?.refId);}
function profileForItem(item){return catalog?.weapons?.find(profile=>profile.id===item.profileId);}
function propertiesOf(weapon){return Array.isArray(weapon?.properties)?weapon.properties.join(' '):String(weapon?.properties||'');}
function weaponDamageLabel(weapon){return ({slash:'Р',pierce:'К',blunt:'Д'})[weapon?.damageType]||String(weapon?.damageType||'');}
function weaponRangeLabel(weapon){return weapon?.kind==='melee'?`${Number(weapon.reach||5)} фт`:`${Number(weapon.range||0)} фт`;}
function equippedWeapons(actor){
 const list=(actor?.inventory||[]).filter(item=>item.kind==='weapon'&&item.equipped&&!item.thrown).map(item=>({...profileForItem(item),id:item.id,name:item.model||item.name})).filter(weapon=>weapon.kind);
 if(actor?.isCreature)list.push(...(actor.creatureAttacks||[]).map((weapon,index)=>({...weapon,id:`creature-${index}`})));
 list.push({id:'unarmed',name:'Безоружный бой',cost:2,kind:'melee',die:4,damage:1,damageType:'blunt',reach:5,properties:[],category:'Безоружный бой'});
 if(['gnoll','kuthi','gvined'].includes(actor?.species)||(actor?.effects||[]).some(effect=>effect.key==='predator'))list.push({id:'natural',name:'Естественное оружие',cost:2,kind:'melee',die:actor?.species==='gnoll'||actor?.species==='gvined'?6:4,damage:actor?.species==='gnoll'||actor?.species==='gvined'?2:1,damageType:actor?.species==='gvined'?'slash':'pierce',reach:5,properties:[],category:'Безоружный бой'});
 return list;
}
function reloadableWeapons(actor){return equippedWeapons(actor).filter(weapon=>['bow','crossbow','firearm'].includes(weapon.kind)&&!['unarmed','natural'].includes(weapon.id));}
function tacticalAvailable(actor,key){
 if(key==='brace')return equippedWeapons(actor).some(weapon=>weapon.kind==='melee'&&propertiesOf(weapon).includes('Упор'))||(actor.effects||[]).some(effect=>effect.key==='brace');if(!['counter','escape','stand','dismount','intercept'].includes(key))return true;
 if(key==='dismount')return Boolean(actor.mounted);
 if(key==='intercept')return data?.campaign?.characters?.some(row=>row.state?.effects?.some(effect=>effect.key==='charge'&&effect.targetId===actor.id));
 return (actor.effects||[]).some(effect=>effect.key===({counter:'counter',escape:'bound',stand:'prone'}[key]));
}
function canActNow(actor){
 const active=data?.campaign?.initiative?.entries?.[data.campaign.initiative.currentIndex]?.refId;
 return Boolean(bridge?.combat()&&active===actor?.id&&!actor?.medical?.dead&&!actor?.wounds?.critical);
}

async function load(){
 if(!bridge||loading)return loading;
 loading=(async()=>{
  const session=bridge.session();
  const response=await fetch(`/api/tol/state?mode=${session.mode}&clientId=${encodeURIComponent(session.clientId)}`,{headers:{'X-Fatum-Presence-Token':session.presenceToken||''}});
  if(!response.ok)return;
  const next=await response.json();
  if(campaignId&&campaignId!==next.campaign.campaignId){location.reload();return;}
  campaignId=next.campaign.campaignId;
  data=next;
  if(!catalog)catalog=await (await fetch('/tol/catalog.json')).json();
  render();
  window.dispatchEvent(new CustomEvent('fatum-tol-state-loaded',{detail:{revision:data?.tol?.revision??null,reactionIds:(data?.tol?.reactions||[]).map(item=>item.id)}}));
 })().catch(error=>bridge.toast(error.message,'error')).finally(()=>loading=null);
 return loading;
}

function bindQuickDescriptions(){
 document.querySelectorAll('#quick-weapon-list [data-tol-desc]').forEach(button=>{
  button.onmouseenter=()=>bridge.describe?.(button.dataset.tolDesc);
  button.onmouseleave=()=>bridge.describe?.(pick?'Выберите цель на карте.':'Выберите действие.');
 });
}

function render(){
 const dock=$('action-dock');
 if(!selected||selected.ruleset!=='tol'||!data||!catalog){if(dock&&selected?.ruleset==='tol')dock.hidden=true;syncReactionPanels();return;}
 const actor=ownedActor();if(!actor){dock.hidden=true;syncReactionPanels();return;}
 if(!bridge?.dockAvailable)throw new Error('Classic action dock availability check is unavailable.');
 if(actor.medical?.dead||!bridge.dockAvailable(actor.id)){dock.hidden=true;syncReactionPanels();return;}
 dock.hidden=false;document.documentElement.dataset.ruleset='tol';
 const reserve=Number(actor.traits?.initial?.['Бережливый']||0)>0?` · Запас ${actor.resources.reserve}/${actor.traits.initial['Бережливый']}`:'';
 if(!bridge?.dockHeader)throw new Error('Classic action dock header renderer is unavailable.');
 bridge.dockHeader({actorId:actor.id,resourceText:`ОД ${actor.odCurrent}/${actor.od} · Мораль ${actor.morale.current}/${actor.morale.max} · БЗ ${actor.bz}/${actor.armorBzMax}${reserve} · Напр. ${actor.resources.tension}`,wounds:{light:actor.wounds.light,lightMax:actor.wounds.lightMax,medium:actor.wounds.medium,mediumMax:actor.wounds.mediumMax,serious:actor.wounds.serious,seriousMax:actor.wounds.seriousMax,critical:actor.wounds.critical,bleeding:actor.medical.bleeding,dead:actor.medical.dead}});

 const inCombat=bridge.combat(),incapacitated=actor.medical.dead||actor.wounds.critical,canAct=canActNow(actor);
 let html='';
 for(const weapon of equippedWeapons(actor)){
  const availability=attackAvailability(actor,weapon,null),universal=/Универс/.test(propertiesOf(weapon)),realBowAmmo=weapon.kind!=='bow'||weaponAmmoCount(actor,weapon)>0,baseDisabled=!canAct||!availability.ok||!realBowAmmo;
  const modes=universal?[['slash',' · Рубящий'],['pierce',' · Колющий']]:[[null,'']];
  for(const [damageType,suffix] of modes)html+=actionButton(`${weapon.name}${suffix}`,'attack-weapon-target',{weaponId:weapon.id,damageType:damageType||undefined},Number(weapon.cost||2),`${weapon.kind==='melee'?'Удар':'Выстрел'} · 1к${Number(weapon.die||4)} · урон ${Number(weapon.damage||0)} ${weaponDamageLabel(weapon)} · ${weaponRangeLabel(weapon)}${availability.ok?'':` · ${availability.reason}`}`,baseDisabled,weapon.kind==='melee'?icons.attack:'⌖','weapon');
  if(weapon.kind==='bow'&&availability.ok&&canUseReserve(actor))for(const [damageType,suffix] of modes)html+=actionButton(`${weapon.name} · Запас${suffix}`,'attack-weapon-target',{weaponId:weapon.id,damageType:damageType||undefined,reserve:true},Number(weapon.cost||2),`Выстрел без расхода стрелы · Запас ${Number(actor.resources.reserve||0)}`,!canAct, '⌖','weapon');
  for(const mastery of availableAttackMasteries(actor,weapon,null)){const masteryName=mastery.extra.mastery||mastery.name;for(const [damageType,suffix] of modes)html+=actionButton(`${weapon.name} · ${mastery.name}${suffix}`,'attack-weapon-target',{weaponId:weapon.id,damageType:damageType||undefined,mastery:masteryName,...mastery.extra},Number(weapon.cost||2),mastery.meta,!canAct||!availability.ok||!realBowAmmo,weapon.kind==='melee'?icons.attack:'⌖','weapon');}
 }
 for(const [key,label,cost] of rootOptions().tactical.filter(([key])=>tacticalAvailable(actor,key))){
  const reaction=['counter','intercept'].includes(key),toggleEffect=(actor.effects||[]).find(effect=>effect.key===key&&effect.toggleAction===key),toggleActive=!!toggleEffect&&!toggleEffect.toggleUsed;
  const disabled=incapacitated||(!reaction&&!canAct)||(reaction&&!inCombat)||(!reaction&&!toggleActive&&actor.odCurrent<cost);
  const mountToggle=key==='mount'&&toggleActive&&actor.mounted;
  const direct=['aim','stance','dash','withdraw','brace','stand','dismount','counter'].includes(key)||mountToggle;
  const targeted=['charge','grapple'].includes(key)||(key==='mount'&&!mountToggle);
  const action=['jump','climb'].includes(key)?'tactical-check':direct?'tactical':targeted?'tactical-target':key==='escape'?'escape-picker':key==='intercept'?'intercept-picker':'tactical';
  const args={tactical:key};if(targeted)args.pickTarget=true;if(key==='counter')args.targetId=(actor.effects||[]).find(effect=>effect.key==='counter')?.targetId||null;
  html+=actionButton(label,action,args,cost,toggleActive?`${label}: нажмите ещё раз, чтобы отменить и вернуть ОД.`:label,disabled,icons[key]||'◇',toggleActive?'active':'');
 }
 for(const weapon of reloadableWeapons(actor)){
  const ready=actor.ready?.[weapon.id]||{},ammo=weaponAmmoCount(actor,weapon),reserve=canUseReserve(actor),used=actor.used?.combat||{};
  if(weapon.kind==='bow'){const cost=weapon.name==='Тяжёлый боевой лук'?2:1;html+=actionButton(`${ready.drawn?'Натянут':'Натянуть'}: ${weapon.name}`,'reload',{weaponId:weapon.id},cost,ready.drawn?'Лук уже готов к выстрелу.':'Подготовить лук к выстрелу.',incapacitated||!!ready.drawn,icons.reload,'weapon');continue;}
  const capacity=Number(weapon.capacity||1),loaded=Number(ready.loaded||0),full=loaded>=capacity,cost=Number(weapon.reload||1),movedHeavy=weapon.kind==='crossbow'&&weapon.name==='Тяжёлый арбалет'&&actor.moved;
  html+=actionButton(`Перезарядить: ${weapon.name}`,'reload',{weaponId:weapon.id},cost,`Заряжено ${loaded}/${capacity} · боеприпасы ${ammo}`,incapacitated||full||ammo<=0||movedHeavy,icons.reload,'weapon');
  if(weapon.kind==='crossbow'&&reserve&&!full&&!movedHeavy)html+=actionButton(`${weapon.name} · Запас`,'reload',{weaponId:weapon.id,reserve:true},cost,`Не расходовать болт · Запас ${actor.resources.reserve}`,incapacitated,icons.reload,'weapon');
  if(weapon.kind==='crossbow'&&actor.mastery?.includes('Арбалетчик')&&!used['Арбалетчик']&&!full){html+=actionButton(`${weapon.name} · Арбалетчик`,'reload',{weaponId:weapon.id,mastery:'Арбалетчик'},Math.max(1,cost-1),'Перезарядка на 1 ОД дешевле.',incapacitated||ammo<=0,icons.reload,'weapon');if(reserve)html+=actionButton(`${weapon.name} · Арбалетчик + Запас`,'reload',{weaponId:weapon.id,mastery:'Арбалетчик',reserve:true},Math.max(1,cost-1),`Снижение ОД · Запас ${actor.resources.reserve}`,incapacitated,icons.reload,'weapon');}
 }
 const pavise=(actor.inventory||[]).find(item=>item.kind==='shield'&&item.equipped&&item.profileId==='shields-4');if(pavise)html+=actionButton('Установить Павезу','pavise-point',{itemId:pavise.id},1,'Поставить Павезу в соседнюю клетку как небольшое укрытие.',!canAct,icons.shield||'▣','weapon');
 html+=actionButton('Предметы','category',{category:'items'},null,'Предметы и ремонт',false,icons.items)
  +actionButton('Навыки','check-popover',{},null,'Проверки навыков',false,icons.skills)
  +actionButton('Особенности','category',{category:'features'},null,'Черты и способности Вида',false,icons.features)
  +actionButton('Мастерство','category',{category:'mastery'},null,'Выбранные Мастерства',false,icons.mastery)
  +actionButton('Характер','category',{category:'character'},null,'Черты характера',false,icons.character)
  +actionButton('Убеждения','category',{category:'beliefs'},null,'Убеждения и Стержень',false,icons.beliefs)
  +actionButton('Магия','category',{category:'magic'},null,'Известные формулы',false,icons.magic)
  +actionButton('Помощь','heal-target',{},null,'Первая помощь и стабилизация',false,icons.heal)
  +actionButton(actor.isCreature?'Лист NPC':'Мини-лист','mini-sheet',{},null,actor.isCreature?'Открыть компактный профиль NPC':'Открыть компактный лист над картой',false,icons.sheet)
  +(actor.isCreature?'':actionButton('Полный лист','full-sheet',{tab:'combat'},null,'Открыть полный лист персонажа',false,icons.fullSheet));
 if((actor.effects||[]).some(effect=>effect.key==='casting'&&effect.interrupted))html+=actionButton('Удержать ритуал','ritual-hold',{},null,'Попытаться удержать прерванный ритуал',false,icons.magic);
 const free=(actor.effects||[]).find(effect=>effect.key==='free-move');if(free){const movesOther=free.moveTargetId&&free.moveTargetId!==actor.id;html+=actionButton(`${movesOther?'Сместить цель':'Сместиться'} ${free.feet} фт`,'free-move',{effectId:free.id,pickPoint:true,originActorId:free.moveTargetId||actor.id,maxRange:Number(free.feet||0),actorId:actor.id},0,free.description,false,icons.move);}
 if(!bridge?.dockSlots||!bridge?.dockVttButtons)throw new Error('Classic action dock slot renderer is unavailable.');
 html+=bridge.dockVttButtons(actor.id);
 bridge.dockSlots({html,targeting:()=>Boolean(pick),targetingText:'Выберите цель на карте.',idleText:'Выберите действие.'});
 syncReactionPanels();
}

function showMiniSheet(actor=ownedActor()){
 if(!actor||!bridge?.miniSheet)return;
 if(actor.isCreature){const attacks=actor.creatureAttacks||[],armor=actor.naturalArmor||{},w=actor.wounds||{},m=actor.morale||{};const html=`<div class="bm-mini-stat"><span>Роль</span><strong>${esc(actor.creatureRole||actor.creatureRank||'NPC')}</strong></div><div class="bm-mini-stat"><span>ОД</span><strong>${Number(actor.odCurrent||0)}/${Number(actor.od||actor.creatureOd||3)}</strong></div><div class="bm-mini-stat"><span>Мораль</span><strong>${Number(m.current||0)}/${Number(m.max||actor.creatureMorale||10)}</strong></div><div class="bm-mini-stat"><span>Скорость</span><strong>${Number(actor.creatureSpeed||30)} фт</strong></div><div class="bm-mini-stat"><span>Ранения</span><strong>${Number(w.light||0)}/${Number(w.medium||0)}/${Number(w.serious||0)}${w.critical?' · крит.':''}${actor.medical?.bleeding?' · кровь':''}</strong></div><div class="bm-mini-stat"><span>Броня Р/К/Д</span><strong>${Number(armor.slash||0)}/${Number(armor.pierce||0)}/${Number(armor.blunt||0)}</strong></div>${attacks.length?`<h3>Атаки</h3>${attacks.map(x=>`<div class="bm-mini-stat"><span>${esc(x.name||'Атака')}</span><strong>1к${Number(x.die||6)} · урон ${Number(x.damage||0)} · ${Number(x.reach||5)} фт</strong></div>`).join('')}`:''}${actor.creatureAbilities?`<h3>Особенности</h3><div class="bm-mini-stat"><span></span><strong>${esc(actor.creatureAbilities)}</strong></div>`:''}`;bridge.miniSheet({title:actor.name||'NPC',html});return;}
 const reserveMax=Number(actor.traits?.initial?.['Бережливый']||0),armor=(actor.inventory||[]).find(item=>item.kind==='armor'&&item.equipped),shield=(actor.inventory||[]).find(item=>item.kind==='shield'&&item.equipped),weapons=equippedWeapons(actor).filter(weapon=>!['unarmed','natural'].includes(String(weapon.id)));
 const wounds=[`Лёгкие ${actor.wounds?.light||0}/${actor.wounds?.lightMax||0}`,`Средние ${actor.wounds?.medium||0}/${actor.wounds?.mediumMax||0}`,`Серьёзные ${actor.wounds?.serious||0}/${actor.wounds?.seriousMax||0}`,actor.wounds?.critical?'Критическое':''].filter(Boolean).join(' · ');
 let html=`<div class="bm-mini-stat"><span>ОД</span><strong>${Number(actor.odCurrent||0)}/${Number(actor.od||0)}</strong></div><div class="bm-mini-stat"><span>Мораль</span><strong>${Number(actor.morale?.current||0)}/${Number(actor.morale?.max||0)}</strong></div><div class="bm-mini-stat"><span>БЗ</span><strong>${Number(actor.bz||0)}/${Number(actor.armorBzMax||0)}</strong></div><div class="bm-mini-stat"><span>Напряжение</span><strong>${Number(actor.resources?.tension||0)}</strong></div>`;
 if(reserveMax>0)html+=`<div class="bm-mini-stat"><span>Запас</span><strong>${Number(actor.resources?.reserve||0)}/${reserveMax}</strong></div>`;
 html+=`<div class="bm-mini-stat"><span>Ранения</span><strong>${esc(wounds||'Нет')}</strong></div>`;
 if(armor||shield){html+='<h3>Защита</h3>';if(armor)html+=`<div class="bm-mini-stat"><span>Броня</span><strong>${esc(armor.model||armor.name||'Надета')}</strong></div>`;if(shield)html+=`<div class="bm-mini-stat"><span>Щит</span><strong>${esc(shield.model||shield.name||'Экипирован')}</strong></div>`;}
 if(weapons.length){html+='<h3>Оружие</h3>'+weapons.map(weapon=>`<div class="bm-mini-stat"><span>${esc(weapon.name)}</span><strong>1к${Number(weapon.die||4)} · урон ${Number(weapon.damage||0)} ${esc(weaponDamageLabel(weapon))}</strong></div>`).join('');}
 bridge.miniSheet({title:actor.name||'Персонаж',html});
}
function openFullSheet(tab='combat'){const actor=ownedActor();if(actor?.isCreature)return showMiniSheet(actor);if(!selected?.refId||!bridge?.openFullSheet)return;hideQuickPopup();bridge.openFullSheet(selected.refId,tab);}

function hideQuickPopup(){if(!bridge?.hideQuick)throw new Error('Classic quick-attack shell is unavailable.');bridge.hideQuick();quickContext=null;}
function showCompactMenu(title,entries,token=selected){
 quickContext={type:'menu'};
 if(!bridge?.quickRow||!bridge?.showQuick)throw new Error('Classic quick-attack renderer is unavailable.');
 const rowsHtml=entries.map(entry=>bridge.quickRow({name:entry.name,meta:entry.meta||'',buttons:[{label:entry.button||'Выбрать',primary:entry.primary!==false,disabled:!!entry.disabled,action:entry.action,args:entry.args||{},description:entry.description||entry.name}]})).join('')||'<div class="bm-muted">Нет доступных действий.</div>';
 bridge.showQuick({title,rowsHtml,actorId:token?.refId||null});bindQuickDescriptions();
}

function availableAttackMasteries(actor,weapon,targetActor){
 const used=actor?.used?.combat||{},chosen=new Set(actor?.mastery||[]),props=propertiesOf(weapon),out=[];
 const add=(name,meta='',extra={})=>{if(chosen.has(name)&&!used[name])out.push({name,meta,extra});};
 if(weapon.kind==='melee'&&weapon.category==='Клинковое')add('Фехтовальщик','Преимущество; усиленное Превосходство');
 if(weapon.kind==='melee'&&(!targetActor||!otherEnemiesNearby(actor,targetActor.id)))add('Дуэлянт','+1к4, если рядом нет других противников');
 if(weapon.category==='Ударное')add('Молотобоец','Бронебойность +1');
 if((actor.effects||[]).some(e=>e.key==='hidden'))add('Засадник','+1к4 из Скрытности; после атаки 5 футов');
 if(weapon.kind==='bow'&&!actorEngaged(actor)&&!(actor.effects||[]).some(e=>e.key==='charge'))add('Лучник','+1к4 к выстрелу');
 if(weapon.kind==='firearm'){add('Стрелок древности','+1к4 к атаке',{ignorePenalty:false});add('Стрелок древности · позиция','Игнорировать один штраф',{ignorePenalty:true,mastery:'Стрелок древности'});}
 if(weapon.kind==='thrown')add('Метатель','После атаки смещение к оружию на 5 футов');
 return out;
}
function attackAvailability(actor,weapon,target){
 const distance=target?bridge.distance?.(actor.id,target.id):0;
 if(target&&Number.isFinite(distance)){const max=weapon.kind==='melee'?Number(weapon.reach||5):Number(weapon.range||0);if(distance>max+.01)return {ok:false,reason:`цель дальше ${max} футов`};}
 if((actor.effects||[]).some(e=>e.key==='soul-out'))return {ok:false,reason:'тело обездвижено'};
 if((actor.effects||[]).some(e=>e.key==='bound')&&Number(weapon.reach||0)>=10)return {ok:false,reason:'длинное оружие неприменимо в Захвате'};
 const ready=actor.ready?.[weapon.id]||{};
 if(weapon.kind==='bow'){
  const required=Number(String(weapon.requirement||'').match(/\d+/)?.[0]||0),strong=Number(actor.traits?.main?.['Сильный']||0),strength=(strong>=5?3:Math.floor(strong/2))+Number(actor.skillBonuses?.['Физическая сила']||0);
  if(required&&strength<required)return {ok:false,reason:`требуется Сила ${required}`};
  if(!ready.drawn)return {ok:false,reason:'сначала натяните лук'};
  if(weapon.name==='Тяжёлый боевой лук'&&actorEngaged(actor))return {ok:false,reason:'тяжёлый лук нельзя использовать под давлением'};
  if(weaponAmmoCount(actor,weapon)<=0&&!canUseReserve(actor))return {ok:false,reason:'нет стрел или Запаса'};
 }
 if(['crossbow','firearm'].includes(weapon.kind)&&Number(ready.loaded||0)<=0)return {ok:false,reason:'оружие не заряжено'};
 return {ok:true,reason:''};
}
function showAttackMasteryPicker(weaponId){
 const actor=ownedActor(),targetId=quickContext?.targetActorId,target=actorById(targetId),weapon=equippedWeapons(actor).find(w=>String(w.id)===String(weaponId));if(!actor||!target||!weapon)return;
 const token=tokenByActorId(targetId)||selected,universal=/Универс/.test(propertiesOf(weapon)),masteries=availableAttackMasteries(actor,weapon,target),entries=[],availability=attackAvailability(actor,weapon,target),bowReserve=weapon.kind==='bow'&&canUseReserve(actor),realAmmo=weapon.kind!=='bow'||weaponAmmoCount(actor,weapon)>0;
 const ordinaryTypes=universal?[["slash","Рубящий"],["pierce","Колющий"]]:[[null,'']];
 for(const [damageType,typeLabel] of ordinaryTypes)entries.push({name:`Обычная атака${typeLabel?` · ${typeLabel}`:''}`,meta:availability.ok?'без Мастерства':availability.reason,action:'attack-finalize',args:{targetId,weaponId:weapon.id,damageType:damageType||undefined},disabled:!availability.ok||weapon.kind==='bow'&&!realAmmo,button:weapon.kind==='melee'?'Удар':'Выстрел'});
 if(bowReserve&&availability.ok)for(const [damageType,typeLabel] of ordinaryTypes)entries.push({name:`Запас${typeLabel?` · ${typeLabel}`:''}`,meta:`не расходовать стрелу · осталось ${actor.resources.reserve}`,action:'attack-finalize',args:{targetId,weaponId:weapon.id,damageType:damageType||undefined,reserve:true},button:'Выстрел'});
 for(const m of masteries){const mastery=m.extra.mastery||m.name,damageTypes=universal?[["slash","Рубящий"],["pierce","Колющий"]]:[[null,'']];for(const [damageType,typeLabel] of damageTypes){if(realAmmo||weapon.kind!=='bow')entries.push({name:`${m.name}${typeLabel?` · ${typeLabel}`:''}`,meta:availability.ok?m.meta:availability.reason,action:'attack-finalize',args:{targetId,weaponId:weapon.id,mastery,damageType:damageType||undefined,...m.extra},disabled:!availability.ok,button:'Применить'});if(bowReserve&&availability.ok)entries.push({name:`${m.name} · Запас${typeLabel?` · ${typeLabel}`:''}`,meta:`${m.meta} · Запас ${actor.resources.reserve}`,action:'attack-finalize',args:{targetId,weaponId:weapon.id,mastery,damageType:damageType||undefined,reserve:true,...m.extra},button:'Применить'});}}
 showCompactMenu(`${weapon.name} · вариант атаки`,entries,token);
}
function weaponRows(actor,targetToken){
 const target=actorById(targetToken?.refId);if(!bridge?.quickRow)throw new Error('Classic quick-attack row renderer is unavailable.');
 return equippedWeapons(actor).map(weapon=>{
  const availability=attackAvailability(actor,weapon,target),summary=`1к${weapon.die||4} · урон ${weapon.damage||0} ${weaponDamageLabel(weapon)} · ${weaponRangeLabel(weapon)}${availability.ok?'':` · ${availability.reason}`}`;
  const universal=/Универс/.test(propertiesOf(weapon)),masteries=availability.ok?availableAttackMasteries(actor,weapon,target):[];
  const melee=weapon.kind==='melee',ordinaryLabel=melee?'Удар':'Выстрел',realBowAmmo=weapon.kind!=='bow'||weaponAmmoCount(actor,weapon)>0,disabled=!availability.ok||!realBowAmmo;
  const buttons=universal?
   [{label:'Руб.',primary:true,disabled,data:{'tol-quick-weapon':weapon.id,'tol-damage-type':'slash'}},{label:'Кол.',primary:false,disabled,data:{'tol-quick-weapon':weapon.id,'tol-damage-type':'pierce'}}]:
   [{label:ordinaryLabel,primary:true,disabled,data:{'tol-quick-weapon':weapon.id}}];
  let html=bridge.quickRow({name:weapon.name,meta:summary,buttons});
  if(masteries.length)html+=bridge.quickRow({name:'↳ Мастерство',meta:masteries.map(m=>m.name).join(' · '),buttons:[{label:'Приём',primary:false,data:{'tol-attack-mastery-menu':weapon.id}}]});
  const reserveReady=weapon.kind==='bow'&&availability.ok&&canUseReserve(actor);
  if(reserveReady)html+=bridge.quickRow({name:'↳ Запас',meta:`Стрела не расходуется · осталось ${Number(actor.resources.reserve||0)}`,buttons:[{label:'Выстрел',action:'attack-finalize',args:{targetId:target?.id,weaponId:weapon.id,reserve:true},description:'Потратить Запас вместо стрелы'}]});
  return html;
 }).join('');
}
function showAttackPicker(targetToken){
 const actor=ownedActor();if(!actor||!targetToken?.refId||targetToken.refId===actor.id)return;
 if(targetToken.stealthRuntime?.active){bridge.toast('Цель находится в Скрытности: обычная атака и выстрел невозможны. Используйте площадное воздействие.','error');return;}
 cancelPick(false);quickContext={type:'attack',targetActorId:targetToken.refId,targetTokenId:targetToken.id};
 if(!bridge?.showQuick)throw new Error('Classic quick-attack shell is unavailable.');
 bridge.showQuick({title:`${actor.name} → ${targetToken.name}`,rowsHtml:weaponRows(actor,targetToken),actorId:targetToken.refId});bindQuickDescriptions();
}
function beginAttackTarget(){
 if(!selected||!canActNow(ownedActor()))return;
 hideQuickPopup();pick={kind:'attack',message:{actorId:selected.refId}};document.body.classList.add('bm-targeting');bridge.previewStart?.({actorId:selected.refId,type:'line',label:'Атака'});bridge.describe?.('Выберите токен цели.');bridge.toast('Выберите цель. Esc — отмена.');
}
function beginWeaponAttackTarget(args={}){const actor=ownedActor(),weapon=equippedWeapons(actor).find(w=>String(w.id)===String(args.weaponId));if(!selected||!actor||!weapon||!canActNow(actor))return;hideQuickPopup();pick={kind:'weapon-attack',message:{args:{...args},actorId:selected.refId}};document.body.classList.add('bm-targeting');bridge.previewStart?.({actorId:selected.refId,type:'line',maxRange:weapon.kind==='melee'?Number(weapon.reach||5):Number(weapon.range||0),label:weapon.name});bridge.describe?.(`${weapon.name}: выберите цель.`);bridge.toast(`${weapon.name}: выберите цель. Esc — отмена.`);}
async function finishWeaponAttackTarget(current,targetToken){const actor=ownedActor(),args={...(current.message?.args||{})},weapon=equippedWeapons(actor).find(w=>String(w.id)===String(args.weaponId)),target=actorById(targetToken?.refId);if(!actor||!weapon||!target)return;if(targetToken?.stealthRuntime?.active){bridge.toast('Цель находится в Скрытности: обычная атака и выстрел невозможны. Используйте площадное воздействие.','error');return;}const availability=attackAvailability(actor,weapon,target);if(!availability.ok){bridge.toast(availability.reason,'error');return;}cancelPick(false);try{const result=await finishMapAction('attack-resolve',{...args,targetId:target.id});if(result?.resolutionPending){selectedSuperiority.set(result.reactionId,new Set(result.selectedSuperiority||[]));syncReactionPanels();}else if(result?.hit)bridge.hitActor?.(target.id,result.damage||1);}finally{bridge.previewClear?.();}}
function beginTarget(action,args){hideQuickPopup();const label=args.label||(args.tactical==='charge'?'Натиск':args.tactical==='grapple'?'Захват':'Цель');pick={kind:'command',allowSelf:!!args.allowSelf,message:{action,args:{...args},allowSelf:!!args.allowSelf}};document.body.classList.add('bm-targeting');bridge.previewStart?.({actorId:selected?.refId,type:'line',maxRange:Number(args.maxRange||0),label});bridge.toast(`${label}: выберите токен цели. Esc — отмена.`);}
function beginPoint(action,args){hideQuickPopup();const originActorId=args.originActorId||selected?.refId;pick={kind:'point',message:{action,args:{...args}}};document.body.classList.add('bm-targeting');bridge.previewStart?.({actorId:originActorId,type:'line',maxRange:Number(args.maxRange||0),label:args.label||'Точка'});bridge.toast('Выберите точку. Esc — отмена.');}
function cancelPick(hidePopup=true){pick=null;document.body.classList.remove('bm-targeting');bridge?.previewClear?.();if(hidePopup)hideQuickPopup();bridge?.describe?.('Выберите действие.');}

function spellNumber(spell){return Number(String(spell?.id||'').split('-')[1]||0);}
function spellMapSpec(spell){
 const number=spellNumber(spell),maxRange=Math.max(0,Number(spell?.rangeFeet||0)),radiusFeet=Math.max(0,Number(spell?.radiusFeet||0));
 if(number===1)return {mode:'point',maxRange,radiusFeet,label:spell.name};
 if(number===2)return {mode:'point',maxRange,label:spell.name};
 if(number===4)return {mode:'point',maxRange:5,label:spell.name,flow:'witness-trace'};
 if(number===5)return {mode:'self',radiusFeet,label:spell.name};
 if(number===9)return {mode:'confirm',label:spell.name,flow:'fresh-blood'};
 if(number===15)return {mode:'target',maxRange:5,label:spell.name,flow:'recent-dead',allowDead:true,ritual:true};
 if(number===26)return {mode:'self',maxRange:100,label:spell.name,flow:'rift-latest'};
 if(number===29)return {mode:'multi-dead',maxRange:30,label:spell.name,flow:'raise-dead'};
 if([3,6,7,8,10,11,12,13,16,17,18,19,21,25,27].includes(number))return {mode:'target',maxRange,label:spell.name,allowSelf:[10,12,16].includes(number),flow:({10:'wound-medium',11:'command',12:'wound-heal',16:'turn-source',18:'effect',19:'move-target',27:'damage-type'})[number]||'cast'};
 if(number===14)return {mode:'point',maxRange:20,label:spell.name,flow:'shadow'};
 if([20,23,30].includes(number))return {mode:'area',maxRange,radiusFeet,label:spell.name,needsAreaResistance:true,needsDamageType:number===30};
 if(number===22)return {mode:'point',maxRange:30,radiusFeet:15,label:spell.name,flow:'great-seal',activationTurns:1};
 if(number===24)return {mode:'point',maxRange:100,label:spell.name,flow:'path-fold'};
 if(number===28)return {mode:'self-area',radiusFeet:20,label:spell.name};
 return null;
}
function startSpellTarget(spell,spec,args={},next=spec.flow||'cast'){
 hideQuickPopup();pick={kind:'spell-target',allowSelf:!!spec.allowSelf,message:{spellId:spell.id,spec,args:{...args},next,allowSelf:!!spec.allowSelf}};document.body.classList.add('bm-targeting');bridge.previewStart?.({actorId:ownedActor().id,type:'line',maxRange:spec.maxRange||0,label:spell.name});bridge.describe?.(`Выберите цель для «${spell.name}».`);bridge.toast(`«${spell.name}»: выберите цель. Esc — отмена.`);
}
function startSpellPoint(spell,spec,args={},next='cast',originActorId=null){
 hideQuickPopup();pick={kind:'spell-point',message:{spellId:spell.id,spec,args:{...args},next,originActorId:originActorId||ownedActor().id}};document.body.classList.add('bm-targeting');bridge.previewStart?.({actorId:originActorId||ownedActor().id,type:spec.radiusFeet?'area':'line',radiusFeet:spec.radiusFeet||0,maxRange:spec.maxRange||0,label:spell.name});bridge.describe?.(`Выберите точку для «${spell.name}».`);bridge.toast(`«${spell.name}»: выберите точку. Esc — отмена.`);
}
function startSpellAreaSelectedTarget(spell,spec,args={}){
 hideQuickPopup();pick={kind:'spell-area-target',message:{spellId:spell.id,spec,args:{...args,areaResistance:'selected'}}};document.body.classList.add('bm-targeting');bridge.previewStart?.({actorId:ownedActor().id,type:'line',label:`${spell.name} · цель сопротивления`});bridge.toast(`«${spell.name}»: сначала выберите цель, чьё сопротивление учитывать.`);
}
function showTextEntryMenu(title,label,value,action,args={},token=selected,argKey='category',hint='Коротко укажите необходимое решение.'){
 if(!bridge?.quickTextRow||!bridge?.showQuick)throw new Error('Classic quick text renderer is unavailable.');
 quickContext={type:'text'};
 const rowsHtml=bridge.quickTextRow({label,hint,value:value||'',action,args,argKey,buttonLabel:'Далее'});
 bridge.showQuick({title,rowsHtml,actorId:token?.refId||selected?.refId});
 setTimeout(()=>document.querySelector('[data-tol-text-value]')?.focus(),0);
}
function renderMultiSelectMenu(){
 const ctx=quickContext;if(ctx?.type!=='multi')return;if(!bridge?.quickRow||!bridge?.showQuick)throw new Error('Classic quick picker renderer is unavailable.');
 const selectedNames=ctx.entries.filter(entry=>ctx.selected.has(entry.id)).map(entry=>entry.name),rows=ctx.entries.map(entry=>bridge.quickRow({name:entry.name,meta:entry.meta||'',buttons:[{label:ctx.selected.has(entry.id)?'✓ Выбран':'Выбрать',primary:ctx.selected.has(entry.id),data:{'tol-multi-toggle':entry.id}}]}));
 rows.push(bridge.quickRow({name:ctx.selected.size?`Выбрано: ${selectedNames.join(', ')}`:'Спутники не выбраны',meta:`Можно выбрать от 0 до ${ctx.max}. ${ctx.allowCanvas?'Можно также щёлкать по соседним токенам прямо на карте.':''}`,buttons:[{label:ctx.confirmLabel||'Далее',primary:true,data:{'tol-multi-confirm':''}}]}));
 const instructions=ctx.instructions?`<div class="bm-muted" style="padding:8px 10px;line-height:1.35">${esc(ctx.instructions)}</div>`:'';
 bridge.showQuick({title:ctx.title,rowsHtml:instructions+rows.join(''),actorId:(ctx.token||selected)?.refId});
}
function showMultiSelectMenu(title,entries,{max=2,confirmAction,confirmArgs={},token=selected,instructions='',confirmLabel='Далее',allowCanvas=false}={}){quickContext={type:'multi',title,entries,selected:new Set(),max,confirmAction,confirmArgs,token,instructions,confirmLabel,allowCanvas};renderMultiSelectMenu();}
function chooseAreaDamageType(spell,spec,args){
 showCompactMenu(`${spell.name} · тип урона`,[['slash','Рубящий'],['pierce','Колющий'],['blunt','Дробящий']].map(([damageType,name])=>({name,meta:'тип воздействия',action:'magic-area-start',args:{spellId:spell.id,...args,damageType},button:'Выбрать'})),selected);
}
function configureAreaSpell(spell,spec){
 const cfg=spellConfig(spell),master=bridge.session().mode==='master';if(spec.needsDamageType&&!master){bridge.toast('Тип воздействия этой формулы не указан в правилах; его должен выбрать Ведущий.','error');return;}
 const continueWith=areaResistance=>{const args={areaResistance};if(spec.needsDamageType)return chooseAreaDamageType(spell,spec,args);if(areaResistance==='selected')return startSpellAreaSelectedTarget(spell,spec,args);return startSpellPoint(spell,spec,args);};
 if(!master){if(!['highest','selected'].includes(cfg.areaResistance)){bridge.toast('Для этой площадной формулы Ведущий сначала задаёт способ учёта сопротивления.','error');return;}continueWith(cfg.areaResistance);return;}
 showCompactMenu(`${spell.name} · сопротивление области`,[{name:'Наибольшее в области',meta:'учесть максимальный бонус сопротивления среди задетых',action:'magic-area-resistance',args:{spellId:spell.id,areaResistance:'highest'},button:'Далее'},{name:'Выбранная цель',meta:'учесть сопротивление выбранного существа',action:'magic-area-resistance',args:{spellId:spell.id,areaResistance:'selected'},button:'Далее'}],selected);
}
function showWoundChoice(spell,args,targetId,{mediumOnly=false,nextAction='magic-finalize',nextArgs={}}={}){
 const target=actorById(targetId),token=tokenByActorId(targetId)||selected;if(!target)return;const wounds=(target.woundList||[]).filter(w=>Number(w.severity)<=2&&(!mediumOnly||Number(w.severity)===2)&&!(spellNumber(spell)===12&&w.healedByMagic));
 showCompactMenu(`${spell.name} · ранение`,wounds.map(w=>({name:woundSeverityLabel(w.severity),meta:`${target.name} · ${String(w.id).slice(0,6)}`,action:nextAction,args:{spellId:spell.id,...args,targetId,woundId:w.id,...nextArgs},button:'Выбрать'})).concat(wounds.length?[]:[{name:'Нет подходящего ранения',meta:mediumOnly?'Нужно Среднее ранение':'Нужно Лёгкое или Среднее ранение',action:'magic-finalize',args:{},disabled:true,button:'—'}]),token);
}
function showWillingChoice(spell,args,targetId){
 const target=actorById(targetId),token=tokenByActorId(targetId)||selected;showCompactMenu(`${spell.name} · ${target?.name||'цель'}`,[{name:'Добровольная цель',meta:'Сопротивление не применяется',action:'magic-finalize',args:{spellId:spell.id,...args,targetId,willing:true},button:'Сотворить'},{name:'Цель сопротивляется',meta:`Сопротивление: ${spell.resistance||'по формуле'}`,action:'magic-finalize',args:{spellId:spell.id,...args,targetId,willing:false},button:'Сотворить'}],token);
}
function continueSpellTarget(current,targetToken){
 const spell=catalog?.spells?.find(item=>item.id===current.message.spellId),spec=current.message.spec,args={...current.message.args,targetId:targetToken.refId},next=current.message.next||'cast';if(!spell)return;
 if(targetToken?.stealthRuntime?.active){bridge.toast('Цель находится в Скрытности: точечная Формула по ней невозможна. Задеть её можно только площадной атакой.','error');return;}
 cancelPick(false);
 if(next==='cast')return finishMapAction('magic-resolve',{spellId:spell.id,...args}).then(result=>{if(result?.resolutionPending)syncReactionPanels();}).catch(()=>{});
 if(next==='recent-dead'){const target=actorById(targetToken.refId);if(!target?.medical?.dead){bridge.toast('Для ритуала выберите токен умершего существа.','error');return;}return showCompactMenu(`${spell.name} · останки`,[{name:'Недавно умершее существо',meta:'Подтвердите применимость формулы к этим останкам.',action:'magic-finalize',args:{spellId:spell.id,...args,recentDead:true,beginRitual:true},button:'Начать ритуал'}],targetToken);}
 if(next==='wound-medium')return showWoundChoice(spell,args,targetToken.refId,{mediumOnly:true});
 if(next==='wound-heal')return showWoundChoice(spell,args,targetToken.refId,{nextAction:'magic-willing-menu'});
 if(next==='command')return showCompactMenu(`${spell.name} · повеление`,['стой','брось','отойди','молчи','встань'].map(command=>({name:`«${command}»`,meta:'короткое повеление',action:'magic-finalize',args:{spellId:spell.id,...args,command},button:'Сотворить'})),targetToken);
 if(next==='turn-source')return showWoundChoice(spell,{secondaryId:targetToken.refId},targetToken.refId,{nextAction:'magic-turn-recipient-start'});
 if(next==='turn-recipient')return showWillingChoice(spell,args,targetToken.refId);
 if(next==='effect'){const target=actorById(targetToken.refId),effects=target?.effects||[];return showCompactMenu(`${spell.name} · эффект`,effects.map(effect=>({name:effect.description||effect.key,meta:'выберите подходящую личину / магический эффект',action:'magic-finalize',args:{spellId:spell.id,...args,effectId:effect.id},button:'Снять'})).concat(effects.length?[]:[{name:'Нет активных эффектов',action:'magic-finalize',args:{},disabled:true,button:'—'}]),targetToken);}
 if(next==='move-target')return startSpellPoint(spell,{...spec,radiusFeet:0,maxRange:20},args,'move-choice',targetToken.refId);
}
function continueSpellPoint(current,world){
 const spell=catalog?.spells?.find(item=>item.id===current.message.spellId),args={...current.message.args,point:world},next=current.message.next||'cast';cancelPick(false);if(!spell)return;
 if(next==='move-choice'){const token=tokenByActorId(args.targetId)||selected;return showCompactMenu(`${spell.name} · завершение`,[{name:'Переместить',meta:'до 20 футов',action:'magic-finalize',args:{spellId:spell.id,...args,prone:false},button:'Сотворить'},{name:'Переместить и Сбить',meta:'дополнительно Сбить цель',action:'magic-finalize',args:{spellId:spell.id,...args,prone:true},button:'Сотворить'}],token);}
 return finishMapAction('magic-resolve',{spellId:spell.id,...args}).then(result=>{if(result?.resolutionPending)syncReactionPanels();}).catch(()=>{});
}
function beginPathFold(spell,spec){
 const actor=ownedActor(),candidates=data?.campaign?.characters?.map(row=>row.state).filter(other=>other.id!==actor.id&&!other.medical?.dead&&!other.wounds?.critical&&tokenByActorId(other.id)&&Number(bridge.distance?.(actor.id,other.id))<=5.01)||[];
 showMultiSelectMenu(`${spell.name} · Шаг 1/2: спутники`,candidates.map(other=>({id:other.id,name:other.name,meta:`${Math.round(Number(bridge.distance?.(actor.id,other.id)||0))} фт · добровольная цель`})),{max:2,confirmAction:'magic-path-point',confirmArgs:{spellId:spell.id},token:selected,instructions:'Выберите до двух добровольных существ в 5 футах. Можно нажать «Выбрать» в списке или щёлкнуть по их токенам на карте. Если спутники не нужны — сразу переходите к шагу 2.',confirmLabel:'Шаг 2/2 · выбрать точку',allowCanvas:true});
 pick={kind:'spell-multi',allowSelf:false,message:{spellId:spell.id,candidateIds:candidates.map(other=>other.id)}};document.body.classList.add('bm-targeting');bridge.previewStart?.({actorId:actor.id,type:'self-area',radiusFeet:5,label:`${spell.name} · спутники`});bridge.describe?.('Шаг 1/2: выберите до двух соседних спутников, затем нажмите «Шаг 2/2 · выбрать точку».');bridge.toast('«Преломить путь»: сначала выберите 0–2 спутников в 5 футах, затем точку назначения.');
}
function beginRaiseDead(spell){
 const actor=ownedActor(),candidates=(data?.campaign?.characters||[]).map(row=>row.state).filter(other=>other.id!==actor?.id&&other.medical?.dead&&tokenByActorId(other.id)&&Number(bridge.distance?.(actor.id,other.id))<=30.01);
 if(!candidates.length){bridge.toast('На активной карте нет мёртвых NPC или умерших персонажей игроков для «Гласа над прахом».','error');return;}
 showMultiSelectMenu(`${spell.name} · мёртвые`,candidates.map(other=>({id:other.id,name:other.name,meta:other.isCreature?'мёртвое существо / NPC':'умерший персонаж игрока'})),{max:6,confirmAction:'magic-raised-mode-start',confirmArgs:{spellId:spell.id},token:selected,instructions:'Можно выбрать до шести мёртвых тел в 30 футах, включая умерших персонажей игроков.'});
}
function chooseRaisedResistance(args){
 const spell=catalog?.spells?.find(item=>item.id===args.spellId),ids=[...new Set(args.additionalIds||[])],targets=ids.map(actorById).filter(Boolean);if(!spell||!targets.length){bridge.toast('Выберите хотя бы одно мёртвое тело.','error');return;}
 if(bridge.session().mode!=='master')return finishMapAction('magic-resolve',{...args,ritual:true,entityResistance:'highest',beginRitual:true,ritualMinutes:10}).then(result=>{if(result?.resolutionPending)syncReactionPanels();}).catch(()=>{});
 const entries=[{name:'Наибольшая Воля среди выбранных',meta:'рабочее решение Ведущего для одного d100 против нескольких сущностей',action:'magic-raised-mode',args:{...args,entityResistance:'highest'},button:'Далее'}];
 for(const target of targets)entries.push({name:`Воля: ${target.name}`,meta:'учесть сопротивление этой сущности как опорное',action:'magic-raised-mode',args:{...args,entityResistance:'selected',targetId:target.id},button:'Далее'});
 showCompactMenu(`${spell.name} · сопротивление`,entries,tokenByActorId(targets[0].id)||selected);
}
function showRaisedCastMode(spell,args){
 const entries=[{name:'Мёртвые тела',meta:'3 ОД · до шести тел в 30 футах · без сопротивления',action:'magic-finalize',args:{spellId:spell.id,...args,ritual:false,entityResistance:'highest'},button:'Сотворить'}];
 entries.push({name:'Остаточные духи',meta:'3 ОД · ритуал 10 минут · Воля духов',action:'magic-raised-resistance',args:{spellId:spell.id,...args,ritual:true},button:'Ритуал'});
 showCompactMenu(`${spell.name} · способ`,entries,selected);
}
function beginNativeMagic(spellId){
 const spell=catalog?.spells?.find(item=>item.id===spellId),actor=ownedActor(),spec=spellMapSpec(spell);if(!spell||!actor)return;if(!spec){bridge.toast('Для этой формулы ещё нет нативного картового сценария.','error');return;}
 const ritual=(actor.effects||[]).find(effect=>effect.key==='casting'&&effect.spellId===spell.id);if(ritual){if(ritual.interrupted){bridge.toast('Сначала удержите прерванный ритуал.','error');return;}if(Number(data?.tol?.clock||0)<Number(ritual.readyAt||0)){bridge.toast(`Ритуал ещё идёт. Осталось ${Math.max(1,Math.ceil(Number(ritual.readyAt)-Number(data?.tol?.clock||0)))} мин.`);return;}return finishMapAction('magic-resolve',{spellId,ritualComplete:true}).then(result=>{if(result?.resolutionPending)syncReactionPanels();}).catch(()=>{});}
 if(spec.flow==='fresh-blood')return showCompactMenu(spell.name,[{name:'Свежая кровь владельца есть',meta:'Формула укажет направление к владельцу крови в пределах одной мили.',action:'magic-finalize',args:{spellId,freshBlood:true},button:'Сотворить'}],selected);
 if(spec.flow==='raise-dead')return beginRaiseDead(spell);
 if(spec.mode==='self')return finishMapAction('magic-resolve',{spellId}).then(result=>{if(result?.resolutionPending)syncReactionPanels();}).catch(()=>{});
 if(spec.mode==='self-area'){bridge.previewStart?.({actorId:actor.id,type:'self-area',radiusFeet:spec.radiusFeet,label:spell.name});return showCompactMenu(spell.name,[{name:'Сотворить в своей позиции',meta:`Область ${spec.radiusFeet} футов вокруг мага`,action:'magic-self-area-cast',args:{spellId},button:'Сотворить'}],selected);}
 if(spec.mode==='area')return configureAreaSpell(spell,spec);
 if(spec.flow==='shadow')return showCompactMenu(spell.name,[{name:'Исходная и конечная точки находятся в тени',meta:'Это условие формулы карта автоматически определить не может.',action:'magic-shadow-point',args:{spellId,inShadow:true},button:'Подтвердить'}],selected);
 if(spec.flow==='great-seal'){if(bridge.session().mode!=='master'){bridge.toast('Категорию Великой печати определяет Ведущий.','error');return;}return showTextEntryMenu(spell.name,'Категория сверхъестественных существ','Порождение Бездны','magic-great-seal-point',{spellId});}
 if(spec.flow==='path-fold')return beginPathFold(spell,spec);
 if(spec.flow==='damage-type'){if(bridge.session().mode!=='master'){bridge.toast('Тип воздействия «Суда плоти» не указан правилами и должен быть выбран Ведущим.','error');return;}return showCompactMenu(`${spell.name} · тип воздействия`,[['slash','Рубящий'],['pierce','Колющий'],['blunt','Дробящий']].map(([damageType,name])=>({name,meta:'рабочее решение Ведущего',action:'magic-damage-target-start',args:{spellId,damageType},button:'Далее'})),selected);}
 if(spec.mode==='point')return startSpellPoint(spell,spec,{},spec.flow==='great-seal'?'great-seal':'cast');
 return startSpellTarget(spell,spec,{},spec.flow||'cast');
}
function startConfiguredArea(args){const spell=catalog?.spells?.find(item=>item.id===args.spellId),spec=spellMapSpec(spell);if(!spell||!spec)return;if(args.areaResistance==='selected')startSpellAreaSelectedTarget(spell,spec,args);else startSpellPoint(spell,spec,args);}

function featureTarget(action,args,label,maxRange=0,allowSelf=false){return beginTarget(action,{...args,label,maxRange,allowSelf,pickTarget:true});}
function lastCheckFailedFor(actor,skills){return actor?.lastCheck?.kind==='check'&&!actor.lastCheck.success&&(!skills||skills.includes(actor.lastCheck.skill));}
function runTraitNative(name){
 const actor=ownedActor();if(!actor)return;
 if(['Эрудит','Уверенный 1','За мной','Вдумчивый 3','Вдумчивый 6'].includes(name))return finishMapAction('trait',{name}).catch(()=>{});
 if(name==='Вес слова'){if(!lastCheckFailedFor(actor,['Убеждение','Обман','Интуиция','Запугивание','Очарование']))return bridge.toast('«Вес слова» доступен после проваленной проверки Харизмы.','error');return finishMapAction('trait',{name}).catch(()=>{});}
 if(['Не спускать глаз','Разобрать слабость','Изученная цель'].includes(name))return featureTarget('trait-direct',{name},name,0,false);
 if(name==='Уверенный 2')return featureTarget('trait-direct',{name},name,30,false);
 if(name==='Уверенный 5')return featureTarget('trait-direct',{name},name,30,false);
 if(name==='Вдумчивый 5')return featureTarget('trait-direct',{name},name,30,false);
 if(name==='Уверенный 4')return featureTarget('trait-loss-target',{name},name,30,true);
 return bridge.toast('Для этой способности нет отдельного ручного действия на карте.','error');
}
function masteryIntegrated(name){return ['Фехтовальщик','Дуэлянт','Секироносец','Молотобоец','Древковик','Засадник','Лучник','Арбалетчик','Стрелок древности','Метатель','Копейщик','Борец','Бронник','Костоправ','Щитоносец','Телохранитель'].includes(name);}
function runMasteryNative(name){
 const actor=ownedActor(),m=catalog?.mastery?.find(x=>x.name===name)||(actor?.customMastery||[]).find(x=>x.name===name);if(!actor||!m)return;
 if(['Утешитель','Глашатай'].includes(name))return featureTarget('mastery-direct',{name},name,bridge.combat()?30:0,false);
 if(name==='Боевой предводитель')return featureTarget('mastery-direct',{name},name,30,false);
 if(['Переговорщик','Разведчик','Взломщик'].includes(name)){if(!lastCheckFailedFor(actor,{'Переговорщик':['Убеждение','Очарование'],'Разведчик':['Скрытность','Бдительность'],'Взломщик':['Взлом']}[name]))return bridge.toast(`${name} требует подходящего проваленного броска.`,'error');return finishMapAction('mastery',{name}).catch(()=>{});}
 if(name==='Боец в доспехе')return finishMapAction('mastery',{name}).catch(()=>{});
 if(masteryIntegrated(name))return bridge.toast('Это Мастерство встроено в соответствующее действие карты и появляется там, когда применимо.');
 return finishMapAction('mastery',{name}).catch(()=>{});
}
function runSpeciesNative(feature){
 const actor=ownedActor();if(!actor)return;
 if(feature==='cover-scars')return showCompactMenu('Светящиеся шрамы',[{name:'Закрыть шрамы',action:'species-direct',args:{feature,covered:true},button:'Закрыть'},{name:'Открыть шрамы',action:'species-direct',args:{feature,covered:false},button:'Открыть'}],selected);
 if(feature==='swimming')return showCompactMenu('Движение Крау',[{name:'Плавание',action:'species-direct',args:{feature,swimming:true},button:'Выбрать'},{name:'Суша',action:'species-direct',args:{feature,swimming:false},button:'Выбрать'}],selected);
 if(feature==='human-reroll'){if(!lastCheckFailedFor(actor))return bridge.toast('Нужна только что проваленная немагическая проверка.','error');return showCompactMenu('Человеческая пластичность',[{name:'Повторная попытка физически возможна',meta:'1 раз за большой привал',action:'species-direct',args:{feature,repeatPossible:true},button:'Переброс'}],selected);}
 if(feature==='fari-memory')return showCompactMenu('Память Мотылька',[{name:'Я лично видел / слышал / читал сведения',action:'species-direct',args:{feature,witnessed:true},button:'Применить'}],selected);
 if(feature==='mimic')return showCompactMenu('Миметическая нервная система',Object.keys(actor.skills||{}).map(skill=>({name:skill,meta:'наблюдённый успешный навык',action:'species-direct',args:{feature,observedSkill:skill},button:'Запомнить'})),selected);
 if(feature==='synapse')return featureTarget('species-direct',{feature},'Источник приказа',0,false);
 if(feature==='hydrate'||feature==='grave-sight')return finishMapAction('species',{feature}).catch(()=>{});
 if(feature==='sense'){const contexts={gnoll:[['strength','Массивное сложение'],['scent','Нюх падальщика'],['immunity','Желудок падальщика']],kuthi:[['sight','Вранье зрение'],['voice','Подражание'],['mountain','Горная физиология']],krau:[['depth','Рождённый для глубин']],pallid:[['immunity','Чужая плоть']]};return showCompactMenu('Видовое преимущество',(contexts[actor.species]||[]).map(([context,name])=>({name,action:'species-direct',args:{feature,context},button:'Подготовить'})),selected);}
 if(feature==='abyss-gift'){if(actor.abyssGift==='flesh'){const wounds=(actor.woundList||[]).filter(w=>Number(w.severity)<=2);return showCompactMenu('Дар Плоти',wounds.map(w=>({name:woundSeverityLabel(w.severity),meta:`Ранение ${String(w.id).slice(0,6)}`,action:'species-direct',args:{feature,woundId:w.id},button:'Снять ступень'})),selected);}if(actor.abyssGift==='memory')return showCompactMenu('Дар Памяти Крови',[{name:'Есть кровь недавно умершего разумного',meta:'1 Доза · 10 минут',action:'species-direct',args:{feature,freshBlood:true},button:'Применить'}],selected);return finishMapAction('species',{feature}).catch(()=>{});}
 return bridge.toast('Эта видовая способность не требует отдельной команды карты.');
}
function beginCharacterContext(name,feature){
 const actor=ownedActor(),entry=catalog?.characterTraits?.find(x=>x.name===name)||(actor?.customCharacterTraits||[]).find(x=>x.name===name);if(!actor||!entry)return;
 if(feature==='support'){const modes=[];if(entry.kind==='character'){const label=({narrative:'Нарративная Опора',advantage:'Преимущество к подходящей проверке',d4:'+1к4 к подходящей проверке',plus1:'+1 к подходящей проверке',attack1:'+1 к следующей атаке / Обмену'})[entry.mechanic]||'Собственная Опора';modes.push({name:label,meta:entry.support||entry.description,action:'character-mode',args:{name,feature,mode:entry.mechanic==='narrative'?'narrative':'check'},button:'Опора'});}else if(entry.modes?.includes('check'))modes.push({name:'+1к4 к подходящей проверке',meta:entry.support,action:'character-mode',args:{name,feature,mode:'check'},button:'Опора'});if(entry.modes?.includes('morale'))modes.push({name:'Восстановить Мораль',meta:entry.support,action:'character-mode',args:{name,feature,mode:'morale'},button:'Опора'});if(entry.modes?.includes('reduce'))modes.push({name:'Снизить потерю Морали',meta:entry.support,action:'character-mode',args:{name,feature,mode:'reduce'},button:'Опора'});return showCompactMenu(`${name} · Опора`,modes,selected);}
 return showCompactMenu(`${name} · Срыв`,[{name:'Сюжетное осложнение',meta:entry.breakdown,action:'character-mode',args:{name,feature,mode:'narrative'},button:'Принять'},{name:'Потерять 1к4 Морали',meta:entry.breakdown,action:'character-mode',args:{name,feature,mode:'morale'},button:'Принять'}],selected);
}
function characterMode(args){return showTextEntryMenu(`${args.name||'Характер'} · ${args.feature==='breakdown'?'Срыв':'Опора'}`,'Связь с ситуацией','', 'character-context',args,selected,'context','Коротко опишите поступок, риск или давление, из-за которого Черта срабатывает.');}
function characterContext(args){
 const actor=ownedActor();if(!actor)return;
 if(args.feature==='support'&&args.mode==='morale'&&args.name==='Весельчак')return featureTarget('character-direct',args,'Кому поднять Мораль',0,true);
 if(args.feature==='support'&&args.mode==='reduce')return showTextEntryMenu(`${args.name} · потеря Морали`,'Сколько Морали теряется до снижения','', 'character-loss-finalize',args,selected,'loss','Введите исходную потерю Морали числом.');
 return finishMapAction('character',args).catch(()=>{});
}
function beginBeliefNative(name,core=false){return showTextEntryMenu(core?'Стержень':name,'Связь с риском / выбором','', core?'core-belief-finalize':'belief-context',{name},selected,'context','Коротко опишите, почему это Убеждение сейчас действительно имеет цену или влияет на решение.');}
function beliefContext(args){
 const actor=ownedActor(),entry=catalog?.beliefs?.find(x=>x.name===args.name)||(actor?.customBeliefs||[]).find(x=>x.name===args.name);if(!actor||!entry)return;
 if(args.name==='Кровь требует крови')return featureTarget('belief-direct',args,args.name,0,false);
 if(args.name==='Бездна — скверна')return showCompactMenu(args.name,[{name:'Сдержать ужас',meta:'Уменьшить потерю Морали на 1к4',action:'belief-reduce-start',args,button:'Потеря Морали'},{name:'Противостоять Бездне',meta:'+1к4 к следующей Воле против Бездны',action:'belief-direct',args:{...args,mode:'check'},button:'Подготовить'}],selected);
 if(args.name==='Род и община прежде всего')return featureTarget('belief-community-target',args,'Союзник рода / общины',0,true);
 if(/уменьшить/.test(entry.description))return showTextEntryMenu(`${args.name} · потеря Морали`,'Исходная потеря Морали','', 'belief-loss-finalize',args,selected,'loss','Введите потерю до уменьшения.');
 if(/восстановить|восстанавливает/.test(entry.description)){
  const selfOnly=args.name==='Есть черта, которую нельзя переступать';
  const entries=[{name:'Восстановить себе',meta:'1к8 Морали, если условие Убеждения выполнено',action:'belief-direct',args:{...args,mode:'morale'},button:'Применить'}];
  if(!selfOnly)entries.push({name:'Восстановить другому',meta:'выберите цель',action:'belief-target-start',args:{...args,mode:'morale'},button:'Цель'});
  return showCompactMenu(args.name,entries,selected);
 }
 return finishMapAction('belief',args).catch(()=>{});
}
function showBeliefCommunityChoice(args){
 const target=actorById(args.targetId),token=tokenByActorId(args.targetId)||selected;if(!target)return;
 return showCompactMenu('Род и община прежде всего',[{name:'+1 к следующей проверке',meta:'Союзник получает подготовленный бонус',action:'belief-direct',args:{...args,mode:'check'},button:'Подготовить'},{name:'Восстановить 1к8 Морали',meta:'Союзнику',action:'belief-direct',args:{...args,mode:'morale'},button:'Восстановить'}],token);
}


function renderCategory(key){
 const actor=ownedActor();if(!actor)return;const options=rootOptions();let title='',entries=[];
 if(key==='skills'){title='Проверки навыков';entries=Object.entries(actor.skills).map(([skill,state])=>({name:skill,meta:`${state.cube} ${state.bonus>=0?'+':''}${state.bonus}`,action:'check-skill',args:{skill},description:`Проверка ${skill}`,button:'Бросок'}));}
 if(key==='features'){title='Особенности';entries=options.abilities(actor,catalog).filter(item=>!item.action.startsWith('mastery')).map(item=>({name:item.name,meta:item.cost!=null?`${item.cost} ОД`:'',action:'feature-native',args:{kind:item.action.startsWith('trait')?'trait':'species',...item.args},description:item.description,disabled:item.used,button:'Применить'}));}
 if(key==='mastery'){title='Мастерство';entries=options.abilities(actor,catalog).filter(item=>item.action.startsWith('mastery')).map(item=>({name:item.name,meta:item.cost!=null?`${item.cost} ОД`:'',action:'feature-native',args:{kind:'mastery',...item.args},description:item.description,disabled:item.used,button:'Применить'}));}
 if(key==='magic'){title='Известные формулы';entries=catalog.spells.filter(spell=>actor.spells.includes(spell.id)).map(spell=>({name:spell.name,meta:`Порог ${spell.threshold} · ${spell.cost||spell.od||'?'} ОД${spellMapSpec(spell)?' · карта':''}`,action:'magic-map',args:{spellId:spell.id},description:spell.description,disabled:actor.weaponProficiencies['Магия']<spell.threshold||(actor.effects||[]).some(effect=>['magic-forbidden','anti-magic'].includes(effect.key)),button:'Сотворить'}));}
 if(key==='character'){title='Характер';entries=actor.characterTraits.flatMap(item=>[{name:`${item.name} · Опора`,action:'character-native',args:{name:item.name,feature:'support'},description:item.support,disabled:actor.used.scene['Опора'],button:'Опора'},{name:`${item.name} · Срыв`,action:'character-native',args:{name:item.name,feature:'breakdown'},description:item.breakdown,disabled:actor.used.scene['Срыв'],button:'Срыв'}]);}
 if(key==='beliefs'){title='Убеждения';entries=(actor.beliefs||[]).map(name=>catalog.beliefs.find(item=>item.name===name)||(actor.customBeliefs||[]).find(item=>item.name===name)).filter(Boolean).map(item=>({name:item.name,action:'belief-native',args:{name:item.name},description:item.description||item.narrative||'',disabled:actor.used?.[item.frequency==='1/бой'?'combat':item.frequency?.includes('привал')?'rest':'scene']?.[item.name],button:'Применить'}));entries.unshift({name:`Стержень · ${actor.coreBelief||'не выбран'}`,action:'core-belief-native',args:{name:actor.coreBelief},description:'Восстановить 1к8 Морали за следование Стержню несмотря на риск.',disabled:actor.used.scene['Стержень']||!actor.coreBelief,button:'Стержень'});}
 if(key==='items'){title='Предметы';entries=actor.inventory.filter(item=>item.kind==='item').map(item=>({name:item.name,meta:`${item.uses} исп.`,action:'item-native',args:{itemId:item.id},description:catalog.items.find(profile=>(profile.id||profile.name)===item.profileId)?.description,disabled:item.uses<=0,button:'Использовать'}));entries.push({name:'Ремонт снаряжения',action:'repair-native',args:{},button:'Открыть'});}
 showCompactMenu(title,entries,selected);
}

function showSkillDifficulty(skill){
 const actor=ownedActor();if(!actor)return;
 const state=actor.skills?.[skill]||{};
 showCompactMenu(`${skill} · сложность`,[4,6,8,10,12].map(sides=>({name:`1к${sides}`,meta:`${state.cube||''} ${Number(state.bonus||0)>=0?'+':''}${Number(state.bonus||0)} против 1к${sides}`,action:'check-direct',args:{skill,difficulty:sides},button:'Бросок'})),selected);
}
function beginHealTarget(){
 hideQuickPopup();pick={kind:'heal-target',allowSelf:true,message:{}};document.body.classList.add('bm-targeting');bridge.previewStart?.({actorId:selected?.refId,type:'line',label:'Помощь'});bridge.toast('Выберите персонажа для помощи. Esc — отмена.');
}
function healerHasKit(actor){return (actor?.inventory||[]).some(item=>item.name==='Набор лекаря'&&Number(item.uses||1)>0);}
function bandageKit(actor){return (actor?.inventory||[]).find(item=>String(item.name||'').startsWith('Перевязочный комплект')&&Number(item.uses||0)>0);}
function showHealPicker(targetToken){
 const actor=ownedActor(),target=actorById(targetToken?.refId);if(!actor||!target)return;cancelPick(false);const entries=[];
 if(target.medical?.bleeding){
  if(bandageKit(actor))entries.push({name:'Остановить Кровотечение',meta:'Перевязочный комплект · 1 ОД',action:'heal-direct',args:{targetId:target.id,method:'bandage'},button:'Помочь'});
  if(Number(actor.traits?.initial?.['Бережливый']||0)>0&&Number(actor.resources?.reserve||0)>0)entries.push({name:'Остановить Кровотечение',meta:'Потратить 1 Запас · 1 ОД',action:'heal-direct',args:{targetId:target.id,method:'bandage',reserve:true},button:'Запас'});
  if(!bandageKit(actor)&&!(Number(actor.traits?.initial?.['Бережливый']||0)>0&&Number(actor.resources?.reserve||0)>0))entries.push({name:'Остановить Кровотечение',meta:'Нет перевязочного комплекта или Запаса',action:'heal-direct',args:{targetId:target.id,method:'bandage'},disabled:true,button:'Недоступно'});
 }
 if(target.wounds?.critical)entries.push({name:'Стабилизировать',meta:'Медицина против 1к6 · 2 ОД',action:'heal-direct',args:{targetId:target.id,method:'stabilize'},button:'Проверка'});
 if(!bridge.combat()&&bridge.session().mode==='master'&&healerHasKit(actor)&&Array.isArray(target.woundList)&&target.woundList.some(w=>Number(w.severity)<4))entries.push({name:'Уход за раной',meta:'Вне боя · Набор лекаря · сложность задаёт Ведущий',action:'heal-care-wounds',args:{targetId:target.id},button:'Выбрать'});
 if(!bridge.combat()&&bridge.session().mode==='master'&&healerHasKit(actor))entries.push({name:'Лечение травмы',meta:'Конечность/сустав · параметры лечения определяет Ведущий',action:'heal-trauma-name',args:{targetId:target.id},button:'Описать'});
 if(!entries.length)entries.push({name:'Сейчас помощь не требуется',meta:bridge.combat()?'Нет Кровотечения или Критического ранения':'Нет подходящего действия',action:'heal-direct',args:{targetId:target.id,method:'bandage'},disabled:true,button:'—'});
 showCompactMenu(`Помощь · ${target.name}`,entries,targetToken);
}
function showCareWounds(targetId){
 const target=actorById(targetId),token=tokenByActorId(targetId)||selected;if(!target)return;const wounds=(target.woundList||[]).filter(w=>Number(w.severity)<4);
 showCompactMenu(`Уход · ${target.name}`,wounds.map(w=>({name:woundSeverityLabel(w.severity),meta:`Ранение ${String(w.id).slice(0,6)}`,action:'heal-care-difficulty',args:{targetId,method:'care',woundId:w.id},button:'Выбрать'})),token);
}
function showCareDifficulty(args){
 const token=tokenByActorId(args.targetId)||selected;showCompactMenu('Сложность ухода',[4,6,8,10,12].map(sides=>({name:`1к${sides}`,meta:'Решение Ведущего по условиям лечения',action:'heal-direct',args:{...args,difficulty:sides},button:'Проверка'})),token);
}
function showTraumaDifficulty(args){
 const token=tokenByActorId(args.targetId)||selected;showCompactMenu('Сложность лечения травмы',[4,6,8,10,12].map(sides=>({name:`1к${sides}`,meta:'Ведущий определяет сложность по травме, времени и условиям',action:'heal-direct',args:{...args,method:'trauma',difficulty:sides},button:'Проверка'})),token);
}

function inventoryItem(itemId){return ownedActor()?.inventory?.find(item=>item.id===itemId&&item.kind==='item')||null;}
function beginItemTarget(itemId,flow='direct'){
 const item=inventoryItem(itemId);if(!item)return;hideQuickPopup();pick={kind:'item-target',allowSelf:true,message:{itemId,flow}};document.body.classList.add('bm-targeting');bridge.previewStart?.({actorId:selected?.refId,type:'line',maxRange:5,label:item.name});bridge.describe?.(`Выберите цель для «${item.name}».`);bridge.toast(`«${item.name}»: выберите цель в пределах 5 футов. Esc — отмена.`);
}
function showNativeItem(itemId){
 const item=inventoryItem(itemId);if(!item)return;const name=String(item.name||'');
 if(name.startsWith('Перевязочный комплект')||name==='Набор лекаря')return beginHealTarget();
 if(name==='Противоядие')return beginItemTarget(item.id,'direct');
 if(name==='Шина и перевязь')return beginItemTarget(item.id,'splint');
 if(['Факел','Масляный фонарь'].includes(name))return finishMapAction('item',{itemId:item.id,targetId:ownedActor()?.id}).catch(()=>{});
 if(name==='Ремонтный набор брони')return showRepairPicker();
 const meta=name==='Точильный набор'?'По правилам сам по себе не даёт боевого бонуса.':name==='Походный припас'?'Расходуется при привале, а не отдельной боевой кнопкой.':'Правила не задают этому предмету отдельного автоматического эффекта карты.';
 return showCompactMenu(name,[{name:'Использование определяется ситуацией',meta,action:'sheet',args:{},button:'Открыть лист',primary:false}],selected);
}
function continueItemTarget(current,targetToken){
 const item=inventoryItem(current.message.itemId);if(!item)return cancelPick();cancelPick(false);if(current.message.flow==='splint')return showTextEntryMenu(item.name,'Подходящая травма','', 'item-splint-finalize',{itemId:item.id,targetId:targetToken.refId},targetToken);return finishMapAction('item',{itemId:item.id,targetId:targetToken.refId}).catch(()=>{});
}
function repairableItems(actor){return (actor?.inventory||[]).filter(item=>{if(item.kind==='weapon')return !!item.damaged;if(!['armor','shield'].includes(item.kind))return false;const profile=(item.kind==='armor'?catalog?.armor:catalog?.shields)?.find(row=>row.id===item.profileId);return profile&&Number(item.bzCurrent||0)<Number(profile.bz||0);});}
function showRepairPicker(){
 const actor=ownedActor();if(!actor)return;if(bridge.combat()){bridge.toast('Ремонт выполняется в безопасной обстановке вне боя.','error');return;}const items=repairableItems(actor);showCompactMenu('Ремонт снаряжения',items.map(item=>{const profile=(item.kind==='armor'?catalog?.armor:item.kind==='shield'?catalog?.shields:catalog?.weapons)?.find(row=>row.id===item.profileId);return {name:item.model||item.name,meta:item.kind==='weapon'?'Повреждено':`БЗ ${Number(item.bzCurrent||0)}/${Number(profile?.bz||0)}`,action:'repair-method',args:{itemId:item.id},button:'Ремонт'};}).concat(items.length?[]:[{name:'Нет повреждённого снаряжения',meta:'Ремонт сейчас не требуется.',action:'sheet',args:{},disabled:true,button:'—'}]),selected);
}
function showRepairMethod(itemId){
 const item=ownedActor()?.inventory?.find(row=>row.id===itemId);if(!item)return;const armor=['armor','shield'].includes(item.kind),entries=[{name:'Полевой ремонт',meta:armor?'1 час · ремонтный набор · Механика 1к6 · +1 БЗ':'Обычно Механика 1к6–1к8',action:'repair-difficulty',args:{itemId,workshop:false},button:'Далее'}];entries.push({name:'Мастерская',meta:armor?'4 часа · материалы · до +2 БЗ':'Полноценная мастерская даёт Преимущество',action:'repair-difficulty',args:{itemId,workshop:true},button:'Далее'});showCompactMenu(`Ремонт · ${item.model||item.name}`,entries,selected);
}
function showRepairDifficulty(args){
 if(bridge.session().mode!=='master'){bridge.toast('Сложность ремонта по конкретным условиям задаёт Ведущий.','error');return;}const item=ownedActor()?.inventory?.find(row=>row.id===args.itemId),armor=['armor','shield'].includes(item?.kind),suggested=armor&&!args.workshop?[6]:[4,6,8,10,12];showCompactMenu('Сложность ремонта',suggested.map(sides=>({name:`1к${sides}`,meta:args.workshop?'Мастерская · Преимущество':armor?'Полевой ремонт брони/щита':'Полевой ремонт оружия',action:'repair-finalize',args:{...args,difficulty:sides,tools:true,materials:true},button:'Проверка'})),selected);
}

function weaponAmmoCount(actor,weapon){return Math.max(0,Number(actor?.ammo?.[weapon?.ammo]||0));}
function canUseReserve(actor){return Number(actor?.traits?.initial?.['Бережливый']||0)>0&&Number(actor?.resources?.reserve||0)>0;}
function showReloadPicker(){
 const actor=ownedActor();if(!actor)return;const entries=[];
 for(const weapon of reloadableWeapons(actor)){
  const ready=actor.ready?.[weapon.id]||{},ammo=weaponAmmoCount(actor,weapon),reserve=canUseReserve(actor),used=actor.used?.combat||{};
  if(weapon.kind==='bow'){
   entries.push({name:weapon.name,meta:ready.drawn?'Уже натянут':weapon.name==='Тяжёлый боевой лук'?'Натянуть · 2 ОД':'Натянуть · 1 ОД',action:'reload',args:{weaponId:weapon.id},disabled:!!ready.drawn,description:`Натянуть ${weapon.name}`,button:ready.drawn?'Готов':'Натянуть'});continue;
  }
  const capacity=Number(weapon.capacity||1),loaded=Number(ready.loaded||0),full=loaded>=capacity;
  if(full){entries.push({name:weapon.name,meta:`заряжено ${loaded}/${capacity}`,action:'reload',args:{weaponId:weapon.id},disabled:true,button:'Готово'});continue;}
  const movedHeavy=weapon.kind==='crossbow'&&weapon.name==='Тяжёлый арбалет'&&actor.moved;
  if(ammo>0&&!movedHeavy)entries.push({name:weapon.name,meta:`заряжено ${loaded}/${capacity} · боеприпасы ${ammo}`,action:'reload',args:{weaponId:weapon.id},button:'Зарядить'});
  if(weapon.kind==='crossbow'&&reserve&&!movedHeavy)entries.push({name:`${weapon.name} · Запас`,meta:`не расходовать болт · Запас ${actor.resources.reserve}`,action:'reload',args:{weaponId:weapon.id,reserve:true},button:'Запас'});
  const crossbowMastery=weapon.kind==='crossbow'&&actor.mastery?.includes('Арбалетчик')&&!used['Арбалетчик'];
  if(crossbowMastery&&ammo>0)entries.push({name:`${weapon.name} · Арбалетчик`,meta:`перезарядка на 1 ОД дешевле${movedHeavy?' · разрешает после движения':''}`,action:'reload',args:{weaponId:weapon.id,mastery:'Арбалетчик'},button:'Мастерство'});
  if(crossbowMastery&&reserve)entries.push({name:`${weapon.name} · Арбалетчик + Запас`,meta:`снижение ОД · Запас ${actor.resources.reserve}`,action:'reload',args:{weaponId:weapon.id,mastery:'Арбалетчик',reserve:true},button:'Применить'});
  if(weapon.kind==='firearm'&&ammo<=0)entries.push({name:weapon.name,meta:`заряжено ${loaded}/${capacity} · нет древних зарядов`,action:'reload',args:{weaponId:weapon.id},disabled:true,button:'Нет зарядов'});
  if(weapon.kind==='crossbow'&&ammo<=0&&!reserve)entries.push({name:weapon.name,meta:`заряжено ${loaded}/${capacity} · нет болтов или Запаса`,action:'reload',args:{weaponId:weapon.id},disabled:true,button:'Нет боеприпасов'});
 }
 showCompactMenu('Подготовка оружия',entries,selected);
}
function showEscapePicker(){
 const actor=ownedActor(),bound=(actor.effects||[]).find(effect=>effect.key==='bound');if(!bound?.sourceId){bridge.toast('Нет Захвата, из которого можно вырваться.','error');return;}
 const targetToken=bridge.scene()?.tokens?.find(token=>token.refId===bound.sourceId)||selected;
 showCompactMenu('Вырваться из Захвата',[{name:'Физическая сила',action:'tactical',args:{tactical:'escape',targetId:bound.sourceId,defense:'strength'},button:'Попытка'},{name:'Акробатика',action:'tactical',args:{tactical:'escape',targetId:bound.sourceId,defense:'dodge'},button:'Попытка'}],targetToken);
}
function showGrappleDefensePicker(targetToken){
 const target=actorById(targetToken?.refId);if(!target)return;
 showCompactMenu(`Захват · ${target.name}`,[{name:'Физическая сила',meta:'Цель сопротивляется силой',action:'tactical',args:{tactical:'grapple',targetId:target.id,defense:'strength'},button:'Захват'},{name:'Акробатика',meta:'Цель пытается выскользнуть',action:'tactical',args:{tactical:'grapple',targetId:target.id,defense:'dodge'},button:'Захват'}],targetToken);
}
function showInterceptPicker(){
 const actor=ownedActor(),charger=data?.campaign?.characters?.map(row=>row.state).find(other=>(other.effects||[]).some(effect=>effect.key==='charge'&&effect.targetId===actor.id));if(!charger){bridge.toast('Нет Натиска для Перехвата.','error');return;}
 const chargerWeapon=equippedWeapons(charger)[0]?.id||'unarmed',kop=actor.mastery?.includes('Копейщик')&&!actor.used?.combat?.['Копейщик'];
 const weapons=equippedWeapons(actor).filter(weapon=>/Упор/.test(propertiesOf(weapon))),entries=[];
 for(const weapon of weapons){entries.push({name:weapon.name,meta:'Упор',action:'tactical',args:{tactical:'intercept',targetId:charger.id,weaponId:weapon.id,targetWeaponId:chargerWeapon},button:'Перехват'});if(kop)entries.push({name:`${weapon.name} · Копейщик`,meta:'1/бой · Перехват с Преимуществом',action:'tactical',args:{tactical:'intercept',targetId:charger.id,weaponId:weapon.id,targetWeaponId:chargerWeapon,mastery:'Копейщик'},button:'Мастерство'});}
 const targetToken=bridge.scene()?.tokens?.find(token=>token.refId===charger.id)||selected;
 showCompactMenu('Перехват Натиска',entries.length?entries:[{name:'Нет оружия с Упором',meta:'Перехват недоступен',action:'sheet',args:{},disabled:true,button:'—'}],targetToken);
}
function showTacticalCheckPicker(tactical,heavyArmor=false){
 const label=tactical==='jump'?'Прыжок':'Карабкаться',cost=tactical==='jump'?1:2,entries=[4,6,8,10,12].map(sides=>({name:`1к${sides}`,meta:`${label} · ${cost} ОД${heavyArmor?' · Помеха от брони':''}`,action:'tactical',args:{tactical,difficulty:sides,heavyArmor},button:'Проверка'}));
 showCompactMenu(label,entries,selected);
}
function showTacticalConditionPicker(tactical){
 const label=tactical==='jump'?'Прыжок':'Карабкаться';
 showCompactMenu(label,[{name:'Обычные условия',meta:'без дополнительной Помехи',action:'tactical-check-difficulty',args:{tactical,heavyArmor:false},button:'Сложность'},{name:'Броня мешает движению',meta:'применить Помеху, если это уместно по ситуации',action:'tactical-check-difficulty',args:{tactical,heavyArmor:true},button:'Сложность'}],selected);
}


async function apiAction(action,args={},options={}){
 if(!data)await load();const session=bridge.session(),actorId=options.actorId||args.actorId||selected?.refId;
 const payload={action,...args,actorId,sceneId:args.sceneId||bridge.scene()?.id,campaignId:data.campaign.campaignId,revision:data.tol.revision,requestId:uuid(),clientId:session.clientId,presenceToken:session.presenceToken};
 const response=await fetch('/api/tol/action',{method:'POST',headers:{'Content-Type':'application/json','X-Fatum-Presence-Token':session.presenceToken||''},body:JSON.stringify(payload)});const result=await response.json();if(!response.ok)throw Error(result.error||`HTTP ${response.status}`);if(result.revision!==undefined)data.tol.revision=result.revision;return result;
}
async function finishMapAction(action,args={},options={}){
 try{
  const response=await apiAction(action,args,options),result=response.result;
  bridge.visualize?.(action,result);
  if(['combat-start','combat-next','combat-end'].includes(action)&&Array.isArray(result?.autoFinalizedResults))for(const finalized of result.autoFinalizedResults){bridge.visualize?.(`${action}-auto`,finalized);if(['melee','ranged'].includes(finalized?.kind)&&finalized?.settled&&finalized?.hit&&finalized?.targetId)bridge.hitActor?.(finalized.targetId,finalized.damage||1);}
  if(result?.text||result?.formula)bridge.toast(result.text||result.formula);
  await bridge.refresh();await load();return result;
 }catch(error){bridge.toast(error.message,'error');throw error;}
}
async function performQuickAttack(weaponId,damageType){
 const actor=ownedActor(),targetId=quickContext?.targetActorId;if(!actor||!targetId)return;
 const targetToken=bridge.scene()?.tokens?.find(token=>token.refId===targetId);hideQuickPopup();
 if(targetToken?.stealthRuntime?.active){bridge.toast('Цель находится в Скрытности: обычная атака и выстрел невозможны. Используйте площадное воздействие.','error');return;}
 try{
  const result=await finishMapAction('attack-resolve',{targetId,weaponId,damageType:damageType||undefined});
  if(result?.resolutionPending){selectedSuperiority.set(result.reactionId,new Set(result.selectedSuperiority||[]));syncReactionPanels();}
  else if(result?.hit)bridge.hitActor?.(targetId,result.damage||1);
 }finally{bridge.previewClear?.();if(targetToken)bridge.select?.(selected?.id);}
}

function reactionOptions(reaction){
 const result=reaction?.result||{},attacker=actorById(reaction.actorId),defender=actorById(reaction.targetId),picked=selectedSuperiority.get(reaction.id)||new Set(reaction.selectedSuperiority||[]),out=[];
 if(['followup','bodyguard','opportunity'].includes(reaction.kind))return (reaction.options||[]).map(option=>({id:option.id,label:option.label,actorId:option.actorId||attacker?.id,masterOnly:!!option.masterOnly,effect:option.shortEffect||option.effect||option.label}));
 if(reaction.kind==='check'){
  if(Array.isArray(reaction.options))return reaction.options.map(option=>({id:option.id,label:option.label,actorId:option.actorId||attacker?.id,masterOnly:!!option.masterOnly,needsContext:!!option.needsContext,effect:option.shortEffect||option.effect||option.label}));
  if(attacker?.resources?.coins>0&&!result.coinUsed&&!result.fortuneUsed&&!result.edge)out.push({id:'coin-check',label:'Счастливая монета',actorId:attacker.id,effect:'Перебросить проверку целиком. Второй результат обязателен.'});
  if(!result.success&&attacker?.resources?.fortune>0&&!result.coinUsed&&!result.fortuneUsed&&!result.edge)out.push({id:'fortune-check',label:'Фортуна',actorId:attacker.id,effect:'Перебросить проваленную проверку.'});
  if(result.edgeAvailable&&!result.success&&!result.edge){out.push({id:'edge-check',label:'Успех на грани',actorId:attacker.id,effect:'Принять успех ценой последствия.'});if(Number(attacker?.traits?.bonus?.['Удачливый']||0)>=5&&attacker?.resources?.fortune>0)out.push({id:'edge-fortune',label:'На грани + Фортуна',actorId:attacker.id,effect:'Снизить тяжесть принятого последствия на одну ступень.'});}
  return out;
 }
 if(reaction.kind==='magic'){
  if(attacker?.resources?.coins>0&&!result.rerolled&&!result.forcedInterruption)out.push({id:'coin-caster',label:'Счастливая монета',actorId:attacker.id,effect:'Перебросить d100 Магии. Второй результат обязателен.'});
  if(!result.success&&Number(result.severity)!==Number(result.baseSeverity))out.push({id:'adjudication',label:'Подтверждение Ведущего',actorId:attacker?.id,masterOnly:true,effect:`Последствие ${result.severity} вместо базового ${result.baseSeverity}. Текстовый ввод не требуется.`});
  return out;
 }
 if(attacker?.resources?.coins>0&&!result.coinUsed&&!result.fortuneUsed)out.push({id:'coin-attacker',label:'Счастливая монета',actorId:attacker.id,effect:'Перебросить свой бросок. Второй результат обязателен.'});
 if(result.kind==='melee'&&result.defense?.mode!=='incapacitated'&&defender?.resources?.coins>0&&!result.defense?.coinUsed)out.push({id:'coin-defender',label:'Счастливая монета',actorId:defender.id,effect:'Перебросить бросок защиты.'});
 if(!result.hit&&attacker?.resources?.fortune>0&&!result.fortuneUsed&&!result.coinUsed)out.push({id:'fortune-attacker',label:'Фортуна',actorId:attacker.id,effect:'Перебросить проваленную атаку.'});
 if(result.hit&&Number(defender?.traits?.bonus?.['Удачливый']||0)>=2&&defender?.resources?.fortune>0&&!result.fortuneForcedReroll)out.push({id:'fortune-defender',label:'Удачливый',actorId:defender.id,effect:'Заставить атакующего перебросить успешную атаку.'});
 if(Number(result.superiority||0)>picked.size){const choices=['damage','push','opening'];if(/Щитолом/.test(propertiesOf(result.weapon)))choices.push('shield');if(/Крючье/.test(propertiesOf(result.weapon)))choices.push('hook');if(attacker?.species==='gnoll'&&result.weapon?.id==='natural')choices.push('grapple');out.push({id:'superiority',label:'Превосходство',actorId:attacker?.id,choices,effect:`Выберите ${Number(result.superiority)-picked.size} эффект(а).`});}
 return out;
}
function reactionActorAllowed(actorId){return bridge.session().mode==='master'||actorId===selected?.refId;}
function ensureReactionLayer(){
 let layer=$('roll-reaction-layer');if(layer)return layer;layer=document.createElement('div');layer.id='roll-reaction-layer';layer.className='bm-roll-reaction-layer';$('stage')?.appendChild(layer);return layer;
}
const superiorityLabels={damage:'+1 урон',push:'Оттеснить 5 фт',opening:'+1 к следующему Обмену',shield:'Повредить щит',hook:'Крючье',grapple:'Захват'};
function reactionPosition(reaction,index){if(!bridge?.reactionPosition)throw new Error('Classic reaction-panel positioning is unavailable.');return bridge.reactionPosition(reaction.actorId,reaction.targetId,index)||{left:8,top:58};}
function syncReactionPanels(){
 const layer=ensureReactionLayer();if(!layer)return;const reactions=data?.tol?.reactions||[],visible=[],active=new Set();
 for(const reaction of reactions){const options=reactionOptions(reaction).filter(option=>(!option.masterOnly&&reactionActorAllowed(option.actorId))||(option.masterOnly&&bridge.session().mode==='master'));const selectedInvolved=reaction.kind==='followup'?reaction.actorId===selected?.refId:[reaction.actorId,reaction.targetId].includes(selected?.refId);if(options.length||selectedInvolved||bridge.session().mode==='master')visible.push({reaction,options});}
 visible.forEach(({reaction,options},index)=>{
  const result=reaction.result||{},attacker=actorById(reaction.actorId),defender=actorById(reaction.targetId),pos=reactionPosition(reaction,index),picked=selectedSuperiority.get(reaction.id)||new Set(reaction.selectedSuperiority||[]),magic=reaction.kind==='magic',check=reaction.kind==='check',followup=reaction.kind==='followup',bodyguard=reaction.kind==='bodyguard',opportunity=reaction.kind==='opportunity',needsAdjudication=magic&&!result.success&&Number(result.severity)!==Number(result.baseSeverity),canAdjudicate=bridge.session().mode==='master';
  const title=bodyguard?(result.title||'Телохранитель'):opportunity?(result.title||'Провоцированная атака'):followup?(result.title||'Доступная возможность'):check?`${attacker?.name||'Персонаж'} · ${result.skill||'Проверка'}`:magic?`${attacker?.name||'Маг'} · ${result.spellName||'Магия'}`:`${attacker?.name||'Атакующий'} → ${defender?.name||'Цель'}`;
  const subtitle=bodyguard?(result.summary||'Локальная реакция на объявленную атаку.'):opportunity?(result.summary||'Цель покидает ближний бой без Отхода.'):followup?(result.summary||'Решите сейчас или пропустите.'):check?`${result.total} против ${result.target} · ${result.success?'успех':'провал'}`:magic?`${result.formula||''} · ${result.success?'успех':`Последствие ${result.severity}`}`:(result.kind==='melee'?`Обмен ${result.total} : ${result.target}`:`Атака ${result.total} против МЗ ${result.target}`);
  const acceptText=opportunity?'Не атаковать':followup?'Пропустить':needsAdjudication?'Принять Последствие':'Принять результат';
  const acceptTitle=opportunity?'Пропустить провоцированную атаку':followup?'Пропустить дополнительную возможность':'Принять результат';
  const actionsHtml=options.filter(option=>!['superiority','adjudication'].includes(option.id)).map(option=>`<button class="bm-roll-reaction-button" data-tol-reaction-action="${esc(option.id)}" data-reaction-id="${esc(reaction.id)}" data-actor-id="${esc(option.actorId)}" ${reactionBusy?'disabled':''}><strong>${esc(option.label)}</strong><small>${esc(option.effect)}</small></button>`).join('')+options.filter(option=>option.id==='superiority').map(option=>`<div class="bm-roll-reaction-hint">${esc(option.effect)}</div><div class="tol-superiority-grid">${option.choices.map(choice=>`<button class="bm-roll-reaction-button ${picked.has(choice)?'active':''}" data-tol-superiority="${esc(choice)}" data-reaction-id="${esc(reaction.id)}" data-actor-id="${esc(option.actorId)}" ${reactionBusy?'disabled':''}><strong>${picked.has(choice)?'✓ ':''}${esc(superiorityLabels[choice]||choice)}</strong></button>`).join('')}</div>`).join('')+(needsAdjudication?`<div class="bm-roll-reaction-hint"><strong>Изменённая тяжесть Обратного удара</strong><br>${esc(result.backlash||'')}<br>${canAdjudicate?'Нажмите «Принять Последствие». Конкретное изменение Ведущий озвучивает за столом; VTT ничего вводить не требует.':'Ожидается решение Ведущего; карта при этом не блокируется.'}</div>`:'');
  if(!bridge?.reactionPanelInner)throw new Error('Classic reaction-panel renderer is unavailable.');
  const inner=bridge.reactionPanelInner({title,subtitle,actionsHtml,showClose:!bodyguard,showAccept:!bodyguard,closeAttrs:`data-tol-reaction-accept="${esc(reaction.id)}"`,acceptAttrs:`data-tol-reaction-accept="${esc(reaction.id)}" data-actor-id="${esc(reaction.actorId||selected?.refId||'')}"`,closeTitle:acceptTitle,acceptLabel:acceptText,disabled:reactionBusy||needsAdjudication&&!canAdjudicate});
  const id=String(reaction.id),signature=inner,existing=Array.from(layer.querySelectorAll('[data-tol-reaction]')).find(node=>node.dataset.tolReaction===id);let panel=existing;
  if(!panel){panel=document.createElement('section');panel.className='bm-roll-reaction-panel';panel.dataset.tolReaction=id;layer.appendChild(panel);}
  panel.style.left=`${pos.left}px`;panel.style.top=`${pos.top}px`;
  // Match Classic: do not recreate reaction buttons on every state refresh. Replacing
  // the DOM between pointerdown and pointerup cancels the click and makes close/accept
  // appear unresponsive. Only refresh the contents when the actual panel changes.
  if(panel.dataset.renderSignature!==signature){panel.innerHTML=inner;panel.dataset.renderSignature=signature;}
  active.add(id);
 });
 layer.querySelectorAll('[data-tol-reaction]').forEach(panel=>{if(!active.has(panel.dataset.tolReaction))panel.remove();});
 layer.dataset.hasPanels=active.size?'1':'0';
}

async function applyReaction(reactionId,choice,actorId){
 if(reactionBusy)return;const reaction=data?.tol?.reactions?.find(item=>item.id===reactionId);if(!reaction)return;
 if(reaction.kind==='check'&&['edge-check','edge-fortune'].includes(choice)){const actorToken=tokenByActorId(reaction.actorId)||selected;showTextEntryMenu('Успех на грани','Цена успеха','', 'check-edge-finalize',{reactionId,choice},actorToken,'consequence','Опишите принятую цену или осложнение.');return;}
 if(reaction.kind==='check'&&(choice.startsWith('character:')||choice.startsWith('belief:'))){const actorToken=tokenByActorId(reaction.actorId)||selected,title=choice.startsWith('character:')?choice.slice(10):choice.slice(7);showTextEntryMenu(title,'Связь с ситуацией / цена','', 'check-context-finalize',{reactionId,choice},actorToken,'context','Коротко опишите, почему эффект применим к этому броску.');return;}
 reactionBusy=true;syncReactionPanels();
 try{const action=reaction.kind==='bodyguard'?'bodyguard-reaction':reaction.kind==='opportunity'?'opportunity-reaction':reaction.kind==='followup'?'followup-reaction':reaction.kind==='magic'?'magic-reaction':reaction.kind==='check'?'check-reaction':'attack-reaction';const result=await finishMapAction(action,{reactionId,choice},{actorId});if(reaction.kind==='attack'||result?.kind==='melee'||result?.kind==='ranged'){if(result?.reactionId)selectedSuperiority.set(result.reactionId,new Set(result.selectedSuperiority||[]));if(!result?.resolutionPending&&result?.hit&&result?.targetId)bridge.hitActor?.(result.targetId,result.damage||1);}if(result?.pickPoint)beginPoint('free-move',{effectId:result.effectId,pickPoint:true,originActorId:result.moveActorId,actorId:reaction.actorId,maxRange:Number(result.maxRange||5),label:'Смещение'});}
 finally{reactionBusy=false;syncReactionPanels();}
}
async function toggleSuperiority(reactionId,choice,actorId){
 const reaction=data?.tol?.reactions?.find(item=>item.id===reactionId);if(!reaction)return;const limit=Number(reaction.result?.superiority||0),set=new Set(selectedSuperiority.get(reactionId)||reaction.selectedSuperiority||[]);if(set.has(choice))set.delete(choice);else if(set.size<limit)set.add(choice);else{bridge.toast(`Можно выбрать эффектов: ${limit}.`,'error');return;}
 if(reactionBusy)return;reactionBusy=true;syncReactionPanels();
 try{const result=await finishMapAction('attack-reaction',{reactionId,choice:'superiority',superiority:[...set]},{actorId});selectedSuperiority.set(reactionId,new Set(result.selectedSuperiority||[]));}
 finally{reactionBusy=false;syncReactionPanels();}
}
async function acceptReaction(reactionId,actorId){
 if(reactionBusy)return;const reaction=data?.tol?.reactions?.find(item=>item.id===reactionId),targetId=reaction?.targetId,magic=reaction?.kind==='magic',check=reaction?.kind==='check',followup=reaction?.kind==='followup',opportunity=reaction?.kind==='opportunity',args={reactionId};if(magic&&!reaction.result.success&&Number(reaction.result.severity)!==Number(reaction.result.baseSeverity))args.adjustment={};
 reactionBusy=true;syncReactionPanels();
 try{const action=opportunity?'opportunity-reaction':followup?'followup-accept':magic?'magic-accept':check?'check-accept':'attack-accept',payload=opportunity?{reactionId,choice:'opportunity:skip'}:args;const result=await finishMapAction(action,payload,{actorId:actorId||reaction?.actorId||selected?.refId});selectedSuperiority.delete(reactionId);hideQuickPopup();if(!opportunity&&!followup&&!magic&&!check&&result?.hit&&targetId)bridge.hitActor?.(targetId,result.damage||1);}
 finally{reactionBusy=false;syncReactionPanels();}
}

async function classicSkillProfile(actorId,combatContext=false){
 if(!data)await load();const actor=actorById(actorId);if(!actor)return {skills:[],optionsBySkill:{}};const session=bridge.session(),qs=new URLSearchParams({actorId:String(actorId),combatContext:combatContext?'1':'0',mode:session.mode==='master'?'master':'player',clientId:session.clientId||''});
 const response=await fetch(`/api/tol/check-profile?${qs}`,{headers:{'X-Fatum-Presence-Token':session.presenceToken||''}}),payload=await response.json();if(!response.ok)throw Error(payload.error||`HTTP ${response.status}`);return payload;
}

async function rollClassicSkillPopover(args={}){
 const actor=actorById(args.actorId)||ownedActor();if(!actor)return null;
 const condition=String(args.condition||'normal'),payload={skill:args.skill,difficulty:Number(args.difficulty||6),difficultyModifier:Number(args.difficultyModifier||0),combat:Boolean(args.combatContext),extraDice:Array.isArray(args.extraDice)?args.extraDice:[],optionIds:Array.isArray(args.optionIds)?args.optionIds:[],optionContexts:args.optionContexts&&typeof args.optionContexts==='object'?args.optionContexts:{}};
 if(condition==='advantage')payload.advantage=true;else if(condition==='hindrance')payload.hindrance=true;
 const result=await finishMapAction('check-resolve',payload);if(result?.resolutionPending)syncReactionPanels();return result;
}

async function execute(action,args={},extra={}){
 if(action==='mini-sheet')return showMiniSheet();
 if(action==='full-sheet')return openFullSheet(args.tab||extra.tab||'combat');
 if(action==='attack-target')return beginAttackTarget();
 if(action==='attack-weapon-target')return beginWeaponAttackTarget(args);
 if(action==='category')return renderCategory(args.category);
 if(action==='check-popover')return bridge.openSkill?.(selected?.refId);
 if(action==='check-skill')return showSkillDifficulty(args.skill);
 if(action==='check-direct')return finishMapAction('check-resolve',args).then(result=>{if(result?.resolutionPending)syncReactionPanels();}).catch(()=>{});
 if(action==='heal-target')return beginHealTarget();
 if(action==='heal-direct')return finishMapAction('heal',args);
 if(action==='heal-care-wounds')return showCareWounds(args.targetId);
 if(action==='heal-care-difficulty')return showCareDifficulty(args);
 if(action==='heal-trauma-name')return showTextEntryMenu('Лечение травмы','Травма конечности/сустава','', 'heal-trauma-difficulty',args,tokenByActorId(args.targetId)||selected,'injury','Коротко укажите травму, которую обрабатывает персонаж.');
 if(action==='heal-trauma-difficulty')return showTraumaDifficulty(args);
 if(action==='item-native')return showNativeItem(args.itemId);
 if(action==='item-direct')return finishMapAction('item',args);
 if(action==='item-splint-finalize')return finishMapAction('item',{...args,injury:args.category});
 if(action==='repair-native')return showRepairPicker();
 if(action==='repair-method')return showRepairMethod(args.itemId);
 if(action==='repair-difficulty')return showRepairDifficulty(args);
 if(action==='repair-finalize')return finishMapAction('repair',args);
 if(action==='check-edge-finalize')return finishMapAction('check-reaction',{reactionId:args.reactionId,choice:args.choice,consequence:args.consequence}).then(result=>{if(result?.resolutionPending)syncReactionPanels();}).catch(()=>{});
 if(action==='check-context-finalize')return finishMapAction('check-reaction',{reactionId:args.reactionId,choice:args.choice,context:args.context}).then(result=>{if(result?.resolutionPending)syncReactionPanels();}).catch(()=>{});
 if(action==='attack-finalize'){hideQuickPopup();return finishMapAction('attack-resolve',args).then(result=>{if(result?.resolutionPending){selectedSuperiority.set(result.reactionId,new Set(result.selectedSuperiority||[]));syncReactionPanels();}else if(result?.hit&&args.targetId)bridge.hitActor?.(args.targetId,result.damage||1);}).catch(()=>{});}
 if(action==='feature-native')return args.kind==='trait'?runTraitNative(args.name):args.kind==='species'?runSpeciesNative(args.feature):runMasteryNative(args.name);
 if(action==='trait-direct')return finishMapAction('trait',args).catch(()=>{});
 if(action==='trait-loss-target')return showTextEntryMenu(`${args.name} · потеря Морали`,'Исходная потеря Морали','', 'trait-direct',args,tokenByActorId(args.targetId)||selected,'loss','Введите потерю до уменьшения.');
 if(action==='mastery-direct')return finishMapAction('mastery',args).catch(()=>{});
 if(action==='species-direct')return finishMapAction('species',args).catch(()=>{});
 if(action==='character-native')return beginCharacterContext(args.name,args.feature);
 if(action==='character-mode')return characterMode(args);
 if(action==='character-context')return characterContext(args);
 if(action==='character-direct')return finishMapAction('character',args).catch(()=>{});
 if(action==='character-loss-finalize')return finishMapAction('character',{...args,loss:Number(args.loss||0)}).catch(()=>{});
 if(action==='belief-native')return beginBeliefNative(args.name,false);
 if(action==='core-belief-native')return beginBeliefNative(args.name,true);
 if(action==='core-belief-finalize')return finishMapAction('character',{feature:'core',context:args.context}).catch(()=>{});
 if(action==='belief-context')return beliefContext(args);
 if(action==='belief-reduce-start')return showTextEntryMenu(`${args.name} · потеря Морали`,'Исходная потеря Морали','', 'belief-loss-finalize',args,selected,'loss','Введите потерю до уменьшения.');
 if(action==='belief-community-target')return featureTarget('belief-community-choice',args,'Союзник рода / общины',0,true);
 if(action==='belief-community-choice')return showBeliefCommunityChoice(args);
 if(action==='belief-target-start')return featureTarget('belief-direct',args,args.name,0,true);
 if(action==='belief-direct')return finishMapAction('belief',args).catch(()=>{});
 if(action==='belief-loss-finalize')return finishMapAction('belief',{...args,mode:'reduce',loss:Number(args.loss||0)}).catch(()=>{});
 if(action==='magic-map')return beginNativeMagic(args.spellId);
 if(action==='magic-finalize')return finishMapAction('magic-resolve',args).then(result=>{if(result?.resolutionPending)syncReactionPanels();}).catch(()=>{});
 if(action==='magic-raised-mode-start'){const spell=catalog?.spells?.find(item=>item.id===args.spellId);if(spell)return showRaisedCastMode(spell,args);return;}
 if(action==='magic-raised-resistance')return chooseRaisedResistance(args);
 if(action==='magic-raised-mode')return finishMapAction('magic-resolve',{...args,ritual:true,beginRitual:true,ritualMinutes:10}).then(result=>{if(result?.resolutionPending)syncReactionPanels();}).catch(()=>{});
 if(action==='magic-willing-menu'){const spell=catalog?.spells?.find(item=>item.id===args.spellId);if(spell)return showWillingChoice(spell,args,args.targetId);return;}
 if(action==='magic-turn-recipient-start'){const spell=catalog?.spells?.find(item=>item.id===args.spellId),spec=spellMapSpec(spell);if(!spell||!spec)return;const nextArgs={...args};delete nextArgs.targetId;return startSpellTarget(spell,spec,nextArgs,'turn-recipient');}
 if(action==='magic-damage-target-start'){const spell=catalog?.spells?.find(item=>item.id===args.spellId),spec=spellMapSpec(spell);if(spell&&spec)return startSpellTarget(spell,spec,args,'cast');return;}
 if(action==='magic-shadow-point'){const spell=catalog?.spells?.find(item=>item.id===args.spellId),spec=spellMapSpec(spell);if(spell&&spec)return startSpellPoint(spell,spec,args,'cast');return;}
 if(action==='magic-great-seal-point'){const spell=catalog?.spells?.find(item=>item.id===args.spellId),spec=spellMapSpec(spell);if(spell&&spec)return startSpellPoint(spell,spec,{...args},'cast');return;}
 if(action==='magic-path-point'){const spell=catalog?.spells?.find(item=>item.id===args.spellId),spec=spellMapSpec(spell);if(spell&&spec)return startSpellPoint(spell,spec,{...args,willing:true},'cast');return;}
 if(action==='magic-self-area-cast'){bridge.previewClear?.();return finishMapAction('magic-resolve',{...args,centerActorId:ownedActor()?.id}).then(result=>{if(result?.resolutionPending)syncReactionPanels();}).catch(()=>{});}
 if(action==='magic-area-resistance'){const spell=catalog?.spells?.find(item=>item.id===args.spellId),spec=spellMapSpec(spell);if(!spell||!spec)return;if(spec.needsDamageType)return chooseAreaDamageType(spell,spec,{areaResistance:args.areaResistance});return startConfiguredArea(args);}
 if(action==='magic-area-start')return startConfiguredArea(args);
 if(action==='reload-picker')return showReloadPicker();
 if(action==='tactical-check')return showTacticalConditionPicker(args.tactical);
 if(action==='tactical-check-difficulty')return showTacticalCheckPicker(args.tactical,!!args.heavyArmor);
 if(action==='tactical-target')return beginTarget('tactical',args);
 if(action==='escape-picker')return showEscapePicker();
 if(action==='intercept-picker')return showInterceptPicker();
 if(action==='pavise-point')return beginPoint('pavise-place',{...args,pickPoint:true,maxRange:5,label:'Установить Павезу'});
 if(action==='free-move'&&args.pickPoint)return beginPoint(action,args);
 const direct=['combat-next','combat-start','combat-end','pending-cancel','free-move','map-item-pickup','pavise-place','npc-step','coin','reroll','fortune','follow-choice','ritual-hold','reload','tactical'];
 if(direct.includes(action)&&!args.pickPoint&&!args.pickTarget){try{return await finishMapAction(action,args,extra);}catch{return;}}
 bridge.toast(`Действие «${action}» не подключено к нативному интерфейсу Classic.`, 'error');
}

async function gmStats(actorId){if(!data)await load();const actor=actorById(actorId);if(!actor)return null;const wounds=actor.wounds||{},morale=actor.morale||{};return{wounds:{light:Number(wounds.light||0),lightMax:Number(wounds.lightMax||0),medium:Number(wounds.medium||0),mediumMax:Number(wounds.mediumMax||0),serious:Number(wounds.serious||0),seriousMax:Number(wounds.seriousMax||0),critical:Boolean(wounds.critical)},morale:{current:Number(morale.current||0),max:Number(morale.max||0)},od:{current:Number(actor.odCurrent||0),max:Number(actor.od||0)},ob:{current:Number(actor.resources?.tension||0),max:99},bz:{current:Number(actor.bz||0),max:Number(actor.armorBzMax||0)},speed:{effective:Number(actor.speed||actor.creatureSpeed||30)},mzOverride:null,tol:true};}
async function gmStatsSave(actorId,stats){return finishMapAction('gm-stats',stats||{},{actorId});}
async function gmLife(actorId,operation){return finishMapAction('gm-life',{operation},{actorId});}
async function gmContext(kind,actorId,args={}){if(kind==='combat'){if(!bridge.combat())return finishMapAction('combat-start',{tokenIds:[args.tokenId].filter(Boolean)},{actorId});return finishMapAction('combat-participant',{operation:args.operation||'add'},{actorId});}if(kind.startsWith('stealth-'))return finishMapAction('gm-stealth',{operation:kind.slice('stealth-'.length),...args},{actorId});if(kind.startsWith('quick-'))return finishMapAction('gm-quick-effect',{operation:kind.slice('quick-'.length),sceneId:bridge.scene()?.id,...args},{actorId});throw Error('Неизвестная мастерская команда ToL.');}

function install(){
 if(installed)return;bridge=window.FatumTolMapBridge;if(!bridge)return;installed=true;document.documentElement.dataset.ruleset='tol';
 const link=document.createElement('link');link.rel='stylesheet';link.href='/tol/map-ui.css?v=tol-story-items5';document.head.appendChild(link);
 ensureReactionLayer();

 document.addEventListener('click',event=>{
  const textAction=event.target.closest('[data-tol-text-action]');if(textAction){event.preventDefault();event.stopImmediatePropagation();let args={};try{args=JSON.parse(textAction.dataset.tolTextArgs||'{}');}catch{}const input=$('quick-weapon-list')?.querySelector('[data-tol-text-value]'),value=input?.value?.trim(),key=input?.dataset.tolTextKey||'category';if(!value){bridge.toast('Заполните поле.','error');return;}hideQuickPopup();execute(textAction.dataset.tolTextAction,{...args,[key]:value});return;}
  const multiToggle=event.target.closest('[data-tol-multi-toggle]');if(multiToggle&&quickContext?.type==='multi'){event.preventDefault();event.stopImmediatePropagation();const id=multiToggle.dataset.tolMultiToggle;if(quickContext.selected.has(id))quickContext.selected.delete(id);else if(quickContext.selected.size<quickContext.max)quickContext.selected.add(id);else{bridge.toast(`Можно выбрать не больше ${quickContext.max}.`,'error');return;}renderMultiSelectMenu();return;}
  const multiConfirm=event.target.closest('[data-tol-multi-confirm]');if(multiConfirm&&quickContext?.type==='multi'){event.preventDefault();event.stopImmediatePropagation();const ctx=quickContext,args={...(ctx.confirmArgs||{}),additionalIds:[...ctx.selected]},action=ctx.confirmAction;if(ctx.allowCanvas)cancelPick(false);hideQuickPopup();execute(action,args);return;}
  const reactionButton=event.target.closest('[data-tol-reaction-action]');if(reactionButton){event.preventDefault();event.stopImmediatePropagation();applyReaction(reactionButton.dataset.reactionId,reactionButton.dataset.tolReactionAction,reactionButton.dataset.actorId);return;}
  const superiorityButton=event.target.closest('[data-tol-superiority]');if(superiorityButton){event.preventDefault();event.stopImmediatePropagation();toggleSuperiority(superiorityButton.dataset.reactionId,superiorityButton.dataset.tolSuperiority,superiorityButton.dataset.actorId);return;}
  const acceptButton=event.target.closest('[data-tol-reaction-accept]');if(acceptButton){event.preventDefault();event.stopImmediatePropagation();const reaction=data?.tol?.reactions?.find(item=>item.id===acceptButton.dataset.tolReactionAccept),actorId=acceptButton.dataset.actorId||selected?.refId||reaction?.actorId;acceptReaction(acceptButton.dataset.tolReactionAccept,actorId);return;}
  const masteryMenu=event.target.closest('[data-tol-attack-mastery-menu]');if(masteryMenu){event.preventDefault();event.stopImmediatePropagation();showAttackMasteryPicker(masteryMenu.dataset.tolAttackMasteryMenu);return;}
  const quickWeapon=event.target.closest('[data-tol-quick-weapon]');if(quickWeapon){event.preventDefault();event.stopImmediatePropagation();performQuickAttack(quickWeapon.dataset.tolQuickWeapon,quickWeapon.dataset.tolDamageType);return;}
  if(event.target.closest('#quick-attack-cancel')&&quickContext){event.preventDefault();event.stopImmediatePropagation();cancelPick();return;}
  const button=event.target.closest('[data-tol-command]');if(button&&!button.disabled){event.preventDefault();const args=JSON.parse(button.dataset.tolArgs||'{}');hideQuickPopup();execute(button.dataset.tolCommand,args);}
 },true);

 window.addEventListener('pointerdown',event=>{
  if(pick||!bridge.isCanvas(event.target)||event.button!==0)return;const world=bridge.worldPoint(event),target=bridge.hitToken(world),tolType=target?.kind==='interactive'?target.interactive?.tolType:null;if(!['dropped-weapon','pavise'].includes(tolType))return;event.preventDefault();event.stopImmediatePropagation();const actor=ownedActor();if(!actor){bridge.toast('Сначала выберите свой токен.','error');return;}execute('map-item-pickup',{mapTokenId:target.id});
 },true);

 window.addEventListener('pointerdown',event=>{
  if(!pick||!bridge.isCanvas(event.target)||event.button!==0)return;const world=bridge.worldPoint(event),target=bridge.hitToken(world);
  const pointPick=['point','spell-point'].includes(pick.kind),allowSelf=Boolean(pick.allowSelf||pick.message?.allowSelf);if(!pointPick&&!target){bridge.toast('Выберите токен цели.');return;}if(target?.refId===selected?.refId&&!pointPick&&!allowSelf){bridge.toast('Нужно выбрать другой токен.','error');return;}
  event.preventDefault();event.stopImmediatePropagation();const current=pick;
  if(current.kind==='spell-multi'){
   const ctx=quickContext,candidateIds=new Set(current.message?.candidateIds||[]),actorId=target?.refId;if(ctx?.type!=='multi'||!ctx.allowCanvas||!actorId||!candidateIds.has(actorId)){bridge.toast('Для «Преломить путь» можно выбрать только живого соседнего спутника в 5 футах.','error');return;}
   if(ctx.selected.has(actorId))ctx.selected.delete(actorId);else if(ctx.selected.size<ctx.max)ctx.selected.add(actorId);else{bridge.toast(`Можно выбрать не больше ${ctx.max} спутников.`,'error');return;}renderMultiSelectMenu();bridge.toast(ctx.selected.has(actorId)?`${target.name}: добавлен в перенос.`:`${target.name}: исключён из переноса.`);return;
  }
  if(current.kind==='weapon-attack'){finishWeaponAttackTarget(current,target);return;}
  if(current.kind==='attack'){showAttackPicker(target);return;}
  if(current.kind==='heal-target'){showHealPicker(target);return;}
  if(current.kind==='item-target'){continueItemTarget(current,target);return;}
  if(current.kind==='spell-target'){continueSpellTarget(current,target);return;}
  if(current.kind==='spell-area-target'){const spell=catalog?.spells?.find(item=>item.id===current.message.spellId),spec=current.message.spec,args={...current.message.args,targetId:target?.refId};cancelPick(false);startSpellPoint(spell,spec,args);return;}
  if(current.kind==='spell-point'){continueSpellPoint(current,world);return;}
  if(current.kind==='command'&&current.message.action==='tactical'&&current.message.args?.tactical==='grapple'){cancelPick(false);showGrappleDefensePicker(target);return;}
  cancelPick(false);
  if(current.kind==='point'){const {action,args}=current.message;delete args.pickPoint;execute(action,{...args,point:world});return;}
  if(current.kind==='command'){const {action,args}=current.message;delete args.pickTarget;execute(action,{...args,targetId:target?.refId});}
 },true);

 window.addEventListener('keydown',event=>{if(event.key==='Escape')cancelPick();});
 window.addEventListener('fatum-tol-open',event=>{const token=bridge.scene()?.tokens.find(item=>item.refId===event.detail.actorId);if(token){selected=token;const actor=actorById(token.refId);if(actor?.isCreature)showMiniSheet(actor);else bridge.openFullSheet?.(token.refId,event.detail?.tab||'combat');}});
 window.addEventListener('fatum-tol-select',event=>{const token=bridge.scene()?.tokens.find(item=>item.refId===event.detail.actorId);if(token){selected=token;load();}});
 window.addEventListener('fatum-tol-opportunity-choice',async event=>{
  const detail=event.detail||{};if(!detail.reactionId||!detail.choice)return;
  try{
   if(loading)await loading;
   await load();
   const reaction=data?.tol?.reactions?.find(item=>item.id===detail.reactionId&&item.kind==='opportunity');
   if(!reaction){bridge.toast('Провоцированная атака уже разрешена.');return;}
   await applyReaction(detail.reactionId,detail.choice,detail.actorId||reaction.actorId);
  }catch(error){bridge.toast(error.message||'Не удалось выполнить провоцированную атаку.','error');}
 });
 window.addEventListener('fatum-tol-refresh',()=>{if(bridge.ruleset()==='tol')load();});
 document.addEventListener('click',event=>{const button=event.target.closest('[data-tol-sheet]');if(button){const token=bridge.scene()?.tokens.find(item=>item.refId===button.dataset.tolSheet);if(token){selected=token;const actor=actorById(token.refId);if(actor?.isCreature)showMiniSheet(actor);else bridge.openFullSheet?.(token.refId,'combat');}const menu=$('token-context-menu');if(menu)menu.hidden=true;}},true);
 load();setInterval(()=>{if(bridge.ruleset()==='tol')load();},1200);
}

fetch('/api/status').then(response=>response.json()).then(status=>{if(status.ruleset==='tol')install();}).catch(()=>{});
window.FatumTolInventory={
 async ready(){if(!bridge)install();await load();return true;},
 actor(actorId){return actorById(actorId);},
 record(actorId){return recordByActorId(actorId);},
 catalog(){return catalog;},
 async grant(actorId,kind,profileId,model=''){return finishMapAction('grant',{kind,profileId,model},{actorId});},
 async equip(actorId,itemId,slot=1,equipped=true){return finishMapAction('equip',{itemId,slot,equipped},{actorId});},
 async customAdd(actorId,{name,quantity=1,description=''}={}){return finishMapAction('custom-item-add',{name,quantity,description},{actorId});},
 async customEdit(actorId,itemId,{name,quantity=1,description=''}={}){return finishMapAction('custom-item-edit',{itemId,name,quantity,description},{actorId});},
 async remove(actorId,itemId){return finishMapAction('item-remove',{itemId},{actorId});},
 async use(actorId,itemId){selected=tokenByActorId(actorId)||selected;return execute('item-native',{itemId});}
};
window.TolMapDock={refresh(token){selected=token;if(!bridge)install();if(data)render();else load();},command:execute,skillProfile:classicSkillProfile,rollSkillPopover:rollClassicSkillPopover,gmStats,gmStatsSave,gmLife,gmContext,hasPendingReaction(actorId){return (data?.tol?.reactions||[]).some(item=>item?.actorId===actorId||item?.targetId===actorId);},async cloneActor(actorId){const response=await apiAction('clone',{}, {actorId});await load();return {id:response.result?.actorId,name:response.result?.name,ruleset:'tol',__tolClone:true};},async removeActor(actorId){const response=await apiAction('remove',{}, {actorId});await load();return response.result;}};
})();
