/* Shared presentation constraints. Authoritative spending remains in core/tol. */
(function(root){
'use strict';
const lv=(a,k)=>Number(a.traits?.main?.[k]??a.traits?.bonus?.[k]??a.traits?.initial?.[k]??0);
const sum=o=>Object.values(o||{}).reduce((s,v)=>s+Number(v||0),0);
function budget(a){const level=Number(a.level||1),baseOs=600+200*(level-1),osBonus=Math.max(0,Number(a.gmAllowances?.os||0));return {initial:3,main:3+(level>=2?2:0)+Math.max(0,level-2),bonus:level+1,mainCap:level<=2?3:level<=5?4:level<=8?5:6,professional:3+[3,5,9].filter(l=>level>=l).length+(a.species==='human'&&a.humanGift==='mind'?1:0),proficiency:Object.keys(a.traits?.main||{}).reduce((s,k)=>s+[1,3,4,6].filter(v=>lv(a,k)>=v).length+(['Ловкий','Выносливый','Обаятельный'].includes(k)&&lv(a,k)>=5?1:0),0),baseOs,osBonus,os:baseOs+osBonus};}
function selectionLimits(a,settings={}){return{mastery:(settings.experienced?3:2)+Math.max(0,Number(a.gmAllowances?.mastery||0)),beliefs:3+Math.max(0,Number(a.gmAllowances?.beliefs||0)),character:(settings.dramatic?3:2)+Math.max(0,Number(a.gmAllowances?.character||0))};}
function levelAllowed(a,group,name,value){const b=budget(a),max=group==='initial'?3:group==='main'?b.mainCap:6;return value>=0&&value<=max&&sum(a.traits[group])-lv(a,name)+value<=b[group];}
function pickReason(a,key,name,catalog,settings={}){
 const current=key==='characterTraits'?a.characterTraits.map(x=>x.name):a[key]||[];if(current.includes(name))return '';
 const picks=selectionLimits(a,settings),limits={professionalSkills:budget(a).professional,mastery:picks.mastery,characterTraits:picks.character,beliefs:picks.beliefs,spells:a.weaponProficiencies['Магия']?a.weaponProficiencies['Магия']+1:0};
 if(current.length>=limits[key])return `Доступно выборов: ${limits[key]}`;
 if(key==='beliefs'){const p=catalog.beliefs.find(x=>x.name===name);if(current.includes(p?.incompatible))return 'Несовместимо: '+p.incompatible;}
 if(key==='spells'&&catalog.spells.find(x=>x.id===name)?.threshold>a.weaponProficiencies['Магия'])return 'Порог выше Владения Магией';return '';
}
const traitActions=[['Не спускать глаз','Бдительный',6,1,'combat'],['Эрудит','Умный',3,0,'scene'],['Разобрать слабость','Умный',6,1],['Вес слова','Обаятельный',6,0,'scene'],['Уверенный 1','Уверенный',1,0,'scene'],['Уверенный 2','Уверенный',2,1,'combat'],['Уверенный 4','Уверенный',4,0,'combat'],['Уверенный 5','Уверенный',5,0,'combat'],['За мной','Уверенный',6,2,'combat'],['Изученная цель','Вдумчивый',1,1],['Вдумчивый 3','Вдумчивый',3,0,'combat'],['Вдумчивый 5','Вдумчивый',5,1,'combat'],['Вдумчивый 6','Вдумчивый',6,0,'scene']];
const tactical=[['aim','Прицеливание',1],['stance','Защитная стойка',1],['withdraw','Отход',2],['dash','Рывок',2],['brace','Упор',1],['charge','Натиск',1],['counter','Встречный удар',1],['intercept','Перехват',0],['grapple','Захват',2],['escape','Вырваться',2],['jump','Прыжок',1],['climb','Карабкаться',2],['stand','Встать',1],['mount','Верхом',1],['dismount','Спешиться',1]];
function abilities(a,c){const entries=traitActions.filter(x=>lv(a,x[1])>=x[2]).map(([name,trait,level,cost,scope])=>({name,action:'trait-dialog',args:{name},cost,used:!!a.used?.[scope]?.[name],description:`${trait} ${level}. ${c.traitRules?.[trait]||''}`}));
 const species={human:[['human-reroll','Человеческая пластичность']],gnoll:[['sense','Звериные чувства']],krif:[['grave-sight','Зрение погребальщика']],fari:[['fari-memory','Память Мотылька'],['cover-scars','Закрыть / открыть шрамы']],kuthi:[['sense','Чувства Кути']],gvined:[['mimic','Миметическая нервная система'],['synapse','Синаптический рубец']],krau:[['hydrate','Увлажнить жабры'],['swimming','Плавание / суша'],['sense','Чувства глубины']],pallid:[['abyss-gift','Дар Бездны'],['sense','Иная физиология']]};
 if(!a.isCreature)for(const [feature,name] of species[a.species]||[])entries.push({name,action:'species-dialog',args:{feature},used:!!a.used?.scene?.[name]||!!a.used?.rest?.[name],description:c.species.find(x=>x.id===a.species)?.description});
 for(const name of a.mastery||[]){const m=c.mastery.find(x=>x.name===name)||(a.customMastery||[]).find(x=>x.name===name);if(m)entries.push({name:m.name,action:'mastery-dialog',args:{name:m.name},used:!!a.used?.[m.frequency==='1/бой'?'combat':m.frequency?.includes('привал')?'rest':'scene']?.[m.name],description:m.description||m.narrative||''});}return entries;
}
const api={lv,sum,budget,selectionLimits,levelAllowed,pickReason,traitActions,tactical,abilities};if(typeof module!=='undefined')module.exports=api;else root.TolOptions=api;
})(typeof window!=='undefined'?window:globalThis);
