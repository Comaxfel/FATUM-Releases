/* ToL party graph adapter. Interaction lifecycle mirrors FATUM Classic party canvas;
   only node-position persistence is routed to the ToL server state. */
(() => {
  'use strict';
  const NODE_WIDTH = 1400;
  const NODE_HEIGHT = 920;
  const GAP_X = 100;
  const GAP_Y = 100;
  const SCALE_MIN = .12;
  const SCALE_MAX = 1.35;
  const clamp = (value, min, max) => Math.max(min, Math.min(max, Number(value) || 0));

  function position(saved, index, total = 1) {
    if (saved) return { x: clamp(saved.x, 0, 8000), y: clamp(saved.y, 0, 8000) };
    const columns = Math.max(1, Math.ceil(Math.sqrt(Math.max(1, total) * 1.45)));
    return {
      x: (index % columns) * (NODE_WIDTH + GAP_X),
      y: Math.floor(index / columns) * (NODE_HEIGHT + GAP_Y)
    };
  }

  function bind(viewport, { campaignId, master, save }) {
    if (!viewport || viewport.dataset.partyBound) return;
    viewport.dataset.partyBound = 'true';
    const world = viewport.querySelector('.party-canvas-world');
    if (!world) return;

    const key = `tolPartyCanvas:${campaignId}`;
    let hasSavedCanvas = false;
    let canvas = { x: 80, y: 70, scale: .52 };
    let activePan = null;
    let panLocked = false;
    let panHeld = false;
    try {
      const raw = localStorage.getItem(key);
      if (raw) {
        canvas = { ...canvas, ...JSON.parse(raw) };
        hasSavedCanvas = true;
      }
    } catch {}

    const panButton = viewport.parentElement?.querySelector('[data-party-pan-toggle]') || document.querySelector('[data-party-pan-toggle]');
    const readout = viewport.parentElement?.querySelector('.party-zoom-readout') || document.querySelector('.party-zoom-readout');
    const cards = () => [...viewport.querySelectorAll('.party-card[data-party-character-id]')];
    const persistCanvas = () => localStorage.setItem(key, JSON.stringify(canvas));
    const isTypingTarget = target => target instanceof Element && Boolean(target.closest('input,textarea,select,[contenteditable="true"]'));
    const isPartyCardTarget = target => target instanceof Element && Boolean(target.closest('.party-card'));

    function updateBackground() {
      const major = Math.max(32, 160 * canvas.scale);
      const minor = Math.max(8, 40 * canvas.scale);
      viewport.style.backgroundSize = `${major}px ${major}px, ${major}px ${major}px, ${minor}px ${minor}px, ${minor}px ${minor}px`;
      viewport.style.backgroundPosition = `${canvas.x}px ${canvas.y}px, ${canvas.x}px ${canvas.y}px, ${canvas.x}px ${canvas.y}px, ${canvas.x}px ${canvas.y}px`;
    }
    function applyTransform(persist = false) {
      canvas.scale = clamp(canvas.scale, SCALE_MIN, SCALE_MAX);
      world.style.transform = `translate(${canvas.x}px, ${canvas.y}px) scale(${canvas.scale})`;
      if (readout) readout.textContent = `${Math.round(canvas.scale * 100)}%`;
      updateBackground();
      if (persist) persistCanvas();
    }
    function updatePanUi() {
      const active = Boolean(panLocked || panHeld);
      viewport.classList.toggle('pan-tool-active', active);
      if (panButton) {
        panButton.classList.toggle('active', panLocked);
        panButton.textContent = panLocked ? '✋ Панорама: вкл' : '✋ Панорама';
        panButton.setAttribute('aria-pressed', panLocked ? 'true' : 'false');
      }
    }
    function bounds() {
      const list = cards();
      if (!list.length) return { minX: 0, minY: 0, width: NODE_WIDTH, height: NODE_HEIGHT };
      const pts = list.map(card => ({ x: parseFloat(card.style.left) || 0, y: parseFloat(card.style.top) || 0 }));
      const minX = Math.min(...pts.map(p => p.x));
      const minY = Math.min(...pts.map(p => p.y));
      const maxX = Math.max(...pts.map(p => p.x + NODE_WIDTH));
      const maxY = Math.max(...pts.map(p => p.y + NODE_HEIGHT));
      return { minX, minY, width: maxX - minX, height: maxY - minY };
    }
    function fit(persist = true) {
      const rect = viewport.getBoundingClientRect();
      const box = bounds();
      const margin = 70;
      canvas.scale = Math.min(SCALE_MAX, Math.max(SCALE_MIN, Math.min((rect.width - margin * 2) / box.width, (rect.height - margin * 2) / box.height)));
      canvas.x = (rect.width - box.width * canvas.scale) / 2 - box.minX * canvas.scale;
      canvas.y = (rect.height - box.height * canvas.scale) / 2 - box.minY * canvas.scale;
      applyTransform(persist);
    }
    function zoomAt(clientX, clientY, factor) {
      const rect = viewport.getBoundingClientRect();
      const pointerX = clientX - rect.left;
      const pointerY = clientY - rect.top;
      const worldX = (pointerX - canvas.x) / canvas.scale;
      const worldY = (pointerY - canvas.y) / canvas.scale;
      const nextScale = Math.min(SCALE_MAX, Math.max(SCALE_MIN, canvas.scale * factor));
      canvas.x = pointerX - worldX * nextScale;
      canvas.y = pointerY - worldY * nextScale;
      canvas.scale = nextScale;
      applyTransform(true);
    }
    function zoomBy(factor) {
      const rect = viewport.getBoundingClientRect();
      zoomAt(rect.left + rect.width / 2, rect.top + rect.height / 2, factor);
    }
    function resetZoom() {
      const rect = viewport.getBoundingClientRect();
      const cx = rect.width / 2;
      const cy = rect.height / 2;
      const worldX = (cx - canvas.x) / canvas.scale;
      const worldY = (cy - canvas.y) / canvas.scale;
      canvas.scale = 1;
      canvas.x = cx - worldX;
      canvas.y = cy - worldY;
      applyTransform(true);
    }
    function focus(characterId) {
      const card = viewport.querySelector(`.party-card[data-party-character-id="${CSS.escape(characterId)}"]`);
      if (!card) return;
      const rect = viewport.getBoundingClientRect();
      const x = parseFloat(card.style.left) || 0;
      const y = parseFloat(card.style.top) || 0;
      const margin = 24;
      const nextScale = Math.min(1, Math.max(SCALE_MIN, Math.min((rect.width - margin * 2) / NODE_WIDTH, (rect.height - margin * 2) / NODE_HEIGHT)));
      canvas.scale = nextScale;
      canvas.x = (rect.width - NODE_WIDTH * nextScale) / 2 - x * nextScale;
      canvas.y = (rect.height - NODE_HEIGHT * nextScale) / 2 - y * nextScale;
      applyTransform(true);
      cards().forEach(node => node.classList.remove('is-focused'));
      card.classList.add('is-focused');
      setTimeout(() => card.classList.remove('is-focused'), 900);
    }

    function beginPan(event) {
      if (event.button !== 0) return false;
      const forcedPan = panLocked || panHeld;
      if (!forcedPan && isPartyCardTarget(event.target)) return false;
      if (forcedPan && event.target instanceof Element && event.target.closest('.party-card-toolbar select,.party-card-toolbar button,.party-card-toolbar input,.party-card-toolbar a')) return false;
      activePan = { startX: event.clientX, startY: event.clientY, originX: canvas.x, originY: canvas.y };
      viewport.classList.add('is-panning');
      event.preventDefault();
      return true;
    }
    function onMouseDown(event) {
      if (!viewport.contains(event.target)) return;
      beginPan(event);
    }
    function onMouseMove(event) {
      if (!activePan) return;
      canvas.x = activePan.originX + (event.clientX - activePan.startX);
      canvas.y = activePan.originY + (event.clientY - activePan.startY);
      applyTransform(false);
      event.preventDefault();
    }
    function finishPan() {
      if (!activePan) return;
      activePan = null;
      viewport.classList.remove('is-panning');
      persistCanvas();
    }
    function startNodeDrag(event, characterId) {
      if (!master || panLocked || panHeld) return;
      if (event.button !== 0 || event.target.closest('select,button,input,textarea,a')) return;
      const card = viewport.querySelector(`.party-card[data-party-character-id="${CSS.escape(characterId)}"]`);
      if (!card) return;
      const startX = event.clientX;
      const startY = event.clientY;
      const originX = parseFloat(card.style.left) || 0;
      const originY = parseFloat(card.style.top) || 0;
      card.classList.add('is-focused');
      viewport.classList.add('is-moving-node');
      event.currentTarget.setPointerCapture?.(event.pointerId);
      const move = moveEvent => {
        card.style.left = `${originX + (moveEvent.clientX - startX) / canvas.scale}px`;
        card.style.top = `${originY + (moveEvent.clientY - startY) / canvas.scale}px`;
      };
      const end = () => {
        card.classList.remove('is-focused');
        viewport.classList.remove('is-moving-node');
        window.removeEventListener('pointermove', move, true);
        window.removeEventListener('pointerup', end, true);
        window.removeEventListener('pointercancel', end, true);
        Promise.resolve(save(characterId, { x: parseFloat(card.style.left) || 0, y: parseFloat(card.style.top) || 0 })).catch(() => {});
      };
      window.addEventListener('pointermove', move, true);
      window.addEventListener('pointerup', end, true);
      window.addEventListener('pointercancel', end, true);
      event.preventDefault();
    }

    viewport.addEventListener('mousedown', onMouseDown, true);
    window.addEventListener('mousemove', onMouseMove, true);
    window.addEventListener('mouseup', finishPan, true);
    window.addEventListener('blur', finishPan);
    viewport.addEventListener('wheel', event => {
      const forcedPan = panLocked || panHeld;
      if (!forcedPan && isPartyCardTarget(event.target)) return;
      event.preventDefault();
      zoomAt(event.clientX, event.clientY, Math.exp(-event.deltaY * .0014));
    }, { passive: false, capture: true });
    viewport.addEventListener('pointerdown', event => {
      const toolbar = event.target.closest?.('.party-card-toolbar');
      const card = toolbar?.closest('.party-card[data-party-character-id]');
      if (toolbar && card) startNodeDrag(event, card.dataset.partyCharacterId);
    });
    viewport.addEventListener('click', event => {
      const button = event.target.closest?.('[data-party-focus]');
      if (button) focus(button.closest('.party-card')?.dataset.partyCharacterId);
    });
    viewport.parentElement?.querySelector('[data-party-fit]')?.addEventListener('click', () => fit());
    viewport.parentElement?.querySelector('[data-party-zoom-out]')?.addEventListener('click', () => zoomBy(.82));
    viewport.parentElement?.querySelector('[data-party-zoom-in]')?.addEventListener('click', () => zoomBy(1.22));
    viewport.parentElement?.querySelector('[data-party-zoom-reset]')?.addEventListener('click', resetZoom);
    panButton?.addEventListener('click', () => { panLocked = !panLocked; updatePanUi(); viewport.focus?.(); });
    window.addEventListener('keydown', event => {
      if (event.code !== 'Space' || event.repeat || isTypingTarget(event.target) || !document.body.classList.contains('party-mode-active')) return;
      panHeld = true;
      updatePanUi();
      event.preventDefault();
    }, true);
    window.addEventListener('keyup', event => {
      if (event.code !== 'Space') return;
      panHeld = false;
      updatePanUi();
      finishPan();
      event.preventDefault();
    }, true);

    applyTransform(false);
    updatePanUi();
    if (!hasSavedCanvas) requestAnimationFrame(() => fit(false));
  }

  const api = { position, bind, NODE_WIDTH, NODE_HEIGHT };
  if (typeof module !== 'undefined') module.exports = api;
  else window.TolBoard = api;
})();
