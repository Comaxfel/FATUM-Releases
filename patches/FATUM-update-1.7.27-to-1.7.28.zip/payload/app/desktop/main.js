'use strict';

const { app, BrowserWindow, ipcMain, shell, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { fork, spawn } = require('child_process');
const { atomicWriteJsonSync } = require('../core/io');

let APP_VERSION = '0.0.0';
try { APP_VERSION = String(require('../package.json').version || APP_VERSION); } catch {}
// compatibility marker: const APP_VERSION = '1.7.5';
// compatibility marker: const APP_VERSION = '1.5.7';
// compatibility marker: const APP_VERSION = '1.3.0';
// compatibility marker: const APP_VERSION = '1.2.0';
// compatibility marker: const APP_VERSION = '1.1.14';
const isPlayerRole = process.argv.includes('--player') || /player/i.test(path.basename(process.execPath));
const isMasterRole = process.argv.includes('--master') || /master/i.test(path.basename(process.execPath));
const role = isPlayerRole ? 'player' : (isMasterRole ? 'master' : 'launcher');
// Separate settings and single-instance locks for the Master and Player roles.
try {
  app.setPath('userData', path.join(app.getPath('appData'), role === 'master' ? 'FATUM Master' : (role === 'player' ? 'FATUM Player' : 'FATUM Launcher')));
} catch {}
let mainWindow = null;
let serverProcess = null;
let serverPort = null;
let quitting = false;

function settingsFile() { return path.join(app.getPath('userData'), 'desktop-settings.json'); }
function readSettings() {
  try { return JSON.parse(fs.readFileSync(settingsFile(), 'utf8')); }
  catch { return {}; }
}
function writeSettings(patch) {
  const current = readSettings();
  const next = { ...current, ...patch };
  fs.mkdirSync(path.dirname(settingsFile()), { recursive:true });
  atomicWriteJsonSync(settingsFile(), next, 2);
  return next;
}
function normalizedServerUrl(value) {
  let text = String(value || '').trim();
  if (!text) return null;
  if (!/^https?:\/\//i.test(text)) text = `http://${text}`;
  try {
    const url = new URL(text);
    if (!url.port) url.port = '3000';
    url.pathname = ''; url.search = ''; url.hash = '';
    return url.toString().replace(/\/$/, '');
  } catch { return null; }
}
async function probeServer(url) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 4500);
  try {
    const response = await fetch(`${url}/api/status`, { signal:controller.signal, cache:'no-store' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const payload = await response.json();
    if (!payload?.ok || !payload?.battlemap) throw new Error('Это не сервер FATUM.');
    return payload;
  } finally { clearTimeout(timeout); }
}
function externalDataDir() {
  if (process.env.FATUM_DESKTOP_DATA_DIR) return path.resolve(process.env.FATUM_DESKTOP_DATA_DIR);
  if (!app.isPackaged) return path.join(app.getAppPath(), 'data');
  const portable = process.env.PORTABLE_EXECUTABLE_DIR;
  return portable ? path.join(portable, 'FATUM-data') : path.join(app.getPath('userData'), 'data');
}

function desktopIconPath() {
  const candidate = path.join(app.getAppPath(), 'build', 'icon.png');
  return fs.existsSync(candidate) ? candidate : undefined;
}

function installRootDir() {
  if (app.isPackaged) return path.dirname(process.execPath);
  return app.getAppPath();
}
function launcherPagePath(message = '') {
  const file = path.join(__dirname,'launcher.html');
  const url = new URL(`file://${file.replace(/\\/g,'/')}`);
  url.searchParams.set('version', APP_VERSION);
  if (message) url.searchParams.set('message', message);
  return url.toString();
}
function runBatchScript(filename) {
  const scriptPath = path.join(installRootDir(), filename);
  if (!fs.existsSync(scriptPath)) return { ok:false, error:`Файл ${filename} не найден.` };
  try {
    const child = spawn('cmd.exe', ['/c', 'start', '', scriptPath], {
      cwd: installRootDir(), detached: true, windowsHide: false, stdio: 'ignore'
    });
    child.unref();
    return { ok:true, file:scriptPath };
  } catch (error) {
    return { ok:false, error:String(error?.message || error) };
  }
}
function psSingleQuoted(value) {
  return `'${String(value || '').replace(/'/g, "''")}'`;
}
function runBatchScriptAfterExit(filename) {
  const rootDir = installRootDir();
  const scriptPath = path.join(rootDir, filename);
  if (!fs.existsSync(scriptPath)) return { ok:false, error:`Файл ${filename} не найден.` };

  try {
    // Start the updater FIRST, while the Launcher is still alive.
    // The updater receives the Launcher PID and waits for that PID (and the
    // remaining Electron FATUM.exe children) to disappear before touching files.
    //
    // This deliberately uses the same cmd.exe "start" path that already proved
    // able to open the updater window from FATUM Launcher. The previous r2/r3
    // approach started a hidden PowerShell helper and only then exited FATUM;
    // on some Windows setups that helper could be lost/stuck after app.exit().
    const launcherPid = process.pid;
    const child = spawn('cmd.exe', [
      '/c', 'start', '', scriptPath, '--wait-pid', String(launcherPid)
    ], {
      cwd: rootDir,
      detached: true,
      windowsHide: false,
      stdio: 'ignore'
    });
    child.unref();

    quitting = true;
    setTimeout(() => app.exit(0), 120);
    return { ok:true, file:scriptPath, closingLauncher:true, waitPid:launcherPid };
  } catch (error) {
    return { ok:false, error:String(error?.message || error) };
  }
}
function relaunchWithRole(targetRole,ruleset='classic') {
  ruleset=ruleset==='tol'?'tol':'classic';
  if (!['player','master','launcher'].includes(targetRole)) return { ok:false, error:'Некорректная роль запуска.' };
  const passthroughArgs = process.argv.slice(1).filter(arg => !['--player','--master','--launcher','--ruleset=tol','--ruleset=classic'].includes(arg));
  app.relaunch({ execPath: process.execPath, args: [...passthroughArgs, `--ruleset=${ruleset}`, targetRole === 'launcher' ? '--launcher' : `--${targetRole}`] });
  setImmediate(() => app.quit());
  return { ok:true };
}
function serverScript() { return path.join(app.getAppPath(), 'server.js'); }
function startMasterServer() {
  return new Promise((resolve, reject) => {
    const env = {
      ...process.env,
      ELECTRON_RUN_AS_NODE:'1',
      FATUM_NO_BROWSER:'1',
      FATUM_DESKTOP:'1',
      FATUM_DATA_DIR:externalDataDir(),
      FATUM_PORT:String(readSettings().masterPort || 3000)
    };
    serverProcess = fork(serverScript(), [], { execPath:process.execPath, env, silent:true });
    const timer = setTimeout(() => reject(new Error('Сервер FATUM не запустился вовремя.')), 20000);
    serverProcess.on('message', message => {
      if (message?.type !== 'fatum-ready') return;
      clearTimeout(timer); serverPort = Number(message.port) || 3000;
      writeSettings({ masterPort:serverPort }); resolve(serverPort);
    });
    serverProcess.stdout?.on('data', chunk => process.stdout.write(`[FATUM] ${chunk}`));
    serverProcess.stderr?.on('data', chunk => process.stderr.write(`[FATUM] ${chunk}`));
    serverProcess.once('exit', code => {
      if (!quitting && mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('fatum-server-stopped', { code });
      }
    });
    serverProcess.once('error', error => { clearTimeout(timer); reject(error); });
  });
}
function sameOriginUrl(a, b) {
  try { return new URL(a).origin === new URL(b).origin; } catch { return false; }
}

// v1.7.27: privileged Desktop IPC is never authorized merely because a page
// is displayed inside FATUM. Player pages are delivered by a remote GM server,
// so they must not be able to launch the updater/restore process, switch roles,
// or open local installation paths.
function ipcSenderUrl(event) {
  try { return String(event?.senderFrame?.url || event?.sender?.getURL?.() || ''); } catch { return ''; }
}
function localDesktopPage(url, fileName) {
  try {
    const target = new URL(url);
    if (target.protocol !== 'file:') return false;
    let targetPath = decodeURIComponent(target.pathname || '');
    if (process.platform === 'win32' && /^\/[A-Za-z]:/.test(targetPath)) targetPath = targetPath.slice(1);
    return path.resolve(targetPath) === path.resolve(path.join(__dirname, fileName));
  } catch { return false; }
}
function ipcSurface(event) {
  const url = ipcSenderUrl(event);
  if (localDesktopPage(url, 'launcher.html')) return 'launcher';
  if (localDesktopPage(url, 'connect.html')) return 'connect';
  try {
    const target = new URL(url);
    if (!/^https?:$/.test(target.protocol)) return 'unknown';
    if (role === 'master' && serverPort && target.origin === `http://127.0.0.1:${serverPort}`) return 'master';
    const saved = normalizedServerUrl(readSettings().playerServerUrl);
    if (role === 'player' && saved && target.origin === new URL(saved).origin) return 'player';
  } catch {}
  return 'unknown';
}
function ipcAllowed(event, ...allowed) { return allowed.includes(ipcSurface(event)); }
function deniedIpc(action) { return { ok:false, error:`Действие «${action}» заблокировано политикой безопасности Desktop.` }; }
function navigationAllowed(url) {
  try {
    const target = new URL(url);
    if (target.protocol === 'file:') {
      const connect = path.resolve(path.join(__dirname, 'connect.html'));
      const launcher = path.resolve(path.join(__dirname, 'launcher.html'));
      let targetPath = decodeURIComponent(target.pathname || '');
      if (process.platform === 'win32' && /^\/[A-Za-z]:/.test(targetPath)) targetPath = targetPath.slice(1);
      const resolved = path.resolve(targetPath);
      return resolved === connect || resolved === launcher;
    }
    if (!/^https?:$/.test(target.protocol)) return false;
    if (role === 'master' && serverPort) return target.origin === `http://127.0.0.1:${serverPort}`;
    const saved = normalizedServerUrl(readSettings().playerServerUrl);
    return Boolean(saved && sameOriginUrl(target.toString(), saved));
  } catch { return false; }
}
function guardNavigation(webContents) {
  webContents.on('will-navigate', (event, url) => {
    if (navigationAllowed(url)) return;
    event.preventDefault();
    if (/^https?:/i.test(url)) shell.openExternal(url).catch(() => {});
  });
  webContents.on('will-redirect', (event, url) => {
    if (navigationAllowed(url)) return;
    event.preventDefault();
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    title: role === 'master' ? 'FATUM — Мастер' : (role === 'player' ? 'FATUM — Игрок' : 'FATUM Launcher'),
    width: role === 'launcher' ? 1320 : 1600, height: role === 'launcher' ? 820 : 1000, minWidth: role === 'launcher' ? 1100 : 1050, minHeight: role === 'launcher' ? 720 : 700,
    show:false, backgroundColor:'#090b10', autoHideMenuBar:true,
    icon:desktopIconPath(),
    fullscreen: role === 'launcher' ? false : readSettings().fullscreen !== false,
    webPreferences:{
      preload:path.join(__dirname,'preload.js'),
      contextIsolation:true,
      nodeIntegration:false,
      sandbox:true,
      webSecurity:true,
      webviewTag:false,
      allowRunningInsecureContent:false
    }
  });
  guardNavigation(mainWindow.webContents);
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    const childOptions = {
      width:900,
      height:820,
      minWidth:560,
      minHeight:560,
      autoHideMenuBar:true,
      backgroundColor:'#090b10',
      icon:desktopIconPath(),
      webPreferences:{
        preload:path.join(__dirname,'preload.js'),
        contextIsolation:true,
        nodeIntegration:false,
        sandbox:true,
        webSecurity:true,
        webviewTag:false,
        allowRunningInsecureContent:false
      }
    };
    if (url === 'about:blank' || !url) return { action:'allow', overrideBrowserWindowOptions:childOptions };
    try {
      const target = new URL(url);
      const current = new URL(mainWindow.webContents.getURL());
      if (target.origin === current.origin && /^https?:$/.test(target.protocol)) {
        return { action:'allow', overrideBrowserWindowOptions:childOptions };
      }
    } catch {}
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action:'deny' };
  });
  mainWindow.webContents.on('did-create-window', child => {
    child.setMenuBarVisibility(false);
    child.setTitle('FATUM');
    guardNavigation(child.webContents);
  });
  mainWindow.webContents.on('before-input-event', (event,input) => {
    if (input.key === 'F11' && input.type === 'keyDown') { event.preventDefault(); toggleFullscreen(); }
    if (input.key === 'F5' && input.type === 'keyDown') { event.preventDefault(); mainWindow.webContents.reloadIgnoringCache(); }
  });
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    if (role !== 'launcher' && !mainWindow.isFullScreen()) mainWindow.maximize();
  });
  mainWindow.on('closed', () => { mainWindow=null; });
}
function toggleFullscreen() {
  if (!mainWindow) return false;
  const next = !mainWindow.isFullScreen();
  mainWindow.setFullScreen(next); writeSettings({ fullscreen:next });
  return next;
}
function connectPagePath(error = '') {
  const file = path.join(__dirname,'connect.html');
  const url = new URL(`file://${file.replace(/\\/g,'/')}`);
  url.searchParams.set('version',APP_VERSION);
  if (error) url.searchParams.set('error',error);
  return url.toString();
}
async function loadPlayerServer(serverUrl, showError = true) {
  const normalized = normalizedServerUrl(serverUrl);
  if (!normalized) {
    await mainWindow.loadURL(connectPagePath('Введите корректный адрес сервера.'));
    return false;
  }
  try {
    await probeServer(normalized);
    writeSettings({ playerServerUrl:normalized });
    await mainWindow.loadURL(`${normalized}/player?desktop=1`);
    return true;
  } catch (error) {
    if (showError) await mainWindow.loadURL(connectPagePath(`Не удалось подключиться к ${normalized}: ${error.message}`));
    return false;
  }
}

async function loadCampaignLauncher() {
  if (!mainWindow || mainWindow.isDestroyed()) return false;
  if (role === 'master') {
    if (!serverPort) throw new Error('Сервер Мастера ещё не готов.');
    await mainWindow.loadURL(`http://127.0.0.1:${serverPort}/launcher.html?mode=master&desktop=1&ruleset=${process.argv.includes('--ruleset=tol')?'tol':'classic'}`);
    return true;
  }
  const saved = normalizedServerUrl(readSettings().playerServerUrl);
  if (!saved) {
    await mainWindow.loadURL(connectPagePath('Сначала подключитесь к серверу Мастера.'));
    return false;
  }
  try {
    await probeServer(saved);
    await mainWindow.loadURL(`${saved}/launcher.html?mode=player&desktop=1&ruleset=${process.argv.includes('--ruleset=tol')?'tol':'classic'}`);
    return true;
  } catch (error) {
    await mainWindow.loadURL(connectPagePath(`Сервер сейчас недоступен: ${error.message}`));
    return false;
  }
}

async function requestExit() {
  if (!mainWindow || mainWindow.isDestroyed()) { app.quit(); return true; }
  const isMaster = role === 'master';
  const result = await dialog.showMessageBox(mainWindow, {
    type:'question',
    title:'Выход из FATUM',
    message:isMaster ? 'Закрыть FATUM и остановить сервер?' : 'Закрыть FATUM?',
    detail:isMaster ? 'Все подключённые игроки будут отключены. Текущее состояние кампании уже сохраняется автоматически.' : 'Вы вернётесь к игре при следующем запуске приложения.',
    buttons:['Выйти','Отмена'],
    defaultId:1,
    cancelId:1,
    noLink:true
  });
  if (result.response !== 0) return false;
  setImmediate(() => app.quit());
  return true;
}
async function loadInitialPage() {
  if (role === 'launcher') {
    await mainWindow.loadURL(launcherPagePath());
    return;
  }
  if (role === 'master') {
    const port = await startMasterServer();
    await mainWindow.loadURL(`http://127.0.0.1:${port}/master?desktop=1`);
    return;
  }
  const saved = readSettings().playerServerUrl;
  if (saved && await loadPlayerServer(saved, false)) return;
  await mainWindow.loadURL(connectPagePath(saved ? 'Сохранённый сервер сейчас недоступен.' : ''));
}


ipcMain.on('desktop:alert-sync', (event, payload = {}) => {
  if (!ipcAllowed(event,'master','player','launcher','connect')) { event.returnValue = false; return; }
  try {
    const owner = BrowserWindow.fromWebContents(event.sender) || mainWindow || undefined;
    const options = {
      type:'info',
      title:String(payload.title || 'FATUM'),
      message:String(payload.message || ''),
      buttons:['ОК'],
      defaultId:0,
      cancelId:0,
      noLink:true
    };
    if (owner) dialog.showMessageBoxSync(owner, options); else dialog.showMessageBoxSync(options);
    event.returnValue = true;
  } catch (error) {
    event.returnValue = false;
  }
});
ipcMain.on('desktop:confirm-sync', (event, payload = {}) => {
  if (!ipcAllowed(event,'master','player','launcher','connect')) { event.returnValue = false; return; }
  try {
    const owner = BrowserWindow.fromWebContents(event.sender) || mainWindow || undefined;
    const options = {
      type:'question',
      title:String(payload.title || 'FATUM'),
      message:String(payload.message || ''),
      buttons:['Подтвердить','Отмена'],
      defaultId:0,
      cancelId:1,
      noLink:true
    };
    const result = owner ? dialog.showMessageBoxSync(owner, options) : dialog.showMessageBoxSync(options);
    event.returnValue = result === 0;
  } catch (error) {
    event.returnValue = false;
  }
});

async function nativeSaveHtmlAsPng(event, payload = {}) {
  const owner = BrowserWindow.fromWebContents(event.sender) || mainWindow || undefined;
  const safeBase = String(payload.filename || 'fatum-character.png')
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, '_')
    .replace(/\.+$/g, '') || 'fatum-character.png';
  const requestedWidth = Math.max(320, Math.min(4096, Math.ceil(Number(payload.width) || 1000)));
  const requestedHeight = Math.max(320, Math.min(16000, Math.ceil(Number(payload.height) || 1400)));
  const html = String(payload.html || '');
  if (!html.trim()) return { ok:false, error:'Пустая область экспорта.' };

  const tempDir = path.join(app.getPath('temp'), 'fatum-export');
  fs.mkdirSync(tempDir, { recursive:true });
  const tempFile = path.join(tempDir, `sheet-${process.pid}-${Date.now()}-${Math.random().toString(16).slice(2)}.html`);
  const background = String(payload.background || '#f5f0e6');
  const documentHtml = `<!doctype html><html><head><meta charset="utf-8"><meta name="color-scheme" content="light only"><style>html,body{margin:0!important;padding:0!important;background:${background}!important;overflow:hidden!important;}*{box-sizing:border-box;}</style></head><body>${html}</body></html>`;
  let exportWindow = null;
  try {
    fs.writeFileSync(tempFile, documentHtml, 'utf8');
    exportWindow = new BrowserWindow({
      show:false,
      useContentSize:true,
      width:requestedWidth,
      height:Math.min(requestedHeight, 8000),
      backgroundColor:background,
      webPreferences:{
        offscreen:true,
        contextIsolation:true,
        nodeIntegration:false,
        sandbox:true,
        webSecurity:true,
        images:true,
        javascript:true
      }
    });
    await exportWindow.loadFile(tempFile);
    await exportWindow.webContents.executeJavaScript(`(async()=>{try{if(document.fonts&&document.fonts.ready)await document.fonts.ready;}catch{};await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));return true;})()`);
    const measured = await exportWindow.webContents.executeJavaScript(`(()=>({width:Math.ceil(Math.max(document.documentElement.scrollWidth,document.body?.scrollWidth||0)),height:Math.ceil(Math.max(document.documentElement.scrollHeight,document.body?.scrollHeight||0))}))()`);
    const width = Math.max(1, Math.min(4096, Number(measured?.width) || requestedWidth));
    const height = Math.max(1, Math.min(16000, Number(measured?.height) || requestedHeight));
    exportWindow.setContentSize(width, height, false);
    await new Promise(resolve => setTimeout(resolve, 80));
    const image = await exportWindow.webContents.capturePage({ x:0, y:0, width, height }, { stayHidden:true, stayAwake:true });
    if (image.isEmpty()) throw new Error('Electron не смог получить изображение листа.');

    const result = owner
      ? await dialog.showSaveDialog(owner, { title:'Сохранить лист персонажа', defaultPath:safeBase, filters:[{ name:'PNG image', extensions:['png'] }] })
      : await dialog.showSaveDialog({ title:'Сохранить лист персонажа', defaultPath:safeBase, filters:[{ name:'PNG image', extensions:['png'] }] });
    if (result.canceled || !result.filePath) return { ok:false, canceled:true };
    fs.writeFileSync(result.filePath, image.toPNG());
    return { ok:true, filePath:result.filePath, width, height };
  } catch (error) {
    return { ok:false, error:String(error?.message || error) };
  } finally {
    try { if (exportWindow && !exportWindow.isDestroyed()) exportWindow.destroy(); } catch {}
    try { fs.unlinkSync(tempFile); } catch {}
  }
}
ipcMain.handle('desktop:save-html-png', async (event, payload) => ipcAllowed(event,'master','player') ? nativeSaveHtmlAsPng(event,payload) : deniedIpc('экспорт PNG'));

ipcMain.handle('desktop:get-context', event => {
  const surface = ipcSurface(event);
  if (surface === 'launcher' || surface === 'connect') return { role, version:APP_VERSION, serverPort, settings:readSettings(), installDir:surface === 'launcher' ? installRootDir() : null };
  if (surface === 'master' || surface === 'player') return { role, version:APP_VERSION, serverPort:role === 'master' ? serverPort : null, settings:{ fullscreen:readSettings().fullscreen !== false }, installDir:null };
  return { role, version:APP_VERSION, serverPort:null, settings:{}, installDir:null };
});
ipcMain.handle('desktop:connect-server', async (event, value) => {
  if (!ipcAllowed(event, 'connect')) return deniedIpc('подключение к серверу');
  const normalized = normalizedServerUrl(value);
  if (!normalized) return { ok:false, error:'Некорректный адрес.' };
  try { const status=await probeServer(normalized);writeSettings({playerServerUrl:normalized});await mainWindow.loadURL(`${normalized}/player?desktop=1`);return {ok:true,status,url:normalized}; }
  catch(error){return {ok:false,error:error.message};}
});
ipcMain.on('desktop:change-server', event => { if (ipcAllowed(event,'player','connect')&&role==='player'&&mainWindow) mainWindow.loadURL(connectPagePath()); });
ipcMain.handle('desktop:go-campaigns', async event => { if(!ipcAllowed(event,'master','player'))return deniedIpc('переход к кампаниям');try { return { ok:await loadCampaignLauncher() }; } catch(error) { return { ok:false, error:error.message }; } });
ipcMain.handle('desktop:request-exit', event => ipcAllowed(event,'launcher','connect','master','player') ? requestExit() : deniedIpc('выход'));
ipcMain.handle('desktop:toggle-fullscreen', event => ipcAllowed(event,'master','player') ? toggleFullscreen() : false);
ipcMain.handle('desktop:get-server-url', event => ipcAllowed(event,'master','player','connect') ? (role==='master'&&serverPort?`http://127.0.0.1:${serverPort}`:readSettings().playerServerUrl||null) : null);
ipcMain.handle('desktop:launch-role', async (event, targetRole, ruleset) => ipcAllowed(event,'launcher') ? relaunchWithRole(String(targetRole || 'launcher'),ruleset) : deniedIpc('смена роли'));
ipcMain.handle('desktop:run-updater', event => ipcAllowed(event,'launcher') ? runBatchScriptAfterExit('UPDATE_FATUM.cmd') : deniedIpc('обновление'));
ipcMain.handle('desktop:run-restore', event => ipcAllowed(event,'launcher') ? runBatchScriptAfterExit('RESTORE_FATUM.cmd') : deniedIpc('восстановление'));
ipcMain.handle('desktop:open-install-dir', async event => {
  if (!ipcAllowed(event,'launcher')) return deniedIpc('открытие папки установки');
  try {
    const result = await shell.openPath(installRootDir());
    return result ? { ok:false, error:result } : { ok:true, path:installRootDir() };
  } catch (error) {
    return { ok:false, error:String(error?.message || error) };
  }
});

if (!app.requestSingleInstanceLock({ role })) app.quit();
else {
  app.on('second-instance', () => { if(mainWindow){if(mainWindow.isMinimized())mainWindow.restore();mainWindow.focus();} });
  app.whenReady().then(async () => {
    app.setAppUserModelId(role==='master'?'com.fatum.vtt.master':(role==='player'?'com.fatum.vtt.player':'com.fatum.vtt.launcher'));
    createWindow();
    try { await loadInitialPage(); }
    catch(error){await mainWindow.loadURL(connectPagePath(`Ошибка запуска: ${error.message}`));}
  });
  app.on('window-all-closed', () => app.quit());
  app.on('before-quit', () => {
    quitting=true;
    if(serverProcess&&!serverProcess.killed){try{serverProcess.kill('SIGTERM');}catch{}}
  });
}
