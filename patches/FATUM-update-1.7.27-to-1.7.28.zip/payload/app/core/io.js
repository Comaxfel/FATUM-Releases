'use strict';

const fs = require('fs');
const path = require('path');
const { randomBytes } = require('crypto');

function temporarySibling(filePath, tag = 'tmp') {
  return `${filePath}.${process.pid}-${Date.now()}-${randomBytes(4).toString('hex')}.${tag}`;
}

async function replaceFile(temporary, destination) {
  try {
    await fs.promises.rename(temporary, destination);
    return;
  } catch (error) {
    // Windows can reject rename when the destination exists. The fallback is
    // intentionally narrow and only used for the well-known replacement errors.
    if (!['EEXIST', 'EPERM', 'EACCES', 'ENOTEMPTY'].includes(error?.code)) throw error;
  }
  await fs.promises.rm(destination, { force: true });
  await fs.promises.rename(temporary, destination);
}

function replaceFileSync(temporary, destination) {
  try {
    fs.renameSync(temporary, destination);
    return;
  } catch (error) {
    if (!['EEXIST', 'EPERM', 'EACCES', 'ENOTEMPTY'].includes(error?.code)) throw error;
  }
  fs.rmSync(destination, { force: true });
  fs.renameSync(temporary, destination);
}

async function atomicWriteFile(filePath, data, encoding = undefined) {
  await fs.promises.mkdir(path.dirname(filePath), { recursive: true });
  const temporary = temporarySibling(filePath);
  try {
    await fs.promises.writeFile(temporary, data, encoding);
    await replaceFile(temporary, filePath);
  } catch (error) {
    await fs.promises.rm(temporary, { force: true }).catch(() => {});
    throw error;
  }
}

function atomicWriteFileSync(filePath, data, encoding = undefined) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const temporary = temporarySibling(filePath);
  try {
    fs.writeFileSync(temporary, data, encoding);
    replaceFileSync(temporary, filePath);
  } catch (error) {
    try { fs.rmSync(temporary, { force: true }); } catch {}
    throw error;
  }
}

async function atomicWriteJson(filePath, value, space = 2) {
  return atomicWriteFile(filePath, JSON.stringify(value, null, space), 'utf8');
}

function atomicWriteJsonSync(filePath, value, space = 2) {
  return atomicWriteFileSync(filePath, JSON.stringify(value, null, space), 'utf8');
}

module.exports = {
  temporarySibling,
  replaceFile,
  replaceFileSync,
  atomicWriteFile,
  atomicWriteFileSync,
  atomicWriteJson,
  atomicWriteJsonSync
};
