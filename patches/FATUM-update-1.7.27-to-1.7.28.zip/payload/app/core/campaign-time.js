'use strict';

const ALL_SKILLS = [
  'Физическая сила','Взлом','Акробатика','Скрытность',
  'Выдержка','Стойкость','Иммунитет',
  'Бдительность','Воля','Меткость','Выживание',
  'Анализ','Эрудиция','Память','Медицина','Механика',
  'Убеждение','Обман','Интуиция','Запугивание','Очарование'
];
const ENDURANCE_SKILLS = ['Выдержка','Стойкость','Иммунитет'];
const INTELLIGENCE_AND_CONCENTRATION = ['Бдительность','Воля','Меткость','Выживание','Анализ','Эрудиция','Память','Медицина','Механика'];
const SURVIVAL_SOURCES = new Set(['campaign-survival-hunger','campaign-survival-sleep']);
const CRITICAL_RECOVERY_SOURCE = 'critical-recovery';

function clamp(value, min, max) {
  const number = Number(value);
  return Math.max(min, Math.min(max, Number.isFinite(number) ? number : min));
}
function nowIso() { return new Date().toISOString(); }
function makeTimeline(raw = {}) {
  const source = raw && typeof raw === 'object' ? raw : {};
  const supplies = source.supplies && typeof source.supplies === 'object' ? source.supplies : {};
  const modules = source.modules && typeof source.modules === 'object' ? source.modules : {};
  return {
    day: Math.round(clamp(source.day ?? 1, 1, 999999)),
    minuteOfDay: Math.round(clamp(source.minuteOfDay ?? 480, 0, 1439)),
    restSerial: Math.max(0, Math.round(Number(source.restSerial) || 0)),
    supplies: {
      mode: supplies.mode === 'expedition' ? 'expedition' : 'permanent',
      current: Math.max(0, Math.round(clamp(supplies.current ?? 0, 0, 999999)))
    },
    modules: { exhaustionSleep: modules.exhaustionSleep === true },
    updatedAt: source.updatedAt || nowIso()
  };
}
function ensureCharacterState(character, day = 1) {
  const state = character?.state && typeof character.state === 'object' ? character.state : (character.state = {});
  state.wounds = state.wounds && typeof state.wounds === 'object' ? state.wounds : { light:0,lightMax:2,medium:0,mediumMax:1,serious:0,seriousMax:1,critical:false };
  state.activeEffects = Array.isArray(state.activeEffects) ? state.activeEffects : [];
  const survival = state.campaignSurvival && typeof state.campaignSurvival === 'object' ? state.campaignSurvival : {};
  state.campaignSurvival = {
    hungerStage: ['satiated','hungry','exhausted'].includes(survival.hungerStage) ? survival.hungerStage : 'satiated',
    missedMeals: Math.max(0, Math.round(Number(survival.missedMeals) || 0)),
    sleepDebtDays: Math.max(0, Math.round(Number(survival.sleepDebtDays) || 0)),
    lastLongRestDay: Math.max(0, Math.round(Number.isFinite(Number(survival.lastLongRestDay)) ? Number(survival.lastLongRestDay) : day)),
    lastRestAt: survival.lastRestAt || null,
    lastFedAt: survival.lastFedAt || null
  };
  return state;
}
function skillMap(skills, amount) {
  return Object.fromEntries(skills.map(skill => [skill, amount]));
}
function removeSystemEffects(state, sources = SURVIVAL_SOURCES) {
  state.activeEffects = (Array.isArray(state.activeEffects) ? state.activeEffects : []).filter(effect => !sources.has(effect?.source));
}
function upsertEffect(state, source, title, desc, skillBonuses) {
  state.activeEffects = (Array.isArray(state.activeEffects) ? state.activeEffects : []).filter(effect => effect?.source !== source);
  state.activeEffects.unshift({
    id: `${source}-${Date.now()}-${Math.random().toString(16).slice(2,8)}`,
    title, name:title, desc, description:desc, source, duration:'Пока действует модуль кампании',
    skillBonuses, createdAt:nowIso(), campaignSystem:true
  });
}
function syncSurvivalEffects(character, timeline) {
  const state = ensureCharacterState(character, timeline.day);
  removeSystemEffects(state);
  if (!timeline.modules.exhaustionSleep) return state.campaignSurvival;
  const survival = state.campaignSurvival;
  if (survival.hungerStage === 'hungry') {
    upsertEffect(state, 'campaign-survival-hunger', 'Голодный', '−1 к Физической силе и навыкам Выносливости.', {
      'Физическая сила':-1, ...skillMap(ENDURANCE_SKILLS,-1)
    });
  } else if (survival.hungerStage === 'exhausted') {
    upsertEffect(state, 'campaign-survival-hunger', 'Истощённый', '−2 ко всем проверкам навыков.', skillMap(ALL_SKILLS,-2));
  }
  if (survival.sleepDebtDays === 1) {
    upsertEffect(state, 'campaign-survival-sleep', 'Не выспался', '−1 к навыкам Интеллекта и Концентрации.', skillMap(INTELLIGENCE_AND_CONCENTRATION,-1));
  } else if (survival.sleepDebtDays >= 2) {
    upsertEffect(state, 'campaign-survival-sleep', 'Критическое недосыпание', '−2 ко всем проверкам навыков.', skillMap(ALL_SKILLS,-2));
  }
  return survival;
}
function setModuleEnabled(timeline, characters, enabled) {
  timeline.modules.exhaustionSleep = Boolean(enabled);
  for (const character of characters || []) {
    const state = ensureCharacterState(character, timeline.day);
    state.campaignSurvival = {
      hungerStage:'satiated', missedMeals:0, sleepDebtDays:0,
      lastLongRestDay:Math.max(0,timeline.day-1), lastRestAt:null, lastFedAt:null
    };
    syncSurvivalEffects(character, timeline);
  }
  timeline.updatedAt = nowIso();
  return timeline;
}
function clearDayBoundRuntime(character) {
  const state = character?.state;
  const runtime = state?._battlemapAberration;
  if (runtime && typeof runtime === 'object') delete runtime.lockedUntilDay;
  if (state && Array.isArray(state.activeEffects)) {
    state.activeEffects = state.activeEffects.filter(effect => !/до\s+конца\s+дня/i.test(String(effect?.duration || '')));
  }
}
function advanceTime(timeline, characters, minutes) {
  const delta = Math.round(clamp(minutes, 0, 5256000));
  if (!delta) return { minutes:0, crossedDays:0 };
  const oldDay = timeline.day;
  const total = timeline.minuteOfDay + delta;
  const crossedDays = Math.floor(total / 1440);
  timeline.minuteOfDay = total % 1440;
  timeline.day += crossedDays;
  if (crossedDays > 0) {
    for (let nextDay = oldDay + 1; nextDay <= timeline.day; nextDay += 1) {
      const previousDay = nextDay - 1;
      for (const character of characters || []) {
        clearDayBoundRuntime(character);
        if (!timeline.modules.exhaustionSleep) continue;
        const state = ensureCharacterState(character, previousDay);
        const survival = state.campaignSurvival;
        if (survival.lastLongRestDay < previousDay) survival.sleepDebtDays += 1;
      }
    }
  }
  timeline.updatedAt = nowIso();
  for (const character of characters || []) syncSurvivalEffects(character, timeline);
  return { minutes:delta, crossedDays };
}
function setClock(timeline, characters, day, minuteOfDay) {
  const targetDay = Math.round(clamp(day, 1, 999999));
  const targetMinute = Math.round(clamp(minuteOfDay, 0, 1439));
  if (targetDay > timeline.day || (targetDay === timeline.day && targetMinute >= timeline.minuteOfDay)) {
    const delta = (targetDay - timeline.day) * 1440 + targetMinute - timeline.minuteOfDay;
    return advanceTime(timeline, characters, delta);
  }
  // The GM may correct the campaign clock backwards. This deliberately does
  // not roll survival state backwards; it only corrects the displayed clock.
  timeline.day = targetDay;
  timeline.minuteOfDay = targetMinute;
  timeline.updatedAt = nowIso();
  return { minutes:0, crossedDays:0, correctedBackwards:true };
}
function setSupplies(timeline, mode, current) {
  timeline.supplies.mode = mode === 'expedition' ? 'expedition' : 'permanent';
  timeline.supplies.current = Math.max(0, Math.round(clamp(current, 0, 999999)));
  timeline.updatedAt = nowIso();
  return timeline.supplies;
}
function clearShortRestStates(character) {
  const state = character?.state;
  if (!state) return;
  if (state.werewolf && typeof state.werewolf === 'object') state.werewolf.aftereffects = false;
  state.activeEffects = (Array.isArray(state.activeEffects) ? state.activeEffects : []).filter(effect => effect?.source !== 'werewolfAftereffects');
  const runtime = state._battlemapAberration;
  if (runtime && typeof runtime === 'object') delete runtime.odPenaltyUntilRest;
  if (state._battlemapTraitUsage && typeof state._battlemapTraitUsage === 'object') delete state._battlemapTraitUsage.luckyRerollUsedAt;
  // Generic future-proof escape hatch for effects explicitly marked by duration.
  state.activeEffects = state.activeEffects.filter(effect => !/до\s+(?:короткого\s+)?(?:отдыха|привала)/i.test(String(effect?.duration || '')) || SURVIVAL_SOURCES.has(effect?.source));
}
function healForRest(character, kind) {
  const state = ensureCharacterState(character);
  const before = {
    light:Number(state.wounds.light)||0,
    medium:Number(state.wounds.medium)||0,
    serious:Number(state.wounds.serious)||0
  };
  state.wounds.light = 0;
  if (kind === 'long') {
    state.wounds.medium = 0;
    state.wounds.serious = 0;
    state.activeEffects = state.activeEffects.filter(effect => effect?.source !== CRITICAL_RECOVERY_SOURCE);
    // v1.6.1: long-rest Bonus Trait resources are restored here so the
    // campaign clock and battlemap use the same source of truth.
    if (state._battlemapBonusTraits && typeof state._battlemapBonusTraits === 'object') {
      state._battlemapBonusTraits.longRestUsed = {};
      delete state._battlemapBonusTraits.secondWindPrepared;
    }
  }
  clearShortRestStates(character);
  return {
    light:before.light,
    medium:kind === 'long' ? before.medium : 0,
    serious:kind === 'long' ? before.serious : 0
  };
}
function applyNutrition(character, timeline, fed) {
  const state = ensureCharacterState(character, timeline.day);
  const survival = state.campaignSurvival;
  if (fed) {
    survival.missedMeals = 0;
    survival.lastFedAt = nowIso();
  } else {
    // The FATUM rules define the hunger stages and the cost of a satiated rest,
    // but do not define how many unfed rests advance a stage. Track the fact
    // without inventing a mandatory transition; the GM chooses the stage.
    survival.missedMeals += 1;
  }
  return survival;
}
function setHungerStage(character, timeline, stage) {
  const state = ensureCharacterState(character, timeline.day);
  state.campaignSurvival.hungerStage = ['satiated','hungry','exhausted'].includes(stage) ? stage : 'satiated';
  syncSurvivalEffects(character, timeline);
  return state.campaignSurvival;
}
function applyRest(timeline, characters, options = {}) {
  const kind = options.kind === 'long' ? 'long' : 'short';
  const durationMinutes = kind === 'long' ? 300 : 60;
  const byId = new Map((characters || []).map(character => [character.id, character]));
  const requestedIds = Array.isArray(options.participantIds) ? [...new Set(options.participantIds.map(String))] : [...byId.keys()];
  const participants = requestedIds.map(id => byId.get(id)).filter(Boolean);
  const fedRequested = new Set(Array.isArray(options.fedCharacterIds) ? options.fedCharacterIds.map(String) : requestedIds);
  const fedIds = new Set();
  if (timeline.supplies.mode === 'permanent') {
    for (const character of participants) fedIds.add(character.id);
  } else {
    for (const character of participants) if (fedRequested.has(character.id)) fedIds.add(character.id);
    if (fedIds.size > timeline.supplies.current) {
      const error = new Error(`Недостаточно походных припасов: нужно ${fedIds.size}, доступно ${timeline.supplies.current}.`);
      error.statusCode = 409;
      throw error;
    }
    timeline.supplies.current -= fedIds.size;
  }
  const clock = advanceTime(timeline, characters, durationMinutes);
  const results = [];
  for (const character of participants) {
    const healing = healForRest(character, kind);
    const state = ensureCharacterState(character, timeline.day);
    state.campaignSurvival.lastRestAt = nowIso();
    if (kind === 'long') {
      state.campaignSurvival.sleepDebtDays = 0;
      state.campaignSurvival.lastLongRestDay = timeline.day;
    }
    applyNutrition(character, timeline, fedIds.has(character.id));
    syncSurvivalEffects(character, timeline);
    results.push({
      characterId:character.id,
      name:character.name,
      fed:fedIds.has(character.id),
      healing,
      hungerStage:state.campaignSurvival.hungerStage,
      sleepDebtDays:state.campaignSurvival.sleepDebtDays
    });
  }
  timeline.restSerial += 1;
  timeline.updatedAt = nowIso();
  return { kind, durationMinutes, clock, results, supplies:{...timeline.supplies}, restSerial:timeline.restSerial };
}
function addCriticalRecoveryEffect(state) {
  if (!state || typeof state !== 'object') return;
  state.activeEffects = Array.isArray(state.activeEffects) ? state.activeEffects : [];
  state.activeEffects = state.activeEffects.filter(effect => effect?.source !== CRITICAL_RECOVERY_SOURCE);
  state.activeEffects.unshift({
    id:`critical-recovery-${Date.now()}-${Math.random().toString(16).slice(2,8)}`,
    title:'Восстановление после Критического ранения',
    name:'Восстановление после Критического ранения',
    desc:'−2 ко всем проверкам до ближайшего длительного привала.',
    description:'−2 ко всем проверкам до ближайшего длительного привала.',
    source:CRITICAL_RECOVERY_SOURCE,
    duration:'До длительного привала',
    skillBonuses:skillMap(ALL_SKILLS,-2),
    createdAt:nowIso(), campaignSystem:true
  });
}
function statusForCharacter(character, timeline) {
  const state = ensureCharacterState(character, timeline.day);
  return {
    characterId:character.id,
    name:character.name,
    hungerStage:state.campaignSurvival.hungerStage,
    missedMeals:state.campaignSurvival.missedMeals,
    sleepDebtDays:state.campaignSurvival.sleepDebtDays,
    lastLongRestDay:state.campaignSurvival.lastLongRestDay
  };
}

module.exports = {
  ALL_SKILLS,
  CRITICAL_RECOVERY_SOURCE,
  makeTimeline,
  ensureCharacterState,
  syncSurvivalEffects,
  setModuleEnabled,
  advanceTime,
  setClock,
  setSupplies,
  setHungerStage,
  applyRest,
  addCriticalRecoveryEffect,
  statusForCharacter
};
