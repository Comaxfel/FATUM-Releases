'use strict';

// Visual semantics only. Classic Battlemap owns transport/rendering; ToL only
// describes which compact effect should represent an already resolved action.
const MAGIC = Object.freeze({
  'spell-01': { family:'aura',      color:'#e9e6d6', secondaryColor:'#91b7c7', durationMs:1395,  radius:30, particles:9, sides:0, intensity:1.05, twist:.18, travelKind:'ember' },
  'spell-02': { family:'sigil',     color:'#d7b56d', secondaryColor:'#8e6f42', durationMs:1364,  radius:8,  particles:8, sides:4, intensity:1.05, twist:.34, travelKind:'sigil' },
  'spell-03': { family:'heal',      color:'#d9d5c8', secondaryColor:'#8f2330', durationMs:1209,  radius:5,  particles:10, sides:0, intensity:1.05, twist:.16, travelKind:'blood' },
  'spell-04': { family:'echo',      color:'#b7d5cf', secondaryColor:'#6d8d89', durationMs:1628, radius:9,  particles:11, sides:0, intensity:1.05, twist:.42, travelKind:'spirit' },
  'spell-05': { family:'shadow',    color:'#695a88', secondaryColor:'#211b30', durationMs:1519,  radius:20, particles:12, sides:0, intensity:1.05, twist:.61, travelKind:'shade' },
  'spell-06': { family:'bolt',      color:'#6e8d58', secondaryColor:'#1c2418', durationMs:1023,  radius:5,  particles:10, sides:3, intensity:1.22, twist:.22, travelKind:'ember' },
  'spell-07': { family:'bind',      color:'#77909c', secondaryColor:'#33454d', durationMs:1395,  radius:7,  particles:8, sides:4, intensity:1.05, twist:.27, travelKind:'chain' },
  'spell-08': { family:'seal',      color:'#8d87b8', secondaryColor:'#3f395e', durationMs:1271,  radius:7,  particles:9, sides:6, intensity:1.05, twist:.46, travelKind:'sigil' },
  'spell-09': { family:'tether',    color:'#9b2738', secondaryColor:'#3a0f18', durationMs:1705, radius:6,  particles:9, sides:0, intensity:1.11, twist:.73, travelKind:'blood' },
  'spell-10': { family:'heal',      color:'#d69aa0', secondaryColor:'#7d3741', durationMs:1395,  radius:6,  particles:11, sides:0, intensity:1.05, twist:.31, travelKind:'blood' },
  'spell-11': { family:'wave',      color:'#d5bd78', secondaryColor:'#665733', durationMs:1178,  radius:8,  particles:10, sides:0, intensity:1.19, twist:.19, travelKind:'sigil' },
  'spell-12': { family:'stitch',    color:'#d6a08d', secondaryColor:'#744c43', durationMs:1581, radius:6,  particles:12, sides:0, intensity:1.05, twist:.53, travelKind:'blood' },
  'spell-13': { family:'shock',     color:'#cbd1d2', secondaryColor:'#5b686b', durationMs:961,  radius:6,  particles:9, sides:0, intensity:1.30, twist:.14, travelKind:'cinder' },
  'spell-14': { family:'teleport',  color:'#63527f', secondaryColor:'#16121f', durationMs:1519,  radius:8,  particles:12, sides:0, intensity:1.16, twist:.88, travelKind:'rift' },
  'spell-15': { family:'spirit',    color:'#c7d1c8', secondaryColor:'#6d7f77', durationMs:2015, radius:9,  particles:13, sides:0, intensity:1.05, twist:.67, travelKind:'spirit' },
  'spell-16': { family:'tether',    color:'#b74850', secondaryColor:'#e0b5a7', durationMs:1628, radius:7,  particles:11, sides:0, intensity:1.24, twist:.49, travelKind:'blood' },
  'spell-17': { family:'sigil',     color:'#88adb5', secondaryColor:'#395962', durationMs:1674, radius:10, particles:10, sides:7, intensity:1.05, twist:.24, travelKind:'sigil' },
  'spell-18': { family:'dispel',    color:'#d9e3df', secondaryColor:'#7894a1', durationMs:1364,  radius:8,  particles:12, sides:5, intensity:1.23, twist:.37, travelKind:'sigil' },
  'spell-19': { family:'hand',      color:'#8e75a5', secondaryColor:'#3c2b50', durationMs:1178,  radius:9,  particles:10, sides:0, intensity:1.27, twist:.33, travelKind:'rift' },
  'spell-20': { family:'column',    color:'#827c72', secondaryColor:'#d38b55', durationMs:1736, radius:10, particles:14,sides:0, intensity:1.32, twist:.72, travelKind:'cinder' },
  'spell-21': { family:'spirit',    color:'#a8c3d2', secondaryColor:'#465c70', durationMs:1798, radius:8,  particles:12, sides:0, intensity:1.13, twist:.91, travelKind:'spirit' },
  'spell-22': { family:'zone',      color:'#d2b269', secondaryColor:'#617b92', durationMs:1829, radius:15, particles:16,sides:8, intensity:1.05, twist:.28, travelKind:'sigil' },
  'spell-23': { family:'harvest',   color:'#4c4359', secondaryColor:'#17141c', durationMs:1628, radius:15, particles:16,sides:0, intensity:1.32, twist:.83, travelKind:'shade' },
  'spell-24': { family:'teleport',  color:'#6d9caf', secondaryColor:'#263c49', durationMs:1674, radius:10, particles:13, sides:0, intensity:1.24, twist:.44, travelKind:'rift' },
  'spell-25': { family:'fade',      color:'#aaa99f', secondaryColor:'#5b5a56', durationMs:1581, radius:8,  particles:10, sides:0, intensity:1.05, twist:.57, travelKind:'shade' },
  'spell-26': { family:'rift',      color:'#8d4b77', secondaryColor:'#241322', durationMs:2046, radius:12, particles:14,sides:0, intensity:1.35, twist:.96, travelKind:'rift' },
  'spell-27': { family:'flesh',     color:'#a64a52', secondaryColor:'#5a2028', durationMs:1426,  radius:7,  particles:13, sides:0, intensity:1.30, twist:.39, travelKind:'blood' },
  'spell-28': { family:'zone',      color:'#a34c4c', secondaryColor:'#2e1718', durationMs:1829, radius:20, particles:14,sides:10,intensity:1.13, twist:.12, travelKind:'sigil' },
  'spell-29': { family:'spirit',    color:'#80927f', secondaryColor:'#28312b', durationMs:2139, radius:12, particles:16,sides:0, intensity:1.19, twist:.76, travelKind:'spirit' },
  'spell-30': { family:'judgment',  color:'#d59b48', secondaryColor:'#733b28', durationMs:1519,  radius:20, particles:16,sides:6, intensity:1.35, twist:.21, travelKind:'cinder' }
});

function weaponPreset(weapon={}){
  const name=String(weapon.name||''),category=String(weapon.category||''),kind=String(weapon.kind||''),damageType=String(weapon.damageType||'');
  if(/укус|челюст/i.test(`${name} ${category}`))return 'melee-bite';
  if(/когт/i.test(`${name} ${category}`))return 'melee-claw';
  if(kind==='bow')return /тяж/i.test(name)?'arrow-heavy':'arrow';
  if(kind==='crossbow')return /тяж|военн/i.test(name)?'bolt-heavy':'bolt';
  if(kind==='firearm')return /тяж/i.test(name)?'firearm-heavy':'firearm';
  if(kind==='thrown'){
    if(/нож/i.test(name))return 'thrown-knife';
    if(/пращ/i.test(name))return 'sling-stone';
    if(/копь|дрот/i.test(name))return /тяж/i.test(name)?'thrown-spear-heavy':'thrown-spear';
    return 'thrown';
  }
  if(category==='Топоры')return /секир/i.test(name)?'melee-cleave-heavy':'melee-cleave';
  if(category==='Ударное')return /молот/i.test(name)?'melee-blunt-heavy':'melee-blunt';
  if(category==='Древковое')return damageType==='slash'?'melee-sweep':'melee-thrust-long';
  if(category==='Безоружный бой')return 'melee-unarmed';
  if(/Двуручный/.test(name))return 'melee-slash-heavy';
  if(damageType==='pierce')return 'melee-thrust';
  if(damageType==='blunt')return 'melee-blunt';
  return 'melee-slash';
}

function attackDescriptor(weapon={}){
  const preset=weaponPreset(weapon),kind=String(weapon.kind||'melee');
  const ranged=kind!=='melee',heavy=/heavy/.test(preset);
  // Melee must read as a quick strike, not as a slow spell animation. The
  // renderer keeps a short impact tail after contact, so this duration is the
  // actual wind-up/swing/recovery window. Heavy weapons are a little slower,
  // claws/unarmed a little faster, but all stay comfortably below one second.
  let durationMs=480;
  if(!ranged){
    if(/claw|bite|unarmed/.test(preset))durationMs=390;
    else if(/thrust/.test(preset))durationMs=430;
    else if(/sweep|cleave/.test(preset))durationMs=heavy?570:510;
    else if(/blunt/.test(preset))durationMs=heavy?560:470;
    else durationMs=heavy?550:450;
  }else if(kind==='firearm')durationMs=heavy?780:680;
  else if(kind==='bow')durationMs=heavy?1320:1180;
  else if(kind==='crossbow')durationMs=heavy?1240:1100;
  else if(kind==='thrown')durationMs=/spear/.test(preset)?1480:/knife/.test(preset)?1220:1340;
  return {kind:ranged?'tol-projectile':'tol-melee',preset,durationMs,damageType:String(weapon.damageType||''),intensity:heavy?1.78:ranged?1.34:1.52};
}

const DEFAULT_TRAVEL_BY_FAMILY=Object.freeze({
  aura:'ember',
  sigil:'sigil',
  heal:'blood',
  echo:'spirit',
  shadow:'shade',
  bolt:'ember',
  bind:'chain',
  seal:'sigil',
  tether:'blood',
  wave:'sigil',
  stitch:'blood',
  shock:'cinder',
  teleport:'rift',
  spirit:'spirit',
  dispel:'sigil',
  hand:'rift',
  column:'cinder',
  zone:'sigil',
  harvest:'shade',
  fade:'shade',
  rift:'rift',
  flesh:'blood',
  judgment:'cinder'
});

function magicDescriptor(spellId){
  const base=MAGIC[String(spellId||'')];
  if(!base)return null;
  const family=String(base.family||'');
  const travelKind=String(base.travelKind||DEFAULT_TRAVEL_BY_FAMILY[family]||'sigil');
  // Keep all 30 formula identities from MAGIC, but make the live Battlemap
  // presentation brighter/longer. Every formula must also advertise at least
  // one visible travel / arrival cue so the map never resolves a spell silently.
  return {kind:'tol-magic',preset:String(spellId),...base,travelKind,durationMs:Math.round(base.durationMs*1.18),particles:Math.max(8,Math.round(Number(base.particles||8)*1.28)),intensity:Math.max(1.32,Number(base.intensity||1)*1.22),glow:true};
}

function grappleDescriptor(success,action='grapple'){
  const escape=String(action)==='escape';
  return {kind:'tol-melee',preset:success?(escape?'grapple-break':'grapple-lock'):'grapple-fail',durationMs:success?1450:1120,damageType:'control',intensity:success?1.6:1.28,color:success?(escape?'#79c9bd':'#c95849'):'#81786d',secondaryColor:success?(escape?'#d9fff5':'#f0b96f'):'#d8cab0',grapple:true};
}

function zonePreset(zone={}){
  if(zone.vfxPreset&&MAGIC[zone.vfxPreset])return zone.vfxPreset;
  if(zone.type==='light')return 'spell-01';
  if(zone.type==='ward')return 'spell-02';
  if(zone.type==='great-seal')return 'spell-22';
  if(zone.type==='anti-magic')return 'spell-28';
  if(zone.type==='unstable-rift')return 'spell-26';
  return null;
}

module.exports={MAGIC,weaponPreset,attackDescriptor,magicDescriptor,grappleDescriptor,zonePreset};
