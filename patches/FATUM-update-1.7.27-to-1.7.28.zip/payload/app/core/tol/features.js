'use strict';
const E=require('./engine');const {assert,n,die,use,effect,has,level,pay,requireTarget,morale,check}=E;
const SKILL_FORMS={
 'Физическая сила':['Физическая сила','Физическую силу','Физической силы','Силы'],
 'Взлом':['Взлом','Взлома','Взлому'],
 'Акробатика':['Акробатика','Акробатику','Акробатики'],
 'Скрытность':['Скрытность','Скрытности','Скрытностью'],
 'Выдержка':['Выдержка','Выдержку','Выдержки'],
 'Стойкость':['Стойкость','Стойкости'],
 'Иммунитет':['Иммунитет','Иммунитета','Иммунитету'],
 'Бдительность':['Бдительность','Бдительности','Бдительностью'],
 'Воля':['Воля','Воле','Воли','Волю'],
 'Меткость':['Меткость','Меткости'],
 'Выживание':['Выживание','Выживания','Выживанию'],
 'Анализ':['Анализ','Анализа','Анализу'],
 'Эрудиция':['Эрудиция','Эрудиции','Эрудицию'],
 'Память':['Память','Памяти','Памятью'],
 'Медицина':['Медицина','Медицины','Медицине','Медицину'],
 'Механика':['Механика','Механики','Механике','Механику'],
 'Убеждение':['Убеждение','Убеждения','Убеждению'],
 'Обман':['Обман','Обмана','Обману'],
 'Интуиция':['Интуиция','Интуиции','Интуицию'],
 'Запугивание':['Запугивание','Запугивания','Запугиванию'],
 'Очарование':['Очарование','Очарования','Очарованию']
};
const skillsIn=text=>{const source=String(text||'').toLocaleLowerCase('ru-RU').replace(/ё/g,'е');return Object.values(E.SKILLS).flat().filter(skill=>(SKILL_FORMS[skill]||[skill]).some(form=>source.includes(String(form).toLocaleLowerCase('ru-RU').replace(/ё/g,'е'))));};
const MASTERY_CHECK_SKILLS={
 'Следопыт':['Выживание','Бдительность'],'Зверолов':['Механика','Выживание'],'Выживальщик':['Выдержка','Иммунитет','Выживание'],'Разведчик':['Скрытность','Бдительность'],'Верхолаз':['Акробатика','Физическая сила'],'Всадник':['Акробатика','Выживание','Воля'],'Лодочник':['Акробатика','Выживание'],'Кузнец':['Механика'],'Оружейник':['Механика'],'Взломщик':['Взлом'],'Лекарь':['Медицина'],'Травник':['Медицина','Выживание','Эрудиция'],'Писец':['Память','Эрудиция'],'Хранитель хроник':['Память','Эрудиция'],'Знаток древностей':['Анализ','Эрудиция'],'Исследователь сверхъестественного':['Анализ','Эрудиция'],'Могильщик':['Медицина','Анализ','Эрудиция'],'Переговорщик':['Убеждение','Очарование'],'Торговец':['Убеждение','Обман','Интуиция'],'Дознаватель':['Интуиция','Анализ','Запугивание'],'Притворщик':['Обман'],'Придворный':['Очарование','Убеждение','Память'],'Посредник':['Интуиция','Обман','Убеждение']
};
const REACTIVE_MASTERY=new Set(['Разведчик','Взломщик','Переговорщик']);
const REACTIVE_BELIEFS=new Set(['Старое нас погубило','Жизнь дороже слова','Победа имеет цену','Судьбу куют руками']);
const GENERIC_MASTERY_CHECKS=new Set(['Бронник']);
const GENERIC_BELIEF_CHECKS=new Set(['Есть знания, которым следует умереть','Клятва священна','Слабого должно защищать']);
const GENERIC_CHARACTER_CHECKS=new Set(['Упрямый','Азартный','Преданный','Самоуверенный','Лояльный']);
const CHARISMA_SKILLS=E.SKILLS['Обаятельный'];
function checkTextMechanic(text,name=''){
 const source=String(text||''),extra=/\+\s*1[кd]4/i.test(source)?4:0,advantage=/преимуществ/i.test(source),modifier=name==='Эрудит'?2:0;
 return {extraDie:extra,advantage,modifier};
}
function checkUsageScope(kind,entry){
 if(kind==='belief')return /бой/i.test(String(entry?.frequency||''))?'combat':'scene';
 if(kind==='mastery')return /большой\s+привал|привал/i.test(String(entry?.frequency||''))?'rest':/бой/i.test(String(entry?.frequency||''))?'combat':'scene';
 return 'scene';
}
function checkOptionUsed(a,kind,name,entry){const scope=checkUsageScope(kind,entry);return Boolean(a.used?.[scope]?.[name]);}
function customEntry(a,kind,name){const list=kind==='mastery'?a.customMastery:kind==='belief'?a.customBeliefs:a.customCharacterTraits;return (list||[]).find(x=>x.name===name)||null;}
function customMechanicEffect(a,entry,context=''){
 const text=[entry.description,entry.support,entry.narrative,context].filter(Boolean).join(' ').trim();
 if(entry.mechanic==='narrative'){effect(a,'custom-narrative',text||entry.name,{sourceName:entry.name,needsGm:true});return {text:text||entry.name,narrative:true};}
 if(entry.mechanic==='attack1'){effect(a,'custom-attack',text||entry.name,{sourceName:entry.name,nextAttack:true,modifier:1});return {text:`${entry.name}: +1 к следующей подходящей атаке/Обмену.`};}
 const extra={sourceName:entry.name,nextCheck:true,skills:entry.skills||[]};if(entry.mechanic==='advantage')extra.advantage=true;if(entry.mechanic==='d4')extra.extraDie=4;if(entry.mechanic==='plus1')extra.modifier=1;effect(a,'custom-check',text||entry.name,extra);return {text:`${entry.name}: механический эффект подготовлен к следующей подходящей проверке.`};
}
function characterCheckApplies(entry,skill){if(!entry?.modes?.includes('check'))return false;const skills=skillsIn(entry.support||'');return skills.includes(skill)||GENERIC_CHARACTER_CHECKS.has(entry.name);}
function beliefCheckApplies(entry,skill){if(!entry)return false;const skills=skillsIn(entry.description||'');if(skills.includes(skill))return true;if(REACTIVE_BELIEFS.has(entry.name))return entry.name!=='Старое нас погубило';return GENERIC_BELIEF_CHECKS.has(entry.name);}
function checkOptions(a,skill){
 const result=[],push=(option)=>{if(option?.relevant)result.push(option);};
 for(const name of a.mastery||[]){const entry=E.catalog.mastery.find(x=>x.name===name)||customEntry(a,'mastery',name),skills=entry?.kind==='mastery'&&entry?.skills?.length?entry.skills:(MASTERY_CHECK_SKILLS[name]||skillsIn(entry?.description||''));if(!entry||(!skills.includes(skill)&&!GENERIC_MASTERY_CHECKS.has(name)))continue;const reactionOnly=entry.kind==='mastery'?entry.mechanic==='narrative'||entry.mechanic==='attack1':REACTIVE_MASTERY.has(name),mechanic=entry.kind==='mastery'?{advantage:entry.mechanic==='advantage',extraDie:entry.mechanic==='d4'?4:0,modifier:entry.mechanic==='plus1'?1:0}:checkTextMechanic(entry.description,name),direct=Boolean(!reactionOnly&&(mechanic.advantage||mechanic.extraDie||mechanic.modifier));push({id:`mastery:${name}`,kind:'mastery',name,text:entry.description,frequency:entry.frequency,relevant:true,used:checkOptionUsed(a,'mastery',name,entry),reactionOnly:reactionOnly||!direct,selectable:direct,needsContext:GENERIC_MASTERY_CHECKS.has(name),mechanic});}
 for(const name of a.beliefs||[]){const entry=E.catalog.beliefs.find(x=>x.name===name)||customEntry(a,'belief',name);if(entry?.kind==='belief'){if(entry.mechanic==='narrative'||entry.mechanic==='attack1'||entry.skills?.length&&!entry.skills.includes(skill))continue;}else if(!beliefCheckApplies(entry,skill))continue;const reactionOnly=entry?.kind==='belief'?false:REACTIVE_BELIEFS.has(name),mechanic=entry?.kind==='belief'?{advantage:entry.mechanic==='advantage',extraDie:entry.mechanic==='d4'?4:0,modifier:entry.mechanic==='plus1'?1:0}:checkTextMechanic(entry.description,name),direct=Boolean(!reactionOnly&&(mechanic.advantage||mechanic.extraDie||mechanic.modifier));push({id:`belief:${name}`,kind:'belief',name,text:entry.description,frequency:entry.frequency,relevant:true,used:checkOptionUsed(a,'belief',name,entry),reactionOnly:reactionOnly||!direct,selectable:direct,needsContext:direct,mechanic});}
 for(const picked of a.characterTraits||[]){const name=picked?.name||picked,entry=E.catalog.characterTraits.find(x=>x.name===name)||customEntry(a,'character',name);if(entry?.kind==='character'?(entry.mechanic!=='narrative'&&entry.mechanic!=='attack1'&&(!entry.skills?.length||entry.skills.includes(skill))):characterCheckApplies(entry,skill)){const cm=entry?.kind==='character'?{advantage:entry.mechanic==='advantage',extraDie:entry.mechanic==='d4'?4:0,modifier:entry.mechanic==='plus1'?1:0}:{extraDie:4};push({id:`character:${name}`,kind:'character',name,text:entry.support||entry.description,frequency:'1/сцену',relevant:true,used:Boolean(a.used?.scene?.['Опора']),reactionOnly:entry?.kind!=='character',selectable:entry?.kind==='character',needsContext:true,mechanic:cm});}}
 if(level(a,'Умный')>=3&&['Анализ','Эрудиция','Память'].includes(skill))push({id:'trait:Эрудит',kind:'trait',name:'Эрудит',text:'1 раз за сцену при немагической проверке знания: знакомство с предметом и +2.',frequency:'1/сцену',relevant:true,used:Boolean(a.used?.scene?.['Эрудит']),reactionOnly:false,selectable:true,mechanic:{modifier:2}});
 if(level(a,'Уверенный')>=1&&['Воля',...CHARISMA_SKILLS].includes(skill))push({id:'trait:Уверенный 1',kind:'trait',name:'Самообладание',text:'1 раз за сцену перед проверкой Харизмы или Воли получите Преимущество.',frequency:'1/сцену',relevant:true,used:Boolean(a.used?.scene?.['Уверенный 1']),reactionOnly:false,selectable:true,mechanic:{advantage:true}});
 if(level(a,'Обаятельный')>=6&&CHARISMA_SKILLS.includes(skill))push({id:'trait:Вес слова',kind:'trait',name:'Вес слова',text:'1 раз за социальную сцену после провала проверки Харизмы потребуйте Успех на грани независимо от разницы; Ведущий назначает Тяжёлое последствие.',frequency:'1/сцену',relevant:true,used:Boolean(a.used?.scene?.['Вес слова']),reactionOnly:true,selectable:false,mechanic:{}});
 const speciesOptions={
  gnoll:[['gnoll-massive','Массивное сложение',['Физическая сила'],'Преимущество на Физическую силу при Захвате, сопротивлении Захвату, толчке, удержании и сопротивлении принудительному перемещению.'],['gnoll-scent','Нюх падальщика',['Бдительность','Выживание'],'Преимущество при поиске крови, свежего запахового следа, раненого существа или падали.'],['gnoll-immunity','Желудок падальщика',['Иммунитет'],'Преимущество против естественных болезней, испорченной пищи, заражённой воды и пищевых токсинов.']],
  kuthi:[['kuthi-sight','Вранье зрение',['Бдительность'],'Преимущество при обнаружении далёких объектов и слабого движения.'],['kuthi-voice','Подражание',['Обман'],'Преимущество при подражании знакомому голосу, если цель только слышит Кутхи.'],['kuthi-mountain','Горная физиология',['Выдержка','Иммунитет'],'Преимущество против сильного естественного холода, разреженного воздуха и высотной болезни.']],
  krau:[['krau-depth','Рождённый для глубин',['Выдержка'],'Преимущество против долгого плавания, холодной воды, естественного давления глубины и нагрузки под водой.']],
  pallid:[['pallid-immunity','Чужая плоть',['Иммунитет'],'Преимущество против естественных болезней, ядов, заражённой воды, испорченной пищи и естественных токсинов.']]
 };
 for(const [id,name,skills,text] of speciesOptions[a.species]||[])if(skills.includes(skill))push({id:`species:${id}`,kind:'species',name,text,frequency:'по ситуации',relevant:true,used:false,reactionOnly:false,selectable:true,mechanic:{advantage:true}});
 if(a.species==='fari'&&skill==='Память')push({id:'species:fari-memory',kind:'species',name:'Память Мотылька',text:'1 раз за сцену Преимущество на Память, если Фарий лично видел, читал, слышал или записывал сведения.',frequency:'1/сцену',relevant:true,used:Boolean(a.used?.scene?.['Память Мотылька']),reactionOnly:false,selectable:true,mechanic:{advantage:true}});
 return result;
}
function applyCheckSelections(a,b){
 const selected=[...new Set(Array.isArray(b.optionIds)?b.optionIds.map(String):[])];if(!selected.length)return {...b};
 const valid=new Map(checkOptions(a,b.skill).map(x=>[x.id,x])),options={...b},applied=[];let masteryCount=0;
 const preparedMastery=(a.effects||[]).find(e=>e.nextCheck&&e.sourceName&&(a.mastery||[]).includes(e.sourceName)&&(!e.context||e.context===b.context)&&(!e.targetId||e.targetId===b.targetId)&&(!e.skills?.length||e.skills.includes(b.skill)));
 for(const id of selected){const option=valid.get(id);assert(option&&option.selectable&&!option.reactionOnly,`Особенность «${id}» нельзя применить до этой проверки.`);assert(!option.used,`«${option.name}» уже использовано.`);const optionContext=String(b.optionContexts?.[id]||'').trim().slice(0,1000);if(option.needsContext)assert(optionContext.length>=3,`Опишите, как «${option.name}» связано с этой проверкой.`);if(option.kind==='mastery'){masteryCount++;assert(!preparedMastery,`К этой проверке уже подготовлено Мастерство «${preparedMastery?.sourceName}».`);}assert(masteryCount<=1,'К одной проверке можно применить только одно Мастерство.');const m=option.mechanic||{};options.modifier=n(options.modifier)+n(m.modifier);if(m.extraDie){options.extraDice=Array.isArray(options.extraDice)?[...options.extraDice]:[];options.extraDice.push(m.extraDie);}options.advantage=Boolean(options.advantage||m.advantage);
  if(option.kind==='mastery'){const entry=E.catalog.mastery.find(x=>x.name===option.name)||customEntry(a,'mastery',option.name);use(a,option.name,checkUsageScope('mastery',entry));}
  else if(option.kind==='belief'){const entry=E.catalog.beliefs.find(x=>x.name===option.name)||customEntry(a,'belief',option.name);use(a,option.name,checkUsageScope('belief',entry));}
  else if(option.kind==='character')use(a,'Опора','scene');
  else if(option.kind==='trait')use(a,id==='trait:Уверенный 1'?'Уверенный 1':option.name,'scene');
  else if(option.kind==='species'&&id==='species:fari-memory')use(a,'Память Мотылька','scene');
  applied.push({id:option.id,kind:option.kind,name:option.name,text:option.text,...(optionContext?{context:optionContext}:{})});
 }
 options.appliedCheckOptions=applied;return options;
}

function combatMastery(a,t,w,name,b,ctx){assert(a.mastery.includes(name),'Это Мастерство не выбрано.');const m=E.catalog.mastery.find(m=>m.name===name);assert(m?.frequency==='1/бой','Не боевое Мастерство.');const result={};
 if(name==='Фехтовальщик'){assert(w.category==='Клинковое','Нужно клинковое оружие.');result.advantage=true;}
 else if(name==='Дуэлянт'){assert(!ctx.otherEnemies?.(a,t),'Рядом есть другие противники.');result.extraDie=4;}
 else if(name==='Секироносец'){assert(w.category==='Топоры'&&E.equipped(t,'shield'),'Нужны топор и цель со щитом.');return {postSuccess:true};}
 else if(name==='Молотобоец'){assert(w.category==='Ударное','Нужно Ударное оружие.');result.piercing=1;}
 else if(name==='Древковик'){assert(w.kind==='melee'&&w.reach===10,'Нужно Длинное оружие.');return {postSuccess:true};}
 else if(name==='Засадник'){assert(has(a,'hidden')||b.ambush,'Нужна подготовленная засада или Скрытность.');result.extraDie=4;}
 else if(name==='Лучник'){assert(w.kind==='bow'&&!ctx.engaged?.(a)&&!has(a,'charge'),'Нужен лук без Натиска и противника рядом.');result.extraDie=4;}
 else if(name==='Стрелок древности'){assert(w.kind==='firearm','Нужно древнее револьверное оружие.');if(b.ignorePenalty)result.bonus=1;else result.extraDie=4;}
 else if(name==='Метатель'){assert(w.kind==='thrown','Нужно метательное оружие.');}
 else assert(false,'Это Мастерство применяется отдельным действием.');use(a,name,'combat');return result;
}
function mastery(a,t,b,ctx){const m=E.catalog.mastery.find(x=>x.name===b.name)||customEntry(a,'mastery',b.name);assert(m&&a.mastery.includes(m.name),'Мастерство не выбрано.');const scope=m.frequency.includes('привал')?'rest':m.frequency.includes('бой')?'combat':'scene';use(a,m.name,scope);if(m.kind==='mastery')return customMechanicEffect(a,m,b.context||'');
 if(['Утешитель','Глашатай'].includes(m.name)){requireTarget(a,t,ctx,ctx.combat?30:Infinity);if(ctx.combat)pay(a,1,ctx);const roll=die(8,ctx.rng);return {text:m.description,roll,restored:morale(t,roll,ctx)};}
 if(m.name==='Боевой предводитель'){requireTarget(a,t,ctx,30);pay(a,1,ctx);effect(t,'leader','+1 к следующей атаке, Обмену или проверке.',{modifier:1,nextCheck:true,nextAttack:true,scope:'next-turn-start'});}
 else if(m.name==='Боец в доспехе')effect(a,'ignore-armor',m.description,{scope:'next-turn-end'});
 else if(m.name==='Телохранитель'){assert(b.triggeredAttack,'Телохранитель применяется только как реакция на атаку по соседнему союзнику.');requireTarget(a,t,ctx,5);effect(t,'bodyguard',m.description,{defenseAdvantage:true,sourceId:a.id,scope:'reaction'});}
 else if(m.name==='Щитоносец'){assert(b.successfulShieldDefense,'Требуется успешная защита щитом.');effect(a,'free-move',m.description,{feet:5,scope:'reaction',moveTargetId:b.moveTargetId||a.id});}
 else if(m.name==='Секироносец'){assert(b.successfulAttack&&t,'Секироносец применяется только после успешной атаки топором по цели со щитом.');const shield=t.inventory.find(i=>i.kind==='shield'&&i.equipped);assert(shield,'У цели нет экипированного щита.');shield.bzCurrent=Math.max(0,n(shield.bzCurrent)-1);E.project(t);}
 else if(m.name==='Древковик'){assert(b.wonExchange&&t,'Древковик применяется только после победы в Обмене Длинным оружием.');ctx.push?.(a,t,5);}
 else if(m.name==='Бронник'){assert(b.repaired,'Примените Бронника при успешном ремонте.');const it=t?.inventory.find(i=>i.id===b.itemId)||a.inventory.find(i=>i.id===b.itemId);assert(it,'Выберите броню.');const p=E.catalog.armor.concat(E.catalog.shields).find(x=>x.id===it.profileId);it.bzCurrent=Math.min(p.bz,n(it.bzCurrent)+1);}
 else if(m.name==='Костоправ'){requireTarget(a,t,ctx,5);assert(b.treatmentSucceeded,'Требуется успешное лечение.');effect(t,'splint','Штраф подходящей травмы уменьшается на ступень до привала.',{scope:'rest',injury:b.injury||''});}
 else if(['Переговорщик','Разведчик','Взломщик'].includes(m.name)){assert(b.roll&&!b.roll.success,'Требуется свой проваленный бросок.');const allowed={'Переговорщик':['Убеждение','Очарование'],'Разведчик':['Скрытность','Бдительность'],'Взломщик':['Взлом']}[m.name];assert(allowed.includes(b.roll.skill),'Мастерство неприменимо к навыку.');return modifyRoll(a,b.roll,m.name==='Переговорщик'?'reroll-minus-one':'d4',ctx);}
 else {const explicit={Кузнец:['Механика'],Оружейник:['Механика'],Зверолов:['Механика','Выживание'],Лекарь:['Медицина'],Травник:['Медицина','Выживание','Эрудиция'],Лодочник:['Акробатика','Выживание'],Всадник:['Акробатика','Выживание','Воля'],Могильщик:['Медицина','Анализ','Эрудиция'],Дознаватель:['Интуиция','Анализ','Запугивание']};const list=explicit[m.name]||skillsIn(m.description);
 const extra=/\+1к4/.test(m.description),advantage=/[Пп]реимуществ/.test(m.description);if(extra||advantage)effect(a,'mastery-check',m.description,{sourceName:m.name,nextCheck:true,skills:list,extraDie:extra?4:0,advantage});else effect(a,'mastery-narrative',m.description,{sourceName:m.name,needsGm:true});}
 return {text:m.description};
}
function modifyRoll(a,r,mode,ctx,allowSuccess=false){assert(r.actorId===a.id&&r.kind==='check','Можно изменить только собственную проверку навыка.');assert(allowSuccess||!r.success,'Нужна проваленная проверка.');if(mode==='reroll-minus-one')return {...check(a,r.skill,{...r.options,modifier:n(r.options.modifier)-1},ctx),replaces:r.id};const extra=die(4,ctx.rng),out={...r,extra:n(r.extra)+extra,total:r.total+extra,id:E.id(),replaces:r.id};out.success=out.critical==='success'||out.critical!=='failure'&&out.total>=out.target;out.margin=out.total-out.target;return out;}
function belief(a,t,b,ctx){const m=E.catalog.beliefs.find(x=>x.name===b.name)||customEntry(a,'belief',b.name);assert(m&&a.beliefs.includes(m.name),'Убеждение не выбрано.');assert(b.context&&String(b.context).trim().length>=3,'Опишите риск и связь с Убеждением.');use(a,m.name,m.frequency==='1/бой'?'combat':m.frequency.includes('привал')?'rest':'scene');if(m.kind==='belief')return customMechanicEffect(a,m,b.context);
 if(m.name==='Кровь требует крови'){requireTarget(a,t,ctx,Infinity);effect(a,'blood-debt',m.description,{nextAttack:true,modifier:1,targetId:t.id,scope:'next-turn-end'});return {text:m.description};}
 if(/восстановить|восстанавливает/.test(m.description)&&b.mode==='morale'){const target=t||a,roll=die(8,ctx.rng);return {text:m.description,roll,restored:morale(target,roll,ctx)};}
 if(/уменьшить/.test(m.description)&&b.mode==='reduce'){const amount=die(m.description.includes('1к6')?6:4,ctx.rng);assert(n(b.loss)>0,'Укажите потерю Морали до уменьшения.');return {text:m.description,roll:amount,change:morale(a,-Math.max(0,n(b.loss)-amount),ctx)};}
 if(m.name==='Старое нас погубило'){assert(b.roll&&['Анализ','Эрудиция'].includes(b.roll.skill),'Нужен провал Анализа/Эрудиции.');return modifyRoll(a,b.roll,'reroll-minus-one',ctx);}
 if(/после провал/.test(m.description)&&b.roll)return modifyRoll(a,b.roll,'d4',ctx);
 effect(t||a,'belief-check',m.description,{nextCheck:true,skills:skillsIn(m.description),extraDie:m.description.includes('+1к4')?4:0,modifier:m.name==='Род и община прежде всего'?1:0,advantage:m.description.includes('преимущество'),sourceName:m.name});return {text:m.description};
}
function character(a,b,ctx){
 assert(b.context&&String(b.context).trim().length>=3,'Опишите поступок и его цену.');
 if(b.feature==='core'){assert(a.beliefs.includes(a.coreBelief),'Стержень не выбран.');use(a,'Стержень');const roll=die(8,ctx.rng);return {roll,restored:morale(a,roll,ctx),text:'Стержень: восстановление Морали.'};}
 if(b.feature==='betrayal'){const roll=die(4,ctx.rng);return {roll,change:morale(a,-roll,ctx),text:'Предательство Стержня.'};}
 const entry=E.catalog.characterTraits.find(x=>x.name===b.name)||customEntry(a,'character',b.name);assert(entry&&a.characterTraits.some(x=>x.name===entry.name),'Выберите свою Черту характера.');
 if(b.feature==='breakdown'){use(a,'Срыв');const roll=b.mode==='morale'?die(4,ctx.rng):0;if(roll)morale(a,-roll,ctx);effect(a,'breakdown',(entry.breakdown||entry.narrative||entry.description||entry.name)+' '+b.context,{needsGm:true});return {roll,text:'Срыв принят: '+entry.name+'. Монету за значимый Срыв выдаёт Ведущий.'};}
 use(a,'Опора');if(entry.kind==='character')return customMechanicEffect(a,entry,b.context);assert(entry.modes.includes(b.mode),'Этот вариант Опоры не указан у выбранной Черты характера.');
 if(b.mode==='morale'){const target=entry.name==='Весельчак'?(ctx.target||a):a;if(target.id!==a.id)requireTarget(a,target,ctx,Infinity);const roll=die(entry.moraleDie||8,ctx.rng);return {roll,restored:morale(target,roll,ctx),targetId:target.id,text:entry.name+': Мораль +'+roll};}
 if(b.mode==='reduce'){const roll=die(entry.reduceDie||4,ctx.rng);return {roll,change:morale(a,-Math.max(0,n(b.loss)-roll),ctx),text:entry.name+': потеря Морали снижена на '+roll};}
 if(b.afterRoll){const base=b.roll||a.lastCheck;assert(base?.kind==='check'&&!base.supportUsed,'Нет своего доступного броска.');const next=modifyRoll(a,base,'d4',ctx,true);next.supportUsed=true;return next;}
 effect(a,'character-support',entry.support+' '+b.context,{nextCheck:true,extraDie:4});return {text:'Опора «'+entry.name+'»: +1к4 к следующей подходящей немагической проверке.'};
}
function speciesAction(a,t,b,ctx){const act=b.feature;assert(!a.isCreature,'Виды игровых персонажей не применяются к профилю существа.');
 if(act==='swimming'){assert(a.species==='krau','Плавательная Скорость доступна Крау.');a.swimming=!!b.swimming;return {text:a.swimming?'Плавание: 40 футов.':'Наземное движение.'};}
 if(act==='cover-scars'){assert(a.species==='fari','Светящиеся шрамы есть у Фария.');a.scarsCovered=!!b.covered;return {text:a.scarsCovered?'Шрамы закрыты.':'Шрамы светятся на 5 футов.'};}
 if(act==='human-reroll'){assert(a.species==='human'&&b.roll?.kind==='check'&&!b.roll.success,'Пластичность применяется к провалу немагического навыка.');assert(b.repeatPossible,'Повторная попытка должна быть физически возможна.');use(a,'Человеческая пластичность','rest');return check(a,b.roll.skill,b.roll.options,ctx);}
 if(act==='fari-memory'){assert(a.species==='fari'&&b.witnessed,'Фарий должен лично знать сведения.');use(a,'Память Мотылька');effect(a,'moth-memory','Преимущество на Память.',{skills:['Память'],advantage:true,nextCheck:true});}
 else if(act==='mimic'){assert(a.species==='gvined'&&b.observedSkill,'Нужно наблюдать успешный немагический навык.');use(a,'Миметическая нервная система');effect(a,'mimic','Преимущество на следующую проверку наблюдённого навыка.',{skills:[b.observedSkill],advantage:true,nextCheck:true});}
 else if(act==='synapse'){assert(a.species==='gvined','Способность Гвинеда.');const r=check(a,'Воля',{difficulty:10},ctx);if(!r.success){effect(a,'synapse','−1 ОД; нельзя атаковать источник приказа до конца следующего хода.',{targetId:t?.id,scope:'next-turn-end'});a.odCurrent=Math.max(0,a.odCurrent-1);}return r;}
 else if(act==='hydrate'){assert(a.species==='krau','Способность Крау.');ctx.advanceMinutes?.(10);a.effects=a.effects.filter(e=>e.key!=='desiccated');a.lastHydration=n(ctx.clock)+10;}
 else if(act==='lantern-damage'){assert(a.species==='fari','У персонажа нет Фонаря Души.');const damage=n(b.damage);a.resources.lantern=Math.max(0,a.resources.lantern-(damage>=4?2:damage>=2?1:0));if(a.resources.lantern===0){a.medical.dead=true;a.medical.finalDeath=true;delete a.medical.returnAt;}}
 else if(act==='abyss-gift'){assert(a.species==='pallid','Дар доступен Паллиду.');assert(a.resources.blood>0,'Нужна Доза крови.');a.resources.blood--;if(a.abyssGift==='predator'){pay(a,2,ctx);effect(a,'predator','Дар Хищника: +10 Скорости, когти 3 Р, силовые Захваты с Преимуществом.');}else if(a.abyssGift==='flesh'){pay(a,1,ctx);use(a,'Дар Плоти');const w=a.woundList.find(w=>w.id===b.woundId&&w.severity<=2);assert(w,'Выберите Лёгкое или Среднее ранение.');if(--w.severity===0)a.woundList=a.woundList.filter(x=>x.id!==w.id);}else{assert(b.freshBlood,'Нужна кровь недавно умершего разумного.');use(a,'Дар Памяти Крови','rest');ctx.advanceMinutes?.(10);effect(a,'blood-memory','Один чувственный фрагмент памяти и один вопрос Ведущему.',{needsGm:true});}}
 else if(act==='sense'){const contexts={gnoll:{strength:['Физическая сила'],scent:['Бдительность','Выживание'],immunity:['Иммунитет']},kuthi:{sight:['Бдительность'],voice:['Обман'],mountain:['Выдержка','Иммунитет']},krau:{depth:['Выдержка']},pallid:{immunity:['Иммунитет']}};const skills=contexts[a.species]?.[b.context];assert(skills,'Неизвестное видовое преимущество.');effect(a,'species-sense',speciesDescription(a,b.context),{nextCheck:true,skills,advantage:true});}
 else if(act==='grave-sight'){assert(a.species==='krif','Способность Крифа.');ctx.advanceMinutes?.(10);effect(a,'grave-sight','Последний сильный чувственный/эмоциональный отпечаток недавно умершего.',{needsGm:true});}
 else if(!['fari-memory','mimic'].includes(act))assert(false,'Неизвестная видовая способность.');E.project(a);return {text:'Видовая способность применена.'};}
function speciesDescription(a,context){return `${E.species(a).name}: ${context}. Условия — в описании Вида.`;}
function trait(a,t,b,ctx){const name=b.name;
 const req={'Не спускать глаз':['Бдительный',6],'Эрудит':['Умный',3],'Разобрать слабость':['Умный',6],'Вес слова':['Обаятельный',6],'Уверенный 1':['Уверенный',1],'Уверенный 2':['Уверенный',2],'Уверенный 4':['Уверенный',4],'Уверенный 5':['Уверенный',5],'За мной':['Уверенный',6],'Изученная цель':['Вдумчивый',1],'Вдумчивый 3':['Вдумчивый',3],'Вдумчивый 5':['Вдумчивый',5],'Вдумчивый 6':['Вдумчивый',6]};const r=req[name];assert(r&&level(a,r[0])>=r[1],'Способность черты недоступна.');
 if(name==='Эрудит'){use(a,name);effect(a,'erudite','Знакомство с предметом знания, +2 к немагической проверке.',{nextCheck:true,modifier:2,skills:['Эрудиция','Память','Анализ']});}
 if(name==='Вес слова'){use(a,name);assert(b.roll&&!b.roll.success&&['Убеждение','Обман','Интуиция','Запугивание','Очарование'].includes(b.roll.skill),'Нужен провал Харизмы.');return {...b.roll,success:true,edge:true,consequence:'Тяжёлое последствие назначает Ведущий.'};}
 if(name==='Не спускать глаз'){use(a,name,'combat');requireTarget(a,t,ctx,Infinity);pay(a,1,ctx);effect(a,'watch','Первый раз в раунде +1 против наблюдаемой цели.',{targetId:t.id});}
 if(name==='Разобрать слабость'){pay(a,1,ctx);requireTarget(a,t,ctx,Infinity);const roll=check(a,'Анализ',{difficulty:10},ctx);if(roll.success)effect(a,'weakness','Два наблюдаемых факта; Преимущество на первую атаку по цели.',{targetId:t.id,nextAttack:true,advantage:true,scope:'next-turn-end'});return {...roll,facts:roll.success?'Ведущий сообщает два наблюдаемых факта.':null};}
 if(name==='Уверенный 1'){use(a,name);effect(a,'confident','Преимущество на Волю/Харизму.',{nextCheck:true,advantage:true,skills:['Воля',...E.SKILLS['Обаятельный']]});}
 if(name==='Уверенный 2'){use(a,name,'combat');pay(a,1,ctx);requireTarget(a,t,ctx,30);const roll=die(6,ctx.rng);return {roll,restored:morale(t,roll,ctx)};}
 if(name==='Уверенный 4'){use(a,name,'combat');requireTarget(a,t||a,ctx,30);const roll=die(8,ctx.rng);return {roll,change:morale(t||a,-Math.max(0,n(b.loss)-roll),ctx)};}
 if(name==='Уверенный 5'){use(a,name,'combat');requireTarget(a,t,ctx,30);assert(t.morale.current===0,'Мораль союзника должна упасть до 0.');t.morale.current=1;}
 if(name==='За мной'){use(a,name,'combat');pay(a,2,ctx);const targets=(ctx.actors||[]).filter(t=>t.id!==a.id&&ctx.allied?.(a,t)&&ctx.distance(a,t)<=30);return {targets:targets.map(x=>x.id),followMe:true};}
 if(name==='Изученная цель'){pay(a,1,ctx);requireTarget(a,t,ctx,Infinity);effect(a,'studied','Ведущий сообщает один наблюдаемый факт.',{targetId:t.id,needsGm:true});}
 if(name==='Вдумчивый 3'||name==='Вдумчивый 5'){use(a,name,'combat');const studied=a.effects.find(e=>e.key==='studied');assert(studied,'Нет Изученной цели.');if(name.endsWith('5')){pay(a,1,ctx);requireTarget(a,t,ctx,30);}effect(name.endsWith('5')?t:a,'studied-attack','Преимущество против Изученной цели.',{targetId:studied.targetId,nextCheck:true,nextAttack:true,advantage:true,scope:'next-turn-end'});}
 if(name==='Вдумчивый 6'){use(a,name);effect(a,'thoughtful-reaction','Одно подходящее неатакующее действие стоимостью 1 ОД как реакция.',{scope:'reaction',permission:true});}
 return {text:'Способность применена.'};}
function applyCheckFeatures(a,b){const options={...b};if(b.skill==='Бдительность'&&b.context==='surprise'&&level(a,'Вдумчивый')>=4&&!a.used.scene['Вдумчивый 4']){use(a,'Вдумчивый 4');options.advantage=true;}if(b.skill==='Бдительность'&&a.effects.some(e=>e.key==='watch'&&e.targetId===b.targetId)&&!a.used.round.watch){options.modifier=n(options.modifier)+1;a.used.round.watch=true;}const applied=[];for(const e of a.effects.filter(e=>e.nextCheck&&(!e.context||e.context===b.context)&&(!e.targetId||e.targetId===b.targetId)&&(!e.skills?.length||e.skills.includes(b.skill)))){if(e.sourceName&&applied.some(x=>x.sourceName&&a.mastery.includes(x.sourceName))&&a.mastery.includes(e.sourceName))continue;options.modifier=n(options.modifier)+n(e.modifier);options.extraDice||=(options.extraDie?[options.extraDie]:[]);if(e.extraDie)options.extraDice.push(e.extraDie);options.advantage ||= e.advantage;applied.push(e);}a.effects=a.effects.filter(e=>!applied.includes(e));return options;}
module.exports={combatMastery,mastery,belief,character,speciesAction,trait,applyCheckFeatures,modifyRoll,skillsIn,characterCheckApplies,beliefCheckApplies,checkOptions,applyCheckSelections};
