'use strict';
// ToL tactical AI shares the Classic battle-map planner, but all mechanical
// actions still go through the authoritative ToL service. This module contains
// rules-aware scoring only; it does not spend resources by itself (except for
// the legacy npc-step compatibility helper at the bottom).
const E=require('./engine'),C=require('./combat');

const COMBAT_SPELLS=new Set(['spell-03','spell-06','spell-07','spell-08','spell-10','spell-11','spell-12','spell-13','spell-16','spell-19','spell-20','spell-21','spell-23','spell-27','spell-28','spell-30']);
const OFFENSIVE_SPELLS=new Set(['spell-06','spell-07','spell-08','spell-11','spell-13','spell-19','spell-20','spell-21','spell-23','spell-27','spell-30']);
const AREA_SPELLS=new Set(['spell-20','spell-23','spell-30']);
const SUPPORT_SPELLS=new Set(['spell-03','spell-10','spell-12','spell-16','spell-28']);

function profiles(a){
  const result=(a.creatureAttacks||[]).map((_,i)=>E.weapon(a,`creature-${i}`));
  for(const item of (a.inventory||[]).filter(x=>x.kind==='weapon'&&x.equipped&&!x.damaged&&!x.thrown))result.push(E.weapon(a,item.id));
  return result.length?result:[E.weapon(a,'unarmed')];
}
function ranged(w){return ['bow','crossbow','firearm','thrown'].includes(String(w?.kind||''));}
function melee(w){return String(w?.kind||'melee')==='melee';}
function effectiveRange(w){return Number(melee(w)?w.reach:w.range)||5;}
function weaponReady(a,w){const r=a.ready?.[w.id]||{};if(w.kind==='bow')return Boolean(r.drawn);if(w.kind==='crossbow'||w.kind==='firearm')return Number(r.loaded||0)>0;return true;}
function reloadCost(a,w){if(w.kind==='bow')return w.name==='Тяжёлый боевой лук'?2:1;return Math.max(1,Number(w.reload||1));}
function usableCombatSpells(a){return (a.spells||[]).filter(id=>COMBAT_SPELLS.has(id)&&E.catalog.spells.some(s=>s.id===id&&Number(s.threshold||0)<=Number(a.weaponProficiencies?.['Магия']||0)));}
function hasCombatMagic(a){return Number(a.weaponProficiencies?.['Магия']||0)>0&&usableCombatSpells(a).length>0&&!E.has(a,'magic-forbidden')&&!E.has(a,'anti-magic');}
function inferRole(a){
  const ws=profiles(a),rs=ws.filter(ranged),ms=ws.filter(melee),spells=usableCombatSpells(a),magic=Number(a.weaponProficiencies?.['Магия']||0),inventory=a.inventory||[];
  if(magic>=2&&spells.some(id=>OFFENSIVE_SPELLS.has(id)))return'caster';
  if(inventory.some(i=>i.kind==='shield'&&i.equipped&&Number(i.bzCurrent??1)>0))return'shieldbearer';
  if(ms.some(w=>effectiveRange(w)>=10||/Упор|Крючье/.test(String(w.properties||''))))return'polearm';
  if(a.isCreature&&(a.creatureAttacks||[]).length&&!inventory.some(i=>i.kind==='weapon'&&i.equipped&&!i.damaged&&!i.thrown))return'monster';
  if(rs.length&&ms.length)return'skirmisher';
  if(rs.length)return'ranged';
  return'melee';
}
function weaponScore(a,w,distance=0,role='auto'){
  const range=effectiveRange(w),inRange=distance<=range+.01,bonus=(()=>{try{return E.attackBonus(a,w);}catch{return Number(w.fixedBonus||0);}})(),cost=Math.max(1,Number(w.cost||2)),props=String(w.properties||'');
  let score=Number(w.damage||1)*7+Number(w.piercing||0)*3+Number(w.die||4)*.55+bonus*2.2-cost*2.4;
  if(inRange)score+=14;else score-=Math.min(35,(distance-range)*.25);
  if(ranged(w)){score+=Math.min(8,range/45);if(!weaponReady(a,w))score-=Math.max(4,reloadCost(a,w)*3);}
  if(role==='melee'){score+=melee(w)?9:-5;}
  if(role==='polearm'){score+=melee(w)&&effectiveRange(w)>=10?10:melee(w)?1:-6;if(/Упор/.test(props))score+=8;if(/Крючье/.test(props))score+=3;}
  if(role==='shieldbearer'){score+=melee(w)?7:-4;if(effectiveRange(w)<=5)score+=2;}
  if(role==='skirmisher'){if(w.kind==='thrown')score+=10;else if(w.kind==='bow'&&(/Подвижный/.test(props)||range<=150))score+=7;else if(ranged(w))score+=4;else if(melee(w))score+=3;}
  if(role==='ranged'){score+=ranged(w)?9:-7;if(ranged(w)&&range>=120)score+=Math.min(6,range/60);}
  if(role==='monster'&&melee(w))score+=9;
  return score;
}
function bestWeapon(a,distance=0,role='auto'){return [...profiles(a)].sort((x,y)=>weaponScore(a,y,distance,role)-weaponScore(a,x,distance,role))[0]||null;}
function woundLoad(a){return (a.woundList||[]).reduce((sum,w)=>sum+Math.max(1,Number(w.severity||1))*2,0)+(a.wounds?.critical?10:0);}
function combatPower(a){
  if(!a||a.medical?.dead||a.wounds?.critical)return 0;
  const ws=profiles(a),best=ws.reduce((m,w)=>Math.max(m,weaponScore(a,w,Math.min(60,effectiveRange(w)),inferRole(a))),0),magic=hasCombatMagic(a)?Number(a.weaponProficiencies?.['Магия']||0)*6+usableCombatSpells(a).length*1.4:0,shield=(a.inventory||[]).some(i=>i.kind==='shield'&&i.equipped&&Number(i.bzCurrent||0)>0)?7:0;
  return Math.max(1,best+magic+shield+Number(a.od||0)*2+Number(a.morale?.current||0)*.15-woundLoad(a)*1.7);
}
function spellUtility(a,spellId,{distance=0,enemiesInArea=1,alliesInArea=0,target=null,role='caster'}={}){
  const spell=E.catalog.spells.find(s=>s.id===spellId);if(!spell||!usableCombatSpells(a).includes(spellId))return-Infinity;const range=Number(spell.rangeFeet||0);if(range&&distance>range+.01)return-Infinity;
  let score=10+Number(spell.threshold||0)*2;
  if(OFFENSIVE_SPELLS.has(spellId))score+=12;if(SUPPORT_SPELLS.has(spellId))score+=role==='medic'||role==='shieldbearer'?10:3;
  if(AREA_SPELLS.has(spellId))score+=enemiesInArea*10-alliesInArea*28;
  if(spellId==='spell-03'&&!target?.medical?.bleeding)return-Infinity;
  if(spellId==='spell-12'&&!target?.woundList?.some(w=>[1,2].includes(Number(w.severity))))return-Infinity;
  if(spellId==='spell-28')score+=role==='caster'||role==='shieldbearer'?4:0;
  return score;
}
function chooseSpell(a,options={}){let best=null;for(const id of usableCombatSpells(a)){const score=spellUtility(a,id,options);if(Number.isFinite(score)&&(!best||score>best.score))best={id,score,spell:E.catalog.spells.find(s=>s.id===id)};}return best;}

// Legacy helper used by the old sheet-side "npc-step" API. Kept compatible;
// the full map AI is implemented in battlemap-server.js and calls ToL actions.
async function step(a,ctx){
  E.assert(ctx.master&&a.isCreature,'Помощник управляет только существом Ведущего.');
  E.assert(ctx.combat&&ctx.activeId===a.id,'Сейчас ход другого участника.');
  if(a.medical.dead||a.wounds.critical)return {text:'Существо недееспособно.'};
  const enemies=ctx.actors.filter(t=>t.id!==a.id&&!t.medical.dead&&!t.wounds.critical&&ctx.hostile(a,t)&&ctx.visible(a,t)).sort((x,y)=>ctx.distance(a,x)-ctx.distance(a,y));
  if(!enemies.length)return {text:'Нет видимого противника. Ведущий может выбрать дальнейшее поведение.'};
  const target=enemies[0];
  if(!a.fearless&&a.morale.current===0){const moved=await ctx.moveToward?.(a,target,{retreat:true});return {text:moved?'Существо отступает из-за нулевой Морали.':'Путь отступления закрыт.',moved:!!moved};}
  if(E.has(a,'prone')&&a.odCurrent>=1)return C.tactical(a,null,{tactical:'stand'},ctx);
  const choices=profiles(a).filter(w=>(w.kind==='bow'?1:w.cost)<=a.odCurrent).sort((x,y)=>weaponScore(a,y,ctx.distance(a,target))-weaponScore(a,x,ctx.distance(a,target)));
  if(!choices.length)return {text:'Недостаточно ОД для доступных атак.'};
  let weapon=choices.find(w=>ctx.distance(a,target)<=effectiveRange(w));if(!weapon){await ctx.moveToward?.(a,target,{reach:effectiveRange(choices[0])});weapon=choices.find(w=>ctx.distance(a,target)<=effectiveRange(w));}
  if(!weapon)return {text:'Существо приблизилось настолько, насколько позволяет свободный путь и Скорость.'};
  if(['bow','crossbow','firearm'].includes(weapon.kind)&&!weaponReady(a,weapon)){const cost=reloadCost(a,weapon);if(cost>a.odCurrent)return {text:'На подготовку оружия не хватает ОД.'};return C.reload(a,{weaponId:weapon.id},ctx);}
  return C.attack(a,target,{weaponId:weapon.id},ctx);
}
module.exports={COMBAT_SPELLS,OFFENSIVE_SPELLS,AREA_SPELLS,SUPPORT_SPELLS,profiles,ranged,melee,effectiveRange,weaponReady,reloadCost,usableCombatSpells,hasCombatMagic,inferRole,weaponScore,bestWeapon,combatPower,spellUtility,chooseSpell,step};
