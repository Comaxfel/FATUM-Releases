'use strict';
const E=require('./engine');const {assert,n,level,has,effect,die,skill,weapon,attackBonus,pay,requireTarget,rollWeapon,damage,addWound,morale,use,equipped,project}=E;
function condition(a,w,b={}){return Number(Boolean(b.advantage))-Number(Boolean(b.hindrance||a.wounds.medium&&level(a,'Крепкий')<2||has(a,'bound')&&w.kind==='melee'&&w.cost>=3));}
function consume(a,w,b){if(w.kind==='bow'){assert(a.ready[w.id]?.drawn,'Сначала натяните лук.');a.ready[w.id].drawn=false;}
 if(['crossbow','firearm'].includes(w.kind)){assert(n(a.ready[w.id]?.loaded)>0,'Оружие не заряжено.');a.ready[w.id].loaded--;}
 if(w.ammo&&w.kind==='bow'){if(b.reserve){assert(a.resources.reserve>0&&level(a,'Бережливый')>0,'Нет Запаса.');a.resources.reserve--;}else{assert(a.ammo[w.ammo]>0,'Нет боеприпасов.');a.ammo[w.ammo]--;}}
 if(w.kind==='thrown'&&w.name!=='Праща'){const item=a.inventory.find(i=>i.id===w.id);item.thrown=true;item.equipped=false;}
}
function attack(a,t,b,ctx){const w=weapon(a,b.weaponId),melee=w.kind==='melee',gap=b.gap===true;requireTarget(a,t,ctx,melee?w.reach:w.range);assert(!has(a,'bound')||w.reach<10,'Длинное оружие неприменимо в Захвате.');assert(!has(a,'soul-out'),'Тело обездвижено.');
 if(b.lantern){assert(t.species==='fari'&&t.resources.lantern>0,'У цели нет целого Фонаря Души.');b={...b,hindrance:true};}const wasHidden=has(a,'hidden');let advantage=!!b.advantage,hindrance=!!b.hindrance,bonus=attackBonus(a,w,ctx),cost=gap?3:w.cost;
 if(w.kind==='bow'){const strength=E.baseSkill(a,'Физическая сила'),required=n(String(w.requirement||'').match(/\d+/)?.[0]);assert(strength>=required,'Не выполнено требование Силы лука.');cost=1;}
 const distance=ctx.distance?.(a,t)??n(b.distance,5);if(!melee&&distance>w.range/2)hindrance=true;
 if(!melee&&ctx.engaged?.(t))hindrance=true;
 if(!melee&&ctx.engaged?.(a)){if(w.kind==='bow')assert(!has(a,'bound')&&w.name!=='Тяжёлый боевой лук','Лук нельзя использовать в этих условиях.');if(w.kind==='firearm'&&w.name.includes('ружьё'))assert(distance>5||!b.shortDistance,'Ружьё неприменимо на Короткой дистанции.');hindrance=true;}
 if(gap&&!w.properties.includes('Точное'))hindrance=true;
 if(melee&&w.properties.includes('Тесное')&&distance<=5)bonus--;
 if(has(a,'bound')&&w.reach===5&&['Малое оружие','Безоружный бой'].includes(w.category))advantage=true;
 if(has(a,'hidden'))advantage=true;
 if(!melee&&has(a,'aim')){bonus++;a.effects=a.effects.filter(e=>e.key!=='aim');}
 if(!melee&&a.mounted){if(a.mountDashed)hindrance=true;else if(a.moved)bonus--;}
 if(w.name==='Револьверное ружьё'&&!a.moved)bonus++;
 if(has(a,'recoil'))bonus--;
 if(a.effects.some(e=>e.key==='priglyadka'&&e.targetId===t.id)){bonus++;a.effects=a.effects.filter(e=>e.key!=='priglyadka');}
 if(a.effects.some(e=>e.key==='watch'&&e.targetId===t.id)&&!a.used.round.watch){bonus++;a.used.round.watch=true;}
 for(const e of a.effects.filter(e=>e.nextAttack&&(!e.targetId||e.targetId===t.id))){bonus+=n(e.modifier);advantage ||= !!e.advantage;}
 const m=b.mastery?require('./features').combatMastery(a,t,w,b.mastery,b,ctx):{};bonus+=n(m.bonus);advantage ||= !!m.advantage;
 const gm=E.takeNextRollDirective(a);advantage ||= !!gm.advantage;hindrance ||= !!gm.hindrance;
 if(!ctx.freeAttack)pay(a,cost,ctx);consume(a,w,b);if(distance<=5.01)ctx.engage?.(a,t);const ar=rollWeapon(w.die,condition(a,w,{advantage,hindrance}),ctx.rng);const extra=m.extraDie?die(m.extraDie,ctx.rng):0;
 const result={id:E.id(),kind:melee?'melee':'ranged',actorId:a.id,targetId:t.id,weapon:E.clone(w),rolls:ar.rolls,roll:ar.value,bonus,extra,total:ar.value+bonus+extra,mastery:b.mastery||null,masteryEffect:m,attackOptions:E.clone(b),cost,piercing:n(w.piercing)+(gap?2:0)+n(m.piercing),damage:w.damage+(a.mounted&&b.mountedCharge?1:0)+(w.id==='unarmed'&&level(a,'Сильный')>=6?1:0),damageType:w.properties.includes('Универс')&&b.damageType==='pierce'?'pierce':w.damageType,extraDie:m.extraDie||0,condition:condition(a,w,{advantage,hindrance}),gmForcedOutcome:gm.forcedOutcome||null,gmRollDirective:gm.sources||[]};
 if(a.mounted&&b.mountedCharge){assert(n(a.movedFeet)>=20,'Для Конного натиска нужно пройти 20 футов по прямой.');pay(a,1,ctx);}
 a.effects=a.effects.filter(e=>!e.nextAttack&&e.key!=='hidden');
 if(melee){result.defensePending=true;result.hiddenPenalty=wasHidden?-1:0;}
 else{const cover=ctx.cover?.(a,t)??n(b.cover);assert(cover!==Infinity,'Полное укрытие.');result.target=E.mz(t,cover,['bow','crossbow','thrown'].includes(w.kind));if(level(t,'Вдумчивый')>=2&&t.effects.some(e=>e.key==='studied'&&e.targetId===a.id)&&!t.used.round.studiedDefense){result.target++;t.used.round.studiedDefense=true;}result.hit=result.total>=result.target;result.margin=result.total-result.target;if(gm.forcedOutcome)result.hit=gm.forcedOutcome==='success';}
 if(w.name==='Тяжёлый револьверный пистолет'&&E.baseSkill(a,'Физическая сила')<2)effect(a,'recoil','−1 к следующей атаке от отдачи.',{nextAttack:true,modifier:-1});
 return result;
}
function defend(result,a,t,b,ctx){assert(result.defensePending,'Защита уже выбрана.');if(t.medical.dead||t.wounds.critical){result.defensePending=false;result.target=0;result.margin=result.total;result.hit=result.margin>0;result.superiority=result.margin>=5?2:result.margin>=3?1:0;result.counterAvailable=false;result.defense={mode:'incapacitated',total:0};return result;}const mode=b.defense||'parry';assert(['parry','dodge','shield'].includes(mode),'Неизвестный способ защиты.');const w=weapon(t,b.weaponId),p=skill(t,'Акробатика',{combat:true});let sides=mode==='dodge'?p.sides:w.die,bonus=mode==='dodge'?p.bonus:attackBonus(t,w,ctx);
 const shield=equipped(t,'shield');if(mode==='shield'){assert(shield&&shield.bzCurrent>0,'Нет исправного щита.');bonus+=n(shield.defense);if(result.weapon.name==='Кистень')bonus--;}
 if(mode!=='dodge'&&w.properties.includes('Быстрое'))bonus++;
 if(has(t,'stance')&&!has(t,'surprised')){bonus+=1;const stance=t.effects.find(e=>e.key==='stance');if(stance)stance.toggleUsed=true;}
 if(t.effects.some(e=>e.key==='watch'&&e.targetId===a.id)&&!t.used.round.watch){bonus++;t.used.round.watch=true;}if(t.effects.some(e=>e.key==='priglyadka'&&e.targetId===a.id)){bonus++;t.effects=t.effects.filter(e=>e.key!=='priglyadka');}bonus-=Math.min(2,t.resources.defenses);t.resources.defenses++;bonus+=n(result.hiddenPenalty);
 if(level(t,'Вдумчивый')>=2&&t.effects.some(e=>e.key==='studied'&&e.targetId===a.id)&&!t.used.round.studiedDefense){bonus++;t.used.round.studiedDefense=true;}
 const defenseEffects=t.effects.filter(e=>(e.defenseAdvantage||e.nextDefense||['studied-attack','weakness','leader'].includes(e.key))&&(!e.targetId||e.targetId===a.id));for(const e of defenseEffects)bonus+=n(e.modifier);const gm=E.takeNextRollDirective(t),defenseAdvantage=Boolean(b.advantage||gm.advantage||defenseEffects.some(e=>e.defenseAdvantage||e.advantage)),defenseHindrance=Boolean(b.hindrance||gm.hindrance),defenseCondition=condition(t,w,{...b,advantage:defenseAdvantage,hindrance:defenseHindrance}),dr=rollWeapon(sides,defenseCondition,ctx.rng);t.effects=t.effects.filter(e=>!defenseEffects.includes(e));result.defense={mode,weapon:w,sides,condition:defenseCondition,counterAllowed:!has(t,'surprised'),rolls:dr.rolls,roll:dr.value,bonus,total:dr.value+bonus,gmForcedOutcome:gm.forcedOutcome||null,gmRollDirective:gm.sources||[]};result.target=result.defense.total;result.margin=result.total-result.target;result.hit=result.margin>0;if(gm.forcedOutcome)result.hit=gm.forcedOutcome==='failure';if(result.gmForcedOutcome)result.hit=result.gmForcedOutcome==='success';result.defensePending=false;
 result.superiority=result.margin>=5?2:result.margin>=3?1:0;if(result.superiority&&result.mastery==='Фехтовальщик')result.superiority=Math.max(2,result.superiority);
 result.counterAvailable=result.margin<=-3&&mode!=='dodge'&&!has(t,'surprised');return result;
}
function coin(r,a,ctx={}){
 assert(r.kind!=='magic'&&!r.defensePending&&!r.settled,'Нет доступного броска Обмена или атаки.');
 assert(a.resources.coins>0,'Нет Счастливых монет.');
 if(a.id===r.actorId){
  assert(!r.coinUsed&&!r.fortuneUsed,'Второй результат обязателен.');
  const roll=rollWeapon(r.weapon.die,r.condition,ctx.rng);r.rolls=roll.rolls;r.roll=roll.value;r.extra=r.extraDie?die(r.extraDie,ctx.rng):0;r.total=r.roll+r.bonus+r.extra;r.coinUsed=true;
 }else{
  const defense=r.defense;assert(a.id===r.targetId&&defense&&defense.mode!=='incapacitated','Нет своего броска защиты.');
  assert(!defense.coinUsed,'Второй результат обязателен.');
  const roll=rollWeapon(defense.sides||defense.weapon.die,defense.condition||0,ctx.rng);defense.rolls=roll.rolls;defense.roll=roll.value;defense.total=defense.roll+defense.bonus;defense.coinUsed=true;r.target=defense.total;
 }
 a.resources.coins--;r.margin=r.total-r.target;r.hit=r.kind==='melee'?r.margin>0:r.margin>=0;
 r.superiority=r.kind==='melee'?(r.margin>=5?2:r.margin>=3?1:0):0;
 if(r.superiority&&r.mastery==='Фехтовальщик')r.superiority=2;
 r.counterAvailable=r.kind==='melee'&&r.margin<=-3&&r.defense?.mode!=='dodge'&&r.defense?.mode!=='incapacitated'&&r.defense?.counterAllowed!==false;
 return r;
}

function fortune(r,a,ctx={}){
 assert(r&&r.kind!=='magic'&&!r.defensePending&&!r.settled,'Нет доступного броска Обмена или атаки.');
 assert(a.resources.fortune>0,'Нет Фортуны.');
 if(a.id===r.actorId){
  assert(!r.hit,'Фортуна атакующего доступна после неудачной атаки.');
  assert(!r.coinUsed&&!r.fortuneUsed,'Этот бросок уже перебрасывался.');
  const roll=rollWeapon(r.weapon.die,r.condition,ctx.rng);r.rolls=roll.rolls;r.roll=roll.value;r.extra=r.extraDie?die(r.extraDie,ctx.rng):0;
  const lucky=level(a,'Удачливый')>=3?die(4,ctx.rng):0;r.total=r.roll+r.bonus+r.extra+lucky;r.fortuneBonus=lucky;r.fortuneUsed=true;
 }else{
  assert(a.id===r.targetId&&r.hit&&level(a,'Удачливый')>=2,'Фортуна защитника сейчас неприменима.');
  assert(!r.coinUsed&&!r.fortuneForcedReroll,'Этот бросок уже перебрасывался.');
  // Удачливый 2 заставляет атакующего перебросить успешную атаку.
  const roll=rollWeapon(r.weapon.die,r.condition,ctx.rng);r.rolls=roll.rolls;r.roll=roll.value;r.extra=r.extraDie?die(r.extraDie,ctx.rng):0;r.total=r.roll+r.bonus+r.extra;r.fortuneForcedReroll=true;
 }
 a.resources.fortune--;r.margin=r.total-r.target;r.hit=r.kind==='melee'?r.margin>0:r.margin>=0;
 r.superiority=r.kind==='melee'?(r.margin>=5?2:r.margin>=3?1:0):0;
 if(r.superiority&&r.mastery==='Фехтовальщик')r.superiority=2;
 r.counterAvailable=r.kind==='melee'&&r.margin<=-3&&r.defense?.mode!=='dodge'&&r.defense?.mode!=='incapacitated'&&r.defense?.counterAllowed!==false;
 return r;
}

function settle(r,a,t,b,ctx){assert(!r.defensePending,'Защитник ещё не выбрал защиту.');assert(!r.settled,'Атака уже разрешена.');r.settled=true;const choices=[...new Set(b.superiority||[])];assert(choices.length<=(r.superiority||0),'Слишком много эффектов Превосходства.');
 if(r.hit){let d=r.damage;for(const choice of choices){if(choice==='damage')d++;else if(choice==='push'){ctx.push?.(a,t,5);}else if(choice==='opening')effect(a,'opening','+1 к следующему Обмену с целью.',{targetId:t.id,nextAttack:true,modifier:1,scope:'next-turn-end'});else if(choice==='shield'){assert(r.weapon.properties.includes('Щитолом'),'У профиля нет Щитолома.');const s=t.inventory.find(x=>x.kind==='shield'&&x.equipped);assert(s,'У цели нет щита.');s.bzCurrent=Math.max(0,s.bzCurrent-1);}else if(choice==='hook'){assert(r.weapon.properties.includes('Крючье'),'У профиля нет Крючья.');ctx.pull?.(a,t,5);}else if(choice==='grapple'){assert(a.species==='gnoll'&&r.weapon.id==='natural','Это эффект челюстей Гнолла.');effect(t,'bound','Захвачен челюстями.',{sourceId:a.id,grapple:true,scope:'combat'});}else assert(false,'Неизвестный эффект Превосходства.');}
 if(r.attackOptions.lantern){const before=t.resources.lantern;require('./features').speciesAction(t,null,{feature:'lantern-damage',damage:d},ctx);r.applied={lanternDamage:before-t.resources.lantern,integrity:t.resources.lantern};}else r.applied=damage(t,d,r.damageType,{...ctx,sourceId:a.id},{piercing:r.piercing});
 if(has(t,'bow-drawn')||Object.values(t.ready).some(x=>x.drawn)){r.holdCheck=E.check(t,'Выдержка',{difficulty:6},ctx);if(!r.holdCheck.success)for(const ready of Object.values(t.ready))ready.drawn=false;}
 }else if(level(a,'Бдительный')>=3)effect(a,'priglyadka','+1 к следующей атаке/Обмену против этой цели.',{targetId:t.id,scope:'next-turn-end'});
 if(r.kind==='melee'&&!r.hit&&r.defense?.mode==='dodge'&&level(t,'Ловкий')>=3)effect(t,'free-move','Лёгкий шаг: 5 футов без реакции атакующего.',{feet:5,ignoreId:a.id,scope:'turn'});
 if(r.kind==='melee'&&!r.hit&&level(t,'Ловкий')>=6&&!t.used.round['Неуловимый']){use(t,'Неуловимый','round');effect(t,'free-move','Неуловимый: 5 футов без реакции атакующего.',{feet:5,ignoreId:a.id,scope:'turn'});}
 if(r.counterAvailable)effect(t,'counter','Встречный удар за 1 ОД без нового Обмена.',{targetId:a.id,weaponId:r.defense.weapon.id,scope:'reaction',damage:r.defense.weapon.damage,damageType:r.defense.weapon.damageType,piercing:r.defense.weapon.piercing});
 if(['Засадник','Метатель'].includes(r.mastery))effect(a,'free-move','Манёвр Мастерства: 5 футов.',{feet:5,scope:'turn'});
 project(a);project(t);return r;
}
function reload(a,b,ctx){const w=weapon(a,b.weaponId);a.ready[w.id]||={loaded:0,drawn:false};const ready=a.ready[w.id];assert(['bow','crossbow','firearm'].includes(w.kind),'Это оружие не требует подготовки.');
 if(w.kind==='bow'){assert(!has(a,'bound'),'Нельзя натянуть лук в Захвате.');assert(!ready.drawn,'Лук уже натянут.');assert(!(ctx.engaged?.(a)&&w.name==='Тяжёлый боевой лук'),'Тяжёлый лук нельзя натянуть под давлением.');pay(a,w.name==='Тяжёлый боевой лук'?2:1,ctx);ready.drawn=true;ready.expiresTurn=n(a.turnSerial)+1;return {text:'Лук натянут.'};}
 if(w.kind==='crossbow'){assert(!ctx.engaged?.(a),'Нельзя перезаряжать арбалет под непосредственным давлением.');assert(!ready.loaded,'Арбалет уже заряжен.');if(w.name==='Тяжёлый арбалет'&&a.moved)assert(b.mastery==='Арбалетчик','Тяжёлый арбалет перезаряжается без перемещения.');}
 let cost=w.reload;if(b.mastery==='Арбалетчик'){assert(w.kind==='crossbow'&&a.mastery.includes('Арбалетчик'),'Мастерство недоступно.');use(a,'Арбалетчик','combat');assert(!a.used.round.costReduction,'В этом раунде уже применено снижение стоимости.');a.used.round.costReduction=true;cost=Math.max(1,cost-1);}
 const capacity=w.capacity||1,count=w.kind==='crossbow'?1:Math.min(2,capacity-ready.loaded);assert(count>0,'Все каморы уже заряжены.');let actual=Math.min(count,a.ammo[w.ammo]);if(b.reserve){assert(w.kind==='crossbow'&&level(a,'Бережливый')>0&&a.resources.reserve>0,'Запас доступен только персонажу с чертой «Бережливый» и не заменяет древние заряды.');a.resources.reserve--;actual=1;}else{assert(actual>0,'Нет боеприпасов.');a.ammo[w.ammo]-=actual;}pay(a,cost,ctx);if(w.name==='Тяжёлый арбалет'&&b.mastery!=='Арбалетчик')effect(a,'immobile','Перезарядка тяжёлого арбалета: без перемещения в этот ход.',{scope:'turn'});ready.loaded+=actual;return {text:`Заряжено: ${actual}.`,cost};
}
function tactical(a,t,b,ctx){
 const action=b.tactical,costs={aim:1,stance:1,dash:2,withdraw:2,charge:1,brace:1,jump:1,climb:2,grapple:2,escape:2,mount:1,dismount:1,stand:1,intercept:0,counter:1};assert(Object.hasOwn(costs,action),'Нет такого действия TOL.');
 const toggleKeys=new Set(['aim','stance','dash','withdraw','mount']),existing=toggleKeys.has(action)?a.effects.find(e=>e.key===action&&e.toggleAction===action):null;
 const refundToggle=e=>{assert(!e.toggleUsed,`${e.toggleLabel||e.description||'Действие'} уже использовано и не может быть отменено.`);a.odCurrent+=n(e.toggleSpentOd);a.resources.debt=Math.max(0,n(a.resources.debt)-n(e.toggleSpentDebt));a.effects=a.effects.filter(x=>x.id!==e.id);if(action==='dash')a.used.round.dash=false;if(action==='mount'){delete a.mounted;delete a.mountSpeed;}project(a);return {kind:'tactical-toggle',action,toggledOff:true,refunded:n(e.toggleSpentOd)+n(e.toggleSpentDebt),text:`${e.toggleLabel||e.description||'Действие'} отменено. ОД возвращены.`};};
 if(existing)return refundToggle(existing);
 if(action==='counter'){const e=a.effects.find(e=>e.key==='counter'&&e.targetId===t?.id);assert(e,'Нет открытия для Встречного удара.');assert(!has(a,'surprised'),'Застигнутый врасплох не может отвечать.');const w=weapon(a,e.weaponId);requireTarget(a,t,ctx,w.reach);pay(a,1,ctx,{reaction:true});a.effects=a.effects.filter(x=>x.id!==e.id);const applied=damage(t,e.damage,e.damageType,{...ctx,sourceId:a.id},{piercing:e.piercing});return {id:E.id(),kind:'melee',actorId:a.id,targetId:t.id,weapon:E.clone(w),hit:true,settled:true,counter:true,damage:e.damage,damageType:e.damageType,piercing:e.piercing,applied,text:`Встречный удар: ${w.name}.`};}
 if(action==='brace'){const existingBrace=a.effects.find(e=>e.key==='brace');if(existingBrace){a.effects=a.effects.filter(e=>e!==existingBrace);project(a);return {kind:'tactical-toggle',action,toggledOff:true,text:'Упор снят.'};}const item=a.inventory.find(i=>i.kind==='weapon'&&i.equipped&&!i.thrown);assert(item,'Для Упора нужно экипированное оружие.');const w=weapon(a,item.id);assert(w.kind==='melee'&&w.properties.includes('Упор'),'Экипированное оружие не имеет свойства «Упор».');pay(a,1,ctx);effect(a,'brace','Упор: противники не могут войти в соседнюю клетку без Натиска.',{weaponId:w.id,scope:'combat'});project(a);return {kind:'tactical-toggle',action,toggledOn:true,text:`Упор установлен: ${w.name}.`};}
 // Validate impossible tactical actions before paying OD. The service layer also
 // rolls a failed transaction back, but these preflights make the combat core
 // itself safe and keep delayed/interactive actions from ever consuming OD on
 // an invalid target, range or state.
 if(action==='dash')assert(!a.used.round.dash,'Рывок уже выполнен.');
 if(action==='grapple'||action==='escape')requireTarget(a,t,ctx,5);
 if(action==='mount'){requireTarget(a,t,ctx,5);assert(t.isMount,'Цель не скакун.');}
 if(action==='dismount')assert(a.mounted,'Персонаж не находится верхом.');
 if(action==='stand')assert(has(a,'prone'),'Персонаж уже стоит.');
 if(action==='charge')requireTarget(a,t,ctx,10);
 if(action==='intercept'){assert(!has(a,'surprised'),'Нельзя Перехватить до первого хода.');const iw=weapon(a,b.weaponId);assert(iw.properties.includes('Упор'),'Нет свойства Упор.');assert(t?.effects.some(e=>e.key==='charge'&&e.targetId===a.id),'Цель не объявляла Натиск.');weapon(t,b.targetWeaponId);}
 const beforeOd=n(a.odCurrent),beforeDebt=n(a.resources.debt);pay(a,costs[action],ctx,{reaction:action==='intercept'});const toggleMeta=label=>({toggleAction:action,toggleLabel:label,toggleSpentOd:Math.max(0,beforeOd-n(a.odCurrent)),toggleSpentDebt:Math.max(0,n(a.resources.debt)-beforeDebt),toggleUsed:false,activatedMovedFeet:n(a.movedFeet)});
 if(action==='aim')effect(a,'aim','+1 к следующей дальней атаке без движения.',{scope:'turn',...toggleMeta('Прицеливание')});
 if(action==='stance')effect(a,'stance','+1 к защитным Обменам до начала следующего хода.',{scope:'next-turn-start',...toggleMeta('Защитная стойка')});
 if(action==='dash'){a.used.round.dash=true;effect(a,'dash','Удвоенная Скорость на раунд.',{scope:'round',...toggleMeta('Рывок')});}
 if(action==='withdraw')effect(a,'withdraw','Безопасный выход из ближнего боя.',{scope:'turn',...toggleMeta('Отход')});
 if(action==='grapple'||action==='escape'){const defenseSkill=b.defense==='dodge'?'Акробатика':'Физическая сила',atk=E.check(a,'Физическая сила',{difficulty:6,advantage:a.species==='gnoll'||has(a,'predator')},ctx),def=skill(t,defenseSkill);const defense=rollWeapon(def.sides,t.species==='gnoll'?1:0,ctx.rng),success=atk.roll+atk.bonus>=defense.value+def.bonus;if(success){if(action==='escape')a.effects=a.effects.filter(e=>e.key!=='bound');else effect(t,'bound','Захват: Скорость 0; короткое оружие с Преимуществом.',{sourceId:a.id,grapple:true,scope:'combat'});}return {kind:'grapple',action,actorId:a.id,targetId:t.id,success,total:atk.roll+atk.bonus,target:defense.value+def.bonus,attackRoll:atk.roll,attackBonus:atk.bonus,defenseSkill,defenseRoll:defense.value,defenseBonus:def.bonus,text:success?(action==='escape'?'Захват разорван.':'Захват успешен.'):(action==='escape'?'Вырваться не удалось.':'Захват не удался.')};}
 if(action==='mount'){a.mounted=t.id;a.mountSpeed=E.speed(t);effect(a,'mount','Верхом: используйте повторно до движения, чтобы отменить посадку и вернуть ОД.',{scope:'scene',mountId:t.id,...toggleMeta('Верхом')});}
 if(action==='dismount'){delete a.mounted;delete a.mountSpeed;a.effects=a.effects.filter(e=>e.key!=='mount');}
 if(action==='stand')a.effects=a.effects.filter(e=>e.key!=='prone');
 if(action==='jump'||action==='climb')return E.check(a,'Акробатика',{difficulty:b.difficulty||6,hindrance:b.heavyArmor},ctx);
 if(action==='charge'){const brace=t.effects.find(e=>e.key==='brace');if(brace){t.effects=t.effects.filter(e=>e!==brace);project(t);}effect(a,'charge','Натиск заявлен: Упор цели преодолён; возможен Перехват.',{targetId:t.id,scope:'turn'});}
 if(action==='intercept'){const w=weapon(a,b.weaponId),ar=rollWeapon(w.die,b.mastery==='Копейщик'?1:0,ctx.rng),tw=weapon(t,b.targetWeaponId),tr=rollWeapon(tw.die,0,ctx.rng);if(b.mastery==='Копейщик'){assert(a.mastery.includes('Копейщик'),'Нет Мастерства.');use(a,'Копейщик','combat');}const success=ar.value+attackBonus(a,w)>tr.value+attackBonus(t,tw);if(success){t.effects=t.effects.filter(e=>e.key!=='charge');effect(t,'charge-stopped','Натиск остановлен на Длинной дистанции.',{scope:'turn'});}return {success,total:ar.value+attackBonus(a,w),target:tr.value+attackBonus(t,tw)};}
 return {text:'Действие применено.'};
}
function startTurn(a){a.turnSerial=n(a.turnSerial)+1;a.resources.defenses=0;a.used.round={};a.effects=a.effects.filter(e=>e.scope!=='next-turn-start'&&e.key!=='surprised');a.odCurrent=Math.max(0,E.baseOd(a)-a.resources.debt);a.resources.debt=0;a.moved=false;a.movedFeet=0;for(const r of Object.values(a.ready))if(r.drawn&&r.expiresTurn<a.turnSerial)r.drawn=false;project(a);}
function endTurn(a,ctx){if(a.medical.dead)return project(a);if(a.medical.bleeding)addWound(a,1,{mandatory:true});if(a.woundList.some(w=>w.severity===4)&&!a.medical.stabilized){a.medical.criticalRounds=n(a.medical.criticalRounds)+1;if(a.medical.criticalRounds>=(level(a,'Крепкий')>=5?4:3)){if(level(a,'Удачливый')>=6&&!a.used.rest['Последний шанс']){use(a,'Последний шанс','rest');a.medical.stabilized=true;a.medical.criticalRounds=0;a.woundList=a.woundList.filter(w=>w.severity!==4);effect(a,'recovery','Восстановление после стабилизации: −2 к проверкам.',{scope:'rest',allChecks:true,modifier:-2});effect(a,'trauma-pending','Ведущий назначает подходящую Травму.',{scope:'permanent',needsGm:true});}else{a.medical.dead=true;if(a.species==='krif'){a.resources.memory=Math.max(0,a.resources.memory-1);a.medical.returnAt=n(ctx.clock)+die(6,ctx.rng)*60;}if(a.species==='fari'&&a.resources.lantern>0)a.medical.returnAt=n(ctx.clock)+(a.medical.bodyDestroyed?1440:480);}}}a.effects=a.effects.filter(e=>!['turn','round','reaction'].includes(e.scope)&&!(e.scope==='next-turn-end'&&n(a.turnSerial)>n(e.createdTurn)));project(a);}
module.exports={attack,defend,coin,fortune,settle,reload,tactical,startTurn,endTurn};
