'use strict';

const { timingSafeEqual } = require('crypto');

const DEFAULT_SECURITY_HEADERS = Object.freeze({
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'same-origin',
  'X-Frame-Options': 'SAMEORIGIN',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy': "object-src 'none'; base-uri 'self'; frame-ancestors 'self'"
});

function secureEquals(a, b) {
  const left = Buffer.from(String(a || ''), 'utf8');
  const right = Buffer.from(String(b || ''), 'utf8');
  return Boolean(left.length && left.length === right.length && timingSafeEqual(left, right));
}

function parseCookies(req) {
  const result = {};
  const header = String(req?.headers?.cookie || '');
  for (const part of header.split(';')) {
    const index = part.indexOf('=');
    if (index < 0) continue;
    const key = part.slice(0, index).trim();
    if (!key) continue;
    const value = part.slice(index + 1).trim();
    try { result[key] = decodeURIComponent(value); }
    catch { result[key] = value; }
  }
  return result;
}

function isLoopbackAddress(value) {
  const address = String(value || '').trim().toLowerCase();
  return address === '127.0.0.1' || address === '::1' || address === '::ffff:127.0.0.1';
}

function isLoopbackRequest(req) { return isLoopbackAddress(req?.socket?.remoteAddress); }

function requestIp(req) {
  // FATUM intentionally has no reverse-proxy trust mode. Using the real socket
  // address avoids spoofable X-Forwarded-For values on LAN/Radmin networks.
  return String(req?.socket?.remoteAddress || 'unknown').toLowerCase();
}

function requestOriginAllowed(req) {
  const rawOrigin = String(req?.headers?.origin || '').trim();
  if (!rawOrigin) return true; // Native clients, curl and same-machine tooling.
  if (rawOrigin === 'null') return false;
  let origin;
  try { origin = new URL(rawOrigin); }
  catch { return false; }
  if (!/^https?:$/.test(origin.protocol)) return false;
  const host = String(req?.headers?.host || '').trim().toLowerCase();
  return Boolean(host && origin.host.toLowerCase() === host);
}

function applySecurityHeaders(res, additional = null) {
  if (!res || res.__fatumSecurityHeadersApplied) return res;
  res.__fatumSecurityHeadersApplied = true;
  const defaults = additional ? { ...DEFAULT_SECURITY_HEADERS, ...additional } : DEFAULT_SECURITY_HEADERS;
  for (const [name, value] of Object.entries(defaults)) {
    if (!res.hasHeader(name)) res.setHeader(name, value);
  }
  return res;
}

class FixedWindowRateLimiter {
  constructor({ windowMs = 60_000, limit = 1200, maxKeys = 4096 } = {}) {
    this.windowMs = Math.max(1000, Number(windowMs) || 60_000);
    this.limit = Math.max(1, Number(limit) || 1200);
    this.maxKeys = Math.max(64, Number(maxKeys) || 4096);
    this.entries = new Map();
  }

  consume(key, cost = 1, now = Date.now()) {
    const normalizedKey = String(key || 'unknown');
    let entry = this.entries.get(normalizedKey);
    if (!entry || now - entry.startedAt >= this.windowMs) {
      entry = { startedAt: now, count: 0, lastSeenAt: now };
      this.entries.set(normalizedKey, entry);
    }
    entry.lastSeenAt = now;
    entry.count += Math.max(1, Number(cost) || 1);
    if (this.entries.size > this.maxKeys) this.prune(now);
    const remaining = Math.max(0, this.limit - entry.count);
    const retryAfterMs = Math.max(0, entry.startedAt + this.windowMs - now);
    return { allowed: entry.count <= this.limit, remaining, retryAfterMs, limit: this.limit };
  }

  prune(now = Date.now()) {
    const staleBefore = now - this.windowMs * 2;
    for (const [key, entry] of this.entries) if (entry.lastSeenAt < staleBefore) this.entries.delete(key);
    if (this.entries.size <= this.maxKeys) return;
    const sorted = [...this.entries.entries()].sort((a, b) => a[1].lastSeenAt - b[1].lastSeenAt);
    for (const [key] of sorted.slice(0, this.entries.size - this.maxKeys)) this.entries.delete(key);
  }
}

module.exports = {
  DEFAULT_SECURITY_HEADERS,
  secureEquals,
  parseCookies,
  isLoopbackAddress,
  isLoopbackRequest,
  requestIp,
  requestOriginAllowed,
  applySecurityHeaders,
  FixedWindowRateLimiter
};
