'use strict';

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { createHash } = require('crypto');
const { spawn } = require('child_process');

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(buffer) {
  let crc = 0xFFFFFFFF;
  for (const byte of buffer) crc = CRC_TABLE[(crc ^ byte) & 0xFF] ^ (crc >>> 8);
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function sha256(buffer) { return createHash('sha256').update(buffer).digest('hex'); }

function dosDateTime(dateValue = new Date()) {
  const date = dateValue instanceof Date ? dateValue : new Date(dateValue);
  const year = Math.max(1980, date.getFullYear());
  const time = ((date.getHours() & 31) << 11) | ((date.getMinutes() & 63) << 5) | (Math.floor(date.getSeconds() / 2) & 31);
  const day = ((year - 1980) << 9) | (((date.getMonth() + 1) & 15) << 5) | (date.getDate() & 31);
  return { time, date: day };
}

function safeZipName(value) {
  const name = String(value || '').replace(/\\/g, '/').replace(/^\/+/, '');
  if (!name || name.includes('\0') || name.split('/').some(part => !part || part === '.' || part === '..')) throw new Error('Некорректное имя файла внутри архива.');
  return name;
}

function createZip(entries, options = {}) {
  const localParts = [];
  const centralParts = [];
  const seenNames = new Set();
  let offset = 0;
  const now = dosDateTime(options.date || new Date());
  for (const raw of entries) {
    const name = safeZipName(raw.name);
    if (seenNames.has(name)) throw new Error(`Нельзя создать ZIP с дублирующейся записью «${name}».`);
    seenNames.add(name);
    const nameBuffer = Buffer.from(name, 'utf8');
    const source = Buffer.isBuffer(raw.data) ? raw.data : Buffer.from(raw.data || '');
    let method = 0;
    let compressed = source;
    if (raw.compress !== false && source.length > 256) {
      const candidate = zlib.deflateRawSync(source, { level: raw.level ?? 6 });
      if (candidate.length + 12 < source.length) { method = 8; compressed = candidate; }
    }
    const crc = crc32(source);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034B50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6);
    local.writeUInt16LE(method, 8);
    local.writeUInt16LE(now.time, 10);
    local.writeUInt16LE(now.date, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(compressed.length, 18);
    local.writeUInt32LE(source.length, 22);
    local.writeUInt16LE(nameBuffer.length, 26);
    local.writeUInt16LE(0, 28);
    localParts.push(local, nameBuffer, compressed);

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014B50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(0x0800, 8);
    central.writeUInt16LE(method, 10);
    central.writeUInt16LE(now.time, 12);
    central.writeUInt16LE(now.date, 14);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(compressed.length, 20);
    central.writeUInt32LE(source.length, 24);
    central.writeUInt16LE(nameBuffer.length, 28);
    central.writeUInt16LE(0, 30);
    central.writeUInt16LE(0, 32);
    central.writeUInt16LE(0, 34);
    central.writeUInt16LE(0, 36);
    central.writeUInt32LE(0, 38);
    central.writeUInt32LE(offset, 42);
    centralParts.push(central, nameBuffer);
    offset += local.length + nameBuffer.length + compressed.length;
  }
  const centralBuffer = Buffer.concat(centralParts);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054B50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(entries.length, 8);
  end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(centralBuffer.length, 12);
  end.writeUInt32LE(offset, 16);
  end.writeUInt16LE(0, 20);
  return Buffer.concat([...localParts, centralBuffer, end]);
}

function parseZip(buffer, options = {}) {
  if (!Buffer.isBuffer(buffer)) buffer = Buffer.from(buffer || '');
  const maxEntries = options.maxEntries || 10000;
  const maxEntryBytes = options.maxEntryBytes || 128 * 1024 * 1024;
  const maxTotalBytes = options.maxTotalBytes || 1024 * 1024 * 1024;
  const maxCompressionRatio = options.maxCompressionRatio || 500;
  let eocd = -1;
  const lower = Math.max(0, buffer.length - 65557);
  for (let index = buffer.length - 22; index >= lower; index -= 1) {
    if (buffer.readUInt32LE(index) === 0x06054B50) { eocd = index; break; }
  }
  if (eocd < 0) throw new Error('Не удалось найти структуру ZIP-архива.');
  const count = buffer.readUInt16LE(eocd + 10);
  const centralSize = buffer.readUInt32LE(eocd + 12);
  const centralOffset = buffer.readUInt32LE(eocd + 16);
  if (count > maxEntries || centralOffset + centralSize > buffer.length) throw new Error('Повреждённый или слишком большой ZIP-архив.');
  const entries = new Map();
  const centralEnd = centralOffset + centralSize;
  let cursor = centralOffset;
  let total = 0;
  for (let i = 0; i < count; i += 1) {
    if (cursor + 46 > buffer.length || buffer.readUInt32LE(cursor) !== 0x02014B50) throw new Error('Повреждённый каталог ZIP-архива.');
    const flags = buffer.readUInt16LE(cursor + 8);
    const method = buffer.readUInt16LE(cursor + 10);
    const expectedCrc = buffer.readUInt32LE(cursor + 16);
    const compressedSize = buffer.readUInt32LE(cursor + 20);
    const uncompressedSize = buffer.readUInt32LE(cursor + 24);
    const nameLength = buffer.readUInt16LE(cursor + 28);
    const extraLength = buffer.readUInt16LE(cursor + 30);
    const commentLength = buffer.readUInt16LE(cursor + 32);
    const localOffset = buffer.readUInt32LE(cursor + 42);
    const recordEnd = cursor + 46 + nameLength + extraLength + commentLength;
    if (recordEnd > centralEnd || recordEnd > buffer.length) throw new Error('Повреждённый каталог ZIP-архива.');
    if (flags & 0x0001) throw new Error('Зашифрованные ZIP-файлы не поддерживаются.');
    const name = safeZipName(buffer.subarray(cursor + 46, cursor + 46 + nameLength).toString((flags & 0x0800) ? 'utf8' : 'latin1'));
    if (entries.has(name)) throw new Error(`Архив содержит дублирующуюся запись «${name}».`);
    if (uncompressedSize > maxEntryBytes || total + uncompressedSize > maxTotalBytes) throw new Error('Распакованное содержимое архива превышает безопасный предел.');
    if (uncompressedSize > 0 && (compressedSize === 0 || uncompressedSize / compressedSize > maxCompressionRatio)) throw new Error(`Файл «${name}» имеет подозрительно высокий коэффициент сжатия.`);
    if (localOffset + 30 > buffer.length || buffer.readUInt32LE(localOffset) !== 0x04034B50) throw new Error('Повреждённая запись ZIP-архива.');
    const localFlags = buffer.readUInt16LE(localOffset + 6);
    const localMethod = buffer.readUInt16LE(localOffset + 8);
    const localNameLength = buffer.readUInt16LE(localOffset + 26);
    const localExtraLength = buffer.readUInt16LE(localOffset + 28);
    if ((localFlags & 0x0001) || localMethod !== method) throw new Error('Параметры ZIP-записи не совпадают с каталогом.');
    const localNameStart = localOffset + 30;
    const localNameEnd = localNameStart + localNameLength;
    if (localNameEnd > buffer.length) throw new Error('Повреждённое имя ZIP-записи.');
    const localName = safeZipName(buffer.subarray(localNameStart, localNameEnd).toString((localFlags & 0x0800) ? 'utf8' : 'latin1'));
    if (localName !== name) throw new Error('Имя ZIP-записи не совпадает с каталогом.');
    const dataOffset = localOffset + 30 + localNameLength + localExtraLength;
    if (dataOffset + compressedSize > buffer.length) throw new Error('Обрезанная запись ZIP-архива.');
    const compressed = buffer.subarray(dataOffset, dataOffset + compressedSize);
    let data;
    if (method === 0) data = Buffer.from(compressed);
    else if (method === 8) data = zlib.inflateRawSync(compressed, { maxOutputLength: maxEntryBytes });
    else throw new Error(`Метод сжатия ZIP ${method} не поддерживается.`);
    if (data.length !== uncompressedSize || crc32(data) !== expectedCrc) throw new Error(`Контрольная сумма файла «${name}» не совпадает.`);
    entries.set(name, data);
    total += data.length;
    cursor = recordEnd;
  }
  if (cursor !== centralEnd) throw new Error('Размер центрального каталога ZIP не совпадает.');
  return entries;
}

function runProcess(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'], ...options });
    let stderr = '';
    const timer = setTimeout(() => { child.kill(); reject(new Error(`${command}: превышено время ожидания.`)); }, options.timeout || 120000);
    child.stderr?.on('data', chunk => { if (stderr.length < 20000) stderr += chunk.toString(); });
    child.once('error', error => { clearTimeout(timer); reject(error); });
    child.once('close', code => { clearTimeout(timer); code === 0 ? resolve() : reject(new Error(`${command} завершился с кодом ${code}: ${stderr.trim().slice(-1000)}`)); });
  });
}

let ffmpegPromise = null;
function ffmpegAvailable() {
  if (!ffmpegPromise) ffmpegPromise = runProcess('ffmpeg', ['-version'], { timeout: 5000 }).then(() => true).catch(() => false);
  return ffmpegPromise;
}

let powershellPromise = null;
function powershellImageOptimizerAvailable() {
  if (process.platform !== 'win32') return Promise.resolve(false);
  if (!powershellPromise) powershellPromise = runProcess('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', 'Add-Type -AssemblyName System.Drawing; exit 0'], { timeout: 8000 }).then(() => true).catch(() => false);
  return powershellPromise;
}

function psLiteral(value) { return `'${String(value).replace(/'/g, "''")}'`; }

async function optimizeImageWithPowerShell(sourcePath, kind, temporaryDirectory) {
  const ext = path.extname(sourcePath).toLowerCase();
  if (!['.png', '.jpg', '.jpeg', '.bmp'].includes(ext) || !(await powershellImageOptimizerAvailable())) return null;
  const token = kind === 'token';
  const outputExt = token ? '.png' : '.jpg';
  const output = path.join(temporaryDirectory, `${Date.now()}-${Math.random().toString(16).slice(2)}${outputExt}`);
  const maximum = token ? 768 : (kind === 'portrait' ? 1200 : 4096);
  const quality = kind === 'portrait' ? 82 : 86;
  const script = `
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$source = ${psLiteral(sourcePath)}
$output = ${psLiteral(output)}
$image = [System.Drawing.Image]::FromFile($source)
try {
  $scale = [Math]::Min(1.0, ${maximum}.0 / [Math]::Max($image.Width, $image.Height))
  $width = [Math]::Max(1, [int][Math]::Round($image.Width * $scale))
  $height = [Math]::Max(1, [int][Math]::Round($image.Height * $scale))
  $format = ${token ? '[System.Drawing.Imaging.PixelFormat]::Format32bppArgb' : '[System.Drawing.Imaging.PixelFormat]::Format24bppRgb'}
  $bitmap = [System.Drawing.Bitmap]::new($width, $height, $format)
  try {
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    try {
      $graphics.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
      $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
      $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
      $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
      ${token ? '$graphics.Clear([System.Drawing.Color]::Transparent)' : '$graphics.Clear([System.Drawing.Color]::Black)'}
      $graphics.DrawImage($image, 0, 0, $width, $height)
    } finally { $graphics.Dispose() }
    ${token ? '$bitmap.Save($output, [System.Drawing.Imaging.ImageFormat]::Png)' : `
    $codec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq 'image/jpeg' } | Select-Object -First 1
    $parameters = [System.Drawing.Imaging.EncoderParameters]::new(1)
    try {
      $parameters.Param[0] = [System.Drawing.Imaging.EncoderParameter]::new([System.Drawing.Imaging.Encoder]::Quality, [long]${quality})
      $bitmap.Save($output, $codec, $parameters)
    } finally { $parameters.Dispose() }
    `}
  } finally { $bitmap.Dispose() }
} finally { $image.Dispose() }
`;
  const encoded = Buffer.from(script, 'utf16le').toString('base64');
  try {
    await runProcess('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], { timeout: 120000 });
    return { data:await fs.promises.readFile(output), extension:outputExt, processor:token ? 'powershell-png-resize' : 'powershell-jpeg' };
  } catch { return null; }
}

async function compactProcessorAvailable() {
  if (await ffmpegAvailable()) return 'ffmpeg';
  if (await powershellImageOptimizerAvailable()) return 'powershell-system-drawing';
  return 'portable-fallback';
}

async function optimizeMediaFile(sourcePath, kind, temporaryDirectory) {
  const original = await fs.promises.readFile(sourcePath);
  const ext = path.extname(sourcePath).toLowerCase();
  if (!(await ffmpegAvailable())) {
    if (kind !== 'audio') {
      const candidate = await optimizeImageWithPowerShell(sourcePath, kind, temporaryDirectory);
      if (candidate && candidate.data.length < original.length * 0.97) return { ...candidate, optimized:true };
    }
    return { data: original, extension: ext || '.bin', optimized: false, processor: 'original' };
  }
  let outputExt = ext;
  let args = null;
  if (['.png', '.jpg', '.jpeg', '.webp'].includes(ext)) {
    outputExt = '.webp';
    const output = path.join(temporaryDirectory, `${Date.now()}-${Math.random().toString(16).slice(2)}.webp`);
    const quality = kind === 'token' ? '84' : kind === 'portrait' ? '82' : '86';
    args = ['-hide_banner', '-loglevel', 'error', '-y', '-i', sourcePath, '-frames:v', '1', '-c:v', 'libwebp', '-quality', quality, '-compression_level', '2', '-preset', kind === 'token' ? 'picture' : 'photo', output];
    try {
      await runProcess('ffmpeg', args, { timeout: 60000 });
      const candidate = await fs.promises.readFile(output);
      if (candidate.length < original.length * 0.97) return { data: candidate, extension: outputExt, optimized: true, processor: 'ffmpeg-webp' };
    } catch {}
  } else if (['.mp3', '.wav', '.m4a', '.aac', '.ogg', '.webm'].includes(ext)) {
    outputExt = '.mp3';
    const output = path.join(temporaryDirectory, `${Date.now()}-${Math.random().toString(16).slice(2)}.mp3`);
    args = ['-hide_banner', '-loglevel', 'error', '-y', '-i', sourcePath, '-vn', '-c:a', 'libmp3lame', '-b:a', '160k', output];
    try {
      await runProcess('ffmpeg', args, { timeout: 240000 });
      const candidate = await fs.promises.readFile(output);
      if (candidate.length < original.length * 0.97) return { data: candidate, extension: outputExt, optimized: true, processor: 'ffmpeg-mp3-160k' };
    } catch {}
  }
  return { data: original, extension: ext || '.bin', optimized: false, processor: 'original' };
}

module.exports = { crc32, sha256, createZip, parseZip, ffmpegAvailable, powershellImageOptimizerAvailable, compactProcessorAvailable, optimizeMediaFile };
